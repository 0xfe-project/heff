// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_comments 142722952
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
V g_heff_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2elexGo_clo;
V g_heff_2efmt_2etoks_2eplainGo(V, V, V);
V g_heff_2efmt_2etoks_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2eplainGo_clo;
V g_heff_2eformat_2echeck(V, V);
V g_heff_2eformat_2echeck_entry(V self, V *a);
extern Clo g_heff_2eformat_2echeck_clo;
V g_heff_2eformat_2eformat(V);
V g_heff_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2eformat_2eformat_clo;
V g_heff_2eformat_2ekeyDeclF(V, V);
V g_heff_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2eformat_2ekeyDeclF_clo;
V g_heff_2eformat_2ekeyTermF(V, V);
V g_heff_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2eformat_2ekeyTermF_clo;
V g_heff_2eformat_2ekeys_get(void);
V g_heff_2eformat_2eparamKey(V, V);
V g_heff_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2eparamKey_clo;
V g_heff_2eformat_2epatKey(V);
V g_heff_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2epatKey_clo;
V g_heff_2eformat_2ereadNoFixities(V);
V g_heff_2eformat_2ereadNoFixities_entry(V self, V *a);
extern Clo g_heff_2eformat_2ereadNoFixities_clo;
V g_heff_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2eformat_2esameMeaning_clo;
V g_heff_2eformat_2estrsEq(V, V);
V g_heff_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2eformat_2estrsEq_clo;
V g_heff_2eimport_2eimportsGo(V, V, V);
V g_heff_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsGo_clo;
V g_heff_2esurface_2efixDecls(V, V, V);
V g_heff_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDecls_clo;
V g_heff_2esurface_2efixityFrom_24s968693116x98413397(V);
V g_heff_2esurface_2efixityFrom_24s968693116x98413397_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixityFrom_24s968693116x98413397_clo;
V g_heff_2esurface_2ereadToks_24s2076454845x2020338244(V, V, V);
V g_heff_2esurface_2ereadToks_24s2076454845x2020338244_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadToks_24s2076454845x2020338244_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1479019137x857976527(V);
V g_prelude_2emap_24s1479019137x857976527_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1479019137x857976527_clo;
V g_prelude_2emap_24s1559710030x546042594(V, V);
V g_prelude_2emap_24s1559710030x546042594_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1559710030x546042594_clo;
V g_prelude_2emap_24s1639847025x48103675(V);
V g_prelude_2emap_24s1639847025x48103675_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1639847025x48103675_clo;
V g_prelude_2emap_24s229671972x1653917392(V);
V g_prelude_2emap_24s229671972x1653917392_entry(V self, V *a);
extern Clo g_prelude_2emap_24s229671972x1653917392_clo;
V g_prelude_2emap_24s242074595x1610727405(V, V, V, V, V, V, V);
V g_prelude_2emap_24s242074595x1610727405_entry(V self, V *a);
extern Clo g_prelude_2emap_24s242074595x1610727405_clo;
V g_prelude_2emap_24s792566809x1637979488(V, V);
V g_prelude_2emap_24s792566809x1637979488_entry(V self, V *a);
extern Clo g_prelude_2emap_24s792566809x1637979488_clo;
V g_prelude_2emap_24s913954207x1153178935(V);
V g_prelude_2emap_24s913954207x1153178935_entry(V self, V *a);
extern Clo g_prelude_2emap_24s913954207x1153178935_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {111, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str30 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str34 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str36 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str39 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str40 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str42 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str45 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str47 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str48 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str50 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str51 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str55 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str56 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str58 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 101, 99, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2epatKey_str60 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str61 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str62 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str63 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str64 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2epatKey_str65 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2epatKey_str66 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str67 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str68 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str69 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str70 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str71 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str72 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str73 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2epatKey_str74 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str76 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str77 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2epatKey_str79 = {{0x80000000u, K_STR, 0}, 4, 4, {119, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str82 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str83 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str85 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2epatKey_entry, 1, 0};

V g_heff_2eformat_2epatKey(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
    V v_x2_246 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str0), v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eformat_2epatKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str3), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str4), heff_strAppend(v_t_249, ((V)&g_heff_2eformat_2epatKey_str5))));
  }
  case TAG_PatTag: {
    V v_t_2410 = heff_field(v_t_243, 0);
    V v_ps_2412 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2413 = (g_prelude_2emap(((V)&g_heff_2eformat_2epatKey_clo), v_ps_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eformat_2epatKey_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str7); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2eformat_2epatKey_str9)));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_parts_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2418});
    V v_x2_2420 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str10), v_parts_2419));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2eformat_2epatKey_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str13), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str14), heff_strAppend(v_t_2423, ((V)&g_heff_2eformat_2epatKey_str15))));
  }
  case TAG_PatOp: {
    V v_x_2424 = heff_field(v_t_243, 0);
    V v_ps_2426 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2427 = (g_prelude_2emap(((V)&g_heff_2eformat_2epatKey_clo), v_ps_2426));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2eformat_2epatKey_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str17); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str18), heff_strAppend(v_t_2430, ((V)&g_heff_2eformat_2epatKey_str19)));
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_parts_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2424, v_t_2432});
    V v_x2_2434 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str20), v_parts_2433));
    V v_t_2437;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2eformat_2epatKey_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_xs_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      v_t_2437 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str22); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str23), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str24), heff_strAppend(v_t_2437, ((V)&g_heff_2eformat_2epatKey_str25))));
  }
  case TAG_PatInt: {
    V v_i_2438 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), NTAG(TAG_Nil)});
    V v_x2_2440 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str26), v_t_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2eformat_2epatKey_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str28); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str29), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str30), heff_strAppend(v_t_2443, ((V)&g_heff_2eformat_2epatKey_str31))));
  }
  case TAG_PatFloat: {
    V v_x_2444 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2444), NTAG(TAG_Nil)});
    V v_x2_2446 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str32), v_t_2445));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2eformat_2epatKey_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str34); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str35), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str36), heff_strAppend(v_t_2449, ((V)&g_heff_2eformat_2epatKey_str37))));
  }
  case TAG_PatString: {
    V v_x_2450 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
    V v_x2_2452 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str38), v_t_2451));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2eformat_2epatKey_str39);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str40); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str41), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str42), heff_strAppend(v_t_2455, ((V)&g_heff_2eformat_2epatKey_str43))));
  }
  case TAG_PatRecord: {
    V v_fs_2456 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_2457 = (g_prelude_2emap_24s242074595x1610727405(((V)&g_heff_2eformat_2epatKey_str44), ((V)&g_heff_2eformat_2epatKey_str45), ((V)&g_heff_2eformat_2epatKey_str46), ((V)&g_heff_2eformat_2epatKey_str47), ((V)&g_heff_2eformat_2epatKey_str48), ((V)&g_heff_2eformat_2epatKey_str49), v_fs_2456));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2eformat_2epatKey_str50);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str51); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str52), heff_strAppend(v_t_2460, ((V)&g_heff_2eformat_2epatKey_str53)));
    V v_parts_2462 = heff_tag(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
    V v_x2_2463 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str54), v_parts_2462));
    V v_t_2466;
    switch (heff_tag_of(v_x2_2463)) {
    case TAG_Nil: {
      v_t_2466 = ((V)&g_heff_2eformat_2epatKey_str55);
      break;
    }
    case TAG_Cons: {
      V v_x_2464 = heff_field(v_x2_2463, 0);
      V v_xs_2465 = heff_field(v_x2_2463, 1);
      heff_take_n(v_x2_2463, 3ULL, 2);
      v_t_2466 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str56); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2463);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str57), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str58), heff_strAppend(v_t_2466, ((V)&g_heff_2eformat_2epatKey_str59))));
  }
  case TAG_PatWord: {
    V v_w_2467 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2469;
    switch (heff_tag_of(v_w_2467)) {
    case TAG_TypeWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str60);
      break;
    }
    case TAG_IntWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str61);
      break;
    }
    case TAG_FloatWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str62);
      break;
    }
    case TAG_StringWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str63);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str64);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str65);
      break;
    }
    case TAG_FixedWord: {
      V v_w_2468 = heff_field(v_w_2467, 0);
      heff_take_n(v_w_2467, 1ULL, 1);
      switch (heff_tag_of(v_w_2468)) {
      case TAG_I8: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str66);
        break;
      }
      case TAG_I16: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str67);
        break;
      }
      case TAG_I32: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str68);
        break;
      }
      case TAG_I64: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str69);
        break;
      }
      case TAG_U8: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str70);
        break;
      }
      case TAG_U16: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str71);
        break;
      }
      case TAG_U32: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str72);
        break;
      }
      case TAG_U64: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str73);
        break;
      }
      case TAG_F32: {
        v_t_2469 = ((V)&g_heff_2eformat_2epatKey_str74);
        break;
      }
      default: heff_nomatch(v_w_2468);
      }
      break;
    }
    default: heff_nomatch(v_w_2467);
    }
    V v_parts_2470 = heff_tag(TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
    V v_x2_2471 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str75), v_parts_2470));
    V v_t_2474;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nil: {
      v_t_2474 = ((V)&g_heff_2eformat_2epatKey_str76);
      break;
    }
    case TAG_Cons: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_xs_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      v_t_2474 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str77); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str78), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str79), heff_strAppend(v_t_2474, ((V)&g_heff_2eformat_2epatKey_str80))));
  }
  case TAG_PatAs: {
    V v_x_2475 = heff_field(v_t_243, 0);
    V v_q_2477 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_t_2478 = (g_heff_2eformat_2epatKey(v_q_2477));
    V v_t_2479 = heff_tag(TAG_Cons, 2, (V[]){v_t_2478, NTAG(TAG_Nil)});
    V v_parts_2480 = heff_tag(TAG_Cons, 2, (V[]){v_x_2475, v_t_2479});
    V v_x2_2481 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2epatKey_str81), v_parts_2480));
    V v_t_2484;
    switch (heff_tag_of(v_x2_2481)) {
    case TAG_Nil: {
      v_t_2484 = ((V)&g_heff_2eformat_2epatKey_str82);
      break;
    }
    case TAG_Cons: {
      V v_x_2482 = heff_field(v_x2_2481, 0);
      V v_xs_2483 = heff_field(v_x2_2481, 1);
      heff_take_n(v_x2_2481, 3ULL, 2);
      v_t_2484 = ({ V a_0 = ((V)&g_heff_2eformat_2epatKey_str83); V a_1 = v_x_2482; V a_2 = v_xs_2483; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2483); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2481);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str84), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str85), heff_strAppend(v_t_2484, ((V)&g_heff_2eformat_2epatKey_str86))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2epatKey(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2eparamKey_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {101, 120, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2eparamKey_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2eparamKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2eformat_2eparamKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2eformat_2eparamKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str3), heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2eformat_2eparamKey_str5))));
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_t_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2416}));
      V v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag(TAG_Cons, 2, (V[]){v_x_2414, v_t_2418});
      V v_x2_2420 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2eparamKey_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2eformat_2eparamKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2eformat_2eparamKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str9), heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2eformat_2eparamKey_str11))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2eparamKey(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str22 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str28 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str34 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str36 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str37 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str38 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str39 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str40 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str41 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str42 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str43 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str44 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str45 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str46 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str47 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str48 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str49 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str50 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str52 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str55 = {{0x80000000u, K_STR, 0}, 4, 4, {119, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str57 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str58 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str62 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str63 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str65 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str68 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str69 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str71 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str73 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str74 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str75 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str77 = {{0x80000000u, K_STR, 0}, 5, 5, {110, 97, 109, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str79 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str80 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str81 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str83 = {{0x80000000u, K_STR, 0}, 5, 5, {110, 97, 109, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str86 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str87 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str89 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str91 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str92 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str93 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str95 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str96 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str97 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str98 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str99 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str100 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str101 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 110, 115, 116, 97, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str103 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str104 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str105 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str106 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str107 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 110, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str108 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str109 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str110 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str111 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str112 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str113 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str114 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str115 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str116 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str117 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str119 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str120 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str121 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str122 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str123 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str124 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str125 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str126 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str127 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str128 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str129 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str130 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str131 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 110, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str132 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str133 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str134 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str135 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str136 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str137 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str138 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str139 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str140 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str141 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str142 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str143 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 110, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str144 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str145 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str146 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str147 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str148 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str149 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 112, 101, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str150 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str151 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str152 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str153 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str154 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str155 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str156 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str157 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str158 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str159 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str160 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str161 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str162 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str163 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str164 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str165 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str166 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str167 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str168 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str169 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str170 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str171 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str172 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str173 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str174 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str175 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str176 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str177 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 105, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str178 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str179 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str180 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str181 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str182 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str183 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str184 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str185 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str186 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str187 = {{0x80000000u, K_STR, 0}, 7, 7, {118, 97, 114, 105, 97, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str188 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str189 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str190 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str191 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str192 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str193 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str194 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str195 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str196 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str197 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str198 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str199 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str200 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str201 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str202 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str203 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str204 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str205 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str206 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str207 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str208 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str209 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str210 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str211 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str212 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str213 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str214 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str215 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str216 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str217 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str218 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str219 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str220 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str221 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str222 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str223 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str224 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str225 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 117, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str226 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str227 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str228 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str229 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str230 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str231 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str232 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str233 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str234 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str235 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str236 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str237 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str238 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str239 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str240 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str241 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str242 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str243 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str244 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str245 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str246 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str247 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str248 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str249 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str250 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str251 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str252 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str253 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str254 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str255 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str256 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str257 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str258 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str259 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str260 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str261 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str262 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str263 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str264 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str265 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 120, 112, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str266 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str267 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str268 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str269 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str270 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str271 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str272 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str273 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str274 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str275 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str276 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str277 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str278 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str279 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str280 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str281 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str282 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str283 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str284 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str285 = {{0x80000000u, K_STR, 0}, 5, 5, {108, 111, 99, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str286 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str287 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str288 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str289 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str290 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str291 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 118, 97, 108, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str292 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eformat_2ekeyTermF_lam0(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam1(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam2(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam3(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam4(V self, V *args);
Clo g_heff_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2eformat_2ekeyTermF(V v_r_240, V v_n_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_it_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
    V v_x2_247 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str0), v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eformat_2ekeyTermF_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str3), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2eformat_2ekeyTermF_str5))));
  }
  case TAG_EImplicitVar: {
    V v_x_2411 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
    V v_x2_2413 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str6), v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eformat_2ekeyTermF_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str10), heff_strAppend(v_t_2416, ((V)&g_heff_2eformat_2ekeyTermF_str11))));
  }
  case TAG_ETag: {
    V v_x_2417 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, NTAG(TAG_Nil)});
    V v_x2_2419 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str12), v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2eformat_2ekeyTermF_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str14); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str15), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str16), heff_strAppend(v_t_2422, ((V)&g_heff_2eformat_2ekeyTermF_str17))));
  }
  case TAG_EInt: {
    V v_i_2423 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_2423), NTAG(TAG_Nil)});
    V v_x2_2425 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str18), v_t_2424));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eformat_2ekeyTermF_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str20); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str21), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str22), heff_strAppend(v_t_2428, ((V)&g_heff_2eformat_2ekeyTermF_str23))));
  }
  case TAG_EFloat: {
    V v_x_2429 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2429), NTAG(TAG_Nil)});
    V v_x2_2431 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str24), v_t_2430));
    V v_t_2434;
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2eformat_2ekeyTermF_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      V v_xs_2433 = heff_field(v_x2_2431, 1);
      heff_take_n(v_x2_2431, 3ULL, 2);
      v_t_2434 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str26); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2431);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str27), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str28), heff_strAppend(v_t_2434, ((V)&g_heff_2eformat_2ekeyTermF_str29))));
  }
  case TAG_EString: {
    V v_x_2435 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){v_x_2435, NTAG(TAG_Nil)});
    V v_x2_2437 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str30), v_t_2436));
    V v_t_2440;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2eformat_2ekeyTermF_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      v_t_2440 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str32); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str33), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str34), heff_strAppend(v_t_2440, ((V)&g_heff_2eformat_2ekeyTermF_str35))));
  }
  case TAG_EWord: {
    V v_w_2441 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2443;
    switch (heff_tag_of(v_w_2441)) {
    case TAG_TypeWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str36);
      break;
    }
    case TAG_IntWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str37);
      break;
    }
    case TAG_FloatWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str38);
      break;
    }
    case TAG_StringWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str39);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str40);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str41);
      break;
    }
    case TAG_FixedWord: {
      V v_w_2442 = heff_field(v_w_2441, 0);
      heff_take_n(v_w_2441, 1ULL, 1);
      switch (heff_tag_of(v_w_2442)) {
      case TAG_I8: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str42);
        break;
      }
      case TAG_I16: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str43);
        break;
      }
      case TAG_I32: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str44);
        break;
      }
      case TAG_I64: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str45);
        break;
      }
      case TAG_U8: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str46);
        break;
      }
      case TAG_U16: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str47);
        break;
      }
      case TAG_U32: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str48);
        break;
      }
      case TAG_U64: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str49);
        break;
      }
      case TAG_F32: {
        v_t_2443 = ((V)&g_heff_2eformat_2ekeyTermF_str50);
        break;
      }
      default: heff_nomatch(v_w_2442);
      }
      break;
    }
    default: heff_nomatch(v_w_2441);
    }
    V v_parts_2444 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
    V v_x2_2445 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str51), v_parts_2444));
    V v_t_2448;
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2eformat_2ekeyTermF_str52);
      break;
    }
    case TAG_Cons: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_xs_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      v_t_2448 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str53); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2445);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str54), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str55), heff_strAppend(v_t_2448, ((V)&g_heff_2eformat_2ekeyTermF_str56))));
  }
  case TAG_EApp: {
    V v_h_2449 = heff_field(v_it_244, 0);
    V v_args_2450 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EApp = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_2449}));
    V v_x2_2452 = (g_prelude_2emap(heff_get(v_r_240, LBL_e), v_args_2450));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2eformat_2ekeyTermF_str57);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str58); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    V v_t_2456 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str59), heff_strAppend(v_t_2455, ((V)&g_heff_2eformat_2ekeyTermF_str60)));
    V v_t_2457 = heff_tag_at(v_ru_24it_244_24EApp, TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
    V v_parts_2458 = heff_tag(TAG_Cons, 2, (V[]){v_t_2451, v_t_2457});
    V v_x2_2459 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str61), v_parts_2458));
    V v_t_2462;
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_Nil: {
      v_t_2462 = ((V)&g_heff_2eformat_2ekeyTermF_str62);
      break;
    }
    case TAG_Cons: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_xs_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      v_t_2462 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str63); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2459);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str64), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str65), heff_strAppend(v_t_2462, ((V)&g_heff_2eformat_2ekeyTermF_str66))));
  }
  case TAG_EProject: {
    V v_x_2463 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2464 = heff_tag(TAG_Cons, 2, (V[]){v_x_2463, NTAG(TAG_Nil)});
    V v_x2_2465 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str67), v_t_2464));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2eformat_2ekeyTermF_str68);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str69); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str70), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str71), heff_strAppend(v_t_2468, ((V)&g_heff_2eformat_2ekeyTermF_str72))));
  }
  case TAG_ENamed: {
    V v_x_2469 = heff_field(v_it_244, 0);
    V v_e_2470 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ENamed = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2470}));
    V v_t_2472 = heff_tag_at(v_ru_24it_244_24ENamed, TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
    V v_parts_2473 = heff_tag(TAG_Cons, 2, (V[]){v_x_2469, v_t_2472});
    V v_x2_2474 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str73), v_parts_2473));
    V v_t_2477;
    switch (heff_tag_of(v_x2_2474)) {
    case TAG_Nil: {
      v_t_2477 = ((V)&g_heff_2eformat_2ekeyTermF_str74);
      break;
    }
    case TAG_Cons: {
      V v_x_2475 = heff_field(v_x2_2474, 0);
      V v_xs_2476 = heff_field(v_x2_2474, 1);
      heff_take_n(v_x2_2474, 3ULL, 2);
      v_t_2477 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str75); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2474);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str76), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str77), heff_strAppend(v_t_2477, ((V)&g_heff_2eformat_2ekeyTermF_str78))));
  }
  case TAG_EPi: {
    V v_b_2478 = heff_field(v_it_244, 0);
    V v_cod_2479 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EPi = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24129;
    switch (heff_tag_of(v_b_2478)) {
    case TAG_PiNamed: {
      V v_x_2480 = heff_field(v_b_2478, 0);
      V v_t_2482 = heff_field(v_b_2478, 2);
      heff_take_n(v_b_2478, 5ULL, 3);
      V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2482}));
      V v_t_2484 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
      V v_parts_2485 = heff_tag(TAG_Cons, 2, (V[]){v_x_2480, v_t_2484});
      V v_x2_2486 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str79), v_parts_2485));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2eformat_2ekeyTermF_str80);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str81); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      v_t_24129 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str82), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str83), heff_strAppend(v_t_2489, ((V)&g_heff_2eformat_2ekeyTermF_str84))));
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2490 = heff_field(v_b_2478, 0);
      V v_t_2493 = heff_field(v_b_2478, 3);
      V v_it5_2494 = heff_field(v_b_2478, 4);
      heff_take_n(v_b_2478, 25ULL, 5);
      switch (heff_tag_of(v_it5_2494)) {
      case TAG_Nothing: {
        V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2493}));
        V v_t_2496 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
        V v_parts_2497 = heff_tag(TAG_Cons, 2, (V[]){v_x_2490, v_t_2496});
        V v_x2_2498 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str85), v_parts_2497));
        V v_t_24101;
        switch (heff_tag_of(v_x2_2498)) {
        case TAG_Nil: {
          v_t_24101 = ((V)&g_heff_2eformat_2ekeyTermF_str86);
          break;
        }
        case TAG_Cons: {
          V v_x_2499 = heff_field(v_x2_2498, 0);
          V v_xs_24100 = heff_field(v_x2_2498, 1);
          heff_take_n(v_x2_2498, 3ULL, 2);
          v_t_24101 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str87); V a_1 = v_x_2499; V a_2 = v_xs_24100; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24100); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2498);
        }
        v_t_24129 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str88), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str89), heff_strAppend(v_t_24101, ((V)&g_heff_2eformat_2ekeyTermF_str90))));
        break;
      }
      case TAG_Just: {
        V v_d_24102 = heff_field(v_it5_2494, 0);
        heff_take_n(v_it5_2494, 1ULL, 1);
        V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2493}));
        V v_t_24104 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_d_24102}));
        V v_t_24105 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
        V v_parts_24106 = heff_tag(TAG_Cons, 2, (V[]){v_x_2490, heff_tag(TAG_Cons, 2, (V[]){v_t_24103, v_t_24105})});
        V v_x2_24107 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str91), v_parts_24106));
        V v_t_24110;
        switch (heff_tag_of(v_x2_24107)) {
        case TAG_Nil: {
          v_t_24110 = ((V)&g_heff_2eformat_2ekeyTermF_str92);
          break;
        }
        case TAG_Cons: {
          V v_x_24108 = heff_field(v_x2_24107, 0);
          V v_xs_24109 = heff_field(v_x2_24107, 1);
          heff_take_n(v_x2_24107, 3ULL, 2);
          v_t_24110 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str93); V a_1 = v_x_24108; V a_2 = v_xs_24109; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24109); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24107);
        }
        v_t_24129 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str94), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str95), heff_strAppend(v_t_24110, ((V)&g_heff_2eformat_2ekeyTermF_str96))));
        break;
      }
      default: heff_nomatch(v_it5_2494);
      }
      break;
    }
    case TAG_PiInstance: {
      V v_x_24111 = heff_field(v_b_2478, 0);
      V v_t_24114 = heff_field(v_b_2478, 3);
      heff_take_n(v_b_2478, 9ULL, 4);
      V v_t_24115 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24114}));
      V v_t_24116 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
      V v_parts_24117 = heff_tag(TAG_Cons, 2, (V[]){v_x_24111, v_t_24116});
      V v_x2_24118 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str97), v_parts_24117));
      V v_t_24121;
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_Nil: {
        v_t_24121 = ((V)&g_heff_2eformat_2ekeyTermF_str98);
        break;
      }
      case TAG_Cons: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        V v_xs_24120 = heff_field(v_x2_24118, 1);
        heff_take_n(v_x2_24118, 3ULL, 2);
        v_t_24121 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str99); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24118);
      }
      v_t_24129 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str100), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str101), heff_strAppend(v_t_24121, ((V)&g_heff_2eformat_2ekeyTermF_str102))));
      break;
    }
    case TAG_PiAnon: {
      V v_t_24122 = heff_field(v_b_2478, 0);
      heff_take_n(v_b_2478, 1ULL, 1);
      V v_t_24123 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24122}));
      V v_parts_24124 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
      V v_x2_24125 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str103), v_parts_24124));
      V v_t_24128;
      switch (heff_tag_of(v_x2_24125)) {
      case TAG_Nil: {
        v_t_24128 = ((V)&g_heff_2eformat_2ekeyTermF_str104);
        break;
      }
      case TAG_Cons: {
        V v_x_24126 = heff_field(v_x2_24125, 0);
        V v_xs_24127 = heff_field(v_x2_24125, 1);
        heff_take_n(v_x2_24125, 3ULL, 2);
        v_t_24128 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str105); V a_1 = v_x_24126; V a_2 = v_xs_24127; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24127); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24125);
      }
      v_t_24129 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str106), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str107), heff_strAppend(v_t_24128, ((V)&g_heff_2eformat_2ekeyTermF_str108))));
      break;
    }
    default: heff_nomatch(v_b_2478);
    }
    V v_t_24130 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_cod_2479}));
    V v_t_24131 = heff_tag(TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
    V v_parts_24132 = heff_tag(TAG_Cons, 2, (V[]){v_t_24129, v_t_24131});
    V v_x2_24133 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str109), v_parts_24132));
    V v_t_24136;
    switch (heff_tag_of(v_x2_24133)) {
    case TAG_Nil: {
      v_t_24136 = ((V)&g_heff_2eformat_2ekeyTermF_str110);
      break;
    }
    case TAG_Cons: {
      V v_x_24134 = heff_field(v_x2_24133, 0);
      V v_xs_24135 = heff_field(v_x2_24133, 1);
      heff_take_n(v_x2_24133, 3ULL, 2);
      v_t_24136 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str111); V a_1 = v_x_24134; V a_2 = v_xs_24135; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24135); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24133);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str112), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str113), heff_strAppend(v_t_24136, ((V)&g_heff_2eformat_2ekeyTermF_str114))));
  }
  case TAG_ELam: {
    V v_b_24137 = heff_field(v_it_244, 0);
    V v_body_24138 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELam = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24163;
    switch (heff_tag_of(v_b_24137)) {
    case TAG_LamName: {
      V v_x_24139 = heff_field(v_b_24137, 0);
      heff_take_n(v_b_24137, 1ULL, 2);
      V v_t_24141 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24139, NTAG(TAG_Nil)});
      V v_x2_24142 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str115), v_t_24141));
      V v_t_24145;
      switch (heff_tag_of(v_x2_24142)) {
      case TAG_Nil: {
        v_t_24145 = ((V)&g_heff_2eformat_2ekeyTermF_str116);
        break;
      }
      case TAG_Cons: {
        V v_x_24143 = heff_field(v_x2_24142, 0);
        V v_xs_24144 = heff_field(v_x2_24142, 1);
        heff_take_n(v_x2_24142, 3ULL, 2);
        v_t_24145 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str117); V a_1 = v_x_24143; V a_2 = v_xs_24144; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24144); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24142);
      }
      v_t_24163 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str118), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str119), heff_strAppend(v_t_24145, ((V)&g_heff_2eformat_2ekeyTermF_str120))));
      break;
    }
    case TAG_LamImplicit: {
      V v_x_24146 = heff_field(v_b_24137, 0);
      heff_take_n(v_b_24137, 1ULL, 2);
      V v_t_24148 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24146, NTAG(TAG_Nil)});
      V v_x2_24149 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str121), v_t_24148));
      V v_t_24152;
      switch (heff_tag_of(v_x2_24149)) {
      case TAG_Nil: {
        v_t_24152 = ((V)&g_heff_2eformat_2ekeyTermF_str122);
        break;
      }
      case TAG_Cons: {
        V v_x_24150 = heff_field(v_x2_24149, 0);
        V v_xs_24151 = heff_field(v_x2_24149, 1);
        heff_take_n(v_x2_24149, 3ULL, 2);
        v_t_24152 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str123); V a_1 = v_x_24150; V a_2 = v_xs_24151; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24151); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24149);
      }
      v_t_24163 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str124), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str125), heff_strAppend(v_t_24152, ((V)&g_heff_2eformat_2ekeyTermF_str126))));
      break;
    }
    case TAG_LamAnn: {
      V v_x_24153 = heff_field(v_b_24137, 0);
      V v_t_24155 = heff_field(v_b_24137, 2);
      heff_take_n(v_b_24137, 5ULL, 3);
      V v_t_24156 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24155}));
      V v_t_24157 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
      V v_parts_24158 = heff_tag(TAG_Cons, 2, (V[]){v_x_24153, v_t_24157});
      V v_x2_24159 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str127), v_parts_24158));
      V v_t_24162;
      switch (heff_tag_of(v_x2_24159)) {
      case TAG_Nil: {
        v_t_24162 = ((V)&g_heff_2eformat_2ekeyTermF_str128);
        break;
      }
      case TAG_Cons: {
        V v_x_24160 = heff_field(v_x2_24159, 0);
        V v_xs_24161 = heff_field(v_x2_24159, 1);
        heff_take_n(v_x2_24159, 3ULL, 2);
        v_t_24162 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str129); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24159);
      }
      v_t_24163 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str130), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str131), heff_strAppend(v_t_24162, ((V)&g_heff_2eformat_2ekeyTermF_str132))));
      break;
    }
    default: heff_nomatch(v_b_24137);
    }
    V v_t_24164 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_24138}));
    V v_t_24165 = heff_tag(TAG_Cons, 2, (V[]){v_t_24164, NTAG(TAG_Nil)});
    V v_parts_24166 = heff_tag(TAG_Cons, 2, (V[]){v_t_24163, v_t_24165});
    V v_x2_24167 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str133), v_parts_24166));
    V v_t_24170;
    switch (heff_tag_of(v_x2_24167)) {
    case TAG_Nil: {
      v_t_24170 = ((V)&g_heff_2eformat_2ekeyTermF_str134);
      break;
    }
    case TAG_Cons: {
      V v_x_24168 = heff_field(v_x2_24167, 0);
      V v_xs_24169 = heff_field(v_x2_24167, 1);
      heff_take_n(v_x2_24167, 3ULL, 2);
      v_t_24170 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str135); V a_1 = v_x_24168; V a_2 = v_xs_24169; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24169); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24167);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str136), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str137), heff_strAppend(v_t_24170, ((V)&g_heff_2eformat_2ekeyTermF_str138))));
  }
  case TAG_EAnn: {
    V v_e_24171 = heff_field(v_it_244, 0);
    V v_t_24172 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EAnn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24173 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_e_24171}));
    V v_t_24174 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_24172}));
    V v_t_24175 = heff_tag_at(v_ru_24it_244_24EAnn, TAG_Cons, 2, (V[]){v_t_24174, NTAG(TAG_Nil)});
    V v_parts_24176 = heff_tag(TAG_Cons, 2, (V[]){v_t_24173, v_t_24175});
    V v_x2_24177 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str139), v_parts_24176));
    V v_t_24180;
    switch (heff_tag_of(v_x2_24177)) {
    case TAG_Nil: {
      v_t_24180 = ((V)&g_heff_2eformat_2ekeyTermF_str140);
      break;
    }
    case TAG_Cons: {
      V v_x_24178 = heff_field(v_x2_24177, 0);
      V v_xs_24179 = heff_field(v_x2_24177, 1);
      heff_take_n(v_x2_24177, 3ULL, 2);
      v_t_24180 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str141); V a_1 = v_x_24178; V a_2 = v_xs_24179; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24179); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24177);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str142), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str143), heff_strAppend(v_t_24180, ((V)&g_heff_2eformat_2ekeyTermF_str144))));
  }
  case TAG_ESpec: {
    V v_acc_24181 = heff_field(v_it_244, 0);
    V v_x_24182 = heff_field(v_it_244, 1);
    V v_v_24184 = heff_field(v_it_244, 3);
    heff_take_n(v_it_244, 11ULL, 4);
    V v_t_24185 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_acc_24181}));
    V v_t_24186 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_v_24184}));
    V v_t_24187 = heff_tag(TAG_Cons, 2, (V[]){v_t_24186, NTAG(TAG_Nil)});
    V v_parts_24188 = heff_tag(TAG_Cons, 2, (V[]){v_t_24185, heff_tag(TAG_Cons, 2, (V[]){v_x_24182, v_t_24187})});
    V v_x2_24189 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str145), v_parts_24188));
    V v_t_24192;
    switch (heff_tag_of(v_x2_24189)) {
    case TAG_Nil: {
      v_t_24192 = ((V)&g_heff_2eformat_2ekeyTermF_str146);
      break;
    }
    case TAG_Cons: {
      V v_x_24190 = heff_field(v_x2_24189, 0);
      V v_xs_24191 = heff_field(v_x2_24189, 1);
      heff_take_n(v_x2_24189, 3ULL, 2);
      v_t_24192 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str147); V a_1 = v_x_24190; V a_2 = v_xs_24191; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24191); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24189);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str148), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str149), heff_strAppend(v_t_24192, ((V)&g_heff_2eformat_2ekeyTermF_str150))));
  }
  case TAG_ESig: {
    V v_fs_24193 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24224 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_fs_24193));
    V v_t_24227;
    switch (heff_tag_of(v_x2_24224)) {
    case TAG_Nil: {
      v_t_24227 = ((V)&g_heff_2eformat_2ekeyTermF_str169);
      break;
    }
    case TAG_Cons: {
      V v_x_24225 = heff_field(v_x2_24224, 0);
      V v_xs_24226 = heff_field(v_x2_24224, 1);
      heff_take_n(v_x2_24224, 3ULL, 2);
      v_t_24227 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str170); V a_1 = v_x_24225; V a_2 = v_xs_24226; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24226); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24224);
    }
    V v_t_24228 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str171), heff_strAppend(v_t_24227, ((V)&g_heff_2eformat_2ekeyTermF_str172)));
    V v_parts_24229 = heff_tag(TAG_Cons, 2, (V[]){v_t_24228, NTAG(TAG_Nil)});
    V v_x2_24230 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str173), v_parts_24229));
    V v_t_24233;
    switch (heff_tag_of(v_x2_24230)) {
    case TAG_Nil: {
      v_t_24233 = ((V)&g_heff_2eformat_2ekeyTermF_str174);
      break;
    }
    case TAG_Cons: {
      V v_x_24231 = heff_field(v_x2_24230, 0);
      V v_xs_24232 = heff_field(v_x2_24230, 1);
      heff_take_n(v_x2_24230, 3ULL, 2);
      v_t_24233 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str175); V a_1 = v_x_24231; V a_2 = v_xs_24232; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24232); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24230);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str176), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str177), heff_strAppend(v_t_24233, ((V)&g_heff_2eformat_2ekeyTermF_str178))));
  }
  case TAG_ESum: {
    V v_vs_24234 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24259 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam1, 1, 1, (V[]){v_r_240}), v_vs_24234));
    V v_t_24262;
    switch (heff_tag_of(v_x2_24259)) {
    case TAG_Nil: {
      v_t_24262 = ((V)&g_heff_2eformat_2ekeyTermF_str195);
      break;
    }
    case TAG_Cons: {
      V v_x_24260 = heff_field(v_x2_24259, 0);
      V v_xs_24261 = heff_field(v_x2_24259, 1);
      heff_take_n(v_x2_24259, 3ULL, 2);
      v_t_24262 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str196); V a_1 = v_x_24260; V a_2 = v_xs_24261; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24261); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24259);
    }
    V v_t_24263 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str197), heff_strAppend(v_t_24262, ((V)&g_heff_2eformat_2ekeyTermF_str198)));
    V v_parts_24264 = heff_tag(TAG_Cons, 2, (V[]){v_t_24263, NTAG(TAG_Nil)});
    V v_x2_24265 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str199), v_parts_24264));
    V v_t_24268;
    switch (heff_tag_of(v_x2_24265)) {
    case TAG_Nil: {
      v_t_24268 = ((V)&g_heff_2eformat_2ekeyTermF_str200);
      break;
    }
    case TAG_Cons: {
      V v_x_24266 = heff_field(v_x2_24265, 0);
      V v_xs_24267 = heff_field(v_x2_24265, 1);
      heff_take_n(v_x2_24265, 3ULL, 2);
      v_t_24268 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str201); V a_1 = v_x_24266; V a_2 = v_xs_24267; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24267); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24265);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str202), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str203), heff_strAppend(v_t_24268, ((V)&g_heff_2eformat_2ekeyTermF_str204))));
  }
  case TAG_EStruct: {
    V v_fs_24269 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24290 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam2, 1, 1, (V[]){v_r_240}), v_fs_24269));
    V v_t_24293;
    switch (heff_tag_of(v_x2_24290)) {
    case TAG_Nil: {
      v_t_24293 = ((V)&g_heff_2eformat_2ekeyTermF_str217);
      break;
    }
    case TAG_Cons: {
      V v_x_24291 = heff_field(v_x2_24290, 0);
      V v_xs_24292 = heff_field(v_x2_24290, 1);
      heff_take_n(v_x2_24290, 3ULL, 2);
      v_t_24293 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str218); V a_1 = v_x_24291; V a_2 = v_xs_24292; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24292); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24290);
    }
    V v_t_24294 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str219), heff_strAppend(v_t_24293, ((V)&g_heff_2eformat_2ekeyTermF_str220)));
    V v_parts_24295 = heff_tag(TAG_Cons, 2, (V[]){v_t_24294, NTAG(TAG_Nil)});
    V v_x2_24296 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str221), v_parts_24295));
    V v_t_24299;
    switch (heff_tag_of(v_x2_24296)) {
    case TAG_Nil: {
      v_t_24299 = ((V)&g_heff_2eformat_2ekeyTermF_str222);
      break;
    }
    case TAG_Cons: {
      V v_x_24297 = heff_field(v_x2_24296, 0);
      V v_xs_24298 = heff_field(v_x2_24296, 1);
      heff_take_n(v_x2_24296, 3ULL, 2);
      v_t_24299 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str223); V a_1 = v_x_24297; V a_2 = v_xs_24298; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24298); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24296);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str224), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str225), heff_strAppend(v_t_24299, ((V)&g_heff_2eformat_2ekeyTermF_str226))));
  }
  case TAG_EMatch: {
    V v_s_24300 = heff_field(v_it_244, 0);
    V v_alts_24301 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EMatch = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24302 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_s_24300}));
    V v_x2_24316 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam3, 1, 1, (V[]){v_r_240}), v_alts_24301));
    V v_t_24319;
    switch (heff_tag_of(v_x2_24316)) {
    case TAG_Nil: {
      v_t_24319 = ((V)&g_heff_2eformat_2ekeyTermF_str233);
      break;
    }
    case TAG_Cons: {
      V v_x_24317 = heff_field(v_x2_24316, 0);
      V v_xs_24318 = heff_field(v_x2_24316, 1);
      heff_take_n(v_x2_24316, 3ULL, 2);
      v_t_24319 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str234); V a_1 = v_x_24317; V a_2 = v_xs_24318; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24318); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24316);
    }
    V v_t_24320 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str235), heff_strAppend(v_t_24319, ((V)&g_heff_2eformat_2ekeyTermF_str236)));
    V v_t_24321 = heff_tag_at(v_ru_24it_244_24EMatch, TAG_Cons, 2, (V[]){v_t_24320, NTAG(TAG_Nil)});
    V v_parts_24322 = heff_tag(TAG_Cons, 2, (V[]){v_t_24302, v_t_24321});
    V v_x2_24323 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str237), v_parts_24322));
    V v_t_24326;
    switch (heff_tag_of(v_x2_24323)) {
    case TAG_Nil: {
      v_t_24326 = ((V)&g_heff_2eformat_2ekeyTermF_str238);
      break;
    }
    case TAG_Cons: {
      V v_x_24324 = heff_field(v_x2_24323, 0);
      V v_xs_24325 = heff_field(v_x2_24323, 1);
      heff_take_n(v_x2_24323, 3ULL, 2);
      v_t_24326 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str239); V a_1 = v_x_24324; V a_2 = v_xs_24325; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24325); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24323);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str240), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str241), heff_strAppend(v_t_24326, ((V)&g_heff_2eformat_2ekeyTermF_str242))));
  }
  case TAG_ELetIn: {
    V v_rhs_24327 = heff_field(v_it_244, 0);
    V v_it2_24328 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELetIn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    switch (heff_tag_of(v_it2_24328)) {
    case TAG_At: {
      V v_it21_24329 = heff_field(v_it2_24328, 0);
      V v_ru_24it2_24328_24At = heff_take_reuse_n(v_it2_24328, 1ULL, 2);
      switch (heff_tag_of(v_it21_24329)) {
      case TAG_MkAlt: {
        V v_p_24331 = heff_field(v_it21_24329, 0);
        V v_e_24332 = heff_field(v_it21_24329, 1);
        heff_take_n(v_it21_24329, 3ULL, 2);
        V v_t_24333 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_rhs_24327}));
        V v_t_24334 = (g_heff_2eformat_2epatKey(v_p_24331));
        V v_t_24335 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24332}));
        V v_t_24336 = heff_tag_at(v_ru_24it_244_24ELetIn, TAG_Cons, 2, (V[]){v_t_24335, NTAG(TAG_Nil)});
        V v_parts_24337 = heff_tag_at(v_ru_24it2_24328_24At, TAG_Cons, 2, (V[]){v_t_24333, heff_tag(TAG_Cons, 2, (V[]){v_t_24334, v_t_24336})});
        V v_x2_24338 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str243), v_parts_24337));
        V v_t_24341;
        switch (heff_tag_of(v_x2_24338)) {
        case TAG_Nil: {
          v_t_24341 = ((V)&g_heff_2eformat_2ekeyTermF_str244);
          break;
        }
        case TAG_Cons: {
          V v_x_24339 = heff_field(v_x2_24338, 0);
          V v_xs_24340 = heff_field(v_x2_24338, 1);
          heff_take_n(v_x2_24338, 3ULL, 2);
          v_t_24341 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str245); V a_1 = v_x_24339; V a_2 = v_xs_24340; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24340); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24338);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str246), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str247), heff_strAppend(v_t_24341, ((V)&g_heff_2eformat_2ekeyTermF_str248))));
      }
      default: return heff_nomatch(v_it21_24329);
      }
    }
    default: return heff_nomatch(v_it2_24328);
    }
  }
  case TAG_EDo: {
    V v_stmts_24342 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24373 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam4, 1, 1, (V[]){v_r_240}), v_stmts_24342));
    V v_t_24376;
    switch (heff_tag_of(v_x2_24373)) {
    case TAG_Nil: {
      v_t_24376 = ((V)&g_heff_2eformat_2ekeyTermF_str267);
      break;
    }
    case TAG_Cons: {
      V v_x_24374 = heff_field(v_x2_24373, 0);
      V v_xs_24375 = heff_field(v_x2_24373, 1);
      heff_take_n(v_x2_24373, 3ULL, 2);
      v_t_24376 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str268); V a_1 = v_x_24374; V a_2 = v_xs_24375; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24375); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24373);
    }
    V v_t_24377 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str269), heff_strAppend(v_t_24376, ((V)&g_heff_2eformat_2ekeyTermF_str270)));
    V v_parts_24378 = heff_tag(TAG_Cons, 2, (V[]){v_t_24377, NTAG(TAG_Nil)});
    V v_x2_24379 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str271), v_parts_24378));
    V v_t_24382;
    switch (heff_tag_of(v_x2_24379)) {
    case TAG_Nil: {
      v_t_24382 = ((V)&g_heff_2eformat_2ekeyTermF_str272);
      break;
    }
    case TAG_Cons: {
      V v_x_24380 = heff_field(v_x2_24379, 0);
      V v_xs_24381 = heff_field(v_x2_24379, 1);
      heff_take_n(v_x2_24379, 3ULL, 2);
      v_t_24382 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str273); V a_1 = v_x_24380; V a_2 = v_xs_24381; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24381); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24379);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str274), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str275), heff_strAppend(v_t_24382, ((V)&g_heff_2eformat_2ekeyTermF_str276))));
  }
  case TAG_ELocal: {
    V v_body_24383 = heff_field(v_it_244, 0);
    V v_ds_24384 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELocal = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24385 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_body_24383}));
    V v_x2_24386 = (g_prelude_2emap(heff_get(v_r_240, LBL_decl), v_ds_24384));
    V v_t_24389;
    switch (heff_tag_of(v_x2_24386)) {
    case TAG_Nil: {
      v_t_24389 = ((V)&g_heff_2eformat_2ekeyTermF_str277);
      break;
    }
    case TAG_Cons: {
      V v_x_24387 = heff_field(v_x2_24386, 0);
      V v_xs_24388 = heff_field(v_x2_24386, 1);
      heff_take_n(v_x2_24386, 3ULL, 2);
      v_t_24389 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str278); V a_1 = v_x_24387; V a_2 = v_xs_24388; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24388); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24386);
    }
    V v_t_24390 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str279), heff_strAppend(v_t_24389, ((V)&g_heff_2eformat_2ekeyTermF_str280)));
    V v_t_24391 = heff_tag_at(v_ru_24it_244_24ELocal, TAG_Cons, 2, (V[]){v_t_24390, NTAG(TAG_Nil)});
    V v_parts_24392 = heff_tag(TAG_Cons, 2, (V[]){v_t_24385, v_t_24391});
    V v_x2_24393 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str281), v_parts_24392));
    V v_t_24396;
    switch (heff_tag_of(v_x2_24393)) {
    case TAG_Nil: {
      v_t_24396 = ((V)&g_heff_2eformat_2ekeyTermF_str282);
      break;
    }
    case TAG_Cons: {
      V v_x_24394 = heff_field(v_x2_24393, 0);
      V v_xs_24395 = heff_field(v_x2_24393, 1);
      heff_take_n(v_x2_24393, 3ULL, 2);
      v_t_24396 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str283); V a_1 = v_x_24394; V a_2 = v_xs_24395; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24395); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24393);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str284), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str285), heff_strAppend(v_t_24396, ((V)&g_heff_2eformat_2ekeyTermF_str286))));
  }
  case TAG_EInvalid: {
    V v_why_24397 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_24398 = heff_tag(TAG_Cons, 2, (V[]){v_why_24397, NTAG(TAG_Nil)});
    V v_x2_24399 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str287), v_t_24398));
    V v_t_24402;
    switch (heff_tag_of(v_x2_24399)) {
    case TAG_Nil: {
      v_t_24402 = ((V)&g_heff_2eformat_2ekeyTermF_str288);
      break;
    }
    case TAG_Cons: {
      V v_x_24400 = heff_field(v_x2_24399, 0);
      V v_xs_24401 = heff_field(v_x2_24399, 1);
      heff_take_n(v_x2_24399, 3ULL, 2);
      v_t_24402 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str289); V a_1 = v_x_24400; V a_2 = v_xs_24401; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24401); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24399);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str290), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str291), heff_strAppend(v_t_24402, ((V)&g_heff_2eformat_2ekeyTermF_str292))));
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2ekeyTermF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_f_24194 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24194)) {
  case TAG_At: {
    V v_it1_24195 = heff_field(v_f_24194, 0);
    V v_ru_24f_24194_24At = heff_take_reuse_n(v_f_24194, 1ULL, 2);
    switch (heff_tag_of(v_it1_24195)) {
    case TAG_DeclareField: {
      V v_x_24197 = heff_field(v_it1_24195, 0);
      V v_t_24199 = heff_field(v_it1_24195, 2);
      V v_it14_24200 = heff_field(v_it1_24195, 3);
      heff_take_n(v_it1_24195, 13ULL, 4);
      switch (heff_tag_of(v_it14_24200)) {
      case TAG_Nothing: {
        V v_t_24201 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_24199}));
        V v_t_24202 = heff_tag_at(v_ru_24f_24194_24At, TAG_Cons, 2, (V[]){v_t_24201, NTAG(TAG_Nil)});
        V v_parts_24203 = heff_tag(TAG_Cons, 2, (V[]){v_x_24197, v_t_24202});
        V v_x2_24204 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str151), v_parts_24203));
        V v_t_24207;
        switch (heff_tag_of(v_x2_24204)) {
        case TAG_Nil: {
          v_t_24207 = ((V)&g_heff_2eformat_2ekeyTermF_str152);
          break;
        }
        case TAG_Cons: {
          V v_x_24205 = heff_field(v_x2_24204, 0);
          V v_xs_24206 = heff_field(v_x2_24204, 1);
          heff_take_n(v_x2_24204, 3ULL, 2);
          v_t_24207 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str153); V a_1 = v_x_24205; V a_2 = v_xs_24206; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24206); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24204);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str154), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str155), heff_strAppend(v_t_24207, ((V)&g_heff_2eformat_2ekeyTermF_str156))));
      }
      case TAG_Just: {
        V v_d_24208 = heff_field(v_it14_24200, 0);
        heff_take_n(v_it14_24200, 1ULL, 1);
        V v_t_24209 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24199}));
        V v_t_24210 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_d_24208}));
        V v_t_24211 = heff_tag_at(v_ru_24f_24194_24At, TAG_Cons, 2, (V[]){v_t_24210, NTAG(TAG_Nil)});
        V v_parts_24212 = heff_tag(TAG_Cons, 2, (V[]){v_x_24197, heff_tag(TAG_Cons, 2, (V[]){v_t_24209, v_t_24211})});
        V v_x2_24213 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str157), v_parts_24212));
        V v_t_24216;
        switch (heff_tag_of(v_x2_24213)) {
        case TAG_Nil: {
          v_t_24216 = ((V)&g_heff_2eformat_2ekeyTermF_str158);
          break;
        }
        case TAG_Cons: {
          V v_x_24214 = heff_field(v_x2_24213, 0);
          V v_xs_24215 = heff_field(v_x2_24213, 1);
          heff_take_n(v_x2_24213, 3ULL, 2);
          v_t_24216 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str159); V a_1 = v_x_24214; V a_2 = v_xs_24215; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24215); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24213);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str160), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str161), heff_strAppend(v_t_24216, ((V)&g_heff_2eformat_2ekeyTermF_str162))));
      }
      default: return heff_nomatch(v_it14_24200);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_24217 = heff_field(v_it1_24195, 0);
      heff_take_n(v_it1_24195, 1ULL, 1);
      V v_t_24218 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24217}));
      V v_parts_24219 = heff_tag_at(v_ru_24f_24194_24At, TAG_Cons, 2, (V[]){v_t_24218, NTAG(TAG_Nil)});
      V v_x2_24220 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str163), v_parts_24219));
      V v_t_24223;
      switch (heff_tag_of(v_x2_24220)) {
      case TAG_Nil: {
        v_t_24223 = ((V)&g_heff_2eformat_2ekeyTermF_str164);
        break;
      }
      case TAG_Cons: {
        V v_x_24221 = heff_field(v_x2_24220, 0);
        V v_xs_24222 = heff_field(v_x2_24220, 1);
        heff_take_n(v_x2_24220, 3ULL, 2);
        v_t_24223 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str165); V a_1 = v_x_24221; V a_2 = v_xs_24222; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24222); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24220);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str166), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str167), heff_strAppend(v_t_24223, ((V)&g_heff_2eformat_2ekeyTermF_str168))));
    }
    default: return heff_nomatch(v_it1_24195);
    }
  }
  default: return heff_nomatch(v_f_24194);
  }
}
V g_heff_2eformat_2ekeyTermF_lam1(V self, V *args) {
  V v_v_24235 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24235)) {
  case TAG_At: {
    V v_it1_24236 = heff_field(v_v_24235, 0);
    V v_ru_24v_24235_24At = heff_take_reuse_n(v_v_24235, 1ULL, 2);
    switch (heff_tag_of(v_it1_24236)) {
    case TAG_TagVariant: {
      V v_t_24238 = heff_field(v_it1_24236, 0);
      V v_args_24240 = heff_field(v_it1_24236, 2);
      heff_take_n(v_it1_24236, 5ULL, 3);
      V v_x2_24241 = (g_prelude_2emap(heff_get(v_r_240, LBL_e), v_args_24240));
      V v_t_24244;
      switch (heff_tag_of(v_x2_24241)) {
      case TAG_Nil: {
        v_t_24244 = ((V)&g_heff_2eformat_2ekeyTermF_str179);
        break;
      }
      case TAG_Cons: {
        V v_x_24242 = heff_field(v_x2_24241, 0);
        V v_xs_24243 = heff_field(v_x2_24241, 1);
        heff_take_n(v_x2_24241, 3ULL, 2);
        v_t_24244 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str180); V a_1 = v_x_24242; V a_2 = v_xs_24243; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24243); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24241);
      }
      V v_t_24245 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str181), heff_strAppend(v_t_24244, ((V)&g_heff_2eformat_2ekeyTermF_str182)));
      V v_t_24246 = heff_tag_at(v_ru_24v_24235_24At, TAG_Cons, 2, (V[]){v_t_24245, NTAG(TAG_Nil)});
      V v_parts_24247 = heff_tag(TAG_Cons, 2, (V[]){v_t_24238, v_t_24246});
      V v_x2_24248 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str183), v_parts_24247));
      V v_t_24251;
      switch (heff_tag_of(v_x2_24248)) {
      case TAG_Nil: {
        v_t_24251 = ((V)&g_heff_2eformat_2ekeyTermF_str184);
        break;
      }
      case TAG_Cons: {
        V v_x_24249 = heff_field(v_x2_24248, 0);
        V v_xs_24250 = heff_field(v_x2_24248, 1);
        heff_take_n(v_x2_24248, 3ULL, 2);
        v_t_24251 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str185); V a_1 = v_x_24249; V a_2 = v_xs_24250; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24250); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24248);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str186), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str187), heff_strAppend(v_t_24251, ((V)&g_heff_2eformat_2ekeyTermF_str188))));
    }
    case TAG_BadVariant: {
      V v_e_24252 = heff_field(v_it1_24236, 0);
      heff_take_n(v_it1_24236, 1ULL, 1);
      V v_t_24253 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24252}));
      V v_parts_24254 = heff_tag_at(v_ru_24v_24235_24At, TAG_Cons, 2, (V[]){v_t_24253, NTAG(TAG_Nil)});
      V v_x2_24255 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str189), v_parts_24254));
      V v_t_24258;
      switch (heff_tag_of(v_x2_24255)) {
      case TAG_Nil: {
        v_t_24258 = ((V)&g_heff_2eformat_2ekeyTermF_str190);
        break;
      }
      case TAG_Cons: {
        V v_x_24256 = heff_field(v_x2_24255, 0);
        V v_xs_24257 = heff_field(v_x2_24255, 1);
        heff_take_n(v_x2_24255, 3ULL, 2);
        v_t_24258 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str191); V a_1 = v_x_24256; V a_2 = v_xs_24257; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24257); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24255);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str192), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str193), heff_strAppend(v_t_24258, ((V)&g_heff_2eformat_2ekeyTermF_str194))));
    }
    default: return heff_nomatch(v_it1_24236);
    }
  }
  default: return heff_nomatch(v_v_24235);
  }
}
V g_heff_2eformat_2ekeyTermF_lam2(V self, V *args) {
  V v_f_24270 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24270)) {
  case TAG_At: {
    V v_it1_24271 = heff_field(v_f_24270, 0);
    V v_ru_24f_24270_24At = heff_take_reuse_n(v_f_24270, 1ULL, 2);
    switch (heff_tag_of(v_it1_24271)) {
    case TAG_SetField: {
      V v_x_24273 = heff_field(v_it1_24271, 0);
      V v_e_24275 = heff_field(v_it1_24271, 2);
      heff_take_n(v_it1_24271, 5ULL, 3);
      V v_t_24276 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24275}));
      V v_t_24277 = heff_tag_at(v_ru_24f_24270_24At, TAG_Cons, 2, (V[]){v_t_24276, NTAG(TAG_Nil)});
      V v_parts_24278 = heff_tag(TAG_Cons, 2, (V[]){v_x_24273, v_t_24277});
      V v_x2_24279 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str205), v_parts_24278));
      V v_t_24282;
      switch (heff_tag_of(v_x2_24279)) {
      case TAG_Nil: {
        v_t_24282 = ((V)&g_heff_2eformat_2ekeyTermF_str206);
        break;
      }
      case TAG_Cons: {
        V v_x_24280 = heff_field(v_x2_24279, 0);
        V v_xs_24281 = heff_field(v_x2_24279, 1);
        heff_take_n(v_x2_24279, 3ULL, 2);
        v_t_24282 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str207); V a_1 = v_x_24280; V a_2 = v_xs_24281; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24281); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24279);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str208), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str209), heff_strAppend(v_t_24282, ((V)&g_heff_2eformat_2ekeyTermF_str210))));
    }
    case TAG_BadFieldSet: {
      V v_e_24283 = heff_field(v_it1_24271, 0);
      heff_take_n(v_it1_24271, 1ULL, 1);
      V v_t_24284 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24283}));
      V v_parts_24285 = heff_tag_at(v_ru_24f_24270_24At, TAG_Cons, 2, (V[]){v_t_24284, NTAG(TAG_Nil)});
      V v_x2_24286 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str211), v_parts_24285));
      V v_t_24289;
      switch (heff_tag_of(v_x2_24286)) {
      case TAG_Nil: {
        v_t_24289 = ((V)&g_heff_2eformat_2ekeyTermF_str212);
        break;
      }
      case TAG_Cons: {
        V v_x_24287 = heff_field(v_x2_24286, 0);
        V v_xs_24288 = heff_field(v_x2_24286, 1);
        heff_take_n(v_x2_24286, 3ULL, 2);
        v_t_24289 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str213); V a_1 = v_x_24287; V a_2 = v_xs_24288; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24288); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24286);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str214), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str215), heff_strAppend(v_t_24289, ((V)&g_heff_2eformat_2ekeyTermF_str216))));
    }
    default: return heff_nomatch(v_it1_24271);
    }
  }
  default: return heff_nomatch(v_f_24270);
  }
}
V g_heff_2eformat_2ekeyTermF_lam3(V self, V *args) {
  V v_a_24303 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24303)) {
  case TAG_At: {
    V v_it1_24304 = heff_field(v_a_24303, 0);
    V v_ru_24a_24303_24At = heff_take_reuse_n(v_a_24303, 1ULL, 2);
    switch (heff_tag_of(v_it1_24304)) {
    case TAG_MkAlt: {
      V v_p_24306 = heff_field(v_it1_24304, 0);
      V v_e_24307 = heff_field(v_it1_24304, 1);
      V v_ru_24it1_24304_24MkAlt = heff_take_reuse_n(v_it1_24304, 3ULL, 2);
      V v_t_24308 = (g_heff_2eformat_2epatKey(v_p_24306));
      V v_t_24309 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24307}));
      V v_t_24310 = heff_tag_at(v_ru_24a_24303_24At, TAG_Cons, 2, (V[]){v_t_24309, NTAG(TAG_Nil)});
      V v_parts_24311 = heff_tag_at(v_ru_24it1_24304_24MkAlt, TAG_Cons, 2, (V[]){v_t_24308, v_t_24310});
      V v_x2_24312 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str227), v_parts_24311));
      V v_t_24315;
      switch (heff_tag_of(v_x2_24312)) {
      case TAG_Nil: {
        v_t_24315 = ((V)&g_heff_2eformat_2ekeyTermF_str228);
        break;
      }
      case TAG_Cons: {
        V v_x_24313 = heff_field(v_x2_24312, 0);
        V v_xs_24314 = heff_field(v_x2_24312, 1);
        heff_take_n(v_x2_24312, 3ULL, 2);
        v_t_24315 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str229); V a_1 = v_x_24313; V a_2 = v_xs_24314; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24314); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24312);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str230), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str231), heff_strAppend(v_t_24315, ((V)&g_heff_2eformat_2ekeyTermF_str232))));
    }
    default: return heff_nomatch(v_it1_24304);
    }
  }
  default: return heff_nomatch(v_a_24303);
  }
}
V g_heff_2eformat_2ekeyTermF_lam4(V self, V *args) {
  V v_m_24343 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_24343)) {
  case TAG_At: {
    V v_it1_24344 = heff_field(v_m_24343, 0);
    V v_ru_24m_24343_24At = heff_take_reuse_n(v_m_24343, 1ULL, 2);
    switch (heff_tag_of(v_it1_24344)) {
    case TAG_StmtBind: {
      V v_x_24346 = heff_field(v_it1_24344, 0);
      V v_e_24348 = heff_field(v_it1_24344, 2);
      heff_take_n(v_it1_24344, 5ULL, 3);
      V v_t_24349 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24348}));
      V v_t_24350 = heff_tag_at(v_ru_24m_24343_24At, TAG_Cons, 2, (V[]){v_t_24349, NTAG(TAG_Nil)});
      V v_parts_24351 = heff_tag(TAG_Cons, 2, (V[]){v_x_24346, v_t_24350});
      V v_x2_24352 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str249), v_parts_24351));
      V v_t_24355;
      switch (heff_tag_of(v_x2_24352)) {
      case TAG_Nil: {
        v_t_24355 = ((V)&g_heff_2eformat_2ekeyTermF_str250);
        break;
      }
      case TAG_Cons: {
        V v_x_24353 = heff_field(v_x2_24352, 0);
        V v_xs_24354 = heff_field(v_x2_24352, 1);
        heff_take_n(v_x2_24352, 3ULL, 2);
        v_t_24355 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str251); V a_1 = v_x_24353; V a_2 = v_xs_24354; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24354); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24352);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str252), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str253), heff_strAppend(v_t_24355, ((V)&g_heff_2eformat_2ekeyTermF_str254))));
    }
    case TAG_StmtLet: {
      V v_p_24356 = heff_field(v_it1_24344, 0);
      V v_e_24357 = heff_field(v_it1_24344, 1);
      V v_ru_24it1_24344_24StmtLet = heff_take_reuse_n(v_it1_24344, 3ULL, 2);
      V v_t_24358 = (g_heff_2eformat_2epatKey(v_p_24356));
      V v_t_24359 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24357}));
      V v_t_24360 = heff_tag_at(v_ru_24m_24343_24At, TAG_Cons, 2, (V[]){v_t_24359, NTAG(TAG_Nil)});
      V v_parts_24361 = heff_tag_at(v_ru_24it1_24344_24StmtLet, TAG_Cons, 2, (V[]){v_t_24358, v_t_24360});
      V v_x2_24362 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str255), v_parts_24361));
      V v_t_24365;
      switch (heff_tag_of(v_x2_24362)) {
      case TAG_Nil: {
        v_t_24365 = ((V)&g_heff_2eformat_2ekeyTermF_str256);
        break;
      }
      case TAG_Cons: {
        V v_x_24363 = heff_field(v_x2_24362, 0);
        V v_xs_24364 = heff_field(v_x2_24362, 1);
        heff_take_n(v_x2_24362, 3ULL, 2);
        v_t_24365 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str257); V a_1 = v_x_24363; V a_2 = v_xs_24364; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24364); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24362);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str258), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str259), heff_strAppend(v_t_24365, ((V)&g_heff_2eformat_2ekeyTermF_str260))));
    }
    case TAG_StmtExpr: {
      V v_e_24366 = heff_field(v_it1_24344, 0);
      heff_take_n(v_it1_24344, 1ULL, 1);
      V v_t_24367 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24366}));
      V v_parts_24368 = heff_tag_at(v_ru_24m_24343_24At, TAG_Cons, 2, (V[]){v_t_24367, NTAG(TAG_Nil)});
      V v_x2_24369 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyTermF_str261), v_parts_24368));
      V v_t_24372;
      switch (heff_tag_of(v_x2_24369)) {
      case TAG_Nil: {
        v_t_24372 = ((V)&g_heff_2eformat_2ekeyTermF_str262);
        break;
      }
      case TAG_Cons: {
        V v_x_24370 = heff_field(v_x2_24369, 0);
        V v_xs_24371 = heff_field(v_x2_24369, 1);
        heff_take_n(v_x2_24369, 3ULL, 2);
        v_t_24372 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyTermF_str263); V a_1 = v_x_24370; V a_2 = v_xs_24371; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24371); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24369);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str264), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str265), heff_strAppend(v_t_24372, ((V)&g_heff_2eformat_2ekeyTermF_str266))));
    }
    default: return heff_nomatch(v_it1_24344);
    }
  }
  default: return heff_nomatch(v_m_24343);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyDeclF_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyDeclF_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {101, 113, 117, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyDeclF_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eformat_2ekeyDeclF_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {101, 113, 117, 97, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyDeclF_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyDeclF_str28 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 102, 105, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyDeclF_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str36 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyDeclF_str38 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str41 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str42 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eformat_2ekeyDeclF_str44 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 114, 105, 109, 105, 116, 105, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str47 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str48 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyDeclF_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str54 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyDeclF_str56 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eformat_2ekeyDeclF_lam0(V self, V *args);
Clo g_heff_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2eformat_2ekeyDeclF(V v_r_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_ty_247}));
    V v_x2_2429 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyDeclF_lam0, 1, 1, (V[]){v_r_240}), v_eqs_248));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2eformat_2ekeyDeclF_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str11); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str12), heff_strAppend(v_t_2432, ((V)&g_heff_2eformat_2ekeyDeclF_str13)));
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    V v_parts_2435 = heff_tag(TAG_Cons, 2, (V[]){v_f_245, heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2434})});
    V v_x2_2436 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str14), v_parts_2435));
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2eformat_2ekeyDeclF_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str16); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str17), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str18), heff_strAppend(v_t_2439, ((V)&g_heff_2eformat_2ekeyDeclF_str19))));
  }
  case TAG_DeclDefine: {
    V v_x_2440 = heff_field(v_t_244, 0);
    V v_ps_2442 = heff_field(v_t_244, 2);
    V v_u_2443 = heff_field(v_t_244, 3);
    V v_body_2444 = heff_field(v_t_244, 4);
    heff_take_n(v_t_244, 29ULL, 5);
    V v_t_2445 = heff_tr(heff_apply(((V)&g_heff_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2446 = (g_prelude_2emap(v_t_2445, v_ps_2442));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2eformat_2ekeyDeclF_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str21); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    V v_t_2450 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str22), heff_strAppend(v_t_2449, ((V)&g_heff_2eformat_2ekeyDeclF_str23)));
    V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_u_2443}));
    V v_t_2452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2444}));
    V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2450, heff_tag(TAG_Cons, 2, (V[]){v_t_2451, v_t_2453})});
    V v_parts_2455 = heff_tag(TAG_Cons, 2, (V[]){v_x_2440, v_t_2454});
    V v_x2_2456 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str24), v_parts_2455));
    V v_t_2459;
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_Nil: {
      v_t_2459 = ((V)&g_heff_2eformat_2ekeyDeclF_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_xs_2458 = heff_field(v_x2_2456, 1);
      heff_take_n(v_x2_2456, 3ULL, 2);
      v_t_2459 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str26); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2456);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str27), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str28), heff_strAppend(v_t_2459, ((V)&g_heff_2eformat_2ekeyDeclF_str29))));
  }
  case TAG_DeclTheory: {
    V v_x_2460 = heff_field(v_t_244, 0);
    V v_ps_2462 = heff_field(v_t_244, 2);
    V v_body_2463 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2464 = heff_tr(heff_apply(((V)&g_heff_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2465 = (g_prelude_2emap(v_t_2464, v_ps_2462));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2eformat_2ekeyDeclF_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str31); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str32), heff_strAppend(v_t_2468, ((V)&g_heff_2eformat_2ekeyDeclF_str33)));
    V v_t_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2463}));
    V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_parts_2472 = heff_tag(TAG_Cons, 2, (V[]){v_x_2460, heff_tag(TAG_Cons, 2, (V[]){v_t_2469, v_t_2471})});
    V v_x2_2473 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str34), v_parts_2472));
    V v_t_2476;
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2eformat_2ekeyDeclF_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_xs_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      v_t_2476 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str36); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2473);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str37), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str38), heff_strAppend(v_t_2476, ((V)&g_heff_2eformat_2ekeyDeclF_str39))));
  }
  case TAG_DeclPrimitive: {
    V v_x_2477 = heff_field(v_t_244, 0);
    V v_t_2479 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2479}));
    V v_t_2481 = heff_tag(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
    V v_parts_2482 = heff_tag(TAG_Cons, 2, (V[]){v_x_2477, v_t_2481});
    V v_x2_2483 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str40), v_parts_2482));
    V v_t_2486;
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2eformat_2ekeyDeclF_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_xs_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      v_t_2486 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str42); V a_1 = v_x_2484; V a_2 = v_xs_2485; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2485); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2483);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str43), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str44), heff_strAppend(v_t_2486, ((V)&g_heff_2eformat_2ekeyDeclF_str45))));
  }
  case TAG_DeclTest: {
    V v_x_2487 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24DeclTest = heff_take_reuse_n(v_t_244, 1ULL, 2);
    heff_drop(v_r_240);
    V v_t_2489 = heff_tag_at(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){v_x_2487, NTAG(TAG_Nil)});
    V v_x2_2490 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str46), v_t_2489));
    V v_t_2493;
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_Nil: {
      v_t_2493 = ((V)&g_heff_2eformat_2ekeyDeclF_str47);
      break;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_xs_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      v_t_2493 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str48); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2490);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str49), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str50), heff_strAppend(v_t_2493, ((V)&g_heff_2eformat_2ekeyDeclF_str51))));
  }
  case TAG_DeclWatch: {
    V v_e_2494 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_2495 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2494}));
    V v_parts_2496 = heff_tag(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    V v_x2_2497 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str52), v_parts_2496));
    V v_t_24100;
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2eformat_2ekeyDeclF_str53);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_xs_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      v_t_24100 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str54); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2497);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str55), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str56), heff_strAppend(v_t_24100, ((V)&g_heff_2eformat_2ekeyDeclF_str57))));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2ekeyDeclF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eformat_2ekeyDeclF_lam0(V self, V *args) {
  V v_eq_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_eq_2410)) {
  case TAG_At: {
    V v_it1_2411 = heff_field(v_eq_2410, 0);
    V v_ru_24eq_2410_24At = heff_take_reuse_n(v_eq_2410, 1ULL, 2);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkEquation: {
      V v_g_2413 = heff_field(v_it1_2411, 0);
      V v_ps_2415 = heff_field(v_it1_2411, 2);
      V v_rhs_2416 = heff_field(v_it1_2411, 3);
      heff_take_n(v_it1_2411, 13ULL, 4);
      V v_x2_2417 = (g_prelude_2emap_24s229671972x1653917392(v_ps_2415));
      V v_t_2420;
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_xs_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      V v_t_2421 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2eformat_2ekeyDeclF_str3)));
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_rhs_2416}));
      V v_t_2423 = heff_tag_at(v_ru_24eq_2410_24At, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_parts_2424 = heff_tag(TAG_Cons, 2, (V[]){v_g_2413, heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
      V v_x2_2425 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2eformat_2ekeyDeclF_str4), v_parts_2424));
      V v_t_2428;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2eformat_2ekeyDeclF_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_xs_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        v_t_2428 = ({ V a_0 = ((V)&g_heff_2eformat_2ekeyDeclF_str6); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str7), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str8), heff_strAppend(v_t_2428, ((V)&g_heff_2eformat_2ekeyDeclF_str9))));
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_eq_2410);
  }
}
V g_heff_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2eformat_2ekeys_val;
static int g_heff_2eformat_2ekeys_st;
static V g_heff_2eformat_2ekeys_init(void) {
  return heff_rec(2, shape_e__decl, (V[]){((V)&g_heff_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2eformat_2ekeys_get(void) {
  if (g_heff_2eformat_2ekeys_st == 2) return g_heff_2eformat_2ekeys_val;
  if (g_heff_2eformat_2ekeys_st == 1) heff_fail("defined by itself");
  g_heff_2eformat_2ekeys_st = 1;
  g_heff_2eformat_2ekeys_val = heff_tr(g_heff_2eformat_2ekeys_init());
  g_heff_2eformat_2ekeys_st = 2;
  return g_heff_2eformat_2ekeys_val;
}
V g_heff_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eformat_2ekeys_get()); V a_1 = v_n_240; V r_ = (g_heff_2eformat_2ekeyTermF(a_0, a_1)); heff_drop(v_n_240); r_; });
}
V g_heff_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eformat_2ekeys_get()); V a_1 = v_d_241; V r_ = (g_heff_2eformat_2ekeyDeclF(a_0, a_1)); heff_drop(v_d_241); r_; });
}
Clo g_heff_2eformat_2ereadNoFixities_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ereadNoFixities_entry, 1, 0};

V g_heff_2eformat_2ereadNoFixities(V v_text_240) {
top: ;
  V v_t_241 = heff_rec(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_242 = (g_heff_2efmt_2elex_2elexGo(v_text_240, v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_243 = heff_arrayFromList(heff_get(heff_dup(v_l_242), LBL_tokens));
  V v_t_244 = (g_heff_2efmt_2etoks_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), heff_get(heff_dup(v_l_242), LBL_tokens)));
  V v_t_245 = (g_prelude_2emap_24s1479019137x857976527(heff_get(v_l_242, LBL_errors)));
  return (g_heff_2esurface_2ereadToks_24s2076454845x2020338244(v_t_243, heff_arrayFromList(v_t_244), v_t_245));
}
V g_heff_2eformat_2ereadNoFixities_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2ereadNoFixities(a[0]);
}
Clo g_heff_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = heff_strEq(heff_dup(v_a_244), heff_dup(v_b_246));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2estrsEq(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eformat_2esameMeaning_str0 = {{0x80000000u, K_STR, 0}, 35, 35, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 116, 104, 101, 32, 105, 109, 112, 111, 114, 116, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2eformat_2esameMeaning_str1 = {{0x80000000u, K_STR, 0}, 68, 68, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 102, 105, 108, 101, 32, 109, 101, 97, 110, 115, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[76]; } g_heff_2eformat_2esameMeaning_str2 = {{0x80000000u, K_STR, 0}, 76, 76, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 108, 111, 115, 101, 32, 111, 114, 32, 109, 111, 118, 101, 32, 97, 32, 99, 111, 109, 109, 101, 110, 116, 32, 97, 99, 114, 111, 115, 115, 32, 99, 111, 100, 101, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41}};
Clo g_heff_2eformat_2esameMeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2esameMeaning_entry, 4, 0};

V g_heff_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = ({ V b_0 = heff_get(heff_dup(v_a_242), LBL_imports); V b_1 = heff_get(heff_dup(v_b_243), LBL_imports); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str0)});
  }
  case TAG_False: {
    V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_a_242), LBL_decls); V b_1 = heff_get(heff_dup(v_b_243), LBL_decls); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_x1_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x1_247 = ({ V b_0 = heff_get(v_a_242, LBL_diags); V b_1 = heff_get(v_b_243, LBL_diags); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      break;
    }
    case TAG_False: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str1)});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2410 = heff_get(v_t_249, LBL_text);
      V v_t_2411 = heff_rec(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2412 = (g_heff_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s792566809x1637979488(MK_INT(0LL), heff_get(v_t_2412, LBL_comments)));
      V v_t_2414 = (g_heff_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2415 = heff_get(v_t_2414, LBL_text);
      V v_t_2416 = heff_rec(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2417 = (g_heff_2efmt_2elex_2elexGo(v_src_2415, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2418 = (g_prelude_2emap_24s792566809x1637979488(MK_INT(0LL), heff_get(v_t_2417, LBL_comments)));
      V v_x1_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_True: {
        return heff_tag(TAG_Right, 1, (V[]){v_out_241});
      }
      case TAG_False: {
        heff_drop(v_out_241);
        return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str2)});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eformat_2esameMeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2esameMeaning(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eformat_2echeck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2echeck_entry, 2, 0};

V g_heff_2eformat_2echeck(V v_src_240, V v_out_241) {
top: ;
  V v_h_242 = (g_heff_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_r_243 = (g_heff_2eformat_2ereadNoFixities(heff_get(heff_dup(v_h_242), LBL_text)));
  V v_t_244 = (g_prelude_2emap_24s1639847025x48103675(heff_get(v_h_242, LBL_imports)));
  V v_t_245 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eformat_2ekeys_get()), LBL_decl), heff_get(heff_dup(v_r_243), LBL_decls)));
  V v_t_246 = (g_prelude_2emap_24s913954207x1153178935(heff_get(v_r_243, LBL_diags)));
  V v_h_247 = (g_heff_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_r_248 = (g_heff_2eformat_2ereadNoFixities(heff_get(heff_dup(v_h_247), LBL_text)));
  V v_t_249 = (g_prelude_2emap_24s1639847025x48103675(heff_get(v_h_247, LBL_imports)));
  V v_t_2410 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eformat_2ekeys_get()), LBL_decl), heff_get(heff_dup(v_r_248), LBL_decls)));
  V v_t_2411 = (g_prelude_2emap_24s913954207x1153178935(heff_get(v_r_248, LBL_diags)));
  return (g_heff_2eformat_2esameMeaning(v_src_240, v_out_241, heff_rec(3, shape_imports__decls__diags, (V[]){v_t_244, v_t_245, v_t_246}), heff_rec(3, shape_imports__decls__diags, (V[]){v_t_249, v_t_2410, v_t_2411})));
}
V g_heff_2eformat_2echeck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2echeck(a[0], a[1]);
}
Clo g_heff_2eformat_2eformat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2eformat_entry, 1, 0};

V g_heff_2eformat_2eformat(V v_src_240) {
top: ;
  V v_t_241 = (g_heff_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_src_242 = heff_get(v_t_241, LBL_text);
  V v_t_243 = heff_rec(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get(v_t_244, LBL_tokens));
  V v_t_246 = (g_heff_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esurface_2efixityFrom_24s968693116x98413397(v_t_246));
  V v_f_248 = heff_get(v_t_247, LBL_fixities);
  V v_t_249 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_f_248, heff_dup(v_src_240)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Left = heff_take_reuse_n(v_t_249, 1ULL, 1);
    heff_drop(v_src_240);
    return heff_tag_at(v_ru_24t_249_24Left, TAG_Left, 1, (V[]){v_why_2410});
  }
  case TAG_Right: {
    V v_out_2411 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    return (g_heff_2eformat_2echeck(v_src_240, v_out_2411));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2eformat_2eformat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2eformat(a[0]);
}