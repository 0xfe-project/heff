// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {111, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str20 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str28 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str35 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 101, 99, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2epatKey_str37 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2epatKey_str38 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str39 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2epatKey_str40 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2epatKey_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2epatKey_str42 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2epatKey_str45 = {{0x80000000u, K_STR, 0}, 4, 4, {119, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str47 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2epatKey_str49 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2epatKey_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2epatKey_entry, 1, 0};

V g_heff_2eformat_2epatKey(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
    V v_x2_246 = (g_prelude_2emap_24s693(v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eformat_2epatKey_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str1), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str2), heff_strAppend(v_t_249, ((V)&g_heff_2eformat_2epatKey_str3))));
  }
  case TAG_PatTag: {
    V v_t_2410 = heff_field(v_t_243, 0);
    V v_ps_2412 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2413 = (g_prelude_2emap(((V)&g_heff_2eformat_2epatKey_clo), v_ps_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eformat_2epatKey_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = v_x_2414; V a_1 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2eformat_2epatKey_str6)));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_parts_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2418});
    V v_x2_2420 = (g_prelude_2emap_24s693(v_parts_2419));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2eformat_2epatKey_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = v_x_2421; V a_1 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str8), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str9), heff_strAppend(v_t_2423, ((V)&g_heff_2eformat_2epatKey_str10))));
  }
  case TAG_PatOp: {
    V v_x_2424 = heff_field(v_t_243, 0);
    V v_ps_2426 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2427 = (g_prelude_2emap(((V)&g_heff_2eformat_2epatKey_clo), v_ps_2426));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2eformat_2epatKey_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = v_xs_2429; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str12), heff_strAppend(v_t_2430, ((V)&g_heff_2eformat_2epatKey_str13)));
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_parts_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2424, v_t_2432});
    V v_x2_2434 = (g_prelude_2emap_24s693(v_parts_2433));
    V v_t_2437;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2eformat_2epatKey_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_xs_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      v_t_2437 = ({ V a_0 = v_x_2435; V a_1 = v_xs_2436; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2436); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str15), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str16), heff_strAppend(v_t_2437, ((V)&g_heff_2eformat_2epatKey_str17))));
  }
  case TAG_PatInt: {
    V v_i_2438 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), NTAG(TAG_Nil)});
    V v_x2_2440 = (g_prelude_2emap_24s693(v_t_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2eformat_2epatKey_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = v_x_2441; V a_1 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str19), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str20), heff_strAppend(v_t_2443, ((V)&g_heff_2eformat_2epatKey_str21))));
  }
  case TAG_PatFloat: {
    V v_x_2444 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2444), NTAG(TAG_Nil)});
    V v_x2_2446 = (g_prelude_2emap_24s693(v_t_2445));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2eformat_2epatKey_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = v_x_2447; V a_1 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str23), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str24), heff_strAppend(v_t_2449, ((V)&g_heff_2eformat_2epatKey_str25))));
  }
  case TAG_PatString: {
    V v_x_2450 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
    V v_x2_2452 = (g_prelude_2emap_24s693(v_t_2451));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2eformat_2epatKey_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = v_x_2453; V a_1 = v_xs_2454; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str27), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str28), heff_strAppend(v_t_2455, ((V)&g_heff_2eformat_2epatKey_str29))));
  }
  case TAG_PatRecord: {
    V v_fs_2456 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_2457 = (g_prelude_2emap_24s694(v_fs_2456));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2eformat_2epatKey_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = v_x_2458; V a_1 = v_xs_2459; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eformat_2epatKey_str31), heff_strAppend(v_t_2460, ((V)&g_heff_2eformat_2epatKey_str32)));
    V v_parts_2462 = heff_tag(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
    V v_x2_2463 = (g_prelude_2emap_24s693(v_parts_2462));
    V v_t_2466;
    switch (heff_tag_of(v_x2_2463)) {
    case TAG_Nil: {
      v_t_2466 = ((V)&g_heff_2eformat_2epatKey_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_2464 = heff_field(v_x2_2463, 0);
      V v_xs_2465 = heff_field(v_x2_2463, 1);
      heff_take_n(v_x2_2463, 3ULL, 2);
      v_t_2466 = ({ V a_0 = v_x_2464; V a_1 = v_xs_2465; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2465); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2463);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str34), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str35), heff_strAppend(v_t_2466, ((V)&g_heff_2eformat_2epatKey_str36))));
  }
  case TAG_PatWord: {
    V v_w_2467 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2468;
    switch (heff_tag_of(v_w_2467)) {
    case TAG_TypeWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str37);
      break;
    }
    case TAG_IntWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str38);
      break;
    }
    case TAG_FloatWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str39);
      break;
    }
    case TAG_StringWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str40);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str41);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2468 = ((V)&g_heff_2eformat_2epatKey_str42);
      break;
    }
    default: heff_nomatch(v_w_2467);
    }
    V v_parts_2469 = heff_tag(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
    V v_x2_2470 = (g_prelude_2emap_24s693(v_parts_2469));
    V v_t_2473;
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_Nil: {
      v_t_2473 = ((V)&g_heff_2eformat_2epatKey_str43);
      break;
    }
    case TAG_Cons: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_xs_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      v_t_2473 = ({ V a_0 = v_x_2471; V a_1 = v_xs_2472; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2472); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2470);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str44), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str45), heff_strAppend(v_t_2473, ((V)&g_heff_2eformat_2epatKey_str46))));
  }
  case TAG_PatAs: {
    V v_x_2474 = heff_field(v_t_243, 0);
    V v_q_2476 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_t_2477 = (g_heff_2eformat_2epatKey(v_q_2476));
    V v_t_2478 = heff_tag(TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
    V v_parts_2479 = heff_tag(TAG_Cons, 2, (V[]){v_x_2474, v_t_2478});
    V v_x2_2480 = (g_prelude_2emap_24s693(v_parts_2479));
    V v_t_2483;
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_Nil: {
      v_t_2483 = ((V)&g_heff_2eformat_2epatKey_str47);
      break;
    }
    case TAG_Cons: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_xs_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      v_t_2483 = ({ V a_0 = v_x_2481; V a_1 = v_xs_2482; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2482); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2480);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2epatKey_str48), heff_strAppend(((V)&g_heff_2eformat_2epatKey_str49), heff_strAppend(v_t_2483, ((V)&g_heff_2eformat_2epatKey_str50))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2epatKey(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2eparamKey_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {101, 120, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2eparamKey_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2eparamKey_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_prelude_2emap_24s693(v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2eformat_2eparamKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str1), heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2eformat_2eparamKey_str3))));
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_t_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2416}));
      V v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag(TAG_Cons, 2, (V[]){v_x_2414, v_t_2418});
      V v_x2_2420 = (g_prelude_2emap_24s693(v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2eformat_2eparamKey_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = v_x_2421; V a_1 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str5), heff_strAppend(((V)&g_heff_2eformat_2eparamKey_str6), heff_strAppend(v_t_2423, ((V)&g_heff_2eformat_2eparamKey_str7))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2eparamKey(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str22 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str24 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str26 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str27 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str28 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str29 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {119, 111, 114, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str34 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str39 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str41 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str45 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str47 = {{0x80000000u, K_STR, 0}, 5, 5, {110, 97, 109, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str49 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str51 = {{0x80000000u, K_STR, 0}, 5, 5, {110, 97, 109, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str55 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str57 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str59 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 110, 115, 116, 97, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str61 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str63 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 110, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str65 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str67 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str69 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str71 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str73 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyTermF_str75 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 109, 112, 108, 105, 99, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str77 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str79 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 110, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str81 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str83 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str85 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str87 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 110, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str89 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str91 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 112, 101, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str92 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str93 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str95 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str96 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str97 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str98 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str99 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str100 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str101 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str103 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str104 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str105 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str106 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str107 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str108 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str109 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str110 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 105, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str111 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str112 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str113 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str114 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str115 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str116 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str117 = {{0x80000000u, K_STR, 0}, 7, 7, {118, 97, 114, 105, 97, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str119 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str120 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str121 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str122 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str123 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str124 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str125 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str126 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str127 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str128 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str129 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str130 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str131 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str132 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str133 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str134 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str135 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str136 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str137 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str138 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str139 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str140 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str141 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str142 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyTermF_str143 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 114, 117, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str144 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str145 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str146 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str147 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str148 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str149 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str150 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str151 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str152 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str153 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str154 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str155 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str156 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str157 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str158 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str159 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str160 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str161 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str162 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str163 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str164 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str165 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eformat_2ekeyTermF_str166 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str167 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str168 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str169 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyTermF_str170 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 120, 112, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str171 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str172 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str173 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str174 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str175 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str176 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eformat_2ekeyTermF_str177 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str178 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str179 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str180 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str181 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str182 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str183 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyTermF_str184 = {{0x80000000u, K_STR, 0}, 5, 5, {108, 111, 99, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str185 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str186 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str187 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eformat_2ekeyTermF_str188 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 118, 97, 108, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyTermF_str189 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eformat_2ekeyTermF_lam0(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam1(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam2(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam3(V self, V *args);
V g_heff_2eformat_2ekeyTermF_lam4(V self, V *args);
Clo g_heff_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2eformat_2ekeyTermF(V v_r_240, V v_n_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_it_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
    V v_x2_247 = (g_prelude_2emap_24s693(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eformat_2ekeyTermF_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str1), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2eformat_2ekeyTermF_str3))));
  }
  case TAG_EImplicitVar: {
    V v_x_2411 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
    V v_x2_2413 = (g_prelude_2emap_24s693(v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eformat_2ekeyTermF_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = v_x_2414; V a_1 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str5), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str6), heff_strAppend(v_t_2416, ((V)&g_heff_2eformat_2ekeyTermF_str7))));
  }
  case TAG_ETag: {
    V v_x_2417 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, NTAG(TAG_Nil)});
    V v_x2_2419 = (g_prelude_2emap_24s693(v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2eformat_2ekeyTermF_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = v_x_2420; V a_1 = v_xs_2421; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str10), heff_strAppend(v_t_2422, ((V)&g_heff_2eformat_2ekeyTermF_str11))));
  }
  case TAG_EInt: {
    V v_i_2423 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_2423), NTAG(TAG_Nil)});
    V v_x2_2425 = (g_prelude_2emap_24s693(v_t_2424));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eformat_2ekeyTermF_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str13), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str14), heff_strAppend(v_t_2428, ((V)&g_heff_2eformat_2ekeyTermF_str15))));
  }
  case TAG_EFloat: {
    V v_x_2429 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2429), NTAG(TAG_Nil)});
    V v_x2_2431 = (g_prelude_2emap_24s693(v_t_2430));
    V v_t_2434;
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2eformat_2ekeyTermF_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      V v_xs_2433 = heff_field(v_x2_2431, 1);
      heff_take_n(v_x2_2431, 3ULL, 2);
      v_t_2434 = ({ V a_0 = v_x_2432; V a_1 = v_xs_2433; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2433); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2431);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str17), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str18), heff_strAppend(v_t_2434, ((V)&g_heff_2eformat_2ekeyTermF_str19))));
  }
  case TAG_EString: {
    V v_x_2435 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){v_x_2435, NTAG(TAG_Nil)});
    V v_x2_2437 = (g_prelude_2emap_24s693(v_t_2436));
    V v_t_2440;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2eformat_2ekeyTermF_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      v_t_2440 = ({ V a_0 = v_x_2438; V a_1 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str21), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str22), heff_strAppend(v_t_2440, ((V)&g_heff_2eformat_2ekeyTermF_str23))));
  }
  case TAG_EWord: {
    V v_w_2441 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2442;
    switch (heff_tag_of(v_w_2441)) {
    case TAG_TypeWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str24);
      break;
    }
    case TAG_IntWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str25);
      break;
    }
    case TAG_FloatWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str26);
      break;
    }
    case TAG_StringWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str27);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str28);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2442 = ((V)&g_heff_2eformat_2ekeyTermF_str29);
      break;
    }
    default: heff_nomatch(v_w_2441);
    }
    V v_parts_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
    V v_x2_2444 = (g_prelude_2emap_24s693(v_parts_2443));
    V v_t_2447;
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nil: {
      v_t_2447 = ((V)&g_heff_2eformat_2ekeyTermF_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_xs_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      v_t_2447 = ({ V a_0 = v_x_2445; V a_1 = v_xs_2446; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2446); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2444);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str31), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str32), heff_strAppend(v_t_2447, ((V)&g_heff_2eformat_2ekeyTermF_str33))));
  }
  case TAG_EApp: {
    V v_h_2448 = heff_field(v_it_244, 0);
    V v_args_2449 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EApp = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_2448}));
    V v_x2_2451 = (g_prelude_2emap(heff_get(v_r_240, LBL_e), v_args_2449));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2eformat_2ekeyTermF_str34);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = v_x_2452; V a_1 = v_xs_2453; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    V v_t_2455 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str35), heff_strAppend(v_t_2454, ((V)&g_heff_2eformat_2ekeyTermF_str36)));
    V v_t_2456 = heff_tag_at(v_ru_24it_244_24EApp, TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
    V v_parts_2457 = heff_tag(TAG_Cons, 2, (V[]){v_t_2450, v_t_2456});
    V v_x2_2458 = (g_prelude_2emap_24s693(v_parts_2457));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2eformat_2ekeyTermF_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = v_x_2459; V a_1 = v_xs_2460; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str38), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str39), heff_strAppend(v_t_2461, ((V)&g_heff_2eformat_2ekeyTermF_str40))));
  }
  case TAG_EProject: {
    V v_x_2462 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_x_2462, NTAG(TAG_Nil)});
    V v_x2_2464 = (g_prelude_2emap_24s693(v_t_2463));
    V v_t_2467;
    switch (heff_tag_of(v_x2_2464)) {
    case TAG_Nil: {
      v_t_2467 = ((V)&g_heff_2eformat_2ekeyTermF_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2465 = heff_field(v_x2_2464, 0);
      V v_xs_2466 = heff_field(v_x2_2464, 1);
      heff_take_n(v_x2_2464, 3ULL, 2);
      v_t_2467 = ({ V a_0 = v_x_2465; V a_1 = v_xs_2466; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2466); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2464);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str42), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str43), heff_strAppend(v_t_2467, ((V)&g_heff_2eformat_2ekeyTermF_str44))));
  }
  case TAG_ENamed: {
    V v_x_2468 = heff_field(v_it_244, 0);
    V v_e_2469 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ENamed = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2469}));
    V v_t_2471 = heff_tag_at(v_ru_24it_244_24ENamed, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_parts_2472 = heff_tag(TAG_Cons, 2, (V[]){v_x_2468, v_t_2471});
    V v_x2_2473 = (g_prelude_2emap_24s693(v_parts_2472));
    V v_t_2476;
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2eformat_2ekeyTermF_str45);
      break;
    }
    case TAG_Cons: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_xs_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      v_t_2476 = ({ V a_0 = v_x_2474; V a_1 = v_xs_2475; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2475); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2473);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str46), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str47), heff_strAppend(v_t_2476, ((V)&g_heff_2eformat_2ekeyTermF_str48))));
  }
  case TAG_EPi: {
    V v_b_2477 = heff_field(v_it_244, 0);
    V v_cod_2478 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EPi = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24118;
    switch (heff_tag_of(v_b_2477)) {
    case TAG_PiNamed: {
      V v_x_2479 = heff_field(v_b_2477, 0);
      V v_t_2481 = heff_field(v_b_2477, 2);
      heff_take_n(v_b_2477, 5ULL, 3);
      V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2481}));
      V v_t_2483 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2482, NTAG(TAG_Nil)});
      V v_parts_2484 = heff_tag(TAG_Cons, 2, (V[]){v_x_2479, v_t_2483});
      V v_x2_2485 = (g_prelude_2emap_24s693(v_parts_2484));
      V v_t_2488;
      switch (heff_tag_of(v_x2_2485)) {
      case TAG_Nil: {
        v_t_2488 = ((V)&g_heff_2eformat_2ekeyTermF_str49);
        break;
      }
      case TAG_Cons: {
        V v_x_2486 = heff_field(v_x2_2485, 0);
        V v_xs_2487 = heff_field(v_x2_2485, 1);
        heff_take_n(v_x2_2485, 3ULL, 2);
        v_t_2488 = ({ V a_0 = v_x_2486; V a_1 = v_xs_2487; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2487); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2485);
      }
      v_t_24118 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str50), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str51), heff_strAppend(v_t_2488, ((V)&g_heff_2eformat_2ekeyTermF_str52))));
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2489 = heff_field(v_b_2477, 0);
      V v_t_2492 = heff_field(v_b_2477, 3);
      heff_take_n(v_b_2477, 9ULL, 4);
      V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2492}));
      V v_t_2494 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
      V v_parts_2495 = heff_tag(TAG_Cons, 2, (V[]){v_x_2489, v_t_2494});
      V v_x2_2496 = (g_prelude_2emap_24s693(v_parts_2495));
      V v_t_2499;
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_Nil: {
        v_t_2499 = ((V)&g_heff_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_Cons: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_xs_2498 = heff_field(v_x2_2496, 1);
        heff_take_n(v_x2_2496, 3ULL, 2);
        v_t_2499 = ({ V a_0 = v_x_2497; V a_1 = v_xs_2498; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2498); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2496);
      }
      v_t_24118 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str54), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str55), heff_strAppend(v_t_2499, ((V)&g_heff_2eformat_2ekeyTermF_str56))));
      break;
    }
    case TAG_PiInstance: {
      V v_x_24100 = heff_field(v_b_2477, 0);
      V v_t_24103 = heff_field(v_b_2477, 3);
      heff_take_n(v_b_2477, 9ULL, 4);
      V v_t_24104 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24103}));
      V v_t_24105 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
      V v_parts_24106 = heff_tag(TAG_Cons, 2, (V[]){v_x_24100, v_t_24105});
      V v_x2_24107 = (g_prelude_2emap_24s693(v_parts_24106));
      V v_t_24110;
      switch (heff_tag_of(v_x2_24107)) {
      case TAG_Nil: {
        v_t_24110 = ((V)&g_heff_2eformat_2ekeyTermF_str57);
        break;
      }
      case TAG_Cons: {
        V v_x_24108 = heff_field(v_x2_24107, 0);
        V v_xs_24109 = heff_field(v_x2_24107, 1);
        heff_take_n(v_x2_24107, 3ULL, 2);
        v_t_24110 = ({ V a_0 = v_x_24108; V a_1 = v_xs_24109; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24109); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24107);
      }
      v_t_24118 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str58), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str59), heff_strAppend(v_t_24110, ((V)&g_heff_2eformat_2ekeyTermF_str60))));
      break;
    }
    case TAG_PiAnon: {
      V v_t_24111 = heff_field(v_b_2477, 0);
      heff_take_n(v_b_2477, 1ULL, 1);
      V v_t_24112 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24111}));
      V v_parts_24113 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
      V v_x2_24114 = (g_prelude_2emap_24s693(v_parts_24113));
      V v_t_24117;
      switch (heff_tag_of(v_x2_24114)) {
      case TAG_Nil: {
        v_t_24117 = ((V)&g_heff_2eformat_2ekeyTermF_str61);
        break;
      }
      case TAG_Cons: {
        V v_x_24115 = heff_field(v_x2_24114, 0);
        V v_xs_24116 = heff_field(v_x2_24114, 1);
        heff_take_n(v_x2_24114, 3ULL, 2);
        v_t_24117 = ({ V a_0 = v_x_24115; V a_1 = v_xs_24116; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24116); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24114);
      }
      v_t_24118 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str62), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str63), heff_strAppend(v_t_24117, ((V)&g_heff_2eformat_2ekeyTermF_str64))));
      break;
    }
    default: heff_nomatch(v_b_2477);
    }
    V v_t_24119 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_cod_2478}));
    V v_t_24120 = heff_tag(TAG_Cons, 2, (V[]){v_t_24119, NTAG(TAG_Nil)});
    V v_parts_24121 = heff_tag(TAG_Cons, 2, (V[]){v_t_24118, v_t_24120});
    V v_x2_24122 = (g_prelude_2emap_24s693(v_parts_24121));
    V v_t_24125;
    switch (heff_tag_of(v_x2_24122)) {
    case TAG_Nil: {
      v_t_24125 = ((V)&g_heff_2eformat_2ekeyTermF_str65);
      break;
    }
    case TAG_Cons: {
      V v_x_24123 = heff_field(v_x2_24122, 0);
      V v_xs_24124 = heff_field(v_x2_24122, 1);
      heff_take_n(v_x2_24122, 3ULL, 2);
      v_t_24125 = ({ V a_0 = v_x_24123; V a_1 = v_xs_24124; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24124); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24122);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str66), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str67), heff_strAppend(v_t_24125, ((V)&g_heff_2eformat_2ekeyTermF_str68))));
  }
  case TAG_ELam: {
    V v_b_24126 = heff_field(v_it_244, 0);
    V v_body_24127 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELam = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24152;
    switch (heff_tag_of(v_b_24126)) {
    case TAG_LamName: {
      V v_x_24128 = heff_field(v_b_24126, 0);
      heff_take_n(v_b_24126, 1ULL, 2);
      V v_t_24130 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24128, NTAG(TAG_Nil)});
      V v_x2_24131 = (g_prelude_2emap_24s693(v_t_24130));
      V v_t_24134;
      switch (heff_tag_of(v_x2_24131)) {
      case TAG_Nil: {
        v_t_24134 = ((V)&g_heff_2eformat_2ekeyTermF_str69);
        break;
      }
      case TAG_Cons: {
        V v_x_24132 = heff_field(v_x2_24131, 0);
        V v_xs_24133 = heff_field(v_x2_24131, 1);
        heff_take_n(v_x2_24131, 3ULL, 2);
        v_t_24134 = ({ V a_0 = v_x_24132; V a_1 = v_xs_24133; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24133); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24131);
      }
      v_t_24152 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str70), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str71), heff_strAppend(v_t_24134, ((V)&g_heff_2eformat_2ekeyTermF_str72))));
      break;
    }
    case TAG_LamImplicit: {
      V v_x_24135 = heff_field(v_b_24126, 0);
      heff_take_n(v_b_24126, 1ULL, 2);
      V v_t_24137 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24135, NTAG(TAG_Nil)});
      V v_x2_24138 = (g_prelude_2emap_24s693(v_t_24137));
      V v_t_24141;
      switch (heff_tag_of(v_x2_24138)) {
      case TAG_Nil: {
        v_t_24141 = ((V)&g_heff_2eformat_2ekeyTermF_str73);
        break;
      }
      case TAG_Cons: {
        V v_x_24139 = heff_field(v_x2_24138, 0);
        V v_xs_24140 = heff_field(v_x2_24138, 1);
        heff_take_n(v_x2_24138, 3ULL, 2);
        v_t_24141 = ({ V a_0 = v_x_24139; V a_1 = v_xs_24140; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24140); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24138);
      }
      v_t_24152 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str74), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str75), heff_strAppend(v_t_24141, ((V)&g_heff_2eformat_2ekeyTermF_str76))));
      break;
    }
    case TAG_LamAnn: {
      V v_x_24142 = heff_field(v_b_24126, 0);
      V v_t_24144 = heff_field(v_b_24126, 2);
      heff_take_n(v_b_24126, 5ULL, 3);
      V v_t_24145 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24144}));
      V v_t_24146 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
      V v_parts_24147 = heff_tag(TAG_Cons, 2, (V[]){v_x_24142, v_t_24146});
      V v_x2_24148 = (g_prelude_2emap_24s693(v_parts_24147));
      V v_t_24151;
      switch (heff_tag_of(v_x2_24148)) {
      case TAG_Nil: {
        v_t_24151 = ((V)&g_heff_2eformat_2ekeyTermF_str77);
        break;
      }
      case TAG_Cons: {
        V v_x_24149 = heff_field(v_x2_24148, 0);
        V v_xs_24150 = heff_field(v_x2_24148, 1);
        heff_take_n(v_x2_24148, 3ULL, 2);
        v_t_24151 = ({ V a_0 = v_x_24149; V a_1 = v_xs_24150; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24150); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24148);
      }
      v_t_24152 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str78), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str79), heff_strAppend(v_t_24151, ((V)&g_heff_2eformat_2ekeyTermF_str80))));
      break;
    }
    default: heff_nomatch(v_b_24126);
    }
    V v_t_24153 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_24127}));
    V v_t_24154 = heff_tag(TAG_Cons, 2, (V[]){v_t_24153, NTAG(TAG_Nil)});
    V v_parts_24155 = heff_tag(TAG_Cons, 2, (V[]){v_t_24152, v_t_24154});
    V v_x2_24156 = (g_prelude_2emap_24s693(v_parts_24155));
    V v_t_24159;
    switch (heff_tag_of(v_x2_24156)) {
    case TAG_Nil: {
      v_t_24159 = ((V)&g_heff_2eformat_2ekeyTermF_str81);
      break;
    }
    case TAG_Cons: {
      V v_x_24157 = heff_field(v_x2_24156, 0);
      V v_xs_24158 = heff_field(v_x2_24156, 1);
      heff_take_n(v_x2_24156, 3ULL, 2);
      v_t_24159 = ({ V a_0 = v_x_24157; V a_1 = v_xs_24158; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24158); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24156);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str82), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str83), heff_strAppend(v_t_24159, ((V)&g_heff_2eformat_2ekeyTermF_str84))));
  }
  case TAG_EAnn: {
    V v_e_24160 = heff_field(v_it_244, 0);
    V v_t_24161 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EAnn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24162 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_e_24160}));
    V v_t_24163 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_24161}));
    V v_t_24164 = heff_tag_at(v_ru_24it_244_24EAnn, TAG_Cons, 2, (V[]){v_t_24163, NTAG(TAG_Nil)});
    V v_parts_24165 = heff_tag(TAG_Cons, 2, (V[]){v_t_24162, v_t_24164});
    V v_x2_24166 = (g_prelude_2emap_24s693(v_parts_24165));
    V v_t_24169;
    switch (heff_tag_of(v_x2_24166)) {
    case TAG_Nil: {
      v_t_24169 = ((V)&g_heff_2eformat_2ekeyTermF_str85);
      break;
    }
    case TAG_Cons: {
      V v_x_24167 = heff_field(v_x2_24166, 0);
      V v_xs_24168 = heff_field(v_x2_24166, 1);
      heff_take_n(v_x2_24166, 3ULL, 2);
      v_t_24169 = ({ V a_0 = v_x_24167; V a_1 = v_xs_24168; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24168); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24166);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str86), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str87), heff_strAppend(v_t_24169, ((V)&g_heff_2eformat_2ekeyTermF_str88))));
  }
  case TAG_ESpec: {
    V v_acc_24170 = heff_field(v_it_244, 0);
    V v_x_24171 = heff_field(v_it_244, 1);
    V v_v_24173 = heff_field(v_it_244, 3);
    heff_take_n(v_it_244, 11ULL, 4);
    V v_t_24174 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_acc_24170}));
    V v_t_24175 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_v_24173}));
    V v_t_24176 = heff_tag(TAG_Cons, 2, (V[]){v_t_24175, NTAG(TAG_Nil)});
    V v_parts_24177 = heff_tag(TAG_Cons, 2, (V[]){v_t_24174, heff_tag(TAG_Cons, 2, (V[]){v_x_24171, v_t_24176})});
    V v_x2_24178 = (g_prelude_2emap_24s693(v_parts_24177));
    V v_t_24181;
    switch (heff_tag_of(v_x2_24178)) {
    case TAG_Nil: {
      v_t_24181 = ((V)&g_heff_2eformat_2ekeyTermF_str89);
      break;
    }
    case TAG_Cons: {
      V v_x_24179 = heff_field(v_x2_24178, 0);
      V v_xs_24180 = heff_field(v_x2_24178, 1);
      heff_take_n(v_x2_24178, 3ULL, 2);
      v_t_24181 = ({ V a_0 = v_x_24179; V a_1 = v_xs_24180; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24180); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24178);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str90), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str91), heff_strAppend(v_t_24181, ((V)&g_heff_2eformat_2ekeyTermF_str92))));
  }
  case TAG_ESig: {
    V v_fs_24182 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24213 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_fs_24182));
    V v_t_24216;
    switch (heff_tag_of(v_x2_24213)) {
    case TAG_Nil: {
      v_t_24216 = ((V)&g_heff_2eformat_2ekeyTermF_str105);
      break;
    }
    case TAG_Cons: {
      V v_x_24214 = heff_field(v_x2_24213, 0);
      V v_xs_24215 = heff_field(v_x2_24213, 1);
      heff_take_n(v_x2_24213, 3ULL, 2);
      v_t_24216 = ({ V a_0 = v_x_24214; V a_1 = v_xs_24215; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24215); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24213);
    }
    V v_t_24217 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str106), heff_strAppend(v_t_24216, ((V)&g_heff_2eformat_2ekeyTermF_str107)));
    V v_parts_24218 = heff_tag(TAG_Cons, 2, (V[]){v_t_24217, NTAG(TAG_Nil)});
    V v_x2_24219 = (g_prelude_2emap_24s693(v_parts_24218));
    V v_t_24222;
    switch (heff_tag_of(v_x2_24219)) {
    case TAG_Nil: {
      v_t_24222 = ((V)&g_heff_2eformat_2ekeyTermF_str108);
      break;
    }
    case TAG_Cons: {
      V v_x_24220 = heff_field(v_x2_24219, 0);
      V v_xs_24221 = heff_field(v_x2_24219, 1);
      heff_take_n(v_x2_24219, 3ULL, 2);
      v_t_24222 = ({ V a_0 = v_x_24220; V a_1 = v_xs_24221; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24221); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24219);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str109), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str110), heff_strAppend(v_t_24222, ((V)&g_heff_2eformat_2ekeyTermF_str111))));
  }
  case TAG_ESum: {
    V v_vs_24223 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24248 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam1, 1, 1, (V[]){v_r_240}), v_vs_24223));
    V v_t_24251;
    switch (heff_tag_of(v_x2_24248)) {
    case TAG_Nil: {
      v_t_24251 = ((V)&g_heff_2eformat_2ekeyTermF_str123);
      break;
    }
    case TAG_Cons: {
      V v_x_24249 = heff_field(v_x2_24248, 0);
      V v_xs_24250 = heff_field(v_x2_24248, 1);
      heff_take_n(v_x2_24248, 3ULL, 2);
      v_t_24251 = ({ V a_0 = v_x_24249; V a_1 = v_xs_24250; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24250); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24248);
    }
    V v_t_24252 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str124), heff_strAppend(v_t_24251, ((V)&g_heff_2eformat_2ekeyTermF_str125)));
    V v_parts_24253 = heff_tag(TAG_Cons, 2, (V[]){v_t_24252, NTAG(TAG_Nil)});
    V v_x2_24254 = (g_prelude_2emap_24s693(v_parts_24253));
    V v_t_24257;
    switch (heff_tag_of(v_x2_24254)) {
    case TAG_Nil: {
      v_t_24257 = ((V)&g_heff_2eformat_2ekeyTermF_str126);
      break;
    }
    case TAG_Cons: {
      V v_x_24255 = heff_field(v_x2_24254, 0);
      V v_xs_24256 = heff_field(v_x2_24254, 1);
      heff_take_n(v_x2_24254, 3ULL, 2);
      v_t_24257 = ({ V a_0 = v_x_24255; V a_1 = v_xs_24256; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24256); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24254);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str127), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str128), heff_strAppend(v_t_24257, ((V)&g_heff_2eformat_2ekeyTermF_str129))));
  }
  case TAG_EStruct: {
    V v_fs_24258 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24279 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam2, 1, 1, (V[]){v_r_240}), v_fs_24258));
    V v_t_24282;
    switch (heff_tag_of(v_x2_24279)) {
    case TAG_Nil: {
      v_t_24282 = ((V)&g_heff_2eformat_2ekeyTermF_str138);
      break;
    }
    case TAG_Cons: {
      V v_x_24280 = heff_field(v_x2_24279, 0);
      V v_xs_24281 = heff_field(v_x2_24279, 1);
      heff_take_n(v_x2_24279, 3ULL, 2);
      v_t_24282 = ({ V a_0 = v_x_24280; V a_1 = v_xs_24281; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24281); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24279);
    }
    V v_t_24283 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str139), heff_strAppend(v_t_24282, ((V)&g_heff_2eformat_2ekeyTermF_str140)));
    V v_parts_24284 = heff_tag(TAG_Cons, 2, (V[]){v_t_24283, NTAG(TAG_Nil)});
    V v_x2_24285 = (g_prelude_2emap_24s693(v_parts_24284));
    V v_t_24288;
    switch (heff_tag_of(v_x2_24285)) {
    case TAG_Nil: {
      v_t_24288 = ((V)&g_heff_2eformat_2ekeyTermF_str141);
      break;
    }
    case TAG_Cons: {
      V v_x_24286 = heff_field(v_x2_24285, 0);
      V v_xs_24287 = heff_field(v_x2_24285, 1);
      heff_take_n(v_x2_24285, 3ULL, 2);
      v_t_24288 = ({ V a_0 = v_x_24286; V a_1 = v_xs_24287; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24287); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24285);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str142), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str143), heff_strAppend(v_t_24288, ((V)&g_heff_2eformat_2ekeyTermF_str144))));
  }
  case TAG_EMatch: {
    V v_s_24289 = heff_field(v_it_244, 0);
    V v_alts_24290 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EMatch = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24291 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_s_24289}));
    V v_x2_24305 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam3, 1, 1, (V[]){v_r_240}), v_alts_24290));
    V v_t_24308;
    switch (heff_tag_of(v_x2_24305)) {
    case TAG_Nil: {
      v_t_24308 = ((V)&g_heff_2eformat_2ekeyTermF_str149);
      break;
    }
    case TAG_Cons: {
      V v_x_24306 = heff_field(v_x2_24305, 0);
      V v_xs_24307 = heff_field(v_x2_24305, 1);
      heff_take_n(v_x2_24305, 3ULL, 2);
      v_t_24308 = ({ V a_0 = v_x_24306; V a_1 = v_xs_24307; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24307); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24305);
    }
    V v_t_24309 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str150), heff_strAppend(v_t_24308, ((V)&g_heff_2eformat_2ekeyTermF_str151)));
    V v_t_24310 = heff_tag_at(v_ru_24it_244_24EMatch, TAG_Cons, 2, (V[]){v_t_24309, NTAG(TAG_Nil)});
    V v_parts_24311 = heff_tag(TAG_Cons, 2, (V[]){v_t_24291, v_t_24310});
    V v_x2_24312 = (g_prelude_2emap_24s693(v_parts_24311));
    V v_t_24315;
    switch (heff_tag_of(v_x2_24312)) {
    case TAG_Nil: {
      v_t_24315 = ((V)&g_heff_2eformat_2ekeyTermF_str152);
      break;
    }
    case TAG_Cons: {
      V v_x_24313 = heff_field(v_x2_24312, 0);
      V v_xs_24314 = heff_field(v_x2_24312, 1);
      heff_take_n(v_x2_24312, 3ULL, 2);
      v_t_24315 = ({ V a_0 = v_x_24313; V a_1 = v_xs_24314; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24314); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24312);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str153), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str154), heff_strAppend(v_t_24315, ((V)&g_heff_2eformat_2ekeyTermF_str155))));
  }
  case TAG_ELetIn: {
    V v_rhs_24316 = heff_field(v_it_244, 0);
    V v_it2_24317 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELetIn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    switch (heff_tag_of(v_it2_24317)) {
    case TAG_At: {
      V v_it21_24318 = heff_field(v_it2_24317, 0);
      V v_ru_24it2_24317_24At = heff_take_reuse_n(v_it2_24317, 1ULL, 2);
      switch (heff_tag_of(v_it21_24318)) {
      case TAG_MkAlt: {
        V v_p_24320 = heff_field(v_it21_24318, 0);
        V v_e_24321 = heff_field(v_it21_24318, 1);
        heff_take_n(v_it21_24318, 3ULL, 2);
        V v_t_24322 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_rhs_24316}));
        V v_t_24323 = (g_heff_2eformat_2epatKey(v_p_24320));
        V v_t_24324 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24321}));
        V v_t_24325 = heff_tag_at(v_ru_24it_244_24ELetIn, TAG_Cons, 2, (V[]){v_t_24324, NTAG(TAG_Nil)});
        V v_parts_24326 = heff_tag_at(v_ru_24it2_24317_24At, TAG_Cons, 2, (V[]){v_t_24322, heff_tag(TAG_Cons, 2, (V[]){v_t_24323, v_t_24325})});
        V v_x2_24327 = (g_prelude_2emap_24s693(v_parts_24326));
        V v_t_24330;
        switch (heff_tag_of(v_x2_24327)) {
        case TAG_Nil: {
          v_t_24330 = ((V)&g_heff_2eformat_2ekeyTermF_str156);
          break;
        }
        case TAG_Cons: {
          V v_x_24328 = heff_field(v_x2_24327, 0);
          V v_xs_24329 = heff_field(v_x2_24327, 1);
          heff_take_n(v_x2_24327, 3ULL, 2);
          v_t_24330 = ({ V a_0 = v_x_24328; V a_1 = v_xs_24329; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24329); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24327);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str157), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str158), heff_strAppend(v_t_24330, ((V)&g_heff_2eformat_2ekeyTermF_str159))));
      }
      default: return heff_nomatch(v_it21_24318);
      }
    }
    default: return heff_nomatch(v_it2_24317);
    }
  }
  case TAG_EDo: {
    V v_stmts_24331 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24362 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyTermF_lam4, 1, 1, (V[]){v_r_240}), v_stmts_24331));
    V v_t_24365;
    switch (heff_tag_of(v_x2_24362)) {
    case TAG_Nil: {
      v_t_24365 = ((V)&g_heff_2eformat_2ekeyTermF_str172);
      break;
    }
    case TAG_Cons: {
      V v_x_24363 = heff_field(v_x2_24362, 0);
      V v_xs_24364 = heff_field(v_x2_24362, 1);
      heff_take_n(v_x2_24362, 3ULL, 2);
      v_t_24365 = ({ V a_0 = v_x_24363; V a_1 = v_xs_24364; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24364); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24362);
    }
    V v_t_24366 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str173), heff_strAppend(v_t_24365, ((V)&g_heff_2eformat_2ekeyTermF_str174)));
    V v_parts_24367 = heff_tag(TAG_Cons, 2, (V[]){v_t_24366, NTAG(TAG_Nil)});
    V v_x2_24368 = (g_prelude_2emap_24s693(v_parts_24367));
    V v_t_24371;
    switch (heff_tag_of(v_x2_24368)) {
    case TAG_Nil: {
      v_t_24371 = ((V)&g_heff_2eformat_2ekeyTermF_str175);
      break;
    }
    case TAG_Cons: {
      V v_x_24369 = heff_field(v_x2_24368, 0);
      V v_xs_24370 = heff_field(v_x2_24368, 1);
      heff_take_n(v_x2_24368, 3ULL, 2);
      v_t_24371 = ({ V a_0 = v_x_24369; V a_1 = v_xs_24370; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24370); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24368);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str176), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str177), heff_strAppend(v_t_24371, ((V)&g_heff_2eformat_2ekeyTermF_str178))));
  }
  case TAG_ELocal: {
    V v_body_24372 = heff_field(v_it_244, 0);
    V v_ds_24373 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELocal = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24374 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_body_24372}));
    V v_x2_24375 = (g_prelude_2emap(heff_get(v_r_240, LBL_decl), v_ds_24373));
    V v_t_24378;
    switch (heff_tag_of(v_x2_24375)) {
    case TAG_Nil: {
      v_t_24378 = ((V)&g_heff_2eformat_2ekeyTermF_str179);
      break;
    }
    case TAG_Cons: {
      V v_x_24376 = heff_field(v_x2_24375, 0);
      V v_xs_24377 = heff_field(v_x2_24375, 1);
      heff_take_n(v_x2_24375, 3ULL, 2);
      v_t_24378 = ({ V a_0 = v_x_24376; V a_1 = v_xs_24377; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24377); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24375);
    }
    V v_t_24379 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str180), heff_strAppend(v_t_24378, ((V)&g_heff_2eformat_2ekeyTermF_str181)));
    V v_t_24380 = heff_tag_at(v_ru_24it_244_24ELocal, TAG_Cons, 2, (V[]){v_t_24379, NTAG(TAG_Nil)});
    V v_parts_24381 = heff_tag(TAG_Cons, 2, (V[]){v_t_24374, v_t_24380});
    V v_x2_24382 = (g_prelude_2emap_24s693(v_parts_24381));
    V v_t_24385;
    switch (heff_tag_of(v_x2_24382)) {
    case TAG_Nil: {
      v_t_24385 = ((V)&g_heff_2eformat_2ekeyTermF_str182);
      break;
    }
    case TAG_Cons: {
      V v_x_24383 = heff_field(v_x2_24382, 0);
      V v_xs_24384 = heff_field(v_x2_24382, 1);
      heff_take_n(v_x2_24382, 3ULL, 2);
      v_t_24385 = ({ V a_0 = v_x_24383; V a_1 = v_xs_24384; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24384); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24382);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str183), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str184), heff_strAppend(v_t_24385, ((V)&g_heff_2eformat_2ekeyTermF_str185))));
  }
  case TAG_EInvalid: {
    V v_why_24386 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_24387 = heff_tag(TAG_Cons, 2, (V[]){v_why_24386, NTAG(TAG_Nil)});
    V v_x2_24388 = (g_prelude_2emap_24s693(v_t_24387));
    V v_t_24391;
    switch (heff_tag_of(v_x2_24388)) {
    case TAG_Nil: {
      v_t_24391 = ((V)&g_heff_2eformat_2ekeyTermF_str186);
      break;
    }
    case TAG_Cons: {
      V v_x_24389 = heff_field(v_x2_24388, 0);
      V v_xs_24390 = heff_field(v_x2_24388, 1);
      heff_take_n(v_x2_24388, 3ULL, 2);
      v_t_24391 = ({ V a_0 = v_x_24389; V a_1 = v_xs_24390; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24390); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24388);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str187), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str188), heff_strAppend(v_t_24391, ((V)&g_heff_2eformat_2ekeyTermF_str189))));
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2ekeyTermF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_f_24183 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24183)) {
  case TAG_At: {
    V v_it1_24184 = heff_field(v_f_24183, 0);
    V v_ru_24f_24183_24At = heff_take_reuse_n(v_f_24183, 1ULL, 2);
    switch (heff_tag_of(v_it1_24184)) {
    case TAG_DeclareField: {
      V v_x_24186 = heff_field(v_it1_24184, 0);
      V v_t_24188 = heff_field(v_it1_24184, 2);
      V v_it14_24189 = heff_field(v_it1_24184, 3);
      heff_take_n(v_it1_24184, 13ULL, 4);
      switch (heff_tag_of(v_it14_24189)) {
      case TAG_Nothing: {
        V v_t_24190 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_24188}));
        V v_t_24191 = heff_tag_at(v_ru_24f_24183_24At, TAG_Cons, 2, (V[]){v_t_24190, NTAG(TAG_Nil)});
        V v_parts_24192 = heff_tag(TAG_Cons, 2, (V[]){v_x_24186, v_t_24191});
        V v_x2_24193 = (g_prelude_2emap_24s693(v_parts_24192));
        V v_t_24196;
        switch (heff_tag_of(v_x2_24193)) {
        case TAG_Nil: {
          v_t_24196 = ((V)&g_heff_2eformat_2ekeyTermF_str93);
          break;
        }
        case TAG_Cons: {
          V v_x_24194 = heff_field(v_x2_24193, 0);
          V v_xs_24195 = heff_field(v_x2_24193, 1);
          heff_take_n(v_x2_24193, 3ULL, 2);
          v_t_24196 = ({ V a_0 = v_x_24194; V a_1 = v_xs_24195; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24195); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24193);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str94), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str95), heff_strAppend(v_t_24196, ((V)&g_heff_2eformat_2ekeyTermF_str96))));
      }
      case TAG_Just: {
        V v_d_24197 = heff_field(v_it14_24189, 0);
        heff_take_n(v_it14_24189, 1ULL, 1);
        V v_t_24198 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_24188}));
        V v_t_24199 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_d_24197}));
        V v_t_24200 = heff_tag_at(v_ru_24f_24183_24At, TAG_Cons, 2, (V[]){v_t_24199, NTAG(TAG_Nil)});
        V v_parts_24201 = heff_tag(TAG_Cons, 2, (V[]){v_x_24186, heff_tag(TAG_Cons, 2, (V[]){v_t_24198, v_t_24200})});
        V v_x2_24202 = (g_prelude_2emap_24s693(v_parts_24201));
        V v_t_24205;
        switch (heff_tag_of(v_x2_24202)) {
        case TAG_Nil: {
          v_t_24205 = ((V)&g_heff_2eformat_2ekeyTermF_str97);
          break;
        }
        case TAG_Cons: {
          V v_x_24203 = heff_field(v_x2_24202, 0);
          V v_xs_24204 = heff_field(v_x2_24202, 1);
          heff_take_n(v_x2_24202, 3ULL, 2);
          v_t_24205 = ({ V a_0 = v_x_24203; V a_1 = v_xs_24204; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24204); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24202);
        }
        return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str98), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str99), heff_strAppend(v_t_24205, ((V)&g_heff_2eformat_2ekeyTermF_str100))));
      }
      default: return heff_nomatch(v_it14_24189);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_24206 = heff_field(v_it1_24184, 0);
      heff_take_n(v_it1_24184, 1ULL, 1);
      V v_t_24207 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24206}));
      V v_parts_24208 = heff_tag_at(v_ru_24f_24183_24At, TAG_Cons, 2, (V[]){v_t_24207, NTAG(TAG_Nil)});
      V v_x2_24209 = (g_prelude_2emap_24s693(v_parts_24208));
      V v_t_24212;
      switch (heff_tag_of(v_x2_24209)) {
      case TAG_Nil: {
        v_t_24212 = ((V)&g_heff_2eformat_2ekeyTermF_str101);
        break;
      }
      case TAG_Cons: {
        V v_x_24210 = heff_field(v_x2_24209, 0);
        V v_xs_24211 = heff_field(v_x2_24209, 1);
        heff_take_n(v_x2_24209, 3ULL, 2);
        v_t_24212 = ({ V a_0 = v_x_24210; V a_1 = v_xs_24211; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24211); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24209);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str102), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str103), heff_strAppend(v_t_24212, ((V)&g_heff_2eformat_2ekeyTermF_str104))));
    }
    default: return heff_nomatch(v_it1_24184);
    }
  }
  default: return heff_nomatch(v_f_24183);
  }
}
V g_heff_2eformat_2ekeyTermF_lam1(V self, V *args) {
  V v_v_24224 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24224)) {
  case TAG_At: {
    V v_it1_24225 = heff_field(v_v_24224, 0);
    V v_ru_24v_24224_24At = heff_take_reuse_n(v_v_24224, 1ULL, 2);
    switch (heff_tag_of(v_it1_24225)) {
    case TAG_TagVariant: {
      V v_t_24227 = heff_field(v_it1_24225, 0);
      V v_args_24229 = heff_field(v_it1_24225, 2);
      heff_take_n(v_it1_24225, 5ULL, 3);
      V v_x2_24230 = (g_prelude_2emap(heff_get(v_r_240, LBL_e), v_args_24229));
      V v_t_24233;
      switch (heff_tag_of(v_x2_24230)) {
      case TAG_Nil: {
        v_t_24233 = ((V)&g_heff_2eformat_2ekeyTermF_str112);
        break;
      }
      case TAG_Cons: {
        V v_x_24231 = heff_field(v_x2_24230, 0);
        V v_xs_24232 = heff_field(v_x2_24230, 1);
        heff_take_n(v_x2_24230, 3ULL, 2);
        v_t_24233 = ({ V a_0 = v_x_24231; V a_1 = v_xs_24232; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24232); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24230);
      }
      V v_t_24234 = heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str113), heff_strAppend(v_t_24233, ((V)&g_heff_2eformat_2ekeyTermF_str114)));
      V v_t_24235 = heff_tag_at(v_ru_24v_24224_24At, TAG_Cons, 2, (V[]){v_t_24234, NTAG(TAG_Nil)});
      V v_parts_24236 = heff_tag(TAG_Cons, 2, (V[]){v_t_24227, v_t_24235});
      V v_x2_24237 = (g_prelude_2emap_24s693(v_parts_24236));
      V v_t_24240;
      switch (heff_tag_of(v_x2_24237)) {
      case TAG_Nil: {
        v_t_24240 = ((V)&g_heff_2eformat_2ekeyTermF_str115);
        break;
      }
      case TAG_Cons: {
        V v_x_24238 = heff_field(v_x2_24237, 0);
        V v_xs_24239 = heff_field(v_x2_24237, 1);
        heff_take_n(v_x2_24237, 3ULL, 2);
        v_t_24240 = ({ V a_0 = v_x_24238; V a_1 = v_xs_24239; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24239); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24237);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str116), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str117), heff_strAppend(v_t_24240, ((V)&g_heff_2eformat_2ekeyTermF_str118))));
    }
    case TAG_BadVariant: {
      V v_e_24241 = heff_field(v_it1_24225, 0);
      heff_take_n(v_it1_24225, 1ULL, 1);
      V v_t_24242 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24241}));
      V v_parts_24243 = heff_tag_at(v_ru_24v_24224_24At, TAG_Cons, 2, (V[]){v_t_24242, NTAG(TAG_Nil)});
      V v_x2_24244 = (g_prelude_2emap_24s693(v_parts_24243));
      V v_t_24247;
      switch (heff_tag_of(v_x2_24244)) {
      case TAG_Nil: {
        v_t_24247 = ((V)&g_heff_2eformat_2ekeyTermF_str119);
        break;
      }
      case TAG_Cons: {
        V v_x_24245 = heff_field(v_x2_24244, 0);
        V v_xs_24246 = heff_field(v_x2_24244, 1);
        heff_take_n(v_x2_24244, 3ULL, 2);
        v_t_24247 = ({ V a_0 = v_x_24245; V a_1 = v_xs_24246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24246); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24244);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str120), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str121), heff_strAppend(v_t_24247, ((V)&g_heff_2eformat_2ekeyTermF_str122))));
    }
    default: return heff_nomatch(v_it1_24225);
    }
  }
  default: return heff_nomatch(v_v_24224);
  }
}
V g_heff_2eformat_2ekeyTermF_lam2(V self, V *args) {
  V v_f_24259 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24259)) {
  case TAG_At: {
    V v_it1_24260 = heff_field(v_f_24259, 0);
    V v_ru_24f_24259_24At = heff_take_reuse_n(v_f_24259, 1ULL, 2);
    switch (heff_tag_of(v_it1_24260)) {
    case TAG_SetField: {
      V v_x_24262 = heff_field(v_it1_24260, 0);
      V v_e_24264 = heff_field(v_it1_24260, 2);
      heff_take_n(v_it1_24260, 5ULL, 3);
      V v_t_24265 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24264}));
      V v_t_24266 = heff_tag_at(v_ru_24f_24259_24At, TAG_Cons, 2, (V[]){v_t_24265, NTAG(TAG_Nil)});
      V v_parts_24267 = heff_tag(TAG_Cons, 2, (V[]){v_x_24262, v_t_24266});
      V v_x2_24268 = (g_prelude_2emap_24s693(v_parts_24267));
      V v_t_24271;
      switch (heff_tag_of(v_x2_24268)) {
      case TAG_Nil: {
        v_t_24271 = ((V)&g_heff_2eformat_2ekeyTermF_str130);
        break;
      }
      case TAG_Cons: {
        V v_x_24269 = heff_field(v_x2_24268, 0);
        V v_xs_24270 = heff_field(v_x2_24268, 1);
        heff_take_n(v_x2_24268, 3ULL, 2);
        v_t_24271 = ({ V a_0 = v_x_24269; V a_1 = v_xs_24270; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24270); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24268);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str131), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str132), heff_strAppend(v_t_24271, ((V)&g_heff_2eformat_2ekeyTermF_str133))));
    }
    case TAG_BadFieldSet: {
      V v_e_24272 = heff_field(v_it1_24260, 0);
      heff_take_n(v_it1_24260, 1ULL, 1);
      V v_t_24273 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24272}));
      V v_parts_24274 = heff_tag_at(v_ru_24f_24259_24At, TAG_Cons, 2, (V[]){v_t_24273, NTAG(TAG_Nil)});
      V v_x2_24275 = (g_prelude_2emap_24s693(v_parts_24274));
      V v_t_24278;
      switch (heff_tag_of(v_x2_24275)) {
      case TAG_Nil: {
        v_t_24278 = ((V)&g_heff_2eformat_2ekeyTermF_str134);
        break;
      }
      case TAG_Cons: {
        V v_x_24276 = heff_field(v_x2_24275, 0);
        V v_xs_24277 = heff_field(v_x2_24275, 1);
        heff_take_n(v_x2_24275, 3ULL, 2);
        v_t_24278 = ({ V a_0 = v_x_24276; V a_1 = v_xs_24277; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24277); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24275);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str135), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str136), heff_strAppend(v_t_24278, ((V)&g_heff_2eformat_2ekeyTermF_str137))));
    }
    default: return heff_nomatch(v_it1_24260);
    }
  }
  default: return heff_nomatch(v_f_24259);
  }
}
V g_heff_2eformat_2ekeyTermF_lam3(V self, V *args) {
  V v_a_24292 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24292)) {
  case TAG_At: {
    V v_it1_24293 = heff_field(v_a_24292, 0);
    V v_ru_24a_24292_24At = heff_take_reuse_n(v_a_24292, 1ULL, 2);
    switch (heff_tag_of(v_it1_24293)) {
    case TAG_MkAlt: {
      V v_p_24295 = heff_field(v_it1_24293, 0);
      V v_e_24296 = heff_field(v_it1_24293, 1);
      V v_ru_24it1_24293_24MkAlt = heff_take_reuse_n(v_it1_24293, 3ULL, 2);
      V v_t_24297 = (g_heff_2eformat_2epatKey(v_p_24295));
      V v_t_24298 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24296}));
      V v_t_24299 = heff_tag_at(v_ru_24a_24292_24At, TAG_Cons, 2, (V[]){v_t_24298, NTAG(TAG_Nil)});
      V v_parts_24300 = heff_tag_at(v_ru_24it1_24293_24MkAlt, TAG_Cons, 2, (V[]){v_t_24297, v_t_24299});
      V v_x2_24301 = (g_prelude_2emap_24s693(v_parts_24300));
      V v_t_24304;
      switch (heff_tag_of(v_x2_24301)) {
      case TAG_Nil: {
        v_t_24304 = ((V)&g_heff_2eformat_2ekeyTermF_str145);
        break;
      }
      case TAG_Cons: {
        V v_x_24302 = heff_field(v_x2_24301, 0);
        V v_xs_24303 = heff_field(v_x2_24301, 1);
        heff_take_n(v_x2_24301, 3ULL, 2);
        v_t_24304 = ({ V a_0 = v_x_24302; V a_1 = v_xs_24303; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24303); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24301);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str146), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str147), heff_strAppend(v_t_24304, ((V)&g_heff_2eformat_2ekeyTermF_str148))));
    }
    default: return heff_nomatch(v_it1_24293);
    }
  }
  default: return heff_nomatch(v_a_24292);
  }
}
V g_heff_2eformat_2ekeyTermF_lam4(V self, V *args) {
  V v_m_24332 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_24332)) {
  case TAG_At: {
    V v_it1_24333 = heff_field(v_m_24332, 0);
    V v_ru_24m_24332_24At = heff_take_reuse_n(v_m_24332, 1ULL, 2);
    switch (heff_tag_of(v_it1_24333)) {
    case TAG_StmtBind: {
      V v_x_24335 = heff_field(v_it1_24333, 0);
      V v_e_24337 = heff_field(v_it1_24333, 2);
      heff_take_n(v_it1_24333, 5ULL, 3);
      V v_t_24338 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24337}));
      V v_t_24339 = heff_tag_at(v_ru_24m_24332_24At, TAG_Cons, 2, (V[]){v_t_24338, NTAG(TAG_Nil)});
      V v_parts_24340 = heff_tag(TAG_Cons, 2, (V[]){v_x_24335, v_t_24339});
      V v_x2_24341 = (g_prelude_2emap_24s693(v_parts_24340));
      V v_t_24344;
      switch (heff_tag_of(v_x2_24341)) {
      case TAG_Nil: {
        v_t_24344 = ((V)&g_heff_2eformat_2ekeyTermF_str160);
        break;
      }
      case TAG_Cons: {
        V v_x_24342 = heff_field(v_x2_24341, 0);
        V v_xs_24343 = heff_field(v_x2_24341, 1);
        heff_take_n(v_x2_24341, 3ULL, 2);
        v_t_24344 = ({ V a_0 = v_x_24342; V a_1 = v_xs_24343; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24343); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24341);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str161), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str162), heff_strAppend(v_t_24344, ((V)&g_heff_2eformat_2ekeyTermF_str163))));
    }
    case TAG_StmtLet: {
      V v_p_24345 = heff_field(v_it1_24333, 0);
      V v_e_24346 = heff_field(v_it1_24333, 1);
      V v_ru_24it1_24333_24StmtLet = heff_take_reuse_n(v_it1_24333, 3ULL, 2);
      V v_t_24347 = (g_heff_2eformat_2epatKey(v_p_24345));
      V v_t_24348 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24346}));
      V v_t_24349 = heff_tag_at(v_ru_24m_24332_24At, TAG_Cons, 2, (V[]){v_t_24348, NTAG(TAG_Nil)});
      V v_parts_24350 = heff_tag_at(v_ru_24it1_24333_24StmtLet, TAG_Cons, 2, (V[]){v_t_24347, v_t_24349});
      V v_x2_24351 = (g_prelude_2emap_24s693(v_parts_24350));
      V v_t_24354;
      switch (heff_tag_of(v_x2_24351)) {
      case TAG_Nil: {
        v_t_24354 = ((V)&g_heff_2eformat_2ekeyTermF_str164);
        break;
      }
      case TAG_Cons: {
        V v_x_24352 = heff_field(v_x2_24351, 0);
        V v_xs_24353 = heff_field(v_x2_24351, 1);
        heff_take_n(v_x2_24351, 3ULL, 2);
        v_t_24354 = ({ V a_0 = v_x_24352; V a_1 = v_xs_24353; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24353); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24351);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str165), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str166), heff_strAppend(v_t_24354, ((V)&g_heff_2eformat_2ekeyTermF_str167))));
    }
    case TAG_StmtExpr: {
      V v_e_24355 = heff_field(v_it1_24333, 0);
      heff_take_n(v_it1_24333, 1ULL, 1);
      V v_t_24356 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_24355}));
      V v_parts_24357 = heff_tag_at(v_ru_24m_24332_24At, TAG_Cons, 2, (V[]){v_t_24356, NTAG(TAG_Nil)});
      V v_x2_24358 = (g_prelude_2emap_24s693(v_parts_24357));
      V v_t_24361;
      switch (heff_tag_of(v_x2_24358)) {
      case TAG_Nil: {
        v_t_24361 = ((V)&g_heff_2eformat_2ekeyTermF_str168);
        break;
      }
      case TAG_Cons: {
        V v_x_24359 = heff_field(v_x2_24358, 0);
        V v_xs_24360 = heff_field(v_x2_24358, 1);
        heff_take_n(v_x2_24358, 3ULL, 2);
        v_t_24361 = ({ V a_0 = v_x_24359; V a_1 = v_xs_24360; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24360); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24358);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str169), heff_strAppend(((V)&g_heff_2eformat_2ekeyTermF_str170), heff_strAppend(v_t_24361, ((V)&g_heff_2eformat_2ekeyTermF_str171))));
    }
    default: return heff_nomatch(v_it1_24333);
    }
  }
  default: return heff_nomatch(v_m_24332);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eformat_2ekeyDeclF_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {101, 113, 117, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eformat_2ekeyDeclF_str12 = {{0x80000000u, K_STR, 0}, 9, 9, {101, 113, 117, 97, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyDeclF_str19 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 102, 105, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eformat_2ekeyDeclF_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eformat_2ekeyDeclF_str30 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 114, 105, 109, 105, 116, 105, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eformat_2ekeyDeclF_str34 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str36 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eformat_2ekeyDeclF_str38 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eformat_2ekeyDeclF_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eformat_2ekeyDeclF_lam0(V self, V *args);
Clo g_heff_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2eformat_2ekeyDeclF(V v_r_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_ty_247}));
    V v_x2_2429 = (g_prelude_2emap(heff_clo(g_heff_2eformat_2ekeyDeclF_lam0, 1, 1, (V[]){v_r_240}), v_eqs_248));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2eformat_2ekeyDeclF_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = v_x_2430; V a_1 = v_xs_2431; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str8), heff_strAppend(v_t_2432, ((V)&g_heff_2eformat_2ekeyDeclF_str9)));
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    V v_parts_2435 = heff_tag(TAG_Cons, 2, (V[]){v_f_245, heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2434})});
    V v_x2_2436 = (g_prelude_2emap_24s693(v_parts_2435));
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2eformat_2ekeyDeclF_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = v_x_2437; V a_1 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str11), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str12), heff_strAppend(v_t_2439, ((V)&g_heff_2eformat_2ekeyDeclF_str13))));
  }
  case TAG_DeclDefine: {
    V v_x_2440 = heff_field(v_t_244, 0);
    V v_ps_2442 = heff_field(v_t_244, 2);
    V v_u_2443 = heff_field(v_t_244, 3);
    V v_body_2444 = heff_field(v_t_244, 4);
    heff_take_n(v_t_244, 29ULL, 5);
    V v_t_2445 = heff_tr(heff_apply(((V)&g_heff_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2446 = (g_prelude_2emap(v_t_2445, v_ps_2442));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2eformat_2ekeyDeclF_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = v_x_2447; V a_1 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    V v_t_2450 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str15), heff_strAppend(v_t_2449, ((V)&g_heff_2eformat_2ekeyDeclF_str16)));
    V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_u_2443}));
    V v_t_2452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2444}));
    V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2450, heff_tag(TAG_Cons, 2, (V[]){v_t_2451, v_t_2453})});
    V v_parts_2455 = heff_tag(TAG_Cons, 2, (V[]){v_x_2440, v_t_2454});
    V v_x2_2456 = (g_prelude_2emap_24s693(v_parts_2455));
    V v_t_2459;
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_Nil: {
      v_t_2459 = ((V)&g_heff_2eformat_2ekeyDeclF_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_xs_2458 = heff_field(v_x2_2456, 1);
      heff_take_n(v_x2_2456, 3ULL, 2);
      v_t_2459 = ({ V a_0 = v_x_2457; V a_1 = v_xs_2458; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2458); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2456);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str18), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str19), heff_strAppend(v_t_2459, ((V)&g_heff_2eformat_2ekeyDeclF_str20))));
  }
  case TAG_DeclTheory: {
    V v_x_2460 = heff_field(v_t_244, 0);
    V v_ps_2462 = heff_field(v_t_244, 2);
    V v_body_2463 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2464 = heff_tr(heff_apply(((V)&g_heff_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2465 = (g_prelude_2emap(v_t_2464, v_ps_2462));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2eformat_2ekeyDeclF_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = v_x_2466; V a_1 = v_xs_2467; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str22), heff_strAppend(v_t_2468, ((V)&g_heff_2eformat_2ekeyDeclF_str23)));
    V v_t_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2463}));
    V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_parts_2472 = heff_tag(TAG_Cons, 2, (V[]){v_x_2460, heff_tag(TAG_Cons, 2, (V[]){v_t_2469, v_t_2471})});
    V v_x2_2473 = (g_prelude_2emap_24s693(v_parts_2472));
    V v_t_2476;
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2eformat_2ekeyDeclF_str24);
      break;
    }
    case TAG_Cons: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_xs_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      v_t_2476 = ({ V a_0 = v_x_2474; V a_1 = v_xs_2475; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2475); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2473);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str25), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str26), heff_strAppend(v_t_2476, ((V)&g_heff_2eformat_2ekeyDeclF_str27))));
  }
  case TAG_DeclPrimitive: {
    V v_x_2477 = heff_field(v_t_244, 0);
    V v_t_2479 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2479}));
    V v_t_2481 = heff_tag(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
    V v_parts_2482 = heff_tag(TAG_Cons, 2, (V[]){v_x_2477, v_t_2481});
    V v_x2_2483 = (g_prelude_2emap_24s693(v_parts_2482));
    V v_t_2486;
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2eformat_2ekeyDeclF_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_xs_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      v_t_2486 = ({ V a_0 = v_x_2484; V a_1 = v_xs_2485; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2485); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2483);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str29), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str30), heff_strAppend(v_t_2486, ((V)&g_heff_2eformat_2ekeyDeclF_str31))));
  }
  case TAG_DeclTest: {
    V v_x_2487 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24DeclTest = heff_take_reuse_n(v_t_244, 1ULL, 2);
    heff_drop(v_r_240);
    V v_t_2489 = heff_tag_at(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){v_x_2487, NTAG(TAG_Nil)});
    V v_x2_2490 = (g_prelude_2emap_24s693(v_t_2489));
    V v_t_2493;
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_Nil: {
      v_t_2493 = ((V)&g_heff_2eformat_2ekeyDeclF_str32);
      break;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_xs_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      v_t_2493 = ({ V a_0 = v_x_2491; V a_1 = v_xs_2492; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2492); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2490);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str33), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str34), heff_strAppend(v_t_2493, ((V)&g_heff_2eformat_2ekeyDeclF_str35))));
  }
  case TAG_DeclWatch: {
    V v_e_2494 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_2495 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2494}));
    V v_parts_2496 = heff_tag(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    V v_x2_2497 = (g_prelude_2emap_24s693(v_parts_2496));
    V v_t_24100;
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2eformat_2ekeyDeclF_str36);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_xs_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      v_t_24100 = ({ V a_0 = v_x_2498; V a_1 = v_xs_2499; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2499); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2497);
    }
    return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str37), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str38), heff_strAppend(v_t_24100, ((V)&g_heff_2eformat_2ekeyDeclF_str39))));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2ekeyDeclF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eformat_2ekeyDeclF_lam0(V self, V *args) {
  V v_eq_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_eq_2410)) {
  case TAG_At: {
    V v_it1_2411 = heff_field(v_eq_2410, 0);
    V v_ru_24eq_2410_24At = heff_take_reuse_n(v_eq_2410, 1ULL, 2);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkEquation: {
      V v_g_2413 = heff_field(v_it1_2411, 0);
      V v_ps_2415 = heff_field(v_it1_2411, 2);
      V v_rhs_2416 = heff_field(v_it1_2411, 3);
      heff_take_n(v_it1_2411, 13ULL, 4);
      V v_x2_2417 = (g_prelude_2emap_24s695(v_ps_2415));
      V v_t_2420;
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_xs_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = v_x_2418; V a_1 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      V v_t_2421 = heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str1), heff_strAppend(v_t_2420, ((V)&g_heff_2eformat_2ekeyDeclF_str2)));
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_rhs_2416}));
      V v_t_2423 = heff_tag_at(v_ru_24eq_2410_24At, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_parts_2424 = heff_tag(TAG_Cons, 2, (V[]){v_g_2413, heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
      V v_x2_2425 = (g_prelude_2emap_24s693(v_parts_2424));
      V v_t_2428;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2eformat_2ekeyDeclF_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_xs_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2427); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      return heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str4), heff_strAppend(((V)&g_heff_2eformat_2ekeyDeclF_str5), heff_strAppend(v_t_2428, ((V)&g_heff_2eformat_2ekeyDeclF_str6))));
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_eq_2410);
  }
}
V g_heff_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2eformat_2ekeys_val;
static int g_heff_2eformat_2ekeys_st;
static V g_heff_2eformat_2ekeys_init(void) {
  return heff_rec(2, shape_77_54, (V[]){((V)&g_heff_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2eformat_2ekeys_get(void) {
  if (g_heff_2eformat_2ekeys_st == 2) return g_heff_2eformat_2ekeys_val;
  if (g_heff_2eformat_2ekeys_st == 1) heff_fail("defined by itself");
  g_heff_2eformat_2ekeys_st = 1;
  g_heff_2eformat_2ekeys_val = heff_tr(g_heff_2eformat_2ekeys_init());
  g_heff_2eformat_2ekeys_st = 2;
  return g_heff_2eformat_2ekeys_val;
}
V g_heff_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eformat_2ekeys_get()); V a_1 = v_n_240; V r_ = (g_heff_2eformat_2ekeyTermF(a_0, a_1)); heff_drop(v_n_240); r_; });
}
V g_heff_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eformat_2ekeys_get()); V a_1 = v_d_241; V r_ = (g_heff_2eformat_2ekeyDeclF(a_0, a_1)); heff_drop(v_d_241); r_; });
}
Clo g_heff_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = heff_strEq(heff_dup(v_a_244), heff_dup(v_b_246));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eformat_2estrsEq(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eformat_2esameMeaning_str0 = {{0x80000000u, K_STR, 0}, 35, 35, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 116, 104, 101, 32, 105, 109, 112, 111, 114, 116, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2eformat_2esameMeaning_str1 = {{0x80000000u, K_STR, 0}, 68, 68, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 102, 105, 108, 101, 32, 109, 101, 97, 110, 115, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[76]; } g_heff_2eformat_2esameMeaning_str2 = {{0x80000000u, K_STR, 0}, 76, 76, {102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 108, 111, 115, 101, 32, 111, 114, 32, 109, 111, 118, 101, 32, 97, 32, 99, 111, 109, 109, 101, 110, 116, 32, 97, 99, 114, 111, 115, 115, 32, 99, 111, 100, 101, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41}};
Clo g_heff_2eformat_2esameMeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2esameMeaning_entry, 4, 0};

V g_heff_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = ({ V b_0 = heff_get(heff_dup(v_a_242), LBL_imports); V b_1 = heff_get(heff_dup(v_b_243), LBL_imports); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str0)});
  }
  case TAG_False: {
    V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_a_242), LBL_decls); V b_1 = heff_get(heff_dup(v_b_243), LBL_decls); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_x1_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x1_247 = ({ V b_0 = heff_get(v_a_242, LBL_diags); V b_1 = heff_get(v_b_243, LBL_diags); V r_ = (g_heff_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      break;
    }
    case TAG_False: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str1)});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2410 = heff_get(v_t_249, LBL_text);
      V v_t_2411 = heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2412 = (g_heff_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s701(heff_get(v_t_2412, LBL_comments)));
      V v_t_2414 = (g_heff_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2415 = heff_get(v_t_2414, LBL_text);
      V v_t_2416 = heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2417 = (g_heff_2efmt_2elex_2elexGo(v_src_2415, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2418 = (g_prelude_2emap_24s701(heff_get(v_t_2417, LBL_comments)));
      V v_x1_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_True: {
        return heff_tag(TAG_Right, 1, (V[]){v_out_241});
      }
      case TAG_False: {
        heff_drop(v_out_241);
        return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eformat_2esameMeaning_str2)});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eformat_2esameMeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2esameMeaning(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eformat_2echeck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2echeck_entry, 2, 0};

V g_heff_2eformat_2echeck(V v_src_240, V v_out_241) {
top: ;
  V v_h_242 = (g_heff_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_r_243 = (g_heff_2esurface_2ereadProgramWith_24s696(heff_get(heff_dup(v_h_242), LBL_text)));
  V v_t_244 = (g_prelude_2emap_24s426(heff_get(v_h_242, LBL_imports)));
  V v_t_245 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eformat_2ekeys_get()), LBL_decl), heff_get(heff_dup(v_r_243), LBL_decls)));
  V v_t_246 = (g_prelude_2emap_24s700(heff_get(v_r_243, LBL_diags)));
  V v_h_247 = (g_heff_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_r_248 = (g_heff_2esurface_2ereadProgramWith_24s696(heff_get(heff_dup(v_h_247), LBL_text)));
  V v_t_249 = (g_prelude_2emap_24s426(heff_get(v_h_247, LBL_imports)));
  V v_t_2410 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eformat_2ekeys_get()), LBL_decl), heff_get(heff_dup(v_r_248), LBL_decls)));
  V v_t_2411 = (g_prelude_2emap_24s700(heff_get(v_r_248, LBL_diags)));
  return (g_heff_2eformat_2esameMeaning(v_src_240, v_out_241, heff_rec(3, shape_136_55_63, (V[]){v_t_244, v_t_245, v_t_246}), heff_rec(3, shape_136_55_63, (V[]){v_t_249, v_t_2410, v_t_2411})));
}
V g_heff_2eformat_2echeck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2echeck(a[0], a[1]);
}
Clo g_heff_2eformat_2eformat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eformat_2eformat_entry, 1, 0};

V g_heff_2eformat_2eformat(V v_src_240) {
top: ;
  V v_t_241 = (g_heff_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_src_242 = heff_get(v_t_241, LBL_text);
  V v_t_243 = heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get(v_t_244, LBL_tokens));
  V v_t_246 = (g_heff_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esurface_2efixityFrom_24s698(v_t_246));
  V v_f_248 = heff_get(v_t_247, LBL_fixities);
  V v_t_249 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_f_248, heff_dup(v_src_240)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Left = heff_take_reuse_n(v_t_249, 1ULL, 1);
    heff_drop(v_src_240);
    return heff_tag_at(v_ru_24t_249_24Left, TAG_Left, 1, (V[]){v_why_2410});
  }
  case TAG_Right: {
    V v_out_2411 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    return (g_heff_2eformat_2echeck(v_src_240, v_out_2411));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2eformat_2eformat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eformat_2eformat(a[0]);
}