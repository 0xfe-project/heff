// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_malg 9839318
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_resource_2eheldBy_24s1025672955x994242974(V, V, V, V, V, V);
V g_resource_2eheldBy_24s1025672955x994242974_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s1025672955x994242974_clo;
V g_resource_2eheldBy_24s1091030979x2054910815(V, V, V, V, V);
V g_resource_2eheldBy_24s1091030979x2054910815_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s1091030979x2054910815_clo;
V g_resource_2eheldBy_24s650049234x1642226888(V, V, V, V, V);
V g_resource_2eheldBy_24s650049234x1642226888_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s650049234x1642226888_clo;
V g_resource_2eheldBy_24s650049234x1642226888_lam1(V self, V *args); static Clo g_resource_2eheldBy_24s650049234x1642226888_lam1_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s650049234x1642226888_lam1, 1, 0};
V g_resource_2eheldBy_24s650049234x1642226888_lam2(V self, V *args);
V g_resource_2eheldBy_24s650049234x1642226888_lam0(V self, V *args);
Clo g_resource_2eheldBy_24s650049234x1642226888_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s650049234x1642226888_entry, 5, 0};

V g_resource_2eheldBy_24s650049234x1642226888(V v_ex_240, V v_body_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_body_241);
    V v_t_246 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_245})}));
    return (g_co_2eop_24s847889387x1388281137(v_t_246, v_z_243, v_z_244));
  }
  case TAG_Right: {
    V v_x_247 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_c_248 = heff_tr(heff_call(v_body_241, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_247)})}));
    return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_resource_2eheldBy_24s650049234x1642226888_lam0, 1, 4, (V[]){v_x_247, v_z_243, v_ex_240, v_z_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_resource_2eheldBy_24s650049234x1642226888_entry(V self, V *a) {
  (void)self;
  return g_resource_2eheldBy_24s650049234x1642226888(a[0], a[1], a[2], a[3], a[4]);
}
V g_resource_2eheldBy_24s650049234x1642226888_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  return v_a_2410;
}
V g_resource_2eheldBy_24s650049234x1642226888_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_drop(v_x_249);
    V v_t_2421 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2420})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2419_24Left, v_t_2421, v_z_243, v_z_244));
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop(v_ex_240);
    heff_drop_rec(v_z_243, 3);
    V f_ = v_z_244;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_resource_2eheldBy_24s650049234x1642226888_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_247, ((V)&g_resource_2eheldBy_24s650049234x1642226888_lam1_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_z_243, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_resource_2eheldBy_24s650049234x1642226888_lam2, 1, 4, (V[]){v_ex_240, v_z_243, v_z_244, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_resource_2eheldBy_24s1025672955x994242974_lam1(V self, V *args);
V g_resource_2eheldBy_24s1025672955x994242974_lam0(V self, V *args);
Clo g_resource_2eheldBy_24s1025672955x994242974_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1025672955x994242974_entry, 6, 0};

V g_resource_2eheldBy_24s1025672955x994242974(V v_ex_240, V v_release_241, V v_body_242, V v_x3_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop(v_release_241);
    heff_drop(v_body_242);
    V v_t_247 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_246})}));
    return (g_co_2eop_24s847889387x1388281137(v_t_247, v_z_244, v_z_245));
  }
  case TAG_Right: {
    V v_x_248 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    V v_c_249 = heff_tr(heff_call(v_body_242, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_248)})}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_resource_2eheldBy_24s1025672955x994242974_lam0, 1, 5, (V[]){v_release_241, v_x_248, v_z_244, v_ex_240, v_z_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_resource_2eheldBy_24s1025672955x994242974_entry(V self, V *a) {
  (void)self;
  return g_resource_2eheldBy_24s1025672955x994242974(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_resource_2eheldBy_24s1025672955x994242974_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_drop(v_x_2410);
    V v_t_2414 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2412_24Left, v_t_2414, v_z_244, v_z_245));
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop(v_ex_240);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = v_x_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_resource_2eheldBy_24s1025672955x994242974_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_release_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = heff_tr(heff_call(v_release_241, 1, (V[]){v_x_248}));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_resource_2eheldBy_24s1025672955x994242974_lam1, 1, 4, (V[]){v_ex_240, v_z_244, v_z_245, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_resource_2eheldBy_24s1091030979x2054910815_lam1(V self, V *args);
V g_resource_2eheldBy_24s1091030979x2054910815_lam0(V self, V *args);
Clo g_resource_2eheldBy_24s1091030979x2054910815_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1091030979x2054910815_entry, 5, 0};

V g_resource_2eheldBy_24s1091030979x2054910815(V v_release_240, V v_body_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Left = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop(v_release_240);
    heff_drop(v_body_241);
    V v_t_246 = heff_tag_at_n(v_ru_24x3_242_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_245})});
    V v_t_247 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_246}));
    return heff_tail(heff_get_n(v_z_243, 1, 3), 2, (V[]){v_t_247, v_z_244});
  }
  case TAG_Right: {
    V v_x_248 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_c_249 = heff_tr(heff_call(v_body_241, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_248)})}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_resource_2eheldBy_24s1091030979x2054910815_lam0, 1, 4, (V[]){v_release_240, v_x_248, v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_resource_2eheldBy_24s1091030979x2054910815_entry(V self, V *a) {
  (void)self;
  return g_resource_2eheldBy_24s1091030979x2054910815(a[0], a[1], a[2], a[3], a[4]);
}
V g_resource_2eheldBy_24s1091030979x2054910815_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_drop(v_x_2410);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_z_243, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_z_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop_rec(v_z_243, 3);
    V f_ = v_z_244;
    args[0] = v_x_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_resource_2eheldBy_24s1091030979x2054910815_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_release_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2411 = heff_tr(heff_call(v_release_240, 1, (V[]){v_x_248}));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_resource_2eheldBy_24s1091030979x2054910815_lam1, 1, 3, (V[]){v_z_243, v_z_244, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}