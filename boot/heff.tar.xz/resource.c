// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Asked 63168
#define TAG_Failed 62128
#define TAG_Left 13886
#define TAG_MkOwned 19359
#define TAG_MkWith 3751
#define TAG_Own 27154
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Throw 56084
#define TAG_Wait 10206
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_path 9928940
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_resource_2eheldBy_24s1065400090x105490439(V, V, V, V, V, V);
V g_resource_2eheldBy_24s1065400090x105490439_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s1065400090x105490439_clo;
V g_resource_2eheldBy_24s1373346961x893610866(V, V, V, V, V);
V g_resource_2eheldBy_24s1373346961x893610866_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s1373346961x893610866_clo;
HEFF_LIT(g_resource_2eheldBy_24s1373346961x893610866_str0, 2, ": ");
HEFF_LIT(g_resource_2eheldBy_24s1373346961x893610866_str1, 2, ": ");
V g_resource_2eheldBy_24s1373346961x893610866_lam0(V self, V *args);
V g_resource_2eheldBy_24s1373346961x893610866_lam2(V self, V *args); static Clo g_resource_2eheldBy_24s1373346961x893610866_lam2_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1373346961x893610866_lam2, 1, 0};
V g_resource_2eheldBy_24s1373346961x893610866_lam4(V self, V *args); static Clo g_resource_2eheldBy_24s1373346961x893610866_lam4_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1373346961x893610866_lam4, 1, 0};
V g_resource_2eheldBy_24s1373346961x893610866_lam6(V self, V *args);
V g_resource_2eheldBy_24s1373346961x893610866_lam5(V self, V *args);
V g_resource_2eheldBy_24s1373346961x893610866_lam3(V self, V *args);
V g_resource_2eheldBy_24s1373346961x893610866_lam1(V self, V *args);
Clo g_resource_2eheldBy_24s1373346961x893610866_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1373346961x893610866_entry, 5, 0};

V g_resource_2eheldBy_24s1373346961x893610866(V v_ex_240, V v_cu_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_cu_241);
    V v_t_246 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_245})}));
    return (g_co_2eop_24s297957795x1045074450(v_t_246, v_z_243, v_z_244));
  }
  case TAG_Right: {
    V v_x_247 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_ex_240);
    V v_t_249 = heff_tag_n(TAG_Own, 2, (V[]){heff_clo_n(g_resource_2eheldBy_24s1373346961x893610866_lam0, 1, 1, (V[]){heff_dup(v_x_247)}), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_cu_241), 1, (V[]){heff_tag_n(TAG_Asked, 1, (V[]){v_t_249})}));
    return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_z_243), heff_clo_n(g_resource_2eheldBy_24s1373346961x893610866_lam1, 1, 4, (V[]){v_x_247, v_z_243, v_cu_241, v_z_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_resource_2eheldBy_24s1373346961x893610866_entry(V self, V *a) {
  (void)self;
  return g_resource_2eheldBy_24s1373346961x893610866(a[0], a[1], a[2], a[3], a[4]);
}
V g_resource_2eheldBy_24s1373346961x893610866_lam0(V self, V *args) {
  V v_use_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_248;
  args[0] = heff_tag_n(TAG_MkOwned, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_resource_2eheldBy_24s1373346961x893610866_lam2(V self, V *args) {
  V v_a_2412 = args[0];
  return v_a_2412;
}
V g_resource_2eheldBy_24s1373346961x893610866_lam4(V self, V *args) {
  V v_a_2420 = args[0];
  return v_a_2420;
}
V g_resource_2eheldBy_24s1373346961x893610866_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_drop(v_x_2436);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_resource_2eheldBy_24s1373346961x893610866_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_cu_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_err_2428 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    V v_path_2429 = heff_take_field(v_err_2428, 3);
    V v_name_2430 = heff_take_field(v_err_2428, 1);
    V v_message_2431 = heff_get_n(v_err_2428, 2, 4);
    V v_t_2432 = heff_strAppend(heff_strAppend(v_path_2429, ((V)&g_resource_2eheldBy_24s1373346961x893610866_str0)), v_name_2430);
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_resource_2eheldBy_24s1373346961x893610866_str1)), v_message_2431);
    V v_t_2434 = heff_tag_n(TAG_Failed, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    heff_clo_take(self, 4);
    V v_t_2435 = heff_tr(heff_call(v_cu_241, 1, (V[]){heff_tag_n(TAG_Asked, 1, (V[]){v_t_2434})}));
    return (g_co_2eop_24s535099379x685970669(v_t_2435, v_z_243, heff_clo_n(g_resource_2eheldBy_24s1373346961x893610866_lam6, 1, 2, (V[]){v_z_244, v_x_2419})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_cu_241);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = v_x_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_resource_2eheldBy_24s1373346961x893610866_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cu_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_247, ((V)&g_resource_2eheldBy_24s1373346961x893610866_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s297957795x1045074450(v_t_2426, heff_dup(v_z_243), heff_clo_n(g_resource_2eheldBy_24s1373346961x893610866_lam5, 1, 4, (V[]){v_cu_241, v_z_243, v_z_244, v_x_2419})));
}
V g_resource_2eheldBy_24s1373346961x893610866_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cu_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_drop(v_x_2411);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){heff_dup(v_x_247), ((V)&g_resource_2eheldBy_24s1373346961x893610866_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s297957795x1045074450(v_t_2418, heff_dup(v_z_243), heff_clo_n(g_resource_2eheldBy_24s1373346961x893610866_lam3, 1, 4, (V[]){v_x_247, v_z_243, v_cu_241, v_z_244})));
}
HEFF_LIT(g_resource_2eheldBy_24s1065400090x105490439_str0, 2, ": ");
HEFF_LIT(g_resource_2eheldBy_24s1065400090x105490439_str1, 2, ": ");
V g_resource_2eheldBy_24s1065400090x105490439_lam0(V self, V *args);
V g_resource_2eheldBy_24s1065400090x105490439_lam3(V self, V *args); static Clo g_resource_2eheldBy_24s1065400090x105490439_lam3_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1065400090x105490439_lam3, 1, 0};
V g_resource_2eheldBy_24s1065400090x105490439_lam5(V self, V *args);
V g_resource_2eheldBy_24s1065400090x105490439_lam4(V self, V *args);
V g_resource_2eheldBy_24s1065400090x105490439_lam2(V self, V *args);
V g_resource_2eheldBy_24s1065400090x105490439_lam1(V self, V *args);
Clo g_resource_2eheldBy_24s1065400090x105490439_clo = {{0x80000000u, K_CLO, 0}, g_resource_2eheldBy_24s1065400090x105490439_entry, 6, 0};

V g_resource_2eheldBy_24s1065400090x105490439(V v_ex_240, V v_cu_241, V v_body_242, V v_x3_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop(v_cu_241);
    heff_drop(v_body_242);
    V v_t_247 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_246})}));
    return (g_co_2eop_24s297957795x1045074450(v_t_247, v_z_244, v_z_245));
  }
  case TAG_Right: {
    V v_x_248 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop(v_ex_240);
    V v_t_2410 = heff_tag_n(TAG_Own, 2, (V[]){heff_clo_n(g_resource_2eheldBy_24s1065400090x105490439_lam0, 1, 1, (V[]){heff_dup(v_x_248)}), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_cu_241), 1, (V[]){heff_tag_n(TAG_Asked, 1, (V[]){v_t_2410})}));
    return (g_co_2eop_24s535099379x685970669(v_t_2411, heff_dup(v_z_244), heff_clo_n(g_resource_2eheldBy_24s1065400090x105490439_lam1, 1, 5, (V[]){v_body_242, v_x_248, v_z_244, v_cu_241, v_z_245})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_resource_2eheldBy_24s1065400090x105490439_entry(V self, V *a) {
  (void)self;
  return g_resource_2eheldBy_24s1065400090x105490439(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_resource_2eheldBy_24s1065400090x105490439_lam0(V self, V *args) {
  V v_use_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_249;
  args[0] = heff_tag_n(TAG_MkOwned, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_resource_2eheldBy_24s1065400090x105490439_lam3(V self, V *args) {
  V v_a_2415 = args[0];
  return v_a_2415;
}
V g_resource_2eheldBy_24s1065400090x105490439_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_drop(v_x_2431);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_resource_2eheldBy_24s1065400090x105490439_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_cu_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_path_2424 = heff_take_field(v_err_2423, 3);
    V v_name_2425 = heff_take_field(v_err_2423, 1);
    V v_message_2426 = heff_get_n(v_err_2423, 2, 4);
    V v_t_2427 = heff_strAppend(heff_strAppend(v_path_2424, ((V)&g_resource_2eheldBy_24s1065400090x105490439_str0)), v_name_2425);
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_resource_2eheldBy_24s1065400090x105490439_str1)), v_message_2426);
    V v_t_2429 = heff_tag_n(TAG_Failed, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    heff_clo_take(self, 4);
    V v_t_2430 = heff_tr(heff_call(v_cu_241, 1, (V[]){heff_tag_n(TAG_Asked, 1, (V[]){v_t_2429})}));
    return (g_co_2eop_24s535099379x685970669(v_t_2430, v_z_244, heff_clo_n(g_resource_2eheldBy_24s1065400090x105490439_lam5, 1, 2, (V[]){v_z_245, v_x_2414})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2422, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_cu_241);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_resource_2eheldBy_24s1065400090x105490439_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_cu_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_248, ((V)&g_resource_2eheldBy_24s1065400090x105490439_lam3_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s297957795x1045074450(v_t_2421, heff_dup(v_z_244), heff_clo_n(g_resource_2eheldBy_24s1065400090x105490439_lam4, 1, 4, (V[]){v_cu_241, v_z_244, v_z_245, v_x_2414})));
}
V g_resource_2eheldBy_24s1065400090x105490439_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_body_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cu_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_drop(v_x_2412);
  heff_clo_take(self, 5);
  V v_c_2413 = heff_tr(heff_call(v_body_242, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_248)})}));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_resource_2eheldBy_24s1065400090x105490439_lam2, 1, 4, (V[]){v_x_248, v_z_244, v_cu_241, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}