// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclPrimitive 46335
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_FloatValue 23118
#define TAG_IntValue 62477
#define TAG_Left 13886
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatRecord 42380
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_StrValue 22621
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_below 294979659
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2eabAbove(V, V, V);
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabAbove_clo;
V g_heff_2esyntax_2esurface_2eabGo(V, V);
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabGo_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldPatL(V, V);
V g_heff_2esyntax_2esurface_2efieldPatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldPatL_clo;
V g_heff_2esyntax_2esurface_2efitsIn(V, V, V, V);
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efitsIn_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixitiesOfText(V, V);
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
V g_heff_2esyntax_2esurface_2efixityOut(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_clo;
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2eintegerFits(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2elambdaL_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2elastEnd(V, V);
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elastEnd_clo;
V g_heff_2esyntax_2esurface_2elistP(V, V);
V g_heff_2esyntax_2esurface_2elistP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elistP_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2epatL(V, V, V);
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epatTok(V);
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTok_clo;
HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo;
V g_heff_2esyntax_2esurface_2eshortcut(V, V, V, V);
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eshortcut_clo;
V g_heff_2esyntax_2esurface_2especGroup(V, V, V);
V g_heff_2esyntax_2esurface_2especGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroup_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1330420811x172858565(V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_clo;
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
Clo g_heff_2esyntax_2esurface_2eisVarE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisVarE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisVarE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisVarE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str0, 2, "&&");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str1, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str2, 2, "||");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str3, 4, "True");
Clo g_heff_2esyntax_2esurface_2eapplyOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eapplyOp_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eapplyOp(V v_op_240, V v_l_241, V v_r_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_op_240, 1)), ((V)&g_heff_2esyntax_2esurface_2eapplyOp_str0))) {
    V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eapplyOp_str1)}), v_t_244});
    return (g_heff_2esyntax_2esurface_2eshortcut(v_op_240, v_l_241, v_r_242, v_t_245));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_op_240, 1)), ((V)&g_heff_2esyntax_2esurface_2eapplyOp_str2))) {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eapplyOp_str3)}), v_t_247});
      return (g_heff_2esyntax_2esurface_2eshortcut(v_op_240, v_l_241, v_t_248, v_r_242));
    } else {
      V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_op_240, 1)});
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_240, 3), heff_get_n(v_op_240, 4, 9)});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2410}), heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_2411})));
    }
  }
}
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eapplyOp(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2elambdaL_24cpr(V v_r_240, V v_binders_241, V v_body_242, V v_z_243) {
top: ;
  V v_m_245 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_binders_241));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_243}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_body_242);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248}});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(heff_dup(v_x_2410)));
      V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_body_242}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2411, heff_clo_n(g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam1, 1, 2, (V[]){v_m_2412, v_x_2410}), v_st_248));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
  }
}
V g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2elamBinderL(v_r_240, v_b_244));
}
V g_heff_2esyntax_2esurface_2elambdaL_24cpr_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_2413}));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      heff_drop(v_x_2410);
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      V v_x_2419 = (g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(v_x_2418, v_x_2410));
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2419}), v_st_2416});
    }
    default: return heff_nomatch(v_x11_2415);
    }
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
Clo g_heff_2esyntax_2esurface_2elambdaL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elambdaL_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elambdaL(V v_r_240, V v_binders_241, V v_body_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2elambdaL_24cpr(v_r_240, v_binders_241, v_body_242, v_z_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elambdaL(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroups_str0, 1, "-");
Clo g_heff_2esyntax_2esurface_2especGroups_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroups_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroups(V v_x1_240, V v_cur_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cur_241));
    V v_xs_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_acc_242});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  }
  case TAG_Cons: {
    V v_t_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroups_str0))) {
      heff_drop_rec(v_t_245, 9);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cur_241));
      V t_0 = v_rest_246;
      V t_1 = NTAG(TAG_Nil);
      V t_2 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_acc_242});
      v_x1_240 = t_0;
      v_cur_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      V t_0 = v_rest_246;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_cur_241});
      V t_2 = v_acc_242;
      v_x1_240 = t_0;
      v_cur_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroups(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroupsOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroupsOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroupsOf(V v_sp_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroupsOf_lam0, 1, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_gs_245 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_246 = heff_tr(g_heff_2esyntax_2esurface_2especGroup(heff_dup(v_sp_240), v_s_241, v_g_244));
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroupsOf_lam1, 1, 3, (V[]){v_m_246, v_sp_240, v_gs_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroupsOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_s_241}), v_st_243});
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_gs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_sp_240);
      heff_drop(v_gs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
      V v_t_2413 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_sp_240, v_x_2412, v_gs_245));
      V f_ = v_t_2413;
      args[0] = v_st_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str0, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str1, 8, ", signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str2, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str4, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_str5, 17, " does not fit in ");
V g_heff_2esyntax_2esurface_2eintegerFits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerFits_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_lam4, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_lam5, 1, 0};
Clo g_heff_2esyntax_2esurface_2eintegerFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eintegerFits(V v_inPat_240, V v_sp_241, V v_x3_242, V v_s_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_StrValue: {
    heff_drop(v_sp_241);
    heff_drop_rec(v_s_243, 5);
    heff_drop(v_n_244);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_lam0_clo);
  }
  case TAG_IntValue: {
    V v_v_247 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_248 = heff_dup(heff_rfield(v_s_243, 4));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_b_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = v_b_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = ({ V a_0 = v_inPat_240; V a_1 = v_t_2410; V a_2 = heff_dup(v_n_244); V a_3 = heff_dup(v_v_247); V r_ = (g_heff_2esyntax_2esurface_2efitsIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_sp_241);
      heff_drop_rec(v_s_243, 5);
      heff_drop(v_n_244);
      heff_drop(v_v_247);
      heff_drop(v_t_2411);
      return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_lam1_clo);
    } else {
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerFits_lam2, 1, 5, (V[]){heff_dup(v_inPat_240), v_s_243, v_n_244, v_v_247, v_sp_241});
    }
  }
  case TAG_FloatValue: {
    heff_drop(v_sp_241);
    heff_drop_rec(v_s_243, 5);
    heff_drop(v_n_244);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_lam3_clo);
  }
  case TAG_RuneValue: {
    heff_drop(v_sp_241);
    heff_drop_rec(v_s_243, 5);
    heff_drop(v_n_244);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_lam4_clo);
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_241);
    heff_drop_rec(v_s_243, 5);
    heff_drop(v_n_244);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_lam5_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eintegerFits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerFits(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam2(V self, V *args) {
  V v_st_2414 = args[0];
  V v_inPat_240 = heff_env(self)[0];
  V v_s_243 = heff_env(self)[1];
  V v_n_244 = heff_env(self)[2];
  V v_v_247 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417;
  if ((heff_dup(v_inPat_240) == NTAG(TAG_True))) {
    heff_drop(v_inPat_240);
    V v_t_2415 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_t_2417 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_str0);
      break;
    }
    case TAG_Just: {
      V v_b_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      if ((heff_dup(v_b_2416) == NTAG(TAG_True))) {
        heff_drop(v_b_2416);
        v_t_2417 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_str1);
      } else {
        heff_drop(v_b_2416);
        v_t_2417 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_str2);
      }
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
  } else {
    heff_drop(v_inPat_240);
    heff_drop_rec(v_s_243, 5);
    v_t_2417 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_str3);
  }
  V v_t_2418 = heff_strAppend(heff_intShow(v_n_244), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_str4), v_t_2417));
  V v_t_2419 = heff_strAppend(heff_intShow(v_v_247), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_str5), v_t_2418));
  V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2420}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam3(V self, V *args) {
  V v_st_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_st_2421});
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam4(V self, V *args) {
  V v_st_2423 = args[0];
  V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_st_2423});
}
V g_heff_2esyntax_2esurface_2eintegerFits_lam5(V self, V *args) {
  V v_st_2425 = args[0];
  V v_t_2426 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_st_2425});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str0, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str1, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str2, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str3, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str4, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str5, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str6, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str7, 27, " is no Unicode scalar value");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str8, 27, " is no Unicode scalar value");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str9, 27, " is no Unicode scalar value");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str10, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str11, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str12, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str13, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str14, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str15, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str16, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str17, 46, "a rune's segment is a code point: `'\303\251'::utf8`");

HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V v_sp_240, V v_v_241, V v_ty_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_StrValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_244}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      heff_drop(v_sp_240);
      V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_245, v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_246}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str3), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Left, 1, (V[]){v_t_249}), v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_IntValue: {
    V v_c_2410 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24IntValue = heff_take_reuse_n(v_v_241, 1ULL, 1);
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      heff_drop(v_sp_240);
      heff_drop(v_c_2410);
      V v_t_2411 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2411, v_p_243}});
    }
    case TAG_SegmentBinary: {
      heff_drop(v_c_2410);
      V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2412}), v_p_243}});
    }
    case TAG_SegmentBits: {
      heff_drop(v_c_2410);
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2413}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      heff_drop(v_c_2410);
      V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2414}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      heff_take_n(v_ty_242, 0ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_c_2410, 1)) {
        if (heff_intLe_c_lent(v_c_2410, MK_INT(1114111LL), 2)) {
          if ((((int64_t)55296ULL) <= heff_peek_word(v_c_2410))) {
            if ((heff_peek_word(v_c_2410) <= ((int64_t)57343ULL))) {
              V v_t_2420 = heff_strAppend(heff_intShow(v_c_2410), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str7));
              V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2420, v_sp_240, NTAG(TAG_Nothing)});
              V v_f_2422 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2421});
              return ((HeffT2){{v_f_2422, v_p_243}});
            } else {
              heff_drop(v_sp_240);
              heff_drop(v_c_2410);
              V v_t_2423 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
              return ((HeffT2){{v_t_2423, v_p_243}});
            }
          } else {
            heff_drop(v_sp_240);
            heff_drop(v_c_2410);
            V v_t_2424 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2424, v_p_243}});
          }
        } else {
          V v_t_2425 = heff_strAppend(heff_intShow(v_c_2410), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str8));
          V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2425, v_sp_240, NTAG(TAG_Nothing)});
          V v_f_2427 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2426});
          return ((HeffT2){{v_f_2427, v_p_243}});
        }
      } else {
        V v_t_2428 = heff_strAppend(heff_intShow(v_c_2410), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str9));
        V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2428, v_sp_240, NTAG(TAG_Nothing)});
        V v_f_2430 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2429});
        return ((HeffT2){{v_f_2430, v_p_243}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_FloatValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str10), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str11), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str12), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2433}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      heff_drop(v_sp_240);
      V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2434, v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str13), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Left, 1, (V[]){v_t_2436}), v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_RuneValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str14), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2437}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str15), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2438}), v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str16), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2439}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str17), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2440}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      heff_drop(v_sp_240);
      V v_t_2442 = heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2442, v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_240);
    heff_drop(v_ty_242);
    V v_t_2443 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_2443, v_p_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_v_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str1, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str2, 15, "unexpected `::`");
V g_heff_2esyntax_2esurface_2epatL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2epatL(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24PCon = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 1, 3), v_args_244));
    V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkPair: {
      V v_x11_247 = heff_field(v_x1_246, 0);
      V v_st_248 = heff_field(v_x1_246, 1);
      V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
      switch (heff_tag_of(v_x11_247)) {
      case TAG_Left: {
        V v_e_249 = heff_field(v_x11_247, 0);
        heff_take_n(v_x11_247, 1ULL, 1);
        heff_drop_rec(v_c_243, 9);
        heff_drop_cell(v_ru_24x1_246_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x2_241_24PCon, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
      }
      case TAG_Right: {
        V v_x_2410 = heff_field(v_x11_247, 0);
        heff_take_n(v_x11_247, 1ULL, 1);
        V v_t_2411 = heff_take_field(v_c_243, 1);
        V v_tsp_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_243, 3), heff_get_n(v_c_243, 4, 9)});
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24PCon, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2411)}), heff_dup(v_tsp_2412)});
        V v_x1_2414 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2413, v_x_2410));
        V v_t_2417;
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_field(v_x1_2414, 1);
          heff_take_n(v_x1_2414, 2ULL, 2);
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        V v_t_2418 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2412, 0)); V rr_ = heff_rec_reuse_nf(v_t_2417, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_x_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2411, v_tsp_2412, v_x_2410}), v_t_2418});
        return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2419}), v_st_248});
      }
      default: return heff_nomatch(v_x11_247);
      }
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_PAtom: {
    V v_t_2420 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PAtom = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2420, 0)), ((V)&g_heff_2esyntax_2esurface_2epatL_str0))) {
      V v_t_2422 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_2420, 1))}));
      V v_t_2423 = (g_list_2eany(v_t_2422, heff_rfield(v_z_242, 4)));
      V v_x_2435;
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_t_2423);
        V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24PAtom, TAG_PatVar, 1, (V[]){heff_dup(heff_rfield(v_t_2420, 1))});
        V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2420, 3), heff_get_n(v_t_2420, 4, 9)});
        v_x_2435 = heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2425});
      } else {
        heff_drop(v_t_2423);
        V v_t_2426 = heff_take_field(v_t_2420, 1);
        V v_tsp_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2420, 3), heff_get_n(v_t_2420, 4, 9)});
        V v_t_2428 = heff_tag_n(TAG_PatTag, 3, (V[]){heff_dup(v_t_2426), heff_dup(v_tsp_2427), NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24PAtom, TAG_PatVar, 1, (V[]){v_t_2426}), heff_dup(v_tsp_2427)});
        V v_x1_2430 = ({ V a_0 = v_t_2429; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2433;
        switch (heff_tag_of(v_x1_2430)) {
        case TAG_At: {
          V v_s_2432 = heff_field(v_x1_2430, 1);
          heff_take_n(v_x1_2430, 2ULL, 2);
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_x1_2430);
        }
        V v_t_2434 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_tsp_2427, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_x_2435 = heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_t_2434});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2435}), v_z_242});
    } else {
      V v_x_2436 = (g_heff_2esyntax_2esurface_2epatTok(v_t_2420));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24PAtom, TAG_Right, 1, (V[]){v_x_2436}), v_z_242});
    }
  }
  case TAG_PParen: {
    V v_p_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_p_2438, v_z_242});
  }
  case TAG_PList: {
    V v_o_2440 = heff_field(v_x2_241, 0);
    V v_ps_2441 = heff_field(v_x2_241, 1);
    V v_c_2443 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2440, 1)), ((V)&g_heff_2esyntax_2esurface_2epatL_str1))) {
      V v_m_2445 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_ps_2441));
      V v_x1_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2446)) {
      case TAG_MkPair: {
        V v_x11_2447 = heff_field(v_x1_2446, 0);
        V v_st_2448 = heff_field(v_x1_2446, 1);
        V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
        switch (heff_tag_of(v_x11_2447)) {
        case TAG_Left: {
          V v_e_2449 = heff_field(v_x11_2447, 0);
          heff_take_n(v_x11_2447, 1ULL, 1);
          heff_drop_rec(v_o_2440, 9);
          heff_drop_rec(v_c_2443, 9);
          return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
        }
        case TAG_Right: {
          V v_x_2450 = heff_field(v_x11_2447, 0);
          V v_ru_24x11_2447_24Right = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
          V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2440, 3, 9), heff_get_n(v_c_2443, 4, 9)});
          V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2447_24Right, TAG_PatBinary, 1, (V[]){v_x_2450}), v_t_2451});
          return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2452}), v_st_2448});
        }
        default: return heff_nomatch(v_x11_2447);
        }
      }
      default: return heff_nomatch(v_x1_2446);
      }
    } else {
      V v_m_2453 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 1, 3), v_ps_2441));
      V v_x1_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_MkPair: {
        V v_x11_2455 = heff_field(v_x1_2454, 0);
        V v_st_2456 = heff_field(v_x1_2454, 1);
        V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
        switch (heff_tag_of(v_x11_2455)) {
        case TAG_Left: {
          V v_e_2457 = heff_field(v_x11_2455, 0);
          heff_take_n(v_x11_2455, 1ULL, 1);
          heff_drop_rec(v_o_2440, 9);
          heff_drop_rec(v_c_2443, 9);
          return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
        }
        case TAG_Right: {
          V v_x_2458 = heff_field(v_x11_2455, 0);
          heff_take_n(v_x11_2455, 1ULL, 1);
          V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2440, 3, 9), heff_get_n(v_c_2443, 4, 9)});
          V v_x_2460 = ({ V a_0 = v_t_2459; V a_1 = v_x_2458; V r_ = heff_tr(g_heff_2esyntax_2esurface_2elistP(a_0, a_1)); heff_drop(v_x_2458); r_; });
          return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2460}), v_st_2456});
        }
        default: return heff_nomatch(v_x11_2455);
        }
      }
      default: return heff_nomatch(v_x1_2454);
      }
    }
  }
  case TAG_POp: {
    V v_l_2461 = heff_field(v_x2_241, 0);
    V v_op_2462 = heff_field(v_x2_241, 1);
    V v_q_2463 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24POp = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    HeffT2 v_t_2464 = (g_heff_2esyntax_2esurface_2epchainOf_24cpr(heff_tag_at_n(v_ru_24x2_241_24POp, TAG_POp, 3, (V[]){v_l_2461, v_op_2462, v_q_2463})));
    {
      V v_field_2465 = v_t_2464.f[0];
      V v_field_2466 = v_t_2464.f[1];
      V v_h_2467 = v_field_2465;
      V v_rest_2468 = v_field_2466;
      V v_m_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_h_2467}));
      V v_x1_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2470)) {
      case TAG_MkPair: {
        V v_x11_2471 = heff_field(v_x1_2470, 0);
        V v_st_2472 = heff_field(v_x1_2470, 1);
        V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
        switch (heff_tag_of(v_x11_2471)) {
        case TAG_Left: {
          V v_e_2473 = heff_field(v_x11_2471, 0);
          heff_take_n(v_x11_2471, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop(v_rest_2468);
          return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
        }
        case TAG_Right: {
          V v_x_2474 = heff_field(v_x11_2471, 0);
          heff_take_n(v_x11_2471, 1ULL, 1);
          V v_m_2486 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam0, 1, 1, (V[]){v_r_240}), v_rest_2468));
          V v_x1_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_st_2472}));
          switch (heff_tag_of(v_x1_2487)) {
          case TAG_MkPair: {
            V v_x11_2488 = heff_field(v_x1_2487, 0);
            V v_st_2489 = heff_field(v_x1_2487, 1);
            heff_take_n(v_x1_2487, 3ULL, 2);
            switch (heff_tag_of(v_x11_2488)) {
            case TAG_Left: {
              V v_e_2490 = heff_field(v_x11_2488, 0);
              heff_take_n(v_x11_2488, 1ULL, 1);
              heff_drop(v_x_2474);
              return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2490}), v_st_2489});
            }
            case TAG_Right: {
              V v_x_2491 = heff_field(v_x11_2488, 0);
              heff_take_n(v_x11_2488, 1ULL, 1);
              heff_drop_cell(v_ru_24x1_2470_24MkPair, 2);
              HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(v_x_2474, v_x_2491, v_st_2489);
            }
            default: return heff_nomatch(v_x11_2488);
            }
          }
          default: return heff_nomatch(v_x1_2487);
          }
        }
        default: return heff_nomatch(v_x11_2471);
        }
      }
      default: return heff_nomatch(v_x1_2470);
      }
    }
  }
  case TAG_PRec: {
    V v_o_2492 = heff_field(v_x2_241, 0);
    V v_fs_2493 = heff_field(v_x2_241, 1);
    V v_c_2495 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 11ULL, 4);
    V v_m_2497 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2493));
    V v_x1_2498 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2498)) {
    case TAG_MkPair: {
      V v_x11_2499 = heff_field(v_x1_2498, 0);
      V v_st_24100 = heff_field(v_x1_2498, 1);
      V v_ru_24x1_2498_24MkPair = heff_take_reuse_n(v_x1_2498, 3ULL, 2);
      switch (heff_tag_of(v_x11_2499)) {
      case TAG_Left: {
        V v_e_24101 = heff_field(v_x11_2499, 0);
        heff_take_n(v_x11_2499, 1ULL, 1);
        heff_drop_rec(v_o_2492, 9);
        heff_drop_rec(v_c_2495, 9);
        return heff_tag_at_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24101}), v_st_24100});
      }
      case TAG_Right: {
        V v_x_24102 = heff_field(v_x11_2499, 0);
        V v_ru_24x11_2499_24Right = heff_take_reuse_n(v_x11_2499, 1ULL, 1);
        V v_t_24103 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2492, 3, 9), heff_get_n(v_c_2495, 4, 9)});
        V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2499_24Right, TAG_PatRecord, 1, (V[]){v_x_24102}), v_t_24103});
        return heff_tag_at_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_24100});
      }
      default: return heff_nomatch(v_x11_2499);
      }
    }
    default: return heff_nomatch(v_x1_2498);
    }
  }
  case TAG_PField: {
    V v_p_24107 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_p_24107, v_z_242});
  }
  case TAG_PAs: {
    V v_x_24108 = heff_field(v_x2_241, 0);
    V v_p_24110 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PAs = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    V v_m_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_p_24110)}));
    V v_x1_24112 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24112)) {
    case TAG_MkPair: {
      V v_x11_24113 = heff_field(v_x1_24112, 0);
      V v_st_24114 = heff_field(v_x1_24112, 1);
      V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
      switch (heff_tag_of(v_x11_24113)) {
      case TAG_Left: {
        V v_e_24115 = heff_field(v_x11_24113, 0);
        heff_take_n(v_x11_24113, 1ULL, 1);
        heff_drop_rec(v_x_24108, 9);
        heff_drop(v_p_24110);
        heff_drop_cell(v_ru_24x2_241_24PAs, 3);
        return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
      }
      case TAG_Right: {
        V v_x_24116 = heff_field(v_x11_24113, 0);
        heff_take_n(v_x11_24113, 1ULL, 1);
        V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24108, 3)), heff_take_field(v_x_24108, 4)});
        V v_t_24118 = heff_tag_at_n(v_ru_24x2_241_24PAs, TAG_PatAs, 3, (V[]){heff_dup(heff_rfield(v_x_24108, 1)), v_t_24117, v_x_24116});
        V v_b_24119 = (g_heff_2esyntax_2ecst_2elastP(v_p_24110));
        V v_t_24120 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_24108, 3, 9), heff_get_n(v_b_24119, 4, 9)});
        V v_x_24121 = heff_tag_n(TAG_At, 2, (V[]){v_t_24118, v_t_24120});
        return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24121}), v_st_24114});
      }
      default: return heff_nomatch(v_x11_24113);
      }
    }
    default: return heff_nomatch(v_x1_24112);
    }
  }
  case TAG_PSeg: {
    V v_cc_24123 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    heff_drop_rec(v_r_240, 3);
    V v_t_24125 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_cc_24123, 3), heff_get_n(v_cc_24123, 4, 9)});
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatL_str2), v_t_24125, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_z_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2epatL_lam1(V self, V *args) {
  V v_st_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  V v_op_2476 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_st_2479}));
  switch (heff_tag_of(v_x1_2480)) {
  case TAG_MkPair: {
    V v_x11_2481 = heff_field(v_x1_2480, 0);
    V v_st_2482 = heff_field(v_x1_2480, 1);
    V v_ru_24x1_2480_24MkPair = heff_take_reuse_n(v_x1_2480, 3ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_Left: {
      V v_e_2483 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      heff_drop(v_op_2476);
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
    }
    case TAG_Right: {
      V v_x_2484 = heff_field(v_x11_2481, 0);
      V v_ru_24x11_2481_24Right = heff_take_reuse_n(v_x11_2481, 1ULL, 1);
      V v_t_2485 = heff_tag_at_n(v_ru_24x11_2481_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_2476, v_x_2484})});
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){v_t_2485, v_st_2482});
    }
    default: return heff_nomatch(v_x11_2481);
    }
  }
  default: return heff_nomatch(v_x1_2480);
  }
}
V g_heff_2esyntax_2esurface_2epatL_lam0(V self, V *args) {
  V v_m_2475 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2475)) {
  case TAG_MkPair: {
    V v_op_2476 = heff_field(v_m_2475, 0);
    V v_p_2477 = heff_field(v_m_2475, 1);
    heff_take_n(v_m_2475, 3ULL, 2);
    V v_m_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_2477}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam1, 1, 2, (V[]){v_m_2478, v_op_2476});
  }
  default: return heff_nomatch(v_m_2475);
  }
}
V g_heff_2esyntax_2esurface_2epatL_lam2(V self, V *args) {
  V v_f_2496 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2efieldPatL(v_r_240, v_f_2496));
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 1)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str1, 5, "above");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str3, 5, "below");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str5, 48, "expected `above` or `below` and operators, not `");
Clo g_heff_2esyntax_2esurface_2eabGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabGo_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eabGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_x2_241, 0);
    V v_tail_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_w_242, 1)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str1))));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_tail_243)));
      V v_t_247 = (g_heff_2esyntax_2esurface_2eabAbove(v_acc_240, v_w_242, v_t_246));
      V v_t_248 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_tail_243));
      V v_t_249 = (g_heff_2esyntax_2esurface_2edropN(v_t_248, v_tail_243));
      V t_0 = v_t_247;
      V t_1 = v_t_249;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_t_2411 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_w_242, 1)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str3))));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_w_242, 7);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2411);
        V v_ops_2412 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_tail_243)));
        V v_t_2416;
        switch (heff_tag_of(v_ops_2412)) {
        case TAG_Nil: {
          v_t_2416 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_acc_240, 11ULL, 4, shape_above__below__loosest__errors, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          break;
        }
        case TAG_Cons: {
          V v_t_2415 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_acc_240, 1), v_ops_2412));
          v_t_2416 = ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 13ULL, 4, shape_above__below__loosest__errors, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_ops_2412);
        }
        V v_t_2417 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_tail_243));
        V v_t_2418 = (g_heff_2esyntax_2esurface_2edropN(v_t_2417, v_tail_243));
        V t_0 = v_t_2416;
        V t_1 = v_t_2418;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_tail_243);
        heff_drop(v_t_2411);
        V v_t_2419 = heff_strAppend(heff_take_field(v_w_242, 1), ((V)&g_heff_2esyntax_2esurface_2eabGo_str4));
        V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_242, 2), heff_get_n(v_w_242, 3, 7)});
        V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eabGo_str5), v_t_2419), v_t_2420, NTAG(TAG_Nothing)});
        V v_t_2422 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_dup(heff_rfield(v_acc_240, 3))});
        return ({ V rv_3 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_acc_240, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2elastEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elastEnd_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elastEnd(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_get_n(v_t_240, 3, 7);
  }
  case TAG_Cons: {
    V v_u_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_t_240, 7);
      return heff_dup(heff_rfield(v_u_242, 3));
    }
    case TAG_Cons: {
      V t_0 = v_t_240;
      V t_1 = v_x22_243;
      v_t_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2elastEnd(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efixityFrom_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixityFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixityFrom(V v_place_240, V v_imported_241, V v_decls_242) {
top: ;
  V v_t_243 = (g_list_2efilter_24s1330420811x172858565(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_242)));
  V v_t_245 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_lam0, 1, 1, (V[]){v_place_240}), v_t_243));
  V v_groups_246 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_245));
  V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_241, 0)), heff_dup(v_groups_246)));
  V v_t_248 = (g_heff_2esyntax_2efixity_2enubByG(v_t_247));
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_241, 1)), NTAG(TAG_Nil)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByE(v_t_249));
  V v_t_2411 = heff_rec_n(2, shape_groups__above, (V[]){v_t_248, v_t_2410});
  V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_t_2411, v_decls_242));
  return ({ V a_0 = v_imported_241; V a_1 = v_decls_242; V a_2 = v_groups_246; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2efixityOut(a_0, a_1, a_2, a_3)); heff_drop(v_decls_242); r_; });
}
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixityFrom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2efixityFrom_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_244));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixitiesOfText_str0, 0, "");
Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixitiesOfText_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efixitiesOfText(V v_imported_240, V v_src_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_241, v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_244 = heff_arrayFromList(heff_get_n(v_t_243, 0, 3));
  V v_t_245 = ({ V a_0 = v_ts_244; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ts_244); r_; });
  V v_t_246 = (g_heff_2esyntax_2esurface_2efixityFrom(((V)&g_heff_2esyntax_2esurface_2efixitiesOfText_str0), v_imported_240, v_t_245));
  return heff_get_n(v_t_246, 0, 2);
}
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixitiesOfText(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V v_kw_240, V v_x_241, V v_ty_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_242), v_st_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_x_241, 9);
      heff_drop(v_ty_242);
      heff_drop_cell(v_ru_24x1_244_24MkPair, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Left, TAG_Left, 1, (V[]){v_e_247}), v_st_246}});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_take_field(v_x_241, 4)});
      V v_t_2410 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){heff_get_n(v_x_241, 1, 9), v_t_249, v_x_248});
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_ty_242));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2412});
      V v_t_2414 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_At, 2, (V[]){v_t_2410, v_t_2413})});
      V v_x_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){v_x_2415}), v_st_246}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
  }
}