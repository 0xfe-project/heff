// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_ReadDirectory 46629
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Sleep 25229
#define LBL_builds 569118448
#define LBL_kind 9787483
#define LBL_modified 129625309
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_running 1782641667
#define LBL_size 10026184
#define LBL_wanted 1152016858
static uint32_t shape_running__pages__builds__wanted__port__proxy[] = {LBL_running, LBL_pages, LBL_builds, LBL_wanted, LBL_port, LBL_proxy};
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(V, V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str2, 3, "src");

static V g_heff_2ebuild_2ewatch_2eproject_val;
static HEFF_ONCE g_heff_2ebuild_2ewatch_2eproject_st;
static V g_heff_2ebuild_2ewatch_2eproject_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str2), v_t_240})});
}
V g_heff_2ebuild_2ewatch_2eproject_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ewatch_2eproject_st)) return g_heff_2ebuild_2ewatch_2eproject_val;
  return heff_global(&g_heff_2ebuild_2ewatch_2eproject_val, &g_heff_2ebuild_2ewatch_2eproject_st, g_heff_2ebuild_2ewatch_2eproject_init);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str2, 1, " ");
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam0(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam0, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam2(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam2, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam4(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam1(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry, 5, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V v_st_240, V v_acc_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_PathStatus, 3, (V[]){heff_dup(v_p_245), NTAG(TAG_True), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam0_clo)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam1, 1, 6, (V[]){heff_dup(v_st_240), v_acc_241, v_rest_246, v_p_243, v_p_244, v_p_245})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam2(V self, V *args) {
  V v_ns_2419 = args[0];
  return v_ns_2419;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam4(V self, V *args) {
  V v_n_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_240; V a_1 = v_p_245; V a_2 = v_n_2428; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2429;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop(v_p_245);
    v_t_2429 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_names_2426 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    V v_t_2427 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str0); V a_3 = v_names_2426; V r_ = (g_list_2efilter_24s2101000672x961294372(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam4, 1, 2, (V[]){heff_dup(v_st_240), v_p_245}), v_t_2427));
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2429, v_rest_246));
  return ({ V a_0 = v_st_240; V a_1 = v_acc_241; V a_2 = v_t_2430; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_drop(v_p_245);
    return ({ V a_0 = v_st_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  }
  case TAG_Right: {
    V v_s_2416 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2417 = heff_take_field(v_s_2416, 0);
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Regular: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_2416, 4);
      heff_drop(v_t_2418);
      V v_t_2420 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam2_clo)})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_lam3, 1, 6, (V[]){v_st_240, v_p_245, v_rest_246, v_acc_241, v_p_243, v_p_244})));
    } else {
      heff_drop_cell(v_ru_24x_2414_24Right, 1);
      heff_drop(v_t_2418);
      V v_t_2431 = heff_intShow(heff_take_field(v_s_2416, 2));
      V v_t_2432 = heff_intShow(heff_get_n(v_s_2416, 1, 4));
      V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str1), v_t_2432));
      V v_t_2434 = heff_strAppend(v_p_245, heff_strAppend(((V)&g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_str2), v_t_2433));
      return ({ V a_0 = v_st_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_acc_241}); V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_entry, 8, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(V v_clock_240, V v_st_241, V v_paths_242, V v_changed_243, V v_stamp_244, V v_now_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_clock_240), 1, (V[]){v_t_248}));
  return (g_co_2eop_24s94900133x232571340(v_t_249, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam0, 1, 8, (V[]){heff_dup(v_st_241), v_paths_242, v_z_246, heff_dup(v_stamp_244), v_clock_240, v_changed_243, v_now_245, heff_dup(v_z_247)})));
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(a[0], a1, a[2], a[3], a4, a[5], a[6], a7); heff_drop(a1); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_paths_242 = heff_env(self)[2];
  V v_changed_243 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_x_2414; V a_5 = v_x_2417; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_241); heff_drop(v_x_2414); heff_drop(v_z_247); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_paths_242 = heff_env(self)[3];
  V v_changed_243 = heff_env(self)[4];
  V v_now_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2414;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nil: {
    v_x_2414 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x_2411, 0);
    V v_xs_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    v_x_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if (heff_strEq_c_lent(v_x_2414, v_stamp_244, 0)) {
    heff_drop(v_x_2414);
    return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_stamp_244; V a_5 = v_now_245; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_241); heff_drop(v_stamp_244); heff_drop(v_z_247); r_; });
  } else {
    heff_drop(v_stamp_244);
    V v_c_2416 = heff_tr(heff_call(heff_dup(v_changed_243), 1, (V[]){v_now_245}));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_z_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam2, 1, 7, (V[]){v_clock_240, v_st_241, v_paths_242, v_changed_243, v_x_2414, v_z_246, v_z_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_paths_242 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_changed_243 = heff_env(self)[5];
  V v_now_245 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return ({ V a_0 = v_st_241; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(v_paths_242); V a_3 = heff_dup(v_z_246); V a_4 = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_lam1, 1, 8, (V[]){v_stamp_244, v_clock_240, heff_dup(v_st_241), v_paths_242, v_changed_243, v_now_245, v_z_246, v_z_247}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_entry, 9, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(V v_lit_240, V v_lit_241, V v_clock_242, V v_st_243, V v_paths_244, V v_stamp_245, V v_now_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_clock_242), 1, (V[]){v_t_249}));
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam0, 1, 9, (V[]){v_now_246, v_z_247, heff_dup(v_st_243), v_paths_244, heff_dup(v_stamp_245), v_lit_240, heff_dup(v_lit_241), v_clock_242, heff_dup(v_z_248)})));
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V a5 = a[5]; V a8 = a[8]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(a[0], a1, a[2], a3, a[4], a5, a[6], a[7], a8); heff_drop(a1); heff_drop(a3); heff_drop(a5); heff_drop(a8); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_clock_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_paths_244 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_clock_242; V a_3 = v_st_243; V a_4 = v_paths_244; V a_5 = v_x_2417; V a_6 = v_x_2419; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_lit_241); heff_drop(v_st_243); heff_drop(v_x_2417); heff_drop(v_z_248); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_stamp_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_clock_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_paths_244 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_xs_2416 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  if (heff_strEq_c_lent(v_x_2417, v_stamp_245, 0)) {
    heff_drop(v_x_2417);
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_clock_242; V a_3 = v_st_243; V a_4 = v_paths_244; V a_5 = v_stamp_245; V a_6 = v_x_2413; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_lit_241); heff_drop(v_st_243); heff_drop(v_stamp_245); heff_drop(v_z_248); r_; });
  } else {
    heff_drop(v_stamp_245);
    return ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_lit_241; V a_2 = v_x_2413; V a_3 = heff_dup(v_z_247); V a_4 = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam3, 1, 8, (V[]){v_lit_240, heff_dup(v_lit_241), v_clock_242, v_st_243, v_paths_244, v_x_2417, v_z_247, v_z_248}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_241); r_; });
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam1(V self, V *args) {
  V v_a_2412 = args[0];
  V v_now_246 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_paths_244 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_stamp_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_clock_242 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2413 = ({ V rv_0 = v_a_2412; V rr_ = heff_rec_reuse_nf(v_now_246, 62ULL, 6, shape_running__pages__builds__wanted__port__proxy, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return ({ V a_0 = v_st_243; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(v_paths_244); V a_3 = heff_dup(v_z_247); V a_4 = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam2, 1, 9, (V[]){v_stamp_245, v_lit_240, v_lit_241, v_clock_242, heff_dup(v_st_243), v_paths_244, v_x_2413, v_z_247, v_z_248}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_now_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_st_243 = heff_env(self)[2];
  V v_paths_244 = heff_env(self)[3];
  V v_stamp_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_clock_242 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  return (g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(NTAG(TAG_Nil), heff_dup(heff_rfield(v_now_246, 0)), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_lam1, 1, 9, (V[]){v_now_246, v_st_243, v_paths_244, v_z_247, v_stamp_245, v_lit_240, v_lit_241, v_clock_242, v_z_248})));
}