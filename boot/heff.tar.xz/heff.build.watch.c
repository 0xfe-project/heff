// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_ReadDirectory 46629
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Sleep 25229
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_modified 129625309
#define LBL_size 10026184
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str2, 3, "src");

static V g_heff_2ebuild_2ewatch_2eproject_val;
static HEFF_ONCE g_heff_2ebuild_2ewatch_2eproject_st;
static V g_heff_2ebuild_2ewatch_2eproject_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str2), v_t_240})});
}
V g_heff_2ebuild_2ewatch_2eproject_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ewatch_2eproject_st)) return g_heff_2ebuild_2ewatch_2eproject_val;
  return heff_global(&g_heff_2ebuild_2ewatch_2eproject_val, &g_heff_2ebuild_2ewatch_2eproject_st, g_heff_2ebuild_2ewatch_2eproject_init);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str2, 1, " ");
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam9(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam8(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam10(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam12(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam11(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry, 3, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V v_st_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
    V v_a_2410 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_248, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    V v_c_2423 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2_clo)));
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4, 2, 5, (V[]){v_c_2423, v_st_240, v_acc_241, v_rest_246, v_p_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2418})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2419));
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3, 2, 1, (V[]){v_x_2420});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6(V self, V *args) {
  V v_r_2436 = args[0];
  return v_r_2436;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam9(V self, V *args) {
  V v_n_2452 = args[0];
  V v_path_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2452));
  return (g_std_2epath_2ejoin(v_path_2434, v_t_2453));
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_z_2450 = args[1];
  V v_z_2451 = args[2];
  V v_path_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2450);
  V v_x_2454 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam9, 1, 1, (V[]){v_path_2434}), v_x_2449));
  V v_x_2455 = (g_list_2emap_24s219049803x1458391381(v_x_2454));
  V f_ = v_z_2451;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam10(V self, V *args) {
  V v_n_2457 = args[0];
  V v_path_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2457));
  return (g_std_2epath_2ejoin(v_path_2434, v_t_2458));
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_2445 = args[1];
  V v_z_2446 = args[2];
  V v_path_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_err_2447 = heff_field(v_x_2444, 0);
    V v_ru_24x_2444_24Left = heff_take_reuse_n(v_x_2444, 1ULL, 1);
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2444_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2447})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2448, heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam8, 3, 1, (V[]){v_path_2434}), v_z_2445, v_z_2446));
  }
  case TAG_Right: {
    V v_x_2456 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    heff_drop(v_z_2445);
    V v_x_2459 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam10, 1, 1, (V[]){v_path_2434}), v_x_2456));
    V v_x_2460 = (g_list_2emap_24s219049803x1458391381(v_x_2459));
    V f_ = v_z_2446;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2460});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam12(V self, V *args) {
  V v_n_2467 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_245));
  V v_t_2469 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2467));
  V v_t_2470 = (g_std_2epath_2ejoin(v_t_2468, v_t_2469));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2470); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2424 = heff_env(self)[3];
  V v_k_2425 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    heff_take_n(v_x_2462, 0ULL, 1);
    heff_drop(v_p_245);
    V v_t_2464 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_240, v_acc_241, v_rest_246));
    V f_ = v_t_2464;
    heff_room[0] = v_hd_2424;
    heff_room[1] = v_k_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2465 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    V v_t_2466 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str0); V a_3 = v_y_2465; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2471 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam12, 1, 2, (V[]){heff_dup(v_st_240), v_p_245}), v_t_2466));
    V v_t_2472 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_240, v_acc_241, v_t_2471));
    V f_ = v_t_2472;
    heff_room[0] = v_hd_2424;
    heff_room[1] = v_k_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2462);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2424 = heff_env(self)[3];
  V v_k_2425 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_drop(v_p_245);
    V v_t_2428 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_240, v_acc_241, v_rest_246));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2424;
    heff_room[1] = v_k_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_s_2429 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    V v_kind_2430 = heff_take_field(v_s_2429, 0);
    V v_modified_2431 = heff_take_field(v_s_2429, 2);
    V v_size_2432 = heff_get_n(v_s_2429, 1, 4);
    V v_t_2433;
    switch (heff_tag_of(v_kind_2430)) {
    case TAG_Regular: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_kind_2430);
    }
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop(v_modified_2431);
      heff_drop(v_size_2432);
      heff_drop(v_t_2433);
      V v_path_2434 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
      V v_t_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2434; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
      V v_a_2437 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2435, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6_clo)});
      V v_t_2438 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
      V v_c_2461 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7, 3, 1, (V[]){v_path_2434})));
      V f_ = v_c_2461;
      heff_room[0] = heff_dup(v_hd_2424);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam11, 1, 6, (V[]){v_st_240, v_acc_241, v_rest_246, v_hd_2424, v_k_2425, v_p_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop_cell(v_ru_24x_2426_24Right, 1);
      heff_drop(v_t_2433);
      V v_t_2473 = heff_strAppend(heff_strAppend(v_p_245, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str1)), heff_intShow(v_modified_2431));
      V v_t_2474 = heff_strAppend(heff_strAppend(v_t_2473, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str2)), heff_intShow(v_size_2432));
      V v_t_2475 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, v_acc_241}), v_rest_246));
      V f_ = v_t_2475;
      heff_room[0] = v_hd_2424;
      heff_room[1] = v_k_2425;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5, 1, 6, (V[]){v_st_240, v_acc_241, v_rest_246, v_hd_2424, v_k_2425, v_p_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_entry, 7, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(V v_st_240, V v_paths_241, V v_changed_242, V v_stamp_243, V v_now_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam0, 1, 7, (V[]){v_st_240, v_paths_241, v_hd_245, heff_dup(v_stamp_243), v_changed_242, v_now_244, heff_dup(v_k_246)})});
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(a[0], a[1], a[2], a3, a[4], a[5], a6); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_paths_241 = heff_env(self)[1];
  V v_changed_242 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_st_240; V a_1 = v_paths_241; V a_2 = v_changed_242; V a_3 = v_x_2417; V a_4 = v_x_2419; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2417); heff_drop(v_k_246); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_stamp_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_paths_241 = heff_env(self)[2];
  V v_changed_242 = heff_env(self)[3];
  V v_now_244 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_xs_2416 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  if (heff_strEq_c_lent(v_x_2417, v_stamp_243, 0)) {
    heff_drop(v_x_2417);
    return ({ V a_0 = v_st_240; V a_1 = v_paths_241; V a_2 = v_changed_242; V a_3 = v_stamp_243; V a_4 = v_now_244; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_stamp_243); heff_drop(v_k_246); r_; });
  } else {
    heff_drop(v_stamp_243);
    V v_c_2418 = heff_tr(heff_call(heff_dup(v_changed_242), 1, (V[]){v_now_244}));
    V f_ = v_c_2418;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam2, 1, 6, (V[]){v_st_240, v_paths_241, v_changed_242, v_x_2417, v_hd_245, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_paths_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_changed_242 = heff_env(self)[4];
  V v_now_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_c_2413 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(heff_dup(v_st_240), NTAG(TAG_Nil), heff_dup(v_paths_241)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_lam1, 1, 7, (V[]){v_stamp_243, v_st_240, v_paths_241, v_changed_242, v_now_244, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}