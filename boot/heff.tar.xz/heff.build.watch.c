// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Other 45236
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Sleep 25229
#define LBL_kind 9787483
#define LBL_modified 129625309
#define LBL_size 10026184
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148(V);
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_entry(V self, V *a);
extern Clo g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str2, 3, "src");

static V g_heff_2ebuild_2ewatch_2eproject_val;
static HEFF_ONCE g_heff_2ebuild_2ewatch_2eproject_st;
static V g_heff_2ebuild_2ewatch_2eproject_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str2), v_t_240})});
}
V g_heff_2ebuild_2ewatch_2eproject_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ewatch_2eproject_st)) return g_heff_2ebuild_2ewatch_2eproject_val;
  return heff_global(&g_heff_2ebuild_2ewatch_2eproject_val, &g_heff_2ebuild_2ewatch_2eproject_st, g_heff_2ebuild_2ewatch_2eproject_init);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str2, 1, " ");
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1, 3, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry, 3, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V v_st_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_245); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2epathStatus_24s1180173567x1248178148(a_0)); heff_drop(v_path_247); r_; });
    V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2, 2, 5, (V[]){v_c_2412, heff_dup(v_st_240), v_acc_241, v_rest_246, v_p_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2426 = (g_list_2emap_24s219049803x1458391381(v_x_2425));
  return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam5, 2, 1, (V[]){v_x_2426});
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7(V self, V *args) {
  V v_n_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = (g_std_2epath_2eparse(v_st_240, v_p_245));
  V v_t_2438 = (g_std_2epath_2eparse(v_st_240, v_n_2436));
  V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2439); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_drop(v_p_245);
    V v_t_2432 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_rest_246));
    V v_t_2433 = ({ V a_0 = v_st_240; V a_1 = v_acc_241; V a_2 = v_t_2432; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    V v_t_2435 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str0); V a_3 = v_y_2434; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2440 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam7, 1, 2, (V[]){heff_dup(v_st_240), v_p_245}), v_t_2435));
    V v_t_2441 = ({ V a_0 = v_st_240; V a_1 = v_acc_241; V a_2 = v_t_2440; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V f_ = v_t_2441;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_drop(v_p_245);
    V v_t_2417 = ({ V a_0 = v_st_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V f_ = v_t_2417;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_s_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_kind_2419 = heff_take_field(v_s_2418, 0);
    V v_modified_2420 = heff_take_field(v_s_2418, 2);
    V v_size_2421 = heff_get_n(v_s_2418, 1, 4);
    V v_t_2422;
    switch (heff_tag_of(v_kind_2419)) {
    case TAG_Regular: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_kind_2419);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_modified_2420);
      heff_drop(v_size_2421);
      heff_drop(v_t_2422);
      V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_245); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2424 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_2423));
      V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam4_clo)}));
      V f_ = v_c_2429;
      heff_room[0] = heff_dup(v_hd_2413);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam6, 1, 6, (V[]){v_rest_246, v_st_240, v_acc_241, v_hd_2413, v_k_2414, v_p_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2422);
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str1), heff_intShow(v_size_2421));
      V v_t_2443 = heff_strAppend(heff_intShow(v_modified_2420), v_t_2442);
      V v_t_2444 = heff_strAppend(v_p_245, heff_strAppend(((V)&g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_str2), v_t_2443));
      V v_t_2445 = ({ V a_0 = v_st_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_acc_241}); V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
      V f_ = v_t_2445;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_lam3, 1, 6, (V[]){v_st_240, v_acc_241, v_rest_246, v_hd_2413, v_k_2414, v_p_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_entry, 8, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(V v_clock_240, V v_st_241, V v_paths_242, V v_changed_243, V v_stamp_244, V v_now_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_clock_240), 1, (V[]){v_t_248}));
  return (g_co_2eop_24s615738393x1686646143(v_t_249, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam0, 1, 8, (V[]){heff_dup(v_st_241), v_paths_242, v_z_246, heff_dup(v_stamp_244), v_clock_240, v_changed_243, v_now_245, heff_dup(v_z_247)})));
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(a[0], a1, a[2], a[3], a4, a[5], a[6], a7); heff_drop(a1); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_paths_242 = heff_env(self)[2];
  V v_changed_243 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_x_2415; V a_5 = v_x_2417; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_241); heff_drop(v_x_2415); heff_drop(v_z_247); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_paths_242 = heff_env(self)[3];
  V v_changed_243 = heff_env(self)[4];
  V v_now_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nil: {
    v_x_2415 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_xs_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    v_x_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  if (heff_strEq_c_lent(v_x_2415, v_stamp_244, 0)) {
    heff_drop(v_x_2415);
    return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_stamp_244; V a_5 = v_now_245; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_241); heff_drop(v_stamp_244); heff_drop(v_z_247); r_; });
  } else {
    heff_drop(v_stamp_244);
    V v_c_2416 = heff_tr(heff_call(heff_dup(v_changed_243), 1, (V[]){v_now_245}));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_z_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam2, 1, 7, (V[]){v_clock_240, v_st_241, v_paths_242, v_changed_243, v_x_2415, v_z_246, v_z_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_paths_242 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_changed_243 = heff_env(self)[5];
  V v_now_245 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  V v_c_2411 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_241, NTAG(TAG_Nil), heff_dup(v_paths_242)));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_lam1, 1, 8, (V[]){v_stamp_244, v_clock_240, v_st_241, v_paths_242, v_changed_243, v_now_245, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}