// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Sleep 25229
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_modified 129625309
#define LBL_size 10026184
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s942716005x1337691863(V, V, V, V);
V g_co_2eop_24s942716005x1337691863_entry(V self, V *a);
extern Clo g_co_2eop_24s942716005x1337691863_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str2, 3, "src");

static V g_heff_2ebuild_2ewatch_2eproject_val;
static HEFF_ONCE g_heff_2ebuild_2ewatch_2eproject_st;
static V g_heff_2ebuild_2ewatch_2eproject_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ewatch_2eproject_str2), v_t_240})});
}
V g_heff_2ebuild_2ewatch_2eproject_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ewatch_2eproject_st)) return g_heff_2ebuild_2ewatch_2eproject_val;
  return heff_global(&g_heff_2ebuild_2ewatch_2eproject_val, &g_heff_2ebuild_2ewatch_2eproject_st, g_heff_2ebuild_2ewatch_2eproject_init);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str2, 1, " ");
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam0(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam1(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam1, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam4(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam4, 3, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam8(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam7(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam7, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam10(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam9(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam6(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam5(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry, 4, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(V v_e_240, V v_st_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_246)));
    V v_lit_249 = heff_dup(v_e_240);
    V v_path_2410 = v_path_248;
    V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
    V v_a_2413 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_2411, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam1_clo)});
    V v_c_2421 = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam2, 2, 2, (V[]){v_a_2413, v_lit_249});
    V v_t_2422 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2426 = heff_tr(heff_call(v_c_2421, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam4_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam5, 2, 6, (V[]){v_c_2426, v_e_240, v_st_241, v_acc_242, v_rest_247, v_p_246});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam1(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_2414, 2), 1, (V[]){v_t_2418}));
    V f_ = heff_get_n(v_hd_2414, 1, 3);
    heff_room[0] = v_t_2419;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_drop_rec(v_hd_2414, 3);
    V f_ = v_k_2415;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_a_2413 = heff_env(self)[0];
  V v_lit_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s942716005x1337691863(v_a_2413, v_lit_249, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam3, 1, 2, (V[]){v_hd_2414, v_k_2415})));
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2441 = (g_list_2emap_24s219049803x1458391381(v_x_2440));
  return heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam8, 2, 1, (V[]){v_x_2441});
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam10(V self, V *args) {
  V v_n_2450 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_p_246));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_2450));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  return ({ V a_0 = v_st_241; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2453); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2427 = heff_env(self)[4];
  V v_k_2428 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Left: {
    heff_take_n(v_x_2445, 0ULL, 1);
    heff_drop(v_p_246);
    V v_t_2447 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(v_e_240, v_st_241, v_acc_242, v_rest_247));
    V f_ = v_t_2447;
    heff_room[0] = v_hd_2427;
    heff_room[1] = v_k_2428;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2448 = heff_field(v_x_2445, 0);
    heff_take_n(v_x_2445, 1ULL, 1);
    V v_t_2449 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str0); V a_3 = v_y_2448; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2454 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_247, heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam10, 1, 2, (V[]){heff_dup(v_st_241), v_p_246}), v_t_2449));
    V v_t_2455 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(v_e_240, v_st_241, v_acc_242, v_t_2454));
    V f_ = v_t_2455;
    heff_room[0] = v_hd_2427;
    heff_room[1] = v_k_2428;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2427 = heff_env(self)[4];
  V v_k_2428 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_drop(v_p_246);
    V v_t_2431 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(v_e_240, v_st_241, v_acc_242, v_rest_247));
    V f_ = v_t_2431;
    heff_room[0] = v_hd_2427;
    heff_room[1] = v_k_2428;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_s_2432 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    V v_kind_2433 = heff_take_field(v_s_2432, 0);
    V v_modified_2434 = heff_take_field(v_s_2432, 2);
    V v_size_2435 = heff_get_n(v_s_2432, 1, 4);
    V v_t_2436;
    switch (heff_tag_of(v_kind_2433)) {
    case TAG_Regular: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_kind_2433);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_modified_2434);
      heff_drop(v_size_2435);
      heff_drop(v_t_2436);
      V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_246)));
      V v_c_2438 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2437));
      V v_t_2439 = (g_exception_2eattempted(heff_dup(v_e_240)));
      V v_c_2444 = heff_tr(heff_call(v_c_2438, 2, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam7_clo)}));
      V f_ = v_c_2444;
      heff_room[0] = heff_dup(v_hd_2427);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam9, 1, 7, (V[]){v_e_240, v_st_241, v_acc_242, v_rest_247, v_hd_2427, v_k_2428, v_p_246});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2436);
      V v_t_2456 = heff_strAppend(heff_strAppend(v_p_246, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str1)), heff_intShow(v_modified_2434));
      V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_str2)), heff_intShow(v_size_2435));
      V v_t_2458 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(v_e_240, v_st_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_acc_242}), v_rest_247));
      V f_ = v_t_2458;
      heff_room[0] = v_hd_2427;
      heff_room[1] = v_k_2428;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam5(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_lam6, 1, 7, (V[]){v_e_240, v_st_241, v_acc_242, v_rest_247, v_hd_2427, v_k_2428, v_p_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_entry, 8, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(V v_e_240, V v_st_241, V v_paths_242, V v_changed_243, V v_stamp_244, V v_now_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_tag_n(TAG_Sleep, 2, (V[]){heff_box_word((((int64_t)250999999ULL) / ((int64_t)1000000ULL))), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam0, 1, 8, (V[]){v_e_240, v_st_241, v_paths_242, v_hd_246, heff_dup(v_stamp_244), v_changed_243, v_now_245, heff_dup(v_k_247)})));
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(a[0], a[1], a[2], a[3], a4, a[5], a[6], a7); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_paths_242 = heff_env(self)[2];
  V v_changed_243 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_x_2417; V a_5 = v_x_2419; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2417); heff_drop(v_k_247); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_paths_242 = heff_env(self)[3];
  V v_changed_243 = heff_env(self)[4];
  V v_now_245 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_xs_2416 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  if (heff_strEq_c_lent(v_x_2417, v_stamp_244, 0)) {
    heff_drop(v_x_2417);
    return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_stamp_244; V a_5 = v_now_245; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_244); heff_drop(v_k_247); r_; });
  } else {
    heff_drop(v_stamp_244);
    V v_c_2418 = heff_tr(heff_call(heff_dup(v_changed_243), 1, (V[]){v_now_245}));
    V f_ = v_c_2418;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam2, 1, 7, (V[]){v_e_240, v_st_241, v_paths_242, v_changed_243, v_x_2417, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_paths_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_stamp_244 = heff_env(self)[4];
  V v_changed_243 = heff_env(self)[5];
  V v_now_245 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2412);
  V v_c_2413 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(heff_dup(v_e_240), heff_dup(v_st_241), NTAG(TAG_Nil), heff_dup(v_paths_242)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_lam1, 1, 8, (V[]){v_stamp_244, v_e_240, v_st_241, v_paths_242, v_changed_243, v_now_245, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}