// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_Tip 31527
#define LBL_numeric 378927440
V g_std_2emap_2ebalance(V, V, V, V);
V g_std_2emap_2ebalance_entry(V self, V *a);
extern Clo g_std_2emap_2ebalance_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2edeleteMin(V);
V g_std_2emap_2edeleteMin_entry(V self, V *a);
extern Clo g_std_2emap_2edeleteMin_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2efindMin_24cpr(V);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
V g_std_2emap_2einsert_24s1733258119x1737094492(V, V, V);
V g_std_2emap_2einsert_24s1733258119x1737094492_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1733258119x1737094492_clo;
V g_std_2emap_2einsert_24s1913725254x907253835(V, V, V);
V g_std_2emap_2einsert_24s1913725254x907253835_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1913725254x907253835_clo;
V g_std_2emap_2einsert_24s389317661x481376749(V, V, V);
V g_std_2emap_2einsert_24s389317661x481376749_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s389317661x481376749_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1702756637x1169753568(V, V);
V g_std_2emap_2elookup_24s1702756637x1169753568_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1702756637x1169753568_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2emapValues(V, V);
V g_std_2emap_2emapValues_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_clo;
V g_std_2emap_2emapValues_24dps(V, V, V);
V g_std_2emap_2emapValues_24dps_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24dps_clo;
V g_std_2emap_2emapValues_24s471823439x1830654496(V);
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo;
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps(V, V);
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_24dps_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

static V g_std_2emap_2eempty_val;
static HEFF_ONCE g_std_2emap_2eempty_st;
static V g_std_2emap_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_std_2emap_2eempty_get(void) {
  if (HEFF_DONE(g_std_2emap_2eempty_st)) return g_std_2emap_2eempty_val;
  return heff_global(&g_std_2emap_2eempty_val, &g_std_2emap_2eempty_st, g_std_2emap_2eempty_init);
}
Clo g_std_2emap_2ebalance_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2ebalance_entry, 4, 0};

V g_std_2emap_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Tip: {
    v_t_249 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_244 = heff_dup(heff_field(v_r_243, 0));
    v_t_249 = v_h_244;
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_t_2415;
  switch (heff_tag_of(v_l_242)) {
  case TAG_Tip: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_2410 = heff_dup(heff_field(v_l_242, 0));
    v_t_2415 = v_h_2410;
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  if (heff_intLt_c(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2415)) {
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      heff_drop(v_k_240);
      heff_drop(v_v_241);
      heff_drop(v_r_243);
      return heff_abandon();
    }
    case TAG_Bin: {
      V v_lk_2418 = heff_field(v_l_242, 1);
      V v_lv_2419 = heff_field(v_l_242, 2);
      V v_ll_2420 = heff_field(v_l_242, 3);
      V v_lr_2421 = heff_field(v_l_242, 4);
      V v_ru_24l_242_24Bin = heff_take_reuse_n(v_l_242, 30ULL, 5);
      V v_t_2427;
      switch (heff_tag_of(v_lr_2421)) {
      case TAG_Tip: {
        v_t_2427 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2422 = heff_dup(heff_field(v_lr_2421, 0));
        v_t_2427 = v_h_2422;
        break;
      }
      default: heff_nomatch(v_lr_2421);
      }
      V v_t_2433;
      switch (heff_tag_of(v_ll_2420)) {
      case TAG_Tip: {
        v_t_2433 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2428 = heff_dup(heff_field(v_ll_2420, 0));
        v_t_2433 = v_h_2428;
        break;
      }
      default: heff_nomatch(v_ll_2420);
      }
      if (heff_intLe_c(v_t_2427, v_t_2433)) {
        V v_x_2440;
        switch (heff_tag_of(v_lr_2421)) {
        case TAG_Tip: {
          v_x_2440 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2435 = heff_dup(heff_field(v_lr_2421, 0));
          v_x_2440 = v_h_2435;
          break;
        }
        default: heff_nomatch(v_lr_2421);
        }
        V v_y_2446;
        switch (heff_tag_of(v_r_243)) {
        case TAG_Tip: {
          v_y_2446 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2441 = heff_dup(heff_field(v_r_243, 0));
          v_y_2446 = v_h_2441;
          break;
        }
        default: heff_nomatch(v_r_243);
        }
        V v_t_2448;
        if (heff_intLe_c_lent(v_x_2440, v_y_2446, 0)) {
          heff_drop(v_x_2440);
          v_t_2448 = v_y_2446;
        } else {
          heff_drop(v_y_2446);
          v_t_2448 = v_x_2440;
        }
        V v_t_2449 = heff_intAdd(MK_INT(1LL), v_t_2448);
        V v_x_2455;
        switch (heff_tag_of(v_ll_2420)) {
        case TAG_Tip: {
          v_x_2455 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2450 = heff_dup(heff_field(v_ll_2420, 0));
          v_x_2455 = v_h_2450;
          break;
        }
        default: heff_nomatch(v_ll_2420);
        }
        V v_t_2457;
        if (heff_intLe_c_lent(v_x_2455, v_t_2449, 0)) {
          heff_drop(v_x_2455);
          v_t_2457 = heff_dup(v_t_2449);
        } else {
          v_t_2457 = v_x_2455;
        }
        return heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2457), v_lk_2418, v_lv_2419, v_ll_2420, heff_tag_n(TAG_Bin, 5, (V[]){v_t_2449, v_k_240, v_v_241, v_lr_2421, v_r_243})});
      } else {
        switch (heff_tag_of(v_lr_2421)) {
        case TAG_Tip: {
          heff_drop(v_k_240);
          heff_drop(v_v_241);
          heff_drop(v_r_243);
          heff_drop(v_lk_2418);
          heff_drop(v_lv_2419);
          heff_drop(v_ll_2420);
          heff_drop_cell(v_ru_24l_242_24Bin, 5);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_mk_2459 = heff_field(v_lr_2421, 1);
          V v_mv_2460 = heff_field(v_lr_2421, 2);
          V v_ml_2461 = heff_field(v_lr_2421, 3);
          V v_mr_2462 = heff_field(v_lr_2421, 4);
          heff_take_n(v_lr_2421, 30ULL, 5);
          V v_x_2468;
          switch (heff_tag_of(v_ll_2420)) {
          case TAG_Tip: {
            v_x_2468 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2463 = heff_dup(heff_field(v_ll_2420, 0));
            v_x_2468 = v_h_2463;
            break;
          }
          default: heff_nomatch(v_ll_2420);
          }
          V v_y_2474;
          switch (heff_tag_of(v_ml_2461)) {
          case TAG_Tip: {
            v_y_2474 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2469 = heff_dup(heff_field(v_ml_2461, 0));
            v_y_2474 = v_h_2469;
            break;
          }
          default: heff_nomatch(v_ml_2461);
          }
          V v_t_2476;
          if (heff_intLe_c_lent(v_x_2468, v_y_2474, 0)) {
            heff_drop(v_x_2468);
            v_t_2476 = v_y_2474;
          } else {
            heff_drop(v_y_2474);
            v_t_2476 = v_x_2468;
          }
          V v_t_2477 = heff_intAdd(MK_INT(1LL), v_t_2476);
          V v_x_2483;
          switch (heff_tag_of(v_mr_2462)) {
          case TAG_Tip: {
            v_x_2483 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2478 = heff_dup(heff_field(v_mr_2462, 0));
            v_x_2483 = v_h_2478;
            break;
          }
          default: heff_nomatch(v_mr_2462);
          }
          V v_y_2489;
          switch (heff_tag_of(v_r_243)) {
          case TAG_Tip: {
            v_y_2489 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2484 = heff_dup(heff_field(v_r_243, 0));
            v_y_2489 = v_h_2484;
            break;
          }
          default: heff_nomatch(v_r_243);
          }
          V v_t_2491;
          if (heff_intLe_c_lent(v_x_2483, v_y_2489, 0)) {
            heff_drop(v_x_2483);
            v_t_2491 = v_y_2489;
          } else {
            heff_drop(v_y_2489);
            v_t_2491 = v_x_2483;
          }
          V v_t_2492 = heff_intAdd(MK_INT(1LL), v_t_2491);
          V v_t_2494;
          if (heff_intLe_c_lent(v_t_2477, v_t_2492, 0)) {
            v_t_2494 = heff_dup(v_t_2492);
          } else {
            v_t_2494 = heff_dup(v_t_2477);
          }
          return heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2494), v_mk_2459, v_mv_2460, heff_tag_n(TAG_Bin, 5, (V[]){v_t_2477, v_lk_2418, v_lv_2419, v_ll_2420, v_ml_2461}), heff_tag_n(TAG_Bin, 5, (V[]){v_t_2492, v_k_240, v_v_241, v_mr_2462, v_r_243})});
        }
        default: return heff_nomatch(v_lr_2421);
        }
      }
    }
    default: return heff_nomatch(v_l_242);
    }
  } else {
    V v_t_24100;
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      v_t_24100 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_2495 = heff_dup(heff_field(v_l_242, 0));
      v_t_24100 = v_h_2495;
      break;
    }
    default: heff_nomatch(v_l_242);
    }
    V v_t_24106;
    switch (heff_tag_of(v_r_243)) {
    case TAG_Tip: {
      v_t_24106 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24101 = heff_dup(heff_field(v_r_243, 0));
      v_t_24106 = v_h_24101;
      break;
    }
    default: heff_nomatch(v_r_243);
    }
    if (heff_intLt_c(heff_intAdd(v_t_24100, MK_INT(1LL)), v_t_24106)) {
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        heff_drop(v_k_240);
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_rk_24109 = heff_field(v_r_243, 1);
        V v_rv_24110 = heff_field(v_r_243, 2);
        V v_rl_24111 = heff_field(v_r_243, 3);
        V v_rr_24112 = heff_field(v_r_243, 4);
        V v_ru_24r_243_24Bin = heff_take_reuse_n(v_r_243, 30ULL, 5);
        V v_t_24118;
        switch (heff_tag_of(v_rl_24111)) {
        case TAG_Tip: {
          v_t_24118 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24113 = heff_dup(heff_field(v_rl_24111, 0));
          v_t_24118 = v_h_24113;
          break;
        }
        default: heff_nomatch(v_rl_24111);
        }
        V v_t_24124;
        switch (heff_tag_of(v_rr_24112)) {
        case TAG_Tip: {
          v_t_24124 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24119 = heff_dup(heff_field(v_rr_24112, 0));
          v_t_24124 = v_h_24119;
          break;
        }
        default: heff_nomatch(v_rr_24112);
        }
        if (heff_intLe_c(v_t_24118, v_t_24124)) {
          V v_x_24131;
          switch (heff_tag_of(v_l_242)) {
          case TAG_Tip: {
            v_x_24131 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24126 = heff_dup(heff_field(v_l_242, 0));
            v_x_24131 = v_h_24126;
            break;
          }
          default: heff_nomatch(v_l_242);
          }
          V v_y_24137;
          switch (heff_tag_of(v_rl_24111)) {
          case TAG_Tip: {
            v_y_24137 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24132 = heff_dup(heff_field(v_rl_24111, 0));
            v_y_24137 = v_h_24132;
            break;
          }
          default: heff_nomatch(v_rl_24111);
          }
          V v_t_24139;
          if (heff_intLe_c_lent(v_x_24131, v_y_24137, 0)) {
            heff_drop(v_x_24131);
            v_t_24139 = v_y_24137;
          } else {
            heff_drop(v_y_24137);
            v_t_24139 = v_x_24131;
          }
          V v_t_24140 = heff_intAdd(MK_INT(1LL), v_t_24139);
          V v_y_24146;
          switch (heff_tag_of(v_rr_24112)) {
          case TAG_Tip: {
            v_y_24146 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24141 = heff_dup(heff_field(v_rr_24112, 0));
            v_y_24146 = v_h_24141;
            break;
          }
          default: heff_nomatch(v_rr_24112);
          }
          V v_t_24148;
          if (heff_intLe_c_lent(v_t_24140, v_y_24146, 0)) {
            v_t_24148 = v_y_24146;
          } else {
            heff_drop(v_y_24146);
            v_t_24148 = heff_dup(v_t_24140);
          }
          return heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24148), v_rk_24109, v_rv_24110, heff_tag_n(TAG_Bin, 5, (V[]){v_t_24140, v_k_240, v_v_241, v_l_242, v_rl_24111}), v_rr_24112});
        } else {
          switch (heff_tag_of(v_rl_24111)) {
          case TAG_Tip: {
            heff_drop(v_k_240);
            heff_drop(v_v_241);
            heff_drop(v_l_242);
            heff_drop(v_rk_24109);
            heff_drop(v_rv_24110);
            heff_drop(v_rr_24112);
            heff_drop_cell(v_ru_24r_243_24Bin, 5);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_24150 = heff_field(v_rl_24111, 1);
            V v_mv_24151 = heff_field(v_rl_24111, 2);
            V v_ml_24152 = heff_field(v_rl_24111, 3);
            V v_mr_24153 = heff_field(v_rl_24111, 4);
            heff_take_n(v_rl_24111, 30ULL, 5);
            V v_x_24159;
            switch (heff_tag_of(v_l_242)) {
            case TAG_Tip: {
              v_x_24159 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24154 = heff_dup(heff_field(v_l_242, 0));
              v_x_24159 = v_h_24154;
              break;
            }
            default: heff_nomatch(v_l_242);
            }
            V v_y_24165;
            switch (heff_tag_of(v_ml_24152)) {
            case TAG_Tip: {
              v_y_24165 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24160 = heff_dup(heff_field(v_ml_24152, 0));
              v_y_24165 = v_h_24160;
              break;
            }
            default: heff_nomatch(v_ml_24152);
            }
            V v_t_24167;
            if (heff_intLe_c_lent(v_x_24159, v_y_24165, 0)) {
              heff_drop(v_x_24159);
              v_t_24167 = v_y_24165;
            } else {
              heff_drop(v_y_24165);
              v_t_24167 = v_x_24159;
            }
            V v_t_24168 = heff_intAdd(MK_INT(1LL), v_t_24167);
            V v_x_24174;
            switch (heff_tag_of(v_mr_24153)) {
            case TAG_Tip: {
              v_x_24174 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24169 = heff_dup(heff_field(v_mr_24153, 0));
              v_x_24174 = v_h_24169;
              break;
            }
            default: heff_nomatch(v_mr_24153);
            }
            V v_y_24180;
            switch (heff_tag_of(v_rr_24112)) {
            case TAG_Tip: {
              v_y_24180 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24175 = heff_dup(heff_field(v_rr_24112, 0));
              v_y_24180 = v_h_24175;
              break;
            }
            default: heff_nomatch(v_rr_24112);
            }
            V v_t_24182;
            if (heff_intLe_c_lent(v_x_24174, v_y_24180, 0)) {
              heff_drop(v_x_24174);
              v_t_24182 = v_y_24180;
            } else {
              heff_drop(v_y_24180);
              v_t_24182 = v_x_24174;
            }
            V v_t_24183 = heff_intAdd(MK_INT(1LL), v_t_24182);
            V v_t_24185;
            if (heff_intLe_c_lent(v_t_24168, v_t_24183, 0)) {
              v_t_24185 = heff_dup(v_t_24183);
            } else {
              v_t_24185 = heff_dup(v_t_24168);
            }
            return heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24185), v_mk_24150, v_mv_24151, heff_tag_n(TAG_Bin, 5, (V[]){v_t_24168, v_k_240, v_v_241, v_l_242, v_ml_24152}), heff_tag_n(TAG_Bin, 5, (V[]){v_t_24183, v_rk_24109, v_rv_24110, v_mr_24153, v_rr_24112})});
          }
          default: return heff_nomatch(v_rl_24111);
          }
        }
      }
      default: return heff_nomatch(v_r_243);
      }
    } else {
      V v_x_24191;
      switch (heff_tag_of(v_l_242)) {
      case TAG_Tip: {
        v_x_24191 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24186 = heff_dup(heff_field(v_l_242, 0));
        v_x_24191 = v_h_24186;
        break;
      }
      default: heff_nomatch(v_l_242);
      }
      V v_y_24197;
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        v_y_24197 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24192 = heff_dup(heff_field(v_r_243, 0));
        v_y_24197 = v_h_24192;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_24199;
      if (heff_intLe_c_lent(v_x_24191, v_y_24197, 0)) {
        heff_drop(v_x_24191);
        v_t_24199 = v_y_24197;
      } else {
        heff_drop(v_y_24197);
        v_t_24199 = v_x_24191;
      }
      return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24199), v_k_240, v_v_241, v_l_242, v_r_243});
    }
  }
}
V g_std_2emap_2ebalance_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2ebalance(a[0], a[1], a[2], a[3]);
}

HeffT2 g_std_2emap_2efindMin_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), heff_dup(v_v_243)})}});
    }
    case TAG_Bin: {
      V t_0 = v_x14_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x14_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2edeleteMin_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2edeleteMin_entry, 1, 0};

V g_std_2emap_2edeleteMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_dup(v_r_245);
    }
    case TAG_Bin: {
      V v_t_2411 = (g_std_2emap_2edeleteMin(v_x14_244));
      return (g_std_2emap_2ebalance(heff_dup(v_x12_242), heff_dup(v_x13_243), v_t_2411, heff_dup(v_r_245)));
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2edeleteMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2edeleteMin(a0); heff_drop(a0); return r;
}
Clo g_std_2emap_2etoListOnto_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2etoListOnto_entry, 2, 0};

V g_std_2emap_2etoListOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = (g_std_2emap_2etoListOnto(v_r_246, v_acc_241));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), v_t_247});
    V t_0 = v_l_245;
    V t_1 = v_t_248;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2etoListOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2etoListOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2emap_2esize_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2esize_entry, 1, 0};

V g_std_2emap_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_std_2emap_2esize(v_l_244));
    V v_t_247 = (g_std_2emap_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2esize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2esize(a0); heff_drop(a0); return r;
}
Clo g_std_2emap_2emapValues_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_entry, 2, 0};

V g_std_2emap_2emapValues(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_241, 0);
    V v_k_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_field(v_x2_241, 2);
    V v_l_245 = heff_field(v_x2_241, 3);
    V v_r_246 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_244}));
    V v_t_248 = (g_std_2emap_2emapValues(heff_dup(v_f_240), v_l_245));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, v_t_247, v_t_248, heff_hole()});
    V v_u_2410 = (g_std_2emap_2emapValues_24dps(v_f_240, v_r_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2emap_2emapValues_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues(a[0], a[1]);
}
Clo g_std_2emap_2emapValues_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24dps_entry, 3, 0};

V g_std_2emap_2emapValues_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x2_241, 0);
    V v_k_244 = heff_field(v_x2_241, 1);
    V v_v_245 = heff_field(v_x2_241, 2);
    V v_l_246 = heff_field(v_x2_241, 3);
    V v_r_247 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_245}));
    V v_t_249 = (g_std_2emap_2emapValues(heff_dup(v_f_240), v_l_246));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_244, v_t_248, v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(4LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_f_240;
    V t_1 = v_r_247;
    V t_2 = v_cell_2410;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2emap_2emapValues_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24dps(a[0], a[1], a[2]);
}
Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s1305793909x1049798133_entry, 3, 0};

V g_std_2emap_2einsert_24s1305793909x1049798133(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_l_246, v_key_241, v_value_242));
      V v_a_2416;
      switch (heff_tag_of(v_l2_2410)) {
      case TAG_Tip: {
        v_a_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2411 = heff_dup(heff_field(v_l2_2410, 0));
        v_a_2416 = v_h_2411;
        break;
      }
      default: heff_nomatch(v_l2_2410);
      }
      V v_b_2422;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2422 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2417 = heff_dup(heff_field(v_r_247, 0));
        v_b_2422 = v_h_2417;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2427;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2422), MK_INT(1LL)), heff_dup(v_a_2416))) {
        heff_drop(v_a_2416);
        heff_drop(v_b_2422);
        v_h_2427 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2416), MK_INT(1LL)), heff_dup(v_b_2422))) {
          heff_drop(v_a_2416);
          heff_drop(v_b_2422);
          v_h_2427 = MK_INT(0LL);
        } else {
          V v_t_2426;
          if (heff_intLe_c_lent(v_a_2416, v_b_2422, 0)) {
            heff_drop(v_a_2416);
            v_t_2426 = v_b_2422;
          } else {
            heff_drop(v_b_2422);
            v_t_2426 = v_a_2416;
          }
          v_h_2427 = heff_intAdd(MK_INT(1LL), v_t_2426);
        }
      }
      if (heff_intEq_c_lent(v_h_2427, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2427);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_2410, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2427, v_k_27_244, v_v_27_245, v_l2_2410, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2430 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_r_247, v_key_241, v_value_242));
        V v_a_2436;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_l_246, 0));
          v_a_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2442;
        switch (heff_tag_of(v_r2_2430)) {
        case TAG_Tip: {
          v_b_2442 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2437 = heff_dup(heff_field(v_r2_2430, 0));
          v_b_2442 = v_h_2437;
          break;
        }
        default: heff_nomatch(v_r2_2430);
        }
        V v_h_2447;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2442), MK_INT(1LL)), heff_dup(v_a_2436))) {
          heff_drop(v_a_2436);
          heff_drop(v_b_2442);
          v_h_2447 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2436), MK_INT(1LL)), heff_dup(v_b_2442))) {
            heff_drop(v_a_2436);
            heff_drop(v_b_2442);
            v_h_2447 = MK_INT(0LL);
          } else {
            V v_t_2446;
            if (heff_intLe_c_lent(v_a_2436, v_b_2442, 0)) {
              heff_drop(v_a_2436);
              v_t_2446 = v_b_2442;
            } else {
              heff_drop(v_b_2442);
              v_t_2446 = v_a_2436;
            }
            v_h_2447 = heff_intAdd(MK_INT(1LL), v_t_2446);
          }
        }
        if (heff_intEq_c_lent(v_h_2447, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2447);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2430));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2447, v_k_27_244, v_v_27_245, v_l_246, v_r2_2430});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s1305793909x1049798133(a[0], a[1], a[2]);
}

HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2elookup_24s1963842891x1660122411_entry, 2, 0};

V g_std_2emap_2elookup_24s1963842891x1660122411(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2emap_2elookup_24s1963842891x1660122411(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2elookup_24s1702756637x1169753568_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2elookup_24s1702756637x1169753568_entry, 2, 0};

V g_std_2emap_2elookup_24s1702756637x1169753568(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2emap_2elookup_24s1702756637x1169753568_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2elookup_24s1702756637x1169753568(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2emap_2edelete_24s339308281x1667047697_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2edelete_24s339308281x1667047697_entry, 2, 0};

V g_std_2emap_2edelete_24s339308281x1667047697(V v_x1_240, V v_key_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 30ULL, 5);
    V v_a_247 = heff_strCompare_lent(v_key_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V v_l2_249 = (g_std_2emap_2edelete_24s339308281x1667047697(v_l_245, v_key_241));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_246)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_246, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_h_2426;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2426 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421))) {
          heff_drop(v_a_2415);
          heff_drop(v_b_2421);
          v_h_2426 = MK_INT(0LL);
        } else {
          V v_t_2425;
          if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
            heff_drop(v_a_2415);
            v_t_2425 = v_b_2421;
          } else {
            heff_drop(v_b_2421);
            v_t_2425 = v_a_2415;
          }
          v_h_2426 = heff_intAdd(MK_INT(1LL), v_t_2425);
        }
      }
      if (heff_intEq_c_lent(v_h_2426, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2426);
        return (g_std_2emap_2ebalance(v_k_27_243, v_v_27_244, v_l2_249, v_r_246));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2426, v_k_27_243, v_v_27_244, v_l2_249, v_r_246});
      }
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_k_27_243);
        heff_drop(v_v_27_244);
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        HeffT2 v_t_2429 = (g_std_2emap_2efindMin_24cpr(v_r_246));
        {
          V v_field_2431 = v_t_2429.f[1];
          int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
          if ((v_tag_2430 == ((int64_t)0ULL))) {
            V v_it1_2433 = v_field_2431;
            switch (heff_tag_of(v_it1_2433)) {
            case TAG_MkPair: {
              V v_k_2434 = heff_field(v_it1_2433, 0);
              V v_v_2435 = heff_field(v_it1_2433, 1);
              heff_take_n(v_it1_2433, 3ULL, 2);
              V v_t_2436 = ({ V a_0 = v_r_246; V r_ = (g_std_2emap_2edeleteMin(a_0)); heff_drop(v_r_246); r_; });
              return (g_std_2emap_2ebalance(v_k_2434, v_v_2435, v_l_245, v_t_2436));
            }
            default: return heff_nomatch(v_it1_2433);
            }
          } else {
            heff_drop(v_r_246);
            heff_drop(v_field_2431);
            return v_l_245;
          }
        }
      } else {
        V v_r2_2437 = (g_std_2emap_2edelete_24s339308281x1667047697(v_r_246, v_key_241));
        V v_a_2443;
        switch (heff_tag_of(v_l_245)) {
        case TAG_Tip: {
          v_a_2443 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2438 = heff_dup(heff_field(v_l_245, 0));
          v_a_2443 = v_h_2438;
          break;
        }
        default: heff_nomatch(v_l_245);
        }
        V v_b_2449;
        switch (heff_tag_of(v_r2_2437)) {
        case TAG_Tip: {
          v_b_2449 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2444 = heff_dup(heff_field(v_r2_2437, 0));
          v_b_2449 = v_h_2444;
          break;
        }
        default: heff_nomatch(v_r2_2437);
        }
        V v_h_2454;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2449), MK_INT(1LL)), heff_dup(v_a_2443))) {
          heff_drop(v_a_2443);
          heff_drop(v_b_2449);
          v_h_2454 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2443), MK_INT(1LL)), heff_dup(v_b_2449))) {
            heff_drop(v_a_2443);
            heff_drop(v_b_2449);
            v_h_2454 = MK_INT(0LL);
          } else {
            V v_t_2453;
            if (heff_intLe_c_lent(v_a_2443, v_b_2449, 0)) {
              heff_drop(v_a_2443);
              v_t_2453 = v_b_2449;
            } else {
              heff_drop(v_b_2449);
              v_t_2453 = v_a_2443;
            }
            v_h_2454 = heff_intAdd(MK_INT(1LL), v_t_2453);
          }
        }
        if (heff_intEq_c_lent(v_h_2454, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2454);
          return (g_std_2emap_2ebalance(v_k_27_243, v_v_27_244, v_l_245, v_r2_2437));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2454, v_k_27_243, v_v_27_244, v_l_245, v_r2_2437});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2emap_2edelete_24s339308281x1667047697(a[0], a1); heff_drop(a1); return r;
}
Clo g_std_2emap_2einsert_24s170109517x1206653089_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s170109517x1206653089_entry, 3, 0};

V g_std_2emap_2einsert_24s170109517x1206653089(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_249 = (g_std_2emap_2einsert_24s170109517x1206653089(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2426;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2426 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421))) {
          heff_drop(v_a_2415);
          heff_drop(v_b_2421);
          v_h_2426 = MK_INT(0LL);
        } else {
          V v_t_2425;
          if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
            heff_drop(v_a_2415);
            v_t_2425 = v_b_2421;
          } else {
            heff_drop(v_b_2421);
            v_t_2425 = v_a_2415;
          }
          v_h_2426 = heff_intAdd(MK_INT(1LL), v_t_2425);
        }
      }
      if (heff_intEq_c_lent(v_h_2426, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2426);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_249, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2426, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2429 = (g_std_2emap_2einsert_24s170109517x1206653089(v_r_247, v_key_241, v_value_242));
        V v_a_2435;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_l_246, 0));
          v_a_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2441;
        switch (heff_tag_of(v_r2_2429)) {
        case TAG_Tip: {
          v_b_2441 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2436 = heff_dup(heff_field(v_r2_2429, 0));
          v_b_2441 = v_h_2436;
          break;
        }
        default: heff_nomatch(v_r2_2429);
        }
        V v_h_2446;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2441), MK_INT(1LL)), heff_dup(v_a_2435))) {
          heff_drop(v_a_2435);
          heff_drop(v_b_2441);
          v_h_2446 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2435), MK_INT(1LL)), heff_dup(v_b_2441))) {
            heff_drop(v_a_2435);
            heff_drop(v_b_2441);
            v_h_2446 = MK_INT(0LL);
          } else {
            V v_t_2445;
            if (heff_intLe_c_lent(v_a_2435, v_b_2441, 0)) {
              heff_drop(v_a_2435);
              v_t_2445 = v_b_2441;
            } else {
              heff_drop(v_b_2441);
              v_t_2445 = v_a_2435;
            }
            v_h_2446 = heff_intAdd(MK_INT(1LL), v_t_2445);
          }
        }
        if (heff_intEq_c_lent(v_h_2446, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2446);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2429));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2446, v_k_27_244, v_v_27_245, v_l_246, v_r2_2429});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s170109517x1206653089(a[0], a[1], a[2]);
}
Clo g_std_2emap_2einsert_24s1913725254x907253835_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s1913725254x907253835_entry, 3, 0};

V g_std_2emap_2einsert_24s1913725254x907253835(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_249 = (g_std_2emap_2einsert_24s1913725254x907253835(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2426;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2426 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421))) {
          heff_drop(v_a_2415);
          heff_drop(v_b_2421);
          v_h_2426 = MK_INT(0LL);
        } else {
          V v_t_2425;
          if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
            heff_drop(v_a_2415);
            v_t_2425 = v_b_2421;
          } else {
            heff_drop(v_b_2421);
            v_t_2425 = v_a_2415;
          }
          v_h_2426 = heff_intAdd(MK_INT(1LL), v_t_2425);
        }
      }
      if (heff_intEq_c_lent(v_h_2426, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2426);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_249, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2426, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2429 = (g_std_2emap_2einsert_24s1913725254x907253835(v_r_247, v_key_241, v_value_242));
        V v_a_2435;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_l_246, 0));
          v_a_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2441;
        switch (heff_tag_of(v_r2_2429)) {
        case TAG_Tip: {
          v_b_2441 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2436 = heff_dup(heff_field(v_r2_2429, 0));
          v_b_2441 = v_h_2436;
          break;
        }
        default: heff_nomatch(v_r2_2429);
        }
        V v_h_2446;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2441), MK_INT(1LL)), heff_dup(v_a_2435))) {
          heff_drop(v_a_2435);
          heff_drop(v_b_2441);
          v_h_2446 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2435), MK_INT(1LL)), heff_dup(v_b_2441))) {
            heff_drop(v_a_2435);
            heff_drop(v_b_2441);
            v_h_2446 = MK_INT(0LL);
          } else {
            V v_t_2445;
            if (heff_intLe_c_lent(v_a_2435, v_b_2441, 0)) {
              heff_drop(v_a_2435);
              v_t_2445 = v_b_2441;
            } else {
              heff_drop(v_b_2441);
              v_t_2445 = v_a_2435;
            }
            v_h_2446 = heff_intAdd(MK_INT(1LL), v_t_2445);
          }
        }
        if (heff_intEq_c_lent(v_h_2446, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2446);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2429));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2446, v_k_27_244, v_v_27_245, v_l_246, v_r2_2429});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s1913725254x907253835_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s1913725254x907253835(a[0], a[1], a[2]);
}
Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24s471823439x1830654496_entry, 1, 0};

V g_std_2emap_2emapValues_24s471823439x1830654496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_241 = heff_field(v_x2_240, 0);
    V v_k_242 = heff_field(v_x2_240, 1);
    V v_v_243 = heff_field(v_x2_240, 2);
    V v_l_244 = heff_field(v_x2_240, 3);
    V v_r_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_246 = (g_std_2emap_2emapValues_24s471823439x1830654496(v_l_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_241, v_k_242, heff_get_n(v_v_243, 1, 3), v_t_246, heff_hole()});
    V v_u_248 = (g_std_2emap_2emapValues_24s471823439x1830654496_24dps(v_r_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24s471823439x1830654496(a[0]);
}
Clo g_std_2emap_2emapValues_24s471823439x1830654496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry, 2, 0};

V g_std_2emap_2emapValues_24s471823439x1830654496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return heff_setField(v_d_241, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_240, 0);
    V v_k_243 = heff_field(v_x2_240, 1);
    V v_v_244 = heff_field(v_x2_240, 2);
    V v_l_245 = heff_field(v_x2_240, 3);
    V v_r_246 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_247 = (g_std_2emap_2emapValues_24s471823439x1830654496(v_l_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, heff_get_n(v_v_244, 1, 3), v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(4LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_r_246;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24s471823439x1830654496_24dps(a[0], a[1]);
}
Clo g_std_2emap_2einsert_24s389317661x481376749_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s389317661x481376749_entry, 3, 0};

V g_std_2emap_2einsert_24s389317661x481376749(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_2410 = (g_std_2emap_2einsert_24s389317661x481376749(v_l_246, v_key_241, v_value_242));
      V v_a_2416;
      switch (heff_tag_of(v_l2_2410)) {
      case TAG_Tip: {
        v_a_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2411 = heff_dup(heff_field(v_l2_2410, 0));
        v_a_2416 = v_h_2411;
        break;
      }
      default: heff_nomatch(v_l2_2410);
      }
      V v_b_2422;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2422 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2417 = heff_dup(heff_field(v_r_247, 0));
        v_b_2422 = v_h_2417;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2427;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2422), MK_INT(1LL)), heff_dup(v_a_2416))) {
        heff_drop(v_a_2416);
        heff_drop(v_b_2422);
        v_h_2427 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2416), MK_INT(1LL)), heff_dup(v_b_2422))) {
          heff_drop(v_a_2416);
          heff_drop(v_b_2422);
          v_h_2427 = MK_INT(0LL);
        } else {
          V v_t_2426;
          if (heff_intLe_c_lent(v_a_2416, v_b_2422, 0)) {
            heff_drop(v_a_2416);
            v_t_2426 = v_b_2422;
          } else {
            heff_drop(v_b_2422);
            v_t_2426 = v_a_2416;
          }
          v_h_2427 = heff_intAdd(MK_INT(1LL), v_t_2426);
        }
      }
      if (heff_intEq_c_lent(v_h_2427, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2427);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_2410, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2427, v_k_27_244, v_v_27_245, v_l2_2410, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2430 = (g_std_2emap_2einsert_24s389317661x481376749(v_r_247, v_key_241, v_value_242));
        V v_a_2436;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_l_246, 0));
          v_a_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2442;
        switch (heff_tag_of(v_r2_2430)) {
        case TAG_Tip: {
          v_b_2442 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2437 = heff_dup(heff_field(v_r2_2430, 0));
          v_b_2442 = v_h_2437;
          break;
        }
        default: heff_nomatch(v_r2_2430);
        }
        V v_h_2447;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2442), MK_INT(1LL)), heff_dup(v_a_2436))) {
          heff_drop(v_a_2436);
          heff_drop(v_b_2442);
          v_h_2447 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2436), MK_INT(1LL)), heff_dup(v_b_2442))) {
            heff_drop(v_a_2436);
            heff_drop(v_b_2442);
            v_h_2447 = MK_INT(0LL);
          } else {
            V v_t_2446;
            if (heff_intLe_c_lent(v_a_2436, v_b_2442, 0)) {
              heff_drop(v_a_2436);
              v_t_2446 = v_b_2442;
            } else {
              heff_drop(v_b_2442);
              v_t_2446 = v_a_2436;
            }
            v_h_2447 = heff_intAdd(MK_INT(1LL), v_t_2446);
          }
        }
        if (heff_intEq_c_lent(v_h_2447, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2447);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2430));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2447, v_k_27_244, v_v_27_245, v_l_246, v_r2_2430});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s389317661x481376749_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s389317661x481376749(a[0], a[1], a[2]);
}

HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_std_2emap_2einsert_24s1733258119x1737094492_lam0(V self, V *args);
V g_std_2emap_2einsert_24s1733258119x1737094492_lam1(V self, V *args);
Clo g_std_2emap_2einsert_24s1733258119x1737094492_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s1733258119x1737094492_entry, 3, 0};

V g_std_2emap_2einsert_24s1733258119x1737094492(V v_lit_240, V v_x1_241, V v_key_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_242, heff_clo_n(g_std_2emap_2einsert_24s1733258119x1737094492_lam0, 1, 1, (V[]){v_lit_240}), NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_244 = heff_field(v_x1_241, 0);
    V v_k_27_245 = heff_field(v_x1_241, 1);
    V v_v_27_246 = heff_field(v_x1_241, 2);
    V v_l_247 = heff_field(v_x1_241, 3);
    V v_r_248 = heff_field(v_x1_241, 4);
    V v_ru_24x1_241_24Bin = heff_take_reuse_n(v_x1_241, 31ULL, 5);
    V v_a_249 = heff_strCompare_lent(v_key_242, v_k_27_245, 0);
    if (heff_intLt_c_lent(v_a_249, MK_INT(0LL), 2)) {
      heff_drop(v_h_244);
      heff_drop(v_a_249);
      V v_l2_2411 = (g_std_2emap_2einsert_24s1733258119x1737094492(v_lit_240, v_l_247, v_key_242));
      V v_a_2417;
      switch (heff_tag_of(v_l2_2411)) {
      case TAG_Tip: {
        v_a_2417 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2412 = heff_dup(heff_field(v_l2_2411, 0));
        v_a_2417 = v_h_2412;
        break;
      }
      default: heff_nomatch(v_l2_2411);
      }
      V v_b_2423;
      switch (heff_tag_of(v_r_248)) {
      case TAG_Tip: {
        v_b_2423 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2418 = heff_dup(heff_field(v_r_248, 0));
        v_b_2423 = v_h_2418;
        break;
      }
      default: heff_nomatch(v_r_248);
      }
      V v_h_2428;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2423), MK_INT(1LL)), heff_dup(v_a_2417))) {
        heff_drop(v_a_2417);
        heff_drop(v_b_2423);
        v_h_2428 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2417), MK_INT(1LL)), heff_dup(v_b_2423))) {
          heff_drop(v_a_2417);
          heff_drop(v_b_2423);
          v_h_2428 = MK_INT(0LL);
        } else {
          V v_t_2427;
          if (heff_intLe_c_lent(v_a_2417, v_b_2423, 0)) {
            heff_drop(v_a_2417);
            v_t_2427 = v_b_2423;
          } else {
            heff_drop(v_b_2423);
            v_t_2427 = v_a_2417;
          }
          v_h_2428 = heff_intAdd(MK_INT(1LL), v_t_2427);
        }
      }
      if (heff_intEq_c_lent(v_h_2428, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_241_24Bin, 5);
        heff_drop(v_h_2428);
        return (g_std_2emap_2ebalance(v_k_27_245, v_v_27_246, v_l2_2411, v_r_248));
      } else {
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2428, v_k_27_245, v_v_27_246, v_l2_2411, v_r_248});
      }
    } else {
      if (heff_intEq_c(v_a_249, MK_INT(0LL))) {
        heff_drop(v_k_27_245);
        heff_drop(v_v_27_246);
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_244, v_key_242, heff_clo_n(g_std_2emap_2einsert_24s1733258119x1737094492_lam1, 1, 1, (V[]){v_lit_240}), v_l_247, v_r_248});
      } else {
        heff_drop(v_h_244);
        V v_r2_2432 = (g_std_2emap_2einsert_24s1733258119x1737094492(v_lit_240, v_r_248, v_key_242));
        V v_a_2438;
        switch (heff_tag_of(v_l_247)) {
        case TAG_Tip: {
          v_a_2438 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2433 = heff_dup(heff_field(v_l_247, 0));
          v_a_2438 = v_h_2433;
          break;
        }
        default: heff_nomatch(v_l_247);
        }
        V v_b_2444;
        switch (heff_tag_of(v_r2_2432)) {
        case TAG_Tip: {
          v_b_2444 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2439 = heff_dup(heff_field(v_r2_2432, 0));
          v_b_2444 = v_h_2439;
          break;
        }
        default: heff_nomatch(v_r2_2432);
        }
        V v_h_2449;
        if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2444), MK_INT(1LL)), heff_dup(v_a_2438))) {
          heff_drop(v_a_2438);
          heff_drop(v_b_2444);
          v_h_2449 = MK_INT(0LL);
        } else {
          if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2438), MK_INT(1LL)), heff_dup(v_b_2444))) {
            heff_drop(v_a_2438);
            heff_drop(v_b_2444);
            v_h_2449 = MK_INT(0LL);
          } else {
            V v_t_2448;
            if (heff_intLe_c_lent(v_a_2438, v_b_2444, 0)) {
              heff_drop(v_a_2438);
              v_t_2448 = v_b_2444;
            } else {
              heff_drop(v_b_2444);
              v_t_2448 = v_a_2438;
            }
            v_h_2449 = heff_intAdd(MK_INT(1LL), v_t_2448);
          }
        }
        if (heff_intEq_c_lent(v_h_2449, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_241_24Bin, 5);
          heff_drop(v_h_2449);
          return (g_std_2emap_2ebalance(v_k_27_245, v_v_27_246, v_l_247, v_r2_2432));
        } else {
          return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2449, v_k_27_245, v_v_27_246, v_l_247, v_r2_2432});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2emap_2einsert_24s1733258119x1737094492_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s1733258119x1737094492(a[0], a[1], a[2]);
}
V g_std_2emap_2einsert_24s1733258119x1737094492_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_243);
  return v_lit_240;
}
V g_std_2emap_2einsert_24s1733258119x1737094492_lam1(V self, V *args) {
  V v_a_2431 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2431);
  return v_lit_240;
}