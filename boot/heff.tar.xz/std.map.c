// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_Tip 31527
#define LBL_numeric 378927440
V g_std_2emap_2ebalance(V, V, V, V);
V g_std_2emap_2ebalance_entry(V self, V *a);
extern Clo g_std_2emap_2ebalance_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2edeleteMin(V);
V g_std_2emap_2edeleteMin_entry(V self, V *a);
extern Clo g_std_2emap_2edeleteMin_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2efindMin_24cpr(V);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
V g_std_2emap_2einsert_24s1863973822x2117969067(V, V, V);
V g_std_2emap_2einsert_24s1863973822x2117969067_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1863973822x2117969067_clo;
V g_std_2emap_2einsert_24s1913725254x907253835(V, V, V);
V g_std_2emap_2einsert_24s1913725254x907253835_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1913725254x907253835_clo;
V g_std_2emap_2einsert_24s738816132x592703192(V, V, V);
V g_std_2emap_2einsert_24s738816132x592703192_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s738816132x592703192_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
V g_std_2emap_2elookup_24s1702756637x1169753568(V, V);
V g_std_2emap_2elookup_24s1702756637x1169753568_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1702756637x1169753568_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2emapValues(V, V);
V g_std_2emap_2emapValues_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_clo;
V g_std_2emap_2emapValues_24dps(V, V, V);
V g_std_2emap_2emapValues_24dps_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24dps_clo;
V g_std_2emap_2emapValues_24s471823439x1830654496(V);
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo;
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps(V, V);
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_24dps_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

static V g_std_2emap_2eempty_val;
static HEFF_ONCE g_std_2emap_2eempty_st;
static V g_std_2emap_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_std_2emap_2eempty_get(void) {
  if (HEFF_DONE(g_std_2emap_2eempty_st)) return g_std_2emap_2eempty_val;
  return heff_global(&g_std_2emap_2eempty_val, &g_std_2emap_2eempty_st, g_std_2emap_2eempty_init);
}
Clo g_std_2emap_2ebalance_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2ebalance_entry, 4, 0};

V g_std_2emap_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Tip: {
    v_t_249 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_244 = heff_dup(heff_field(v_r_243, 0));
    v_t_249 = v_h_244;
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_t_2415;
  switch (heff_tag_of(v_l_242)) {
  case TAG_Tip: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_2410 = heff_dup(heff_field(v_l_242, 0));
    v_t_2415 = v_h_2410;
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  if (heff_intLt_c(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2415)) {
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      heff_drop(v_k_240);
      heff_drop(v_v_241);
      heff_drop(v_r_243);
      return heff_abandon();
    }
    case TAG_Bin: {
      V v_lk_2417 = heff_field(v_l_242, 1);
      V v_lv_2418 = heff_field(v_l_242, 2);
      V v_ll_2419 = heff_field(v_l_242, 3);
      V v_lr_2420 = heff_field(v_l_242, 4);
      V v_ru_24l_242_24Bin = heff_take_reuse_n(v_l_242, 30ULL, 5);
      V v_t_2426;
      switch (heff_tag_of(v_lr_2420)) {
      case TAG_Tip: {
        v_t_2426 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2421 = heff_dup(heff_field(v_lr_2420, 0));
        v_t_2426 = v_h_2421;
        break;
      }
      default: heff_nomatch(v_lr_2420);
      }
      V v_t_2432;
      switch (heff_tag_of(v_ll_2419)) {
      case TAG_Tip: {
        v_t_2432 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2427 = heff_dup(heff_field(v_ll_2419, 0));
        v_t_2432 = v_h_2427;
        break;
      }
      default: heff_nomatch(v_ll_2419);
      }
      if (heff_intLe_c(v_t_2426, v_t_2432)) {
        V v_x_2438;
        switch (heff_tag_of(v_lr_2420)) {
        case TAG_Tip: {
          v_x_2438 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2433 = heff_dup(heff_field(v_lr_2420, 0));
          v_x_2438 = v_h_2433;
          break;
        }
        default: heff_nomatch(v_lr_2420);
        }
        V v_y_2444;
        switch (heff_tag_of(v_r_243)) {
        case TAG_Tip: {
          v_y_2444 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2439 = heff_dup(heff_field(v_r_243, 0));
          v_y_2444 = v_h_2439;
          break;
        }
        default: heff_nomatch(v_r_243);
        }
        V v_t_2445;
        if (heff_intLe_c_lent(v_x_2438, v_y_2444, 0)) {
          heff_drop(v_x_2438);
          v_t_2445 = v_y_2444;
        } else {
          heff_drop(v_y_2444);
          v_t_2445 = v_x_2438;
        }
        V v_t_2446 = heff_intAdd(MK_INT(1LL), v_t_2445);
        V v_x_2452;
        switch (heff_tag_of(v_ll_2419)) {
        case TAG_Tip: {
          v_x_2452 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2447 = heff_dup(heff_field(v_ll_2419, 0));
          v_x_2452 = v_h_2447;
          break;
        }
        default: heff_nomatch(v_ll_2419);
        }
        V v_t_2453;
        if (heff_intLe_c_lent(v_x_2452, v_t_2446, 0)) {
          heff_drop(v_x_2452);
          v_t_2453 = heff_dup(v_t_2446);
        } else {
          v_t_2453 = v_x_2452;
        }
        return heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2453), v_lk_2417, v_lv_2418, v_ll_2419, heff_tag_n(TAG_Bin, 5, (V[]){v_t_2446, v_k_240, v_v_241, v_lr_2420, v_r_243})});
      } else {
        switch (heff_tag_of(v_lr_2420)) {
        case TAG_Tip: {
          heff_drop(v_k_240);
          heff_drop(v_v_241);
          heff_drop(v_r_243);
          heff_drop(v_lk_2417);
          heff_drop(v_lv_2418);
          heff_drop(v_ll_2419);
          heff_drop_cell(v_ru_24l_242_24Bin, 5);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_mk_2455 = heff_field(v_lr_2420, 1);
          V v_mv_2456 = heff_field(v_lr_2420, 2);
          V v_ml_2457 = heff_field(v_lr_2420, 3);
          V v_mr_2458 = heff_field(v_lr_2420, 4);
          heff_take_n(v_lr_2420, 30ULL, 5);
          V v_x_2464;
          switch (heff_tag_of(v_ll_2419)) {
          case TAG_Tip: {
            v_x_2464 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2459 = heff_dup(heff_field(v_ll_2419, 0));
            v_x_2464 = v_h_2459;
            break;
          }
          default: heff_nomatch(v_ll_2419);
          }
          V v_y_2470;
          switch (heff_tag_of(v_ml_2457)) {
          case TAG_Tip: {
            v_y_2470 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2465 = heff_dup(heff_field(v_ml_2457, 0));
            v_y_2470 = v_h_2465;
            break;
          }
          default: heff_nomatch(v_ml_2457);
          }
          V v_t_2471;
          if (heff_intLe_c_lent(v_x_2464, v_y_2470, 0)) {
            heff_drop(v_x_2464);
            v_t_2471 = v_y_2470;
          } else {
            heff_drop(v_y_2470);
            v_t_2471 = v_x_2464;
          }
          V v_t_2472 = heff_intAdd(MK_INT(1LL), v_t_2471);
          V v_x_2478;
          switch (heff_tag_of(v_mr_2458)) {
          case TAG_Tip: {
            v_x_2478 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2473 = heff_dup(heff_field(v_mr_2458, 0));
            v_x_2478 = v_h_2473;
            break;
          }
          default: heff_nomatch(v_mr_2458);
          }
          V v_y_2484;
          switch (heff_tag_of(v_r_243)) {
          case TAG_Tip: {
            v_y_2484 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2479 = heff_dup(heff_field(v_r_243, 0));
            v_y_2484 = v_h_2479;
            break;
          }
          default: heff_nomatch(v_r_243);
          }
          V v_t_2485;
          if (heff_intLe_c_lent(v_x_2478, v_y_2484, 0)) {
            heff_drop(v_x_2478);
            v_t_2485 = v_y_2484;
          } else {
            heff_drop(v_y_2484);
            v_t_2485 = v_x_2478;
          }
          V v_t_2486 = heff_intAdd(MK_INT(1LL), v_t_2485);
          V v_t_2487;
          if (heff_intLe_c_lent(v_t_2472, v_t_2486, 0)) {
            v_t_2487 = heff_dup(v_t_2486);
          } else {
            v_t_2487 = heff_dup(v_t_2472);
          }
          return heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2487), v_mk_2455, v_mv_2456, heff_tag_n(TAG_Bin, 5, (V[]){v_t_2472, v_lk_2417, v_lv_2418, v_ll_2419, v_ml_2457}), heff_tag_n(TAG_Bin, 5, (V[]){v_t_2486, v_k_240, v_v_241, v_mr_2458, v_r_243})});
        }
        default: return heff_nomatch(v_lr_2420);
        }
      }
    }
    default: return heff_nomatch(v_l_242);
    }
  } else {
    V v_t_2493;
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      v_t_2493 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_2488 = heff_dup(heff_field(v_l_242, 0));
      v_t_2493 = v_h_2488;
      break;
    }
    default: heff_nomatch(v_l_242);
    }
    V v_t_2499;
    switch (heff_tag_of(v_r_243)) {
    case TAG_Tip: {
      v_t_2499 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_2494 = heff_dup(heff_field(v_r_243, 0));
      v_t_2499 = v_h_2494;
      break;
    }
    default: heff_nomatch(v_r_243);
    }
    if (heff_intLt_c(heff_intAdd(v_t_2493, MK_INT(1LL)), v_t_2499)) {
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        heff_drop(v_k_240);
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_rk_24101 = heff_field(v_r_243, 1);
        V v_rv_24102 = heff_field(v_r_243, 2);
        V v_rl_24103 = heff_field(v_r_243, 3);
        V v_rr_24104 = heff_field(v_r_243, 4);
        V v_ru_24r_243_24Bin = heff_take_reuse_n(v_r_243, 30ULL, 5);
        V v_t_24110;
        switch (heff_tag_of(v_rl_24103)) {
        case TAG_Tip: {
          v_t_24110 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24105 = heff_dup(heff_field(v_rl_24103, 0));
          v_t_24110 = v_h_24105;
          break;
        }
        default: heff_nomatch(v_rl_24103);
        }
        V v_t_24116;
        switch (heff_tag_of(v_rr_24104)) {
        case TAG_Tip: {
          v_t_24116 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24111 = heff_dup(heff_field(v_rr_24104, 0));
          v_t_24116 = v_h_24111;
          break;
        }
        default: heff_nomatch(v_rr_24104);
        }
        if (heff_intLe_c(v_t_24110, v_t_24116)) {
          V v_x_24122;
          switch (heff_tag_of(v_l_242)) {
          case TAG_Tip: {
            v_x_24122 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24117 = heff_dup(heff_field(v_l_242, 0));
            v_x_24122 = v_h_24117;
            break;
          }
          default: heff_nomatch(v_l_242);
          }
          V v_y_24128;
          switch (heff_tag_of(v_rl_24103)) {
          case TAG_Tip: {
            v_y_24128 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24123 = heff_dup(heff_field(v_rl_24103, 0));
            v_y_24128 = v_h_24123;
            break;
          }
          default: heff_nomatch(v_rl_24103);
          }
          V v_t_24129;
          if (heff_intLe_c_lent(v_x_24122, v_y_24128, 0)) {
            heff_drop(v_x_24122);
            v_t_24129 = v_y_24128;
          } else {
            heff_drop(v_y_24128);
            v_t_24129 = v_x_24122;
          }
          V v_t_24130 = heff_intAdd(MK_INT(1LL), v_t_24129);
          V v_y_24136;
          switch (heff_tag_of(v_rr_24104)) {
          case TAG_Tip: {
            v_y_24136 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24131 = heff_dup(heff_field(v_rr_24104, 0));
            v_y_24136 = v_h_24131;
            break;
          }
          default: heff_nomatch(v_rr_24104);
          }
          V v_t_24137;
          if (heff_intLe_c_lent(v_t_24130, v_y_24136, 0)) {
            v_t_24137 = v_y_24136;
          } else {
            heff_drop(v_y_24136);
            v_t_24137 = heff_dup(v_t_24130);
          }
          return heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24137), v_rk_24101, v_rv_24102, heff_tag_n(TAG_Bin, 5, (V[]){v_t_24130, v_k_240, v_v_241, v_l_242, v_rl_24103}), v_rr_24104});
        } else {
          switch (heff_tag_of(v_rl_24103)) {
          case TAG_Tip: {
            heff_drop(v_k_240);
            heff_drop(v_v_241);
            heff_drop(v_l_242);
            heff_drop(v_rk_24101);
            heff_drop(v_rv_24102);
            heff_drop(v_rr_24104);
            heff_drop_cell(v_ru_24r_243_24Bin, 5);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_24139 = heff_field(v_rl_24103, 1);
            V v_mv_24140 = heff_field(v_rl_24103, 2);
            V v_ml_24141 = heff_field(v_rl_24103, 3);
            V v_mr_24142 = heff_field(v_rl_24103, 4);
            heff_take_n(v_rl_24103, 30ULL, 5);
            V v_x_24148;
            switch (heff_tag_of(v_l_242)) {
            case TAG_Tip: {
              v_x_24148 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24143 = heff_dup(heff_field(v_l_242, 0));
              v_x_24148 = v_h_24143;
              break;
            }
            default: heff_nomatch(v_l_242);
            }
            V v_y_24154;
            switch (heff_tag_of(v_ml_24141)) {
            case TAG_Tip: {
              v_y_24154 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24149 = heff_dup(heff_field(v_ml_24141, 0));
              v_y_24154 = v_h_24149;
              break;
            }
            default: heff_nomatch(v_ml_24141);
            }
            V v_t_24155;
            if (heff_intLe_c_lent(v_x_24148, v_y_24154, 0)) {
              heff_drop(v_x_24148);
              v_t_24155 = v_y_24154;
            } else {
              heff_drop(v_y_24154);
              v_t_24155 = v_x_24148;
            }
            V v_t_24156 = heff_intAdd(MK_INT(1LL), v_t_24155);
            V v_x_24162;
            switch (heff_tag_of(v_mr_24142)) {
            case TAG_Tip: {
              v_x_24162 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24157 = heff_dup(heff_field(v_mr_24142, 0));
              v_x_24162 = v_h_24157;
              break;
            }
            default: heff_nomatch(v_mr_24142);
            }
            V v_y_24168;
            switch (heff_tag_of(v_rr_24104)) {
            case TAG_Tip: {
              v_y_24168 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24163 = heff_dup(heff_field(v_rr_24104, 0));
              v_y_24168 = v_h_24163;
              break;
            }
            default: heff_nomatch(v_rr_24104);
            }
            V v_t_24169;
            if (heff_intLe_c_lent(v_x_24162, v_y_24168, 0)) {
              heff_drop(v_x_24162);
              v_t_24169 = v_y_24168;
            } else {
              heff_drop(v_y_24168);
              v_t_24169 = v_x_24162;
            }
            V v_t_24170 = heff_intAdd(MK_INT(1LL), v_t_24169);
            V v_t_24171;
            if (heff_intLe_c_lent(v_t_24156, v_t_24170, 0)) {
              v_t_24171 = heff_dup(v_t_24170);
            } else {
              v_t_24171 = heff_dup(v_t_24156);
            }
            return heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24171), v_mk_24139, v_mv_24140, heff_tag_n(TAG_Bin, 5, (V[]){v_t_24156, v_k_240, v_v_241, v_l_242, v_ml_24141}), heff_tag_n(TAG_Bin, 5, (V[]){v_t_24170, v_rk_24101, v_rv_24102, v_mr_24142, v_rr_24104})});
          }
          default: return heff_nomatch(v_rl_24103);
          }
        }
      }
      default: return heff_nomatch(v_r_243);
      }
    } else {
      V v_x_24177;
      switch (heff_tag_of(v_l_242)) {
      case TAG_Tip: {
        v_x_24177 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24172 = heff_dup(heff_field(v_l_242, 0));
        v_x_24177 = v_h_24172;
        break;
      }
      default: heff_nomatch(v_l_242);
      }
      V v_y_24183;
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        v_y_24183 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24178 = heff_dup(heff_field(v_r_243, 0));
        v_y_24183 = v_h_24178;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_24184;
      if (heff_intLe_c_lent(v_x_24177, v_y_24183, 0)) {
        heff_drop(v_x_24177);
        v_t_24184 = v_y_24183;
      } else {
        heff_drop(v_y_24183);
        v_t_24184 = v_x_24177;
      }
      return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24184), v_k_240, v_v_241, v_l_242, v_r_243});
    }
  }
}
V g_std_2emap_2ebalance_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2ebalance(a[0], a[1], a[2], a[3]);
}

HeffT2 g_std_2emap_2efindMin_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), heff_dup(v_v_243)})}});
    }
    case TAG_Bin: {
      V t_0 = v_x14_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x14_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2edeleteMin_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2edeleteMin_entry, 1, 0};

V g_std_2emap_2edeleteMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_dup(v_r_245);
    }
    case TAG_Bin: {
      V v_t_2411 = (g_std_2emap_2edeleteMin(v_x14_244));
      return (g_std_2emap_2ebalance(heff_dup(v_x12_242), heff_dup(v_x13_243), v_t_2411, heff_dup(v_r_245)));
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2edeleteMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2edeleteMin(a0); heff_drop(a0); return r;
}
Clo g_std_2emap_2etoListOnto_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2etoListOnto_entry, 2, 0};

V g_std_2emap_2etoListOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = (g_std_2emap_2etoListOnto(v_r_246, v_acc_241));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), v_t_247});
    V t_0 = v_l_245;
    V t_1 = v_t_248;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2etoListOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2etoListOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2emap_2esize_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2esize_entry, 1, 0};

V g_std_2emap_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_std_2emap_2esize(v_l_244));
    V v_t_247 = (g_std_2emap_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2esize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2esize(a0); heff_drop(a0); return r;
}
Clo g_std_2emap_2emapValues_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_entry, 2, 0};

V g_std_2emap_2emapValues(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_241, 0);
    V v_k_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_field(v_x2_241, 2);
    V v_l_245 = heff_field(v_x2_241, 3);
    V v_r_246 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_244}));
    V v_t_248 = (g_std_2emap_2emapValues(heff_dup(v_f_240), v_l_245));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, v_t_247, v_t_248, heff_hole()});
    V v_u_2410 = (g_std_2emap_2emapValues_24dps(v_f_240, v_r_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2emap_2emapValues_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues(a[0], a[1]);
}
Clo g_std_2emap_2emapValues_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24dps_entry, 3, 0};

V g_std_2emap_2emapValues_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x2_241, 0);
    V v_k_244 = heff_field(v_x2_241, 1);
    V v_v_245 = heff_field(v_x2_241, 2);
    V v_l_246 = heff_field(v_x2_241, 3);
    V v_r_247 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_245}));
    V v_t_249 = (g_std_2emap_2emapValues(heff_dup(v_f_240), v_l_246));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_244, v_t_248, v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(4LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_f_240;
    V t_1 = v_r_247;
    V t_2 = v_cell_2410;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2emap_2emapValues_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24dps(a[0], a[1], a[2]);
}
Clo g_std_2emap_2einsert_24s93785294x875597928_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s93785294x875597928_entry, 3, 0};

V g_std_2emap_2einsert_24s93785294x875597928(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_249 = (g_std_2emap_2einsert_24s93785294x875597928(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2423;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421)))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2423 = MK_INT(0LL);
      } else {
        V v_t_2422;
        if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
          heff_drop(v_a_2415);
          v_t_2422 = v_b_2421;
        } else {
          heff_drop(v_b_2421);
          v_t_2422 = v_a_2415;
        }
        v_h_2423 = heff_intAdd(MK_INT(1LL), v_t_2422);
      }
      if (heff_intEq_c_lent(v_h_2423, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2423);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_249, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2423, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2424 = (g_std_2emap_2einsert_24s93785294x875597928(v_r_247, v_key_241, v_value_242));
        V v_a_2430;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2430 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2425 = heff_dup(heff_field(v_l_246, 0));
          v_a_2430 = v_h_2425;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2436;
        switch (heff_tag_of(v_r2_2424)) {
        case TAG_Tip: {
          v_b_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_r2_2424, 0));
          v_b_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_r2_2424);
        }
        V v_h_2438;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2436), MK_INT(1LL)), heff_dup(v_a_2430)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2430), MK_INT(1LL)), heff_dup(v_b_2436)))) {
          heff_drop(v_a_2430);
          heff_drop(v_b_2436);
          v_h_2438 = MK_INT(0LL);
        } else {
          V v_t_2437;
          if (heff_intLe_c_lent(v_a_2430, v_b_2436, 0)) {
            heff_drop(v_a_2430);
            v_t_2437 = v_b_2436;
          } else {
            heff_drop(v_b_2436);
            v_t_2437 = v_a_2430;
          }
          v_h_2438 = heff_intAdd(MK_INT(1LL), v_t_2437);
        }
        if (heff_intEq_c_lent(v_h_2438, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2438);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2424));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2438, v_k_27_244, v_v_27_245, v_l_246, v_r2_2424});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s93785294x875597928(a[0], a[1], a[2]);
}

HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2elookup_24s1930949324x2078207031_entry, 2, 0};

V g_std_2emap_2elookup_24s1930949324x2078207031(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2emap_2elookup_24s1930949324x2078207031(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2emap_2elookup_24s1702756637x1169753568_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2elookup_24s1702756637x1169753568_entry, 2, 0};

V g_std_2emap_2elookup_24s1702756637x1169753568(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2emap_2elookup_24s1702756637x1169753568_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2emap_2elookup_24s1702756637x1169753568(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2edelete_24s1614046289x1611773644_entry, 2, 0};

V g_std_2emap_2edelete_24s1614046289x1611773644(V v_x1_240, V v_key_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 30ULL, 5);
    V v_a_247 = heff_strCompare_lent(v_key_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V v_l2_248 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_l_245, v_key_241));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_246)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_246, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2422);
        return (g_std_2emap_2ebalance(v_k_27_243, v_v_27_244, v_l2_248, v_r_246));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_243, v_v_27_244, v_l2_248, v_r_246});
      }
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_k_27_243);
        heff_drop(v_v_27_244);
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        HeffT2 v_t_2423 = (g_std_2emap_2efindMin_24cpr(v_r_246));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_it1_2426 = v_field_2425;
            switch (heff_tag_of(v_it1_2426)) {
            case TAG_MkPair: {
              V v_k_2427 = heff_field(v_it1_2426, 0);
              V v_v_2428 = heff_field(v_it1_2426, 1);
              heff_take_n(v_it1_2426, 3ULL, 2);
              V v_t_2429 = ({ V a_0 = v_r_246; V r_ = (g_std_2emap_2edeleteMin(a_0)); heff_drop(v_r_246); r_; });
              return (g_std_2emap_2ebalance(v_k_2427, v_v_2428, v_l_245, v_t_2429));
            }
            default: return heff_nomatch(v_it1_2426);
            }
          } else {
            heff_drop(v_r_246);
            heff_drop(v_field_2425);
            return v_l_245;
          }
        }
      } else {
        V v_r2_2430 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_r_246, v_key_241));
        V v_a_2436;
        switch (heff_tag_of(v_l_245)) {
        case TAG_Tip: {
          v_a_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_l_245, 0));
          v_a_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_l_245);
        }
        V v_b_2442;
        switch (heff_tag_of(v_r2_2430)) {
        case TAG_Tip: {
          v_b_2442 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2437 = heff_dup(heff_field(v_r2_2430, 0));
          v_b_2442 = v_h_2437;
          break;
        }
        default: heff_nomatch(v_r2_2430);
        }
        V v_h_2444;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2442), MK_INT(1LL)), heff_dup(v_a_2436)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2436), MK_INT(1LL)), heff_dup(v_b_2442)))) {
          heff_drop(v_a_2436);
          heff_drop(v_b_2442);
          v_h_2444 = MK_INT(0LL);
        } else {
          V v_t_2443;
          if (heff_intLe_c_lent(v_a_2436, v_b_2442, 0)) {
            heff_drop(v_a_2436);
            v_t_2443 = v_b_2442;
          } else {
            heff_drop(v_b_2442);
            v_t_2443 = v_a_2436;
          }
          v_h_2444 = heff_intAdd(MK_INT(1LL), v_t_2443);
        }
        if (heff_intEq_c_lent(v_h_2444, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2444);
          return (g_std_2emap_2ebalance(v_k_27_243, v_v_27_244, v_l_245, v_r2_2430));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2444, v_k_27_243, v_v_27_244, v_l_245, v_r2_2430});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2emap_2edelete_24s1614046289x1611773644(a[0], a1); heff_drop(a1); return r;
}
Clo g_std_2emap_2einsert_24s170109517x1206653089_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s170109517x1206653089_entry, 3, 0};

V g_std_2emap_2einsert_24s170109517x1206653089(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_248 = (g_std_2emap_2einsert_24s170109517x1206653089(v_l_246, v_key_241, v_value_242));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_247, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2422);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_248, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_244, v_v_27_245, v_l2_248, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2423 = (g_std_2emap_2einsert_24s170109517x1206653089(v_r_247, v_key_241, v_value_242));
        V v_a_2429;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2429 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2424 = heff_dup(heff_field(v_l_246, 0));
          v_a_2429 = v_h_2424;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2435;
        switch (heff_tag_of(v_r2_2423)) {
        case TAG_Tip: {
          v_b_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_r2_2423, 0));
          v_b_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_r2_2423);
        }
        V v_h_2437;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2435), MK_INT(1LL)), heff_dup(v_a_2429)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2429), MK_INT(1LL)), heff_dup(v_b_2435)))) {
          heff_drop(v_a_2429);
          heff_drop(v_b_2435);
          v_h_2437 = MK_INT(0LL);
        } else {
          V v_t_2436;
          if (heff_intLe_c_lent(v_a_2429, v_b_2435, 0)) {
            heff_drop(v_a_2429);
            v_t_2436 = v_b_2435;
          } else {
            heff_drop(v_b_2435);
            v_t_2436 = v_a_2429;
          }
          v_h_2437 = heff_intAdd(MK_INT(1LL), v_t_2436);
        }
        if (heff_intEq_c_lent(v_h_2437, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2437);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2423));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2437, v_k_27_244, v_v_27_245, v_l_246, v_r2_2423});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s170109517x1206653089(a[0], a[1], a[2]);
}
Clo g_std_2emap_2einsert_24s1913725254x907253835_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s1913725254x907253835_entry, 3, 0};

V g_std_2emap_2einsert_24s1913725254x907253835(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_248 = (g_std_2emap_2einsert_24s1913725254x907253835(v_l_246, v_key_241, v_value_242));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_247, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2422);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_248, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_244, v_v_27_245, v_l2_248, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2423 = (g_std_2emap_2einsert_24s1913725254x907253835(v_r_247, v_key_241, v_value_242));
        V v_a_2429;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2429 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2424 = heff_dup(heff_field(v_l_246, 0));
          v_a_2429 = v_h_2424;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2435;
        switch (heff_tag_of(v_r2_2423)) {
        case TAG_Tip: {
          v_b_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_r2_2423, 0));
          v_b_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_r2_2423);
        }
        V v_h_2437;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2435), MK_INT(1LL)), heff_dup(v_a_2429)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2429), MK_INT(1LL)), heff_dup(v_b_2435)))) {
          heff_drop(v_a_2429);
          heff_drop(v_b_2435);
          v_h_2437 = MK_INT(0LL);
        } else {
          V v_t_2436;
          if (heff_intLe_c_lent(v_a_2429, v_b_2435, 0)) {
            heff_drop(v_a_2429);
            v_t_2436 = v_b_2435;
          } else {
            heff_drop(v_b_2435);
            v_t_2436 = v_a_2429;
          }
          v_h_2437 = heff_intAdd(MK_INT(1LL), v_t_2436);
        }
        if (heff_intEq_c_lent(v_h_2437, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2437);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2423));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2437, v_k_27_244, v_v_27_245, v_l_246, v_r2_2423});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s1913725254x907253835_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s1913725254x907253835(a[0], a[1], a[2]);
}
Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24s471823439x1830654496_entry, 1, 0};

V g_std_2emap_2emapValues_24s471823439x1830654496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_241 = heff_field(v_x2_240, 0);
    V v_k_242 = heff_field(v_x2_240, 1);
    V v_v_243 = heff_field(v_x2_240, 2);
    V v_l_244 = heff_field(v_x2_240, 3);
    V v_r_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_246 = (g_std_2emap_2emapValues_24s471823439x1830654496(v_l_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_241, v_k_242, heff_get_n(v_v_243, 1, 3), v_t_246, heff_hole()});
    V v_u_248 = (g_std_2emap_2emapValues_24s471823439x1830654496_24dps(v_r_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24s471823439x1830654496(a[0]);
}
Clo g_std_2emap_2emapValues_24s471823439x1830654496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry, 2, 0};

V g_std_2emap_2emapValues_24s471823439x1830654496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return heff_setField(v_d_241, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_240, 0);
    V v_k_243 = heff_field(v_x2_240, 1);
    V v_v_244 = heff_field(v_x2_240, 2);
    V v_l_245 = heff_field(v_x2_240, 3);
    V v_r_246 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_247 = (g_std_2emap_2emapValues_24s471823439x1830654496(v_l_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, heff_get_n(v_v_244, 1, 3), v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(4LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_r_246;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2emap_2emapValues_24s471823439x1830654496_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2emapValues_24s471823439x1830654496_24dps(a[0], a[1]);
}
Clo g_std_2emap_2einsert_24s1863973822x2117969067_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s1863973822x2117969067_entry, 3, 0};

V g_std_2emap_2einsert_24s1863973822x2117969067(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_249 = (g_std_2emap_2einsert_24s1863973822x2117969067(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2423;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421)))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2423 = MK_INT(0LL);
      } else {
        V v_t_2422;
        if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
          heff_drop(v_a_2415);
          v_t_2422 = v_b_2421;
        } else {
          heff_drop(v_b_2421);
          v_t_2422 = v_a_2415;
        }
        v_h_2423 = heff_intAdd(MK_INT(1LL), v_t_2422);
      }
      if (heff_intEq_c_lent(v_h_2423, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        heff_drop(v_h_2423);
        return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l2_249, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2423, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2424 = (g_std_2emap_2einsert_24s1863973822x2117969067(v_r_247, v_key_241, v_value_242));
        V v_a_2430;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2430 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2425 = heff_dup(heff_field(v_l_246, 0));
          v_a_2430 = v_h_2425;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2436;
        switch (heff_tag_of(v_r2_2424)) {
        case TAG_Tip: {
          v_b_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_r2_2424, 0));
          v_b_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_r2_2424);
        }
        V v_h_2438;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2436), MK_INT(1LL)), heff_dup(v_a_2430)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2430), MK_INT(1LL)), heff_dup(v_b_2436)))) {
          heff_drop(v_a_2430);
          heff_drop(v_b_2436);
          v_h_2438 = MK_INT(0LL);
        } else {
          V v_t_2437;
          if (heff_intLe_c_lent(v_a_2430, v_b_2436, 0)) {
            heff_drop(v_a_2430);
            v_t_2437 = v_b_2436;
          } else {
            heff_drop(v_b_2436);
            v_t_2437 = v_a_2430;
          }
          v_h_2438 = heff_intAdd(MK_INT(1LL), v_t_2437);
        }
        if (heff_intEq_c_lent(v_h_2438, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          heff_drop(v_h_2438);
          return (g_std_2emap_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2424));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2438, v_k_27_244, v_v_27_245, v_l_246, v_r2_2424});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2emap_2einsert_24s1863973822x2117969067_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s1863973822x2117969067(a[0], a[1], a[2]);
}

HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_std_2emap_2einsert_24s738816132x592703192_lam0(V self, V *args);
V g_std_2emap_2einsert_24s738816132x592703192_lam1(V self, V *args);
Clo g_std_2emap_2einsert_24s738816132x592703192_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2einsert_24s738816132x592703192_entry, 3, 0};

V g_std_2emap_2einsert_24s738816132x592703192(V v_lit_240, V v_x1_241, V v_key_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_242, heff_clo_n(g_std_2emap_2einsert_24s738816132x592703192_lam0, 1, 1, (V[]){v_lit_240}), NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_244 = heff_field(v_x1_241, 0);
    V v_k_27_245 = heff_field(v_x1_241, 1);
    V v_v_27_246 = heff_field(v_x1_241, 2);
    V v_l_247 = heff_field(v_x1_241, 3);
    V v_r_248 = heff_field(v_x1_241, 4);
    V v_ru_24x1_241_24Bin = heff_take_reuse_n(v_x1_241, 31ULL, 5);
    V v_a_249 = heff_strCompare_lent(v_key_242, v_k_27_245, 0);
    if (heff_intLt_c_lent(v_a_249, MK_INT(0LL), 2)) {
      heff_drop(v_h_244);
      heff_drop(v_a_249);
      V v_l2_2410 = (g_std_2emap_2einsert_24s738816132x592703192(v_lit_240, v_l_247, v_key_242));
      V v_a_2416;
      switch (heff_tag_of(v_l2_2410)) {
      case TAG_Tip: {
        v_a_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2411 = heff_dup(heff_field(v_l2_2410, 0));
        v_a_2416 = v_h_2411;
        break;
      }
      default: heff_nomatch(v_l2_2410);
      }
      V v_b_2422;
      switch (heff_tag_of(v_r_248)) {
      case TAG_Tip: {
        v_b_2422 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2417 = heff_dup(heff_field(v_r_248, 0));
        v_b_2422 = v_h_2417;
        break;
      }
      default: heff_nomatch(v_r_248);
      }
      V v_h_2424;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2422), MK_INT(1LL)), heff_dup(v_a_2416)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2416), MK_INT(1LL)), heff_dup(v_b_2422)))) {
        heff_drop(v_a_2416);
        heff_drop(v_b_2422);
        v_h_2424 = MK_INT(0LL);
      } else {
        V v_t_2423;
        if (heff_intLe_c_lent(v_a_2416, v_b_2422, 0)) {
          heff_drop(v_a_2416);
          v_t_2423 = v_b_2422;
        } else {
          heff_drop(v_b_2422);
          v_t_2423 = v_a_2416;
        }
        v_h_2424 = heff_intAdd(MK_INT(1LL), v_t_2423);
      }
      if (heff_intEq_c_lent(v_h_2424, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x1_241_24Bin, 5);
        heff_drop(v_h_2424);
        return (g_std_2emap_2ebalance(v_k_27_245, v_v_27_246, v_l2_2410, v_r_248));
      } else {
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2424, v_k_27_245, v_v_27_246, v_l2_2410, v_r_248});
      }
    } else {
      if (heff_intEq_c(v_a_249, MK_INT(0LL))) {
        heff_drop(v_k_27_245);
        heff_drop(v_v_27_246);
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_244, v_key_242, heff_clo_n(g_std_2emap_2einsert_24s738816132x592703192_lam1, 1, 1, (V[]){v_lit_240}), v_l_247, v_r_248});
      } else {
        heff_drop(v_h_244);
        V v_r2_2426 = (g_std_2emap_2einsert_24s738816132x592703192(v_lit_240, v_r_248, v_key_242));
        V v_a_2432;
        switch (heff_tag_of(v_l_247)) {
        case TAG_Tip: {
          v_a_2432 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2427 = heff_dup(heff_field(v_l_247, 0));
          v_a_2432 = v_h_2427;
          break;
        }
        default: heff_nomatch(v_l_247);
        }
        V v_b_2438;
        switch (heff_tag_of(v_r2_2426)) {
        case TAG_Tip: {
          v_b_2438 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2433 = heff_dup(heff_field(v_r2_2426, 0));
          v_b_2438 = v_h_2433;
          break;
        }
        default: heff_nomatch(v_r2_2426);
        }
        V v_h_2440;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2438), MK_INT(1LL)), heff_dup(v_a_2432)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2432), MK_INT(1LL)), heff_dup(v_b_2438)))) {
          heff_drop(v_a_2432);
          heff_drop(v_b_2438);
          v_h_2440 = MK_INT(0LL);
        } else {
          V v_t_2439;
          if (heff_intLe_c_lent(v_a_2432, v_b_2438, 0)) {
            heff_drop(v_a_2432);
            v_t_2439 = v_b_2438;
          } else {
            heff_drop(v_b_2438);
            v_t_2439 = v_a_2432;
          }
          v_h_2440 = heff_intAdd(MK_INT(1LL), v_t_2439);
        }
        if (heff_intEq_c_lent(v_h_2440, MK_INT(0LL), 2)) {
          heff_drop_cell(v_ru_24x1_241_24Bin, 5);
          heff_drop(v_h_2440);
          return (g_std_2emap_2ebalance(v_k_27_245, v_v_27_246, v_l_247, v_r2_2426));
        } else {
          return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2440, v_k_27_245, v_v_27_246, v_l_247, v_r2_2426});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2emap_2einsert_24s738816132x592703192_entry(V self, V *a) {
  (void)self;
  return g_std_2emap_2einsert_24s738816132x592703192(a[0], a[1], a[2]);
}
V g_std_2emap_2einsert_24s738816132x592703192_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_243);
  return v_lit_240;
}
V g_std_2emap_2einsert_24s738816132x592703192_lam1(V self, V *args) {
  V v_a_2425 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2425);
  return v_lit_240;
}
Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry, 3, 0};

V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V v_tok_240, V v_x1_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_x1_241, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}