// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerOf(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerOf_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
V g_heff_2esyntax_2esurfaceprint_2elistItems(V);
V g_heff_2esyntax_2esurfaceprint_2elistItems_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elistItems_clo;
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_heff_2esyntax_2esurfaceprint_2eoperatorGo(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eoperatorGo_clo;
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(V);
V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_clo;
V g_heff_2esyntax_2esurfaceprint_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo;
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etypeFormer_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    V v_x1_242 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo(heff_dup(v_x_240), MK_INT(0LL), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nothing: {
      return v_x_240;
    }
    case TAG_Just: {
      V v_ws_243 = heff_field(v_x1_242, 0);
      heff_take_n(v_x1_242, 1ULL, 1);
      V v_t_246;
      switch (heff_tag_of(v_ws_243)) {
      case TAG_Nil: {
        v_t_246 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_244 = heff_field(v_ws_243, 0);
        V v_xs_245 = heff_field(v_ws_243, 1);
        heff_take_n(v_ws_243, 3ULL, 2);
        v_t_246 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
        break;
      }
      default: heff_nomatch(v_ws_243);
      }
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_246);
      heff_drop(v_t_247);
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), heff_strAppend(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5)));
    }
    default: return heff_nomatch(v_x1_242);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_249 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}); V a_3 = v_b_246; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_246); r_; });
    V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), v_t_249));
    V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1), v_t_2410));
    V v_t_2412 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2), v_t_2411));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3), v_t_2412);
  }
  case TAG_AbsConst: {
    V v_b_2413 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2416 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2413; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_2413); r_; });
    V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5), v_t_2417));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6), v_t_2418);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4, 3, " : ");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = ({ V a_0 = heff_dup(v_c_240); V a_1 = MK_INT(0LL); V a_2 = heff_dup(heff_rfield(v_acc_242, 0)); V a_3 = v_t_245; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_l_244), heff_rfield(v_ds_241, 1)));
    V v_t_2415;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_c_240);
      heff_drop_rec(v_ds_241, 3);
      v_t_2415 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0);
      break;
    }
    case TAG_Just: {
      V v_i_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_xs_2410 = heff_get_n(v_ds_241, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_249))) {
        if (heff_intLt_c(heff_dup(v_i_249), heff_arrayLength_lent(v_xs_2410, 0))) {
          V v_t_2413 = heff_arrayIndex(v_xs_2410, v_i_249);
          V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_2413));
          v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1), v_t_2414);
        } else {
          heff_drop(v_c_240);
          heff_drop(v_i_249);
          heff_drop(v_xs_2410);
          v_t_2415 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
        }
      } else {
        heff_drop(v_c_240);
        heff_drop(v_i_249);
        heff_drop(v_xs_2410);
        v_t_2415 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4), heff_strAppend(v_t_247, v_t_2415));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_l_244, v_t_2416), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2417));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2418});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str16, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str17, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str18, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str21, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str22, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str25, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str26, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str27, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str29, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str30, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str31, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str32, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str33, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str34, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str35, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str36, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str37, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str38, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str41, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str42, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str43, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str44, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    return ({ V a_0 = v_xs_242; V a_1 = v_i_244; V r_ = (g_heff_2esyntax_2esurfaceprint_2elocalName(a_0, a_1)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), 2)) {
      return v_x_245;
    } else {
      V v_x1_247 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo(heff_dup(v_x_245), MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Nothing: {
        return v_x_245;
      }
      case TAG_Just: {
        V v_ws_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_ws_248)) {
        case TAG_Nil: {
          v_t_2411 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_ws_248, 0);
          V v_xs_2410 = heff_field(v_ws_248, 1);
          heff_take_n(v_ws_248, 3ULL, 2);
          v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
          break;
        }
        default: heff_nomatch(v_ws_248);
        }
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_t_2411);
        heff_drop(v_t_2412);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str4), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str5)));
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
  }
  case TAG_SCode: {
    V v_t_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2413; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
  }
  case TAG_SApp: {
    V v_f_2414 = heff_field(v_e_243, 0);
    V v_a_2415 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(v_c_240, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2414, v_a_2415}));
  }
  case TAG_SLam: {
    V v_t_2416 = heff_field(v_e_243, 0);
    V v_b_2417 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2416, v_b_2417})));
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2418; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2420 = heff_arrayToList(heff_take_field(v_d_2419, 0));
    V v_t_2421 = heff_arrayToList(heff_get_n(v_d_2419, 2, 3));
    V v_t_2422 = (g_heff_2eutil_2edict_2ezipKV(v_t_2420, v_t_2421));
    V v_x2_2427 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam0, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2422));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str8); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str9), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str10)));
  }
  case TAG_SProj: {
    V v_e2_2431 = heff_field(v_e_243, 0);
    V v_l_2432 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(2LL), v_xs_242, v_e2_2431));
    return heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str11), v_l_2432));
  }
  case TAG_STag: {
    V v_x_2434 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2435 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2436 = (g_heff_2esyntax_2esurfaceprint_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nothing: {
      V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2435)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2437, MK_INT(0LL))) {
        heff_drop_rec(v_c_240, 2);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2435);
        return v_x_2434;
      } else {
        V v_s_2440 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str12); V a_1 = v_x_2434; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam1, 1, 2, (V[]){v_c_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2435); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str13), heff_strAppend(v_s_2440, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str14)));
        } else {
          return v_s_2440;
        }
      }
    }
    case TAG_Just: {
      V v_items_2442 = heff_field(v_t_2436, 0);
      heff_take_n(v_t_2436, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2434);
      heff_drop(v_ts_2435);
      V v_x2_2444 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), v_items_2442));
      V v_t_2447;
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_Nil: {
        v_t_2447 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        V v_xs_2446 = heff_field(v_x2_2444, 1);
        heff_take_n(v_x2_2444, 3ULL, 2);
        v_t_2447 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str16); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2444);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str17), heff_strAppend(v_t_2447, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str18)));
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_SMatch: {
    V v_s_2448 = heff_field(v_e_243, 0);
    V v_cases_2449 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2450 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_242), v_s_2448));
    V v_t_2451 = heff_arrayToList(heff_take_field(v_cases_2449, 0));
    V v_t_2452 = heff_arrayToList(heff_get_n(v_cases_2449, 2, 3));
    V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
    V v_x2_2457 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam3, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2453));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str20); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    V v_t_2461 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str21), v_t_2460));
    V v_s_2462 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str22), v_t_2461);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str23), heff_strAppend(v_s_2462, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str24)));
    } else {
      return v_s_2462;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2464 = heff_field(v_e_243, 0);
    V v_x_2465 = heff_field(v_e_243, 1);
    V v_v_2466 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2467 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2464));
    V v_t_2468 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), v_xs_242, v_v_2466));
    V v_t_2469 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str25), heff_strAppend(v_t_2468, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str26)));
    V v_t_2470 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str27), heff_strAppend(v_x_2465, v_t_2469));
    V v_s_2471 = heff_strAppend(v_t_2467, v_t_2470);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str28), heff_strAppend(v_s_2471, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str29)));
    } else {
      return v_s_2471;
    }
  }
  case TAG_SIs: {
    V v_e2_2473 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2473;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str30);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str31);
  }
  case TAG_SRec: {
    V v_e2_2474 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2474;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SFix: {
    V v_e2_27_2476 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2476)) {
    case TAG_MkAbs: {
      V v_x_2477 = heff_field(v_e2_27_2476, 0);
      heff_take_n(v_e2_27_2476, 1ULL, 2);
      return v_x_2477;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2476, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str32);
    }
    default: return heff_nomatch(v_e2_27_2476);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2481 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2481;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2482 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str33), heff_strAppend(v_x_2482, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str34)));
  }
  case TAG_SMetaApp: {
    V v_m_2483 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str35), heff_intShow(v_m_2483));
  }
  case TAG_SLitInt: {
    V v_i_2486 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2486);
  }
  case TAG_SLitFloat: {
    V v_x_2487 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2487);
  }
  case TAG_SLitString: {
    V v_s_2488 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2489 = (g_heff_2eutil_2erune_2equoteGo(v_s_2488, MK_INT(0LL), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str37), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str38)));
  }
  case TAG_SLitBytes: {
    V v_s_2490 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2491 = (g_heff_2eutil_2erune_2equoteBytesGo(v_s_2490, MK_INT(0LL), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str39), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str40)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str41), heff_strAppend(v_t_2491, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str42)));
  }
  case TAG_SLitRune: {
    V v_ch_2492 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2493 = (g_heff_2eutil_2erune_2equoted(v_ch_2492));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str43), heff_strAppend(v_t_2493, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str44)));
  }
  case TAG_SLitFixed: {
    V v_n_2495 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2495);
  }
  case TAG_SLitFloat32: {
    V v_x_2496 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2496);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_l_2424 = heff_field(v_f_2423, 0);
    V v_e_2425 = heff_field(v_f_2423, 1);
    heff_take_n(v_f_2423, 3ULL, 2);
    V v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), v_xs_242, v_e_2425));
    return heff_strAppend(v_l_2424, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str6), v_t_2426));
  }
  default: return heff_nomatch(v_f_2423);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam1(V self, V *args) {
  V v_a_2439 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(2LL), v_xs_242, v_a_2439));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam2(V self, V *args) {
  V v_a_2443 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), v_xs_242, v_a_2443));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_lam3(V self, V *args) {
  V v_alt_2454 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_intAdd(heff_take_field(v_c_240, 1), MK_INT(2LL));
  V v_t_2456 = ({ V rv_1 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_c_240, 1ULL, 2, shape_im__indent, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_t_2456; V a_1 = v_xs_242; V a_2 = v_alt_2454; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2454); r_; });
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    return v_e_240;
  }
  case TAG_SGlobal: {
    return v_e_240;
  }
  case TAG_SCode: {
    return v_e_240;
  }
  case TAG_SApp: {
    return v_e_240;
  }
  case TAG_SLam: {
    return v_e_240;
  }
  case TAG_SCons: {
    return v_e_240;
  }
  case TAG_SProj: {
    return v_e_240;
  }
  case TAG_STag: {
    return v_e_240;
  }
  case TAG_SMatch: {
    return v_e_240;
  }
  case TAG_SSpecialize: {
    return v_e_240;
  }
  case TAG_SIs: {
    V v_e1_2418 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V t_0 = v_e1_2418;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_e_240;
  }
  case TAG_SAbandon: {
    return v_e_240;
  }
  case TAG_SRec: {
    return v_e_240;
  }
  case TAG_SFix: {
    return v_e_240;
  }
  case TAG_SImplicit: {
    return v_e_240;
  }
  case TAG_SPrim: {
    return v_e_240;
  }
  case TAG_SMetaApp: {
    return v_e_240;
  }
  case TAG_SLitInt: {
    return v_e_240;
  }
  case TAG_SLitFloat: {
    return v_e_240;
  }
  case TAG_SLitString: {
    return v_e_240;
  }
  case TAG_SLitBytes: {
    return v_e_240;
  }
  case TAG_SLitRune: {
    return v_e_240;
  }
  case TAG_SLitFixed: {
    return v_e_240;
  }
  case TAG_SLitFloat32: {
    return v_e_240;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9, 2, 0};
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_x5_243, 0);
    V v_dom_2410 = heff_field(v_x5_243, 1);
    V v_cod_2411 = heff_field(v_x5_243, 2);
    V v_implicit_2412 = heff_field(v_x5_243, 3);
    V v_dflt_2413 = heff_field(v_x5_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(heff_rec_n(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, v_dom_2410, heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(heff_rec_n(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, v_dom_2410, heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3)));
    } else {
      return v_s_2421;
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_x5_243, 1);
    V v_ds_2425 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 2)));
    V v_fs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_t_2436 = heff_get_n(v_acc_2435, 1, 2);
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_t_2436, 0);
      V v_xs_2438 = heff_field(v_t_2436, 1);
      heff_take_n(v_t_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 0)));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 2)));
    V v_t_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2451 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2455 = heff_field(v_x5_243, 0);
    V v_t_2458 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2458, v_lit_240}), v_p_241, v_xs_242, v_t2_2455);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo), NTAG(TAG_False)});
    V v_t_2463 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2462, v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2459));
    V v_s_2464 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17), v_t_2463);
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18), heff_strAppend(v_s_2464, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19)));
    } else {
      return v_s_2464;
    }
  }
  case TAG_SFixed: {
    V v_w_2466 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2466)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28);
    }
    default: return heff_nomatch(v_w_2466);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(heff_rec_n(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo), NTAG(TAG_False)});
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2447; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2447); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    heff_take_n(v_v_2444, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8); V a_1 = v_t_2445; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2446); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args) {
  V v_a_2456 = args[0];
  V v_a_2457 = args[1];
  heff_drop(v_a_2456);
  heff_drop(v_a_2457);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if (heff_intLe_c(MK_INT(65LL), heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2))) {
        if (heff_intLe_c(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2), MK_INT(90LL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str2), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str4), heff_strAppend(v_x_241, v_t_247));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str5), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str7), heff_strAppend(v_x_241, v_t_2410));
  }
  case TAG_SFunction: {
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2417));
  }
  case TAG_SRecord: {
    V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2422));
  }
  case TAG_SSum: {
    V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2425));
  }
  case TAG_SIsTy: {
    V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str17), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2428));
  }
  case TAG_SPrimInt: {
    V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str20), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2430));
  }
  case TAG_SPrimFloat: {
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2432));
  }
  case TAG_SPrimString: {
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str26), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2434));
  }
  case TAG_SPrimRune: {
    V v_t_2435 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str29), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2436));
  }
  case TAG_SPrimArray: {
    V v_t_2438 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str32), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2439));
  }
  case TAG_SFixed: {
    V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2442));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str0), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str1)));
      V v_d_249 = heff_strAppend(v_shown_242, v_t_248);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2410, NTAG(TAG_Nil)));
      V v_x2_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        v_x2_2413 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2412));
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nothing: {
        return v_d_249;
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        heff_take_n(v_x2_2413, 1ULL, 1);
        heff_drop(v_d_249);
        return v_x_2414;
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2416 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str2), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str3)));
      return heff_strAppend(v_shown_242, v_t_2417);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SGlobal: {
    V v_t_2419 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str4), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str5)));
      V v_d_2422 = heff_strAppend(v_shown_242, v_t_2421);
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2423, NTAG(TAG_Nil)));
      V v_x2_2426;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2425 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 1);
        v_x2_2426 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2425));
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_Nothing: {
        return v_d_2422;
      }
      case TAG_Just: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        heff_take_n(v_x2_2426, 1ULL, 1);
        heff_drop(v_d_2422);
        return v_x_2427;
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2419, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2429 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str6), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str7)));
      return heff_strAppend(v_shown_242, v_t_2430);
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_SCode: {
    V v_t_2432 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str8), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str9)));
      V v_d_2435 = heff_strAppend(v_shown_242, v_t_2434);
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2437 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2436, NTAG(TAG_Nil)));
      V v_x2_2439;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2439 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        v_x2_2439 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2438));
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nothing: {
        return v_d_2435;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        heff_take_n(v_x2_2439, 1ULL, 1);
        heff_drop(v_d_2435);
        return v_x_2440;
      }
      default: return heff_nomatch(v_x2_2439);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2432, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2442 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str10), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str11)));
      return heff_strAppend(v_shown_242, v_t_2443);
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_SApp: {
    V v_t_2446 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      V v_t_2447 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2448 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str12), heff_strAppend(v_t_2447, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str13)));
      V v_d_2449 = heff_strAppend(v_shown_242, v_t_2448);
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2451 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2450, NTAG(TAG_Nil)));
      V v_x2_2453;
      switch (heff_tag_of(v_t_2451)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2453 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2452 = heff_field(v_t_2451, 0);
        heff_take_n(v_t_2451, 1ULL, 1);
        v_x2_2453 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2452));
        break;
      }
      default: heff_nomatch(v_t_2451);
      }
      switch (heff_tag_of(v_x2_2453)) {
      case TAG_Nothing: {
        return v_d_2449;
      }
      case TAG_Just: {
        V v_x_2454 = heff_field(v_x2_2453, 0);
        heff_take_n(v_x2_2453, 1ULL, 1);
        heff_drop(v_d_2449);
        return v_x_2454;
      }
      default: return heff_nomatch(v_x2_2453);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2456 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2457 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str14), heff_strAppend(v_t_2456, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str15)));
      return heff_strAppend(v_shown_242, v_t_2457);
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_SLam: {
    V v_t_2460 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_Nothing: {
      V v_t_2461 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2462 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str16), heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str17)));
      V v_d_2463 = heff_strAppend(v_shown_242, v_t_2462);
      V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2465 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2464, NTAG(TAG_Nil)));
      V v_x2_2467;
      switch (heff_tag_of(v_t_2465)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2467 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2466 = heff_field(v_t_2465, 0);
        heff_take_n(v_t_2465, 1ULL, 1);
        v_x2_2467 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2466));
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_Nothing: {
        return v_d_2463;
      }
      case TAG_Just: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        heff_take_n(v_x2_2467, 1ULL, 1);
        heff_drop(v_d_2463);
        return v_x_2468;
      }
      default: return heff_nomatch(v_x2_2467);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2460, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2470 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2471 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str18), heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str19)));
      return heff_strAppend(v_shown_242, v_t_2471);
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2473)) {
    case TAG_Nothing: {
      V v_t_2474 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str20), heff_strAppend(v_t_2474, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str21)));
      V v_d_2476 = heff_strAppend(v_shown_242, v_t_2475);
      V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2478 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2477, NTAG(TAG_Nil)));
      V v_x2_2480;
      switch (heff_tag_of(v_t_2478)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2480 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2479 = heff_field(v_t_2478, 0);
        heff_take_n(v_t_2478, 1ULL, 1);
        v_x2_2480 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2479));
        break;
      }
      default: heff_nomatch(v_t_2478);
      }
      switch (heff_tag_of(v_x2_2480)) {
      case TAG_Nothing: {
        return v_d_2476;
      }
      case TAG_Just: {
        V v_x_2481 = heff_field(v_x2_2480, 0);
        heff_take_n(v_x2_2480, 1ULL, 1);
        heff_drop(v_d_2476);
        return v_x_2481;
      }
      default: return heff_nomatch(v_x2_2480);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2473, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2483 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str22), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str23)));
      return heff_strAppend(v_shown_242, v_t_2484);
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_SProj: {
    V v_t_2487 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2487)) {
    case TAG_Nothing: {
      V v_t_2488 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str24), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str25)));
      V v_d_2490 = heff_strAppend(v_shown_242, v_t_2489);
      V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2492 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_2491, NTAG(TAG_Nil)));
      V v_x2_2494;
      switch (heff_tag_of(v_t_2492)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2493 = heff_field(v_t_2492, 0);
        heff_take_n(v_t_2492, 1ULL, 1);
        v_x2_2494 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2493));
        break;
      }
      default: heff_nomatch(v_t_2492);
      }
      switch (heff_tag_of(v_x2_2494)) {
      case TAG_Nothing: {
        return v_d_2490;
      }
      case TAG_Just: {
        V v_x_2495 = heff_field(v_x2_2494, 0);
        heff_take_n(v_x2_2494, 1ULL, 1);
        heff_drop(v_d_2490);
        return v_x_2495;
      }
      default: return heff_nomatch(v_x2_2494);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2487, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2497 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2498 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str26), heff_strAppend(v_t_2497, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str27)));
      return heff_strAppend(v_shown_242, v_t_2498);
    }
    default: return heff_nomatch(v_t_2487);
    }
  }
  case TAG_STag: {
    V v_t_24101 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24101)) {
    case TAG_Nothing: {
      V v_t_24102 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24103 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str28), heff_strAppend(v_t_24102, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str29)));
      V v_d_24104 = heff_strAppend(v_shown_242, v_t_24103);
      V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24106 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24105, NTAG(TAG_Nil)));
      V v_x2_24108;
      switch (heff_tag_of(v_t_24106)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24108 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24107 = heff_field(v_t_24106, 0);
        heff_take_n(v_t_24106, 1ULL, 1);
        v_x2_24108 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24107));
        break;
      }
      default: heff_nomatch(v_t_24106);
      }
      switch (heff_tag_of(v_x2_24108)) {
      case TAG_Nothing: {
        return v_d_24104;
      }
      case TAG_Just: {
        V v_x_24109 = heff_field(v_x2_24108, 0);
        heff_take_n(v_x2_24108, 1ULL, 1);
        heff_drop(v_d_24104);
        return v_x_24109;
      }
      default: return heff_nomatch(v_x2_24108);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24101, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24111 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24112 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str30), heff_strAppend(v_t_24111, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str31)));
      return heff_strAppend(v_shown_242, v_t_24112);
    }
    default: return heff_nomatch(v_t_24101);
    }
  }
  case TAG_SMatch: {
    V v_t_24115 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24115)) {
    case TAG_Nothing: {
      V v_t_24116 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24117 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str32), heff_strAppend(v_t_24116, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str33)));
      V v_d_24118 = heff_strAppend(v_shown_242, v_t_24117);
      V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24120 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24119, NTAG(TAG_Nil)));
      V v_x2_24122;
      switch (heff_tag_of(v_t_24120)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24122 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24121 = heff_field(v_t_24120, 0);
        heff_take_n(v_t_24120, 1ULL, 1);
        v_x2_24122 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24121));
        break;
      }
      default: heff_nomatch(v_t_24120);
      }
      switch (heff_tag_of(v_x2_24122)) {
      case TAG_Nothing: {
        return v_d_24118;
      }
      case TAG_Just: {
        V v_x_24123 = heff_field(v_x2_24122, 0);
        heff_take_n(v_x2_24122, 1ULL, 1);
        heff_drop(v_d_24118);
        return v_x_24123;
      }
      default: return heff_nomatch(v_x2_24122);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24115, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24125 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str34), heff_strAppend(v_t_24125, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str35)));
      return heff_strAppend(v_shown_242, v_t_24126);
    }
    default: return heff_nomatch(v_t_24115);
    }
  }
  case TAG_SSpecialize: {
    V v_t_24130 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24130)) {
    case TAG_Nothing: {
      V v_t_24131 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24132 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str36), heff_strAppend(v_t_24131, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str37)));
      V v_d_24133 = heff_strAppend(v_shown_242, v_t_24132);
      V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24135 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24134, NTAG(TAG_Nil)));
      V v_x2_24137;
      switch (heff_tag_of(v_t_24135)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24136 = heff_field(v_t_24135, 0);
        heff_take_n(v_t_24135, 1ULL, 1);
        v_x2_24137 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24136));
        break;
      }
      default: heff_nomatch(v_t_24135);
      }
      switch (heff_tag_of(v_x2_24137)) {
      case TAG_Nothing: {
        return v_d_24133;
      }
      case TAG_Just: {
        V v_x_24138 = heff_field(v_x2_24137, 0);
        heff_take_n(v_x2_24137, 1ULL, 1);
        heff_drop(v_d_24133);
        return v_x_24138;
      }
      default: return heff_nomatch(v_x2_24137);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24130, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 3);
      V v_t_24140 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24141 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str38), heff_strAppend(v_t_24140, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str39)));
      return heff_strAppend(v_shown_242, v_t_24141);
    }
    default: return heff_nomatch(v_t_24130);
    }
  }
  case TAG_SIs: {
    V v_t_24143 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24143)) {
    case TAG_Nothing: {
      V v_t_24144 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str40), heff_strAppend(v_t_24144, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str41)));
      V v_d_24146 = heff_strAppend(v_shown_242, v_t_24145);
      V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24148 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24147, NTAG(TAG_Nil)));
      V v_x2_24150;
      switch (heff_tag_of(v_t_24148)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24150 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24149 = heff_field(v_t_24148, 0);
        heff_take_n(v_t_24148, 1ULL, 1);
        v_x2_24150 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24149));
        break;
      }
      default: heff_nomatch(v_t_24148);
      }
      switch (heff_tag_of(v_x2_24150)) {
      case TAG_Nothing: {
        return v_d_24146;
      }
      case TAG_Just: {
        V v_x_24151 = heff_field(v_x2_24150, 0);
        heff_take_n(v_x2_24150, 1ULL, 1);
        heff_drop(v_d_24146);
        return v_x_24151;
      }
      default: return heff_nomatch(v_x2_24150);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24143, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24153 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str42), heff_strAppend(v_t_24153, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str43)));
      return heff_strAppend(v_shown_242, v_t_24154);
    }
    default: return heff_nomatch(v_t_24143);
    }
  }
  case TAG_SOpaque: {
    V v_t_24155 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24155)) {
    case TAG_Nothing: {
      V v_t_24156 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24157 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str44), heff_strAppend(v_t_24156, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str45)));
      V v_d_24158 = heff_strAppend(v_shown_242, v_t_24157);
      V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24160 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24159, NTAG(TAG_Nil)));
      V v_x2_24162;
      switch (heff_tag_of(v_t_24160)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24162 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24161 = heff_field(v_t_24160, 0);
        heff_take_n(v_t_24160, 1ULL, 1);
        v_x2_24162 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24161));
        break;
      }
      default: heff_nomatch(v_t_24160);
      }
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_Nothing: {
        return v_d_24158;
      }
      case TAG_Just: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        heff_take_n(v_x2_24162, 1ULL, 1);
        heff_drop(v_d_24158);
        return v_x_24163;
      }
      default: return heff_nomatch(v_x2_24162);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24155, 0ULL, 1);
      heff_drop(v_name_241);
      V v_t_24165 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24166 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str46), heff_strAppend(v_t_24165, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str47)));
      return heff_strAppend(v_shown_242, v_t_24166);
    }
    default: return heff_nomatch(v_t_24155);
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24167 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
    V v_t_24168 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str48), heff_strAppend(v_t_24167, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24168);
  }
  case TAG_SRec: {
    V v_t_24170 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24170)) {
    case TAG_Nothing: {
      V v_t_24171 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str50), heff_strAppend(v_t_24171, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str51)));
      V v_d_24173 = heff_strAppend(v_shown_242, v_t_24172);
      V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24175 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24174, NTAG(TAG_Nil)));
      V v_x2_24177;
      switch (heff_tag_of(v_t_24175)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24177 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24176 = heff_field(v_t_24175, 0);
        heff_take_n(v_t_24175, 1ULL, 1);
        v_x2_24177 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24176));
        break;
      }
      default: heff_nomatch(v_t_24175);
      }
      switch (heff_tag_of(v_x2_24177)) {
      case TAG_Nothing: {
        return v_d_24173;
      }
      case TAG_Just: {
        V v_x_24178 = heff_field(v_x2_24177, 0);
        heff_take_n(v_x2_24177, 1ULL, 1);
        heff_drop(v_d_24173);
        return v_x_24178;
      }
      default: return heff_nomatch(v_x2_24177);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24170, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24180 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24181 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str52), heff_strAppend(v_t_24180, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str53)));
      return heff_strAppend(v_shown_242, v_t_24181);
    }
    default: return heff_nomatch(v_t_24170);
    }
  }
  case TAG_SFix: {
    V v_t_24184 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24184)) {
    case TAG_Nothing: {
      V v_t_24185 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24186 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str54), heff_strAppend(v_t_24185, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str55)));
      V v_d_24187 = heff_strAppend(v_shown_242, v_t_24186);
      V v_t_24188 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24189 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24188, NTAG(TAG_Nil)));
      V v_x2_24191;
      switch (heff_tag_of(v_t_24189)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24191 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24190 = heff_field(v_t_24189, 0);
        heff_take_n(v_t_24189, 1ULL, 1);
        v_x2_24191 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24190));
        break;
      }
      default: heff_nomatch(v_t_24189);
      }
      switch (heff_tag_of(v_x2_24191)) {
      case TAG_Nothing: {
        return v_d_24187;
      }
      case TAG_Just: {
        V v_x_24192 = heff_field(v_x2_24191, 0);
        heff_take_n(v_x2_24191, 1ULL, 1);
        heff_drop(v_d_24187);
        return v_x_24192;
      }
      default: return heff_nomatch(v_x2_24191);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24184, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24194 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str56), heff_strAppend(v_t_24194, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str57)));
      return heff_strAppend(v_shown_242, v_t_24195);
    }
    default: return heff_nomatch(v_t_24184);
    }
  }
  case TAG_SImplicit: {
    V v_t_24198 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24198)) {
    case TAG_Nothing: {
      V v_t_24199 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24200 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str58), heff_strAppend(v_t_24199, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str59)));
      V v_d_24201 = heff_strAppend(v_shown_242, v_t_24200);
      V v_t_24202 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24203 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24202, NTAG(TAG_Nil)));
      V v_x2_24205;
      switch (heff_tag_of(v_t_24203)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24205 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24204 = heff_field(v_t_24203, 0);
        heff_take_n(v_t_24203, 1ULL, 1);
        v_x2_24205 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24204));
        break;
      }
      default: heff_nomatch(v_t_24203);
      }
      switch (heff_tag_of(v_x2_24205)) {
      case TAG_Nothing: {
        return v_d_24201;
      }
      case TAG_Just: {
        V v_x_24206 = heff_field(v_x2_24205, 0);
        heff_take_n(v_x2_24205, 1ULL, 1);
        heff_drop(v_d_24201);
        return v_x_24206;
      }
      default: return heff_nomatch(v_x2_24205);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24198, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24208 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str60), heff_strAppend(v_t_24208, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str61)));
      return heff_strAppend(v_shown_242, v_t_24209);
    }
    default: return heff_nomatch(v_t_24198);
    }
  }
  case TAG_SPrim: {
    V v_t_24211 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24211)) {
    case TAG_Nothing: {
      V v_t_24212 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24213 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str62), heff_strAppend(v_t_24212, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str63)));
      V v_d_24214 = heff_strAppend(v_shown_242, v_t_24213);
      V v_t_24215 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24216 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24215, NTAG(TAG_Nil)));
      V v_x2_24218;
      switch (heff_tag_of(v_t_24216)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24218 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24217 = heff_field(v_t_24216, 0);
        heff_take_n(v_t_24216, 1ULL, 1);
        v_x2_24218 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24217));
        break;
      }
      default: heff_nomatch(v_t_24216);
      }
      switch (heff_tag_of(v_x2_24218)) {
      case TAG_Nothing: {
        return v_d_24214;
      }
      case TAG_Just: {
        V v_x_24219 = heff_field(v_x2_24218, 0);
        heff_take_n(v_x2_24218, 1ULL, 1);
        heff_drop(v_d_24214);
        return v_x_24219;
      }
      default: return heff_nomatch(v_x2_24218);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24211, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24221 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24222 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str64), heff_strAppend(v_t_24221, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str65)));
      return heff_strAppend(v_shown_242, v_t_24222);
    }
    default: return heff_nomatch(v_t_24211);
    }
  }
  case TAG_SMetaApp: {
    V v_t_24226 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24226)) {
    case TAG_Nothing: {
      V v_t_24227 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24228 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str66), heff_strAppend(v_t_24227, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str67)));
      V v_d_24229 = heff_strAppend(v_shown_242, v_t_24228);
      V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24231 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24230, NTAG(TAG_Nil)));
      V v_x2_24233;
      switch (heff_tag_of(v_t_24231)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24233 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24232 = heff_field(v_t_24231, 0);
        heff_take_n(v_t_24231, 1ULL, 1);
        v_x2_24233 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24232));
        break;
      }
      default: heff_nomatch(v_t_24231);
      }
      switch (heff_tag_of(v_x2_24233)) {
      case TAG_Nothing: {
        return v_d_24229;
      }
      case TAG_Just: {
        V v_x_24234 = heff_field(v_x2_24233, 0);
        heff_take_n(v_x2_24233, 1ULL, 1);
        heff_drop(v_d_24229);
        return v_x_24234;
      }
      default: return heff_nomatch(v_x2_24233);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24226, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 3);
      V v_t_24236 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24237 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str68), heff_strAppend(v_t_24236, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str69)));
      return heff_strAppend(v_shown_242, v_t_24237);
    }
    default: return heff_nomatch(v_t_24226);
    }
  }
  case TAG_SLitInt: {
    V v_t_24239 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24239)) {
    case TAG_Nothing: {
      V v_t_24240 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24241 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str70), heff_strAppend(v_t_24240, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str71)));
      V v_d_24242 = heff_strAppend(v_shown_242, v_t_24241);
      V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24244 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24243, NTAG(TAG_Nil)));
      V v_x2_24246;
      switch (heff_tag_of(v_t_24244)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24245 = heff_field(v_t_24244, 0);
        heff_take_n(v_t_24244, 1ULL, 1);
        v_x2_24246 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24245));
        break;
      }
      default: heff_nomatch(v_t_24244);
      }
      switch (heff_tag_of(v_x2_24246)) {
      case TAG_Nothing: {
        return v_d_24242;
      }
      case TAG_Just: {
        V v_x_24247 = heff_field(v_x2_24246, 0);
        heff_take_n(v_x2_24246, 1ULL, 1);
        heff_drop(v_d_24242);
        return v_x_24247;
      }
      default: return heff_nomatch(v_x2_24246);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24239, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24249 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24250 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str72), heff_strAppend(v_t_24249, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str73)));
      return heff_strAppend(v_shown_242, v_t_24250);
    }
    default: return heff_nomatch(v_t_24239);
    }
  }
  case TAG_SLitFloat: {
    V v_t_24252 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24252)) {
    case TAG_Nothing: {
      V v_t_24253 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24254 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str74), heff_strAppend(v_t_24253, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str75)));
      V v_d_24255 = heff_strAppend(v_shown_242, v_t_24254);
      V v_t_24256 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24257 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24256, NTAG(TAG_Nil)));
      V v_x2_24259;
      switch (heff_tag_of(v_t_24257)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24259 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24258 = heff_field(v_t_24257, 0);
        heff_take_n(v_t_24257, 1ULL, 1);
        v_x2_24259 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24258));
        break;
      }
      default: heff_nomatch(v_t_24257);
      }
      switch (heff_tag_of(v_x2_24259)) {
      case TAG_Nothing: {
        return v_d_24255;
      }
      case TAG_Just: {
        V v_x_24260 = heff_field(v_x2_24259, 0);
        heff_take_n(v_x2_24259, 1ULL, 1);
        heff_drop(v_d_24255);
        return v_x_24260;
      }
      default: return heff_nomatch(v_x2_24259);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24252, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24262 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24263 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str76), heff_strAppend(v_t_24262, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str77)));
      return heff_strAppend(v_shown_242, v_t_24263);
    }
    default: return heff_nomatch(v_t_24252);
    }
  }
  case TAG_SLitString: {
    V v_t_24265 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24265)) {
    case TAG_Nothing: {
      V v_t_24266 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24267 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str78), heff_strAppend(v_t_24266, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str79)));
      V v_d_24268 = heff_strAppend(v_shown_242, v_t_24267);
      V v_t_24269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24270 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24269, NTAG(TAG_Nil)));
      V v_x2_24272;
      switch (heff_tag_of(v_t_24270)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24272 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24271 = heff_field(v_t_24270, 0);
        heff_take_n(v_t_24270, 1ULL, 1);
        v_x2_24272 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24271));
        break;
      }
      default: heff_nomatch(v_t_24270);
      }
      switch (heff_tag_of(v_x2_24272)) {
      case TAG_Nothing: {
        return v_d_24268;
      }
      case TAG_Just: {
        V v_x_24273 = heff_field(v_x2_24272, 0);
        heff_take_n(v_x2_24272, 1ULL, 1);
        heff_drop(v_d_24268);
        return v_x_24273;
      }
      default: return heff_nomatch(v_x2_24272);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24265, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24275 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24276 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str80), heff_strAppend(v_t_24275, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str81)));
      return heff_strAppend(v_shown_242, v_t_24276);
    }
    default: return heff_nomatch(v_t_24265);
    }
  }
  case TAG_SLitBytes: {
    V v_t_24278 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24278)) {
    case TAG_Nothing: {
      V v_t_24279 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24280 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str82), heff_strAppend(v_t_24279, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str83)));
      V v_d_24281 = heff_strAppend(v_shown_242, v_t_24280);
      V v_t_24282 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24283 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24282, NTAG(TAG_Nil)));
      V v_x2_24285;
      switch (heff_tag_of(v_t_24283)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24285 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24284 = heff_field(v_t_24283, 0);
        heff_take_n(v_t_24283, 1ULL, 1);
        v_x2_24285 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24284));
        break;
      }
      default: heff_nomatch(v_t_24283);
      }
      switch (heff_tag_of(v_x2_24285)) {
      case TAG_Nothing: {
        return v_d_24281;
      }
      case TAG_Just: {
        V v_x_24286 = heff_field(v_x2_24285, 0);
        heff_take_n(v_x2_24285, 1ULL, 1);
        heff_drop(v_d_24281);
        return v_x_24286;
      }
      default: return heff_nomatch(v_x2_24285);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24278, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24288 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24289 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str84), heff_strAppend(v_t_24288, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str85)));
      return heff_strAppend(v_shown_242, v_t_24289);
    }
    default: return heff_nomatch(v_t_24278);
    }
  }
  case TAG_SLitRune: {
    V v_t_24291 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24291)) {
    case TAG_Nothing: {
      V v_t_24292 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24293 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str86), heff_strAppend(v_t_24292, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str87)));
      V v_d_24294 = heff_strAppend(v_shown_242, v_t_24293);
      V v_t_24295 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24296 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24295, NTAG(TAG_Nil)));
      V v_x2_24298;
      switch (heff_tag_of(v_t_24296)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24298 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24297 = heff_field(v_t_24296, 0);
        heff_take_n(v_t_24296, 1ULL, 1);
        v_x2_24298 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24297));
        break;
      }
      default: heff_nomatch(v_t_24296);
      }
      switch (heff_tag_of(v_x2_24298)) {
      case TAG_Nothing: {
        return v_d_24294;
      }
      case TAG_Just: {
        V v_x_24299 = heff_field(v_x2_24298, 0);
        heff_take_n(v_x2_24298, 1ULL, 1);
        heff_drop(v_d_24294);
        return v_x_24299;
      }
      default: return heff_nomatch(v_x2_24298);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24291, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24301 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24302 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str88), heff_strAppend(v_t_24301, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str89)));
      return heff_strAppend(v_shown_242, v_t_24302);
    }
    default: return heff_nomatch(v_t_24291);
    }
  }
  case TAG_SLitFixed: {
    V v_t_24305 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24305)) {
    case TAG_Nothing: {
      V v_t_24306 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24307 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str90), heff_strAppend(v_t_24306, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str91)));
      V v_d_24308 = heff_strAppend(v_shown_242, v_t_24307);
      V v_t_24309 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24310 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24309, NTAG(TAG_Nil)));
      V v_x2_24312;
      switch (heff_tag_of(v_t_24310)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24312 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24311 = heff_field(v_t_24310, 0);
        heff_take_n(v_t_24310, 1ULL, 1);
        v_x2_24312 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24311));
        break;
      }
      default: heff_nomatch(v_t_24310);
      }
      switch (heff_tag_of(v_x2_24312)) {
      case TAG_Nothing: {
        return v_d_24308;
      }
      case TAG_Just: {
        V v_x_24313 = heff_field(v_x2_24312, 0);
        heff_take_n(v_x2_24312, 1ULL, 1);
        heff_drop(v_d_24308);
        return v_x_24313;
      }
      default: return heff_nomatch(v_x2_24312);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24305, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24315 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24316 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str92), heff_strAppend(v_t_24315, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str93)));
      return heff_strAppend(v_shown_242, v_t_24316);
    }
    default: return heff_nomatch(v_t_24305);
    }
  }
  case TAG_SLitFloat32: {
    V v_t_24318 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24318)) {
    case TAG_Nothing: {
      V v_t_24319 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24320 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str94), heff_strAppend(v_t_24319, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str95)));
      V v_d_24321 = heff_strAppend(v_shown_242, v_t_24320);
      V v_t_24322 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24323 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer(v_t_243, v_body_244, v_t_24322, NTAG(TAG_Nil)));
      V v_x2_24325;
      switch (heff_tag_of(v_t_24323)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24325 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24324 = heff_field(v_t_24323, 0);
        heff_take_n(v_t_24323, 1ULL, 1);
        v_x2_24325 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24324));
        break;
      }
      default: heff_nomatch(v_t_24323);
      }
      switch (heff_tag_of(v_x2_24325)) {
      case TAG_Nothing: {
        return v_d_24321;
      }
      case TAG_Just: {
        V v_x_24326 = heff_field(v_x2_24325, 0);
        heff_take_n(v_x2_24325, 1ULL, 1);
        heff_drop(v_d_24321);
        return v_x_24326;
      }
      default: return heff_nomatch(v_x2_24325);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24318, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24328 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24329 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str96), heff_strAppend(v_t_24328, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str97)));
      return heff_strAppend(v_shown_242, v_t_24329);
    }
    default: return heff_nomatch(v_t_24318);
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}