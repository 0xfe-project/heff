// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_typed 312202372
#define LBL_values 1123329101
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2espineGo_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str0, 4, "plus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str1, 5, "minus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str2, 5, "times");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str3, 5, "slash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str4, 7, "percent");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str5, 2, "eq");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str6, 2, "lt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str7, 2, "gt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str8, 3, "amp");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str9, 3, "bar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str10, 4, "bang");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str11, 5, "caret");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str12, 1, "q");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str13, 2, "at");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str14, 4, "hash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str15, 6, "dollar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str16, 5, "tilde");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str17, 5, "colon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str18, 3, "dot");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str19, 9, "backslash");

HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)43ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str0)}});
  } else {
    if ((v_c_240 == ((int64_t)45ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str1)}});
    } else {
      if ((v_c_240 == ((int64_t)42ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str2)}});
      } else {
        if ((v_c_240 == ((int64_t)47ULL))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str3)}});
        } else {
          if ((v_c_240 == ((int64_t)37ULL))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str4)}});
          } else {
            if ((v_c_240 == ((int64_t)61ULL))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str5)}});
            } else {
              if ((v_c_240 == ((int64_t)60ULL))) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str6)}});
              } else {
                if ((v_c_240 == ((int64_t)62ULL))) {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str7)}});
                } else {
                  if ((v_c_240 == ((int64_t)38ULL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str8)}});
                  } else {
                    if ((v_c_240 == ((int64_t)124ULL))) {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str9)}});
                    } else {
                      if ((v_c_240 == ((int64_t)33ULL))) {
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str10)}});
                      } else {
                        if ((v_c_240 == ((int64_t)94ULL))) {
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str11)}});
                        } else {
                          if ((v_c_240 == ((int64_t)63ULL))) {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str12)}});
                          } else {
                            if ((v_c_240 == ((int64_t)64ULL))) {
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str13)}});
                            } else {
                              if ((v_c_240 == ((int64_t)35ULL))) {
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str14)}});
                              } else {
                                if ((v_c_240 == ((int64_t)36ULL))) {
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str15)}});
                                } else {
                                  if ((v_c_240 == ((int64_t)126ULL))) {
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str16)}});
                                  } else {
                                    if ((v_c_240 == ((int64_t)58ULL))) {
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str17)}});
                                    } else {
                                      if ((v_c_240 == ((int64_t)46ULL))) {
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str18)}});
                                      } else {
                                        if ((v_c_240 == ((int64_t)92ULL))) {
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str19)}});
                                        } else {
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    HeffT2 v_t_241 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_243 = v_t_241.f[1];
      int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
      if ((v_tag_242 == ((int64_t)0ULL))) {
        V v_ws_244 = v_field_243;
        V v_t_247;
        switch (heff_tag_of(v_ws_244)) {
        case TAG_Nil: {
          v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_245 = heff_field(v_ws_244, 0);
          V v_xs_246 = heff_field(v_ws_244, 1);
          heff_take_n(v_ws_244, 3ULL, 2);
          v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
          break;
        }
        default: heff_nomatch(v_ws_244);
        }
        V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_247);
        heff_drop(v_t_248);
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), v_x_240), ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5));
      } else {
        heff_drop(v_field_243);
        return v_x_240;
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2espineGo_24cpr(V v_h_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_SLocal: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SCode: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_h_240, 0);
    V v_a_246 = heff_field(v_h_240, 1);
    V v_ru_24h_240_24SApp = heff_take_reuse_n(v_h_240, 3ULL, 2);
    V t_0 = v_f_245;
    V t_1 = heff_tag_at_n(v_ru_24h_240_24SApp, TAG_Cons, 2, (V[]){v_a_246, v_acc_241});
    v_h_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SLam: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SCons: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SProj: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_STag: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SIs: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SOpaque: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SRec: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SFix: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{v_h_240, v_acc_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_h_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0, 12, "prelude.Pair");

HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V v_sp_240) {
top: ;
  V v_head_241 = heff_take_field(v_sp_240, 0);
  V v_args_242 = heff_get_n(v_sp_240, 1, 2);
  switch (heff_tag_of(v_head_241)) {
  case TAG_SLocal: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_head_241, 0);
    heff_take_n(v_head_241, 1ULL, 1);
    switch (heff_tag_of(v_args_242)) {
    case TAG_Nil: {
      heff_drop(v_x_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_args_242, 0);
      V v_it2_246 = heff_field(v_args_242, 1);
      V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        heff_drop(v_x_244);
        heff_drop(v_a_245);
        heff_drop_cell(v_ru_24args_242_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_b_247 = heff_field(v_it2_246, 0);
        V v_it22_248 = heff_field(v_it2_246, 1);
        V v_ru_24it2_246_24Cons = heff_take_reuse_n(v_it2_246, 3ULL, 2);
        switch (heff_tag_of(v_it22_248)) {
        case TAG_Nil: {
          if (heff_strEq_c(v_x_244, ((V)&g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0))) {
            V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_a_245), NTAG(TAG_Nil)));
            HeffT2 v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(v_t_249));
            V v_t_2414;
            {
              V v_field_2412 = v_t_2410.f[1];
              int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
              if ((v_tag_2411 == ((int64_t)0ULL))) {
                heff_drop(v_a_245);
                heff_drop_cell(v_ru_24args_242_24Cons, 2);
                V v_x_2413 = v_field_2412;
                v_t_2414 = v_x_2413;
              } else {
                heff_drop(v_field_2412);
                v_t_2414 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
              }
            }
            V v_t_2415 = heff_tag_at_n(v_ru_24it2_246_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
            V v_f_2416 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2415));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
          } else {
            heff_drop(v_a_245);
            heff_drop_cell(v_ru_24args_242_24Cons, 2);
            heff_drop(v_b_247);
            heff_drop_cell(v_ru_24it2_246_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_248, 0ULL, 2);
          heff_drop(v_x_244);
          heff_drop(v_a_245);
          heff_drop_cell(v_ru_24args_242_24Cons, 2);
          heff_drop(v_b_247);
          heff_drop_cell(v_ru_24it2_246_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it22_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_args_242)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_head_241, 0ULL, 3);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_head_241, 0ULL, 3);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_head_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2, 5, ") -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8, 2, "{{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str10, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str11, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str12, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str13, 6, "{{_ : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str14, 6, "}} -> ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_x6_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_244, 0);
    V v_b_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkAbs = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0), heff_dup(v_x_246)), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1));
      V v_t_249 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_249, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_248, v_t_2410), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2));
      V v_t_2412 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2412, MK_INT(0LL), heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){v_x_246, v_xs_241}), v_b_247));
      return heff_strAppend(v_t_2411, v_t_2413);
    }
    case TAG_Impl: {
      V v_c_2414 = v_c_240;
      V v_xs_2415 = heff_dup(v_xs_241);
      V v_dom_2416 = heff_dup(v_dom_243);
      V v_r_2443;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_2417 = heff_field(v_dom_243, 0);
        heff_take_n(v_dom_243, 1ULL, 1);
        V v_t_2418 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = ({ V a_0 = v_t_2418; V a_1 = v_u_2417; V a_2 = v_b_247; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241}); V r_ = (g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(a_0, a_1, a_2, a_3)); heff_drop(v_u_2417); r_; });
        break;
      }
      case TAG_SDecode: {
        heff_take_n(v_dom_243, 0ULL, 1);
        V v_t_2420 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2420, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SFunction: {
        heff_take_n(v_dom_243, 0ULL, 5);
        V v_t_2426 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2426, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SRecord: {
        heff_take_n(v_dom_243, 0ULL, 3);
        V v_t_2430 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2430, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SSum: {
        heff_take_n(v_dom_243, 0ULL, 1);
        V v_t_2432 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2432, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SIsTy: {
        heff_take_n(v_dom_243, 0ULL, 1);
        V v_t_2434 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2434, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2435 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2435, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2436 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2436, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2437 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2437, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SPrimRune: {
        V v_t_2438 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2438, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SPrimArray: {
        heff_take_n(v_dom_243, 0ULL, 1);
        V v_t_2440 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2440, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_dom_243, 0ULL, 1);
        V v_t_2442 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_r_2443 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2442, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      V v_names_2444 = heff_take_field(v_r_2443, 0);
      V v_ctx_2445 = heff_take_field(v_r_2443, 2);
      V v_rest_2446 = heff_get_n(v_r_2443, 1, 3);
      V v_t_2449;
      switch (heff_tag_of(v_names_2444)) {
      case TAG_Nil: {
        v_t_2449 = ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2447 = heff_field(v_names_2444, 0);
        V v_xs_2448 = heff_field(v_names_2444, 1);
        heff_take_n(v_names_2444, 3ULL, 2);
        v_t_2449 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
        break;
      }
      default: heff_nomatch(v_names_2444);
      }
      V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5), v_t_2449), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6));
      V v_t_2451 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_2414, 0)), heff_dup(heff_rfield(v_c_2414, 1)), NTAG(TAG_True)});
      V v_t_2452 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2451, MK_INT(0LL), v_xs_2415, v_dom_2416));
      V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2450, v_t_2452), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7));
      V v_t_2454 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_2414, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2455 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(0LL), v_ctx_2445, v_rest_2446));
      return heff_strAppend(v_t_2453, v_t_2455);
    }
    case TAG_Inst: {
      V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8), heff_dup(v_x_246)), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9));
      V v_t_2457 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2458 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2457, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2459 = heff_strAppend(heff_strAppend(v_t_2456, v_t_2458), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str10));
      V v_t_2460 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2461 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2460, MK_INT(0LL), heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){v_x_246, v_xs_241}), v_b_247));
      return heff_strAppend(v_t_2459, v_t_2461);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2462 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2463 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2464 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2463, MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2465 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2466 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2465, MK_INT(0LL), v_xs_241, v_b_2462));
      return heff_strAppend(heff_strAppend(v_t_2464, ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str11)), v_t_2466);
    }
    case TAG_Impl: {
      V v_t_2467 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2468 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2467, MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2469 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2470 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2469, MK_INT(0LL), v_xs_241, v_b_2462));
      return heff_strAppend(heff_strAppend(v_t_2468, ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str12)), v_t_2470);
    }
    case TAG_Inst: {
      V v_t_2471 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2472 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2471, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2473 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str13), v_t_2472), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str14));
      V v_t_2474 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2475 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2474, MK_INT(0LL), v_xs_241, v_b_2462));
      return heff_strAppend(v_t_2473, v_t_2475);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a5 = a[5]; V r = g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(a[0], a[1], a2, a[3], a[4], a5); heff_drop(a2); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "{_ : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "} -> ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), heff_dup(v_x_245)), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1));
    V v_t_248 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_248, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_247, v_t_249), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2));
    V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2410, v_t_2411), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3));
    V v_t_2413 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2413, MK_INT(0LL), heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){v_x_245, v_xs_241}), v_b_246));
    return heff_strAppend(v_t_2412, v_t_2414);
  }
  case TAG_AbsConst: {
    V v_b_2415 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2416, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2417), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5));
    V v_t_2419 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2419), ((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6));
    V v_t_2421 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2421, MK_INT(0LL), v_xs_241, v_b_2415));
    return heff_strAppend(v_t_2420, v_t_2422);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  V v_names_244 = heff_take_field(v_acc_242, 0);
  V v_out_245 = heff_get_n(v_acc_242, 1, 2);
  V v_byName_246 = heff_take_field(v_ds_241, 1);
  V v_values_247 = heff_get_n(v_ds_241, 2, 3);
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_248 = heff_field(v_x5_243, 0);
    V v_t_249 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_2410 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), heff_dup(v_names_244), v_t_249));
    V v_t_2412 = heff_strAppend(heff_strAppend(heff_dup(v_l_248), ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0)), v_t_2411);
    HeffT2 v_t_2413 = ({ V a_0 = v_byName_246; V a_1 = v_l_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_246); r_; });
    V v_t_2420;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_i_2416 = v_field_2415;
        V v_xs_2417 = v_values_247;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2416, 1) && heff_intLt_c(heff_dup(v_i_2416), heff_arrayLength_lent(v_xs_2417, 0)))) {
          V v_t_2418 = heff_arrayIndex(v_xs_2417, v_i_2416);
          V v_t_2419 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(v_names_244), v_t_2418));
          v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1), v_t_2419);
        } else {
          heff_drop_rec(v_c_240, 3);
          heff_drop(v_i_2416);
          heff_drop(v_xs_2417);
          v_t_2420 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
        }
      } else {
        heff_drop_rec(v_c_240, 3);
        heff_drop(v_values_247);
        heff_drop(v_field_2415);
        v_t_2420 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3);
      }
    }
    V v_t_2421 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, v_t_2420), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_out_245, v_t_2421));
    return heff_rec_n(2, shape_names__out, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_248, v_names_244}), v_t_2422});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str4, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_a_246)) {
    case TAG_SImplicit: {
      V v_a1_248 = heff_field(v_a_246, 0);
      V v_a2_249 = heff_field(v_a_246, 1);
      heff_take_n(v_a_246, 3ULL, 2);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop(v_a1_248);
        heff_drop(v_a2_249);
        heff_drop(v_t_2410);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_d_245;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      } else {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0), v_a1_248), ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1));
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_a2_249));
        V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2411, v_t_2412), ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2));
        V v_cell_2414 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
        V v_u_2415 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_cell_2414;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
    }
    default: {
      HeffT2 v_t_2416 = ({ V b_0 = heff_arrayToList(heff_dup(v_names_242)); V a_1 = heff_dup(v_i_243); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_m_2419 = v_field_2418;
          switch (heff_tag_of(v_m_2419)) {
          case TAG_Nothing: {
            V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_246));
            V v_cell_2421 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
            V v_u_2422 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2421));
            heff_drop(v_u_2422);
            V t_0 = v_c_240;
            V t_1 = v_xs_241;
            V t_2 = v_names_242;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            V t_4 = v_rest_247;
            V t_5 = v_cell_2421;
            v_c_240 = t_0;
            v_xs_241 = t_1;
            v_names_242 = t_2;
            v_i_243 = t_3;
            v_x6_244 = t_4;
            v_d_245 = t_5;
            goto top;
          }
          case TAG_Just: {
            V v_n_2423 = heff_field(v_m_2419, 0);
            heff_take_n(v_m_2419, 1ULL, 1);
            V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
            if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
              heff_drop(v_a_246);
              heff_drop_cell(v_ru_24x6_244_24Cons, 2);
              heff_drop(v_n_2423);
              heff_drop(v_t_2424);
              V t_0 = v_c_240;
              V t_1 = v_xs_241;
              V t_2 = v_names_242;
              V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
              V t_4 = v_rest_247;
              V t_5 = v_d_245;
              v_c_240 = t_0;
              v_xs_241 = t_1;
              v_names_242 = t_2;
              v_i_243 = t_3;
              v_x6_244 = t_4;
              v_d_245 = t_5;
              goto top;
            } else {
              heff_drop(v_t_2424);
              V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str3), v_n_2423), ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str4));
              V v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_a_246));
              V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2425, v_t_2426), ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str5));
              V v_cell_2428 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2427, heff_hole()});
              V v_u_2429 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2428));
              heff_drop(v_u_2429);
              V t_0 = v_c_240;
              V t_1 = v_xs_241;
              V t_2 = v_names_242;
              V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
              V t_4 = v_rest_247;
              V t_5 = v_cell_2428;
              v_c_240 = t_0;
              v_xs_241 = t_1;
              v_names_242 = t_2;
              v_i_243 = t_3;
              v_x6_244 = t_4;
              v_d_245 = t_5;
              goto top;
            }
          }
          default: return heff_nomatch(v_m_2419);
          }
        } else {
          heff_drop(v_field_2418);
          V v_t_2430 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_246));
          V v_cell_2431 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2430, heff_hole()});
          V v_u_2432 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2431));
          heff_drop(v_u_2432);
          V t_0 = v_c_240;
          V t_1 = v_xs_241;
          V t_2 = v_names_242;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          V t_4 = v_rest_247;
          V t_5 = v_cell_2431;
          v_c_240 = t_0;
          v_xs_241 = t_1;
          v_names_242 = t_2;
          v_i_243 = t_3;
          v_x6_244 = t_4;
          v_d_245 = t_5;
          goto top;
        }
      }
    }
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 4, " -> ");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2410), v_t_2411);
      V v_xs_2413 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2413, heff_dup(v_body_246)));
      return heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5)), v_t_2414);
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_c_240, v_p_241, v_xs_242, v_e_243));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    V v_f_2425 = (g_heff_2eelab_2eprimitive_2eprimName(v_x_2424));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return v_x1_240;
  }
  case TAG_SGlobal: {
    return v_x1_240;
  }
  case TAG_SCode: {
    return v_x1_240;
  }
  case TAG_SApp: {
    return v_x1_240;
  }
  case TAG_SLam: {
    return v_x1_240;
  }
  case TAG_SCons: {
    return v_x1_240;
  }
  case TAG_SProj: {
    return v_x1_240;
  }
  case TAG_STag: {
    return v_x1_240;
  }
  case TAG_SMatch: {
    return v_x1_240;
  }
  case TAG_SSpecialize: {
    return v_x1_240;
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_x1_240;
  }
  case TAG_SAbandon: {
    return v_x1_240;
  }
  case TAG_SRec: {
    return v_x1_240;
  }
  case TAG_SFix: {
    return v_x1_240;
  }
  case TAG_SImplicit: {
    return v_x1_240;
  }
  case TAG_SPrim: {
    return v_x1_240;
  }
  case TAG_SMetaApp: {
    return v_x1_240;
  }
  case TAG_SLitInt: {
    return v_x1_240;
  }
  case TAG_SLitFloat: {
    return v_x1_240;
  }
  case TAG_SLitString: {
    return v_x1_240;
  }
  case TAG_SLitBytes: {
    return v_x1_240;
  }
  case TAG_SLitRune: {
    return v_x1_240;
  }
  case TAG_SLitFixed: {
    return v_x1_240;
  }
  case TAG_SLitFloat32: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return v_x1_240;
  }
  case TAG_SDecode: {
    return v_x1_240;
  }
  case TAG_SFunction: {
    return v_x1_240;
  }
  case TAG_SRecord: {
    return v_x1_240;
  }
  case TAG_SSum: {
    return v_x1_240;
  }
  case TAG_SIsTy: {
    V v_d_2412 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_d_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_x1_240;
  }
  case TAG_SPrimFloat: {
    return v_x1_240;
  }
  case TAG_SPrimString: {
    return v_x1_240;
  }
  case TAG_SPrimRune: {
    return v_x1_240;
  }
  case TAG_SPrimArray: {
    return v_x1_240;
  }
  case TAG_SFixed: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eunIsTy(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9, 2, 0};
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0_clo), NTAG(TAG_False)});
    V v_t_249 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_248, v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_249, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_2410 = heff_field(v_x5_243, 0);
    V v_dom_2411 = heff_field(v_x5_243, 1);
    V v_cod_2412 = heff_field(v_x5_243, 2);
    V v_implicit_2413 = heff_field(v_x5_243, 3);
    V v_dflt_2414 = heff_field(v_x5_243, 4);
    V v_s_2424;
    switch (heff_tag_of(v_dflt_2414)) {
    case TAG_Nothing: {
      V v_t_2417 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1_clo), NTAG(TAG_False)});
      V v_t_2418 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2417, v_lit_240, NTAG(TAG_True)});
      v_s_2424 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(v_t_2418, v_xs_242, v_level_2410, heff_dup(v_dom_2411), heff_dup(v_cod_2412), v_implicit_2413));
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2414, 0);
      V v_t_2422 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2_clo), NTAG(TAG_False)});
      V v_t_2423 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2422, v_lit_240, NTAG(TAG_True)});
      v_s_2424 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_t_2423, v_xs_242, heff_dup(v_dom_2411), heff_dup(v_cod_2412), heff_dup(v_d_2419)));
      break;
    }
    default: heff_nomatch(v_dflt_2414);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str2), v_s_2424), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str3));
    } else {
      return v_s_2424;
    }
  }
  case TAG_SRecord: {
    V v_fs_2426 = heff_field(v_x5_243, 1);
    V v_ds_2427 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_keys_2428 = heff_dup(heff_rfield(v_fs_2426, 0));
    V v_values_2429 = heff_dup(heff_rfield(v_fs_2426, 2));
    V v_fs_2430 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_t_2431 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2438 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2427)}); V a_1 = v_t_2431; V a_2 = v_fs_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2430); r_; });
    V v_t_2439 = heff_get_n(v_acc_2438, 1, 2);
    V v_t_2442;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_t_2439, 0);
      V v_xs_2441 = heff_field(v_t_2439, 1);
      heff_take_n(v_t_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str5); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str6), v_t_2442), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str7));
  }
  case TAG_SSum: {
    V v_vs_2443 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_keys_2444 = heff_dup(heff_rfield(v_vs_2443, 0));
    V v_values_2445 = heff_dup(heff_rfield(v_vs_2443, 2));
    V v_t_2446 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2444), heff_arrayToList(v_values_2445)));
    V v_x2_2455 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2446));
    V v_t_2458;
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_Nil: {
      v_t_2458 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_xs_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      v_t_2458 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str10); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2455);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str11), v_t_2458), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str12));
  }
  case TAG_SIsTy: {
    V v_t2_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8_clo), NTAG(TAG_False)});
    V v_t_2463 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2462, v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2463, v_p_241, v_xs_242, heff_dup(v_t2_2459));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2464 = heff_field(v_x5_243, 0);
    V v_t_2467 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9_clo), NTAG(TAG_False)});
    V v_t_2468 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2467, v_lit_240, NTAG(TAG_True)});
    V v_t_2469 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2468, MK_INT(2LL), v_xs_242, heff_dup(v_a_2464)));
    V v_s_2470 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str17), v_t_2469);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str18), v_s_2470), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str19));
    } else {
      return v_s_2470;
    }
  }
  case TAG_SFixed: {
    V v_w_2471 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2471)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str28);
    }
    default: return heff_nomatch(v_w_2471);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  heff_drop(v_a_2415);
  heff_drop(v_a_2416);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2(V self, V *args) {
  V v_a_2420 = args[0];
  V v_a_2421 = args[1];
  heff_drop(v_a_2420);
  heff_drop(v_a_2421);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4(V self, V *args) {
  V v_a_2434 = args[0];
  V v_a_2435 = args[1];
  heff_drop(v_a_2434);
  heff_drop(v_a_2435);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_f_2433 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4_clo), NTAG(TAG_False)});
  V v_t_2437 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2436, v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2437, v_ds_2427, v_acc_2432, v_f_2433));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7(V self, V *args) {
  V v_a_2451 = args[0];
  V v_a_2452 = args[1];
  heff_drop(v_a_2451);
  heff_drop(v_a_2452);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6(V self, V *args) {
  V v_t2_2450 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7_clo), NTAG(TAG_False)});
  V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2453, v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(2LL), v_xs_242, v_t2_2450));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5(V self, V *args) {
  V v_v_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2447)) {
  case TAG_MkPair: {
    V v_t_2448 = heff_field(v_v_2447, 0);
    V v_ts_2449 = heff_field(v_v_2447, 1);
    heff_take_n(v_v_2447, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str8); V a_1 = v_t_2448; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2449); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2447);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9(V self, V *args) {
  V v_a_2465 = args[0];
  V v_a_2466 = args[1];
  heff_drop(v_a_2465);
  heff_drop(v_a_2466);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28, 5, " @ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return ({ V a_0 = v_xs_242; V a_1 = v_i_244; V r_ = (g_heff_2esyntax_2esurfaceprint_2elocalName(a_0, a_1)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0), 2)) {
      return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
    } else {
      HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_245, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_ws_249 = v_field_248;
          V v_t_2412;
          switch (heff_tag_of(v_ws_249)) {
          case TAG_Nil: {
            v_t_2412 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_2410 = heff_field(v_ws_249, 0);
            V v_xs_2411 = heff_field(v_ws_249, 1);
            heff_take_n(v_ws_249, 3ULL, 2);
            v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
            break;
          }
          default: heff_nomatch(v_ws_249);
          }
          V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3), v_t_2412);
          heff_drop(v_t_2413);
          return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4), v_x_245), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5));
        } else {
          heff_drop(v_field_248);
          return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
        }
      }
    }
  }
  case TAG_SCode: {
    V v_t_2414 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2415 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2415, v_p_241, v_xs_242, v_t_2414);
  }
  case TAG_SApp: {
    V v_f_2416 = heff_field(v_e_243, 0);
    V v_a_2417 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2418 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(v_t_2418, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2416, v_a_2417}));
  }
  case TAG_SLam: {
    V v_t_2419 = heff_field(v_e_243, 0);
    V v_b_2420 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2421 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2419, v_b_2420})));
    return ({ V a_0 = v_t_2421; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2422; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2423 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_keys_2424 = heff_take_field(v_d_2423, 0);
    V v_values_2425 = heff_get_n(v_d_2423, 2, 3);
    V v_t_2426 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2424), heff_arrayToList(v_values_2425)));
    V v_x2_2432 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2426));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2432);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9), v_t_2435), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10));
  }
  case TAG_SProj: {
    V v_e2_2436 = heff_field(v_e_243, 0);
    V v_l_2437 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2438 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2439 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2438, MK_INT(2LL), v_xs_242, v_e2_2436));
    return heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11)), v_l_2437);
  }
  case TAG_STag: {
    V v_x_2440 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2441 = heff_dup(heff_field(v_e_243, 1));
    HeffT2 v_t_2442 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_e_243));
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_x_2440);
        heff_drop(v_ts_2441);
        V v_items_2445 = v_field_2444;
        V v_x2_2448 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2445));
        V v_t_2451;
        switch (heff_tag_of(v_x2_2448)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_x2_2448, 0);
          V v_xs_2450 = heff_field(v_x2_2448, 1);
          heff_take_n(v_x2_2448, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2448);
        }
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14), v_t_2451), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15));
      } else {
        heff_drop(v_field_2444);
        V v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2441)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intEq_c(v_t_2452, MK_INT(0LL))) {
          heff_drop(v_lit_240);
          heff_drop(v_p_241);
          heff_drop(v_xs_242);
          heff_drop(v_ts_2441);
          return v_x_2440;
        } else {
          V v_s_2455 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16); V a_1 = v_x_2440; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2441); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
            return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17), v_s_2455), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18));
          } else {
            return v_s_2455;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    V v_s_2456 = heff_field(v_e_243, 0);
    V v_cases_2457 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_keys_2458 = heff_take_field(v_cases_2457, 0);
    V v_values_2459 = heff_get_n(v_cases_2457, 2, 3);
    V v_t_2460 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
    V v_t_2461 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2460, MK_INT(0LL), heff_dup(v_xs_242), v_s_2456));
    V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19), v_t_2461), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20));
    V v_t_2463 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2458), heff_arrayToList(v_values_2459)));
    V v_x2_2466 = (g_list_2emap_24tok2(v_ru_24e_243_24SMatch, heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2463));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_s_2470 = heff_strAppend(v_t_2462, v_t_2469);
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23), v_s_2470), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24));
    } else {
      return v_s_2470;
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_2474 = (g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(v_e_243, NTAG(TAG_Nil)));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_base_2477 = v_field_2475;
      V v_sets_2478 = v_field_2476;
      V v_t_2479 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
      V v_t_2480 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2479, MK_INT(1LL), heff_dup(v_xs_242), v_base_2477));
      V v_x2_2486 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4, 1, 2, (V[]){v_lit_240, v_xs_242}), v_sets_2478));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      V v_t_2490 = heff_strAppend(heff_strAppend(v_t_2480, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28)), v_t_2489);
      V v_s_2491 = heff_strAppend(v_t_2490, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29));
      if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30), v_s_2491), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31));
      } else {
        return v_s_2491;
      }
    }
  }
  case TAG_SIs: {
    V v_e2_2492 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2493 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2493, v_p_241, v_xs_242, v_e2_2492);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33);
  }
  case TAG_SRec: {
    V v_e2_2494 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2495 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2495, v_p_241, v_xs_242, v_e2_2494);
  }
  case TAG_SFix: {
    V v_e2_27_2497 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2497)) {
    case TAG_MkAbs: {
      V v_x_2498 = heff_field(v_e2_27_2497, 0);
      heff_take_n(v_e2_27_2497, 1ULL, 2);
      return v_x_2498;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2497, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34);
    }
    default: return heff_nomatch(v_e2_27_2497);
    }
  }
  case TAG_SImplicit: {
    V v_e2_24102 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V v_t_24103 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_24103, v_p_241, v_xs_242, v_e2_24102);
  }
  case TAG_SPrim: {
    V v_x_24104 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24105 = ({ V a_0 = v_x_24104; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_24104); r_; });
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35), v_t_24105), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36));
  }
  case TAG_SMetaApp: {
    V v_m_24106 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37), heff_intShow(v_m_24106));
  }
  case TAG_SLitInt: {
    V v_i_24109 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_24109);
  }
  case TAG_SLitFloat: {
    V v_x_24110 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24110);
  }
  case TAG_SLitString: {
    V v_s_24111 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24112 = (g_heff_2eutil_2erune_2equoteGo(v_s_24111, MK_INT(0LL), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38)));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39), v_t_24112), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40));
  }
  case TAG_SLitBytes: {
    V v_s_24113 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24114 = ({ V a_0 = v_s_24113; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41); V a_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42); V r_ = (g_heff_2eutil_2erune_2equoteBytesGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_24113); r_; });
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43), v_t_24114), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44));
  }
  case TAG_SLitRune: {
    V v_ch_24115 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24116 = (g_heff_2eutil_2erune_2equoted(v_ch_24115));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45), v_t_24116), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46));
  }
  case TAG_SLitFixed: {
    V v_n_24118 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_24118);
  }
  case TAG_SLitFloat32: {
    V v_x_24119 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24119);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args) {
  V v_f_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_f_2427, 0);
    V v_e_2429 = heff_field(v_f_2427, 1);
    heff_take_n(v_f_2427, 3ULL, 2);
    V v_t_2430 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2430, MK_INT(0LL), v_xs_242, v_e_2429));
    return heff_strAppend(heff_strAppend(v_l_2428, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6)), v_t_2431);
  }
  default: return heff_nomatch(v_f_2427);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args) {
  V v_a_2446 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2447, MK_INT(0LL), v_xs_242, v_a_2446));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2454, MK_INT(2LL), v_xs_242, v_a_2453));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args) {
  V v_alt_2464 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_box_word((heff_unbox_word(v_lit_240) + ((int64_t)2ULL))), NTAG(TAG_False)});
  return ({ V a_0 = v_t_2465; V a_1 = v_xs_242; V a_2 = v_alt_2464; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2464); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args) {
  V v_st_2481 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_st_2481, 0);
    V v_v_2483 = heff_field(v_st_2481, 1);
    heff_take_n(v_st_2481, 3ULL, 2);
    V v_t_2484 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2485 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2484, MK_INT(0LL), v_xs_242, v_v_2483));
    return heff_strAppend(heff_strAppend(v_x_2482, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25)), v_t_2485);
  }
  default: return heff_nomatch(v_st_2481);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_246 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_246, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_x5_243, 0);
    V v_dom_248 = heff_field(v_x5_243, 1);
    V v_cod_249 = heff_field(v_x5_243, 2);
    V v_implicit_2410 = heff_field(v_x5_243, 3);
    V v_dflt_2411 = heff_field(v_x5_243, 4);
    V v_s_2415;
    switch (heff_tag_of(v_dflt_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(v_t_2412, v_xs_242, v_level_247, heff_dup(v_dom_248), heff_dup(v_cod_249), v_implicit_2410));
      break;
    }
    case TAG_Just: {
      V v_d_2413 = heff_field(v_dflt_2411, 0);
      V v_t_2414 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_t_2414, v_xs_242, heff_dup(v_dom_248), heff_dup(v_cod_249), heff_dup(v_d_2413)));
      break;
    }
    default: heff_nomatch(v_dflt_2411);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2), v_s_2415), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3));
    } else {
      return v_s_2415;
    }
  }
  case TAG_SRecord: {
    V v_fs_2417 = heff_field(v_x5_243, 1);
    V v_ds_2418 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_keys_2419 = heff_dup(heff_rfield(v_fs_2417, 0));
    V v_values_2420 = heff_dup(heff_rfield(v_fs_2417, 2));
    V v_fs_2421 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2419), heff_arrayToList(v_values_2420)));
    V v_t_2422 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2426 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2418)}); V a_1 = v_t_2422; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
    V v_t_2427 = heff_get_n(v_acc_2426, 1, 2);
    V v_t_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_t_2427, 0);
      V v_xs_2429 = heff_field(v_t_2427, 1);
      heff_take_n(v_t_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6), v_t_2430), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7));
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_keys_2432 = heff_dup(heff_rfield(v_vs_2431, 0));
    V v_values_2433 = heff_dup(heff_rfield(v_vs_2431, 2));
    V v_t_2434 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
    V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2434));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11), v_t_2443), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12));
  }
  case TAG_SIsTy: {
    V v_t2_2444 = heff_field(v_x5_243, 0);
    V v_t_2445 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2445, v_p_241, v_xs_242, heff_dup(v_t2_2444));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2446 = heff_field(v_x5_243, 0);
    V v_t_2447 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    V v_t_2448 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2447, MK_INT(2LL), v_xs_242, heff_dup(v_a_2446)));
    V v_s_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17), v_t_2448);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18), v_s_2449), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19));
    } else {
      return v_s_2449;
    }
  }
  case TAG_SFixed: {
    V v_w_2450 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2450)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28);
    }
    default: return heff_nomatch(v_w_2450);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_f_2424 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2425, v_ds_2418, v_acc_2423, v_f_2424));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args) {
  V v_t2_2438 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2439, MK_INT(2LL), v_xs_242, v_t2_2438));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args) {
  V v_v_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2435)) {
  case TAG_MkPair: {
    V v_t_2436 = heff_field(v_v_2435, 0);
    V v_ts_2437 = heff_field(v_v_2435, 1);
    heff_take_n(v_v_2435, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8); V a_1 = v_t_2436; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2437); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2435);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str1, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str2, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str3, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str8, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str9, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str10, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str15, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str16, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str17, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str18, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str20, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str21, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str22, 1, "\012");
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr(V v_lit_240, V v_name_241, V v_tf_242) {
top: ;
  V v_def_243 = heff_take_field(v_tf_242, 2);
  V v_large_244 = heff_take_field(v_tf_242, 3);
  V v_params_245 = heff_take_field(v_tf_242, 0);
  V v_names_246 = heff_get_n(v_tf_242, 1, 4);
  switch (heff_tag_of(v_def_243)) {
  case TAG_SRecord: {
    V v_fs_248 = heff_dup(heff_field(v_def_243, 1));
    V v_ds_249 = heff_dup(heff_field(v_def_243, 2));
    V v_keys_2410 = heff_take_field(v_fs_248, 0);
    V v_values_2411 = heff_get_n(v_fs_248, 2, 3);
    if ((heff_dup(v_large_244) == NTAG(TAG_True))) {
      heff_drop_tag(v_def_243, 3);
      heff_drop(v_large_244);
      V v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str0); V a_1 = v_name_241; V a_2 = v_params_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_245); r_; });
      V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str1), v_t_2412), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str2));
      V v_fs_2414 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2410), heff_arrayToList(v_values_2411)));
      V v_t_2415 = heff_rec_n(2, shape_names__out, (V[]){v_names_246, NTAG(TAG_Nil)});
      V v_acc_2419 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam0, 2, 2, (V[]){v_lit_240, v_ds_249}); V a_1 = v_t_2415; V a_2 = v_fs_2414; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2414); r_; });
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str3), heff_get_n(v_acc_2419, 1, 2)));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str5); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_f_2424 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2423), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str6));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
    } else {
      heff_drop(v_large_244);
      heff_drop(v_ds_249);
      heff_drop(v_keys_2410);
      heff_drop(v_values_2411);
      V v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str7); V a_1 = v_name_241; V a_2 = v_params_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_245); r_; });
      V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str8), v_t_2425), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str9));
      V v_t_2427 = v_def_243;
      V v_t_2428 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2428, MK_INT(0LL), v_names_246, v_t_2427));
      V v_f_2430 = heff_strAppend(heff_strAppend(v_t_2426, v_t_2429), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str10));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
    }
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_def_243, 0);
    heff_take_n(v_def_243, 1ULL, 1);
    V v_keys_2432 = heff_take_field(v_vs_2431, 0);
    V v_values_2433 = heff_get_n(v_vs_2431, 2, 3);
    if ((heff_dup(v_large_244) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      heff_drop(v_names_246);
      heff_drop(v_keys_2432);
      heff_drop(v_values_2433);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_large_244);
      V v_t_2434 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str11); V a_1 = v_name_241; V a_2 = v_params_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_245); r_; });
      V v_x1_2435 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(heff_dup(v_keys_2432)), heff_arrayToList(heff_dup(v_values_2433))));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nil: {
        heff_drop(v_lit_240);
        heff_drop(v_names_246);
        heff_drop(v_keys_2432);
        heff_drop(v_values_2433);
        v_t_2448 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str12);
        break;
      }
      case TAG_Cons: {
        V v_ru_24x1_2435_24Cons = heff_take_reuse_n(v_x1_2435, 0ULL, 2);
        V v_t_2438 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
        V v_x2_2444 = (g_list_2emap_24tok2(v_ru_24x1_2435_24Cons, heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam1, 1, 2, (V[]){v_lit_240, v_names_246}), v_t_2438));
        V v_t_2447;
        switch (heff_tag_of(v_x2_2444)) {
        case TAG_Nil: {
          v_t_2447 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str14);
          break;
        }
        case TAG_Cons: {
          V v_x_2445 = heff_field(v_x2_2444, 0);
          V v_xs_2446 = heff_field(v_x2_2444, 1);
          heff_take_n(v_x2_2444, 3ULL, 2);
          v_t_2447 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str15); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2444);
        }
        v_t_2448 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str16), v_t_2447);
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str17), v_t_2434), v_t_2448);
      V v_f_2450 = heff_strAppend(v_t_2449, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str18));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
    }
  }
  default: {
    if ((heff_dup(v_large_244) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_def_243);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      heff_drop(v_names_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_large_244);
      V v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str19); V a_1 = v_name_241; V a_2 = v_params_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_245); r_; });
      V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str20), v_t_2451), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str21));
      V v_t_2453 = v_def_243;
      V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      V v_t_2455 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(0LL), v_names_246, v_t_2453));
      V v_f_2456 = heff_strAppend(heff_strAppend(v_t_2452, v_t_2455), ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str22));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2456}});
    }
  }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_f_2417 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2418, v_ds_249, v_acc_2416, v_f_2417));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam2(V self, V *args) {
  V v_t2_2442 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_names_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2443, MK_INT(2LL), v_names_246, v_t2_2442));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam1(V self, V *args) {
  V v_v_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_names_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2439)) {
  case TAG_MkPair: {
    V v_t_2440 = heff_field(v_v_2439, 0);
    V v_ts_2441 = heff_field(v_v_2439, 1);
    heff_take_n(v_v_2439, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_str13); V a_1 = v_t_2440; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr_lam2, 1, 2, (V[]){v_lit_240, v_names_246}); V b_3 = heff_arrayToList(v_ts_2441); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2439);
  }
}