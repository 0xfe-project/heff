// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_def 308863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo;
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    HeffT2 v_t_242 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_ws_246 = v_field_244;
        V v_t_249;
        switch (heff_tag_of(v_ws_246)) {
        case TAG_Nil: {
          v_t_249 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_247 = heff_field(v_ws_246, 0);
          V v_xs_248 = heff_field(v_ws_246, 1);
          heff_take_n(v_ws_246, 3ULL, 2);
          v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
          break;
        }
        default: heff_nomatch(v_ws_246);
        }
        V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_249);
        heff_drop(v_t_2410);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), heff_strAppend(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5)));
      } else {
        heff_drop(v_field_244);
        return v_x_240;
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}), v_b_246));
    V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), v_t_249));
    V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1), v_t_2410));
    V v_t_2412 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2), v_t_2411));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3), v_t_2412);
  }
  case TAG_AbsConst: {
    V v_b_2413 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), v_xs_241, v_b_2413));
    V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5), v_t_2417));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6), v_t_2418);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4, 3, " : ");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_245));
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ds_241, 1), v_l_244));
    V v_t_2418;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_i_2412 = v_field_2410;
        V v_xs_2413 = heff_get_n(v_ds_241, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_2412, 1)) {
          if (heff_intLt_c(heff_dup(v_i_2412), heff_arrayLength_lent(v_xs_2413, 0))) {
            V v_t_2416 = heff_arrayIndex(v_xs_2413, v_i_2412);
            V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_2416));
            v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0), v_t_2417);
          } else {
            heff_drop(v_c_240);
            heff_drop(v_i_2412);
            heff_drop(v_xs_2413);
            v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1);
          }
        } else {
          heff_drop(v_c_240);
          heff_drop(v_i_2412);
          heff_drop(v_xs_2413);
          v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
        }
      } else {
        heff_drop(v_c_240);
        heff_drop_rec(v_ds_241, 3);
        heff_drop(v_field_2410);
        v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3);
      }
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4), heff_strAppend(v_t_247, v_t_2418));
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_l_244, v_t_2419), NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2420));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_c_240, v_p_241, v_xs_242, v_e_243));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2424}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return v_x1_240;
  }
  case TAG_SGlobal: {
    return v_x1_240;
  }
  case TAG_SCode: {
    return v_x1_240;
  }
  case TAG_SApp: {
    return v_x1_240;
  }
  case TAG_SLam: {
    return v_x1_240;
  }
  case TAG_SCons: {
    return v_x1_240;
  }
  case TAG_SProj: {
    return v_x1_240;
  }
  case TAG_STag: {
    return v_x1_240;
  }
  case TAG_SMatch: {
    return v_x1_240;
  }
  case TAG_SSpecialize: {
    return v_x1_240;
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_x1_240;
  }
  case TAG_SAbandon: {
    return v_x1_240;
  }
  case TAG_SRec: {
    return v_x1_240;
  }
  case TAG_SFix: {
    return v_x1_240;
  }
  case TAG_SImplicit: {
    return v_x1_240;
  }
  case TAG_SPrim: {
    return v_x1_240;
  }
  case TAG_SMetaApp: {
    return v_x1_240;
  }
  case TAG_SLitInt: {
    return v_x1_240;
  }
  case TAG_SLitFloat: {
    return v_x1_240;
  }
  case TAG_SLitString: {
    return v_x1_240;
  }
  case TAG_SLitBytes: {
    return v_x1_240;
  }
  case TAG_SLitRune: {
    return v_x1_240;
  }
  case TAG_SLitFixed: {
    return v_x1_240;
  }
  case TAG_SLitFloat32: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9, 2, 0};
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_x5_243, 0);
    V v_dom_2410 = heff_field(v_x5_243, 1);
    V v_cod_2411 = heff_field(v_x5_243, 2);
    V v_implicit_2412 = heff_field(v_x5_243, 3);
    V v_dflt_2413 = heff_field(v_x5_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(heff_rec_n(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, heff_dup(v_dom_2410), heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(heff_rec_n(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, heff_dup(v_dom_2410), heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3)));
    } else {
      return v_s_2421;
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_x5_243, 1);
    V v_ds_2425 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 2)));
    V v_fs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_t_2436 = heff_get_n(v_acc_2435, 1, 2);
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_t_2436, 0);
      V v_xs_2438 = heff_field(v_t_2436, 1);
      heff_take_n(v_t_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 0)));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 2)));
    V v_t_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2451 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2455 = heff_field(v_x5_243, 0);
    V v_t_2458 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2458, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_t2_2455));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo), NTAG(TAG_False)});
    V v_t_2463 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2462, v_lit_240}), MK_INT(2LL), v_xs_242, heff_dup(v_a_2459)));
    V v_s_2464 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17), v_t_2463);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18), heff_strAppend(v_s_2464, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19)));
    } else {
      return v_s_2464;
    }
  }
  case TAG_SFixed: {
    V v_w_2466 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2466)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28);
    }
    default: return heff_nomatch(v_w_2466);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(heff_rec_n(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}), MK_INT(2LL), v_xs_242, v_t2_2447));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    heff_take_n(v_v_2444, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8); V a_1 = v_t_2445; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2446); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args) {
  V v_a_2456 = args[0];
  V v_a_2457 = args[1];
  heff_drop(v_a_2456);
  heff_drop(v_a_2457);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str2), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str4), heff_strAppend(v_x_241, v_t_247));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str5), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str7), heff_strAppend(v_x_241, v_t_2410));
  }
  case TAG_SFunction: {
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2417));
  }
  case TAG_SRecord: {
    V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2422));
  }
  case TAG_SSum: {
    V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2425));
  }
  case TAG_SIsTy: {
    V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str17), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2428));
  }
  case TAG_SPrimInt: {
    V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str20), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2430));
  }
  case TAG_SPrimFloat: {
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2432));
  }
  case TAG_SPrimString: {
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str26), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2434));
  }
  case TAG_SPrimRune: {
    V v_t_2435 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str29), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2436));
  }
  case TAG_SPrimArray: {
    V v_t_2438 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str32), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2439));
  }
  case TAG_SFixed: {
    V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2442));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2, 1, "\012");

HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_name_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_tf_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SU: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecode: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFunction: {
      heff_take_n(v_t_243, 0ULL, 5);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRecord: {
      heff_take_n(v_t_243, 0ULL, 3);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSum: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_t_2415 = heff_dup(heff_rfield(v_tf_242, 3));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_name_240);
        heff_drop(v_t_2415);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0), v_name_240, heff_rfield(v_tf_242, 0)));
        V v_f_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimInt: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimString: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimRune: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2410 = v_field_248;
        heff_drop(v_x_2410);
        V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str0), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str1)));
        return heff_strAppend(v_shown_242, v_t_2412);
      } else {
        heff_drop(v_field_248);
        V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str3)));
        V v_d_2415 = heff_strAppend(v_shown_242, v_t_2414);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2417 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2416; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_tf_2421 = v_field_2419;
            HeffT2 v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2421));
            {
              V v_field_2424 = v_t_2422.f[1];
              int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
              if ((v_tag_2423 == ((int64_t)0ULL))) {
                heff_drop(v_d_2415);
                V v_x_2426 = v_field_2424;
                return v_x_2426;
              } else {
                heff_drop(v_field_2424);
                return v_d_2415;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2419);
            return v_d_2415;
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2428 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2432 = v_field_2430;
        heff_drop(v_x_2432);
        V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str4), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str5)));
        return heff_strAppend(v_shown_242, v_t_2434);
      } else {
        heff_drop(v_field_2430);
        V v_t_2435 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str6), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str7)));
        V v_d_2437 = heff_strAppend(v_shown_242, v_t_2436);
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2439 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2438; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2441 = v_t_2439.f[1];
          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
          if ((v_tag_2440 == ((int64_t)0ULL))) {
            V v_tf_2443 = v_field_2441;
            HeffT2 v_t_2444 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2443));
            {
              V v_field_2446 = v_t_2444.f[1];
              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
              if ((v_tag_2445 == ((int64_t)0ULL))) {
                heff_drop(v_d_2437);
                V v_x_2448 = v_field_2446;
                return v_x_2448;
              } else {
                heff_drop(v_field_2446);
                return v_d_2437;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2441);
            return v_d_2437;
          }
        }
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2450 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2452 = v_t_2450.f[1];
      int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
      if ((v_tag_2451 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2454 = v_field_2452;
        heff_drop(v_x_2454);
        V v_t_2455 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2456 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str8), heff_strAppend(v_t_2455, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str9)));
        return heff_strAppend(v_shown_242, v_t_2456);
      } else {
        heff_drop(v_field_2452);
        V v_t_2457 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2458 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str10), heff_strAppend(v_t_2457, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str11)));
        V v_d_2459 = heff_strAppend(v_shown_242, v_t_2458);
        V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2461 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2460; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2463 = v_t_2461.f[1];
          int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
          if ((v_tag_2462 == ((int64_t)0ULL))) {
            V v_tf_2465 = v_field_2463;
            HeffT2 v_t_2466 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2465));
            {
              V v_field_2468 = v_t_2466.f[1];
              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
              if ((v_tag_2467 == ((int64_t)0ULL))) {
                heff_drop(v_d_2459);
                V v_x_2470 = v_field_2468;
                return v_x_2470;
              } else {
                heff_drop(v_field_2468);
                return v_d_2459;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2463);
            return v_d_2459;
          }
        }
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2477 = v_field_2475;
        heff_drop(v_x_2477);
        V v_t_2478 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str12), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str13)));
        return heff_strAppend(v_shown_242, v_t_2479);
      } else {
        heff_drop(v_field_2475);
        V v_t_2480 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2481 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str14), heff_strAppend(v_t_2480, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str15)));
        V v_d_2482 = heff_strAppend(v_shown_242, v_t_2481);
        V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2484 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2483; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2486 = v_t_2484.f[1];
          int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
          if ((v_tag_2485 == ((int64_t)0ULL))) {
            V v_tf_2488 = v_field_2486;
            HeffT2 v_t_2489 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2488));
            {
              V v_field_2491 = v_t_2489.f[1];
              int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
              if ((v_tag_2490 == ((int64_t)0ULL))) {
                heff_drop(v_d_2482);
                V v_x_2493 = v_field_2491;
                return v_x_2493;
              } else {
                heff_drop(v_field_2491);
                return v_d_2482;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2486);
            return v_d_2482;
          }
        }
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_2496 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2498 = v_t_2496.f[1];
      int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
      if ((v_tag_2497 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24100 = v_field_2498;
        heff_drop(v_x_24100);
        V v_t_24101 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str16), heff_strAppend(v_t_24101, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str17)));
        return heff_strAppend(v_shown_242, v_t_24102);
      } else {
        heff_drop(v_field_2498);
        V v_t_24103 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str18), heff_strAppend(v_t_24103, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str19)));
        V v_d_24105 = heff_strAppend(v_shown_242, v_t_24104);
        V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24107 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24106; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24109 = v_t_24107.f[1];
          int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
          if ((v_tag_24108 == ((int64_t)0ULL))) {
            V v_tf_24111 = v_field_24109;
            HeffT2 v_t_24112 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24111));
            {
              V v_field_24114 = v_t_24112.f[1];
              int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
              if ((v_tag_24113 == ((int64_t)0ULL))) {
                heff_drop(v_d_24105);
                V v_x_24116 = v_field_24114;
                return v_x_24116;
              } else {
                heff_drop(v_field_24114);
                return v_d_24105;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24109);
            return v_d_24105;
          }
        }
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_24118 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24120 = v_t_24118.f[1];
      int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
      if ((v_tag_24119 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24122 = v_field_24120;
        heff_drop(v_x_24122);
        V v_t_24123 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str20), heff_strAppend(v_t_24123, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str21)));
        return heff_strAppend(v_shown_242, v_t_24124);
      } else {
        heff_drop(v_field_24120);
        V v_t_24125 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str22), heff_strAppend(v_t_24125, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str23)));
        V v_d_24127 = heff_strAppend(v_shown_242, v_t_24126);
        V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24129 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24128; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24131 = v_t_24129.f[1];
          int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
          if ((v_tag_24130 == ((int64_t)0ULL))) {
            V v_tf_24133 = v_field_24131;
            HeffT2 v_t_24134 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24133));
            {
              V v_field_24136 = v_t_24134.f[1];
              int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
              if ((v_tag_24135 == ((int64_t)0ULL))) {
                heff_drop(v_d_24127);
                V v_x_24138 = v_field_24136;
                return v_x_24138;
              } else {
                heff_drop(v_field_24136);
                return v_d_24127;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24131);
            return v_d_24127;
          }
        }
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_24141 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24143 = v_t_24141.f[1];
      int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
      if ((v_tag_24142 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24145 = v_field_24143;
        heff_drop(v_x_24145);
        V v_t_24146 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24147 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str24), heff_strAppend(v_t_24146, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str25)));
        return heff_strAppend(v_shown_242, v_t_24147);
      } else {
        heff_drop(v_field_24143);
        V v_t_24148 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24149 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str26), heff_strAppend(v_t_24148, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str27)));
        V v_d_24150 = heff_strAppend(v_shown_242, v_t_24149);
        V v_t_24151 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24152 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24151; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24154 = v_t_24152.f[1];
          int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
          if ((v_tag_24153 == ((int64_t)0ULL))) {
            V v_tf_24156 = v_field_24154;
            HeffT2 v_t_24157 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24156));
            {
              V v_field_24159 = v_t_24157.f[1];
              int64_t v_tag_24158 = ((int64_t)v_t_24157.f[0]);
              if ((v_tag_24158 == ((int64_t)0ULL))) {
                heff_drop(v_d_24150);
                V v_x_24161 = v_field_24159;
                return v_x_24161;
              } else {
                heff_drop(v_field_24159);
                return v_d_24150;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24154);
            return v_d_24150;
          }
        }
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_24164 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24166 = v_t_24164.f[1];
      int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
      if ((v_tag_24165 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24168 = v_field_24166;
        heff_drop(v_x_24168);
        V v_t_24169 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24170 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str28), heff_strAppend(v_t_24169, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str29)));
        return heff_strAppend(v_shown_242, v_t_24170);
      } else {
        heff_drop(v_field_24166);
        V v_t_24171 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str30), heff_strAppend(v_t_24171, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str31)));
        V v_d_24173 = heff_strAppend(v_shown_242, v_t_24172);
        V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24175 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24174; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24177 = v_t_24175.f[1];
          int64_t v_tag_24176 = ((int64_t)v_t_24175.f[0]);
          if ((v_tag_24176 == ((int64_t)0ULL))) {
            V v_tf_24179 = v_field_24177;
            HeffT2 v_t_24180 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24179));
            {
              V v_field_24182 = v_t_24180.f[1];
              int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
              if ((v_tag_24181 == ((int64_t)0ULL))) {
                heff_drop(v_d_24173);
                V v_x_24184 = v_field_24182;
                return v_x_24184;
              } else {
                heff_drop(v_field_24182);
                return v_d_24173;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24177);
            return v_d_24173;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_24187 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24189 = v_t_24187.f[1];
      int64_t v_tag_24188 = ((int64_t)v_t_24187.f[0]);
      if ((v_tag_24188 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24191 = v_field_24189;
        heff_drop(v_x_24191);
        V v_t_24192 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24193 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str32), heff_strAppend(v_t_24192, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str33)));
        return heff_strAppend(v_shown_242, v_t_24193);
      } else {
        heff_drop(v_field_24189);
        V v_t_24194 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str34), heff_strAppend(v_t_24194, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str35)));
        V v_d_24196 = heff_strAppend(v_shown_242, v_t_24195);
        V v_t_24197 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24198 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24197; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24200 = v_t_24198.f[1];
          int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
          if ((v_tag_24199 == ((int64_t)0ULL))) {
            V v_tf_24202 = v_field_24200;
            HeffT2 v_t_24203 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24202));
            {
              V v_field_24205 = v_t_24203.f[1];
              int64_t v_tag_24204 = ((int64_t)v_t_24203.f[0]);
              if ((v_tag_24204 == ((int64_t)0ULL))) {
                heff_drop(v_d_24196);
                V v_x_24207 = v_field_24205;
                return v_x_24207;
              } else {
                heff_drop(v_field_24205);
                return v_d_24196;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24200);
            return v_d_24196;
          }
        }
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_24211 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24213 = v_t_24211.f[1];
      int64_t v_tag_24212 = ((int64_t)v_t_24211.f[0]);
      if ((v_tag_24212 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24215 = v_field_24213;
        heff_drop(v_x_24215);
        V v_t_24216 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24217 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str36), heff_strAppend(v_t_24216, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str37)));
        return heff_strAppend(v_shown_242, v_t_24217);
      } else {
        heff_drop(v_field_24213);
        V v_t_24218 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24219 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str38), heff_strAppend(v_t_24218, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str39)));
        V v_d_24220 = heff_strAppend(v_shown_242, v_t_24219);
        V v_t_24221 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24222 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24221; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24224 = v_t_24222.f[1];
          int64_t v_tag_24223 = ((int64_t)v_t_24222.f[0]);
          if ((v_tag_24223 == ((int64_t)0ULL))) {
            V v_tf_24226 = v_field_24224;
            HeffT2 v_t_24227 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24226));
            {
              V v_field_24229 = v_t_24227.f[1];
              int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
              if ((v_tag_24228 == ((int64_t)0ULL))) {
                heff_drop(v_d_24220);
                V v_x_24231 = v_field_24229;
                return v_x_24231;
              } else {
                heff_drop(v_field_24229);
                return v_d_24220;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24224);
            return v_d_24220;
          }
        }
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_24233 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24235 = v_t_24233.f[1];
      int64_t v_tag_24234 = ((int64_t)v_t_24233.f[0]);
      if ((v_tag_24234 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24237 = v_field_24235;
        heff_drop(v_x_24237);
        V v_t_24238 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24239 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str40), heff_strAppend(v_t_24238, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str41)));
        return heff_strAppend(v_shown_242, v_t_24239);
      } else {
        heff_drop(v_field_24235);
        V v_t_24240 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24241 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str42), heff_strAppend(v_t_24240, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str43)));
        V v_d_24242 = heff_strAppend(v_shown_242, v_t_24241);
        V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24244 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24243; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24246 = v_t_24244.f[1];
          int64_t v_tag_24245 = ((int64_t)v_t_24244.f[0]);
          if ((v_tag_24245 == ((int64_t)0ULL))) {
            V v_tf_24248 = v_field_24246;
            HeffT2 v_t_24249 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24248));
            {
              V v_field_24251 = v_t_24249.f[1];
              int64_t v_tag_24250 = ((int64_t)v_t_24249.f[0]);
              if ((v_tag_24250 == ((int64_t)0ULL))) {
                heff_drop(v_d_24242);
                V v_x_24253 = v_field_24251;
                return v_x_24253;
              } else {
                heff_drop(v_field_24251);
                return v_d_24242;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24246);
            return v_d_24242;
          }
        }
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_24254 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24256 = v_t_24254.f[1];
      int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
      if ((v_tag_24255 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        V v_x_24258 = v_field_24256;
        heff_drop(v_x_24258);
        V v_t_24259 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24260 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str44), heff_strAppend(v_t_24259, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str45)));
        return heff_strAppend(v_shown_242, v_t_24260);
      } else {
        heff_drop(v_field_24256);
        V v_t_24261 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24262 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str46), heff_strAppend(v_t_24261, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str47)));
        V v_d_24263 = heff_strAppend(v_shown_242, v_t_24262);
        V v_t_24264 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24265 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24264; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24267 = v_t_24265.f[1];
          int64_t v_tag_24266 = ((int64_t)v_t_24265.f[0]);
          if ((v_tag_24266 == ((int64_t)0ULL))) {
            V v_tf_24269 = v_field_24267;
            HeffT2 v_t_24270 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24269));
            {
              V v_field_24272 = v_t_24270.f[1];
              int64_t v_tag_24271 = ((int64_t)v_t_24270.f[0]);
              if ((v_tag_24271 == ((int64_t)0ULL))) {
                heff_drop(v_d_24263);
                V v_x_24274 = v_field_24272;
                return v_x_24274;
              } else {
                heff_drop(v_field_24272);
                return v_d_24263;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24267);
            return v_d_24263;
          }
        }
      }
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24275 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
    V v_t_24276 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str48), heff_strAppend(v_t_24275, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24276);
  }
  case TAG_SRec: {
    HeffT2 v_t_24278 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24280 = v_t_24278.f[1];
      int64_t v_tag_24279 = ((int64_t)v_t_24278.f[0]);
      if ((v_tag_24279 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24282 = v_field_24280;
        heff_drop(v_x_24282);
        V v_t_24283 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24284 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str50), heff_strAppend(v_t_24283, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str51)));
        return heff_strAppend(v_shown_242, v_t_24284);
      } else {
        heff_drop(v_field_24280);
        V v_t_24285 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24286 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str52), heff_strAppend(v_t_24285, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str53)));
        V v_d_24287 = heff_strAppend(v_shown_242, v_t_24286);
        V v_t_24288 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24289 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24288; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24291 = v_t_24289.f[1];
          int64_t v_tag_24290 = ((int64_t)v_t_24289.f[0]);
          if ((v_tag_24290 == ((int64_t)0ULL))) {
            V v_tf_24293 = v_field_24291;
            HeffT2 v_t_24294 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24293));
            {
              V v_field_24296 = v_t_24294.f[1];
              int64_t v_tag_24295 = ((int64_t)v_t_24294.f[0]);
              if ((v_tag_24295 == ((int64_t)0ULL))) {
                heff_drop(v_d_24287);
                V v_x_24298 = v_field_24296;
                return v_x_24298;
              } else {
                heff_drop(v_field_24296);
                return v_d_24287;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24291);
            return v_d_24287;
          }
        }
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24301 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24303 = v_t_24301.f[1];
      int64_t v_tag_24302 = ((int64_t)v_t_24301.f[0]);
      if ((v_tag_24302 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24305 = v_field_24303;
        heff_drop(v_x_24305);
        V v_t_24306 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24307 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str54), heff_strAppend(v_t_24306, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str55)));
        return heff_strAppend(v_shown_242, v_t_24307);
      } else {
        heff_drop(v_field_24303);
        V v_t_24308 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24309 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str56), heff_strAppend(v_t_24308, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str57)));
        V v_d_24310 = heff_strAppend(v_shown_242, v_t_24309);
        V v_t_24311 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24312 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24311; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24314 = v_t_24312.f[1];
          int64_t v_tag_24313 = ((int64_t)v_t_24312.f[0]);
          if ((v_tag_24313 == ((int64_t)0ULL))) {
            V v_tf_24316 = v_field_24314;
            HeffT2 v_t_24317 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24316));
            {
              V v_field_24319 = v_t_24317.f[1];
              int64_t v_tag_24318 = ((int64_t)v_t_24317.f[0]);
              if ((v_tag_24318 == ((int64_t)0ULL))) {
                heff_drop(v_d_24310);
                V v_x_24321 = v_field_24319;
                return v_x_24321;
              } else {
                heff_drop(v_field_24319);
                return v_d_24310;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24314);
            return v_d_24310;
          }
        }
      }
    }
  }
  case TAG_SImplicit: {
    HeffT2 v_t_24324 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24326 = v_t_24324.f[1];
      int64_t v_tag_24325 = ((int64_t)v_t_24324.f[0]);
      if ((v_tag_24325 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24328 = v_field_24326;
        heff_drop(v_x_24328);
        V v_t_24329 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24330 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str58), heff_strAppend(v_t_24329, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str59)));
        return heff_strAppend(v_shown_242, v_t_24330);
      } else {
        heff_drop(v_field_24326);
        V v_t_24331 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24332 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str60), heff_strAppend(v_t_24331, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str61)));
        V v_d_24333 = heff_strAppend(v_shown_242, v_t_24332);
        V v_t_24334 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24335 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24334; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24337 = v_t_24335.f[1];
          int64_t v_tag_24336 = ((int64_t)v_t_24335.f[0]);
          if ((v_tag_24336 == ((int64_t)0ULL))) {
            V v_tf_24339 = v_field_24337;
            HeffT2 v_t_24340 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24339));
            {
              V v_field_24342 = v_t_24340.f[1];
              int64_t v_tag_24341 = ((int64_t)v_t_24340.f[0]);
              if ((v_tag_24341 == ((int64_t)0ULL))) {
                heff_drop(v_d_24333);
                V v_x_24344 = v_field_24342;
                return v_x_24344;
              } else {
                heff_drop(v_field_24342);
                return v_d_24333;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24337);
            return v_d_24333;
          }
        }
      }
    }
  }
  case TAG_SPrim: {
    HeffT2 v_t_24346 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24348 = v_t_24346.f[1];
      int64_t v_tag_24347 = ((int64_t)v_t_24346.f[0]);
      if ((v_tag_24347 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24350 = v_field_24348;
        heff_drop(v_x_24350);
        V v_t_24351 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24352 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str62), heff_strAppend(v_t_24351, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str63)));
        return heff_strAppend(v_shown_242, v_t_24352);
      } else {
        heff_drop(v_field_24348);
        V v_t_24353 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24354 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str64), heff_strAppend(v_t_24353, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str65)));
        V v_d_24355 = heff_strAppend(v_shown_242, v_t_24354);
        V v_t_24356 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24357 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24356; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24359 = v_t_24357.f[1];
          int64_t v_tag_24358 = ((int64_t)v_t_24357.f[0]);
          if ((v_tag_24358 == ((int64_t)0ULL))) {
            V v_tf_24361 = v_field_24359;
            HeffT2 v_t_24362 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24361));
            {
              V v_field_24364 = v_t_24362.f[1];
              int64_t v_tag_24363 = ((int64_t)v_t_24362.f[0]);
              if ((v_tag_24363 == ((int64_t)0ULL))) {
                heff_drop(v_d_24355);
                V v_x_24366 = v_field_24364;
                return v_x_24366;
              } else {
                heff_drop(v_field_24364);
                return v_d_24355;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24359);
            return v_d_24355;
          }
        }
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24370 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24372 = v_t_24370.f[1];
      int64_t v_tag_24371 = ((int64_t)v_t_24370.f[0]);
      if ((v_tag_24371 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24374 = v_field_24372;
        heff_drop(v_x_24374);
        V v_t_24375 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24376 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str66), heff_strAppend(v_t_24375, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str67)));
        return heff_strAppend(v_shown_242, v_t_24376);
      } else {
        heff_drop(v_field_24372);
        V v_t_24377 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24378 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str68), heff_strAppend(v_t_24377, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str69)));
        V v_d_24379 = heff_strAppend(v_shown_242, v_t_24378);
        V v_t_24380 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24381 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24380; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24383 = v_t_24381.f[1];
          int64_t v_tag_24382 = ((int64_t)v_t_24381.f[0]);
          if ((v_tag_24382 == ((int64_t)0ULL))) {
            V v_tf_24385 = v_field_24383;
            HeffT2 v_t_24386 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24385));
            {
              V v_field_24388 = v_t_24386.f[1];
              int64_t v_tag_24387 = ((int64_t)v_t_24386.f[0]);
              if ((v_tag_24387 == ((int64_t)0ULL))) {
                heff_drop(v_d_24379);
                V v_x_24390 = v_field_24388;
                return v_x_24390;
              } else {
                heff_drop(v_field_24388);
                return v_d_24379;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24383);
            return v_d_24379;
          }
        }
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24392 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24394 = v_t_24392.f[1];
      int64_t v_tag_24393 = ((int64_t)v_t_24392.f[0]);
      if ((v_tag_24393 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24396 = v_field_24394;
        heff_drop(v_x_24396);
        V v_t_24397 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24398 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str70), heff_strAppend(v_t_24397, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str71)));
        return heff_strAppend(v_shown_242, v_t_24398);
      } else {
        heff_drop(v_field_24394);
        V v_t_24399 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24400 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str72), heff_strAppend(v_t_24399, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str73)));
        V v_d_24401 = heff_strAppend(v_shown_242, v_t_24400);
        V v_t_24402 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24403 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24402; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24405 = v_t_24403.f[1];
          int64_t v_tag_24404 = ((int64_t)v_t_24403.f[0]);
          if ((v_tag_24404 == ((int64_t)0ULL))) {
            V v_tf_24407 = v_field_24405;
            HeffT2 v_t_24408 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24407));
            {
              V v_field_24410 = v_t_24408.f[1];
              int64_t v_tag_24409 = ((int64_t)v_t_24408.f[0]);
              if ((v_tag_24409 == ((int64_t)0ULL))) {
                heff_drop(v_d_24401);
                V v_x_24412 = v_field_24410;
                return v_x_24412;
              } else {
                heff_drop(v_field_24410);
                return v_d_24401;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24405);
            return v_d_24401;
          }
        }
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24414 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24416 = v_t_24414.f[1];
      int64_t v_tag_24415 = ((int64_t)v_t_24414.f[0]);
      if ((v_tag_24415 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24418 = v_field_24416;
        heff_drop(v_x_24418);
        V v_t_24419 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24420 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str74), heff_strAppend(v_t_24419, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str75)));
        return heff_strAppend(v_shown_242, v_t_24420);
      } else {
        heff_drop(v_field_24416);
        V v_t_24421 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str76), heff_strAppend(v_t_24421, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str77)));
        V v_d_24423 = heff_strAppend(v_shown_242, v_t_24422);
        V v_t_24424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24425 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24424; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24427 = v_t_24425.f[1];
          int64_t v_tag_24426 = ((int64_t)v_t_24425.f[0]);
          if ((v_tag_24426 == ((int64_t)0ULL))) {
            V v_tf_24429 = v_field_24427;
            HeffT2 v_t_24430 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24429));
            {
              V v_field_24432 = v_t_24430.f[1];
              int64_t v_tag_24431 = ((int64_t)v_t_24430.f[0]);
              if ((v_tag_24431 == ((int64_t)0ULL))) {
                heff_drop(v_d_24423);
                V v_x_24434 = v_field_24432;
                return v_x_24434;
              } else {
                heff_drop(v_field_24432);
                return v_d_24423;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24427);
            return v_d_24423;
          }
        }
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24436 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24438 = v_t_24436.f[1];
      int64_t v_tag_24437 = ((int64_t)v_t_24436.f[0]);
      if ((v_tag_24437 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24440 = v_field_24438;
        heff_drop(v_x_24440);
        V v_t_24441 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str78), heff_strAppend(v_t_24441, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str79)));
        return heff_strAppend(v_shown_242, v_t_24442);
      } else {
        heff_drop(v_field_24438);
        V v_t_24443 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24444 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str80), heff_strAppend(v_t_24443, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str81)));
        V v_d_24445 = heff_strAppend(v_shown_242, v_t_24444);
        V v_t_24446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24447 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24446; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24449 = v_t_24447.f[1];
          int64_t v_tag_24448 = ((int64_t)v_t_24447.f[0]);
          if ((v_tag_24448 == ((int64_t)0ULL))) {
            V v_tf_24451 = v_field_24449;
            HeffT2 v_t_24452 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24451));
            {
              V v_field_24454 = v_t_24452.f[1];
              int64_t v_tag_24453 = ((int64_t)v_t_24452.f[0]);
              if ((v_tag_24453 == ((int64_t)0ULL))) {
                heff_drop(v_d_24445);
                V v_x_24456 = v_field_24454;
                return v_x_24456;
              } else {
                heff_drop(v_field_24454);
                return v_d_24445;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24449);
            return v_d_24445;
          }
        }
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24458 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24460 = v_t_24458.f[1];
      int64_t v_tag_24459 = ((int64_t)v_t_24458.f[0]);
      if ((v_tag_24459 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24462 = v_field_24460;
        heff_drop(v_x_24462);
        V v_t_24463 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24464 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str82), heff_strAppend(v_t_24463, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str83)));
        return heff_strAppend(v_shown_242, v_t_24464);
      } else {
        heff_drop(v_field_24460);
        V v_t_24465 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24466 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str84), heff_strAppend(v_t_24465, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str85)));
        V v_d_24467 = heff_strAppend(v_shown_242, v_t_24466);
        V v_t_24468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24469 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24468; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24471 = v_t_24469.f[1];
          int64_t v_tag_24470 = ((int64_t)v_t_24469.f[0]);
          if ((v_tag_24470 == ((int64_t)0ULL))) {
            V v_tf_24473 = v_field_24471;
            HeffT2 v_t_24474 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24473));
            {
              V v_field_24476 = v_t_24474.f[1];
              int64_t v_tag_24475 = ((int64_t)v_t_24474.f[0]);
              if ((v_tag_24475 == ((int64_t)0ULL))) {
                heff_drop(v_d_24467);
                V v_x_24478 = v_field_24476;
                return v_x_24478;
              } else {
                heff_drop(v_field_24476);
                return v_d_24467;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24471);
            return v_d_24467;
          }
        }
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24480 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24482 = v_t_24480.f[1];
      int64_t v_tag_24481 = ((int64_t)v_t_24480.f[0]);
      if ((v_tag_24481 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24484 = v_field_24482;
        heff_drop(v_x_24484);
        V v_t_24485 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24486 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str86), heff_strAppend(v_t_24485, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str87)));
        return heff_strAppend(v_shown_242, v_t_24486);
      } else {
        heff_drop(v_field_24482);
        V v_t_24487 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24488 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str88), heff_strAppend(v_t_24487, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str89)));
        V v_d_24489 = heff_strAppend(v_shown_242, v_t_24488);
        V v_t_24490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24491 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24490; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24493 = v_t_24491.f[1];
          int64_t v_tag_24492 = ((int64_t)v_t_24491.f[0]);
          if ((v_tag_24492 == ((int64_t)0ULL))) {
            V v_tf_24495 = v_field_24493;
            HeffT2 v_t_24496 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24495));
            {
              V v_field_24498 = v_t_24496.f[1];
              int64_t v_tag_24497 = ((int64_t)v_t_24496.f[0]);
              if ((v_tag_24497 == ((int64_t)0ULL))) {
                heff_drop(v_d_24489);
                V v_x_24500 = v_field_24498;
                return v_x_24500;
              } else {
                heff_drop(v_field_24498);
                return v_d_24489;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24493);
            return v_d_24489;
          }
        }
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24503 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24505 = v_t_24503.f[1];
      int64_t v_tag_24504 = ((int64_t)v_t_24503.f[0]);
      if ((v_tag_24504 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24507 = v_field_24505;
        heff_drop(v_x_24507);
        V v_t_24508 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24509 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str90), heff_strAppend(v_t_24508, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str91)));
        return heff_strAppend(v_shown_242, v_t_24509);
      } else {
        heff_drop(v_field_24505);
        V v_t_24510 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24511 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str92), heff_strAppend(v_t_24510, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str93)));
        V v_d_24512 = heff_strAppend(v_shown_242, v_t_24511);
        V v_t_24513 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24514 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24513; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24516 = v_t_24514.f[1];
          int64_t v_tag_24515 = ((int64_t)v_t_24514.f[0]);
          if ((v_tag_24515 == ((int64_t)0ULL))) {
            V v_tf_24518 = v_field_24516;
            HeffT2 v_t_24519 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24518));
            {
              V v_field_24521 = v_t_24519.f[1];
              int64_t v_tag_24520 = ((int64_t)v_t_24519.f[0]);
              if ((v_tag_24520 == ((int64_t)0ULL))) {
                heff_drop(v_d_24512);
                V v_x_24523 = v_field_24521;
                return v_x_24523;
              } else {
                heff_drop(v_field_24521);
                return v_d_24512;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24516);
            return v_d_24512;
          }
        }
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24525 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24527 = v_t_24525.f[1];
      int64_t v_tag_24526 = ((int64_t)v_t_24525.f[0]);
      if ((v_tag_24526 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24529 = v_field_24527;
        heff_drop(v_x_24529);
        V v_t_24530 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24531 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str94), heff_strAppend(v_t_24530, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str95)));
        return heff_strAppend(v_shown_242, v_t_24531);
      } else {
        heff_drop(v_field_24527);
        V v_t_24532 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24533 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str96), heff_strAppend(v_t_24532, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str97)));
        V v_d_24534 = heff_strAppend(v_shown_242, v_t_24533);
        V v_t_24535 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24536 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24535; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24538 = v_t_24536.f[1];
          int64_t v_tag_24537 = ((int64_t)v_t_24536.f[0]);
          if ((v_tag_24537 == ((int64_t)0ULL))) {
            V v_tf_24540 = v_field_24538;
            HeffT2 v_t_24541 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24540));
            {
              V v_field_24543 = v_t_24541.f[1];
              int64_t v_tag_24542 = ((int64_t)v_t_24541.f[0]);
              if ((v_tag_24542 == ((int64_t)0ULL))) {
                heff_drop(v_d_24534);
                V v_x_24545 = v_field_24543;
                return v_x_24545;
              } else {
                heff_drop(v_field_24543);
                return v_d_24534;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24538);
            return v_d_24534;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}