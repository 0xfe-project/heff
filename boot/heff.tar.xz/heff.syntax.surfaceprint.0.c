// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_typed 312202372
#define LBL_values 1123329101
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_clo;
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eopHead(V);
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo;
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    HeffT2 v_t_241 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_243 = v_t_241.f[1];
      int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
      if ((v_tag_242 == ((int64_t)0ULL))) {
        V v_ws_244 = v_field_243;
        V v_t_247;
        switch (heff_tag_of(v_ws_244)) {
        case TAG_Nil: {
          v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_245 = heff_field(v_ws_244, 0);
          V v_xs_246 = heff_field(v_ws_244, 1);
          heff_take_n(v_ws_244, 3ULL, 2);
          v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
          break;
        }
        default: heff_nomatch(v_ws_244);
        }
        V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_247);
        heff_drop(v_t_248);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), heff_strAppend(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5)));
      } else {
        heff_drop(v_field_243);
        return v_x_240;
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0, 12, "prelude.Pair");

HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V v_sp_240) {
top: ;
  V v_head_241 = heff_take_field(v_sp_240, 0);
  V v_args_242 = heff_get_n(v_sp_240, 1, 2);
  switch (heff_tag_of(v_head_241)) {
  case TAG_SLocal: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_head_241, 0);
    heff_take_n(v_head_241, 1ULL, 1);
    switch (heff_tag_of(v_args_242)) {
    case TAG_Nil: {
      heff_drop(v_x_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_args_242, 0);
      V v_it2_246 = heff_field(v_args_242, 1);
      V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        heff_drop(v_x_244);
        heff_drop(v_a_245);
        heff_drop_cell(v_ru_24args_242_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_b_247 = heff_field(v_it2_246, 0);
        V v_it22_248 = heff_field(v_it2_246, 1);
        V v_ru_24it2_246_24Cons = heff_take_reuse_n(v_it2_246, 3ULL, 2);
        switch (heff_tag_of(v_it22_248)) {
        case TAG_Nil: {
          if (heff_strEq_c(v_x_244, ((V)&g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0))) {
            V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_a_245), NTAG(TAG_Nil)));
            HeffT2 v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(v_t_249));
            V v_t_2414;
            {
              V v_field_2412 = v_t_2410.f[1];
              int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
              if ((v_tag_2411 == ((int64_t)0ULL))) {
                heff_drop(v_a_245);
                heff_drop_cell(v_ru_24args_242_24Cons, 2);
                V v_x_2413 = v_field_2412;
                v_t_2414 = v_x_2413;
              } else {
                heff_drop(v_field_2412);
                v_t_2414 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
              }
            }
            V v_t_2415 = heff_tag_at_n(v_ru_24it2_246_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
            V v_f_2416 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2415));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
          } else {
            heff_drop(v_a_245);
            heff_drop_cell(v_ru_24args_242_24Cons, 2);
            heff_drop(v_b_247);
            heff_drop_cell(v_ru_24it2_246_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_248, 0ULL, 2);
          heff_drop(v_x_244);
          heff_drop(v_a_245);
          heff_drop_cell(v_ru_24args_242_24Cons, 2);
          heff_drop(v_b_247);
          heff_drop_cell(v_ru_24it2_246_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it22_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_args_242)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_head_241, 0ULL, 3);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_head_241, 0ULL, 3);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_head_241, 0ULL, 2);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_head_241, 0ULL, 1);
    heff_drop(v_args_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_head_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_247, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2410 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}), v_b_246));
    V v_t_2412 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), v_t_2411));
    V v_t_2413 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1), v_t_2412));
    V v_t_2414 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2), v_t_2413));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3), v_t_2414);
  }
  case TAG_AbsConst: {
    V v_b_2415 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2416, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2419 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2419, MK_INT(0LL), v_xs_241, v_b_2415));
    V v_t_2421 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2420));
    V v_t_2422 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5), v_t_2421));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6), v_t_2422);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 3, " : ");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  V v_names_244 = heff_take_field(v_acc_242, 0);
  V v_out_245 = heff_get_n(v_acc_242, 1, 2);
  V v_byName_246 = heff_take_field(v_ds_241, 1);
  V v_values_247 = heff_get_n(v_ds_241, 2, 3);
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_248 = heff_field(v_x5_243, 0);
    V v_t_249 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_2410 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), heff_dup(v_names_244), v_t_249));
    HeffT2 v_t_2412 = ({ V a_0 = v_byName_246; V a_1 = v_l_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_byName_246); r_; });
    V v_t_2419;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_i_2415 = v_field_2414;
        V v_xs_2416 = v_values_247;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2415, 1) && heff_intLt_c(heff_dup(v_i_2415), heff_arrayLength_lent(v_xs_2416, 0)))) {
          V v_t_2417 = heff_arrayIndex(v_xs_2416, v_i_2415);
          V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(v_names_244), v_t_2417));
          v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0), v_t_2418);
        } else {
          heff_drop_rec(v_c_240, 3);
          heff_drop(v_i_2415);
          heff_drop(v_xs_2416);
          v_t_2419 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1);
        }
      } else {
        heff_drop_rec(v_c_240, 3);
        heff_drop(v_values_247);
        heff_drop(v_field_2414);
        v_t_2419 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
      }
    }
    V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3), heff_strAppend(v_t_2411, v_t_2419));
    V v_t_2421 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_l_248), v_t_2420), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_out_245, v_t_2421));
    return heff_rec_n(2, shape_names__out, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_248, v_names_244}), v_t_2422});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str3, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(heff_dup(v_c_240), v_xs_242, v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_248 = v_field_247;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_MkPair: {
        V v_l_249 = heff_field(v_it1_248, 0);
        V v_r2_2410 = heff_field(v_it1_248, 1);
        heff_take_n(v_it1_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_249));
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
        V v_t_2413 = ({ V b_0 = heff_get_n(v_t_2412, 0, 2); V r_ = (g_heff_2esyntax_2esurfaceprint_2eopHead(b_0)); heff_drop(b_0); r_; });
        V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(1LL), v_xs_242, v_r2_2410));
        V v_t_2415 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str0), v_t_2414));
        V v_s_2416 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str1), v_t_2415));
        if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str2), heff_strAppend(v_s_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str3)));
        } else {
          return v_s_2416;
        }
      }
      default: return heff_nomatch(v_it1_248);
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
      HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(v_c_240, v_p_241, v_xs_242, v_t_2417);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_c_240, v_p_241, v_xs_242, v_e_243));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2424}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return v_x1_240;
  }
  case TAG_SGlobal: {
    return v_x1_240;
  }
  case TAG_SCode: {
    return v_x1_240;
  }
  case TAG_SApp: {
    return v_x1_240;
  }
  case TAG_SLam: {
    return v_x1_240;
  }
  case TAG_SCons: {
    return v_x1_240;
  }
  case TAG_SProj: {
    return v_x1_240;
  }
  case TAG_STag: {
    return v_x1_240;
  }
  case TAG_SMatch: {
    return v_x1_240;
  }
  case TAG_SSpecialize: {
    return v_x1_240;
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_x1_240;
  }
  case TAG_SAbandon: {
    return v_x1_240;
  }
  case TAG_SRec: {
    return v_x1_240;
  }
  case TAG_SFix: {
    return v_x1_240;
  }
  case TAG_SImplicit: {
    return v_x1_240;
  }
  case TAG_SPrim: {
    return v_x1_240;
  }
  case TAG_SMetaApp: {
    return v_x1_240;
  }
  case TAG_SLitInt: {
    return v_x1_240;
  }
  case TAG_SLitFloat: {
    return v_x1_240;
  }
  case TAG_SLitString: {
    return v_x1_240;
  }
  case TAG_SLitBytes: {
    return v_x1_240;
  }
  case TAG_SLitRune: {
    return v_x1_240;
  }
  case TAG_SLitFixed: {
    return v_x1_240;
  }
  case TAG_SLitFloat32: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      switch (heff_tag_of(v_dom_242)) {
      case TAG_SU: {
        if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) <= ((int64_t)90ULL)))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      }
      default: return heff_nomatch(v_dom_242);
      }
    }
    case TAG_LargeU: {
      V v_t_245 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str2), heff_strAppend(v_t_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str4), heff_strAppend(v_x_241, v_t_246));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str5), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str7), heff_strAppend(v_x_241, v_t_249));
  }
  case TAG_SFunction: {
    V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str8), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2416));
  }
  case TAG_SRecord: {
    V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str11), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2421));
  }
  case TAG_SSum: {
    V v_t_2423 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str14), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2424));
  }
  case TAG_SIsTy: {
    V v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str17), heff_strAppend(v_t_2426, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2427));
  }
  case TAG_SPrimInt: {
    V v_t_2428 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str20), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2429));
  }
  case TAG_SPrimFloat: {
    V v_t_2430 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str23), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2431));
  }
  case TAG_SPrimString: {
    V v_t_2432 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str26), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2433));
  }
  case TAG_SPrimRune: {
    V v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str29), heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2435));
  }
  case TAG_SPrimArray: {
    V v_t_2437 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str32), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2438));
  }
  case TAG_SFixed: {
    V v_t_2440 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2441 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str35), heff_strAppend(v_t_2440, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2441));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2, 1, "\012");

HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_name_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_tf_242 = heff_field(v_x2_241, 0);
    V v_def_243 = heff_dup(heff_rfield(v_tf_242, 2));
    V v_large_244 = heff_dup(heff_rfield(v_tf_242, 3));
    V v_params_245 = heff_dup(heff_rfield(v_tf_242, 0));
    switch (heff_tag_of(v_def_243)) {
    case TAG_SU: {
      heff_take_n(v_def_243, 0ULL, 1);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecode: {
      heff_take_n(v_def_243, 0ULL, 1);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFunction: {
      heff_take_n(v_def_243, 0ULL, 5);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRecord: {
      heff_take_n(v_def_243, 0ULL, 3);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSum: {
      heff_take_n(v_def_243, 0ULL, 1);
      if (!(heff_dup(v_large_244) == NTAG(TAG_True))) {
        heff_drop(v_large_244);
        V v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0); V a_1 = v_name_240; V a_2 = v_params_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_245); r_; });
        V v_f_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
      } else {
        heff_drop(v_name_240);
        heff_drop(v_large_244);
        heff_drop(v_params_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_def_243, 0ULL, 1);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimInt: {
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimString: {
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimRune: {
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_def_243, 0ULL, 1);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_take_n(v_def_243, 0ULL, 1);
      heff_drop(v_name_240);
      heff_drop(v_large_244);
      heff_drop(v_params_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_def_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_249 = v_field_248;
        heff_drop(v_x_249);
        V v_t_2410 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str0), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str1)));
        return heff_strAppend(v_shown_242, v_t_2412);
      } else {
        heff_drop(v_field_248);
        V v_t_2413 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2413, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str2), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str3)));
        V v_d_2416 = heff_strAppend(v_shown_242, v_t_2415);
        V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2418 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2417; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_tf_2421 = v_field_2420;
            V v_t_2422 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2423 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2422, v_name_241, v_tf_2421));
            {
              V v_field_2425 = v_t_2423.f[1];
              int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
              if ((v_tag_2424 == ((int64_t)0ULL))) {
                heff_drop(v_d_2416);
                V v_x_2426 = v_field_2425;
                return v_x_2426;
              } else {
                heff_drop(v_field_2425);
                return v_d_2416;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2420);
            return v_d_2416;
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2428 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2431 = v_field_2430;
        heff_drop(v_x_2431);
        V v_t_2432 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2432, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str4), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str5)));
        return heff_strAppend(v_shown_242, v_t_2434);
      } else {
        heff_drop(v_field_2430);
        V v_t_2435 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2436 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2435, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2437 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str6), heff_strAppend(v_t_2436, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str7)));
        V v_d_2438 = heff_strAppend(v_shown_242, v_t_2437);
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2440 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2439; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          if ((v_tag_2441 == ((int64_t)0ULL))) {
            V v_tf_2443 = v_field_2442;
            V v_t_2444 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2445 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2444, v_name_241, v_tf_2443));
            {
              V v_field_2447 = v_t_2445.f[1];
              int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
              if ((v_tag_2446 == ((int64_t)0ULL))) {
                heff_drop(v_d_2438);
                V v_x_2448 = v_field_2447;
                return v_x_2448;
              } else {
                heff_drop(v_field_2447);
                return v_d_2438;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2442);
            return v_d_2438;
          }
        }
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2450 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2452 = v_t_2450.f[1];
      int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
      if ((v_tag_2451 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2453 = v_field_2452;
        heff_drop(v_x_2453);
        V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2455 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2456 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str8), heff_strAppend(v_t_2455, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str9)));
        return heff_strAppend(v_shown_242, v_t_2456);
      } else {
        heff_drop(v_field_2452);
        V v_t_2457 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2458 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2457, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2459 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str10), heff_strAppend(v_t_2458, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str11)));
        V v_d_2460 = heff_strAppend(v_shown_242, v_t_2459);
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2462 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2461; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2464 = v_t_2462.f[1];
          int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
          if ((v_tag_2463 == ((int64_t)0ULL))) {
            V v_tf_2465 = v_field_2464;
            V v_t_2466 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2467 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2466, v_name_241, v_tf_2465));
            {
              V v_field_2469 = v_t_2467.f[1];
              int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
              if ((v_tag_2468 == ((int64_t)0ULL))) {
                heff_drop(v_d_2460);
                V v_x_2470 = v_field_2469;
                return v_x_2470;
              } else {
                heff_drop(v_field_2469);
                return v_d_2460;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2464);
            return v_d_2460;
          }
        }
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2476 = v_field_2475;
        heff_drop(v_x_2476);
        V v_t_2477 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2478 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2477, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str12), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str13)));
        return heff_strAppend(v_shown_242, v_t_2479);
      } else {
        heff_drop(v_field_2475);
        V v_t_2480 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2481 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2480, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2482 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str14), heff_strAppend(v_t_2481, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str15)));
        V v_d_2483 = heff_strAppend(v_shown_242, v_t_2482);
        V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2485 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2484; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2487 = v_t_2485.f[1];
          int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
          if ((v_tag_2486 == ((int64_t)0ULL))) {
            V v_tf_2488 = v_field_2487;
            V v_t_2489 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2490 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2489, v_name_241, v_tf_2488));
            {
              V v_field_2492 = v_t_2490.f[1];
              int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
              if ((v_tag_2491 == ((int64_t)0ULL))) {
                heff_drop(v_d_2483);
                V v_x_2493 = v_field_2492;
                return v_x_2493;
              } else {
                heff_drop(v_field_2492);
                return v_d_2483;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2487);
            return v_d_2483;
          }
        }
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_2496 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2498 = v_t_2496.f[1];
      int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
      if ((v_tag_2497 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2499 = v_field_2498;
        heff_drop(v_x_2499);
        V v_t_24100 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24101 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24100, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str16), heff_strAppend(v_t_24101, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str17)));
        return heff_strAppend(v_shown_242, v_t_24102);
      } else {
        heff_drop(v_field_2498);
        V v_t_24103 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24104 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24103, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str18), heff_strAppend(v_t_24104, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str19)));
        V v_d_24106 = heff_strAppend(v_shown_242, v_t_24105);
        V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24108 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24107; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24110 = v_t_24108.f[1];
          int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
          if ((v_tag_24109 == ((int64_t)0ULL))) {
            V v_tf_24111 = v_field_24110;
            V v_t_24112 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24113 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24112, v_name_241, v_tf_24111));
            {
              V v_field_24115 = v_t_24113.f[1];
              int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
              if ((v_tag_24114 == ((int64_t)0ULL))) {
                heff_drop(v_d_24106);
                V v_x_24116 = v_field_24115;
                return v_x_24116;
              } else {
                heff_drop(v_field_24115);
                return v_d_24106;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24110);
            return v_d_24106;
          }
        }
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_24118 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24120 = v_t_24118.f[1];
      int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
      if ((v_tag_24119 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24121 = v_field_24120;
        heff_drop(v_x_24121);
        V v_t_24122 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24123 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24122, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str20), heff_strAppend(v_t_24123, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str21)));
        return heff_strAppend(v_shown_242, v_t_24124);
      } else {
        heff_drop(v_field_24120);
        V v_t_24125 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24126 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24125, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str22), heff_strAppend(v_t_24126, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str23)));
        V v_d_24128 = heff_strAppend(v_shown_242, v_t_24127);
        V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24130 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24129; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24132 = v_t_24130.f[1];
          int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
          if ((v_tag_24131 == ((int64_t)0ULL))) {
            V v_tf_24133 = v_field_24132;
            V v_t_24134 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24135 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24134, v_name_241, v_tf_24133));
            {
              V v_field_24137 = v_t_24135.f[1];
              int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
              if ((v_tag_24136 == ((int64_t)0ULL))) {
                heff_drop(v_d_24128);
                V v_x_24138 = v_field_24137;
                return v_x_24138;
              } else {
                heff_drop(v_field_24137);
                return v_d_24128;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24132);
            return v_d_24128;
          }
        }
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_24141 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24143 = v_t_24141.f[1];
      int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
      if ((v_tag_24142 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24144 = v_field_24143;
        heff_drop(v_x_24144);
        V v_t_24145 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24146 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24145, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24147 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str24), heff_strAppend(v_t_24146, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str25)));
        return heff_strAppend(v_shown_242, v_t_24147);
      } else {
        heff_drop(v_field_24143);
        V v_t_24148 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24149 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24148, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24150 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str26), heff_strAppend(v_t_24149, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str27)));
        V v_d_24151 = heff_strAppend(v_shown_242, v_t_24150);
        V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24153 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24152; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24155 = v_t_24153.f[1];
          int64_t v_tag_24154 = ((int64_t)v_t_24153.f[0]);
          if ((v_tag_24154 == ((int64_t)0ULL))) {
            V v_tf_24156 = v_field_24155;
            V v_t_24157 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24158 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24157, v_name_241, v_tf_24156));
            {
              V v_field_24160 = v_t_24158.f[1];
              int64_t v_tag_24159 = ((int64_t)v_t_24158.f[0]);
              if ((v_tag_24159 == ((int64_t)0ULL))) {
                heff_drop(v_d_24151);
                V v_x_24161 = v_field_24160;
                return v_x_24161;
              } else {
                heff_drop(v_field_24160);
                return v_d_24151;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24155);
            return v_d_24151;
          }
        }
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_24164 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24166 = v_t_24164.f[1];
      int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
      if ((v_tag_24165 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24167 = v_field_24166;
        heff_drop(v_x_24167);
        V v_t_24168 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24169 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24168, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24170 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str28), heff_strAppend(v_t_24169, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str29)));
        return heff_strAppend(v_shown_242, v_t_24170);
      } else {
        heff_drop(v_field_24166);
        V v_t_24171 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24172 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24171, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24173 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str30), heff_strAppend(v_t_24172, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str31)));
        V v_d_24174 = heff_strAppend(v_shown_242, v_t_24173);
        V v_t_24175 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24176 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24175; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24178 = v_t_24176.f[1];
          int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
          if ((v_tag_24177 == ((int64_t)0ULL))) {
            V v_tf_24179 = v_field_24178;
            V v_t_24180 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24181 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24180, v_name_241, v_tf_24179));
            {
              V v_field_24183 = v_t_24181.f[1];
              int64_t v_tag_24182 = ((int64_t)v_t_24181.f[0]);
              if ((v_tag_24182 == ((int64_t)0ULL))) {
                heff_drop(v_d_24174);
                V v_x_24184 = v_field_24183;
                return v_x_24184;
              } else {
                heff_drop(v_field_24183);
                return v_d_24174;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24178);
            return v_d_24174;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_24187 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24189 = v_t_24187.f[1];
      int64_t v_tag_24188 = ((int64_t)v_t_24187.f[0]);
      if ((v_tag_24188 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24190 = v_field_24189;
        heff_drop(v_x_24190);
        V v_t_24191 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24192 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24191, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24193 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str32), heff_strAppend(v_t_24192, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str33)));
        return heff_strAppend(v_shown_242, v_t_24193);
      } else {
        heff_drop(v_field_24189);
        V v_t_24194 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24195 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24194, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24196 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str34), heff_strAppend(v_t_24195, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str35)));
        V v_d_24197 = heff_strAppend(v_shown_242, v_t_24196);
        V v_t_24198 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24199 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24198; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24201 = v_t_24199.f[1];
          int64_t v_tag_24200 = ((int64_t)v_t_24199.f[0]);
          if ((v_tag_24200 == ((int64_t)0ULL))) {
            V v_tf_24202 = v_field_24201;
            V v_t_24203 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24204 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24203, v_name_241, v_tf_24202));
            {
              V v_field_24206 = v_t_24204.f[1];
              int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
              if ((v_tag_24205 == ((int64_t)0ULL))) {
                heff_drop(v_d_24197);
                V v_x_24207 = v_field_24206;
                return v_x_24207;
              } else {
                heff_drop(v_field_24206);
                return v_d_24197;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24201);
            return v_d_24197;
          }
        }
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_24211 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24213 = v_t_24211.f[1];
      int64_t v_tag_24212 = ((int64_t)v_t_24211.f[0]);
      if ((v_tag_24212 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24214 = v_field_24213;
        heff_drop(v_x_24214);
        V v_t_24215 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24216 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24215, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24217 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str36), heff_strAppend(v_t_24216, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str37)));
        return heff_strAppend(v_shown_242, v_t_24217);
      } else {
        heff_drop(v_field_24213);
        V v_t_24218 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24219 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24218, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24220 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str38), heff_strAppend(v_t_24219, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str39)));
        V v_d_24221 = heff_strAppend(v_shown_242, v_t_24220);
        V v_t_24222 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24223 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24222; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24225 = v_t_24223.f[1];
          int64_t v_tag_24224 = ((int64_t)v_t_24223.f[0]);
          if ((v_tag_24224 == ((int64_t)0ULL))) {
            V v_tf_24226 = v_field_24225;
            V v_t_24227 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24228 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24227, v_name_241, v_tf_24226));
            {
              V v_field_24230 = v_t_24228.f[1];
              int64_t v_tag_24229 = ((int64_t)v_t_24228.f[0]);
              if ((v_tag_24229 == ((int64_t)0ULL))) {
                heff_drop(v_d_24221);
                V v_x_24231 = v_field_24230;
                return v_x_24231;
              } else {
                heff_drop(v_field_24230);
                return v_d_24221;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24225);
            return v_d_24221;
          }
        }
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_24233 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24235 = v_t_24233.f[1];
      int64_t v_tag_24234 = ((int64_t)v_t_24233.f[0]);
      if ((v_tag_24234 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24236 = v_field_24235;
        heff_drop(v_x_24236);
        V v_t_24237 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24238 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24237, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24239 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str40), heff_strAppend(v_t_24238, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str41)));
        return heff_strAppend(v_shown_242, v_t_24239);
      } else {
        heff_drop(v_field_24235);
        V v_t_24240 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24241 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24240, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str42), heff_strAppend(v_t_24241, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str43)));
        V v_d_24243 = heff_strAppend(v_shown_242, v_t_24242);
        V v_t_24244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24245 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24244; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24247 = v_t_24245.f[1];
          int64_t v_tag_24246 = ((int64_t)v_t_24245.f[0]);
          if ((v_tag_24246 == ((int64_t)0ULL))) {
            V v_tf_24248 = v_field_24247;
            V v_t_24249 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24250 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24249, v_name_241, v_tf_24248));
            {
              V v_field_24252 = v_t_24250.f[1];
              int64_t v_tag_24251 = ((int64_t)v_t_24250.f[0]);
              if ((v_tag_24251 == ((int64_t)0ULL))) {
                heff_drop(v_d_24243);
                V v_x_24253 = v_field_24252;
                return v_x_24253;
              } else {
                heff_drop(v_field_24252);
                return v_d_24243;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24247);
            return v_d_24243;
          }
        }
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_24254 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24256 = v_t_24254.f[1];
      int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
      if ((v_tag_24255 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        V v_x_24257 = v_field_24256;
        heff_drop(v_x_24257);
        V v_t_24258 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24259 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24258, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24260 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str44), heff_strAppend(v_t_24259, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str45)));
        return heff_strAppend(v_shown_242, v_t_24260);
      } else {
        heff_drop(v_field_24256);
        V v_t_24261 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24262 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24261, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24263 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str46), heff_strAppend(v_t_24262, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str47)));
        V v_d_24264 = heff_strAppend(v_shown_242, v_t_24263);
        V v_t_24265 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24266 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24265; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24268 = v_t_24266.f[1];
          int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
          if ((v_tag_24267 == ((int64_t)0ULL))) {
            V v_tf_24269 = v_field_24268;
            V v_t_24270 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24271 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24270, v_name_241, v_tf_24269));
            {
              V v_field_24273 = v_t_24271.f[1];
              int64_t v_tag_24272 = ((int64_t)v_t_24271.f[0]);
              if ((v_tag_24272 == ((int64_t)0ULL))) {
                heff_drop(v_d_24264);
                V v_x_24274 = v_field_24273;
                return v_x_24274;
              } else {
                heff_drop(v_field_24273);
                return v_d_24264;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24268);
            return v_d_24264;
          }
        }
      }
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24275 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
    V v_t_24276 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24275, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
    V v_t_24277 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str48), heff_strAppend(v_t_24276, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24277);
  }
  case TAG_SRec: {
    HeffT2 v_t_24279 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24281 = v_t_24279.f[1];
      int64_t v_tag_24280 = ((int64_t)v_t_24279.f[0]);
      if ((v_tag_24280 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24282 = v_field_24281;
        heff_drop(v_x_24282);
        V v_t_24283 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24284 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24283, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24285 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str50), heff_strAppend(v_t_24284, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str51)));
        return heff_strAppend(v_shown_242, v_t_24285);
      } else {
        heff_drop(v_field_24281);
        V v_t_24286 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24287 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24286, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24288 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str52), heff_strAppend(v_t_24287, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str53)));
        V v_d_24289 = heff_strAppend(v_shown_242, v_t_24288);
        V v_t_24290 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24291 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24290; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24293 = v_t_24291.f[1];
          int64_t v_tag_24292 = ((int64_t)v_t_24291.f[0]);
          if ((v_tag_24292 == ((int64_t)0ULL))) {
            V v_tf_24294 = v_field_24293;
            V v_t_24295 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24296 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24295, v_name_241, v_tf_24294));
            {
              V v_field_24298 = v_t_24296.f[1];
              int64_t v_tag_24297 = ((int64_t)v_t_24296.f[0]);
              if ((v_tag_24297 == ((int64_t)0ULL))) {
                heff_drop(v_d_24289);
                V v_x_24299 = v_field_24298;
                return v_x_24299;
              } else {
                heff_drop(v_field_24298);
                return v_d_24289;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24293);
            return v_d_24289;
          }
        }
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24302 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24304 = v_t_24302.f[1];
      int64_t v_tag_24303 = ((int64_t)v_t_24302.f[0]);
      if ((v_tag_24303 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24305 = v_field_24304;
        heff_drop(v_x_24305);
        V v_t_24306 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24307 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24306, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24308 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str54), heff_strAppend(v_t_24307, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str55)));
        return heff_strAppend(v_shown_242, v_t_24308);
      } else {
        heff_drop(v_field_24304);
        V v_t_24309 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24310 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24309, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24311 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str56), heff_strAppend(v_t_24310, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str57)));
        V v_d_24312 = heff_strAppend(v_shown_242, v_t_24311);
        V v_t_24313 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24314 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24313; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24316 = v_t_24314.f[1];
          int64_t v_tag_24315 = ((int64_t)v_t_24314.f[0]);
          if ((v_tag_24315 == ((int64_t)0ULL))) {
            V v_tf_24317 = v_field_24316;
            V v_t_24318 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24319 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24318, v_name_241, v_tf_24317));
            {
              V v_field_24321 = v_t_24319.f[1];
              int64_t v_tag_24320 = ((int64_t)v_t_24319.f[0]);
              if ((v_tag_24320 == ((int64_t)0ULL))) {
                heff_drop(v_d_24312);
                V v_x_24322 = v_field_24321;
                return v_x_24322;
              } else {
                heff_drop(v_field_24321);
                return v_d_24312;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24316);
            return v_d_24312;
          }
        }
      }
    }
  }
  case TAG_SImplicit: {
    HeffT2 v_t_24325 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24327 = v_t_24325.f[1];
      int64_t v_tag_24326 = ((int64_t)v_t_24325.f[0]);
      if ((v_tag_24326 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24328 = v_field_24327;
        heff_drop(v_x_24328);
        V v_t_24329 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24330 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24329, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24331 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str58), heff_strAppend(v_t_24330, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str59)));
        return heff_strAppend(v_shown_242, v_t_24331);
      } else {
        heff_drop(v_field_24327);
        V v_t_24332 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24333 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24332, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24334 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str60), heff_strAppend(v_t_24333, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str61)));
        V v_d_24335 = heff_strAppend(v_shown_242, v_t_24334);
        V v_t_24336 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24337 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24336; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24339 = v_t_24337.f[1];
          int64_t v_tag_24338 = ((int64_t)v_t_24337.f[0]);
          if ((v_tag_24338 == ((int64_t)0ULL))) {
            V v_tf_24340 = v_field_24339;
            V v_t_24341 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24342 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24341, v_name_241, v_tf_24340));
            {
              V v_field_24344 = v_t_24342.f[1];
              int64_t v_tag_24343 = ((int64_t)v_t_24342.f[0]);
              if ((v_tag_24343 == ((int64_t)0ULL))) {
                heff_drop(v_d_24335);
                V v_x_24345 = v_field_24344;
                return v_x_24345;
              } else {
                heff_drop(v_field_24344);
                return v_d_24335;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24339);
            return v_d_24335;
          }
        }
      }
    }
  }
  case TAG_SPrim: {
    HeffT2 v_t_24347 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24349 = v_t_24347.f[1];
      int64_t v_tag_24348 = ((int64_t)v_t_24347.f[0]);
      if ((v_tag_24348 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24350 = v_field_24349;
        heff_drop(v_x_24350);
        V v_t_24351 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24352 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24351, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24353 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str62), heff_strAppend(v_t_24352, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str63)));
        return heff_strAppend(v_shown_242, v_t_24353);
      } else {
        heff_drop(v_field_24349);
        V v_t_24354 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24355 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24354, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24356 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str64), heff_strAppend(v_t_24355, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str65)));
        V v_d_24357 = heff_strAppend(v_shown_242, v_t_24356);
        V v_t_24358 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24359 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24358; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24361 = v_t_24359.f[1];
          int64_t v_tag_24360 = ((int64_t)v_t_24359.f[0]);
          if ((v_tag_24360 == ((int64_t)0ULL))) {
            V v_tf_24362 = v_field_24361;
            V v_t_24363 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24364 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24363, v_name_241, v_tf_24362));
            {
              V v_field_24366 = v_t_24364.f[1];
              int64_t v_tag_24365 = ((int64_t)v_t_24364.f[0]);
              if ((v_tag_24365 == ((int64_t)0ULL))) {
                heff_drop(v_d_24357);
                V v_x_24367 = v_field_24366;
                return v_x_24367;
              } else {
                heff_drop(v_field_24366);
                return v_d_24357;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24361);
            return v_d_24357;
          }
        }
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24371 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24373 = v_t_24371.f[1];
      int64_t v_tag_24372 = ((int64_t)v_t_24371.f[0]);
      if ((v_tag_24372 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24374 = v_field_24373;
        heff_drop(v_x_24374);
        V v_t_24375 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24376 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24375, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24377 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str66), heff_strAppend(v_t_24376, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str67)));
        return heff_strAppend(v_shown_242, v_t_24377);
      } else {
        heff_drop(v_field_24373);
        V v_t_24378 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24379 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24378, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24380 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str68), heff_strAppend(v_t_24379, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str69)));
        V v_d_24381 = heff_strAppend(v_shown_242, v_t_24380);
        V v_t_24382 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24383 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24382; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24385 = v_t_24383.f[1];
          int64_t v_tag_24384 = ((int64_t)v_t_24383.f[0]);
          if ((v_tag_24384 == ((int64_t)0ULL))) {
            V v_tf_24386 = v_field_24385;
            V v_t_24387 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24388 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24387, v_name_241, v_tf_24386));
            {
              V v_field_24390 = v_t_24388.f[1];
              int64_t v_tag_24389 = ((int64_t)v_t_24388.f[0]);
              if ((v_tag_24389 == ((int64_t)0ULL))) {
                heff_drop(v_d_24381);
                V v_x_24391 = v_field_24390;
                return v_x_24391;
              } else {
                heff_drop(v_field_24390);
                return v_d_24381;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24385);
            return v_d_24381;
          }
        }
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24393 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24395 = v_t_24393.f[1];
      int64_t v_tag_24394 = ((int64_t)v_t_24393.f[0]);
      if ((v_tag_24394 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24396 = v_field_24395;
        heff_drop(v_x_24396);
        V v_t_24397 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24398 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24397, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24399 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str70), heff_strAppend(v_t_24398, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str71)));
        return heff_strAppend(v_shown_242, v_t_24399);
      } else {
        heff_drop(v_field_24395);
        V v_t_24400 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24401 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24400, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24402 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str72), heff_strAppend(v_t_24401, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str73)));
        V v_d_24403 = heff_strAppend(v_shown_242, v_t_24402);
        V v_t_24404 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24405 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24404; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24407 = v_t_24405.f[1];
          int64_t v_tag_24406 = ((int64_t)v_t_24405.f[0]);
          if ((v_tag_24406 == ((int64_t)0ULL))) {
            V v_tf_24408 = v_field_24407;
            V v_t_24409 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24410 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24409, v_name_241, v_tf_24408));
            {
              V v_field_24412 = v_t_24410.f[1];
              int64_t v_tag_24411 = ((int64_t)v_t_24410.f[0]);
              if ((v_tag_24411 == ((int64_t)0ULL))) {
                heff_drop(v_d_24403);
                V v_x_24413 = v_field_24412;
                return v_x_24413;
              } else {
                heff_drop(v_field_24412);
                return v_d_24403;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24407);
            return v_d_24403;
          }
        }
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24415 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24417 = v_t_24415.f[1];
      int64_t v_tag_24416 = ((int64_t)v_t_24415.f[0]);
      if ((v_tag_24416 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24418 = v_field_24417;
        heff_drop(v_x_24418);
        V v_t_24419 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24420 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24419, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24421 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str74), heff_strAppend(v_t_24420, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str75)));
        return heff_strAppend(v_shown_242, v_t_24421);
      } else {
        heff_drop(v_field_24417);
        V v_t_24422 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24423 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24422, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24424 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str76), heff_strAppend(v_t_24423, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str77)));
        V v_d_24425 = heff_strAppend(v_shown_242, v_t_24424);
        V v_t_24426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24427 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24426; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24429 = v_t_24427.f[1];
          int64_t v_tag_24428 = ((int64_t)v_t_24427.f[0]);
          if ((v_tag_24428 == ((int64_t)0ULL))) {
            V v_tf_24430 = v_field_24429;
            V v_t_24431 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24432 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24431, v_name_241, v_tf_24430));
            {
              V v_field_24434 = v_t_24432.f[1];
              int64_t v_tag_24433 = ((int64_t)v_t_24432.f[0]);
              if ((v_tag_24433 == ((int64_t)0ULL))) {
                heff_drop(v_d_24425);
                V v_x_24435 = v_field_24434;
                return v_x_24435;
              } else {
                heff_drop(v_field_24434);
                return v_d_24425;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24429);
            return v_d_24425;
          }
        }
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24437 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24439 = v_t_24437.f[1];
      int64_t v_tag_24438 = ((int64_t)v_t_24437.f[0]);
      if ((v_tag_24438 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24440 = v_field_24439;
        heff_drop(v_x_24440);
        V v_t_24441 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24442 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24441, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str78), heff_strAppend(v_t_24442, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str79)));
        return heff_strAppend(v_shown_242, v_t_24443);
      } else {
        heff_drop(v_field_24439);
        V v_t_24444 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24445 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24444, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24446 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str80), heff_strAppend(v_t_24445, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str81)));
        V v_d_24447 = heff_strAppend(v_shown_242, v_t_24446);
        V v_t_24448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24449 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24448; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24451 = v_t_24449.f[1];
          int64_t v_tag_24450 = ((int64_t)v_t_24449.f[0]);
          if ((v_tag_24450 == ((int64_t)0ULL))) {
            V v_tf_24452 = v_field_24451;
            V v_t_24453 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24454 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24453, v_name_241, v_tf_24452));
            {
              V v_field_24456 = v_t_24454.f[1];
              int64_t v_tag_24455 = ((int64_t)v_t_24454.f[0]);
              if ((v_tag_24455 == ((int64_t)0ULL))) {
                heff_drop(v_d_24447);
                V v_x_24457 = v_field_24456;
                return v_x_24457;
              } else {
                heff_drop(v_field_24456);
                return v_d_24447;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24451);
            return v_d_24447;
          }
        }
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24459 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24461 = v_t_24459.f[1];
      int64_t v_tag_24460 = ((int64_t)v_t_24459.f[0]);
      if ((v_tag_24460 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24462 = v_field_24461;
        heff_drop(v_x_24462);
        V v_t_24463 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24464 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24463, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24465 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str82), heff_strAppend(v_t_24464, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str83)));
        return heff_strAppend(v_shown_242, v_t_24465);
      } else {
        heff_drop(v_field_24461);
        V v_t_24466 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24467 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24466, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24468 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str84), heff_strAppend(v_t_24467, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str85)));
        V v_d_24469 = heff_strAppend(v_shown_242, v_t_24468);
        V v_t_24470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24471 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24470; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24473 = v_t_24471.f[1];
          int64_t v_tag_24472 = ((int64_t)v_t_24471.f[0]);
          if ((v_tag_24472 == ((int64_t)0ULL))) {
            V v_tf_24474 = v_field_24473;
            V v_t_24475 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24476 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24475, v_name_241, v_tf_24474));
            {
              V v_field_24478 = v_t_24476.f[1];
              int64_t v_tag_24477 = ((int64_t)v_t_24476.f[0]);
              if ((v_tag_24477 == ((int64_t)0ULL))) {
                heff_drop(v_d_24469);
                V v_x_24479 = v_field_24478;
                return v_x_24479;
              } else {
                heff_drop(v_field_24478);
                return v_d_24469;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24473);
            return v_d_24469;
          }
        }
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24481 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24483 = v_t_24481.f[1];
      int64_t v_tag_24482 = ((int64_t)v_t_24481.f[0]);
      if ((v_tag_24482 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24484 = v_field_24483;
        heff_drop(v_x_24484);
        V v_t_24485 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24486 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24485, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24487 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str86), heff_strAppend(v_t_24486, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str87)));
        return heff_strAppend(v_shown_242, v_t_24487);
      } else {
        heff_drop(v_field_24483);
        V v_t_24488 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24489 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24488, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24490 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str88), heff_strAppend(v_t_24489, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str89)));
        V v_d_24491 = heff_strAppend(v_shown_242, v_t_24490);
        V v_t_24492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24493 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24492; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24495 = v_t_24493.f[1];
          int64_t v_tag_24494 = ((int64_t)v_t_24493.f[0]);
          if ((v_tag_24494 == ((int64_t)0ULL))) {
            V v_tf_24496 = v_field_24495;
            V v_t_24497 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24498 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24497, v_name_241, v_tf_24496));
            {
              V v_field_24500 = v_t_24498.f[1];
              int64_t v_tag_24499 = ((int64_t)v_t_24498.f[0]);
              if ((v_tag_24499 == ((int64_t)0ULL))) {
                heff_drop(v_d_24491);
                V v_x_24501 = v_field_24500;
                return v_x_24501;
              } else {
                heff_drop(v_field_24500);
                return v_d_24491;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24495);
            return v_d_24491;
          }
        }
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24504 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24506 = v_t_24504.f[1];
      int64_t v_tag_24505 = ((int64_t)v_t_24504.f[0]);
      if ((v_tag_24505 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24507 = v_field_24506;
        heff_drop(v_x_24507);
        V v_t_24508 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24509 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24508, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24510 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str90), heff_strAppend(v_t_24509, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str91)));
        return heff_strAppend(v_shown_242, v_t_24510);
      } else {
        heff_drop(v_field_24506);
        V v_t_24511 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24512 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24511, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24513 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str92), heff_strAppend(v_t_24512, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str93)));
        V v_d_24514 = heff_strAppend(v_shown_242, v_t_24513);
        V v_t_24515 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24516 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24515; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24518 = v_t_24516.f[1];
          int64_t v_tag_24517 = ((int64_t)v_t_24516.f[0]);
          if ((v_tag_24517 == ((int64_t)0ULL))) {
            V v_tf_24519 = v_field_24518;
            V v_t_24520 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24521 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24520, v_name_241, v_tf_24519));
            {
              V v_field_24523 = v_t_24521.f[1];
              int64_t v_tag_24522 = ((int64_t)v_t_24521.f[0]);
              if ((v_tag_24522 == ((int64_t)0ULL))) {
                heff_drop(v_d_24514);
                V v_x_24524 = v_field_24523;
                return v_x_24524;
              } else {
                heff_drop(v_field_24523);
                return v_d_24514;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24518);
            return v_d_24514;
          }
        }
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24526 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24528 = v_t_24526.f[1];
      int64_t v_tag_24527 = ((int64_t)v_t_24526.f[0]);
      if ((v_tag_24527 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24529 = v_field_24528;
        heff_drop(v_x_24529);
        V v_t_24530 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24531 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24530, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24532 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str94), heff_strAppend(v_t_24531, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str95)));
        return heff_strAppend(v_shown_242, v_t_24532);
      } else {
        heff_drop(v_field_24528);
        V v_t_24533 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24534 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24533, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24535 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str96), heff_strAppend(v_t_24534, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str97)));
        V v_d_24536 = heff_strAppend(v_shown_242, v_t_24535);
        V v_t_24537 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24538 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24537; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24540 = v_t_24538.f[1];
          int64_t v_tag_24539 = ((int64_t)v_t_24538.f[0]);
          if ((v_tag_24539 == ((int64_t)0ULL))) {
            V v_tf_24541 = v_field_24540;
            V v_t_24542 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24543 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24542, v_name_241, v_tf_24541));
            {
              V v_field_24545 = v_t_24543.f[1];
              int64_t v_tag_24544 = ((int64_t)v_t_24543.f[0]);
              if ((v_tag_24544 == ((int64_t)0ULL))) {
                heff_drop(v_d_24536);
                V v_x_24546 = v_field_24545;
                return v_x_24546;
              } else {
                heff_drop(v_field_24545);
                return v_d_24536;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24540);
            return v_d_24536;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28, 5, " @ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return (g_heff_2esyntax_2esurfaceprint_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0), 2)) {
      return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
    } else {
      HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_245, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_ws_249 = v_field_248;
          V v_t_2412;
          switch (heff_tag_of(v_ws_249)) {
          case TAG_Nil: {
            v_t_2412 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_2410 = heff_field(v_ws_249, 0);
            V v_xs_2411 = heff_field(v_ws_249, 1);
            heff_take_n(v_ws_249, 3ULL, 2);
            v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
            break;
          }
          default: heff_nomatch(v_ws_249);
          }
          V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3), v_t_2412);
          heff_drop(v_t_2413);
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5)));
        } else {
          heff_drop(v_field_248);
          return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
        }
      }
    }
  }
  case TAG_SCode: {
    V v_t_2414 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2415 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2415, v_p_241, v_xs_242, v_t_2414);
  }
  case TAG_SApp: {
    V v_f_2416 = heff_field(v_e_243, 0);
    V v_a_2417 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2418 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(v_t_2418, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2416, v_a_2417}));
  }
  case TAG_SLam: {
    V v_t_2419 = heff_field(v_e_243, 0);
    V v_b_2420 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2421 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2419, v_b_2420})));
    return ({ V a_0 = v_t_2421; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2422; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2423 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_keys_2424 = heff_take_field(v_d_2423, 0);
    V v_values_2425 = heff_get_n(v_d_2423, 2, 3);
    V v_t_2426 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2424), heff_arrayToList(v_values_2425)));
    V v_x2_2432 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2426));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2432);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10)));
  }
  case TAG_SProj: {
    V v_e2_2436 = heff_field(v_e_243, 0);
    V v_l_2437 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2438 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2439 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2438, MK_INT(2LL), v_xs_242, v_e2_2436));
    return heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11), v_l_2437));
  }
  case TAG_STag: {
    V v_x_2440 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2441 = heff_dup(heff_field(v_e_243, 1));
    HeffT2 v_t_2442 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_e_243));
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_x_2440);
        heff_drop(v_ts_2441);
        V v_items_2445 = v_field_2444;
        V v_x2_2448 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2445));
        V v_t_2451;
        switch (heff_tag_of(v_x2_2448)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_x2_2448, 0);
          V v_xs_2450 = heff_field(v_x2_2448, 1);
          heff_take_n(v_x2_2448, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2448);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15)));
      } else {
        heff_drop(v_field_2444);
        V v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2441)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intEq_c(v_t_2452, MK_INT(0LL))) {
          heff_drop(v_lit_240);
          heff_drop(v_p_241);
          heff_drop(v_xs_242);
          heff_drop(v_ts_2441);
          return v_x_2440;
        } else {
          V v_s_2455 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16); V a_1 = v_x_2440; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2441); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
            return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17), heff_strAppend(v_s_2455, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18)));
          } else {
            return v_s_2455;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    V v_s_2456 = heff_field(v_e_243, 0);
    V v_cases_2457 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_keys_2458 = heff_take_field(v_cases_2457, 0);
    V v_values_2459 = heff_get_n(v_cases_2457, 2, 3);
    V v_t_2460 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
    V v_t_2461 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2460, MK_INT(0LL), heff_dup(v_xs_242), v_s_2456));
    V v_t_2462 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2458), heff_arrayToList(v_values_2459)));
    V v_x2_2465 = (g_list_2emap_24tok2(v_ru_24e_243_24SMatch, heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2462));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2469 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21), v_t_2468));
    V v_s_2470 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22), v_t_2469);
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23), heff_strAppend(v_s_2470, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24)));
    } else {
      return v_s_2470;
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_2474 = (g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(v_e_243, NTAG(TAG_Nil)));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_base_2477 = v_field_2475;
      V v_sets_2478 = v_field_2476;
      V v_t_2479 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
      V v_t_2480 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2479, MK_INT(1LL), heff_dup(v_xs_242), v_base_2477));
      V v_x2_2486 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4, 1, 2, (V[]){v_lit_240, v_xs_242}), v_sets_2478));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      V v_t_2490 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29)));
      V v_s_2491 = heff_strAppend(v_t_2480, v_t_2490);
      if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30), heff_strAppend(v_s_2491, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31)));
      } else {
        return v_s_2491;
      }
    }
  }
  case TAG_SIs: {
    V v_e2_2492 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2493 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2493, v_p_241, v_xs_242, v_e2_2492);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33);
  }
  case TAG_SRec: {
    V v_e2_2494 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2495 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2495, v_p_241, v_xs_242, v_e2_2494);
  }
  case TAG_SFix: {
    V v_e2_27_2497 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2497)) {
    case TAG_MkAbs: {
      V v_x_2498 = heff_field(v_e2_27_2497, 0);
      heff_take_n(v_e2_27_2497, 1ULL, 2);
      return v_x_2498;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2497, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34);
    }
    default: return heff_nomatch(v_e2_27_2497);
    }
  }
  case TAG_SImplicit: {
    V v_e2_24102 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V v_t_24103 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_24103, v_p_241, v_xs_242, v_e2_24102);
  }
  case TAG_SPrim: {
    V v_x_24104 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35), heff_strAppend(v_x_24104, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36)));
  }
  case TAG_SMetaApp: {
    V v_m_24105 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37), heff_intShow(v_m_24105));
  }
  case TAG_SLitInt: {
    V v_i_24108 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_24108);
  }
  case TAG_SLitFloat: {
    V v_x_24109 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24109);
  }
  case TAG_SLitString: {
    V v_s_24110 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24111 = ({ V a_0 = v_s_24110; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38); V r_ = (g_heff_2eutil_2erune_2equoteGo(a_0, a_1, a_2)); heff_drop(v_s_24110); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39), heff_strAppend(v_t_24111, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40)));
  }
  case TAG_SLitBytes: {
    V v_s_24112 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24113 = ({ V a_0 = v_s_24112; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41); V a_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42); V r_ = (g_heff_2eutil_2erune_2equoteBytesGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_24112); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43), heff_strAppend(v_t_24113, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44)));
  }
  case TAG_SLitRune: {
    V v_ch_24114 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24115 = (g_heff_2eutil_2erune_2equoted(v_ch_24114));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45), heff_strAppend(v_t_24115, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46)));
  }
  case TAG_SLitFixed: {
    V v_n_24117 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_24117);
  }
  case TAG_SLitFloat32: {
    V v_x_24118 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24118);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args) {
  V v_f_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_f_2427, 0);
    V v_e_2429 = heff_field(v_f_2427, 1);
    heff_take_n(v_f_2427, 3ULL, 2);
    V v_t_2430 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2430, MK_INT(0LL), v_xs_242, v_e_2429));
    return heff_strAppend(v_l_2428, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6), v_t_2431));
  }
  default: return heff_nomatch(v_f_2427);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args) {
  V v_a_2446 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2447, MK_INT(0LL), v_xs_242, v_a_2446));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2454, MK_INT(2LL), v_xs_242, v_a_2453));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args) {
  V v_alt_2463 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_box_word((heff_unbox_word(v_lit_240) + ((int64_t)2ULL))), NTAG(TAG_False)});
  return ({ V a_0 = v_t_2464; V a_1 = v_xs_242; V a_2 = v_alt_2463; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2463); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args) {
  V v_st_2481 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_st_2481, 0);
    V v_v_2483 = heff_field(v_st_2481, 1);
    heff_take_n(v_st_2481, 3ULL, 2);
    V v_t_2484 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2485 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2484, MK_INT(0LL), v_xs_242, v_v_2483));
    return heff_strAppend(v_x_2482, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25), v_t_2485));
  }
  default: return heff_nomatch(v_st_2481);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_246 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_246, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_x5_243, 0);
    V v_dom_248 = heff_field(v_x5_243, 1);
    V v_cod_249 = heff_field(v_x5_243, 2);
    V v_implicit_2410 = heff_field(v_x5_243, 3);
    V v_dflt_2411 = heff_field(v_x5_243, 4);
    V v_s_2415;
    switch (heff_tag_of(v_dflt_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(v_t_2412, v_xs_242, v_level_247, heff_dup(v_dom_248), heff_dup(v_cod_249), v_implicit_2410));
      break;
    }
    case TAG_Just: {
      V v_d_2413 = heff_field(v_dflt_2411, 0);
      V v_t_2414 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_t_2414, v_xs_242, heff_dup(v_dom_248), heff_dup(v_cod_249), heff_dup(v_d_2413)));
      break;
    }
    default: heff_nomatch(v_dflt_2411);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2), heff_strAppend(v_s_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3)));
    } else {
      return v_s_2415;
    }
  }
  case TAG_SRecord: {
    V v_fs_2417 = heff_field(v_x5_243, 1);
    V v_ds_2418 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_keys_2419 = heff_dup(heff_rfield(v_fs_2417, 0));
    V v_values_2420 = heff_dup(heff_rfield(v_fs_2417, 2));
    V v_fs_2421 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2419), heff_arrayToList(v_values_2420)));
    V v_t_2422 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2426 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2418)}); V a_1 = v_t_2422; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
    V v_t_2427 = heff_get_n(v_acc_2426, 1, 2);
    V v_t_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_t_2427, 0);
      V v_xs_2429 = heff_field(v_t_2427, 1);
      heff_take_n(v_t_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7)));
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_keys_2432 = heff_dup(heff_rfield(v_vs_2431, 0));
    V v_values_2433 = heff_dup(heff_rfield(v_vs_2431, 2));
    V v_t_2434 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
    V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2434));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2444 = heff_field(v_x5_243, 0);
    V v_t_2445 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2445, v_p_241, v_xs_242, heff_dup(v_t2_2444));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2446 = heff_field(v_x5_243, 0);
    V v_t_2447 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    V v_t_2448 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2447, MK_INT(2LL), v_xs_242, heff_dup(v_a_2446)));
    V v_s_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17), v_t_2448);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18), heff_strAppend(v_s_2449, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19)));
    } else {
      return v_s_2449;
    }
  }
  case TAG_SFixed: {
    V v_w_2450 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2450)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28);
    }
    default: return heff_nomatch(v_w_2450);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_f_2424 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2425, v_ds_2418, v_acc_2423, v_f_2424));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args) {
  V v_t2_2438 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2439, MK_INT(2LL), v_xs_242, v_t2_2438));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args) {
  V v_v_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2435)) {
  case TAG_MkPair: {
    V v_t_2436 = heff_field(v_v_2435, 0);
    V v_ts_2437 = heff_field(v_v_2435, 1);
    heff_take_n(v_v_2435, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8); V a_1 = v_t_2436; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2437); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2435);
  }
}