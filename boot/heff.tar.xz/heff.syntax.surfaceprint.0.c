// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_typed 312202372
#define LBL_values 1123329101
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_clo;
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eopHead(V);
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo;
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    HeffT2 v_t_242 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_ws_246 = v_field_244;
        V v_t_249;
        switch (heff_tag_of(v_ws_246)) {
        case TAG_Nil: {
          v_t_249 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_247 = heff_field(v_ws_246, 0);
          V v_xs_248 = heff_field(v_ws_246, 1);
          heff_take_n(v_ws_246, 3ULL, 2);
          v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
          break;
        }
        default: heff_nomatch(v_ws_246);
        }
        V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_249);
        heff_drop(v_t_2410);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), heff_strAppend(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5)));
      } else {
        heff_drop(v_field_244);
        return v_x_240;
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0, 12, "prelude.Pair");

HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V v_sp_240) {
top: ;
  V v_t_241 = heff_take_field(v_sp_240, 0);
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_243 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_244 = heff_get_n(v_sp_240, 1, 2);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_t_244, 0);
      V v_it2_246 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24Cons = heff_take_reuse_n(v_t_244, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        heff_drop(v_x_243);
        heff_drop(v_a_245);
        heff_drop_cell(v_ru_24t_244_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_b_247 = heff_field(v_it2_246, 0);
        V v_it22_248 = heff_field(v_it2_246, 1);
        V v_ru_24it2_246_24Cons = heff_take_reuse_n(v_it2_246, 3ULL, 2);
        switch (heff_tag_of(v_it22_248)) {
        case TAG_Nil: {
          if (heff_strEq_c(v_x_243, ((V)&g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr_str0))) {
            V v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_a_245), NTAG(TAG_Nil)));
            HeffT2 v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(v_t_2410));
            V v_t_2416;
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                heff_drop(v_a_245);
                heff_drop_cell(v_ru_24t_244_24Cons, 2);
                V v_x_2415 = v_field_2413;
                v_t_2416 = v_x_2415;
              } else {
                heff_drop(v_field_2413);
                v_t_2416 = heff_tag_at_n(v_ru_24t_244_24Cons, TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
              }
            }
            V v_t_2417 = heff_tag_at_n(v_ru_24it2_246_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
            V v_f_2418 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2417));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
          } else {
            heff_drop(v_a_245);
            heff_drop_cell(v_ru_24t_244_24Cons, 2);
            heff_drop(v_b_247);
            heff_drop_cell(v_ru_24it2_246_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_248, 0ULL, 2);
          heff_drop(v_x_243);
          heff_drop(v_a_245);
          heff_drop_cell(v_ru_24t_244_24Cons, 2);
          heff_drop(v_b_247);
          heff_drop_cell(v_ru_24it2_246_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it22_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_244)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_247, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2410 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}), v_b_246));
    V v_t_2412 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), v_t_2411));
    V v_t_2413 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1), v_t_2412));
    V v_t_2414 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2), v_t_2413));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3), v_t_2414);
  }
  case TAG_AbsConst: {
    V v_b_2415 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2416, MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2419 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2419, MK_INT(0LL), v_xs_241, v_b_2415));
    V v_t_2421 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2420));
    V v_t_2422 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5), v_t_2421));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6), v_t_2422);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4, 3, " : ");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_247, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_245));
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ds_241, 1), v_l_244));
    V v_t_2419;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_i_2413 = v_field_2411;
        V v_xs_2414 = heff_get_n(v_ds_241, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1)) {
          if (heff_intLt_c(heff_dup(v_i_2413), heff_arrayLength_lent(v_xs_2414, 0))) {
            V v_t_2417 = heff_arrayIndex(v_xs_2414, v_i_2413);
            V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_2417));
            v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0), v_t_2418);
          } else {
            heff_drop_rec(v_c_240, 3);
            heff_drop(v_i_2413);
            heff_drop(v_xs_2414);
            v_t_2419 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1);
          }
        } else {
          heff_drop_rec(v_c_240, 3);
          heff_drop(v_i_2413);
          heff_drop(v_xs_2414);
          v_t_2419 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
        }
      } else {
        heff_drop_rec(v_c_240, 3);
        heff_drop_rec(v_ds_241, 3);
        heff_drop(v_field_2411);
        v_t_2419 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3);
      }
    }
    V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4), heff_strAppend(v_t_248, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_l_244, v_t_2420), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2421));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2422});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str3, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(heff_dup(v_c_240), v_xs_242, v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_249 = v_field_247;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_MkPair: {
        V v_l_2410 = heff_field(v_it1_249, 0);
        V v_r2_2411 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_2410));
        V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
        V v_t_2414 = ({ V b_0 = heff_get_n(v_t_2413, 0, 2); V r_ = (g_heff_2esyntax_2esurfaceprint_2eopHead(b_0)); heff_drop(b_0); r_; });
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(1LL), v_xs_242, v_r2_2411));
        V v_t_2416 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str0), v_t_2415));
        V v_s_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str1), v_t_2416));
        if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str2), heff_strAppend(v_s_2417, ((V)&g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_str3)));
        } else {
          return v_s_2417;
        }
      }
      default: return heff_nomatch(v_it1_249);
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2419 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
      HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(v_c_240, v_p_241, v_xs_242, v_t_2419);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_c_240, v_p_241, v_xs_242, v_e_243));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2424}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return v_x1_240;
  }
  case TAG_SGlobal: {
    return v_x1_240;
  }
  case TAG_SCode: {
    return v_x1_240;
  }
  case TAG_SApp: {
    return v_x1_240;
  }
  case TAG_SLam: {
    return v_x1_240;
  }
  case TAG_SCons: {
    return v_x1_240;
  }
  case TAG_SProj: {
    return v_x1_240;
  }
  case TAG_STag: {
    return v_x1_240;
  }
  case TAG_SMatch: {
    return v_x1_240;
  }
  case TAG_SSpecialize: {
    return v_x1_240;
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_x1_240;
  }
  case TAG_SAbandon: {
    return v_x1_240;
  }
  case TAG_SRec: {
    return v_x1_240;
  }
  case TAG_SFix: {
    return v_x1_240;
  }
  case TAG_SImplicit: {
    return v_x1_240;
  }
  case TAG_SPrim: {
    return v_x1_240;
  }
  case TAG_SMetaApp: {
    return v_x1_240;
  }
  case TAG_SLitInt: {
    return v_x1_240;
  }
  case TAG_SLitFloat: {
    return v_x1_240;
  }
  case TAG_SLitString: {
    return v_x1_240;
  }
  case TAG_SLitBytes: {
    return v_x1_240;
  }
  case TAG_SLitRune: {
    return v_x1_240;
  }
  case TAG_SLitFixed: {
    return v_x1_240;
  }
  case TAG_SLitFloat32: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str2), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str4), heff_strAppend(v_x_241, v_t_247));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str5), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str7), heff_strAppend(v_x_241, v_t_2410));
  }
  case TAG_SFunction: {
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2417));
  }
  case TAG_SRecord: {
    V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2422));
  }
  case TAG_SSum: {
    V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2425));
  }
  case TAG_SIsTy: {
    V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str17), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2428));
  }
  case TAG_SPrimInt: {
    V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str20), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2430));
  }
  case TAG_SPrimFloat: {
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2432));
  }
  case TAG_SPrimString: {
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str26), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2434));
  }
  case TAG_SPrimRune: {
    V v_t_2435 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str29), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2436));
  }
  case TAG_SPrimArray: {
    V v_t_2438 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str32), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2439));
  }
  case TAG_SFixed: {
    V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2442));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2, 1, "\012");

HeffT2 g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_name_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_tf_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SU: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecode: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFunction: {
      heff_take_n(v_t_243, 0ULL, 5);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRecord: {
      heff_take_n(v_t_243, 0ULL, 3);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSum: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_t_2415 = heff_dup(heff_rfield(v_tf_242, 3));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_name_240);
        heff_drop(v_t_2415);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str0), v_name_240, heff_rfield(v_tf_242, 0)));
        V v_f_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str1), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eabstractOf_24cpr_str2)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimInt: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimString: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimRune: {
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop(v_name_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2410 = v_field_248;
        heff_drop(v_x_2410);
        V v_t_2411 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2411, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str0), heff_strAppend(v_t_2412, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str1)));
        return heff_strAppend(v_shown_242, v_t_2413);
      } else {
        heff_drop(v_field_248);
        V v_t_2414 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2414, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str2), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str3)));
        V v_d_2417 = heff_strAppend(v_shown_242, v_t_2416);
        V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2419 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2418; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_tf_2423 = v_field_2421;
            V v_t_2424 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2425 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2424, v_name_241, v_tf_2423));
            {
              V v_field_2427 = v_t_2425.f[1];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              if ((v_tag_2426 == ((int64_t)0ULL))) {
                heff_drop(v_d_2417);
                V v_x_2429 = v_field_2427;
                return v_x_2429;
              } else {
                heff_drop(v_field_2427);
                return v_d_2417;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2421);
            return v_d_2417;
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2435 = v_field_2433;
        heff_drop(v_x_2435);
        V v_t_2436 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2437 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2436, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str4), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str5)));
        return heff_strAppend(v_shown_242, v_t_2438);
      } else {
        heff_drop(v_field_2433);
        V v_t_2439 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2440 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2439, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2441 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str6), heff_strAppend(v_t_2440, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str7)));
        V v_d_2442 = heff_strAppend(v_shown_242, v_t_2441);
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2444 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2443; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2446 = v_t_2444.f[1];
          int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
          if ((v_tag_2445 == ((int64_t)0ULL))) {
            V v_tf_2448 = v_field_2446;
            V v_t_2449 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2450 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2449, v_name_241, v_tf_2448));
            {
              V v_field_2452 = v_t_2450.f[1];
              int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
              if ((v_tag_2451 == ((int64_t)0ULL))) {
                heff_drop(v_d_2442);
                V v_x_2454 = v_field_2452;
                return v_x_2454;
              } else {
                heff_drop(v_field_2452);
                return v_d_2442;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2446);
            return v_d_2442;
          }
        }
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2456 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2458 = v_t_2456.f[1];
      int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
      if ((v_tag_2457 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2460 = v_field_2458;
        heff_drop(v_x_2460);
        V v_t_2461 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2462 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2461, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2463 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str8), heff_strAppend(v_t_2462, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str9)));
        return heff_strAppend(v_shown_242, v_t_2463);
      } else {
        heff_drop(v_field_2458);
        V v_t_2464 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2465 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2464, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2466 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str10), heff_strAppend(v_t_2465, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str11)));
        V v_d_2467 = heff_strAppend(v_shown_242, v_t_2466);
        V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2469 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2468; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2471 = v_t_2469.f[1];
          int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
          if ((v_tag_2470 == ((int64_t)0ULL))) {
            V v_tf_2473 = v_field_2471;
            V v_t_2474 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_2475 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_2474, v_name_241, v_tf_2473));
            {
              V v_field_2477 = v_t_2475.f[1];
              int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
              if ((v_tag_2476 == ((int64_t)0ULL))) {
                heff_drop(v_d_2467);
                V v_x_2479 = v_field_2477;
                return v_x_2479;
              } else {
                heff_drop(v_field_2477);
                return v_d_2467;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2471);
            return v_d_2467;
          }
        }
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2482 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2484 = v_t_2482.f[1];
      int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
      if ((v_tag_2483 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2486 = v_field_2484;
        heff_drop(v_x_2486);
        V v_t_2487 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2488 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2487, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str12), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str13)));
        return heff_strAppend(v_shown_242, v_t_2489);
      } else {
        heff_drop(v_field_2484);
        V v_t_2490 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_2491 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2490, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2492 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str14), heff_strAppend(v_t_2491, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str15)));
        V v_d_2493 = heff_strAppend(v_shown_242, v_t_2492);
        V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2495 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2494; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_2497 = v_t_2495.f[1];
          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
          if ((v_tag_2496 == ((int64_t)0ULL))) {
            V v_tf_2499 = v_field_2497;
            V v_t_24100 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24101 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24100, v_name_241, v_tf_2499));
            {
              V v_field_24103 = v_t_24101.f[1];
              int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
              if ((v_tag_24102 == ((int64_t)0ULL))) {
                heff_drop(v_d_2493);
                V v_x_24105 = v_field_24103;
                return v_x_24105;
              } else {
                heff_drop(v_field_24103);
                return v_d_2493;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2497);
            return v_d_2493;
          }
        }
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_24108 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24110 = v_t_24108.f[1];
      int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
      if ((v_tag_24109 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24112 = v_field_24110;
        heff_drop(v_x_24112);
        V v_t_24113 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24114 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24113, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str16), heff_strAppend(v_t_24114, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str17)));
        return heff_strAppend(v_shown_242, v_t_24115);
      } else {
        heff_drop(v_field_24110);
        V v_t_24116 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24117 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24116, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24118 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str18), heff_strAppend(v_t_24117, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str19)));
        V v_d_24119 = heff_strAppend(v_shown_242, v_t_24118);
        V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24121 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24120; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24123 = v_t_24121.f[1];
          int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
          if ((v_tag_24122 == ((int64_t)0ULL))) {
            V v_tf_24125 = v_field_24123;
            V v_t_24126 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24127 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24126, v_name_241, v_tf_24125));
            {
              V v_field_24129 = v_t_24127.f[1];
              int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
              if ((v_tag_24128 == ((int64_t)0ULL))) {
                heff_drop(v_d_24119);
                V v_x_24131 = v_field_24129;
                return v_x_24131;
              } else {
                heff_drop(v_field_24129);
                return v_d_24119;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24123);
            return v_d_24119;
          }
        }
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_24133 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24137 = v_field_24135;
        heff_drop(v_x_24137);
        V v_t_24138 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24139 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24138, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24140 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str20), heff_strAppend(v_t_24139, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str21)));
        return heff_strAppend(v_shown_242, v_t_24140);
      } else {
        heff_drop(v_field_24135);
        V v_t_24141 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24142 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24141, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24143 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str22), heff_strAppend(v_t_24142, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str23)));
        V v_d_24144 = heff_strAppend(v_shown_242, v_t_24143);
        V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24146 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24145; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24148 = v_t_24146.f[1];
          int64_t v_tag_24147 = ((int64_t)v_t_24146.f[0]);
          if ((v_tag_24147 == ((int64_t)0ULL))) {
            V v_tf_24150 = v_field_24148;
            V v_t_24151 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24152 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24151, v_name_241, v_tf_24150));
            {
              V v_field_24154 = v_t_24152.f[1];
              int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
              if ((v_tag_24153 == ((int64_t)0ULL))) {
                heff_drop(v_d_24144);
                V v_x_24156 = v_field_24154;
                return v_x_24156;
              } else {
                heff_drop(v_field_24154);
                return v_d_24144;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24148);
            return v_d_24144;
          }
        }
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_24159 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24161 = v_t_24159.f[1];
      int64_t v_tag_24160 = ((int64_t)v_t_24159.f[0]);
      if ((v_tag_24160 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24163 = v_field_24161;
        heff_drop(v_x_24163);
        V v_t_24164 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24165 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24164, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24166 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str24), heff_strAppend(v_t_24165, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str25)));
        return heff_strAppend(v_shown_242, v_t_24166);
      } else {
        heff_drop(v_field_24161);
        V v_t_24167 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24168 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24167, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str26), heff_strAppend(v_t_24168, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str27)));
        V v_d_24170 = heff_strAppend(v_shown_242, v_t_24169);
        V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24172 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24171; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24174 = v_t_24172.f[1];
          int64_t v_tag_24173 = ((int64_t)v_t_24172.f[0]);
          if ((v_tag_24173 == ((int64_t)0ULL))) {
            V v_tf_24176 = v_field_24174;
            V v_t_24177 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24178 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24177, v_name_241, v_tf_24176));
            {
              V v_field_24180 = v_t_24178.f[1];
              int64_t v_tag_24179 = ((int64_t)v_t_24178.f[0]);
              if ((v_tag_24179 == ((int64_t)0ULL))) {
                heff_drop(v_d_24170);
                V v_x_24182 = v_field_24180;
                return v_x_24182;
              } else {
                heff_drop(v_field_24180);
                return v_d_24170;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24174);
            return v_d_24170;
          }
        }
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_24185 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24187 = v_t_24185.f[1];
      int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
      if ((v_tag_24186 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24189 = v_field_24187;
        heff_drop(v_x_24189);
        V v_t_24190 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24191 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24190, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24192 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str28), heff_strAppend(v_t_24191, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str29)));
        return heff_strAppend(v_shown_242, v_t_24192);
      } else {
        heff_drop(v_field_24187);
        V v_t_24193 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24194 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24193, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str30), heff_strAppend(v_t_24194, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str31)));
        V v_d_24196 = heff_strAppend(v_shown_242, v_t_24195);
        V v_t_24197 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24198 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24197; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24200 = v_t_24198.f[1];
          int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
          if ((v_tag_24199 == ((int64_t)0ULL))) {
            V v_tf_24202 = v_field_24200;
            V v_t_24203 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24204 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24203, v_name_241, v_tf_24202));
            {
              V v_field_24206 = v_t_24204.f[1];
              int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
              if ((v_tag_24205 == ((int64_t)0ULL))) {
                heff_drop(v_d_24196);
                V v_x_24208 = v_field_24206;
                return v_x_24208;
              } else {
                heff_drop(v_field_24206);
                return v_d_24196;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24200);
            return v_d_24196;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_24211 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24213 = v_t_24211.f[1];
      int64_t v_tag_24212 = ((int64_t)v_t_24211.f[0]);
      if ((v_tag_24212 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24215 = v_field_24213;
        heff_drop(v_x_24215);
        V v_t_24216 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24217 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24216, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24218 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str32), heff_strAppend(v_t_24217, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str33)));
        return heff_strAppend(v_shown_242, v_t_24218);
      } else {
        heff_drop(v_field_24213);
        V v_t_24219 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24220 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24219, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24221 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str34), heff_strAppend(v_t_24220, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str35)));
        V v_d_24222 = heff_strAppend(v_shown_242, v_t_24221);
        V v_t_24223 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24224 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24223; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24226 = v_t_24224.f[1];
          int64_t v_tag_24225 = ((int64_t)v_t_24224.f[0]);
          if ((v_tag_24225 == ((int64_t)0ULL))) {
            V v_tf_24228 = v_field_24226;
            V v_t_24229 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24230 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24229, v_name_241, v_tf_24228));
            {
              V v_field_24232 = v_t_24230.f[1];
              int64_t v_tag_24231 = ((int64_t)v_t_24230.f[0]);
              if ((v_tag_24231 == ((int64_t)0ULL))) {
                heff_drop(v_d_24222);
                V v_x_24234 = v_field_24232;
                return v_x_24234;
              } else {
                heff_drop(v_field_24232);
                return v_d_24222;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24226);
            return v_d_24222;
          }
        }
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_24238 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24240 = v_t_24238.f[1];
      int64_t v_tag_24239 = ((int64_t)v_t_24238.f[0]);
      if ((v_tag_24239 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24242 = v_field_24240;
        heff_drop(v_x_24242);
        V v_t_24243 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24244 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24243, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24245 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str36), heff_strAppend(v_t_24244, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str37)));
        return heff_strAppend(v_shown_242, v_t_24245);
      } else {
        heff_drop(v_field_24240);
        V v_t_24246 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24246, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str38), heff_strAppend(v_t_24247, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str39)));
        V v_d_24249 = heff_strAppend(v_shown_242, v_t_24248);
        V v_t_24250 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24251 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24250; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24253 = v_t_24251.f[1];
          int64_t v_tag_24252 = ((int64_t)v_t_24251.f[0]);
          if ((v_tag_24252 == ((int64_t)0ULL))) {
            V v_tf_24255 = v_field_24253;
            V v_t_24256 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24257 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24256, v_name_241, v_tf_24255));
            {
              V v_field_24259 = v_t_24257.f[1];
              int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
              if ((v_tag_24258 == ((int64_t)0ULL))) {
                heff_drop(v_d_24249);
                V v_x_24261 = v_field_24259;
                return v_x_24261;
              } else {
                heff_drop(v_field_24259);
                return v_d_24249;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24253);
            return v_d_24249;
          }
        }
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_24263 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24265 = v_t_24263.f[1];
      int64_t v_tag_24264 = ((int64_t)v_t_24263.f[0]);
      if ((v_tag_24264 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24267 = v_field_24265;
        heff_drop(v_x_24267);
        V v_t_24268 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24269 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24268, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24270 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str40), heff_strAppend(v_t_24269, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str41)));
        return heff_strAppend(v_shown_242, v_t_24270);
      } else {
        heff_drop(v_field_24265);
        V v_t_24271 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24272 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24271, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24273 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str42), heff_strAppend(v_t_24272, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str43)));
        V v_d_24274 = heff_strAppend(v_shown_242, v_t_24273);
        V v_t_24275 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24276 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24275; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24278 = v_t_24276.f[1];
          int64_t v_tag_24277 = ((int64_t)v_t_24276.f[0]);
          if ((v_tag_24277 == ((int64_t)0ULL))) {
            V v_tf_24280 = v_field_24278;
            V v_t_24281 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24282 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24281, v_name_241, v_tf_24280));
            {
              V v_field_24284 = v_t_24282.f[1];
              int64_t v_tag_24283 = ((int64_t)v_t_24282.f[0]);
              if ((v_tag_24283 == ((int64_t)0ULL))) {
                heff_drop(v_d_24274);
                V v_x_24286 = v_field_24284;
                return v_x_24286;
              } else {
                heff_drop(v_field_24284);
                return v_d_24274;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24278);
            return v_d_24274;
          }
        }
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_24287 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24289 = v_t_24287.f[1];
      int64_t v_tag_24288 = ((int64_t)v_t_24287.f[0]);
      if ((v_tag_24288 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        V v_x_24291 = v_field_24289;
        heff_drop(v_x_24291);
        V v_t_24292 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24293 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24292, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24294 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str44), heff_strAppend(v_t_24293, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str45)));
        return heff_strAppend(v_shown_242, v_t_24294);
      } else {
        heff_drop(v_field_24289);
        V v_t_24295 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24296 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24295, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24297 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str46), heff_strAppend(v_t_24296, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str47)));
        V v_d_24298 = heff_strAppend(v_shown_242, v_t_24297);
        V v_t_24299 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24300 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24299; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24302 = v_t_24300.f[1];
          int64_t v_tag_24301 = ((int64_t)v_t_24300.f[0]);
          if ((v_tag_24301 == ((int64_t)0ULL))) {
            V v_tf_24304 = v_field_24302;
            V v_t_24305 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24306 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24305, v_name_241, v_tf_24304));
            {
              V v_field_24308 = v_t_24306.f[1];
              int64_t v_tag_24307 = ((int64_t)v_t_24306.f[0]);
              if ((v_tag_24307 == ((int64_t)0ULL))) {
                heff_drop(v_d_24298);
                V v_x_24310 = v_field_24308;
                return v_x_24310;
              } else {
                heff_drop(v_field_24308);
                return v_d_24298;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24302);
            return v_d_24298;
          }
        }
      }
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24311 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
    V v_t_24312 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24311, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
    V v_t_24313 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str48), heff_strAppend(v_t_24312, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24313);
  }
  case TAG_SRec: {
    HeffT2 v_t_24315 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24317 = v_t_24315.f[1];
      int64_t v_tag_24316 = ((int64_t)v_t_24315.f[0]);
      if ((v_tag_24316 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24319 = v_field_24317;
        heff_drop(v_x_24319);
        V v_t_24320 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24321 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24320, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24322 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str50), heff_strAppend(v_t_24321, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str51)));
        return heff_strAppend(v_shown_242, v_t_24322);
      } else {
        heff_drop(v_field_24317);
        V v_t_24323 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24324 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24323, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24325 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str52), heff_strAppend(v_t_24324, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str53)));
        V v_d_24326 = heff_strAppend(v_shown_242, v_t_24325);
        V v_t_24327 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24328 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24327; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24330 = v_t_24328.f[1];
          int64_t v_tag_24329 = ((int64_t)v_t_24328.f[0]);
          if ((v_tag_24329 == ((int64_t)0ULL))) {
            V v_tf_24332 = v_field_24330;
            V v_t_24333 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24334 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24333, v_name_241, v_tf_24332));
            {
              V v_field_24336 = v_t_24334.f[1];
              int64_t v_tag_24335 = ((int64_t)v_t_24334.f[0]);
              if ((v_tag_24335 == ((int64_t)0ULL))) {
                heff_drop(v_d_24326);
                V v_x_24338 = v_field_24336;
                return v_x_24338;
              } else {
                heff_drop(v_field_24336);
                return v_d_24326;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24330);
            return v_d_24326;
          }
        }
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24341 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24343 = v_t_24341.f[1];
      int64_t v_tag_24342 = ((int64_t)v_t_24341.f[0]);
      if ((v_tag_24342 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24345 = v_field_24343;
        heff_drop(v_x_24345);
        V v_t_24346 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24347 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24346, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24348 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str54), heff_strAppend(v_t_24347, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str55)));
        return heff_strAppend(v_shown_242, v_t_24348);
      } else {
        heff_drop(v_field_24343);
        V v_t_24349 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24350 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24349, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24351 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str56), heff_strAppend(v_t_24350, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str57)));
        V v_d_24352 = heff_strAppend(v_shown_242, v_t_24351);
        V v_t_24353 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24354 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24353; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24356 = v_t_24354.f[1];
          int64_t v_tag_24355 = ((int64_t)v_t_24354.f[0]);
          if ((v_tag_24355 == ((int64_t)0ULL))) {
            V v_tf_24358 = v_field_24356;
            V v_t_24359 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24360 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24359, v_name_241, v_tf_24358));
            {
              V v_field_24362 = v_t_24360.f[1];
              int64_t v_tag_24361 = ((int64_t)v_t_24360.f[0]);
              if ((v_tag_24361 == ((int64_t)0ULL))) {
                heff_drop(v_d_24352);
                V v_x_24364 = v_field_24362;
                return v_x_24364;
              } else {
                heff_drop(v_field_24362);
                return v_d_24352;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24356);
            return v_d_24352;
          }
        }
      }
    }
  }
  case TAG_SImplicit: {
    HeffT2 v_t_24367 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24369 = v_t_24367.f[1];
      int64_t v_tag_24368 = ((int64_t)v_t_24367.f[0]);
      if ((v_tag_24368 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24371 = v_field_24369;
        heff_drop(v_x_24371);
        V v_t_24372 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24373 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24372, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24374 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str58), heff_strAppend(v_t_24373, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str59)));
        return heff_strAppend(v_shown_242, v_t_24374);
      } else {
        heff_drop(v_field_24369);
        V v_t_24375 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24376 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24375, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24377 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str60), heff_strAppend(v_t_24376, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str61)));
        V v_d_24378 = heff_strAppend(v_shown_242, v_t_24377);
        V v_t_24379 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24380 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24379; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24382 = v_t_24380.f[1];
          int64_t v_tag_24381 = ((int64_t)v_t_24380.f[0]);
          if ((v_tag_24381 == ((int64_t)0ULL))) {
            V v_tf_24384 = v_field_24382;
            V v_t_24385 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24386 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24385, v_name_241, v_tf_24384));
            {
              V v_field_24388 = v_t_24386.f[1];
              int64_t v_tag_24387 = ((int64_t)v_t_24386.f[0]);
              if ((v_tag_24387 == ((int64_t)0ULL))) {
                heff_drop(v_d_24378);
                V v_x_24390 = v_field_24388;
                return v_x_24390;
              } else {
                heff_drop(v_field_24388);
                return v_d_24378;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24382);
            return v_d_24378;
          }
        }
      }
    }
  }
  case TAG_SPrim: {
    HeffT2 v_t_24392 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24394 = v_t_24392.f[1];
      int64_t v_tag_24393 = ((int64_t)v_t_24392.f[0]);
      if ((v_tag_24393 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24396 = v_field_24394;
        heff_drop(v_x_24396);
        V v_t_24397 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24398 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24397, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24399 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str62), heff_strAppend(v_t_24398, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str63)));
        return heff_strAppend(v_shown_242, v_t_24399);
      } else {
        heff_drop(v_field_24394);
        V v_t_24400 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24401 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24400, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24402 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str64), heff_strAppend(v_t_24401, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str65)));
        V v_d_24403 = heff_strAppend(v_shown_242, v_t_24402);
        V v_t_24404 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24405 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24404; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24407 = v_t_24405.f[1];
          int64_t v_tag_24406 = ((int64_t)v_t_24405.f[0]);
          if ((v_tag_24406 == ((int64_t)0ULL))) {
            V v_tf_24409 = v_field_24407;
            V v_t_24410 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24411 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24410, v_name_241, v_tf_24409));
            {
              V v_field_24413 = v_t_24411.f[1];
              int64_t v_tag_24412 = ((int64_t)v_t_24411.f[0]);
              if ((v_tag_24412 == ((int64_t)0ULL))) {
                heff_drop(v_d_24403);
                V v_x_24415 = v_field_24413;
                return v_x_24415;
              } else {
                heff_drop(v_field_24413);
                return v_d_24403;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24407);
            return v_d_24403;
          }
        }
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24419 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24421 = v_t_24419.f[1];
      int64_t v_tag_24420 = ((int64_t)v_t_24419.f[0]);
      if ((v_tag_24420 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24423 = v_field_24421;
        heff_drop(v_x_24423);
        V v_t_24424 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24425 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24424, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24426 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str66), heff_strAppend(v_t_24425, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str67)));
        return heff_strAppend(v_shown_242, v_t_24426);
      } else {
        heff_drop(v_field_24421);
        V v_t_24427 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24428 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24427, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24429 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str68), heff_strAppend(v_t_24428, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str69)));
        V v_d_24430 = heff_strAppend(v_shown_242, v_t_24429);
        V v_t_24431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24432 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24431; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24434 = v_t_24432.f[1];
          int64_t v_tag_24433 = ((int64_t)v_t_24432.f[0]);
          if ((v_tag_24433 == ((int64_t)0ULL))) {
            V v_tf_24436 = v_field_24434;
            V v_t_24437 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24438 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24437, v_name_241, v_tf_24436));
            {
              V v_field_24440 = v_t_24438.f[1];
              int64_t v_tag_24439 = ((int64_t)v_t_24438.f[0]);
              if ((v_tag_24439 == ((int64_t)0ULL))) {
                heff_drop(v_d_24430);
                V v_x_24442 = v_field_24440;
                return v_x_24442;
              } else {
                heff_drop(v_field_24440);
                return v_d_24430;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24434);
            return v_d_24430;
          }
        }
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24444 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24446 = v_t_24444.f[1];
      int64_t v_tag_24445 = ((int64_t)v_t_24444.f[0]);
      if ((v_tag_24445 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24448 = v_field_24446;
        heff_drop(v_x_24448);
        V v_t_24449 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24450 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24449, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24451 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str70), heff_strAppend(v_t_24450, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str71)));
        return heff_strAppend(v_shown_242, v_t_24451);
      } else {
        heff_drop(v_field_24446);
        V v_t_24452 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24453 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24452, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24454 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str72), heff_strAppend(v_t_24453, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str73)));
        V v_d_24455 = heff_strAppend(v_shown_242, v_t_24454);
        V v_t_24456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24457 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24456; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24459 = v_t_24457.f[1];
          int64_t v_tag_24458 = ((int64_t)v_t_24457.f[0]);
          if ((v_tag_24458 == ((int64_t)0ULL))) {
            V v_tf_24461 = v_field_24459;
            V v_t_24462 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24463 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24462, v_name_241, v_tf_24461));
            {
              V v_field_24465 = v_t_24463.f[1];
              int64_t v_tag_24464 = ((int64_t)v_t_24463.f[0]);
              if ((v_tag_24464 == ((int64_t)0ULL))) {
                heff_drop(v_d_24455);
                V v_x_24467 = v_field_24465;
                return v_x_24467;
              } else {
                heff_drop(v_field_24465);
                return v_d_24455;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24459);
            return v_d_24455;
          }
        }
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24469 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24471 = v_t_24469.f[1];
      int64_t v_tag_24470 = ((int64_t)v_t_24469.f[0]);
      if ((v_tag_24470 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24473 = v_field_24471;
        heff_drop(v_x_24473);
        V v_t_24474 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24475 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24474, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24476 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str74), heff_strAppend(v_t_24475, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str75)));
        return heff_strAppend(v_shown_242, v_t_24476);
      } else {
        heff_drop(v_field_24471);
        V v_t_24477 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24478 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24477, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24479 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str76), heff_strAppend(v_t_24478, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str77)));
        V v_d_24480 = heff_strAppend(v_shown_242, v_t_24479);
        V v_t_24481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24482 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24481; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24484 = v_t_24482.f[1];
          int64_t v_tag_24483 = ((int64_t)v_t_24482.f[0]);
          if ((v_tag_24483 == ((int64_t)0ULL))) {
            V v_tf_24486 = v_field_24484;
            V v_t_24487 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24488 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24487, v_name_241, v_tf_24486));
            {
              V v_field_24490 = v_t_24488.f[1];
              int64_t v_tag_24489 = ((int64_t)v_t_24488.f[0]);
              if ((v_tag_24489 == ((int64_t)0ULL))) {
                heff_drop(v_d_24480);
                V v_x_24492 = v_field_24490;
                return v_x_24492;
              } else {
                heff_drop(v_field_24490);
                return v_d_24480;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24484);
            return v_d_24480;
          }
        }
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24494 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24496 = v_t_24494.f[1];
      int64_t v_tag_24495 = ((int64_t)v_t_24494.f[0]);
      if ((v_tag_24495 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24498 = v_field_24496;
        heff_drop(v_x_24498);
        V v_t_24499 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24500 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24499, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24501 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str78), heff_strAppend(v_t_24500, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str79)));
        return heff_strAppend(v_shown_242, v_t_24501);
      } else {
        heff_drop(v_field_24496);
        V v_t_24502 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24503 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24502, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24504 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str80), heff_strAppend(v_t_24503, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str81)));
        V v_d_24505 = heff_strAppend(v_shown_242, v_t_24504);
        V v_t_24506 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24507 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24506; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24509 = v_t_24507.f[1];
          int64_t v_tag_24508 = ((int64_t)v_t_24507.f[0]);
          if ((v_tag_24508 == ((int64_t)0ULL))) {
            V v_tf_24511 = v_field_24509;
            V v_t_24512 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24513 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24512, v_name_241, v_tf_24511));
            {
              V v_field_24515 = v_t_24513.f[1];
              int64_t v_tag_24514 = ((int64_t)v_t_24513.f[0]);
              if ((v_tag_24514 == ((int64_t)0ULL))) {
                heff_drop(v_d_24505);
                V v_x_24517 = v_field_24515;
                return v_x_24517;
              } else {
                heff_drop(v_field_24515);
                return v_d_24505;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24509);
            return v_d_24505;
          }
        }
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24519 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24521 = v_t_24519.f[1];
      int64_t v_tag_24520 = ((int64_t)v_t_24519.f[0]);
      if ((v_tag_24520 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24523 = v_field_24521;
        heff_drop(v_x_24523);
        V v_t_24524 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24525 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24524, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24526 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str82), heff_strAppend(v_t_24525, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str83)));
        return heff_strAppend(v_shown_242, v_t_24526);
      } else {
        heff_drop(v_field_24521);
        V v_t_24527 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24528 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24527, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24529 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str84), heff_strAppend(v_t_24528, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str85)));
        V v_d_24530 = heff_strAppend(v_shown_242, v_t_24529);
        V v_t_24531 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24532 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24531; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24534 = v_t_24532.f[1];
          int64_t v_tag_24533 = ((int64_t)v_t_24532.f[0]);
          if ((v_tag_24533 == ((int64_t)0ULL))) {
            V v_tf_24536 = v_field_24534;
            V v_t_24537 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24538 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24537, v_name_241, v_tf_24536));
            {
              V v_field_24540 = v_t_24538.f[1];
              int64_t v_tag_24539 = ((int64_t)v_t_24538.f[0]);
              if ((v_tag_24539 == ((int64_t)0ULL))) {
                heff_drop(v_d_24530);
                V v_x_24542 = v_field_24540;
                return v_x_24542;
              } else {
                heff_drop(v_field_24540);
                return v_d_24530;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24534);
            return v_d_24530;
          }
        }
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24544 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24546 = v_t_24544.f[1];
      int64_t v_tag_24545 = ((int64_t)v_t_24544.f[0]);
      if ((v_tag_24545 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24548 = v_field_24546;
        heff_drop(v_x_24548);
        V v_t_24549 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24550 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24549, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24551 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str86), heff_strAppend(v_t_24550, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str87)));
        return heff_strAppend(v_shown_242, v_t_24551);
      } else {
        heff_drop(v_field_24546);
        V v_t_24552 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24553 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24552, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24554 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str88), heff_strAppend(v_t_24553, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str89)));
        V v_d_24555 = heff_strAppend(v_shown_242, v_t_24554);
        V v_t_24556 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24557 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24556; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24559 = v_t_24557.f[1];
          int64_t v_tag_24558 = ((int64_t)v_t_24557.f[0]);
          if ((v_tag_24558 == ((int64_t)0ULL))) {
            V v_tf_24561 = v_field_24559;
            V v_t_24562 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24563 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24562, v_name_241, v_tf_24561));
            {
              V v_field_24565 = v_t_24563.f[1];
              int64_t v_tag_24564 = ((int64_t)v_t_24563.f[0]);
              if ((v_tag_24564 == ((int64_t)0ULL))) {
                heff_drop(v_d_24555);
                V v_x_24567 = v_field_24565;
                return v_x_24567;
              } else {
                heff_drop(v_field_24565);
                return v_d_24555;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24559);
            return v_d_24555;
          }
        }
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24570 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24572 = v_t_24570.f[1];
      int64_t v_tag_24571 = ((int64_t)v_t_24570.f[0]);
      if ((v_tag_24571 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24574 = v_field_24572;
        heff_drop(v_x_24574);
        V v_t_24575 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24576 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24575, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24577 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str90), heff_strAppend(v_t_24576, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str91)));
        return heff_strAppend(v_shown_242, v_t_24577);
      } else {
        heff_drop(v_field_24572);
        V v_t_24578 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24579 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24578, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24580 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str92), heff_strAppend(v_t_24579, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str93)));
        V v_d_24581 = heff_strAppend(v_shown_242, v_t_24580);
        V v_t_24582 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24583 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24582; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24585 = v_t_24583.f[1];
          int64_t v_tag_24584 = ((int64_t)v_t_24583.f[0]);
          if ((v_tag_24584 == ((int64_t)0ULL))) {
            V v_tf_24587 = v_field_24585;
            V v_t_24588 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24589 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24588, v_name_241, v_tf_24587));
            {
              V v_field_24591 = v_t_24589.f[1];
              int64_t v_tag_24590 = ((int64_t)v_t_24589.f[0]);
              if ((v_tag_24590 == ((int64_t)0ULL))) {
                heff_drop(v_d_24581);
                V v_x_24593 = v_field_24591;
                return v_x_24593;
              } else {
                heff_drop(v_field_24591);
                return v_d_24581;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24585);
            return v_d_24581;
          }
        }
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24595 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24597 = v_t_24595.f[1];
      int64_t v_tag_24596 = ((int64_t)v_t_24595.f[0]);
      if ((v_tag_24596 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24599 = v_field_24597;
        heff_drop(v_x_24599);
        V v_t_24600 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24601 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24600, MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24602 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str94), heff_strAppend(v_t_24601, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str95)));
        return heff_strAppend(v_shown_242, v_t_24602);
      } else {
        heff_drop(v_field_24597);
        V v_t_24603 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(v_im_240), MK_INT(0LL), NTAG(TAG_True)});
        V v_t_24604 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24603, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24605 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str96), heff_strAppend(v_t_24604, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str97)));
        V v_d_24606 = heff_strAppend(v_shown_242, v_t_24605);
        V v_t_24607 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24608 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24607; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        {
          V v_field_24610 = v_t_24608.f[1];
          int64_t v_tag_24609 = ((int64_t)v_t_24608.f[0]);
          if ((v_tag_24609 == ((int64_t)0ULL))) {
            V v_tf_24612 = v_field_24610;
            V v_t_24613 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_im_240, MK_INT(0LL), NTAG(TAG_False)});
            HeffT2 v_t_24614 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(v_t_24613, v_name_241, v_tf_24612));
            {
              V v_field_24616 = v_t_24614.f[1];
              int64_t v_tag_24615 = ((int64_t)v_t_24614.f[0]);
              if ((v_tag_24615 == ((int64_t)0ULL))) {
                heff_drop(v_d_24606);
                V v_x_24618 = v_field_24616;
                return v_x_24618;
              } else {
                heff_drop(v_field_24616);
                return v_d_24606;
              }
            }
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24610);
            return v_d_24606;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28, 5, " @ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return (g_heff_2esyntax_2esurfaceprint_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str0), 2)) {
      return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
    } else {
      HeffT2 v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_245, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_ws_2411 = v_field_249;
          V v_t_2414;
          switch (heff_tag_of(v_ws_2411)) {
          case TAG_Nil: {
            v_t_2414 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_ws_2411, 0);
            V v_xs_2413 = heff_field(v_ws_2411, 1);
            heff_take_n(v_ws_2411, 3ULL, 2);
            v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2411);
          }
          V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str3), v_t_2414);
          heff_drop(v_t_2415);
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str4), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str5)));
        } else {
          heff_drop(v_field_249);
          return (g_heff_2esyntax_2epresyntax_2emadeNameSaid(v_x_245));
        }
      }
    }
  }
  case TAG_SCode: {
    V v_t_2416 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2417 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2417, v_p_241, v_xs_242, v_t_2416);
  }
  case TAG_SApp: {
    V v_f_2418 = heff_field(v_e_243, 0);
    V v_a_2419 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2420 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(v_t_2420, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2418, v_a_2419}));
  }
  case TAG_SLam: {
    V v_t_2421 = heff_field(v_e_243, 0);
    V v_b_2422 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2423 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, v_b_2422})));
    return ({ V a_0 = v_t_2423; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2424; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2425 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_take_field(v_d_2425, 0));
    V v_t_2427 = heff_arrayToList(heff_get_n(v_d_2425, 2, 3));
    V v_t_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_x2_2434 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2428));
    V v_t_2437;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_xs_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str8); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str9), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str10)));
  }
  case TAG_SProj: {
    V v_e2_2438 = heff_field(v_e_243, 0);
    V v_l_2439 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2440 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2440, MK_INT(2LL), v_xs_242, v_e2_2438));
    return heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str11), v_l_2439));
  }
  case TAG_STag: {
    V v_x_2442 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2443 = heff_dup(heff_field(v_e_243, 1));
    HeffT2 v_t_2444 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_e_243));
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_x_2442);
        heff_drop(v_ts_2443);
        V v_items_2448 = v_field_2446;
        V v_x2_2451 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2448));
        V v_t_2454;
        switch (heff_tag_of(v_x2_2451)) {
        case TAG_Nil: {
          v_t_2454 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2452 = heff_field(v_x2_2451, 0);
          V v_xs_2453 = heff_field(v_x2_2451, 1);
          heff_take_n(v_x2_2451, 3ULL, 2);
          v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str13); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2451);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str14), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str15)));
      } else {
        heff_drop(v_field_2446);
        V v_t_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2443)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intEq_c(v_t_2455, MK_INT(0LL))) {
          heff_drop(v_lit_240);
          heff_drop(v_p_241);
          heff_drop(v_xs_242);
          heff_drop(v_ts_2443);
          return v_x_2442;
        } else {
          V v_s_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str16); V a_1 = v_x_2442; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2443); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
            return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str17), heff_strAppend(v_s_2459, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str18)));
          } else {
            return v_s_2459;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    V v_s_2461 = heff_field(v_e_243, 0);
    V v_cases_2462 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2463 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
    V v_t_2464 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2463, MK_INT(0LL), heff_dup(v_xs_242), v_s_2461));
    V v_t_2465 = heff_arrayToList(heff_take_field(v_cases_2462, 0));
    V v_t_2466 = heff_arrayToList(heff_get_n(v_cases_2462, 2, 3));
    V v_t_2467 = (g_heff_2eutil_2edict_2ezipKV(v_t_2465, v_t_2466));
    V v_x2_2470 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2467));
    V v_t_2473;
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_Nil: {
      v_t_2473 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_xs_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      v_t_2473 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str20); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2470);
    }
    V v_t_2474 = heff_strAppend(v_t_2464, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str21), v_t_2473));
    V v_s_2475 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str22), v_t_2474);
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str23), heff_strAppend(v_s_2475, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str24)));
    } else {
      return v_s_2475;
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_2480 = (g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(v_e_243, NTAG(TAG_Nil)));
    {
      V v_field_2481 = v_t_2480.f[0];
      V v_field_2482 = v_t_2480.f[1];
      V v_base_2483 = v_field_2481;
      V v_sets_2484 = v_field_2482;
      V v_t_2485 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240), NTAG(TAG_False)});
      V v_t_2486 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2485, MK_INT(1LL), heff_dup(v_xs_242), v_base_2483));
      V v_x2_2492 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4, 1, 2, (V[]){v_lit_240, v_xs_242}), v_sets_2484));
      V v_t_2495;
      switch (heff_tag_of(v_x2_2492)) {
      case TAG_Nil: {
        v_t_2495 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str26);
        break;
      }
      case TAG_Cons: {
        V v_x_2493 = heff_field(v_x2_2492, 0);
        V v_xs_2494 = heff_field(v_x2_2492, 1);
        heff_take_n(v_x2_2492, 3ULL, 2);
        v_t_2495 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str27); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2492);
      }
      V v_t_2496 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str28), heff_strAppend(v_t_2495, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str29)));
      V v_s_2497 = heff_strAppend(v_t_2486, v_t_2496);
      if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str30), heff_strAppend(v_s_2497, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str31)));
      } else {
        return v_s_2497;
      }
    }
  }
  case TAG_SIs: {
    V v_e2_2499 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_24100 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_24100, v_p_241, v_xs_242, v_e2_2499);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str32);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str33);
  }
  case TAG_SRec: {
    V v_e2_24101 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_24102 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_24102, v_p_241, v_xs_242, v_e2_24101);
  }
  case TAG_SFix: {
    V v_e2_27_24104 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_24104)) {
    case TAG_MkAbs: {
      V v_x_24105 = heff_field(v_e2_27_24104, 0);
      heff_take_n(v_e2_27_24104, 1ULL, 2);
      return v_x_24105;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_24104, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str34);
    }
    default: return heff_nomatch(v_e2_27_24104);
    }
  }
  case TAG_SImplicit: {
    V v_e2_24109 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V v_t_24110 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_24110, v_p_241, v_xs_242, v_e2_24109);
  }
  case TAG_SPrim: {
    V v_x_24111 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str35), heff_strAppend(v_x_24111, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str36)));
  }
  case TAG_SMetaApp: {
    V v_m_24112 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str37), heff_intShow(v_m_24112));
  }
  case TAG_SLitInt: {
    V v_i_24115 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_24115);
  }
  case TAG_SLitFloat: {
    V v_x_24116 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24116);
  }
  case TAG_SLitString: {
    V v_s_24117 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24118 = ({ V a_0 = v_s_24117; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str38); V r_ = (g_heff_2eutil_2erune_2equoteGo(a_0, a_1, a_2)); heff_drop(v_s_24117); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str39), heff_strAppend(v_t_24118, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str40)));
  }
  case TAG_SLitBytes: {
    V v_s_24119 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24120 = ({ V a_0 = v_s_24119; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str41); V a_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str42); V r_ = (g_heff_2eutil_2erune_2equoteBytesGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_24119); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str43), heff_strAppend(v_t_24120, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str44)));
  }
  case TAG_SLitRune: {
    V v_ch_24121 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_24122 = (g_heff_2eutil_2erune_2equoted(v_ch_24121));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str45), heff_strAppend(v_t_24122, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str46)));
  }
  case TAG_SLitFixed: {
    V v_n_24124 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_24124);
  }
  case TAG_SLitFloat32: {
    V v_x_24125 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24125);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam0(V self, V *args) {
  V v_f_2429 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2429)) {
  case TAG_MkPair: {
    V v_l_2430 = heff_field(v_f_2429, 0);
    V v_e_2431 = heff_field(v_f_2429, 1);
    heff_take_n(v_f_2429, 3ULL, 2);
    V v_t_2432 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2432, MK_INT(0LL), v_xs_242, v_e_2431));
    return heff_strAppend(v_l_2430, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str6), v_t_2433));
  }
  default: return heff_nomatch(v_f_2429);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam1(V self, V *args) {
  V v_a_2449 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2450, MK_INT(0LL), v_xs_242, v_a_2449));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam2(V self, V *args) {
  V v_a_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2458, MK_INT(2LL), v_xs_242, v_a_2457));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam3(V self, V *args) {
  V v_alt_2468 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_box_word((heff_unbox_word(v_lit_240) + ((int64_t)2ULL))), NTAG(TAG_False)});
  return ({ V a_0 = v_t_2469; V a_1 = v_xs_242; V a_2 = v_alt_2468; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2468); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_lam4(V self, V *args) {
  V v_st_2487 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_st_2487, 0);
    V v_v_2489 = heff_field(v_st_2487, 1);
    heff_take_n(v_st_2487, 3ULL, 2);
    V v_t_2490 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_False)});
    V v_t_2491 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_2490, MK_INT(0LL), v_xs_242, v_v_2489));
    return heff_strAppend(v_x_2488, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_str25), v_t_2491));
  }
  default: return heff_nomatch(v_st_2487);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_246 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_246, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_x5_243, 0);
    V v_dom_248 = heff_field(v_x5_243, 1);
    V v_cod_249 = heff_field(v_x5_243, 2);
    V v_implicit_2410 = heff_field(v_x5_243, 3);
    V v_dflt_2411 = heff_field(v_x5_243, 4);
    V v_s_2415;
    switch (heff_tag_of(v_dflt_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(v_t_2412, v_xs_242, v_level_247, heff_dup(v_dom_248), heff_dup(v_cod_249), v_implicit_2410));
      break;
    }
    case TAG_Just: {
      V v_d_2413 = heff_field(v_dflt_2411, 0);
      V v_t_2414 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
      v_s_2415 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_t_2414, v_xs_242, heff_dup(v_dom_248), heff_dup(v_cod_249), heff_dup(v_d_2413)));
      break;
    }
    default: heff_nomatch(v_dflt_2411);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str2), heff_strAppend(v_s_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str3)));
    } else {
      return v_s_2415;
    }
  }
  case TAG_SRecord: {
    V v_fs_2418 = heff_field(v_x5_243, 1);
    V v_ds_2419 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2420 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2418, 0)));
    V v_t_2421 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2418, 2)));
    V v_fs_2422 = (g_heff_2eutil_2edict_2ezipKV(v_t_2420, v_t_2421));
    V v_t_2423 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2427 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2419)}); V a_1 = v_t_2423; V a_2 = v_fs_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2422); r_; });
    V v_t_2428 = heff_get_n(v_acc_2427, 1, 2);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_t_2428, 0);
      V v_xs_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str5); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str6), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str7)));
  }
  case TAG_SSum: {
    V v_vs_2432 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2433 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2432, 0)));
    V v_t_2434 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2432, 2)));
    V v_t_2435 = (g_heff_2eutil_2edict_2ezipKV(v_t_2433, v_t_2434));
    V v_x2_2441 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2435));
    V v_t_2444;
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_Nil: {
      v_t_2444 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_xs_2443 = heff_field(v_x2_2441, 1);
      heff_take_n(v_x2_2441, 3ULL, 2);
      v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str10); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2441);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str11), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2445 = heff_field(v_x5_243, 0);
    V v_t_2446 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2446, v_p_241, v_xs_242, heff_dup(v_t2_2445));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2447 = heff_field(v_x5_243, 0);
    V v_t_2448 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
    V v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2448, MK_INT(2LL), v_xs_242, heff_dup(v_a_2447)));
    V v_s_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str17), v_t_2449);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str18), heff_strAppend(v_s_2450, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str19)));
    } else {
      return v_s_2450;
    }
  }
  case TAG_SFixed: {
    V v_w_2452 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2452)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str28);
    }
    default: return heff_nomatch(v_w_2452);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam0(V self, V *args) {
  V v_acc_2424 = args[0];
  V v_f_2425 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2426, v_ds_2419, v_acc_2424, v_f_2425));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2(V self, V *args) {
  V v_t2_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2440, MK_INT(2LL), v_xs_242, v_t2_2439));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam1(V self, V *args) {
  V v_v_2436 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2436)) {
  case TAG_MkPair: {
    V v_t_2437 = heff_field(v_v_2436, 0);
    V v_ts_2438 = heff_field(v_v_2436, 1);
    heff_take_n(v_v_2436, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_str8); V a_1 = v_t_2437; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2438); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2436);
  }
}