// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerOf(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerOf_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo;
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

static V g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2earrayNone_st;
static V g_heff_2esyntax_2esurfaceprint_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2earrayNone_st)) return g_heff_2esyntax_2esurfaceprint_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2earrayNone_val, &g_heff_2esyntax_2esurfaceprint_2earrayNone_st, g_heff_2esyntax_2esurfaceprint_2earrayNone_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st;
static V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st)) return g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2esurfaceprint_2eplainImplicits_val, &g_heff_2esyntax_2esurfaceprint_2eplainImplicits_st, g_heff_2esyntax_2esurfaceprint_2eplainImplicits_init);
}
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2enamed_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enamed_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2enamed(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str0), 2)) {
    return v_x_240;
  } else {
    HeffT2 v_t_242 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_ws_246 = v_field_244;
        V v_t_249;
        switch (heff_tag_of(v_ws_246)) {
        case TAG_Nil: {
          v_t_249 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_247 = heff_field(v_ws_246, 0);
          V v_xs_248 = heff_field(v_ws_246, 1);
          heff_take_n(v_ws_246, 3ULL, 2);
          v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
          break;
        }
        default: heff_nomatch(v_ws_246);
        }
        V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str3), v_t_249);
        heff_drop(v_t_2410);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str4), heff_strAppend(v_x_240, ((V)&g_heff_2esyntax_2esurfaceprint_2enamed_str5)));
      } else {
        heff_drop(v_field_244);
        return v_x_240;
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2enamed(a[0]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}), v_b_246));
    V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str0), v_t_249));
    V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str1), v_t_2410));
    V v_t_2412 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str2), v_t_2411));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str3), v_t_2412);
  }
  case TAG_AbsConst: {
    V v_b_2413 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), v_xs_241, v_b_2413));
    V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str4), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str5), v_t_2417));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_str6), v_t_2418);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4, 3, " : ");
Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_245));
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ds_241, 1), v_l_244));
    V v_t_2418;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_i_2412 = v_field_2410;
        V v_xs_2413 = heff_get_n(v_ds_241, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_2412, 1)) {
          if (heff_intLt_c(heff_dup(v_i_2412), heff_arrayLength_lent(v_xs_2413, 0))) {
            V v_t_2416 = heff_arrayIndex(v_xs_2413, v_i_2412);
            V v_t_2417 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_t_2416));
            v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str0), v_t_2417);
          } else {
            heff_drop(v_c_240);
            heff_drop(v_i_2412);
            heff_drop(v_xs_2413);
            v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str1);
          }
        } else {
          heff_drop(v_c_240);
          heff_drop(v_i_2412);
          heff_drop(v_xs_2413);
          v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str2);
        }
      } else {
        heff_drop(v_c_240);
        heff_drop_rec(v_ds_241, 3);
        heff_drop(v_field_2410);
        v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str3);
      }
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_str4), heff_strAppend(v_t_247, v_t_2418));
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_l_244, v_t_2419), NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2420));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_str3), v_c_240, v_p_241, v_xs_242, v_e_243));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2424}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2estripIs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return v_x1_240;
  }
  case TAG_SGlobal: {
    return v_x1_240;
  }
  case TAG_SCode: {
    return v_x1_240;
  }
  case TAG_SApp: {
    return v_x1_240;
  }
  case TAG_SLam: {
    return v_x1_240;
  }
  case TAG_SCons: {
    return v_x1_240;
  }
  case TAG_SProj: {
    return v_x1_240;
  }
  case TAG_STag: {
    return v_x1_240;
  }
  case TAG_SMatch: {
    return v_x1_240;
  }
  case TAG_SSpecialize: {
    return v_x1_240;
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_x1_240;
  }
  case TAG_SAbandon: {
    return v_x1_240;
  }
  case TAG_SRec: {
    return v_x1_240;
  }
  case TAG_SFix: {
    return v_x1_240;
  }
  case TAG_SImplicit: {
    return v_x1_240;
  }
  case TAG_SPrim: {
    return v_x1_240;
  }
  case TAG_SMetaApp: {
    return v_x1_240;
  }
  case TAG_SLitInt: {
    return v_x1_240;
  }
  case TAG_SLitFloat: {
    return v_x1_240;
  }
  case TAG_SLitString: {
    return v_x1_240;
  }
  case TAG_SLitBytes: {
    return v_x1_240;
  }
  case TAG_SLitRune: {
    return v_x1_240;
  }
  case TAG_SLitFixed: {
    return v_x1_240;
  }
  case TAG_SLitFloat32: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2estripIs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9, 2, 0};
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_x5_243, 0);
    V v_dom_2410 = heff_field(v_x5_243, 1);
    V v_cod_2411 = heff_field(v_x5_243, 2);
    V v_implicit_2412 = heff_field(v_x5_243, 3);
    V v_dflt_2413 = heff_field(v_x5_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(heff_rec_n(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, heff_dup(v_dom_2410), heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(heff_rec_n(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, heff_dup(v_dom_2410), heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str3)));
    } else {
      return v_s_2421;
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_x5_243, 1);
    V v_ds_2425 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 2)));
    V v_fs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_t_2436 = heff_get_n(v_acc_2435, 1, 2);
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_t_2436, 0);
      V v_xs_2438 = heff_field(v_t_2436, 1);
      heff_take_n(v_t_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 0)));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 2)));
    V v_t_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2451 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str10); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str11), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2455 = heff_field(v_x5_243, 0);
    V v_t_2458 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2458, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_t2_2455));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9_clo), NTAG(TAG_False)});
    V v_t_2463 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2462, v_lit_240}), MK_INT(2LL), v_xs_242, heff_dup(v_a_2459)));
    V v_s_2464 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str17), v_t_2463);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str18), heff_strAppend(v_s_2464, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str19)));
    } else {
      return v_s_2464;
    }
  }
  case TAG_SFixed: {
    V v_w_2466 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2466)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str28);
    }
    default: return heff_nomatch(v_w_2466);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(heff_rec_n(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam7_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}), MK_INT(2LL), v_xs_242, v_t2_2447));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    heff_take_n(v_v_2444, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_str8); V a_1 = v_t_2445; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2446); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam8(V self, V *args) {
  V v_a_2456 = args[0];
  V v_a_2457 = args[1];
  heff_drop(v_a_2456);
  heff_drop(v_a_2457);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216_lam9(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str2), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str4), heff_strAppend(v_x_241, v_t_247));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str5), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str7), heff_strAppend(v_x_241, v_t_2410));
  }
  case TAG_SFunction: {
    V v_t_2416 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2417));
  }
  case TAG_SRecord: {
    V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2422));
  }
  case TAG_SSum: {
    V v_t_2424 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2425));
  }
  case TAG_SIsTy: {
    V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str17), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2428));
  }
  case TAG_SPrimInt: {
    V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str20), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2430));
  }
  case TAG_SPrimFloat: {
    V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2432));
  }
  case TAG_SPrimString: {
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str26), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2434));
  }
  case TAG_SPrimRune: {
    V v_t_2435 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str29), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2436));
  }
  case TAG_SPrimArray: {
    V v_t_2438 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str32), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2439));
  }
  case TAG_SFixed: {
    V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1984140141x1105953216(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2442));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2esurfaceprint_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2410 = v_field_248;
        heff_drop(v_x_2410);
        V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str0), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str1)));
        return heff_strAppend(v_shown_242, v_t_2412);
      } else {
        heff_drop(v_field_248);
        V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str3)));
        V v_d_2415 = heff_strAppend(v_shown_242, v_t_2414);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2417 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2416; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_2422;
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_tf_2421 = v_field_2419;
            v_x2_2422 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2421));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2419);
            v_x2_2422 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Nothing: {
          return v_d_2415;
        }
        case TAG_Just: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          heff_take_n(v_x2_2422, 1ULL, 1);
          heff_drop(v_d_2415);
          return v_x_2423;
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2425 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2429 = v_field_2427;
        heff_drop(v_x_2429);
        V v_t_2430 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str4), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str5)));
        return heff_strAppend(v_shown_242, v_t_2431);
      } else {
        heff_drop(v_field_2427);
        V v_t_2432 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str6), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str7)));
        V v_d_2434 = heff_strAppend(v_shown_242, v_t_2433);
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2436 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2435; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_2441;
        {
          V v_field_2438 = v_t_2436.f[1];
          int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
          if ((v_tag_2437 == ((int64_t)0ULL))) {
            V v_tf_2440 = v_field_2438;
            v_x2_2441 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2440));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2438);
            v_x2_2441 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nothing: {
          return v_d_2434;
        }
        case TAG_Just: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          heff_take_n(v_x2_2441, 1ULL, 1);
          heff_drop(v_d_2434);
          return v_x_2442;
        }
        default: return heff_nomatch(v_x2_2441);
        }
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2444 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_2448 = v_field_2446;
        heff_drop(v_x_2448);
        V v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str8), heff_strAppend(v_t_2449, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str9)));
        return heff_strAppend(v_shown_242, v_t_2450);
      } else {
        heff_drop(v_field_2446);
        V v_t_2451 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2452 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str10), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str11)));
        V v_d_2453 = heff_strAppend(v_shown_242, v_t_2452);
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2455 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2454; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_2460;
        {
          V v_field_2457 = v_t_2455.f[1];
          int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
          if ((v_tag_2456 == ((int64_t)0ULL))) {
            V v_tf_2459 = v_field_2457;
            v_x2_2460 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2459));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2457);
            v_x2_2460 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_Nothing: {
          return v_d_2453;
        }
        case TAG_Just: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          heff_take_n(v_x2_2460, 1ULL, 1);
          heff_drop(v_d_2453);
          return v_x_2461;
        }
        default: return heff_nomatch(v_x2_2460);
        }
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2464 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2466 = v_t_2464.f[1];
      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
      if ((v_tag_2465 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2468 = v_field_2466;
        heff_drop(v_x_2468);
        V v_t_2469 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2470 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str12), heff_strAppend(v_t_2469, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str13)));
        return heff_strAppend(v_shown_242, v_t_2470);
      } else {
        heff_drop(v_field_2466);
        V v_t_2471 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str14), heff_strAppend(v_t_2471, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str15)));
        V v_d_2473 = heff_strAppend(v_shown_242, v_t_2472);
        V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2475 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2474; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_2480;
        {
          V v_field_2477 = v_t_2475.f[1];
          int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
          if ((v_tag_2476 == ((int64_t)0ULL))) {
            V v_tf_2479 = v_field_2477;
            v_x2_2480 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2479));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2477);
            v_x2_2480 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_2480)) {
        case TAG_Nothing: {
          return v_d_2473;
        }
        case TAG_Just: {
          V v_x_2481 = heff_field(v_x2_2480, 0);
          heff_take_n(v_x2_2480, 1ULL, 1);
          heff_drop(v_d_2473);
          return v_x_2481;
        }
        default: return heff_nomatch(v_x2_2480);
        }
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_2484 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_2486 = v_t_2484.f[1];
      int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
      if ((v_tag_2485 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_2488 = v_field_2486;
        heff_drop(v_x_2488);
        V v_t_2489 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_2490 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str16), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str17)));
        return heff_strAppend(v_shown_242, v_t_2490);
      } else {
        heff_drop(v_field_2486);
        V v_t_2491 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_2492 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str18), heff_strAppend(v_t_2491, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str19)));
        V v_d_2493 = heff_strAppend(v_shown_242, v_t_2492);
        V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_2495 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_2494; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24100;
        {
          V v_field_2497 = v_t_2495.f[1];
          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
          if ((v_tag_2496 == ((int64_t)0ULL))) {
            V v_tf_2499 = v_field_2497;
            v_x2_24100 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2499));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_2497);
            v_x2_24100 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24100)) {
        case TAG_Nothing: {
          return v_d_2493;
        }
        case TAG_Just: {
          V v_x_24101 = heff_field(v_x2_24100, 0);
          heff_take_n(v_x2_24100, 1ULL, 1);
          heff_drop(v_d_2493);
          return v_x_24101;
        }
        default: return heff_nomatch(v_x2_24100);
        }
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_24103 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24105 = v_t_24103.f[1];
      int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
      if ((v_tag_24104 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24107 = v_field_24105;
        heff_drop(v_x_24107);
        V v_t_24108 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24109 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str20), heff_strAppend(v_t_24108, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str21)));
        return heff_strAppend(v_shown_242, v_t_24109);
      } else {
        heff_drop(v_field_24105);
        V v_t_24110 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24111 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str22), heff_strAppend(v_t_24110, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str23)));
        V v_d_24112 = heff_strAppend(v_shown_242, v_t_24111);
        V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24114 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24113; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24119;
        {
          V v_field_24116 = v_t_24114.f[1];
          int64_t v_tag_24115 = ((int64_t)v_t_24114.f[0]);
          if ((v_tag_24115 == ((int64_t)0ULL))) {
            V v_tf_24118 = v_field_24116;
            v_x2_24119 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24118));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24116);
            v_x2_24119 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24119)) {
        case TAG_Nothing: {
          return v_d_24112;
        }
        case TAG_Just: {
          V v_x_24120 = heff_field(v_x2_24119, 0);
          heff_take_n(v_x2_24119, 1ULL, 1);
          heff_drop(v_d_24112);
          return v_x_24120;
        }
        default: return heff_nomatch(v_x2_24119);
        }
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_24123 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24125 = v_t_24123.f[1];
      int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
      if ((v_tag_24124 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24127 = v_field_24125;
        heff_drop(v_x_24127);
        V v_t_24128 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24129 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str24), heff_strAppend(v_t_24128, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str25)));
        return heff_strAppend(v_shown_242, v_t_24129);
      } else {
        heff_drop(v_field_24125);
        V v_t_24130 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24131 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str26), heff_strAppend(v_t_24130, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str27)));
        V v_d_24132 = heff_strAppend(v_shown_242, v_t_24131);
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24134 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24133; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24139;
        {
          V v_field_24136 = v_t_24134.f[1];
          int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
          if ((v_tag_24135 == ((int64_t)0ULL))) {
            V v_tf_24138 = v_field_24136;
            v_x2_24139 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24138));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24136);
            v_x2_24139 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24139)) {
        case TAG_Nothing: {
          return v_d_24132;
        }
        case TAG_Just: {
          V v_x_24140 = heff_field(v_x2_24139, 0);
          heff_take_n(v_x2_24139, 1ULL, 1);
          heff_drop(v_d_24132);
          return v_x_24140;
        }
        default: return heff_nomatch(v_x2_24139);
        }
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_24143 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24145 = v_t_24143.f[1];
      int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
      if ((v_tag_24144 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24147 = v_field_24145;
        heff_drop(v_x_24147);
        V v_t_24148 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24149 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str28), heff_strAppend(v_t_24148, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str29)));
        return heff_strAppend(v_shown_242, v_t_24149);
      } else {
        heff_drop(v_field_24145);
        V v_t_24150 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24151 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str30), heff_strAppend(v_t_24150, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str31)));
        V v_d_24152 = heff_strAppend(v_shown_242, v_t_24151);
        V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24154 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24153; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24159;
        {
          V v_field_24156 = v_t_24154.f[1];
          int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
          if ((v_tag_24155 == ((int64_t)0ULL))) {
            V v_tf_24158 = v_field_24156;
            v_x2_24159 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24158));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24156);
            v_x2_24159 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24159)) {
        case TAG_Nothing: {
          return v_d_24152;
        }
        case TAG_Just: {
          V v_x_24160 = heff_field(v_x2_24159, 0);
          heff_take_n(v_x2_24159, 1ULL, 1);
          heff_drop(v_d_24152);
          return v_x_24160;
        }
        default: return heff_nomatch(v_x2_24159);
        }
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_24163 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24165 = v_t_24163.f[1];
      int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
      if ((v_tag_24164 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24167 = v_field_24165;
        heff_drop(v_x_24167);
        V v_t_24168 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str32), heff_strAppend(v_t_24168, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str33)));
        return heff_strAppend(v_shown_242, v_t_24169);
      } else {
        heff_drop(v_field_24165);
        V v_t_24170 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24171 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str34), heff_strAppend(v_t_24170, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str35)));
        V v_d_24172 = heff_strAppend(v_shown_242, v_t_24171);
        V v_t_24173 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24174 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24173; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24179;
        {
          V v_field_24176 = v_t_24174.f[1];
          int64_t v_tag_24175 = ((int64_t)v_t_24174.f[0]);
          if ((v_tag_24175 == ((int64_t)0ULL))) {
            V v_tf_24178 = v_field_24176;
            v_x2_24179 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24178));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24176);
            v_x2_24179 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24179)) {
        case TAG_Nothing: {
          return v_d_24172;
        }
        case TAG_Just: {
          V v_x_24180 = heff_field(v_x2_24179, 0);
          heff_take_n(v_x2_24179, 1ULL, 1);
          heff_drop(v_d_24172);
          return v_x_24180;
        }
        default: return heff_nomatch(v_x2_24179);
        }
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_24184 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24186 = v_t_24184.f[1];
      int64_t v_tag_24185 = ((int64_t)v_t_24184.f[0]);
      if ((v_tag_24185 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24188 = v_field_24186;
        heff_drop(v_x_24188);
        V v_t_24189 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24190 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str36), heff_strAppend(v_t_24189, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str37)));
        return heff_strAppend(v_shown_242, v_t_24190);
      } else {
        heff_drop(v_field_24186);
        V v_t_24191 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24192 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str38), heff_strAppend(v_t_24191, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str39)));
        V v_d_24193 = heff_strAppend(v_shown_242, v_t_24192);
        V v_t_24194 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24195 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24194; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24200;
        {
          V v_field_24197 = v_t_24195.f[1];
          int64_t v_tag_24196 = ((int64_t)v_t_24195.f[0]);
          if ((v_tag_24196 == ((int64_t)0ULL))) {
            V v_tf_24199 = v_field_24197;
            v_x2_24200 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24199));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24197);
            v_x2_24200 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24200)) {
        case TAG_Nothing: {
          return v_d_24193;
        }
        case TAG_Just: {
          V v_x_24201 = heff_field(v_x2_24200, 0);
          heff_take_n(v_x2_24200, 1ULL, 1);
          heff_drop(v_d_24193);
          return v_x_24201;
        }
        default: return heff_nomatch(v_x2_24200);
        }
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_24203 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24205 = v_t_24203.f[1];
      int64_t v_tag_24204 = ((int64_t)v_t_24203.f[0]);
      if ((v_tag_24204 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24207 = v_field_24205;
        heff_drop(v_x_24207);
        V v_t_24208 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str40), heff_strAppend(v_t_24208, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str41)));
        return heff_strAppend(v_shown_242, v_t_24209);
      } else {
        heff_drop(v_field_24205);
        V v_t_24210 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24211 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str42), heff_strAppend(v_t_24210, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str43)));
        V v_d_24212 = heff_strAppend(v_shown_242, v_t_24211);
        V v_t_24213 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24214 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24213; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24219;
        {
          V v_field_24216 = v_t_24214.f[1];
          int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
          if ((v_tag_24215 == ((int64_t)0ULL))) {
            V v_tf_24218 = v_field_24216;
            v_x2_24219 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24218));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24216);
            v_x2_24219 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24219)) {
        case TAG_Nothing: {
          return v_d_24212;
        }
        case TAG_Just: {
          V v_x_24220 = heff_field(v_x2_24219, 0);
          heff_take_n(v_x2_24219, 1ULL, 1);
          heff_drop(v_d_24212);
          return v_x_24220;
        }
        default: return heff_nomatch(v_x2_24219);
        }
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_24221 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24223 = v_t_24221.f[1];
      int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
      if ((v_tag_24222 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        V v_x_24225 = v_field_24223;
        heff_drop(v_x_24225);
        V v_t_24226 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24227 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str44), heff_strAppend(v_t_24226, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str45)));
        return heff_strAppend(v_shown_242, v_t_24227);
      } else {
        heff_drop(v_field_24223);
        V v_t_24228 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24229 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str46), heff_strAppend(v_t_24228, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str47)));
        V v_d_24230 = heff_strAppend(v_shown_242, v_t_24229);
        V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24232 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24231; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24237;
        {
          V v_field_24234 = v_t_24232.f[1];
          int64_t v_tag_24233 = ((int64_t)v_t_24232.f[0]);
          if ((v_tag_24233 == ((int64_t)0ULL))) {
            V v_tf_24236 = v_field_24234;
            v_x2_24237 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24236));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24234);
            v_x2_24237 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24237)) {
        case TAG_Nothing: {
          return v_d_24230;
        }
        case TAG_Just: {
          V v_x_24238 = heff_field(v_x2_24237, 0);
          heff_take_n(v_x2_24237, 1ULL, 1);
          heff_drop(v_d_24230);
          return v_x_24238;
        }
        default: return heff_nomatch(v_x2_24237);
        }
      }
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24239 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
    V v_t_24240 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str48), heff_strAppend(v_t_24239, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24240);
  }
  case TAG_SRec: {
    HeffT2 v_t_24242 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24244 = v_t_24242.f[1];
      int64_t v_tag_24243 = ((int64_t)v_t_24242.f[0]);
      if ((v_tag_24243 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24246 = v_field_24244;
        heff_drop(v_x_24246);
        V v_t_24247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str50), heff_strAppend(v_t_24247, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str51)));
        return heff_strAppend(v_shown_242, v_t_24248);
      } else {
        heff_drop(v_field_24244);
        V v_t_24249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24250 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str52), heff_strAppend(v_t_24249, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str53)));
        V v_d_24251 = heff_strAppend(v_shown_242, v_t_24250);
        V v_t_24252 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24253 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24252; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24258;
        {
          V v_field_24255 = v_t_24253.f[1];
          int64_t v_tag_24254 = ((int64_t)v_t_24253.f[0]);
          if ((v_tag_24254 == ((int64_t)0ULL))) {
            V v_tf_24257 = v_field_24255;
            v_x2_24258 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24257));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24255);
            v_x2_24258 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24258)) {
        case TAG_Nothing: {
          return v_d_24251;
        }
        case TAG_Just: {
          V v_x_24259 = heff_field(v_x2_24258, 0);
          heff_take_n(v_x2_24258, 1ULL, 1);
          heff_drop(v_d_24251);
          return v_x_24259;
        }
        default: return heff_nomatch(v_x2_24258);
        }
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24262 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24264 = v_t_24262.f[1];
      int64_t v_tag_24263 = ((int64_t)v_t_24262.f[0]);
      if ((v_tag_24263 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24266 = v_field_24264;
        heff_drop(v_x_24266);
        V v_t_24267 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24268 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str54), heff_strAppend(v_t_24267, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str55)));
        return heff_strAppend(v_shown_242, v_t_24268);
      } else {
        heff_drop(v_field_24264);
        V v_t_24269 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24270 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str56), heff_strAppend(v_t_24269, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str57)));
        V v_d_24271 = heff_strAppend(v_shown_242, v_t_24270);
        V v_t_24272 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24273 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24272; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24278;
        {
          V v_field_24275 = v_t_24273.f[1];
          int64_t v_tag_24274 = ((int64_t)v_t_24273.f[0]);
          if ((v_tag_24274 == ((int64_t)0ULL))) {
            V v_tf_24277 = v_field_24275;
            v_x2_24278 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24277));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24275);
            v_x2_24278 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24278)) {
        case TAG_Nothing: {
          return v_d_24271;
        }
        case TAG_Just: {
          V v_x_24279 = heff_field(v_x2_24278, 0);
          heff_take_n(v_x2_24278, 1ULL, 1);
          heff_drop(v_d_24271);
          return v_x_24279;
        }
        default: return heff_nomatch(v_x2_24278);
        }
      }
    }
  }
  case TAG_SImplicit: {
    HeffT2 v_t_24282 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24284 = v_t_24282.f[1];
      int64_t v_tag_24283 = ((int64_t)v_t_24282.f[0]);
      if ((v_tag_24283 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24286 = v_field_24284;
        heff_drop(v_x_24286);
        V v_t_24287 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24288 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str58), heff_strAppend(v_t_24287, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str59)));
        return heff_strAppend(v_shown_242, v_t_24288);
      } else {
        heff_drop(v_field_24284);
        V v_t_24289 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24290 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str60), heff_strAppend(v_t_24289, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str61)));
        V v_d_24291 = heff_strAppend(v_shown_242, v_t_24290);
        V v_t_24292 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24293 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24292; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24298;
        {
          V v_field_24295 = v_t_24293.f[1];
          int64_t v_tag_24294 = ((int64_t)v_t_24293.f[0]);
          if ((v_tag_24294 == ((int64_t)0ULL))) {
            V v_tf_24297 = v_field_24295;
            v_x2_24298 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24297));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24295);
            v_x2_24298 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24298)) {
        case TAG_Nothing: {
          return v_d_24291;
        }
        case TAG_Just: {
          V v_x_24299 = heff_field(v_x2_24298, 0);
          heff_take_n(v_x2_24298, 1ULL, 1);
          heff_drop(v_d_24291);
          return v_x_24299;
        }
        default: return heff_nomatch(v_x2_24298);
        }
      }
    }
  }
  case TAG_SPrim: {
    HeffT2 v_t_24301 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24303 = v_t_24301.f[1];
      int64_t v_tag_24302 = ((int64_t)v_t_24301.f[0]);
      if ((v_tag_24302 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24305 = v_field_24303;
        heff_drop(v_x_24305);
        V v_t_24306 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24307 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str62), heff_strAppend(v_t_24306, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str63)));
        return heff_strAppend(v_shown_242, v_t_24307);
      } else {
        heff_drop(v_field_24303);
        V v_t_24308 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24309 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str64), heff_strAppend(v_t_24308, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str65)));
        V v_d_24310 = heff_strAppend(v_shown_242, v_t_24309);
        V v_t_24311 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24312 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24311; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24317;
        {
          V v_field_24314 = v_t_24312.f[1];
          int64_t v_tag_24313 = ((int64_t)v_t_24312.f[0]);
          if ((v_tag_24313 == ((int64_t)0ULL))) {
            V v_tf_24316 = v_field_24314;
            v_x2_24317 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24316));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24314);
            v_x2_24317 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24317)) {
        case TAG_Nothing: {
          return v_d_24310;
        }
        case TAG_Just: {
          V v_x_24318 = heff_field(v_x2_24317, 0);
          heff_take_n(v_x2_24317, 1ULL, 1);
          heff_drop(v_d_24310);
          return v_x_24318;
        }
        default: return heff_nomatch(v_x2_24317);
        }
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24322 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24324 = v_t_24322.f[1];
      int64_t v_tag_24323 = ((int64_t)v_t_24322.f[0]);
      if ((v_tag_24323 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 3);
        V v_x_24326 = v_field_24324;
        heff_drop(v_x_24326);
        V v_t_24327 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24328 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str66), heff_strAppend(v_t_24327, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str67)));
        return heff_strAppend(v_shown_242, v_t_24328);
      } else {
        heff_drop(v_field_24324);
        V v_t_24329 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24330 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str68), heff_strAppend(v_t_24329, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str69)));
        V v_d_24331 = heff_strAppend(v_shown_242, v_t_24330);
        V v_t_24332 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24333 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24332; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24338;
        {
          V v_field_24335 = v_t_24333.f[1];
          int64_t v_tag_24334 = ((int64_t)v_t_24333.f[0]);
          if ((v_tag_24334 == ((int64_t)0ULL))) {
            V v_tf_24337 = v_field_24335;
            v_x2_24338 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24337));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24335);
            v_x2_24338 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24338)) {
        case TAG_Nothing: {
          return v_d_24331;
        }
        case TAG_Just: {
          V v_x_24339 = heff_field(v_x2_24338, 0);
          heff_take_n(v_x2_24338, 1ULL, 1);
          heff_drop(v_d_24331);
          return v_x_24339;
        }
        default: return heff_nomatch(v_x2_24338);
        }
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24341 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24343 = v_t_24341.f[1];
      int64_t v_tag_24342 = ((int64_t)v_t_24341.f[0]);
      if ((v_tag_24342 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24345 = v_field_24343;
        heff_drop(v_x_24345);
        V v_t_24346 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24347 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str70), heff_strAppend(v_t_24346, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str71)));
        return heff_strAppend(v_shown_242, v_t_24347);
      } else {
        heff_drop(v_field_24343);
        V v_t_24348 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24349 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str72), heff_strAppend(v_t_24348, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str73)));
        V v_d_24350 = heff_strAppend(v_shown_242, v_t_24349);
        V v_t_24351 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24352 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24351; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24357;
        {
          V v_field_24354 = v_t_24352.f[1];
          int64_t v_tag_24353 = ((int64_t)v_t_24352.f[0]);
          if ((v_tag_24353 == ((int64_t)0ULL))) {
            V v_tf_24356 = v_field_24354;
            v_x2_24357 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24356));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24354);
            v_x2_24357 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24357)) {
        case TAG_Nothing: {
          return v_d_24350;
        }
        case TAG_Just: {
          V v_x_24358 = heff_field(v_x2_24357, 0);
          heff_take_n(v_x2_24357, 1ULL, 1);
          heff_drop(v_d_24350);
          return v_x_24358;
        }
        default: return heff_nomatch(v_x2_24357);
        }
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24360 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24362 = v_t_24360.f[1];
      int64_t v_tag_24361 = ((int64_t)v_t_24360.f[0]);
      if ((v_tag_24361 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24364 = v_field_24362;
        heff_drop(v_x_24364);
        V v_t_24365 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24366 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str74), heff_strAppend(v_t_24365, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str75)));
        return heff_strAppend(v_shown_242, v_t_24366);
      } else {
        heff_drop(v_field_24362);
        V v_t_24367 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24368 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str76), heff_strAppend(v_t_24367, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str77)));
        V v_d_24369 = heff_strAppend(v_shown_242, v_t_24368);
        V v_t_24370 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24371 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24370; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24376;
        {
          V v_field_24373 = v_t_24371.f[1];
          int64_t v_tag_24372 = ((int64_t)v_t_24371.f[0]);
          if ((v_tag_24372 == ((int64_t)0ULL))) {
            V v_tf_24375 = v_field_24373;
            v_x2_24376 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24375));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24373);
            v_x2_24376 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24376)) {
        case TAG_Nothing: {
          return v_d_24369;
        }
        case TAG_Just: {
          V v_x_24377 = heff_field(v_x2_24376, 0);
          heff_take_n(v_x2_24376, 1ULL, 1);
          heff_drop(v_d_24369);
          return v_x_24377;
        }
        default: return heff_nomatch(v_x2_24376);
        }
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24379 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24381 = v_t_24379.f[1];
      int64_t v_tag_24380 = ((int64_t)v_t_24379.f[0]);
      if ((v_tag_24380 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24383 = v_field_24381;
        heff_drop(v_x_24383);
        V v_t_24384 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24385 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str78), heff_strAppend(v_t_24384, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str79)));
        return heff_strAppend(v_shown_242, v_t_24385);
      } else {
        heff_drop(v_field_24381);
        V v_t_24386 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24387 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str80), heff_strAppend(v_t_24386, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str81)));
        V v_d_24388 = heff_strAppend(v_shown_242, v_t_24387);
        V v_t_24389 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24390 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24389; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24395;
        {
          V v_field_24392 = v_t_24390.f[1];
          int64_t v_tag_24391 = ((int64_t)v_t_24390.f[0]);
          if ((v_tag_24391 == ((int64_t)0ULL))) {
            V v_tf_24394 = v_field_24392;
            v_x2_24395 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24394));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24392);
            v_x2_24395 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24395)) {
        case TAG_Nothing: {
          return v_d_24388;
        }
        case TAG_Just: {
          V v_x_24396 = heff_field(v_x2_24395, 0);
          heff_take_n(v_x2_24395, 1ULL, 1);
          heff_drop(v_d_24388);
          return v_x_24396;
        }
        default: return heff_nomatch(v_x2_24395);
        }
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24398 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24400 = v_t_24398.f[1];
      int64_t v_tag_24399 = ((int64_t)v_t_24398.f[0]);
      if ((v_tag_24399 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24402 = v_field_24400;
        heff_drop(v_x_24402);
        V v_t_24403 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24404 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str82), heff_strAppend(v_t_24403, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str83)));
        return heff_strAppend(v_shown_242, v_t_24404);
      } else {
        heff_drop(v_field_24400);
        V v_t_24405 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24406 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str84), heff_strAppend(v_t_24405, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str85)));
        V v_d_24407 = heff_strAppend(v_shown_242, v_t_24406);
        V v_t_24408 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24409 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24408; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24414;
        {
          V v_field_24411 = v_t_24409.f[1];
          int64_t v_tag_24410 = ((int64_t)v_t_24409.f[0]);
          if ((v_tag_24410 == ((int64_t)0ULL))) {
            V v_tf_24413 = v_field_24411;
            v_x2_24414 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24413));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24411);
            v_x2_24414 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24414)) {
        case TAG_Nothing: {
          return v_d_24407;
        }
        case TAG_Just: {
          V v_x_24415 = heff_field(v_x2_24414, 0);
          heff_take_n(v_x2_24414, 1ULL, 1);
          heff_drop(v_d_24407);
          return v_x_24415;
        }
        default: return heff_nomatch(v_x2_24414);
        }
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24417 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24419 = v_t_24417.f[1];
      int64_t v_tag_24418 = ((int64_t)v_t_24417.f[0]);
      if ((v_tag_24418 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24421 = v_field_24419;
        heff_drop(v_x_24421);
        V v_t_24422 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24423 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str86), heff_strAppend(v_t_24422, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str87)));
        return heff_strAppend(v_shown_242, v_t_24423);
      } else {
        heff_drop(v_field_24419);
        V v_t_24424 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str88), heff_strAppend(v_t_24424, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str89)));
        V v_d_24426 = heff_strAppend(v_shown_242, v_t_24425);
        V v_t_24427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24428 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24427; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24433;
        {
          V v_field_24430 = v_t_24428.f[1];
          int64_t v_tag_24429 = ((int64_t)v_t_24428.f[0]);
          if ((v_tag_24429 == ((int64_t)0ULL))) {
            V v_tf_24432 = v_field_24430;
            v_x2_24433 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24432));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24430);
            v_x2_24433 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24433)) {
        case TAG_Nothing: {
          return v_d_24426;
        }
        case TAG_Just: {
          V v_x_24434 = heff_field(v_x2_24433, 0);
          heff_take_n(v_x2_24433, 1ULL, 1);
          heff_drop(v_d_24426);
          return v_x_24434;
        }
        default: return heff_nomatch(v_x2_24433);
        }
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24437 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24439 = v_t_24437.f[1];
      int64_t v_tag_24438 = ((int64_t)v_t_24437.f[0]);
      if ((v_tag_24438 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 2);
        V v_x_24441 = v_field_24439;
        heff_drop(v_x_24441);
        V v_t_24442 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str90), heff_strAppend(v_t_24442, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str91)));
        return heff_strAppend(v_shown_242, v_t_24443);
      } else {
        heff_drop(v_field_24439);
        V v_t_24444 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24445 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str92), heff_strAppend(v_t_24444, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str93)));
        V v_d_24446 = heff_strAppend(v_shown_242, v_t_24445);
        V v_t_24447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24448 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24447; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24453;
        {
          V v_field_24450 = v_t_24448.f[1];
          int64_t v_tag_24449 = ((int64_t)v_t_24448.f[0]);
          if ((v_tag_24449 == ((int64_t)0ULL))) {
            V v_tf_24452 = v_field_24450;
            v_x2_24453 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24452));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24450);
            v_x2_24453 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24453)) {
        case TAG_Nothing: {
          return v_d_24446;
        }
        case TAG_Just: {
          V v_x_24454 = heff_field(v_x2_24453, 0);
          heff_take_n(v_x2_24453, 1ULL, 1);
          heff_drop(v_d_24446);
          return v_x_24454;
        }
        default: return heff_nomatch(v_x2_24453);
        }
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24456 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(heff_dup(v_body_244)));
    {
      V v_field_24458 = v_t_24456.f[1];
      int64_t v_tag_24457 = ((int64_t)v_t_24456.f[0]);
      if ((v_tag_24457 == ((int64_t)0ULL))) {
        heff_drop(v_name_241);
        heff_drop_tag(v_body_244, 1);
        V v_x_24460 = v_field_24458;
        heff_drop(v_x_24460);
        V v_t_24461 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
        V v_t_24462 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str94), heff_strAppend(v_t_24461, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str95)));
        return heff_strAppend(v_shown_242, v_t_24462);
      } else {
        heff_drop(v_field_24458);
        V v_t_24463 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_t_243)));
        V v_t_24464 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str96), heff_strAppend(v_t_24463, ((V)&g_heff_2esyntax_2esurfaceprint_2eprintSig_str97)));
        V v_d_24465 = heff_strAppend(v_shown_242, v_t_24464);
        V v_t_24466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
        HeffT2 v_t_24467 = ({ V a_0 = v_t_243; V a_1 = v_body_244; V a_2 = v_t_24466; V a_3 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
        V v_x2_24472;
        {
          V v_field_24469 = v_t_24467.f[1];
          int64_t v_tag_24468 = ((int64_t)v_t_24467.f[0]);
          if ((v_tag_24468 == ((int64_t)0ULL))) {
            V v_tf_24471 = v_field_24469;
            v_x2_24472 = (g_heff_2esyntax_2esurfaceprint_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24471));
          } else {
            heff_drop(v_im_240);
            heff_drop(v_name_241);
            heff_drop(v_field_24469);
            v_x2_24472 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_x2_24472)) {
        case TAG_Nothing: {
          return v_d_24465;
        }
        case TAG_Just: {
          V v_x_24473 = heff_field(v_x2_24472, 0);
          heff_take_n(v_x2_24472, 1ULL, 1);
          heff_drop(v_d_24465);
          return v_x_24473;
        }
        default: return heff_nomatch(v_x2_24472);
        }
      }
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}