// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_Done 47505
#define TAG_DoneOrErrno 39355
#define TAG_EQ 8989
#define TAG_ExplicitParam 63083
#define TAG_FromNone 27319
#define TAG_GT 9054
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Keep 49586
#define TAG_LT 9209
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkRegex 19093
#define TAG_MkSegment 38079
#define TAG_Plain 3036
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_branches 719731544
#define LBL_calls 295783919
#define LBL_current 1358797751
#define LBL_diags 296935042
#define LBL_doc 309170
#define LBL_e 319
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_filter 672649891
#define LBL_flows 298885407
#define LBL_group 299987609
#define LBL_holds 300818350
#define LBL_index 301704428
#define LBL_l 326
#define LBL_label 304085774
#define LBL_lams 9809570
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_n 328
#define LBL_name 9869138
#define LBL_outs 9918380
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_result 1012715336
#define LBL_short 310771862
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_style 311138763
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_values 1123329101
#define LBL_watch 314261737
static uint32_t shape_group__branches__current[] = {LBL_group, LBL_branches, LBL_current};
static uint32_t shape_n__flows__outs__calls__lams[] = {LBL_n, LBL_flows, LBL_outs, LBL_calls, LBL_lams};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2emonadic_2equiet(V);
V g_heff_2ecompile_2emonadic_2equiet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2equiet_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2eelab_2eclauses_2ebare(V);
V g_heff_2eelab_2eclauses_2ebare_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebare_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_list_2eall_24s1366771983x151845067(V);
V g_list_2eall_24s1366771983x151845067_entry(V self, V *a);
extern Clo g_list_2eall_24s1366771983x151845067_clo;
V g_list_2eall_24s1859111141x1565023045(V);
V g_list_2eall_24s1859111141x1565023045_entry(V self, V *a);
extern Clo g_list_2eall_24s1859111141x1565023045_clo;
V g_list_2eany_24s1266267134x726671983(V, V);
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a);
extern Clo g_list_2eany_24s1266267134x726671983_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s180477083x124477283(V, V);
V g_list_2eany_24s180477083x124477283_entry(V self, V *a);
extern Clo g_list_2eany_24s180477083x124477283_clo;
V g_list_2eany_24s357349853x1862456690(V, V);
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a);
extern Clo g_list_2eany_24s357349853x1862456690_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s52192015x78999897(V, V);
V g_list_2eany_24s52192015x78999897_entry(V self, V *a);
extern Clo g_list_2eany_24s52192015x78999897_clo;
V g_list_2eascending_24s1644543939x2049175771(V, V, V);
V g_list_2eascending_24s1644543939x2049175771_entry(V self, V *a);
extern Clo g_list_2eascending_24s1644543939x2049175771_clo;
V g_list_2ecollapse_24s1709454359x897477238(V, V, V, V);
V g_list_2ecollapse_24s1709454359x897477238_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1709454359x897477238_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2edescending_24s1947111851x612550467(V, V, V);
V g_list_2edescending_24s1947111851x612550467_entry(V self, V *a);
extern Clo g_list_2edescending_24s1947111851x612550467_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1221993074x1235215335(V, V, V);
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1221993074x1235215335_clo;
V g_list_2efoldl_24f2002190724x1241209655(V, V, V, V, V, V);
V g_list_2efoldl_24f2002190724x1241209655_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2002190724x1241209655_clo;
V g_list_2efoldl_24f2080327479x1330764413(V, V, V, V, V, V, V);
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2080327479x1330764413_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1242386649x1014712668_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s1242386649x1014712668_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1242386649x1014712668_24scalars_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1520027297x1040032870(V, V);
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1520027297x1040032870_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo;
V g_list_2ekeepIf_24f428638463x2144521938_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s1223034477x943356724(V);
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_clo;
V g_list_2ekeepIf_24s1223034477x943356724_24dps(V, V);
V g_list_2ekeepIf_24s1223034477x943356724_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_24dps_clo;
V g_list_2ekeepIf_24s1366776885x1474218589(V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_clo;
V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V, V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo;
V g_list_2ekeepIf_24s478006518x1380334353_24dps(V, V);
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo;
V g_list_2ekeepIf_24s741838803x941779121_24dps(V, V);
V g_list_2ekeepIf_24s741838803x941779121_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_24dps_clo;
V g_list_2ekeepIf_24s949876182x1887521458(V);
V g_list_2ekeepIf_24s949876182x1887521458_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s949876182x1887521458_clo;
V g_list_2ekeepIf_24s949876182x1887521458_24dps(V, V);
V g_list_2ekeepIf_24s949876182x1887521458_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s949876182x1887521458_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1050596570x1917004924(V, V, V);
V g_list_2emap_24f1050596570x1917004924_entry(V self, V *a);
extern Clo g_list_2emap_24f1050596570x1917004924_clo;
V g_list_2emap_24f1050596570x1917004924_24dps(V, V, V, V);
V g_list_2emap_24f1050596570x1917004924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1050596570x1917004924_24dps_clo;
V g_list_2emap_24f1632378148x1903828118_24dps(V, V, V);
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_24dps_clo;
V g_list_2emap_24f552182249x837938394(V, V);
V g_list_2emap_24f552182249x837938394_entry(V self, V *a);
extern Clo g_list_2emap_24f552182249x837938394_clo;
V g_list_2emap_24f552182249x837938394_24dps(V, V, V);
V g_list_2emap_24f552182249x837938394_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f552182249x837938394_24dps_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1007499915x73800978_24dps(V, V);
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_24dps_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1533895818x411093629_24dps(V, V);
V g_list_2emap_24s1533895818x411093629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_24dps_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1722943925x2063725971_24dps(V, V);
V g_list_2emap_24s1722943925x2063725971_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1722943925x2063725971_24dps_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1996604328x2084368959_24dps(V, V);
V g_list_2emap_24s1996604328x2084368959_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1996604328x2084368959_24dps_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s354283597x484250159_24dps(V, V, V);
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_24dps_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s456574265x331130481(V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_clo;
V g_list_2emap_24s456574265x331130481_24dps(V, V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_24dps_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s525732339x518706186_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s525732339x518706186_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s525732339x518706186_24dps_clo;
V g_list_2emap_24s698781565x943874959(V, V, V, V, V, V, V);
V g_list_2emap_24s698781565x943874959_entry(V self, V *a);
extern Clo g_list_2emap_24s698781565x943874959_clo;
V g_list_2emap_24s849938259x51049885(V);
V g_list_2emap_24s849938259x51049885_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_clo;
V g_list_2emap_24s849938259x51049885_24dps(V, V);
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1926973041x331495419(V, V);
V g_list_2emerge_24s1926973041x331495419_entry(V self, V *a);
extern Clo g_list_2emerge_24s1926973041x331495419_clo;
V g_list_2emerge_24s991540778x2011810329(V, V);
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_clo;
V g_list_2emerge_2emergeFrom_240(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_clo;
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_clo;
V g_list_2emergeRuns_24s1455886971x1742651599(V, V, V, V);
V g_list_2emergeRuns_24s1455886971x1742651599_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1455886971x1742651599_clo;
V g_list_2epushRun_24s1176929257x15617969(V, V, V);
V g_list_2epushRun_24s1176929257x15617969_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1176929257x15617969_clo;
V g_list_2epushRun_24s226385754x906688275(V, V, V, V, V);
V g_list_2epushRun_24s226385754x906688275_entry(V self, V *a);
extern Clo g_list_2epushRun_24s226385754x906688275_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2erunFrom_24s272018256x1228369023(V, V);
V g_list_2erunFrom_24s272018256x1228369023_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s272018256x1228369023_clo;
V g_list_2ezipWith_24s1737719962x691725464(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1737719962x691725464_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1737719962x691725464_clo;
V g_list_2ezipWith_24s1737719962x691725464_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1737719962x691725464_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1737719962x691725464_24dps_clo;
V g_list_2ezipWith_24s511663487x682582558_24dps(V, V, V, V, V);
V g_list_2ezipWith_24s511663487x682582558_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s511663487x682582558_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V, V);
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_regex_2eemit(V, V);
V g_regex_2eemit_entry(V self, V *a);
extern Clo g_regex_2eemit_clo;
HeffT3 g_regex_2ereadFrom_24cpr(V, V, V, V, V);
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_list_2econcatMap_lam0(V self, V *args);
Clo g_list_2econcatMap_clo = {{0x80000000u, K_CLO, 0}, g_list_2econcatMap_entry, 2, 0};

V g_list_2econcatMap(V v_f_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_list_2econcatMap_lam0, 2, 1, (V[]){v_f_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_list_2econcatMap_entry(V self, V *a) {
  (void)self;
  return g_list_2econcatMap(a[0], a[1]);
}
V g_list_2econcatMap_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_244}));
  return (g_prelude_2e_2b_2b(v_t_245, v_acc_243));
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    return (g_list_2emerge_2emergeFrom_240(v_le_240, NTAG(TAG_True), v_xs_241, v_ys_242));
  }
  case TAG_Cons: {
    V v_a_243 = heff_dup(heff_field(v_xs_241, 0));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_a_243);
      return (g_list_2emerge_2emergeFrom_240(v_le_240, NTAG(TAG_True), v_xs_241, v_ys_242));
    }
    case TAG_Cons: {
      V v_b_245 = heff_dup(heff_field(v_ys_242, 0));
      V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_a_243, v_b_245}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        return (g_list_2emerge_2emergeFrom_240(v_le_240, NTAG(TAG_True), v_xs_241, v_ys_242));
      } else {
        heff_drop(v_t_247);
        return (g_list_2emerge_2emergeFrom_240(v_le_240, NTAG(TAG_False), v_ys_242, v_xs_241));
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s366344330x1145113647_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_24dps_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_24dps_entry, 2, 0};

V g_list_2emap_24s1409451498x400757684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_x_242, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_242}), ((V)&g_list_2emap_24s1409451498x400757684_24dps_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1409451498x400757684_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1157931537x649184066_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_24dps_entry, 3, 0};

V g_list_2emap_24s1157931537x649184066_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2437;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_sp_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_ExplicitParam: {
        V v_x_249 = heff_field(v_x21_247, 0);
        V v_xsp_2410 = heff_field(v_x21_247, 1);
        V v_t_2411 = heff_field(v_x21_247, 2);
        V v_ru_24x21_247_24ExplicitParam = heff_take_reuse_n(v_x21_247, 7ULL, 3);
        V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_t_2411}));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_IsInferable: {
          V v_i_2413 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsInferable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2416;
          switch (heff_tag_of(v_i_2413)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_i_2413);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsInferable, TAG_TInf, 1, (V[]){v_i_2413}), v_t_2416});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2417 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsCheckable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2420;
          switch (heff_tag_of(v_c_2417)) {
          case TAG_At: {
            V v_s_2419 = heff_dup(heff_field(v_c_2417, 1));
            v_t_2420 = v_s_2419;
            break;
          }
          default: heff_nomatch(v_c_2417);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2417}), v_t_2420});
          break;
        }
        case TAG_IsType: {
          V v_t_2421 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2422 = v_t_2421;
          break;
        }
        default: heff_nomatch(v_x1_2412);
        }
        v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_247_24ExplicitParam, TAG_ExplicitParam, 3, 3ULL, (V[]){v_x_249, v_xsp_2410, v_t_2422}), v_sp_248});
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2423 = heff_field(v_x21_247, 0);
        V v_xsp_2424 = heff_field(v_x21_247, 1);
        V v_t_2425 = heff_field(v_x21_247, 2);
        V v_ru_24x21_247_24ImplicitParam = heff_take_reuse_n(v_x21_247, 7ULL, 3);
        V v_x1_2426 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_t_2425}));
        V v_t_2436;
        switch (heff_tag_of(v_x1_2426)) {
        case TAG_IsInferable: {
          V v_i_2427 = heff_field(v_x1_2426, 0);
          V v_ru_24x1_2426_24IsInferable = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
          V v_t_2430;
          switch (heff_tag_of(v_i_2427)) {
          case TAG_At: {
            V v_s_2429 = heff_dup(heff_field(v_i_2427, 1));
            v_t_2430 = v_s_2429;
            break;
          }
          default: heff_nomatch(v_i_2427);
          }
          v_t_2436 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2426_24IsInferable, TAG_TInf, 1, (V[]){v_i_2427}), v_t_2430});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2431 = heff_field(v_x1_2426, 0);
          V v_ru_24x1_2426_24IsCheckable = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
          V v_t_2434;
          switch (heff_tag_of(v_c_2431)) {
          case TAG_At: {
            V v_s_2433 = heff_dup(heff_field(v_c_2431, 1));
            v_t_2434 = v_s_2433;
            break;
          }
          default: heff_nomatch(v_c_2431);
          }
          v_t_2436 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2426_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2431}), v_t_2434});
          break;
        }
        case TAG_IsType: {
          V v_t_2435 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2436 = v_t_2435;
          break;
        }
        default: heff_nomatch(v_x1_2426);
        }
        v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_247_24ImplicitParam, TAG_ImplicitParam, 3, 3ULL, (V[]){v_x_2423, v_xsp_2424, v_t_2436}), v_sp_248});
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2438);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2439;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1157931537x649184066_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s205414595x1692305030_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_entry, 1, 0};

V g_list_2emap_24s205414595x1692305030(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2455;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x21_244, 0);
        V v_xsp_247 = heff_field(v_x21_244, 1);
        V v_t_248 = heff_field(v_x21_244, 2);
        V v_d_249 = heff_field(v_x21_244, 3);
        V v_ru_24x21_244_24DeclareField = heff_take_reuse_n(v_x21_244, 15ULL, 4);
        HeffT3 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_248));
        {
          V v_field_2412 = v_t_2410.f[1];
          V v_field_2413 = v_t_2410.f[2];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          V v_t_2423;
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_c_2414 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
            V v_t_2417;
            switch (heff_tag_of(v_c_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_c_2414);
            }
            v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
          } else {
            if ((v_tag_2411 == ((int64_t)1ULL))) {
              V v_i_2418 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
              V v_t_2421;
              switch (heff_tag_of(v_i_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_i_2418);
              }
              v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2418}), v_t_2421});
            } else {
              V v_t_2422 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
              v_t_2423 = v_t_2422;
            }
          }
          V v_t_2439;
          switch (heff_tag_of(v_d_249)) {
          case TAG_Nothing: {
            v_t_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x_2424 = heff_field(v_d_249, 0);
            V v_ru_24d_249_24Just = heff_take_reuse_n(v_d_249, 1ULL, 1);
            HeffT3 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2424));
            {
              V v_field_2427 = v_t_2425.f[1];
              V v_field_2428 = v_t_2425.f[2];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              V v_t_2438;
              if ((v_tag_2426 == ((int64_t)0ULL))) {
                V v_c_2429 = heff_tag_n(TAG_At, 2, (V[]){v_field_2427, v_field_2428});
                v_t_2438 = v_c_2429;
              } else {
                if ((v_tag_2426 == ((int64_t)1ULL))) {
                  V v_i_2430 = heff_tag_n(TAG_At, 2, (V[]){v_field_2427, v_field_2428});
                  V v_t_2433;
                  switch (heff_tag_of(v_i_2430)) {
                  case TAG_At: {
                    V v_s_2432 = heff_dup(heff_field(v_i_2430, 1));
                    v_t_2433 = v_s_2432;
                    break;
                  }
                  default: heff_nomatch(v_i_2430);
                  }
                  v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2430}), v_t_2433});
                } else {
                  V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){v_field_2427, v_field_2428});
                  V v_t_2437;
                  switch (heff_tag_of(v_t_2434)) {
                  case TAG_At: {
                    V v_s_2436 = heff_dup(heff_field(v_t_2434, 1));
                    v_t_2437 = v_s_2436;
                    break;
                  }
                  default: heff_nomatch(v_t_2434);
                  }
                  v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2434}), v_t_2437});
                }
              }
              v_t_2439 = heff_tag_at_n(v_ru_24d_249_24Just, TAG_Just, 1, (V[]){v_t_2438});
            }
            break;
          }
          default: heff_nomatch(v_d_249);
          }
          v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_244_24DeclareField, TAG_DeclareField, 4, 3ULL, (V[]){v_x_246, v_xsp_247, v_t_2423, v_t_2439}), v_sp_245});
        }
        break;
      }
      case TAG_BadFieldDecl: {
        V v_e_2440 = heff_field(v_x21_244, 0);
        V v_ru_24x21_244_24BadFieldDecl = heff_take_reuse_n(v_x21_244, 1ULL, 1);
        HeffT3 v_t_2441 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2440));
        {
          V v_field_2443 = v_t_2441.f[1];
          V v_field_2444 = v_t_2441.f[2];
          int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
          V v_t_2454;
          if ((v_tag_2442 == ((int64_t)0ULL))) {
            V v_c_2445 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2443, v_field_2444});
            V v_t_2448;
            switch (heff_tag_of(v_c_2445)) {
            case TAG_At: {
              V v_s_2447 = heff_dup(heff_field(v_c_2445, 1));
              v_t_2448 = v_s_2447;
              break;
            }
            default: heff_nomatch(v_c_2445);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2445}), v_t_2448});
          } else {
            if ((v_tag_2442 == ((int64_t)1ULL))) {
              V v_i_2449 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2443, v_field_2444});
              V v_t_2452;
              switch (heff_tag_of(v_i_2449)) {
              case TAG_At: {
                V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
                v_t_2452 = v_s_2451;
                break;
              }
              default: heff_nomatch(v_i_2449);
              }
              v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
            } else {
              V v_t_2453 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2443, v_field_2444});
              v_t_2454 = v_t_2453;
            }
          }
          v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_244_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2454}), v_sp_245});
        }
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2456 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2455, heff_hole()});
    V v_u_2457 = (g_list_2emap_24s205414595x1692305030_24dps(v_xs_242, v_cell_2456));
    heff_drop(v_u_2457);
    return v_cell_2456;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s205414595x1692305030(a[0]);
}
Clo g_list_2emap_24s1887874170x1747433177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_24dps_entry, 2, 0};

V g_list_2emap_24s1887874170x1747433177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT3 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_2417;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_248 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
          v_t_2411 = v_a_2410;
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_248}), v_t_2411});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_a_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
          V v_t_2415;
          switch (heff_tag_of(v_a_2412)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_2412, 1));
            v_t_2415 = v_a_2414;
            break;
          }
          default: heff_nomatch(v_a_2412);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_2412}), v_t_2415});
        } else {
          V v_a_2416 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
          v_t_2417 = v_a_2416;
        }
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2418);
      V t_0 = v_xs_243;
      V t_1 = v_u_2419;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1887874170x1747433177_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1230969749x2018313496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_24dps_entry, 2, 0};

V g_list_2emap_24s1230969749x2018313496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2423;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_MkAlt: {
        V v_p_247 = heff_field(v_x21_245, 0);
        V v_b_248 = heff_field(v_x21_245, 1);
        V v_ru_24x21_245_24MkAlt = heff_take_reuse_n(v_x21_245, 3ULL, 2);
        HeffT3 v_t_249 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          V v_t_2422;
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_c_2413 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
            v_t_2422 = v_c_2413;
          } else {
            if ((v_tag_2410 == ((int64_t)1ULL))) {
              V v_i_2414 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              V v_t_2417;
              switch (heff_tag_of(v_i_2414)) {
              case TAG_At: {
                V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
                v_t_2417 = v_s_2416;
                break;
              }
              default: heff_nomatch(v_i_2414);
              }
              v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
            } else {
              V v_t_2418 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              V v_t_2421;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
            }
          }
          v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_245_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_247, v_t_2422}), v_sp_246});
        }
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2424);
    V t_0 = v_xs_243;
    V t_1 = v_u_2425;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1230969749x2018313496_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1782778565x402128078_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_24dps_entry, 2, 0};

V g_list_2emap_24s1782778565x402128078_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_ru_24a_244_24MkEquation = heff_take_reuse_n(v_a_244, 15ULL, 4);
        V v_t_2413;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          V v_t_2412 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2410));
          v_t_2413 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2412, v_a_2411});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = heff_tag_re_n(v_ru_24a_244_24MkEquation, TAG_MkEquation, 4, 7ULL, (V[]){v_a_246, v_a_247, v_a_248, v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2416);
    V t_0 = v_xs_243;
    V t_1 = v_u_2417;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1782778565x402128078_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1859111141x1565023045_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1859111141x1565023045_entry, 1, 0};

V g_list_2eall_24s1859111141x1565023045(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2espec_2ecallsNothing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1859111141x1565023045_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1859111141x1565023045(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s378803910x892125795_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s378803910x892125795_entry, 1, 0};

V g_list_2eany_24s378803910x892125795(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s378803910x892125795_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s378803910x892125795(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s1266267134x726671983_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1266267134x726671983_entry, 2, 0};

V g_list_2eany_24s1266267134x726671983(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_lit_240, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_intEq_c_lent(v_x_242, v_t_246, 2)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1266267134x726671983(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1223034477x943356724_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1223034477x943356724_entry, 1, 0};

V g_list_2ekeepIf_24s1223034477x943356724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_245, 0ULL, 2);
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s1223034477x943356724_24dps(v_xs_242, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1223034477x943356724(a[0]);
}
Clo g_list_2ezipWith_24s870182194x1066240094_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_entry, 2, 0};

V g_list_2ezipWith_24s870182194x1066240094(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepF64: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepInt: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s870182194x1066240094_24dps(v_xs_243, v_ys_245, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1366776885x1474218589_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1366776885x1474218589_entry, 2, 0};

V g_list_2ekeepIf_24s1366776885x1474218589(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1366776885x1474218589_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1366776885x1474218589(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1242386649x1014712668_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1242386649x1014712668_24scalars_entry, 6, 0};

V g_list_2efoldl_24s1242386649x1014712668_24scalars(V v_n_240, V v_flows_241, V v_outs_242, V v_calls_243, V v_lams_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    return heff_rec_n(5, shape_n__flows__outs__calls__lams, (V[]){v_n_240, v_flows_241, v_outs_242, v_calls_243, v_lams_244});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_ru_24x3_245_24Cons = heff_take_reuse_n(v_x3_245, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), v_x_246});
    V t_0 = v_n_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_245_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_flows_241});
    V t_2 = v_outs_242;
    V t_3 = v_calls_243;
    V t_4 = v_lams_244;
    V t_5 = v_xs_247;
    v_n_240 = t_0;
    v_flows_241 = t_1;
    v_outs_242 = t_2;
    v_calls_243 = t_3;
    v_lams_244 = t_4;
    v_x3_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s1242386649x1014712668_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1242386649x1014712668_24scalars(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str2, 12, "(A.fromList ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str3, 1, ")");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str4, 8, "(MkPair ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_24dps_str6, 1, ")");
Clo g_list_2emap_24s525732339x518706186_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s525732339x518706186_24dps_entry, 8, 0};

V g_list_2emap_24s525732339x518706186_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_x2_2413 = v_a_2411;
      V v_t_2422;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_xs_2414 = heff_field(v_x2_2413, 0);
        V v_b_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_xs_2416 = (g_list_2emap_24s1397747289x2145601499(heff_arrayToList(v_xs_2414)));
        V v_t_2417 = ({ V a_0 = v_xs_2416; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2416); r_; });
        V v_t_2418 = ({ V a_0 = v_b_2415; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_b_2415); r_; });
        V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_24dps_str0), v_t_2417), ((V)&g_list_2emap_24s525732339x518706186_24dps_str1));
        V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_24dps_str2), v_t_2419), ((V)&g_list_2emap_24s525732339x518706186_24dps_str3));
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_24dps_str4), v_t_2420), ((V)&g_list_2emap_24s525732339x518706186_24dps_str5));
        v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2418), ((V)&g_list_2emap_24s525732339x518706186_24dps_str6));
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_t_2423 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_243));
      V v_t_2424 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2423), heff_dup(v_lit_244));
      v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_t_2422), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2426);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_u_2427;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s525732339x518706186_24dps_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_list_2emap_24s525732339x518706186_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
Clo g_list_2eany_24s52192015x78999897_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s52192015x78999897_entry, 2, 0};

V g_list_2eany_24s52192015x78999897(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s52192015x78999897_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s52192015x78999897(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1366771983x151845067_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1366771983x151845067_entry, 1, 0};

V g_list_2eall_24s1366771983x151845067(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2emonadic_2equiet(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1366771983x151845067_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1366771983x151845067(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s511663487x682582558_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s511663487x682582558_24dps_entry, 5, 0};

V g_list_2ezipWith_24s511663487x682582558_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_x3_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_243, 0);
      V v_ys_248 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_t_249;
      if (heff_intEq_c_lent(v_x_245, v_lit_240, 1)) {
        heff_drop(v_y_247);
        v_t_249 = heff_dup(v_lit_241);
      } else {
        v_t_249 = v_y_247;
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_246;
      V t_3 = v_ys_248;
      V t_4 = v_u_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ezipWith_24s511663487x682582558_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2ezipWith_24s511663487x682582558_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24s456574265x331130481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456574265x331130481_entry, 5, 0};

V g_list_2emap_24s456574265x331130481(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_247 = (g_prelude_2esplit_2esplitFrom_240(v_x_245, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_245, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_247));
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      v_t_2411 = v_x_245;
      break;
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_248, 0);
      heff_take_n(v_a_248, 1ULL, 2);
      heff_drop(v_x_245);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    V v_t_2412 = (g_heff_2ecompile_2eemit_2esafe(v_t_2411));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s456574265x331130481_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, v_cell_2413));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s456574265x331130481_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s456574265x331130481(a0, a[1], a2, a3, a[4]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s391931963x434308123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_24dps_entry, 2, 0};

V g_list_2emap_24s391931963x434308123_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s391931963x434308123_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s949876182x1887521458_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s949876182x1887521458_entry, 1, 0};

V g_list_2ekeepIf_24s949876182x1887521458(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_246 = heff_bool(heff_strEq_c(heff_dup(v_a_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      heff_drop(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if (!(heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s949876182x1887521458_24dps(v_xs_242, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s949876182x1887521458_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s949876182x1887521458(a[0]);
}
Clo g_list_2ezipWith_24s1737719962x691725464_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1737719962x691725464_entry, 9, 0};

V g_list_2ezipWith_24s1737719962x691725464(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2413));
      V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, heff_dup(v_lit_245)), heff_intShow(v_y_2411));
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
      V v_u_2417 = (g_list_2ezipWith_24s1737719962x691725464_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, v_cell_2416));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s1737719962x691725464_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1737719962x691725464(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1275294336x693095586_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_24dps_entry, 3, 0};

V g_list_2emap_24s1275294336x693095586_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_es_245 = heff_dup(v_lit_240);
    V v_e_246 = v_x_243;
    V v_t_2494;
    switch (heff_tag_of(v_e_246)) {
    case TAG_RLocal: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RDup: {
      V v_x_248 = heff_field(v_e_246, 0);
      V v_ru_24e_246_24RDup = heff_take_reuse_n(v_e_246, 1ULL, 1);
      V v_x1_249 = ({ V a_0 = heff_dup(v_x_248); V a_1 = v_es_245; V r_ = (g_list_2eany_24s357349853x1862456690(a_0, a_1)); heff_drop(v_es_245); r_; });
      if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24e_246_24RDup, 1);
        heff_drop(v_x1_249);
        v_t_2494 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_248});
      } else {
        heff_drop(v_x1_249);
        v_t_2494 = heff_tag_re_n(v_ru_24e_246_24RDup, TAG_RDup, 1, 1ULL, (V[]){v_x_248});
      }
      break;
    }
    case TAG_RClo: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RGet: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RGetRaw: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RInt: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RFloat: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RStr: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RBytes: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RFixed: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RF32: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RNTag: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RStatic: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RTag: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RTagIn: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RRec: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RRecIn: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RField: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RDupE: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RFieldV: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RGetN: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RFieldU: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RGetNU: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RWord: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RTakeField: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RGetLabel: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RPrimFn: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RPrim: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RLam: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RCall: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RApply: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RBool: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RAbandon: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RBox: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RUnbox: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RPeek: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RPrimU: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RPrimAt: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RFixU: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RF32U: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    case TAG_RF64U: {
      heff_drop(v_es_245);
      v_t_2494 = v_e_246;
      break;
    }
    default: heff_nomatch(v_e_246);
    }
    V v_cell_2495 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2494, heff_hole()});
    V v_u_2496 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2495);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2496;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1275294336x693095586_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1520027297x1040032870_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1520027297x1040032870_entry, 2, 0};

V g_list_2efoldl_24s1520027297x1040032870(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_result_244 = heff_take_field(v_x_242, 3);
    V v_args_245 = heff_get_n(v_x_242, 2, 5);
    V v_t_246 = v_result_244;
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Gives: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivesOrErrno: {
      V v_a_248 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DoneOrErrno: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_z_240, v_args_245, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1520027297x1040032870(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s478006518x1380334353_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s478006518x1380334353_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = ({ V a_0 = v_x_242; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_244) == NTAG(TAG_True))) {
      heff_drop(v_a_244);
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s478006518x1380334353_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1722943925x2063725971_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1722943925x2063725971_24dps_entry, 2, 0};

V g_list_2emap_24s1722943925x2063725971_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eclauses_2ebare(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1722943925x2063725971_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1722943925x2063725971_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s467798769x1763085075_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_24dps_entry, 2, 0};

V g_list_2emap_24s467798769x1763085075_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s467798769x1763085075_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s18996220x10511024_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_24dps_entry, 2, 0};

V g_list_2emap_24s18996220x10511024_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_path_245 = heff_get_n(v_x_242, 1, 3);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_244, v_path_245}), heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s18996220x10511024_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s180477083x124477283_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s180477083x124477283_entry, 2, 0};

V g_list_2eany_24s180477083x124477283(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s180477083x124477283_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s180477083x124477283(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1476602679x302842688_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1476602679x302842688_entry, 2, 0};

V g_list_2efoldl_24s1476602679x302842688(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_246)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1476602679x302842688(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s478414341x1543613922_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s478414341x1543613922_entry, 2, 0};

V g_list_2efoldl_24s478414341x1543613922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s478414341x1543613922(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2epushRun_24s1176929257x15617969_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s1176929257x15617969_entry, 3, 0};

V g_list_2epushRun_24s1176929257x15617969(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_247 = (g_list_2emerge_24s991540778x2011810329(v_below_246, v_run_241));
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_247;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_248 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_248});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s1176929257x15617969_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s1176929257x15617969(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1996604328x2084368959_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1996604328x2084368959_24dps_entry, 2, 0};

V g_list_2emap_24s1996604328x2084368959_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_k_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_k_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x2_2410 = heff_get_n(v_t_249, 0, 4);
    V v_t_2446;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_SLocal: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x2_2410, 0ULL, 3);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      V v_ru_24x2_2410_24SPrim = heff_take_reuse_n(v_x2_2410, 0ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24x2_2410_24SPrim, TAG_Just, 1, (V[]){v_k_246});
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x2_2410, 0ULL, 3);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x2_2410, 0ULL, 2);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x2_2410, 0ULL, 1);
      heff_drop(v_k_246);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_cell_2447 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2446, heff_hole()});
    V v_u_2448 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2447);
    V t_0 = v_xs_243;
    V t_1 = v_u_2448;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1996604328x2084368959_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1996604328x2084368959_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emergeRuns_24s1455886971x1742651599_lam0(V self, V *args);
Clo g_list_2emergeRuns_24s1455886971x1742651599_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1455886971x1742651599_entry, 4, 0};

V g_list_2emergeRuns_24s1455886971x1742651599(V v_lit_240, V v_lit_241, V v_stack_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_run_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_run_244; V a_3 = v_stack_242; V r_ = (g_list_2ecollapse_24s1709454359x897477238(a_0, a_1, a_2, a_3)); heff_drop(v_stack_242); r_; });
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x32_245, 0);
      V v_xs_247 = heff_field(v_x32_245, 1);
      heff_take_n(v_x32_245, 3ULL, 2);
      V v_t_248 = (g_list_2epushRun_24s226385754x906688275(heff_dup(v_lit_240), heff_dup(v_lit_241), MK_INT(0LL), v_run_244, v_stack_242));
      V v_t_2412 = (g_list_2erunFrom(heff_clo_n(g_list_2emergeRuns_24s1455886971x1742651599_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_x_246, v_xs_247));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_248;
      V t_3 = v_t_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_stack_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2emergeRuns_24s1455886971x1742651599_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1455886971x1742651599(a[0], a[1], a[2], a[3]);
}
V g_list_2emergeRuns_24s1455886971x1742651599_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_a_2411 = heff_strCompare(heff_get_n(v_a_249, 0, 2), heff_get_n(v_a_2410, 0, 2));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(self);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
HEFF_LIT(g_list_2emap_24s354283597x484250159_str0, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str5, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str6, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str7, 8, "(variant");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str8, 1, ")");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str9, 1, " ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str10, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str11, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str12, 4, "(bad");
HEFF_LIT(g_list_2emap_24s354283597x484250159_str13, 1, ")");
Clo g_list_2emap_24s354283597x484250159_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s354283597x484250159_entry, 2, 0};

V g_list_2emap_24s354283597x484250159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2429;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_TagVariant: {
        V v_t_248 = heff_field(v_x21_246, 0);
        V v_args_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 5ULL, 3);
        V v_x2_2411 = (g_list_2emap(heff_get_n(v_r_244, 0, 2), v_args_2410));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_list_2emap_24s354283597x484250159_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_str2), v_t_2414), ((V)&g_list_2emap_24s354283597x484250159_str3));
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_parts_2417 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_t_248, v_t_2416});
        V v_x2_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s354283597x484250159_str4), v_parts_2417));
        V v_t_2421;
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_Nil: {
          v_t_2421 = ((V)&g_list_2emap_24s354283597x484250159_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_xs_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          v_t_2421 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2418);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_str7), v_t_2421), ((V)&g_list_2emap_24s354283597x484250159_str8));
        break;
      }
      case TAG_BadVariant: {
        V v_e_2422 = heff_field(v_x21_246, 0);
        heff_take_n(v_x21_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2422}));
        V v_parts_2424 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
        V v_x2_2425 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s354283597x484250159_str9), v_parts_2424));
        V v_t_2428;
        switch (heff_tag_of(v_x2_2425)) {
        case TAG_Nil: {
          v_t_2428 = ((V)&g_list_2emap_24s354283597x484250159_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_x2_2425, 0);
          V v_xs_2427 = heff_field(v_x2_2425, 1);
          heff_take_n(v_x2_2425, 3ULL, 2);
          v_t_2428 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_str11); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2425);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_str12), v_t_2428), ((V)&g_list_2emap_24s354283597x484250159_str13));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = (g_list_2emap_24s354283597x484250159_24dps(v_lit_240, v_xs_243, v_cell_2430));
    heff_drop(v_u_2431);
    return v_cell_2430;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s354283597x484250159_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s354283597x484250159(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str7, 9, "(equation");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_24dps_str8, 1, ")");
Clo g_list_2emap_24s1055307687x247454614_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_24dps_entry, 3, 0};

V g_list_2emap_24s1055307687x247454614_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2425;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_MkEquation: {
        V v_g_249 = heff_field(v_x21_247, 0);
        V v_ps_2411 = heff_field(v_x21_247, 2);
        V v_rhs_2412 = heff_field(v_x21_247, 3);
        heff_take_n(v_x21_247, 13ULL, 4);
        V v_x2_2413 = (g_list_2emap_24s1561756891x1126436879(v_ps_2411));
        V v_t_2416;
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nil: {
          v_t_2416 = ((V)&g_list_2emap_24s1055307687x247454614_24dps_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_xs_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          v_t_2416 = ({ V a_0 = ((V)&g_list_2emap_24s1055307687x247454614_24dps_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2413);
        }
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_rhs_2412}));
        V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1055307687x247454614_24dps_str2), v_t_2416), ((V)&g_list_2emap_24s1055307687x247454614_24dps_str3));
        V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_parts_2420 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_g_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2419})});
        V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1055307687x247454614_24dps_str4), v_parts_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_list_2emap_24s1055307687x247454614_24dps_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_list_2emap_24s1055307687x247454614_24dps_str6); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1055307687x247454614_24dps_str7), v_t_2424), ((V)&g_list_2emap_24s1055307687x247454614_24dps_str8));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2426);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2427;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1055307687x247454614_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1740858080x874135214_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1740858080x874135214_entry, 1, 0};

V g_list_2eany_24s1740858080x874135214(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_x_241, 6))));
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1740858080x874135214(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s130813166x1111413304_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s130813166x1111413304_entry, 2, 0};

V g_list_2eany_24s130813166x1111413304(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s130813166x1111413304(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s977936796x564903144_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s977936796x564903144_entry, 4, 0};

V g_list_2efoldl_24s977936796x564903144(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_list_2efoldl_24f2094160282x1876485468(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 6)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_246);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s977936796x564903144(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1007499915x73800978_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1007499915x73800978_entry, 1, 0};

V g_list_2emap_24s1007499915x73800978(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_p_243 = v_x_241;
    V v_t_244 = heff_rec_n(3, shape_group__branches__current, (V[]){MK_INT(-1LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    HeffT3 v_t_245 = (g_regex_2ereadFrom_24cpr(v_p_243, MK_INT(0LL), MK_INT(0LL), v_t_244, NTAG(TAG_Nil)));
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2418;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_field_248);
        V v_why_249 = v_field_247;
        v_t_2418 = heff_tag_n(TAG_Left, 1, (V[]){v_why_249});
      } else {
        V v_node_2410 = v_field_247;
        V v_groups_2411 = v_field_248;
        V v_t_2412 = (g_regex_2eemit(v_node_2410, MK_INT(1LL)));
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Done), NTAG(TAG_Nil)});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Keep, 1, (V[]){MK_INT(1LL)}), v_t_2413});
        V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Keep, 1, (V[]){MK_INT(0LL)}), v_t_2415});
        V v_t_2417 = heff_tag_n(TAG_MkRegex, 2, (V[]){heff_arrayFromList(v_t_2416), v_groups_2411});
        v_t_2418 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2417});
      }
      V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
      V v_u_2420 = (g_list_2emap_24s1007499915x73800978_24dps(v_xs_242, v_cell_2419));
      heff_drop(v_u_2420);
      return v_cell_2419;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1007499915x73800978(a[0]);
}
Clo g_list_2ekeepIf_24s741838803x941779121_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s741838803x941779121_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s741838803x941779121_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 6, 10);
    if (!(heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s741838803x941779121_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s741838803x941779121_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1926973041x331495419_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1926973041x331495419_entry, 2, 0};

V g_list_2emerge_24s1926973041x331495419(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(NTAG(TAG_True), v_xs_240, v_ys_241));
  }
  case TAG_Cons: {
    V v_a_242 = heff_dup(heff_field(v_xs_240, 0));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_242, 4);
      return (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(NTAG(TAG_True), v_xs_240, v_ys_241));
    }
    case TAG_Cons: {
      V v_b_244 = heff_dup(heff_field(v_ys_241, 0));
      V v_a_246 = ({ V b_0 = heff_get_n(v_a_242, 1, 4); V b_1 = heff_get_n(v_b_244, 1, 4); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_a_246)) {
      case TAG_LT: {
        return (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(NTAG(TAG_True), v_xs_240, v_ys_241));
      }
      case TAG_EQ: {
        return (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(NTAG(TAG_True), v_xs_240, v_ys_241));
      }
      case TAG_GT: {
        return (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(NTAG(TAG_False), v_ys_241, v_xs_240));
      }
      default: return heff_nomatch(v_a_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1926973041x331495419_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1926973041x331495419(a[0], a[1]);
}
Clo g_list_2erunFrom_24s272018256x1228369023_clo = {{0x80000000u, K_CLO, 0}, g_list_2erunFrom_24s272018256x1228369023_entry, 2, 0};

V g_list_2erunFrom_24s272018256x1228369023(V v_x_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_240, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_241, 0);
    V v_ys_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_245 = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(heff_rfield(v_x_240, 1), heff_rfield(v_y_243, 1)));
    switch (heff_tag_of(v_a_245)) {
    case TAG_LT: {
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_240, NTAG(TAG_Nil)});
      return (g_list_2eascending_24s1644543939x2049175771(heff_dup(v_y_243), heff_tag_n(TAG_Cons, 2, (V[]){v_y_243, v_t_246}), v_ys_244));
    }
    case TAG_EQ: {
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_240, NTAG(TAG_Nil)});
      return (g_list_2eascending_24s1644543939x2049175771(heff_dup(v_y_243), heff_tag_n(TAG_Cons, 2, (V[]){v_y_243, v_t_247}), v_ys_244));
    }
    case TAG_GT: {
      V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_240, NTAG(TAG_Nil)});
      return (g_list_2edescending_24s1947111851x612550467(heff_dup(v_y_243), heff_tag_n(TAG_Cons, 2, (V[]){v_y_243, v_t_248}), v_ys_244));
    }
    default: return heff_nomatch(v_a_245);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2erunFrom_24s272018256x1228369023_entry(V self, V *a) {
  (void)self;
  return g_list_2erunFrom_24s272018256x1228369023(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s849938259x51049885_str0, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str1, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str2, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str3, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str4, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str5, 0, "");
Clo g_list_2emap_24s849938259x51049885_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s849938259x51049885_entry, 1, 0};

V g_list_2emap_24s849938259x51049885(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JArray: {
      V v_ns_247 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = (g_list_2emap_24s698781565x943874959(((V)&g_list_2emap_24s849938259x51049885_str0), ((V)&g_list_2emap_24s849938259x51049885_str1), ((V)&g_list_2emap_24s849938259x51049885_str2), ((V)&g_list_2emap_24s849938259x51049885_str3), ((V)&g_list_2emap_24s849938259x51049885_str4), ((V)&g_list_2emap_24s849938259x51049885_str5), v_ns_247));
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s849938259x51049885_24dps(v_xs_242, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s849938259x51049885_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s849938259x51049885(a[0]);
}
Clo g_list_2emap_24s1533895818x411093629_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1533895818x411093629_24dps_entry, 2, 0};

V g_list_2emap_24s1533895818x411093629_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2elean(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1533895818x411093629_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1533895818x411093629_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str1, 4, "    ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str2, 1, "-");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str3, 2, ", ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str6, 1, "=");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str7, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str8, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str9, 2, ", ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str10, 2, " (");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str11, 1, ")");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_str12, 2, "--");
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_243 = v_x_241;
    V v_short_244 = heff_take_field(v_f_243, 1);
    V v_meta_245 = heff_take_field(v_f_243, 2);
    V v_values_246 = heff_take_field(v_f_243, 4);
    V v_long_247 = heff_take_field(v_f_243, 0);
    V v_doc_248 = heff_get_n(v_f_243, 3, 8);
    V v_t_249;
    if (heff_strEq_c_lent(v_short_244, ((V)&g_list_2emap_24s1753874608x910016727_str0), 2)) {
      heff_drop(v_short_244);
      v_t_249 = ((V)&g_list_2emap_24s1753874608x910016727_str1);
    } else {
      v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_str2), v_short_244), ((V)&g_list_2emap_24s1753874608x910016727_str3));
    }
    V v_t_2410;
    if (heff_strEq_c_lent(v_meta_245, ((V)&g_list_2emap_24s1753874608x910016727_str4), 2)) {
      heff_drop(v_meta_245);
      v_t_2410 = ((V)&g_list_2emap_24s1753874608x910016727_str5);
    } else {
      v_t_2410 = heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_str6), v_meta_245);
    }
    V v_t_2411 = heff_dup(v_values_246);
    V v_t_2418;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      heff_drop(v_values_246);
      v_t_2418 = ((V)&g_list_2emap_24s1753874608x910016727_str7);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2411, 0ULL, 2);
      V v_t_2414 = v_values_246;
      V v_t_2417;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_list_2emap_24s1753874608x910016727_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_t_2414, 0);
        V v_xs_2416 = heff_field(v_t_2414, 1);
        heff_take_n(v_t_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_list_2emap_24s1753874608x910016727_str9); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_str10), v_t_2417), ((V)&g_list_2emap_24s1753874608x910016727_str11));
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_list_2emap_24s1753874608x910016727_str12)), v_long_247);
    V v_t_2420 = (g_std_2ecli_2eline2(heff_strAppend(v_t_2419, v_t_2410), heff_strAppend(v_doc_248, v_t_2418)));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = (g_list_2emap_24s1753874608x910016727_24dps(v_xs_242, v_cell_2421));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f428638463x2144521938_24dps_entry, 5, 0};

V g_list_2ekeepIf_24f428638463x2144521938_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_243, 0);
    V v_xs_246 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      if (!heff_strEq_c_lent(heff_strSlice_lent(v_x_247, v_lit_240, v_lit_241, 0), v_lit_242, 1)) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_248);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_u_249;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_247);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2ekeepIf_24f428638463x2144521938_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2emap_24f1632378148x1903828118_24dps_str0, 13, "static Clo g_");
Clo g_list_2emap_24f1632378148x1903828118_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1632378148x1903828118_24dps_entry, 3, 0};

V g_list_2emap_24f1632378148x1903828118_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_243, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f1632378148x1903828118_24dps_str0))) {
      V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength(v_x_243));
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24f1632378148x1903828118_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f2080327479x1330764413_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2080327479x1330764413_entry, 7, 0};

V g_list_2efoldl_24f2080327479x1330764413(V v_z_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24a_245, V v_box_24b_246) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_a_245 = heff_unbox_word(v_box_24a_245);
  int64_t v_b_246 = heff_unbox_word(v_box_24b_246);
top: ;
  if ((v_b_246 < v_a_245)) {
    return v_z_240;
  } else {
    if (((v_a_245 == v_lit_241) || (heff_unbox_word(heff_strByteAt_lent(v_lit_242, heff_box_word((v_a_245 - v_lit_243)), 2)) == v_lit_244))) {
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_a_245), v_z_240});
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
      int64_t t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    } else {
      V t_0 = v_z_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
      int64_t t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    }
  }
}
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2080327479x1330764413(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1050596570x1917004924_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1050596570x1917004924_entry, 3, 0};

V g_list_2emap_24f1050596570x1917004924(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_module_245 = heff_take_field(v_x_243, 0);
    V v_alias_246 = heff_get_n(v_x_243, 1, 2);
    if (heff_strEq_c_lent(v_module_245, v_lit_241, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_alias_246, heff_dup(v_lit_240)), heff_hole()});
      V v_u_248 = (g_list_2emap_24f1050596570x1917004924_24dps(v_lit_240, v_lit_241, v_xs_244, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_alias_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1050596570x1917004924_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f1050596570x1917004924(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1221993074x1235215335_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1221993074x1235215335_entry, 3, 0};

V g_list_2efoldl_24f1221993074x1235215335(V v_z_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_243, v_lit_241, 0)) {
      V t_0 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_z_240});
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1221993074x1235215335(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry, 8, 0};

V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = heff_strSlice_lent(v_lit_242, v_lit_243, heff_intAdd_lent(v_lit_244, v_lit_245, 0), 4);
    V v_x_2411 = heff_strAppend(v_t_2410, v_x_248);
    V v_t_2412 = heff_strSlice_lent(v_x_2411, v_lit_240, heff_strLength_lent(v_lit_241, 0), 4);
    if (heff_strEq_c_lent(v_t_2412, v_lit_241, 1)) {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_u_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a7 = a[7]; V r = g_list_2ekeepIf_24f1278780364x1365377410_24dps(a0, a1, a2, a3, a[4], a[5], a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24f2002190724x1241209655_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2002190724x1241209655_entry, 6, 0};

V g_list_2efoldl_24f2002190724x1241209655(V v_lit_240, V v_z_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop_rec(v_lit_243, 8);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_243, 2)), 0, 2);
    V v_t_249 = heff_strFind(heff_strOfRunes(v_t_248), heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_242, v_t_249, 2)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efoldl_24f2002190724x1241209655_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_list_2efoldl_24f2002190724x1241209655(a[0], a[1], a[2], a[3], a4, a5); heff_drop(a4); heff_drop(a5); return r;
}
Clo g_list_2emap_24f552182249x837938394_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f552182249x837938394_entry, 2, 0};

V g_list_2emap_24f552182249x837938394(V v_box_24n_240, V v_x2_241) {
  int64_t v_n_240 = heff_unbox_word(v_box_24n_240);
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((v_n_240 <= ((int64_t)0ULL))) {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_x_242, NTAG(TAG_Plain)});
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f552182249x837938394_24dps(heff_box_word((v_n_240 - ((int64_t)1ULL))), v_xs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f552182249x837938394_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f552182249x837938394(a[0], a[1]);
}