// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_start 311115900
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_str0, 5, "given");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_str1, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(V v_sp_240, V v_ys_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_241));
  V v_what_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_str0), heff_intShow(v_t_242));
  V v_t_244 = heff_intShow(heff_get_n(v_sp_240, 0, 2));
  return heff_strAppend(v_what_243, heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_str1), v_t_244));
}
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_str0, 5, "given");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_str1, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(V v_sp_240, V v_ys_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_241));
  V v_what_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_str0), heff_intShow(v_t_242));
  V v_t_244 = heff_intShow(heff_get_n(v_sp_240, 0, 2));
  return heff_strAppend(v_what_243, heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_str1), v_t_244));
}
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(a[0], a1); heff_drop(a1); return r;
}