// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_end 310101
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2efmt_2eimports_2eallNameC(V, V);
V g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eallNameC_clo;
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(V);
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_clo;
V g_heff_2esyntax_2efmt_2eimports_2eimportWords(V);
V g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eimportWords_clo;
V g_heff_2esyntax_2efmt_2eimports_2eisAlias(V);
V g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eisAlias_clo;
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(V, V);
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_clo;
V g_heff_2esyntax_2efmt_2eimports_2enameC(V);
V g_heff_2esyntax_2efmt_2eimports_2enameC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2enameC_clo;
V g_heff_2esyntax_2efmt_2eimports_2eoneImport(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2eoneImport_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eoneImport_clo;
V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(V, V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_clo;
V g_list_2efilter_24s1564977489x772952072(V, V);
V g_list_2efilter_24s1564977489x772952072_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    return v_i_241;
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(10LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2eimports_2enameC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2enameC_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2enameC(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2eimports_2enameC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2enameC(a[0]);
}
Clo g_heff_2esyntax_2efmt_2eimports_2eallNameC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2eallNameC(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2esyntax_2efmt_2eimports_2enameC(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2eallNameC(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eisAlias_str0, 1, ".");
Clo g_heff_2esyntax_2efmt_2eimports_2eisAlias_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eisAlias(V v_x_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0))) {
    if (heff_intLe_c(MK_INT(65LL), heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) {
      if (heff_intLe_c(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2), MK_INT(90LL))) {
        if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2eimports_2eisAlias_str0), v_x_240, MK_INT(0LL), 5))) {
          heff_drop(v_x_240);
          return NTAG(TAG_False);
        } else {
          if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0))) {
            return (g_heff_2esyntax_2efmt_2eimports_2eallNameC(v_x_240, MK_INT(0LL)));
          } else {
            heff_drop(v_x_240);
            return NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2eisAlias(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_str0);
  } else {
    V v_s_242 = ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_str1);
    return (g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_242));
  }
}
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2espacesOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str0));
  } else {
    V v_s_243 = heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_243;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eimportWords_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eimportWords_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2eimportWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eimportWords(V v_rest_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(heff_dup(v_rest_240), MK_INT(0LL), MK_INT(1LL)));
  V v_t_242 = heff_intSub(heff_strLength_lent(v_rest_240, 0), MK_INT(1LL));
  V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_rest_240), v_t_242, MK_INT(-1LL)));
  V v_s_244 = heff_strSlice(v_rest_240, v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2eimports_2eimportWords_str0), heff_dup(v_s_244), MK_INT(0LL), heff_strFind(((V)&g_heff_2esyntax_2efmt_2eimports_2eimportWords_str1), v_s_244, MK_INT(0LL)), NTAG(TAG_Nil)));
  return (g_list_2efilter_24s1564977489x772952072(MK_INT(0LL), v_t_245));
}
V g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2eimportWords(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eoneImport_str0, 2, "as");
Clo g_heff_2esyntax_2efmt_2eimports_2eoneImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eoneImport_entry, 3, 0};

V g_heff_2esyntax_2efmt_2eimports_2eoneImport(V v_i_240, V v_e_241, V v_ws_242) {
top: ;
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_e_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_ws_242, 0);
    V v_ws2_244 = heff_field(v_ws_242, 1);
    switch (heff_tag_of(v_ws2_244)) {
    case TAG_Nil: {
      if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_m_243, 0))) {
        V v_t_246 = (g_heff_2esyntax_2efmt_2eimports_2eallNameC(heff_dup(v_m_243), MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_t_247 = heff_rec_n(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
        } else {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_t_246);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_Cons: {
      V v_kw_248 = heff_field(v_ws2_244, 0);
      V v_ws22_249 = heff_field(v_ws2_244, 1);
      switch (heff_tag_of(v_ws22_249)) {
      case TAG_Nil: {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_a_2410 = heff_field(v_ws22_249, 0);
        V v_ws222_2411 = heff_field(v_ws22_249, 1);
        switch (heff_tag_of(v_ws222_2411)) {
        case TAG_Nil: {
          if (heff_strEq_c_lent(v_kw_248, ((V)&g_heff_2esyntax_2efmt_2eimports_2eoneImport_str0), 2)) {
            if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_m_243, 0))) {
              V v_t_2414 = (g_heff_2esyntax_2efmt_2eimports_2eallNameC(heff_dup(v_m_243), MK_INT(0LL)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_t_2414);
                V v_t_2415 = (g_heff_2esyntax_2efmt_2eimports_2eisAlias(heff_dup(v_a_2410)));
                if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                  heff_drop(v_t_2415);
                  V v_t_2416 = heff_rec_n(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2410)}), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
                } else {
                  heff_drop(v_i_240);
                  heff_drop(v_e_241);
                  heff_drop(v_t_2415);
                  return NTAG(TAG_Nothing);
                }
              } else {
                heff_drop(v_i_240);
                heff_drop(v_e_241);
                heff_drop(v_t_2414);
                return NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_i_240);
              heff_drop(v_e_241);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_i_240);
            heff_drop(v_e_241);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_ws222_2411);
        }
      }
      default: return heff_nomatch(v_ws22_249);
      }
    }
    default: return heff_nomatch(v_ws2_244);
    }
  }
  default: return heff_nomatch(v_ws_242);
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eoneImport_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2eimports_2eoneImport(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_str0, 2, "--");
Clo g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(V v_line_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(heff_dup(v_line_240), MK_INT(0LL), MK_INT(1LL)));
  V v_t_242 = heff_intSub(heff_strLength_lent(v_line_240, 0), MK_INT(1LL));
  V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_line_240), v_t_242, MK_INT(-1LL)));
  V v_t_244 = heff_strSlice(heff_dup(v_line_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_strLength_lent(v_t_244, 0), MK_INT(0LL)) || ({ V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_line_240), MK_INT(0LL), MK_INT(1LL))); int c_ = ({ V v_t_247 = heff_intSub(heff_strLength_lent(v_line_240, 0), MK_INT(1LL)); int c_ = ({ V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_line_240), heff_dup(v_t_247), MK_INT(-1LL))); int c_ = ({ V v_t_249 = heff_strSlice(heff_dup(v_line_240), heff_dup(v_t_246), heff_intAdd(heff_dup(v_t_248), MK_INT(1LL))); int c_ = heff_strEq_c(heff_strSlice_lent(v_t_249, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_str0)); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop(v_line_240);
  heff_drop(v_t_244);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2ereadGo_str0, 7, "import ");
Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V v_src_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  } else {
    V v_t_244 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(heff_dup(v_src_240), heff_dup(v_i_241)));
    V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(heff_strSlice_lent(v_src_240, v_i_241, v_t_244, 4)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_x_246 = heff_strLength_lent(v_src_240, 0);
      V v_t_247 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(heff_dup(v_src_240), v_i_241));
      V v_y_248 = heff_intAdd(v_t_247, MK_INT(1LL));
      V v_t_2410;
      if (heff_intLe_c(heff_dup(v_x_246), heff_dup(v_y_248))) {
        heff_drop(v_y_248);
        v_t_2410 = v_x_246;
      } else {
        heff_drop(v_x_246);
        v_t_2410 = v_y_248;
      }
      V t_0 = v_src_240;
      V t_1 = v_t_2410;
      V t_2 = v_acc_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_t_2411 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(7LL)));
      if (heff_strEq_c(v_t_2411, ((V)&g_heff_2esyntax_2efmt_2eimports_2ereadGo_str0))) {
        V v_t_2413 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(heff_dup(v_src_240), heff_dup(v_i_241)));
        V v_t_2414 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(heff_dup(v_src_240), heff_dup(v_i_241)));
        V v_t_2415 = heff_strSlice(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(7LL)), v_t_2414);
        V v_t_2416 = (g_heff_2esyntax_2efmt_2eimports_2eimportWords(v_t_2415));
        V v_t_2417 = ({ V a_0 = heff_dup(v_i_241); V a_1 = v_t_2413; V a_2 = v_t_2416; V r_ = (g_heff_2esyntax_2efmt_2eimports_2eoneImport(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Nothing: {
          heff_drop(v_src_240);
          heff_drop(v_i_241);
          return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        }
        case TAG_Just: {
          V v_imp_2418 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_x_2419 = heff_strLength_lent(v_src_240, 0);
          V v_t_2420 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(heff_dup(v_src_240), v_i_241));
          V v_y_2421 = heff_intAdd(v_t_2420, MK_INT(1LL));
          V v_t_2423;
          if (heff_intLe_c(heff_dup(v_x_2419), heff_dup(v_y_2421))) {
            heff_drop(v_y_2421);
            v_t_2423 = v_x_2419;
          } else {
            heff_drop(v_x_2419);
            v_t_2423 = v_y_2421;
          }
          V t_0 = v_src_240;
          V t_1 = v_t_2423;
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_imp_2418, v_acc_242});
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_t_2417);
        }
      } else {
        heff_drop(v_src_240);
        heff_drop(v_i_241);
        return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2ereadGo(a[0], a[1], a[2]);
}