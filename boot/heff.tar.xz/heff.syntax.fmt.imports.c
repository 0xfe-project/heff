// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_claim 296100950
#define LBL_col 308218
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_exposes 1070285678
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_imports 10411951
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_listed 844633320
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
static uint32_t shape_imports__exposing__text[] = {LBL_imports, LBL_exposing, LBL_text};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2efmt_2eimports_2eallNameC(V, V);
V g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eallNameC_clo;
V g_heff_2esyntax_2efmt_2eimports_2eblankExposing(V, V);
V g_heff_2esyntax_2efmt_2eimports_2eblankExposing_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eblankExposing_clo;
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(V);
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_clo;
V g_heff_2esyntax_2efmt_2eimports_2eentryText(V);
V g_heff_2esyntax_2efmt_2eimports_2eentryText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eentryText_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingText(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingText_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2eimports_2eimportWords(V);
V g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eimportWords_clo;
V g_heff_2esyntax_2efmt_2eimports_2eisAlias(V);
V g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eisAlias_clo;
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(V, V);
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_clo;
HeffT2 g_heff_2esyntax_2efmt_2eimports_2eoneImport_24cpr(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo;
V g_heff_2esyntax_2efmt_2eimports_2ereadImports(V);
V g_heff_2esyntax_2efmt_2eimports_2ereadImports_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadImports_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(V, V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    return v_i_241;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2elineEndFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2eimports_2eallNameC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2eallNameC(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_c_242 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if (((heff_peek_word(v_c_242) == ((int64_t)46ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)45ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_242);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eallNameC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eallNameC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eisAlias_str0, 1, ".");
Clo g_heff_2esyntax_2efmt_2eimports_2eisAlias_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eisAlias(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
        if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2eimports_2eisAlias_str0), v_x_240, MK_INT(0LL), 5))) {
          if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
            return (g_heff_2esyntax_2efmt_2eimports_2eallNameC(v_x_240, MK_INT(0LL)));
          } else {
            return NTAG(TAG_False);
          }
        } else {
          return NTAG(TAG_False);
        }
      } else {
        return NTAG(TAG_False);
      }
    } else {
      return NTAG(TAG_False);
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eisAlias_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eisAlias(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_str0);
  } else {
    V v_s_241 = ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_str1);
    return (g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_241));
  }
}
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2espacesOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str0));
  } else {
    V v_s_242 = heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_242;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2espacesOf_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eimportWords_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eimportWords_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2eimports_2eimportWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eimportWords(V v_rest_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(v_rest_240, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_rest_240, 0)) - ((int64_t)1ULL));
  V v_t_243 = (g_prelude_2eskipSpaces(v_rest_240, heff_box_word(v_t_242), MK_INT(-1LL)));
  V v_s_244 = heff_strSlice(heff_dup(v_rest_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  V v_t_245 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eimportWords_str0); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2eimports_2eimportWords_str1), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  return (g_list_2ekeepIf_24s1552018029x993523539(MK_INT(0LL), v_t_245));
}
V g_heff_2esyntax_2efmt_2eimports_2eimportWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eimportWords(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eoneImport_24cpr_str0, 2, "as");

HeffT2 g_heff_2esyntax_2efmt_2eimports_2eoneImport_24cpr(V v_i_240, V v_e_241, V v_ws_242) {
top: ;
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_e_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_ws_242, 0);
    V v_ws2_244 = heff_field(v_ws_242, 1);
    heff_take_n(v_ws_242, 3ULL, 2);
    switch (heff_tag_of(v_ws2_244)) {
    case TAG_Nil: {
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_243, 0)))) {
        V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eallNameC(v_m_243, MK_INT(0LL)));
        if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
          heff_drop(v_t_245);
          V v_t_246 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_243, NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_246}});
        } else {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_m_243);
          heff_drop(v_t_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_m_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_Cons: {
      V v_kw_247 = heff_field(v_ws2_244, 0);
      V v_ws22_248 = heff_field(v_ws2_244, 1);
      heff_take_n(v_ws2_244, 3ULL, 2);
      switch (heff_tag_of(v_ws22_248)) {
      case TAG_Nil: {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_m_243);
        heff_drop(v_kw_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_a_249 = heff_field(v_ws22_248, 0);
        V v_ws222_2410 = heff_field(v_ws22_248, 1);
        heff_take_n(v_ws22_248, 3ULL, 2);
        switch (heff_tag_of(v_ws222_2410)) {
        case TAG_Nil: {
          if (heff_strEq_c(v_kw_247, ((V)&g_heff_2esyntax_2efmt_2eimports_2eoneImport_24cpr_str0))) {
            if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_243, 0)))) {
              V v_t_2411 = (g_heff_2esyntax_2efmt_2eimports_2eallNameC(v_m_243, MK_INT(0LL)));
              if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
                heff_drop(v_t_2411);
                V v_t_2412 = (g_heff_2esyntax_2efmt_2eimports_2eisAlias(v_a_249));
                if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
                  heff_drop(v_t_2412);
                  V v_t_2413 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_243, heff_tag_n(TAG_Just, 1, (V[]){v_a_249}), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
                } else {
                  heff_drop(v_i_240);
                  heff_drop(v_e_241);
                  heff_drop(v_m_243);
                  heff_drop(v_a_249);
                  heff_drop(v_t_2412);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_i_240);
                heff_drop(v_e_241);
                heff_drop(v_m_243);
                heff_drop(v_a_249);
                heff_drop(v_t_2411);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_i_240);
              heff_drop(v_e_241);
              heff_drop(v_m_243);
              heff_drop(v_a_249);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_i_240);
            heff_drop(v_e_241);
            heff_drop(v_m_243);
            heff_drop(v_a_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_ws222_2410, 0ULL, 2);
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_m_243);
          heff_drop(v_kw_247);
          heff_drop(v_a_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_ws222_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws22_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_ws2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ws_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_str0, 2, "--");
Clo g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(V v_line_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(v_line_240, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_line_240, 0)) - ((int64_t)1ULL));
  V v_t_243 = (g_prelude_2eskipSpaces(v_line_240, heff_box_word(v_t_242), MK_INT(-1LL)));
  V v_t_244 = heff_strSlice(heff_dup(v_line_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  V v_ret_24bool = heff_bool(((heff_unbox_word(heff_strLength_lent(v_t_244, 0)) == ((int64_t)0ULL)) || ({ V v_t_245 = (g_prelude_2eskipSpaces(v_line_240, MK_INT(0LL), MK_INT(1LL))); int c_ = ({ int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_line_240, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_247 = (g_prelude_2eskipSpaces(v_line_240, heff_box_word(v_t_246), MK_INT(-1LL))); int c_ = ({ V v_t_248 = heff_strSlice(heff_dup(v_line_240), heff_dup(v_t_245), heff_intAdd(heff_dup(v_t_247), MK_INT(1LL))); int c_ = ({ V v_t_249 = heff_strSlice_lent(v_t_248, MK_INT(0LL), MK_INT(2LL), 6); int c_ = heff_strEq_c_lent(v_t_249, ((V)&g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_str0), 2); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }); c_; }); heff_drop(v_t_245); c_; })));
  heff_drop(v_t_244);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2ereadGo_str0, 7, "import ");
Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V v_src_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  } else {
    V v_t_243 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(v_src_240, heff_dup(v_i_241)));
    V v_t_244 = ({ V b_0 = heff_strSlice_lent(v_src_240, v_i_241, v_t_243, 4); V r_ = (g_heff_2esyntax_2efmt_2eimports_2eemptyOrComment(b_0)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_x_245 = heff_strLength_lent(v_src_240, 0);
      V v_t_246 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(v_src_240, v_i_241));
      V v_y_247 = heff_intAdd(v_t_246, MK_INT(1LL));
      V v_t_248;
      if (heff_intLe_c_lent(v_x_245, v_y_247, 0)) {
        heff_drop(v_y_247);
        v_t_248 = v_x_245;
      } else {
        heff_drop(v_x_245);
        v_t_248 = v_y_247;
      }
      V t_0 = v_src_240;
      V t_1 = v_t_248;
      V t_2 = v_acc_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_t_249 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(7LL)));
      if (heff_strEq_c(v_t_249, ((V)&g_heff_2esyntax_2efmt_2eimports_2ereadGo_str0))) {
        V v_t_2410 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(v_src_240, heff_dup(v_i_241)));
        V v_t_2411 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(v_src_240, heff_dup(v_i_241)));
        V v_t_2412 = heff_strSlice(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(7LL)), v_t_2411);
        V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2eimports_2eimportWords(a_0)); heff_drop(v_t_2412); r_; });
        HeffT2 v_t_2414 = (g_heff_2esyntax_2efmt_2eimports_2eoneImport_24cpr(heff_dup(v_i_241), v_t_2410, v_t_2413));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_imp_2417 = v_field_2416;
            V v_x_2418 = heff_strLength_lent(v_src_240, 0);
            V v_t_2419 = (g_heff_2esyntax_2efmt_2eimports_2elineEndFrom(v_src_240, v_i_241));
            V v_y_2420 = heff_intAdd(v_t_2419, MK_INT(1LL));
            V v_t_2421;
            if (heff_intLe_c_lent(v_x_2418, v_y_2420, 0)) {
              heff_drop(v_y_2420);
              v_t_2421 = v_x_2418;
            } else {
              heff_drop(v_x_2418);
              v_t_2421 = v_y_2420;
            }
            V t_0 = v_src_240;
            V t_1 = v_t_2421;
            V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_imp_2417, v_acc_242});
            v_src_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          } else {
            heff_drop(v_i_241);
            heff_drop(v_field_2416);
            return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
          }
        }
      } else {
        heff_drop(v_i_241);
        return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2ereadGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2eimports_2eblankExposing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eblankExposing_entry, 2, 0};

V g_heff_2esyntax_2efmt_2eimports_2eblankExposing(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return v_s_241;
  }
  case TAG_Just: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_h_242, 3)), 0, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_h_242, 3)), 1, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_h_242, 3)), 0, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2eimports_2espacesOf(heff_intSub(v_t_244, v_t_245)));
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_h_242, 3)), 1, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_s_241), v_t_247, heff_strLength_lent(v_s_241, 0));
    return heff_strAppend(heff_strSlice(v_s_241, MK_INT(0LL), v_t_243), heff_strAppend(v_t_246, v_t_248));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eblankExposing_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eblankExposing(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2eimports_2ereadImports_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2ereadImports_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2ereadImports(V v_src_240) {
top: ;
  V v_t_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_claim_242 = heff_get_n(v_t_241, 2, 4);
  V v_t_243 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_t_244 = ({ V b_0 = heff_get_n(v_t_243, 2, 4); V a_1 = v_src_240; V r_ = (g_heff_2esyntax_2efmt_2eimports_2eblankExposing(b_0, a_1)); heff_drop(b_0); r_; });
  V v_imps_245 = (g_heff_2esyntax_2efmt_2eimports_2ereadGo(v_t_244, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1759289969x319536741(v_t_244, v_imps_245));
  return heff_rec_n(3, shape_imports__exposing__text, (V[]){v_imps_245, v_claim_242, v_t_246});
}
V g_heff_2esyntax_2efmt_2eimports_2ereadImports_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2ereadImports(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str6, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eentryText_str7, 0, "");
Clo g_heff_2esyntax_2efmt_2eimports_2eentryText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eentryText_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eentryText(V v_e_240) {
top: ;
  V v_name_241 = heff_take_field(v_e_240, 0);
  V v_tags_242 = heff_get_n(v_e_240, 1, 3);
  V v_x_243 = heff_dup(v_name_241);
  V v_t_245;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_243, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_243, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
      V v_t_244 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(a_0, a_1)); heff_drop(v_x_243); r_; });
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        v_t_245 = v_name_241;
      } else {
        heff_drop(v_t_244);
        v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str0), heff_strAppend(v_name_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str1)));
      }
    } else {
      heff_drop(v_x_243);
      v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str2), heff_strAppend(v_name_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str3)));
    }
  } else {
    heff_drop(v_x_243);
    v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str4), heff_strAppend(v_name_241, ((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str5)));
  }
  V v_t_246;
  if ((heff_dup(v_tags_242) == NTAG(TAG_True))) {
    heff_drop(v_tags_242);
    v_t_246 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str6);
  } else {
    heff_drop(v_tags_242);
    v_t_246 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eentryText_str7);
  }
  return heff_strAppend(v_t_245, v_t_246);
}
V g_heff_2esyntax_2efmt_2eimports_2eentryText_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2eimports_2eentryText(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str0, 6, "module");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str1, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str4, 2, " (");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str6, 6, "module");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str7, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str9, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str10, 2, " (");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str12, 6, "module");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str13, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str15, 5, "\012  , ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str16, 5, "\012  ( ");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str17, 4, "\012  )");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str18, 6, "module");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingText_str19, 7, "module ");
Clo g_heff_2esyntax_2efmt_2eimports_2eexposingText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eexposingText_entry, 3, 0};

V g_heff_2esyntax_2efmt_2eimports_2eexposingText(V v_name_240, V v_x2_241, V v_es_242) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244;
    switch (heff_tag_of(v_name_240)) {
    case TAG_Nothing: {
      v_t_244 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str0);
      break;
    }
    case TAG_Just: {
      V v_name_243 = heff_field(v_name_240, 0);
      v_t_244 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str1), heff_dup(v_name_243));
      break;
    }
    default: heff_nomatch(v_name_240);
    }
    V v_t_247;
    switch (heff_tag_of(v_es_242)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_es_242, 0);
      V v_xs_246 = heff_field(v_es_242, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str3), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_es_242);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str4), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str5)));
    V v_t_249 = heff_strLength(heff_strAppend(v_t_244, v_t_248));
    if ((heff_unbox_word(v_t_249) <= ((int64_t)80ULL))) {
      V v_t_2411;
      switch (heff_tag_of(v_name_240)) {
      case TAG_Nothing: {
        v_t_2411 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str6);
        break;
      }
      case TAG_Just: {
        V v_name_2410 = heff_field(v_name_240, 0);
        v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str7), heff_dup(v_name_2410));
        break;
      }
      default: heff_nomatch(v_name_240);
      }
      V v_t_2414;
      switch (heff_tag_of(v_es_242)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_es_242, 0);
        V v_xs_2413 = heff_field(v_es_242, 1);
        v_t_2414 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str9), heff_dup(v_x_2412), v_xs_2413));
        break;
      }
      default: heff_nomatch(v_es_242);
      }
      V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str10), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str11)));
      return heff_strAppend(v_t_2411, v_t_2415);
    } else {
      V v_t_2417;
      switch (heff_tag_of(v_name_240)) {
      case TAG_Nothing: {
        v_t_2417 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str12);
        break;
      }
      case TAG_Just: {
        V v_name_2416 = heff_field(v_name_240, 0);
        v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str13), heff_dup(v_name_2416));
        break;
      }
      default: heff_nomatch(v_name_240);
      }
      V v_t_2420;
      switch (heff_tag_of(v_es_242)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_es_242, 0);
        V v_xs_2419 = heff_field(v_es_242, 1);
        v_t_2420 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str15), heff_dup(v_x_2418), v_xs_2419));
        break;
      }
      default: heff_nomatch(v_es_242);
      }
      V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str16), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str17)));
      return heff_strAppend(v_t_2417, v_t_2421);
    }
  } else {
    switch (heff_tag_of(v_name_240)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str18);
    }
    case TAG_Just: {
      V v_name_2422 = heff_field(v_name_240, 0);
      return heff_strAppend(((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingText_str19), heff_dup(v_name_2422));
    }
    default: return heff_nomatch(v_name_240);
    }
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eexposingText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2eimports_2eexposingText(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingToks_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2eimports_2eexposingToks_str1, 6, "import");
Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry, 1, 0};

V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_h_241 = heff_field(v_x1_240, 0);
    V v_error_242 = heff_dup(heff_rfield(v_h_241, 4));
    V v_name_243 = heff_dup(heff_rfield(v_h_241, 0));
    V v_listed_244 = heff_dup(heff_rfield(v_h_241, 1));
    V v_exposes_245 = heff_dup(heff_rfield(v_h_241, 2));
    V v_span_246 = heff_dup(heff_rfield(v_h_241, 3));
    V v_t_249;
    switch (heff_tag_of(v_error_242)) {
    case TAG_Nothing: {
      V v_t_247 = (g_list_2emap_24s1975257801x764827799(v_exposes_245));
      v_t_249 = ({ V a_0 = v_name_243; V a_1 = v_listed_244; V a_2 = v_t_247; V r_ = (g_heff_2esyntax_2efmt_2eimports_2eexposingText(a_0, a_1, a_2)); heff_drop(v_name_243); heff_drop(v_listed_244); heff_drop(v_t_247); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_error_242, 0ULL, 1);
      heff_drop(v_name_243);
      heff_drop(v_listed_244);
      heff_drop(v_exposes_245);
      v_t_249 = ((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingToks_str0);
      break;
    }
    default: heff_nomatch(v_error_242);
    }
    V v_t_2410 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2eimports_2eexposingToks_str1), v_t_249, heff_take_field(v_span_246, 0), heff_get_n(v_span_246, 1, 2), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2eimports_2eexposingToks(a0); heff_drop(a0); return r;
}