// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_globals 352931696
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2einstantiate(V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etagHidden(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagHidden_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeEv(V);
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeEv_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24f1325733028x1311723093(V, V, V);
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1325733028x1311723093_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiate_entry, 3, 0};

V g_heff_2eelab_2erules_2einstantiate(V v_e_240, V v_sp_241, V v_w_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_w_242, 2));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_245 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam0, 1, 1, (V[]){heff_dup(v_w_242)})});
    return (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_245, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)));
  } else {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam1, 2, 1, (V[]){v_w_242});
  }
}
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiate(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam2, 1, 1, (V[]){heff_dup(v_w_242)})});
  V v_t_2410 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_t_249, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)});
  V f_ = v_k_247;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especialized_entry, 7, 0};

V g_heff_2eelab_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return (g_heff_2eelab_2erules_2especializedGo(v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), v_sp_249, heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244, v_p_245, v_p_246));
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2especialized(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elettedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elettedAt_entry, 8, 0};

V g_heff_2eelab_2erules_2elettedAt(V v_e_240, V v_a_241, V v_made_242, V v_record_243, V v_bound_244, V v_places_245, V v_z_246, V v_z_247) {
top: ;
  V v_c_248 = (g_heff_2eelab_2erules_2edescribedBound(v_made_242, v_bound_244));
  return heff_tail(v_c_248, 2, (V[]){v_z_246, heff_clo_n(g_heff_2eelab_2erules_2elettedAt_lam0, 1, 7, (V[]){v_e_240, v_places_245, v_made_242, heff_dup(v_bound_244), v_a_241, v_record_243, v_z_247})});
}
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elettedAt(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_places_245 = heff_env(self)[1];
  V v_made_242 = heff_env(self)[2];
  V v_bound_244 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_record_243 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2412 = (g_heff_2eelab_2erules_2evaluesGo(v_t_2411, heff_dup(v_places_245), heff_dup(v_made_242), heff_dup(v_places_245), MK_INT(0LL)));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_bound_244; V r_ = (g_list_2efoldl_24f1325733028x1311723093(a_0, a_1, a_2)); heff_drop(v_bound_244); r_; });
  V v_pairs_2415 = (g_heff_2eelab_2erules_2eentriesGo(v_t_2413, v_t_2414, heff_dup(v_places_245), v_made_242, v_places_245, MK_INT(0LL)));
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2415)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2415));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_pairs_2415));
  V v_t_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  V v_t_2420 = (g_heff_2eelab_2erules_2eletsAround(v_t_2410, v_a_241, v_t_2412, MK_INT(0LL), heff_tag_n(TAG_SCons, 1, (V[]){v_t_2419})));
  V v_x_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_record_243, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V f_ = v_z_247;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str0, 23, "` exports the type of `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str1, 18, "` without its tags");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str2, 8, "module `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str3, 46, "make and match its values with the functions `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str4, 9, "` exports");
Clo g_heff_2eelab_2erules_2etagHidden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagHidden_entry, 5, 0};

V g_heff_2eelab_2erules_2etagHidden(V v_sp_240, V v_x_241, V v_m_242, V v_hd_243, V v_k2_244) {
top: ;
  V v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etagHidden_str0), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2etagHidden_str1)));
  V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etagHidden_str2), heff_strAppend(heff_dup(v_m_242), v_t_245));
  V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etagHidden_str3), heff_strAppend(v_m_242, ((V)&g_heff_2eelab_2erules_2etagHidden_str4)));
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(353LL), NTAG(TAG_SError), v_t_246, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get_n(v_hd_243, 1, 3), 2, (V[]){v_t_2411, v_k2_244});
}
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagHidden(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str12, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str13, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str14, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str15, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str16, 12, "no such tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str17, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str18, 34, "wrong number of arguments for tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str19, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str20, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str21, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str22, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str23, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str24, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str25, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str26, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str27, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str28, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str29, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str30, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str31, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str32, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str33, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str34, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str35, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str36, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str37, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str38, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str39, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str40, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str41, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str42, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str43, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str44, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str45, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str46, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str47, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str48, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str49, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str50, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str51, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str52, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str53, 63, " names no definition or binder in scope, so it is read as a tag");
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3, 2, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0, 4, 4, (V[]){v_x_242, v_sp_240, v_tsp_241, v_cs_243})}});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args) {
  V v_hd_24154 = args[0];
  V v_k_24155 = args[1];
  heff_drop(v_hd_24154);
  V f_ = v_k_24155;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7(V self, V *args) {
  V v_i_24164 = args[0];
  V v_gs_24163 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_24165 = heff_arrayIndex(v_gs_24163, v_i_24164);
  return heff_get_n(v_m_24165, 0, 2);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8(V self, V *args) {
  V v_u_24167 = args[0];
  heff_drop(v_u_24167);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args) {
  V v_x_24162 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_24163 = heff_arrayFromList(v_x_24162);
  V v_t_24166 = heff_arrayGenerate(heff_arrayLength_lent(v_gs_24163, 0), heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7, 1, 1, (V[]){v_gs_24163}));
  V v_x_24168 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_x_242, v_t_24166}), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8_clo)});
  V f_ = v_k_247;
  args[0] = v_x_24168;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args) {
  V v_x_24160 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_24148 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24160);
  V v_c_24161 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_24148)));
  V f_ = v_c_24161;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6, 1, 2, (V[]){v_x_242, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args) {
  V v_x_24157 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_ts_24148 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_sp_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24157);
  V v_t_24158 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_243));
  if (heff_intEq_c(heff_arrayLength_lent(v_ts_24148, 0), v_t_24158)) {
    heff_drop(v_sp_240);
    return ({ V a_0 = heff_dup(v_e_244); V a_1 = v_x_2412; V a_2 = heff_dup(v_x_242); V a_3 = v_tsp_241; V a_4 = heff_dup(v_x_2412); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_24148, v_hd_246, v_x_242, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2412); r_; });
  } else {
    heff_drop(v_cs_243);
    heff_drop(v_ts_24148);
    heff_drop(v_tsp_241);
    V v_t_24169 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
    V v_t_24170 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str17), v_t_24169));
    V v_msg_24171 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str18), v_t_24170);
    V v_t_24172 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_24171, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24173 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24172})});
    V v_t_24174 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24173})});
    V v_t_24175 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24174}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24175;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_cs_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_2437;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2416 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2437 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2416);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2437);
      V v_t_2438 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1)));
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2438, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2440 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2441}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2442;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2437);
      V v_t_2443 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2444 = heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2), heff_dup(v_x_242)));
      V v_msg_2445 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3), v_t_2444);
      V v_t_2446 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4))});
      V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2445, v_tsp_241, v_t_2446});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2449}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2450;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_cs_243);
    V v_t_2477;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2456 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2456)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2456, 0ULL, 1);
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2456, 0ULL, 1);
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2456, 0ULL, 1);
        v_t_2477 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2456);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2477);
      V v_t_2478 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6)));
      V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2478, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2481}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2482;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2477);
      V v_t_2483 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2484 = heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7), heff_dup(v_x_242)));
      V v_msg_2485 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8), v_t_2484);
      V v_t_2486 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9))});
      V v_t_2487 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2485, v_tsp_241, v_t_2486});
      V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2489}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2490;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_cs_243);
    V v_t_24116;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2495 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2495)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2495, 0ULL, 1);
        v_t_24116 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2495, 0ULL, 1);
        v_t_24116 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2495, 0ULL, 1);
        v_t_24116 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24116 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2495);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24116 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24116);
      V v_t_24117 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11)));
      V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24117, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24118})});
      V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
      V v_t_24121 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24120}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24121;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24116);
      V v_t_24122 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24123 = heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str12), heff_dup(v_x_242)));
      V v_msg_24124 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str13), v_t_24123);
      V v_t_24125 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str14))});
      V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24124, v_tsp_241, v_t_24125});
      V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
      V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
      V v_t_24129 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24128}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24129;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeSum: {
    V v_vs_24130 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    HeffT2 v_t_24131 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_vs_24130, 1), v_x_242));
    V v_t_24140;
    {
      V v_field_24133 = v_t_24131.f[1];
      int64_t v_tag_24132 = ((int64_t)v_t_24131.f[0]);
      if ((v_tag_24132 == ((int64_t)0ULL))) {
        V v_i_24135 = v_field_24133;
        V v_xs_24136 = heff_get_n(v_vs_24130, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_24135, 1)) {
          if (heff_intLt_c(heff_dup(v_i_24135), heff_arrayLength_lent(v_xs_24136, 0))) {
            V v_t_24139 = heff_arrayIndex(v_xs_24136, v_i_24135);
            v_t_24140 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_Just, 1, (V[]){v_t_24139});
          } else {
            heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
            heff_drop(v_i_24135);
            heff_drop(v_xs_24136);
            v_t_24140 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          heff_drop(v_i_24135);
          heff_drop(v_xs_24136);
          v_t_24140 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_vs_24130, 3);
        heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
        heff_drop(v_field_24133);
        v_t_24140 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_t_24140)) {
    case TAG_Nothing: {
      heff_drop(v_tsp_241);
      heff_drop(v_cs_243);
      V v_t_24141 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24142 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str15), v_t_24141));
      V v_msg_24143 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str16), v_t_24142);
      V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_24143, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24145 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24144})});
      V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
      V v_t_24147 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24146}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24147;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_ts_24148 = heff_field(v_t_24140, 0);
      heff_take_n(v_t_24140, 1ULL, 1);
      HeffT2 v_t_24149 = (g_heff_2eelab_2erules_2esealedOf_24cpr(heff_dup(heff_rfield(v_e_244, 1)), heff_dup(v_x_2412)));
      V v_c_24156;
      {
        V v_field_24151 = v_t_24149.f[1];
        int64_t v_tag_24150 = ((int64_t)v_t_24149.f[0]);
        if ((v_tag_24150 == ((int64_t)0ULL))) {
          V v_m_24153 = v_field_24151;
          v_c_24156 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2etagHidden_clo), 3, (V[]){heff_dup(v_tsp_241), heff_dup(v_x_242), v_m_24153}));
        } else {
          heff_drop(v_field_24151);
          v_c_24156 = ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3_clo);
        }
      }
      V f_ = v_c_24156;
      heff_room[0] = heff_dup(v_hd_246);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4, 1, 9, (V[]){v_cs_243, v_ts_24148, v_e_244, v_x_2412, v_x_242, v_tsp_241, v_hd_246, v_k_247, v_sp_240});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_24140);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_cs_243);
    V v_t_24198;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24177 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24177)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24177, 0ULL, 1);
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24177, 0ULL, 1);
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24177, 0ULL, 1);
        v_t_24198 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24177);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24198) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24198);
      V v_t_24199 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str19), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str20)));
      V v_t_24200 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24199, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24201 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24200})});
      V v_t_24202 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24201})});
      V v_t_24203 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24202}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24203;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24198);
      V v_t_24204 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24205 = heff_strAppend(v_t_24204, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str21), heff_dup(v_x_242)));
      V v_msg_24206 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str22), v_t_24205);
      V v_t_24207 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str23))});
      V v_t_24208 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24206, v_tsp_241, v_t_24207});
      V v_t_24209 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24208})});
      V v_t_24210 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24209})});
      V v_t_24211 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24210}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24211;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_cs_243);
    V v_t_24234;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24213 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24213)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24213, 0ULL, 1);
        v_t_24234 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24213, 0ULL, 1);
        v_t_24234 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24213, 0ULL, 1);
        v_t_24234 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24234 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24213);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24234 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24234) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24234);
      V v_t_24235 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str24), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str25)));
      V v_t_24236 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24235, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24237 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24236})});
      V v_t_24238 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24237})});
      V v_t_24239 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24238}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24239;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24234);
      V v_t_24240 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24241 = heff_strAppend(v_t_24240, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str26), heff_dup(v_x_242)));
      V v_msg_24242 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str27), v_t_24241);
      V v_t_24243 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str28))});
      V v_t_24244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24242, v_tsp_241, v_t_24243});
      V v_t_24245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24244})});
      V v_t_24246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24245})});
      V v_t_24247 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24246}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24247;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeString: {
    heff_drop(v_cs_243);
    V v_t_24270;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24249 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24249)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24249, 0ULL, 1);
        v_t_24270 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24249, 0ULL, 1);
        v_t_24270 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24249, 0ULL, 1);
        v_t_24270 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24270 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24249);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24270 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24270) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24270);
      V v_t_24271 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str29), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str30)));
      V v_t_24272 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24271, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24273 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24272})});
      V v_t_24274 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24273})});
      V v_t_24275 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24274}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24275;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24270);
      V v_t_24276 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24277 = heff_strAppend(v_t_24276, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str31), heff_dup(v_x_242)));
      V v_msg_24278 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str32), v_t_24277);
      V v_t_24279 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str33))});
      V v_t_24280 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24278, v_tsp_241, v_t_24279});
      V v_t_24281 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24280})});
      V v_t_24282 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24281})});
      V v_t_24283 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24282}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24283;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_cs_243);
    V v_t_24306;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24285 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24285)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24285, 0ULL, 1);
        v_t_24306 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24285, 0ULL, 1);
        v_t_24306 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24285, 0ULL, 1);
        v_t_24306 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24306 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24285);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24306 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24306);
      V v_t_24307 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str34), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str35)));
      V v_t_24308 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24307, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24309 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24308})});
      V v_t_24310 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24309})});
      V v_t_24311 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24310}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24311;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24306);
      V v_t_24312 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24313 = heff_strAppend(v_t_24312, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str36), heff_dup(v_x_242)));
      V v_msg_24314 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str37), v_t_24313);
      V v_t_24315 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str38))});
      V v_t_24316 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24314, v_tsp_241, v_t_24315});
      V v_t_24317 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24316})});
      V v_t_24318 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24317})});
      V v_t_24319 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24318}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24319;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24343;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24322 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24322)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24322, 0ULL, 1);
        v_t_24343 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24322, 0ULL, 1);
        v_t_24343 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24322, 0ULL, 1);
        v_t_24343 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24343 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24322);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24343 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24343) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24343);
      V v_t_24344 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str39), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str40)));
      V v_t_24345 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24344, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24346 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24345})});
      V v_t_24347 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24346})});
      V v_t_24348 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24347}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24348;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24343);
      V v_t_24349 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24350 = heff_strAppend(v_t_24349, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str41), heff_dup(v_x_242)));
      V v_msg_24351 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str42), v_t_24350);
      V v_t_24352 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str43))});
      V v_t_24353 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24351, v_tsp_241, v_t_24352});
      V v_t_24354 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24353})});
      V v_t_24355 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24354})});
      V v_t_24356 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24355}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24356;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24380;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24359 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24359)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24359, 0ULL, 1);
        v_t_24380 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24359, 0ULL, 1);
        v_t_24380 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24359, 0ULL, 1);
        v_t_24380 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24380 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24359);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24380) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24380);
      V v_t_24381 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str44), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str45)));
      V v_t_24382 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24381, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24383 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24382})});
      V v_t_24384 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24383})});
      V v_t_24385 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24384}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24385;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24380);
      V v_t_24386 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24387 = heff_strAppend(v_t_24386, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str46), heff_dup(v_x_242)));
      V v_msg_24388 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str47), v_t_24387);
      V v_t_24389 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str48))});
      V v_t_24390 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24388, v_tsp_241, v_t_24389});
      V v_t_24391 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24390})});
      V v_t_24392 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24391})});
      V v_t_24393 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24392}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24393;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_NoRules: {
    heff_drop(v_cs_243);
    V v_t_24416;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24395 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24395)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24395, 0ULL, 1);
        v_t_24416 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24395, 0ULL, 1);
        v_t_24416 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24395, 0ULL, 1);
        v_t_24416 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24416 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24395);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24416 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24416) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24416);
      V v_t_24417 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str49), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str50)));
      V v_t_24418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24417, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24418})});
      V v_t_24420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24419})});
      V v_t_24421 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24420}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24421;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24416);
      V v_t_24422 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24423 = heff_strAppend(v_t_24422, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str51), heff_dup(v_x_242)));
      V v_msg_24424 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str52), v_t_24423);
      V v_t_24425 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str53))});
      V v_t_24426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24424, v_tsp_241, v_t_24425});
      V v_t_24427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24426})});
      V v_t_24428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24427})});
      V v_t_24429 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24428}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24429;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2, 1, 7, (V[]){v_x_242, v_sp_240, v_hd_246, v_k_247, v_e_244, v_tsp_241, v_cs_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str0, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str1, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str2, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str3, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str4, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str5, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str6, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str7, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str8, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str9, 45, "cannot decode an element of non-universe type");
V g_heff_2eelab_2erules_2euniverseElimSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseElimSyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam3(V self, V *args) {
  V v_c_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 2ULL, 2);
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam5(V self, V *args) {
  V v_u_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  V v_t_2422 = heff_tr(heff_call(heff_get_n(v_g_2419, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_2422; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_2422); r_; });
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_VU: {
    V v_ru_24x_2415_24VU = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_245, 3);
    V v_g_2419;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_g_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2415_24VU, TAG_SDecode, 1, (V[]){heff_dup(heff_rfield(v_g_2419, 0))});
    V f_ = v_k_246;
    args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2420, heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam5, 1, 1, (V[]){v_g_2419})});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    heff_take_n(v_x_2415, 0ULL, 5);
    heff_drop(v_x_247);
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2430}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2431;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VFunction: {
    heff_take_n(v_x_2415, 0ULL, 6);
    heff_drop(v_x_247);
    V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2440}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2441;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VRecord: {
    heff_take_n(v_x_2415, 0ULL, 4);
    heff_drop(v_x_247);
    V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2448}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2449;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_ru_24x_2415_24VSum = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2452 = heff_tag_at_n(v_ru_24x_2415_24VSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2453}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2454;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_x_247);
    V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2457}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2458;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_x_247);
    V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2461}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2462;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimString: {
    heff_drop(v_x_247);
    V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2465}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2466;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimRune: {
    heff_drop(v_x_247);
    V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2469}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimArray: {
    V v_ru_24x_2415_24VPrimArray = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2473 = heff_tag_at_n(v_ru_24x_2415_24VPrimArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2474}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2475;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VFixed: {
    V v_ru_24x_2415_24VFixed = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_at_n(v_ru_24x_2415_24VFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2479}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2480;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam3, 1, 1, (V[]){heff_dup(v_x_247)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam4, 1, 4, (V[]){v_x_247, v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_hd_245, v_k_246, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}