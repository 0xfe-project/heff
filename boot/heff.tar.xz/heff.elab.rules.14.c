// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_digits 615232529
#define LBL_exponent 966452320
#define LBL_globals 352931696
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_negative 1666250321
#define LBL_note 9882809
#define LBL_recovered 474271923
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2erules_2eatFloat64_w(V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64(V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_clo;
V g_heff_2eelab_2erules_2eatFloat64_24tok1_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_clo;
V g_heff_2eelab_2erules_2efracAtFixed(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracAtFixed_clo;
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_24generate0_clo;
V g_heff_2eelab_2erules_2esumIntroNow_24map0(V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_24map0_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etagHidden(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagHidden_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeEv(V);
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeEv_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especialized_entry, 7, 0};

V g_heff_2eelab_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return (g_heff_2eelab_2erules_2especializedGo(v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), v_sp_249, heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244, v_p_245, v_p_246));
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2especialized(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str0, 46, "make and match its values with the functions `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str1, 9, "` exports");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str2, 8, "module `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str3, 23, "` exports the type of `");
HEFF_LIT(g_heff_2eelab_2erules_2etagHidden_str4, 18, "` without its tags");
Clo g_heff_2eelab_2erules_2etagHidden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagHidden_entry, 5, 0};

V g_heff_2eelab_2erules_2etagHidden(V v_sp_240, V v_x_241, V v_m_242, V v_p_243, V v_p_244) {
top: ;
  V v_bind_245 = heff_take_field(v_p_243, 1);
  V v_malg_246 = heff_get_n(v_p_243, 2, 3);
  V v_note_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2etagHidden_str0), heff_dup(v_m_242)), ((V)&g_heff_2eelab_2erules_2etagHidden_str1));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2etagHidden_str2), v_m_242), ((V)&g_heff_2eelab_2erules_2etagHidden_str3));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_x_241), ((V)&g_heff_2eelab_2erules_2etagHidden_str4));
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(353LL), NTAG(TAG_SError), v_t_249, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_247})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2412}));
  return heff_tail(v_bind_245, 2, (V[]){v_t_2413, v_p_244});
}
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagHidden(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0, 34, "wrong number of arguments for tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2, 12, "no such tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4, 12, "no such tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6, 47, "a tag's type is left unknown by an error before");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11, 63, " names no definition or binder in scope, so it is read as a tag");
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3, 2, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam9, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0, 4, 4, (V[]){v_x_242, v_tsp_241, v_cs_243, v_sp_240})}});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7(V self, V *args) {
  V v_u_2437 = args[0];
  heff_drop(v_u_2437);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8(V self, V *args) {
  V v_u_2442 = args[0];
  heff_drop(v_u_2442);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_2435 = heff_arrayFromList(v_x_2434);
  V v_m_2436 = heff_arrayLength_lent(v_gs_2435, 0);
  V v_t_2441;
  if ((heff_peek_word(v_m_2436) <= ((int64_t)0ULL))) {
    heff_drop(v_gs_2435);
    v_t_2441 = heff_arrayGenerate(v_m_2436, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam7_clo));
  } else {
    V v_m_2438 = heff_arrayIndex_lent(v_gs_2435, MK_INT(0LL), 2);
    V v_y_2439 = heff_get_n(v_m_2438, 0, 2);
    V v_t_2440 = heff_arrayKeepsAs_lent(v_gs_2435, v_y_2439, 0);
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_m_2436);
      heff_drop(v_t_2440);
      v_t_2441 = (g_heff_2eelab_2erules_2esumIntroNow_24map0(MK_INT(1LL), heff_arraySet(v_gs_2435, MK_INT(0LL), v_y_2439)));
    } else {
      heff_drop(v_t_2440);
      v_t_2441 = ({ V a_0 = v_gs_2435; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2436, v_y_2439); V r_ = (g_heff_2eelab_2erules_2esumIntroNow_24generate0(a_0, a_1, a_2)); heff_drop(v_gs_2435); r_; });
    }
  }
  V v_x_2443 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_x_242, v_t_2441}), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam8_clo)});
  V f_ = v_k_247;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_2422 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2432);
  V v_c_2433 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_2422)));
  V f_ = v_c_2433;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6, 1, 2, (V[]){v_x_242, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_ts_2422 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_sp_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2430);
  V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_243));
  if (heff_intEq_c(heff_arrayLength_lent(v_ts_2422, 0), v_t_2431)) {
    heff_drop(v_sp_240);
    return ({ V a_0 = heff_dup(v_e_244); V a_1 = v_x_2412; V a_2 = heff_dup(v_x_242); V a_3 = v_tsp_241; V a_4 = heff_dup(v_x_2412); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_2422, v_hd_246, v_x_242, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2412); r_; });
  } else {
    heff_drop(v_cs_243);
    heff_drop(v_ts_2422);
    heff_drop(v_tsp_241);
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0), v_x_242), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1));
    V v_t_2445 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
    V v_msg_2446 = heff_strAppend(v_t_2444, v_t_2445);
    V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_2446, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2449}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2450;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam9(V self, V *args) {
  V v_c_2494 = args[0];
  V v_t_2495 = heff_get_n(v_c_2494, 1, 9);
  switch (heff_tag_of(v_t_2495)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2495, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2495);
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam10(V self, V *args) {
  V v_x_24101 = args[0];
  V v_sp_2488 = heff_env(self)[0];
  V v_malg_2492 = heff_env(self)[1];
  V v_bind_2491 = heff_env(self)[2];
  V v_k_2493 = heff_env(self)[3];
  V v_x_2489 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_24101) == NTAG(TAG_True))) {
    heff_drop(v_x_24101);
    heff_drop(v_x_2489);
    V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6), v_sp_2488, NTAG(TAG_Nothing)});
    V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tr(heff_call(v_malg_2492, 1, (V[]){v_t_24104}));
    V f_ = v_bind_2491;
    heff_room[0] = v_t_24105;
    heff_room[1] = v_k_2493;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24101);
    V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7), v_x_2489), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8));
    V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24106, v_sp_2488, NTAG(TAG_Nothing)});
    V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tr(heff_call(v_malg_2492, 1, (V[]){v_t_24109}));
    V f_ = v_bind_2491;
    heff_room[0] = v_t_24110;
    heff_room[1] = v_k_2493;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_cs_243 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_sp_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeSum: {
    V v_vs_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_byName_2415 = heff_take_field(v_vs_2414, 1);
    V v_values_2416 = heff_get_n(v_vs_2414, 2, 3);
    HeffT2 v_t_2417 = ({ V a_0 = v_byName_2415; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_2415); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_i_2420 = v_field_2419;
        V v_xs_2421 = v_values_2416;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2420, 1) && heff_intLt_c(heff_dup(v_i_2420), heff_arrayLength_lent(v_xs_2421, 0)))) {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          V v_ts_2422 = heff_arrayIndex(v_xs_2421, v_i_2420);
          HeffT2 v_t_2423 = (g_heff_2eelab_2erules_2esealedOf_24cpr(heff_dup(heff_rfield(v_e_244, 1)), heff_dup(v_x_2412)));
          V v_c_2429;
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              V v_m_2426 = v_field_2425;
              v_c_2429 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2etagHidden_clo), 3, (V[]){heff_dup(v_tsp_241), heff_dup(v_x_242), v_m_2426}));
            } else {
              heff_drop(v_field_2425);
              v_c_2429 = ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3_clo);
            }
          }
          V f_ = v_c_2429;
          heff_room[0] = heff_dup(v_hd_246);
          heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4, 1, 9, (V[]){v_cs_243, v_ts_2422, v_e_244, v_x_2412, v_x_242, v_tsp_241, v_hd_246, v_k_247, v_sp_240});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_tsp_241);
          heff_drop(v_cs_243);
          heff_drop(v_i_2420);
          heff_drop(v_xs_2421);
          V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2), v_x_242), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3));
          V v_t_2452 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
          V v_msg_2453 = heff_strAppend(v_t_2451, v_t_2452);
          V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_2453, v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2455 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2454})});
          V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
          V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2456}));
          V f_ = heff_get_n(v_hd_246, 1, 3);
          heff_room[0] = v_t_2457;
          heff_room[1] = v_k_247;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_tsp_241);
        heff_drop(v_cs_243);
        heff_drop(v_values_2416);
        heff_drop(v_field_2419);
        V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4), v_x_242), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5));
        V v_t_2459 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
        V v_msg_2460 = heff_strAppend(v_t_2458, v_t_2459);
        V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_2460, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2462 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2463}));
        V f_ = heff_get_n(v_hd_246, 1, 3);
        heff_room[0] = v_t_2464;
        heff_room[1] = v_k_247;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  default: {
    heff_drop(v_cs_243);
    heff_drop(v_t_2413);
    V v_t_2487;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2466 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2466)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2466);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2487);
      V v_sp_2488 = v_sp_240;
      V v_x_2489 = v_x_242;
      V v_hd_2490 = v_hd_246;
      V v_bind_2491 = heff_take_field(v_hd_2490, 1);
      V v_malg_2492 = heff_get_n(v_hd_2490, 2, 3);
      V v_k_2493 = v_k_247;
      V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam9_clo)})});
      V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
      V v_t_24100 = heff_tr(heff_call(heff_dup(v_malg_2492), 1, (V[]){v_t_2499}));
      V f_ = heff_dup(v_bind_2491);
      heff_room[0] = v_t_24100;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam10, 1, 5, (V[]){v_sp_2488, v_malg_2492, v_bind_2491, v_k_2493, v_x_2489});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2487);
      V v_t_24111 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24112 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9), v_t_24111), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10));
      V v_msg_24113 = heff_strAppend(v_t_24112, heff_dup(v_x_242));
      V v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11))});
      V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24113, v_tsp_241, v_t_24114});
      V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24117}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24118;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_cs_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2, 1, 7, (V[]){v_x_242, v_e_244, v_tsp_241, v_hd_246, v_cs_243, v_k_247, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str0, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str1, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str2, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str3, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str4, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str5, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str6, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str7, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str8, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str9, 45, "cannot decode an element of non-universe type");
V g_heff_2eelab_2erules_2euniverseElimSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseElimSyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam3(V self, V *args) {
  V v_c_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 2ULL, 2);
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam5(V self, V *args) {
  V v_u_2422 = args[0];
  V v_val_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_call(v_val_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_2423; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_2423); r_; });
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_VU: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_245, 3);
    V v_g_2419;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_g_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_stx_2420 = heff_take_field(v_g_2419, 0);
    V v_val_2421 = heff_get_n(v_g_2419, 1, 2);
    V v_t_2424 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_stx_2420}), heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam5, 1, 1, (V[]){v_val_2421})});
    V f_ = v_k_246;
    args[0] = v_t_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    heff_take_n(v_x_2415, 0ULL, 5);
    heff_drop(v_x_247);
    V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2432}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2433;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VFunction: {
    heff_take_n(v_x_2415, 0ULL, 6);
    heff_drop(v_x_247);
    V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2442}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2443;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VRecord: {
    heff_take_n(v_x_2415, 0ULL, 4);
    heff_drop(v_x_247);
    V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2450}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2451;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_ru_24x_2415_24VSum = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2454 = heff_tag_at_n(v_ru_24x_2415_24VSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2455}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2456;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_x_247);
    V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2459}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2460;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_x_247);
    V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2463}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2464;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimString: {
    heff_drop(v_x_247);
    V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2467}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2468;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimRune: {
    heff_drop(v_x_247);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2471}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2472;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimArray: {
    V v_ru_24x_2415_24VPrimArray = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag_at_n(v_ru_24x_2415_24VPrimArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2476}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2477;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VFixed: {
    V v_ru_24x_2415_24VFixed = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_drop(v_x_247);
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2480 = heff_tag_at_n(v_ru_24x_2415_24VFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2481}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2482;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam3, 1, 1, (V[]){heff_dup(v_x_247)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam4, 1, 4, (V[]){v_x_247, v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_hd_245, v_k_246, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_str0, 11, "the literal");
Clo g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(V v_lit_240, V v_sp_241, V v_e_242, V v_a_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_243)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_246, 0ULL, 3);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeInt: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    V v_t_2416 = heff_take_field(v_lit_240, 0);
    double v_x_2418;
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      double v_x_2417 = (g_std_2emath_2efromDecimal_w(heff_take_field(v_lit_240, 1), heff_get_n(v_lit_240, 2, 3)));
      v_x_2418 = ((-1.0) * v_x_2417);
    } else {
      heff_drop(v_t_2416);
      v_x_2418 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_lit_240, 1)), heff_get_n(v_lit_240, 2, 3)));
    }
    V v_t_2419;
    if (((v_x_2418 - v_x_2418) == (0.0))) {
      v_t_2419 = heff_floatShow(heff_box_f64(v_x_2418));
    } else {
      v_t_2419 = ((V)&g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_str0);
    }
    return (g_heff_2eelab_2erules_2eatFloat64_w(v_sp_241, v_t_2419, v_x_2418, v_z_244, v_z_245));
  }
  case TAG_LikeString: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeRune: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeFixed: {
    V v_w_2421 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    return ({ V a_0 = v_sp_241; V a_1 = v_e_242; V a_2 = v_a_243; V a_3 = v_w_2421; V a_4 = v_lit_240; V a_5 = v_z_244; V a_6 = v_z_245; V r_ = (g_heff_2eelab_2erules_2efracAtFixed(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_2421); r_; });
  }
  case TAG_NoRules: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(a[0], a[1], a[2], a[3], a[4], a[5]);
}