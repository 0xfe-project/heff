// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_prelude_2eparseInt_2edigitsFrom_240_24cpr(V, V, V);

HeffT2 g_prelude_2eparseInt_2edigitsFrom_240_24cpr(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_242}});
  } else {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)57ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)48ULL));
      V v_t_244 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), heff_box_word(v_t_243));
      V t_0 = v_s_240;
      V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
      V t_2 = v_t_244;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}