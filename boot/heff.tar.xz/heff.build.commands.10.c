// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_MakeDirectory 16793
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteFile 62589
#define LBL_alias 294261354
#define LBL_bin 307073
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_watches 1357821955
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2enameByteOf(V, V);
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eproject_2eisNameByte(V);
V g_heff_2ebuild_2eproject_2eisNameByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNameByte_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_list_2esortBy_24s390982605x1732870695(V);
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a);
extern Clo g_list_2esortBy_24s390982605x1732870695_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_rest_243);
      V v_f_245 = heff_get_n(v_s_242, 2, 8);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
    } else {
      heff_drop_rec(v_s_242, 8);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0, 5, "check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_i_241, 0)), ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0))) {
      heff_drop(v_rest_242);
      V v_t_244 = heff_get_n(v_i_241, 1, 3);
      V v_f_246;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop_rec(v_i_241, 3);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str0, 26, "abcdefghijklmnopqrstuvwxyz");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str2, 1, "_");
Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameByteOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enameByteOf(V v_s_240, V v_i_241) {
top: ;
  if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)65ULL));
      int64_t v_t_245 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 2)) - ((int64_t)64ULL));
      return heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str0), heff_box_word(v_t_244), heff_box_word(v_t_245));
    } else {
      V v_t_246 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
      } else {
        heff_drop(v_i_241);
        heff_drop(v_t_246);
        return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str1);
      }
    }
  } else {
    V v_t_247 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
    } else {
      heff_drop(v_i_241);
      heff_drop(v_t_247);
      return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str2);
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameByteOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str2, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str3, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str4, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str5, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str6, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str8, 8, "heff run");
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548(V v_rep_240, V v_prog_241, V v_file_242, V v_progArgs_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam0, 2, 5, (V[]){v_c_244, v_prog_241, v_file_242, v_rep_240, v_progArgs_243});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam4(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_cmd_2426 = heff_env(self)[0];
  V v_progArgs_243 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2426, v_progArgs_243, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_hd_2436, v_k_2437));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam8(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_t_2428 = heff_env(self)[0];
  V v_cmd_2426 = heff_env(self)[1];
  V v_progArgs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s495635622x733177935(v_t_2428, heff_dup(v_hd_2436), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam9, 1, 4, (V[]){v_cmd_2426, v_progArgs_243, v_hd_2436, v_k_2437})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_dir_2416 = heff_env(self)[3];
  V v_out_2421 = heff_env(self)[4];
  V v_t_2428 = heff_env(self)[5];
  V v_cmd_2426 = heff_env(self)[6];
  V v_progArgs_243 = heff_env(self)[7];
  V v_hd_2431 = heff_env(self)[8];
  V v_k_2432 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_get_n(heff_get_n(v_x_247, 2, 5), 5, 6);
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str7), NTAG(TAG_Nil)});
  return ({ V a_0 = MK_INT(1LL); V a_1 = v_prog_241; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str8); V a_3 = v_t_2434; V a_4 = v_t_2435; V a_5 = v_x_2410; V a_6 = v_dir_2416; V a_7 = v_out_2421; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam8, 2, 3, (V[]){v_t_2428, v_cmd_2426, v_progArgs_243}); V a_9 = v_hd_2431; V a_10 = v_k_2432; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_t_2430 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_dir_2416 = heff_env(self)[4];
  V v_out_2421 = heff_env(self)[5];
  V v_t_2428 = heff_env(self)[6];
  V v_cmd_2426 = heff_env(self)[7];
  V v_progArgs_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_co_2eop_24s495635622x733177935(v_t_2430, heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam7, 1, 10, (V[]){v_x_247, v_prog_241, v_x_2410, v_dir_2416, v_out_2421, v_t_2428, v_cmd_2426, v_progArgs_243, v_hd_2431, v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_progArgs_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_247, 2)), heff_dup(v_file_242)));
  V v_outPath_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str1));
  V v_dir_2416 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_247, 2)), heff_dup(v_file_242)));
  V v_paths_2417 = heff_dup(heff_rfield(v_x_247, 2));
  V v_d_2418 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2417), heff_dup(v_file_242)));
  V v_t_2419 = heff_dup(heff_rfield(v_paths_2417, 5));
  V v_t_2420;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Posix: {
    v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str2);
    break;
  }
  case TAG_Windows: {
    v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str3);
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  V v_out_2421 = ({ V b_0 = heff_get_n(v_paths_2417, 5, 6); V a_1 = v_d_2418; V a_2 = v_t_2420; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_paths_2422 = heff_dup(heff_rfield(v_x_247, 2));
  V v_d_2423 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2422), heff_dup(v_file_242)));
  V v_t_2424 = heff_dup(heff_rfield(v_paths_2422, 5));
  V v_t_2425;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Posix: {
    v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str4);
    break;
  }
  case TAG_Windows: {
    v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str5);
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_cmd_2426 = ({ V b_0 = heff_get_n(v_paths_2422, 5, 6); V a_1 = v_d_2423; V a_2 = v_t_2425; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2427 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2410), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2427}));
  V v_t_2429 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2429}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(MK_INT(1LL), v_rep_240, heff_dup(v_x_247), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str6)}), v_outPath_2415, v_file_242, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam6, 2, 9, (V[]){v_t_2430, v_x_247, v_prog_241, v_x_2410, v_dir_2416, v_out_2421, v_t_2428, v_cmd_2426, v_progArgs_243}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_progArgs_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam5, 1, 8, (V[]){v_x_247, v_file_242, v_x_2410, v_prog_241, v_rep_240, v_progArgs_243, v_hd_245, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_progArgs_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_242), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam3, 1, 7, (V[]){v_prog_241, v_hd_245, v_x_247, v_file_242, v_rep_240, v_progArgs_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_progArgs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_lam1, 1, 6, (V[]){v_prog_241, v_file_242, v_hd_245, v_rep_240, v_progArgs_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_str0), heff_dup(heff_rfield(v_c_243, 6))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam1, 2, 3, (V[]){heff_dup(v_c_243), v_t_245, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_243, 6, 14); V r_ = (g_list_2efoldl_24f1046331721x1909432377(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2412 = heff_intAdd(v_t_2411, v_x_2410);
  V f_ = v_k_247;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_c_249 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam3, 1, 2, (V[]){v_c_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(heff_dup(heff_rfield(v_c_243, 0)), v_t_245, MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_lam2, 1, 4, (V[]){v_rest_244, v_hd_246, v_c_243, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(V v_rep_240, V v_file_241, V v_badL_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_243)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam0, 1, 5, (V[]){v_cs_243, heff_dup(v_badL_242), v_z_244, v_z_245, v_file_241})});
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam1(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2439);
    V v_t_2440 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_z_244, v_z_245));
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_badL_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_file_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_247);
  HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_243)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2410;
      if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
        heff_drop(v_cs_243);
        heff_drop(v_badL_242);
        heff_drop(v_file_241);
        heff_drop_rec(v_c_2412, 14);
        V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_z_244, v_z_245));
      } else {
        heff_drop(v_badL_242);
        V v_t_2420 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_243); r_; });
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_file_241);
          heff_drop_rec(v_c_2412, 14);
          heff_drop(v_t_2420);
          V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
          V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
          return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_244, v_z_245));
        } else {
          heff_drop(v_t_2420);
          V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
          V v_t_2429 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2428));
          V v_t_2430 = (g_list_2esortBy_24s390982605x1732870695(v_t_2429));
          V v_str_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str1); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str2); V a_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_str3); V b_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2412, 3, 14); V a_7 = v_t_2430; V r_ = (g_list_2efoldl_24s1149369025x804005338(a_0, a_1, b_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(v_t_2430); r_; });
          V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_file_241, v_str_2431, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam1_clo)})});
          V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
          V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
          V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
          return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_lam2, 1, 2, (V[]){v_z_245, v_z_244})));
        }
      }
    } else {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      heff_drop(v_file_241);
      heff_drop(v_field_2410);
      V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_z_244, v_z_245));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833(V v_rep_240, V v_file_241, V v_outPath_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam0, 2, 4, (V[]){v_c_243, v_rep_240, v_file_241, v_outPath_242});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_outPath_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_rep_240; V a_1 = v_file_241; V a_2 = v_outPath_242; V b_3 = heff_intLt(MK_INT(0LL), v_x_247); V a_4 = heff_get_n(v_x_249, 0, 2); V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644(a_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(v_file_241); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_246));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam3, 1, 6, (V[]){v_rep_240, v_file_241, v_outPath_242, v_x_247, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_str0), heff_dup(heff_rfield(v_x_246, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam2, 1, 6, (V[]){v_x_246, v_hd_244, v_rep_240, v_file_241, v_outPath_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_lam1, 1, 5, (V[]){v_hd_244, v_rep_240, v_file_241, v_outPath_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731(V v_prog_240, V v_st_241, V v_t_242, V v_next_243, V v_progs_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam0_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam1, 1, 7, (V[]){heff_dup(v_progs_244), v_t_242, v_prog_240, v_hd_245, heff_dup(v_st_241), v_next_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731(a[0], a1, a[2], a[3], a4, a[5], a[6]); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam0(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam2(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2425);
  V f_ = v_next_243;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_t_2422 = heff_env(self)[0];
  V v_next_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2422, heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam5, 1, 3, (V[]){v_next_243, v_hd_2423, v_k_2424})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_next_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2420), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2421}));
  V v_t_2426 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_x_2420; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam4, 2, 2, (V[]){v_t_2422, v_next_243}); V a_5 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2415);
  V v_total_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_str0), heff_dup(heff_rfield(v_t_242, 1)));
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2417, v_total_2416, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1149334953x1213534731_lam3, 1, 7, (V[]){v_prog_240, v_st_241, v_t_242, v_next_243, v_progs_244, v_hd_245, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s495635622x733177935(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam2(V self, V *args) {
  V v_v_2413 = args[0];
  return v_v_2413;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam4(V self, V *args) {
  V v_d_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = (g_std_2epath_2ejoin(v_st_240, v_d_2428, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str5)));
  V v_t_2430 = ({ V a_0 = v_st_240; V a_1 = v_bin_241; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str6); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2429, v_t_2430);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_path_2423 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_path_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_sep_2425;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str2))) {
    v_sep_2425 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str3);
  } else {
    v_sep_2425 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str4);
  }
  V v_t_2427;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2425, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2425);
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2423, NTAG(TAG_Nil)});
  } else {
    v_t_2427 = ({ V a_0 = v_sep_2425; V a_1 = v_path_2423; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2425, v_path_2423, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_2425); heff_drop(v_path_2423); r_; });
  }
  V v_t_2431 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2427; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2427); r_; });
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    heff_drop(v_t_2431);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2431);
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str8)));
    V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str9)), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_242, v_k_243));
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s495635622x733177935(v_t_2420, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_lam3, 1, 5, (V[]){v_x_2412, v_st_240, v_bin_241, v_k_243, v_hd_242})));
}