// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Move 53768
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_WaitAny 37499
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_checked 974171621
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_goldens 436112074
#define LBL_hash 9690581
#define LBL_implicit 319715269
#define LBL_loaded 849622832
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_seen 10021698
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_version 583465758
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_clo;
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enameByteOf(V, V);
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo;
V g_heff_2ebuild_2ecommands_2eprogramAdded(V, V);
V g_heff_2ebuild_2ecommands_2eprogramAdded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramAdded_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_clo;
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862(V, V, V);
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eproject_2eisNameByte(V);
V g_heff_2ebuild_2eproject_2eisNameByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNameByte_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT3 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s867280822x823468083(V, V);
V g_list_2efilter_24s867280822x823468083_entry(V self, V *a);
extern Clo g_list_2efilter_24s867280822x823468083_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1951926392x340347826(V, V, V);
V g_list_2emap_24s1951926392x340347826_entry(V self, V *a);
extern Clo g_list_2emap_24s1951926392x340347826_clo;
V g_list_2emap_24s492917103x1503990573(V);
V g_list_2emap_24s492917103x1503990573_entry(V self, V *a);
extern Clo g_list_2emap_24s492917103x1503990573_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_rest_243);
      V v_f_245 = heff_get_n(v_s_242, 1, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
    } else {
      heff_drop_rec(v_s_242, 7);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0, 5, "check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_i_241, 0)), ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0))) {
      heff_drop(v_rest_242);
      V v_t_244 = heff_get_n(v_i_241, 1, 3);
      V v_f_246;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop_rec(v_i_241, 3);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramAdded_str0, 45, "its file does not import check, which runs it");
V g_heff_2ebuild_2ecommands_2eprogramAdded_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprogramAdded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramAdded_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprogramAdded(V v_p_240, V v_src_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_src_241, 5), heff_take_field(v_src_241, 3)));
  HeffT3 v_t_243 = ({ V b_0 = heff_get_n(v_src_241, 4, 7); V a_1 = v_t_242; HeffT3 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    v_t_247 = v_field_244;
  }
  HeffT2 v_t_248 = (g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_q_2412 = v_field_2410;
      V v_l_2413 = heff_dup(heff_rfield(v_p_240, 5));
      V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_p_240, 6)), 0, 13);
      V v_c_2415 = heff_take_field(v_p_240, 6);
      V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2eprogramAdded_lam0, 1, 1, (V[]){heff_dup(v_c_2415)}), heff_dup(heff_rfield(v_c_2415, 7))));
      V v_t_2418 = (g_heff_2ebuild_2edriver_2erootsAmong(v_c_2415, v_t_2417));
      V v_t_2419 = (g_heff_2ebuild_2ecommands_2eintegrationText(v_q_2412, v_t_2418));
      V v_t_2420 = heff_get_n(heff_get_n(v_p_240, 5, 7), 0, 5);
      V v_sources_2421 = ({ V a_0 = v_t_2414; V a_1 = v_t_2419; V a_2 = v_t_2420; V r_ = (g_list_2emap_24s1951926392x340347826(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
      V v_t_2422 = ({ V rv_0 = v_sources_2421; V rr_ = heff_rec_reuse_nf(v_l_2413, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2422});
    } else {
      heff_drop_rec(v_p_240, 7);
      heff_drop(v_field_2410);
      return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramAdded_str0)});
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprogramAdded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramAdded(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprogramAdded_lam0(V self, V *args) {
  V v_o_2416 = args[0];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_2415, v_o_2416));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str0, 26, "abcdefghijklmnopqrstuvwxyz");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str2, 1, "_");
Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameByteOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enameByteOf(V v_s_240, V v_i_241) {
top: ;
  if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)65ULL));
      int64_t v_t_245 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 2)) - ((int64_t)64ULL));
      return heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str0), heff_box_word(v_t_244), heff_box_word(v_t_245));
    } else {
      V v_t_246 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
      } else {
        heff_drop(v_i_241);
        heff_drop(v_t_246);
        return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str1);
      }
    }
  } else {
    V v_t_247 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
    } else {
      heff_drop(v_i_241);
      heff_drop(v_t_247);
      return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str2);
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameByteOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(V v_sel_240, V v_jobs_241, V v_x3_242, V v_running_243, V v_done_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_running_243)) {
    case TAG_Nil: {
      heff_drop(v_jobs_241);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam0, 2, 1, (V[]){v_done_244});
    }
    case TAG_Cons: {
      V v_ss_249 = (g_list_2emap_24s492917103x1503990573(heff_dup(v_running_243)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam1, 2, 5, (V[]){v_ss_249, heff_dup(v_sel_240), v_running_243, v_done_244, v_jobs_241});
    }
    default: return heff_nomatch(v_running_243);
    }
  }
  case TAG_Cons: {
    V v_j_2430 = heff_field(v_x3_242, 0);
    V v_rest_2431 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_running_243));
    if (heff_intLt_c_lent(v_t_2432, v_jobs_241, 1)) {
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam5, 2, 6, (V[]){v_j_2430, v_running_243, v_done_244, heff_dup(v_sel_240), v_jobs_241, v_rest_2431});
    } else {
      V v_ss_2444 = (g_list_2emap_24s492917103x1503990573(heff_dup(v_running_243)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam7, 2, 7, (V[]){v_ss_2444, heff_dup(v_sel_240), v_running_243, v_j_2430, v_rest_2431, v_done_244, v_jobs_241});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_done_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_done_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam2(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_running_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_jobs_241 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2421)));
  V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2427;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    heff_drop_tag(v_running_243, 2);
    v_t_2427 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x21_2424 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_x21_2424)) {
    case TAG_MkPair: {
      V v_proc_2425 = heff_field(v_x21_2424, 0);
      heff_take_n(v_x21_2424, 1ULL, 2);
      v_t_2427 = ({ V a_0 = v_proc_2425; V a_1 = v_running_243; V r_ = (g_list_2efilter_24s867280822x823468083(a_0, a_1)); heff_drop(v_proc_2425); r_; });
      break;
    }
    default: heff_nomatch(v_x21_2424);
    }
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2428 = (g_prelude_2e_2b_2b(v_x_2421, v_done_244));
  V v_t_2429 = ({ V a_0 = v_sel_240; V a_1 = v_jobs_241; V a_2 = v_t_2423; V a_3 = v_t_2427; V a_4 = v_t_2428; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sel_240); r_; });
  V f_ = v_t_2429;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_sel_240 = heff_env(self)[0];
  V v_running_243 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_done_244 = heff_env(self)[3];
  V v_jobs_241 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420 = (g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(v_sel_240, heff_dup(v_running_243), heff_dup(v_x_2419)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam4, 1, 7, (V[]){v_x_2419, v_running_243, v_done_244, v_sel_240, v_jobs_241, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_ss_249 = heff_env(self)[0];
  V v_sel_240 = heff_env(self)[1];
  V v_running_243 = heff_env(self)[2];
  V v_done_244 = heff_env(self)[3];
  V v_jobs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WaitAny, 2, (V[]){v_ss_249, ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam3, 1, 6, (V[]){v_sel_240, v_running_243, v_hd_2410, v_done_244, v_jobs_241, v_k_2411})));
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_running_243 = heff_env(self)[0];
  V v_done_244 = heff_env(self)[1];
  V v_sel_240 = heff_env(self)[2];
  V v_jobs_241 = heff_env(self)[3];
  V v_rest_2431 = heff_env(self)[4];
  V v_hd_2434 = heff_env(self)[5];
  V v_k_2435 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2439;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    v_t_2439 = v_running_243;
    break;
  }
  case TAG_Right: {
    V v_r_2438 = heff_dup(heff_field(v_x_2436, 0));
    v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2438, v_running_243});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_t_2442;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_f_2440 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2440, v_done_244});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2436, 0ULL, 1);
    v_t_2442 = v_done_244;
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_t_2443 = ({ V a_0 = v_sel_240; V a_1 = v_jobs_241; V a_2 = v_rest_2431; V a_3 = v_t_2439; V a_4 = v_t_2442; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sel_240); r_; });
  V f_ = v_t_2443;
  heff_room[0] = v_hd_2434;
  heff_room[1] = v_k_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_j_2430 = heff_env(self)[0];
  V v_running_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_jobs_241 = heff_env(self)[4];
  V v_rest_2431 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862(v_j_2430, heff_dup(v_hd_2434), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam6, 1, 7, (V[]){v_running_243, v_done_244, v_sel_240, v_jobs_241, v_rest_2431, v_hd_2434, v_k_2435})));
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam8(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_j_2430 = heff_env(self)[0];
  V v_rest_2431 = heff_env(self)[1];
  V v_x_2454 = heff_env(self)[2];
  V v_running_243 = heff_env(self)[3];
  V v_done_244 = heff_env(self)[4];
  V v_sel_240 = heff_env(self)[5];
  V v_jobs_241 = heff_env(self)[6];
  V v_hd_2445 = heff_env(self)[7];
  V v_k_2446 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2456)));
  V v_t_2458 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2457; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2457); r_; });
  V v_t_2459 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_j_2430, v_rest_2431}), v_t_2458));
  V v_t_2463;
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    heff_drop(v_running_243);
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x21_2460 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    switch (heff_tag_of(v_x21_2460)) {
    case TAG_MkPair: {
      V v_proc_2461 = heff_field(v_x21_2460, 0);
      heff_take_n(v_x21_2460, 1ULL, 2);
      v_t_2463 = ({ V a_0 = v_proc_2461; V a_1 = v_running_243; V r_ = (g_list_2efilter_24s867280822x823468083(a_0, a_1)); heff_drop(v_proc_2461); r_; });
      break;
    }
    default: heff_nomatch(v_x21_2460);
    }
    break;
  }
  default: heff_nomatch(v_x_2454);
  }
  V v_t_2464 = (g_prelude_2e_2b_2b(v_x_2456, v_done_244));
  V v_t_2465 = ({ V a_0 = v_sel_240; V a_1 = v_jobs_241; V a_2 = v_t_2459; V a_3 = v_t_2463; V a_4 = v_t_2464; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sel_240); r_; });
  V f_ = v_t_2465;
  heff_room[0] = v_hd_2445;
  heff_room[1] = v_k_2446;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_sel_240 = heff_env(self)[0];
  V v_running_243 = heff_env(self)[1];
  V v_hd_2445 = heff_env(self)[2];
  V v_j_2430 = heff_env(self)[3];
  V v_rest_2431 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_jobs_241 = heff_env(self)[6];
  V v_k_2446 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2455 = (g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(v_sel_240, heff_dup(v_running_243), heff_dup(v_x_2454)));
  V f_ = v_c_2455;
  heff_room[0] = heff_dup(v_hd_2445);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam10, 1, 9, (V[]){v_j_2430, v_rest_2431, v_x_2454, v_running_243, v_done_244, v_sel_240, v_jobs_241, v_hd_2445, v_k_2446});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_ss_2444 = heff_env(self)[0];
  V v_sel_240 = heff_env(self)[1];
  V v_running_243 = heff_env(self)[2];
  V v_j_2430 = heff_env(self)[3];
  V v_rest_2431 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_jobs_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WaitAny, 2, (V[]){v_ss_2444, ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam8_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s94900133x232571340(v_t_2453, heff_dup(v_hd_2445), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1269914168x297150307_lam9, 1, 8, (V[]){v_sel_240, v_running_243, v_hd_2445, v_j_2430, v_rest_2431, v_done_244, v_jobs_241, v_k_2446})));
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(v_update_240, heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam2, 2, 4, (V[]){v_c_2410, heff_dup(v_update_240), v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(a_0, a_1, a_2)); heff_drop(v_update_240); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam0, 2, 1, (V[]){v_c_241});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897(a[0]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_cs_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_248));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2412;
      V v_t_2415 = (g_heff_2ebuild_2equery_2eexplain(v_c_2414));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(v_t_2415, v_hd_242, v_k_243));
    } else {
      heff_drop(v_field_2412);
      V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_242, v_k_243));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_cs_248 = heff_get_n(v_x_247, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_248), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam4, 1, 3, (V[]){v_cs_248, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam3, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam2, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1346226202x1588123897_lam1, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_str0, 5, ".hash");
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = (g_list_2efilter_24s2128134357x1680551385(heff_rfield(v_x_245, 0), heff_take_field(v_root_241, 2)));
  V v_x_2438;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_245, 3);
      v_x_2438 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2421 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      V v_t_2422 = (g_prelude_2eskipSpaces(v_t_2421, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_t_2421, 0)) - ((int64_t)1ULL));
      V v_t_2424 = (g_prelude_2eskipSpaces(v_t_2421, heff_box_word(v_t_2423), MK_INT(-1LL)));
      V v_t_2425 = heff_strSlice(v_t_2421, v_t_2422, heff_intAdd(v_t_2424, MK_INT(1LL)));
      V v_t_2426 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2425});
      v_x_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2427 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Cons = heff_take_reuse_n(v_t_2420, 1ULL, 2);
    V v_t_2429 = (g_list_2efilter_24s50027113x1989932102(v_r_2427, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2419)) {
      case TAG_Nothing: {
        heff_drop_rec(v_x_245, 3);
        heff_drop_cell(v_ru_24t_2420_24Cons, 2);
        v_x_2438 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2430 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 1);
        V v_t_2431 = (g_prelude_2eskipSpaces(v_t_2430, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_t_2430, 0)) - ((int64_t)1ULL));
        V v_t_2433 = (g_prelude_2eskipSpaces(v_t_2430, heff_box_word(v_t_2432), MK_INT(-1LL)));
        V v_t_2434 = heff_strSlice(v_t_2430, v_t_2431, heff_intAdd(v_t_2433, MK_INT(1LL)));
        V v_t_2435 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2434});
        v_x_2438 = heff_tag_at_n(v_ru_24t_2420_24Cons, TAG_Cons, 2, (V[]){v_t_2435, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2419);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2429, 0ULL, 2);
      heff_drop(v_x_2419);
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24t_2420_24Cons, 2);
      v_x_2438 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V f_ = v_k_249;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_x_245, 1))));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_str0));
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam3_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), v_hd_248, heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam4, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_n_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_244, heff_dup(v_n_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam0_clo)})}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam1, 2, 7, (V[]){v_t_248, v_n_246, heff_dup(v_st_241), v_home_243, v_t_242, v_prog_240, v_next_245});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam3(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam5(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam9(V self, V *args) {
  V v_ok_2439 = args[0];
  return v_ok_2439;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam11(V self, V *args) {
  V v_ok_2447 = args[0];
  return v_ok_2447;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam14(V self, V *args) {
  V v_x_2459 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2457 = heff_env(self)[1];
  V v_k_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2459);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2457;
  heff_room[1] = v_k_2458;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam13(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_t_2456 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_2456, heff_dup(v_hd_2457), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam14, 1, 3, (V[]){v_next_245, v_hd_2457, v_k_2458})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam12(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_x_2415 = heff_env(self)[7];
  V v_next_245 = heff_env(self)[8];
  V v_hd_249 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2454 = ({ V a_0 = v_st_241; V a_1 = v_home_243; V a_2 = v_n_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2455 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2455}));
  return ({ V a_0 = v_t_242; V a_1 = v_x_2413; V a_2 = v_x_2415; V a_3 = v_t_2454; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam13, 2, 2, (V[]){v_t_2456, v_next_245}); V a_5 = v_x_2453; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2453); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_x_2415 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2445);
  V v_to_2446 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), heff_dup(v_n_246)));
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){heff_dup(v_x_2413), v_to_2446, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam11_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam12, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2411, v_prog_240, v_t_242, v_x_2413, v_x_2415, v_next_245, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam15(V self, V *args) {
  V v_ok_2460 = args[0];
  return v_ok_2460;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam17(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam16(V self, V *args) {
  V v_x_2466 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2466);
  V v_t_2467 = ({ V a_0 = v_st_241; V a_1 = heff_get_n(v_t_242, 0, 6); V a_2 = v_n_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2468 = heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str4), v_x_2413));
  V v_why_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str5), v_t_2468);
  V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str6), v_why_2469), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str7));
  V v_t_2471 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2470, NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2476}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam17, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_t_242 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
    heff_drop(v_x_2437);
    V v_path_2438 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), heff_dup(v_n_246)));
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_path_2438, heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam9_clo)})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam10, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2413, v_hd_249, v_x_2411, v_prog_240, v_t_242, v_x_2415, v_next_245, v_k_2410})));
  } else {
    heff_drop(v_x_2437);
    heff_drop(v_home_243);
    heff_drop(v_x_2415);
    heff_drop(v_x_2411);
    heff_drop(v_prog_240);
    heff_drop(v_next_245);
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam15_clo)})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam16, 1, 6, (V[]){v_st_241, v_t_242, v_n_246, v_x_2413, v_hd_249, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_home_243 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2429);
  V v_path_2430 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), heff_dup(v_n_246)));
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2430, heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam7_clo)})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam8, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2415, v_hd_249, v_x_2413, v_x_2411, v_prog_240, v_t_242, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_n_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_home_243 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2422);
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam6, 1, 11, (V[]){v_st_241, v_t_242, v_n_246, v_x_2413, v_hd_249, v_home_243, v_x_2415, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str0), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str1)));
  V v_x_2413 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), v_t_2412));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str2), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_str3)));
  V v_x_2415 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), v_t_2414));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam4, 1, 11, (V[]){v_x_2415, v_hd_249, v_st_241, v_t_242, v_n_246, v_x_2413, v_home_243, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_246 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_home_243 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_lam2, 1, 8, (V[]){v_n_246, v_st_241, v_home_243, v_hd_249, v_t_242, v_prog_240, v_next_245, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848(V v_prog_240, V v_st_241, V v_cmd_242, V v_t_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str0)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_c_248 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_t_247, NTAG(TAG_Nil)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam0, 1, 6, (V[]){v_prog_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam7(V self, V *args) {
  V v_ns_2453 = args[0];
  return v_ns_2453;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam9(V self, V *args) {
  V v_t_2463 = args[0];
  return v_t_2463;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam13(V self, V *args) {
  V v_x_2487 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2487);
  V v_t_2488 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2493}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam12(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2473);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2470, 1)))) {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    V v_n_2475 = heff_get_n(v_x_2470, 1, 2);
    V v_t_2477;
    if (heff_intEq_c_lent(v_n_2475, MK_INT(1LL), 2)) {
      heff_drop(v_n_2475);
      v_t_2477 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str17);
    } else {
      v_t_2477 = heff_strAppend(heff_intShow(v_n_2475), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str18));
    }
    V v_what_2478 = heff_strAppend(v_t_2477, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str19));
    V v_t_2479 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str20), heff_strAppend(v_what_2478, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str21)));
    V v_t_2480 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str22), heff_strAppend(v_cmd_242, v_t_2479));
    V v_t_2481 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str23)), NTAG(TAG_MkUnit)});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2486}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam13, 1, 2, (V[]){v_z_244, v_z_245})));
  } else {
    heff_drop(v_cmd_242);
    V v_t_2494 = heff_dup(heff_rfield(v_x_2470, 0));
    switch (heff_tag_of(v_t_2494)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2470, 2);
      heff_drop(v_z_244);
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      heff_drop_rec(v_t_243, 6);
      V f_ = v_z_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_2494, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086(v_prog_240, v_st_241, v_t_243, heff_get_n(v_x_2470, 0, 2), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_t_2494);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2471 = heff_tag_n(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2471}));
  return (g_co_2eop_24s94900133x232571340(v_t_2472, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam12, 1, 7, (V[]){v_x_2470, v_cmd_242, v_z_244, v_z_245, v_prog_240, v_st_241, v_t_243})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_cmd_242 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2466 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2468;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2468 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2467 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2469 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_243), heff_dup(v_x_2465), v_t_2466, v_t_2468));
  V f_ = v_c_2469;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam11, 1, 7, (V[]){v_x_2465, v_prog_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2461;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2460 = heff_dup(heff_field(v_x_2459, 0));
    v_t_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_total_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2461; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2461); r_; });
  V v_t_2464 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str16), v_total_2462, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam9_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2464, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam10, 1, 7, (V[]){v_x_2459, v_prog_240, v_st_241, v_t_243, v_z_244, v_cmd_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2451);
  V v_path_2452 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str15)));
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_2452, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam7_clo)})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam8, 1, 6, (V[]){v_prog_240, v_z_244, v_st_241, v_t_243, v_cmd_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2419);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2416, 1)))) {
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    heff_drop(v_prog_240);
    V v_n_2421 = heff_get_n(v_x_2416, 1, 2);
    V v_t_2423;
    if (heff_intEq_c_lent(v_n_2421, MK_INT(1LL), 2)) {
      heff_drop(v_n_2421);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str2);
    } else {
      v_t_2423 = heff_strAppend(heff_intShow(v_n_2421), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str3));
    }
    V v_what_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str4));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str5), heff_strAppend(v_what_2424, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str6)));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str7), heff_strAppend(v_cmd_242, v_t_2425));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str8)), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam5, 1, 2, (V[]){v_z_244, v_z_245})));
  } else {
    V v_n_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2416, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2442;
    if (heff_intEq_c_lent(v_n_2440, MK_INT(1LL), 2)) {
      heff_drop(v_n_2440);
      v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str9);
    } else {
      v_t_2442 = heff_strAppend(heff_intShow(v_n_2440), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str10));
    }
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str11), heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str12)));
    V v_str_2444 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str13), heff_strAppend(heff_dup(v_cmd_242), v_t_2443));
    V v_t_2445 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2444, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str14)), NTAG(TAG_MkUnit)});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam6, 1, 6, (V[]){v_st_241, v_t_243, v_z_244, v_prog_240, v_cmd_242, v_z_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2417}));
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam4, 1, 7, (V[]){v_x_2416, v_cmd_242, v_z_244, v_z_245, v_st_241, v_t_243, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2415 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_x_2413); V a_2 = v_t_2414; V a_3 = v_x_249; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam3, 1, 7, (V[]){v_x_2413, v_prog_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_cmd_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_total_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_249));
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_str1), v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam1_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2412, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_lam2, 1, 7, (V[]){v_prog_240, v_x_249, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243})));
}