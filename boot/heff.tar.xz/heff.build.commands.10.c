// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_checked 974171621
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_loaded 849622832
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_seed 10021688
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_watches 1357821955
#define LBL_wrong 314763719
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_file__wrong__reports__outcomes__integrations__loaded__checked[] = {LBL_file, LBL_wrong, LBL_reports, LBL_outcomes, LBL_integrations, LBL_loaded, LBL_checked};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666(V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enameByteOf(V, V);
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_clo;
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
HeffT2 g_heff_2ebuild_2edriver_2erunTests_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eproject_2eisNameByte(V);
V g_heff_2ebuild_2eproject_2eisNameByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNameByte_clo;
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696(V);
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1973550603x1701528639_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1519769500x1591829371(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1519769500x1591829371_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1519769500x1591829371_clo;
V g_list_2ekeepIf_24s1800580503x895008059(V);
V g_list_2ekeepIf_24s1800580503x895008059_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1800580503x895008059_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1927555389x1401173225(V);
V g_list_2emap_24f1927555389x1401173225_entry(V self, V *a);
extern Clo g_list_2emap_24f1927555389x1401173225_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V, V);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_rest_243);
      V v_f_245 = heff_get_n(v_s_242, 2, 8);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
    } else {
      heff_drop_rec(v_s_242, 8);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0, 5, "check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_i_241, 0)), ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str0))) {
      heff_drop(v_rest_242);
      V v_t_244 = heff_get_n(v_i_241, 1, 3);
      V v_f_246;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ecommands_2equalifierOf_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop_rec(v_i_241, 3);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str0, 26, "abcdefghijklmnopqrstuvwxyz");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameByteOf_str2, 1, "_");
Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameByteOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enameByteOf(V v_s_240, V v_i_241) {
top: ;
  if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)65ULL));
      int64_t v_t_245 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 2)) - ((int64_t)64ULL));
      return heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str0), heff_box_word(v_t_244), heff_box_word(v_t_245));
    } else {
      V v_t_246 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
      } else {
        heff_drop(v_i_241);
        heff_drop(v_t_246);
        return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str1);
      }
    }
  } else {
    V v_t_247 = (g_heff_2ebuild_2eproject_2eisNameByte(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
    } else {
      heff_drop(v_i_241);
      heff_drop(v_t_247);
      return ((V)&g_heff_2ebuild_2ecommands_2enameByteOf_str2);
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameByteOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_s_243 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_245 = ({ V a_0 = v_t_244; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_244); r_; });
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0, 2, 4, (V[]){v_c_245, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_247;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_248);
  V v_d_249 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_st_2410 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, v_d_249));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str0)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
  V v_t_2415 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str1), v_b_241));
  V v_c_2416 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(v_t_2414, v_t_2415));
  V f_ = v_c_2416;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2, 1, 2, (V[]){v_k_247, v_id_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str1, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str2, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str6, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str7, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str8, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789(V v_ex_240, V v_argv_241, V v_n_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2415;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam0_clo);
  } else {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str0), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    v_t_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  }
  return heff_tail(v_t_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam1, 1, 5, (V[]){v_hd_243, v_argv_241, v_ex_240, v_n_242, v_k_244})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2439);
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_k_2421;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam6, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_intShow(heff_intAdd(heff_dup(v_n_242), MK_INT(1LL)));
  V v_t_2424 = heff_get_n(v_x_2422, 0, 3);
  V v_t_2428;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Exited: {
    V v_n_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    if (heff_intEq_c(v_n_2425, MK_INT(0LL))) {
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str1);
    } else {
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str2);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str3);
    break;
  }
  case TAG_TimedOut: {
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str4);
    break;
  }
  case TAG_NotRun: {
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str5);
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str6), heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str7)));
  V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str8), heff_strAppend(v_t_2423, v_t_2429));
  V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str9)), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam5, 1, 2, (V[]){v_k_2421, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam4, 1, 3, (V[]){v_n_242, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2453);
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam8(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V f_ = v_k_2444;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam9, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam7(V self, V *args) {
  V v_err_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_err_2442);
  V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_str10), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_hd_2443, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam8, 1, 2, (V[]){v_k_2444, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2457;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2417, v_argv_241, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2419 = (g_std_2eprocess_2ewithProcess_24s1345957496x637138289(heff_dup(v_ex_240), v_t_2418));
  V v_t_2456 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam3, 2, 2, (V[]){v_c_2419, heff_dup(v_n_242)}), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam7, 3, 1, (V[]){v_n_242})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2456, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam10, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_lam2, 1, 5, (V[]){v_argv_241, v_ex_240, v_n_242, v_hd_243, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str0, 10, "heff-test-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str1, 21, "no directory for it: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str2, 5, "win32");
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459(V v_ex_240, V v_sel_241, V v_j_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam1, 1, 5, (V[]){v_hd_243, v_j_242, v_k_244, v_ex_240, heff_dup(v_sel_241)})));
}
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_j_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_sel_241 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    heff_drop(v_x_2413);
    heff_drop(v_ex_240);
    heff_drop(v_sel_241);
    heff_drop(v_hd_243);
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str1), heff_get_n(v_err_2416, 2, 3));
    V v_x_2418 = (g_heff_2ebuild_2ecommands_2ebrokenJob(v_j_242, v_t_2417));
    V f_ = v_k_244;
    args[0] = v_x_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_dir_2419 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_t_2421;
    if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str2))) {
      v_t_2421 = NTAG(TAG_Windows);
    } else {
      v_t_2421 = NTAG(TAG_Posix);
    }
    V v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_dir_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); heff_drop(v_dir_2419); r_; });
    return ({ V a_0 = v_ex_240; V a_1 = v_sel_241; V a_2 = v_j_242; V a_3 = v_t_2422; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sel_241); r_; });
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_sel_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = heff_tr(g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696(((V)&g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_str0)));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_lam2, 1, 6, (V[]){v_j_242, v_k_244, v_x_2413, v_ex_240, v_sel_241, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str1, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str4, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str6, 43, ": checks, but its first line expects errors");
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193(V v_f_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str0), heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str1)));
    V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str2)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam0, 1, 1, (V[]){v_p_243})));
  } else {
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str3), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str4)));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str5)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam1, 1, 2, (V[]){v_f_240, v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  V f_ = v_p_243;
  args[0] = heff_dup(g_heff_2ebuild_2ecommands_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_str6)), NTAG(TAG_Nil)});
  V f_ = v_p_243;
  args[0] = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2422, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str2, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str4, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str6, 13, ": not checked");
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266(V v_rep_240, V v_opts_241, V v_f_242, V v_l_243, V v_cs_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = (g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(v_cs_244));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam0, 1, 6, (V[]){v_cs_244, v_l_243, v_opts_241, v_f_242, v_z_246, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam1(V self, V *args) {
  V v_w_2421 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2421));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam2(V self, V *args) {
  V v_w_2444 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2444));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam3(V self, V *args) {
  V v_w_2462 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2462));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam4(V self, V *args) {
  V v_x_2475 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_cs_244 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_get_n(v_l_243, 1, 5);
  V v_why_2484;
  switch (heff_tag_of(v_t_2476)) {
  case TAG_Nil: {
    HeffT2 v_t_2477 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
    {
      V v_field_2479 = v_t_2477.f[1];
      int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
      if ((v_tag_2478 == ((int64_t)0ULL))) {
        heff_drop(v_f_242);
        V v_x_2481 = v_field_2479;
        v_why_2484 = v_x_2481;
      } else {
        heff_drop(v_field_2479);
        v_why_2484 = heff_strAppend(v_f_242, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str6));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2482 = heff_field(v_t_2476, 0);
    heff_take_n(v_t_2476, 1ULL, 2);
    heff_drop(v_cs_244);
    heff_drop(v_f_242);
    v_why_2484 = v_why_2482;
    break;
  }
  default: heff_nomatch(v_t_2476);
  }
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2484, NTAG(TAG_Nil)});
  V v_x_2486 = heff_tag_n(TAG_Settled, 1, (V[]){heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2485, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)})});
  V f_ = v_z_246;
  args[0] = v_x_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_cs_244 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_244)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_z_245);
      V v_c_2413 = v_field_2411;
      V v_t_2414 = heff_dup(heff_rfield(v_l_243, 1));
      V v_x_2466;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        if (heff_intEq_c(v_x_248, MK_INT(0LL))) {
          heff_drop(v_cs_244);
          HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2erunTests_24cpr(heff_dup(heff_rfield(v_opts_241, 1)), heff_take_field(v_opts_241, 0), heff_dup(v_c_2413)));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
            V v_t_2420 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2419));
            V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam1, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2420));
            V v_t_2423 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
            V v_p_2424 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, NTAG(TAG_Nil), v_t_2423, v_field_2417, v_field_2418, v_l_243, v_c_2413});
            if (heff_strEq_c(heff_get_n(v_opts_241, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str0))) {
              v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
            } else {
              V v_t_2426 = heff_dup(heff_rfield(v_p_2424, 3));
              switch (heff_tag_of(v_t_2426)) {
              case TAG_Nil: {
                V v_t_2427 = heff_dup(heff_rfield(v_p_2424, 4));
                switch (heff_tag_of(v_t_2427)) {
                case TAG_Nil: {
                  heff_drop_rec(v_p_2424, 7);
                  v_x_2466 = heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_t_2427, 0ULL, 2);
                  v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
                  break;
                }
                default: heff_nomatch(v_t_2427);
                }
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2426, 0ULL, 2);
                v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
                break;
              }
              default: heff_nomatch(v_t_2426);
              }
            }
          }
        } else {
          heff_drop_rec(v_opts_241, 4);
          V v_t_2432 = heff_dup(heff_rfield(v_l_243, 1));
          V v_t_2440;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_Nil: {
            HeffT2 v_t_2433 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                V v_x_2437 = v_field_2435;
                v_t_2440 = v_x_2437;
              } else {
                heff_drop(v_field_2435);
                v_t_2440 = heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str1));
              }
            }
            break;
          }
          case TAG_Cons: {
            V v_why_2438 = heff_field(v_t_2432, 0);
            heff_take_n(v_t_2432, 1ULL, 2);
            heff_drop(v_cs_244);
            v_t_2440 = v_why_2438;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_wrong_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
          V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
          V v_t_2443 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2442));
          V v_t_2445 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam2, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2443));
          V v_t_2446 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2445));
          V v_t_2447 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, v_wrong_2441, v_t_2446, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_243, v_c_2413});
          v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2447});
        }
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 0ULL, 2);
        heff_drop(v_x_248);
        heff_drop_rec(v_opts_241, 4);
        V v_t_2450 = heff_dup(heff_rfield(v_l_243, 1));
        V v_t_2458;
        switch (heff_tag_of(v_t_2450)) {
        case TAG_Nil: {
          HeffT2 v_t_2451 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              V v_x_2455 = v_field_2453;
              v_t_2458 = v_x_2455;
            } else {
              heff_drop(v_field_2453);
              v_t_2458 = heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str2));
            }
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2456 = heff_field(v_t_2450, 0);
          heff_take_n(v_t_2450, 1ULL, 2);
          heff_drop(v_cs_244);
          v_t_2458 = v_why_2456;
          break;
        }
        default: heff_nomatch(v_t_2450);
        }
        V v_wrong_2459 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
        V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
        V v_t_2461 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2460));
        V v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam3, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2461));
        V v_t_2464 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2463));
        V v_t_2465 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, v_wrong_2459, v_t_2464, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_243, v_c_2413});
        v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2465});
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      V f_ = v_z_246;
      args[0] = v_x_2466;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x_248);
      heff_drop_rec(v_opts_241, 4);
      heff_drop(v_field_2411);
      V v_t_2467 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str3), heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str4)));
      V v_t_2468 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_str5)), NTAG(TAG_MkUnit)});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_lam4, 1, 4, (V[]){v_l_243, v_cs_244, v_f_242, v_z_246})));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2414 = (g_list_2ekeepIf_24s1800580503x895008059(heff_dup(heff_rfield(v_c_2413, 7))));
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2414));
      V v_t_2423 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
      V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2423); r_; });
      V v_t_2425 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2424));
      V v_xs_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str3); V a_6 = v_t_2425; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2427 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2426));
      V v_c_2428 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(v_sources_241, v_t_2427));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2413, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str7), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0(V self, V *args) {
  V v_o_2415 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2413, heff_rfield(v_o_2415, 1)));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_eff_2420 = v_field_2418;
      V v_t_2421 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2415, 0), heff_get_n(v_o_2415, 1, 2), v_eff_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    } else {
      heff_drop_rec(v_o_2415, 2);
      heff_drop(v_field_2418);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2413 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str4); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str5); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str6); V a_5 = v_x_2429; V r_ = (g_list_2ekeepIf_24s1519769500x1591829371(b_0, a_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2413; V a_6 = v_t_2430; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521(V v_rep_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_done_246, V v_badL_247, V v_checked_248, V v_z_249, V v_z_2410) {
top: ;
  V v_c_2411 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_str0); V a_1 = heff_dup(v_sources_242); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam0, 1, 11, (V[]){v_sources_242, v_checked_248, v_rep_240, v_z_249, heff_dup(v_badL_247), v_z_2410, v_bi_241, v_file_243, heff_dup(v_name_244), v_outPath_245, v_done_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521(a[0], a[1], a[2], a[3], a4, a[5], a[6], a7, a[8], a[9], a[10]); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam1(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_2415), v_sources_242));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2414, v_s_2420));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2421));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_badL_247 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_bi_241 = heff_env(self)[4];
  V v_sources_242 = heff_env(self)[5];
  V v_file_243 = heff_env(self)[6];
  V v_name_244 = heff_env(self)[7];
  V v_outPath_245 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2424);
  if ((heff_dup(v_badL_247) == NTAG(TAG_True))) {
    heff_drop(v_badL_247);
    heff_drop(v_x_2422);
    heff_drop(v_bi_241);
    heff_drop(v_sources_242);
    heff_drop(v_file_243);
    heff_drop(v_name_244);
    heff_drop(v_outPath_245);
    heff_drop(v_done_246);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_z_249, v_z_2410));
  } else {
    heff_drop(v_badL_247);
    V v_t_2432 = (g_list_2eany_24s1740858080x874135214(v_x_2422));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_x_2422);
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_name_244);
      heff_drop(v_outPath_245);
      heff_drop(v_done_246);
      heff_drop(v_t_2432);
      V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_z_249, v_z_2410));
    } else {
      heff_drop(v_t_2432);
      return ({ V a_0 = v_bi_241; V a_1 = v_sources_242; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = v_done_246; V a_6 = v_x_2422; V a_7 = v_z_249; V a_8 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_244); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_checked_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_badL_247 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_bi_241 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_name_244 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_str1); V a_1 = heff_dup(v_sources_242); V a_2 = v_x_2412; V a_3 = heff_dup(v_sources_242); V r_ = (g_list_2emap_24s159228909x554161698(a_0, a_1, a_2, a_3)); heff_drop(v_x_2412); r_; });
  V v_x_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam1, 1, 2, (V[]){heff_dup(v_sources_242), v_x_2414}), v_checked_248));
  V v_c_2423 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_x_2422)));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521_lam2, 1, 10, (V[]){v_badL_247, v_z_249, v_z_2410, v_x_2422, v_bi_241, v_sources_242, v_file_243, v_name_244, v_outPath_245, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(V v_rep_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam0, 2, 6, (V[]){v_c_245, v_rep_240, v_file_243, heff_dup(v_name_241), v_outPath_242, v_done_244});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_249 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2412 = (g_list_2emap_24s1698496827x1884878103(heff_dup(heff_rfield(v_x_2411, 0))));
  V v_t_2413 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_248, 2), heff_take_field(v_x_2411, 1), v_t_2412});
  return ({ V a_0 = v_rep_240; V a_1 = v_t_2413; V a_2 = heff_get_n(v_x_248, 0, 5); V a_3 = v_file_243; V a_4 = v_name_241; V a_5 = v_outPath_242; V a_6 = v_done_244; V b_7 = heff_intLt(MK_INT(0LL), v_x_249); V a_8 = heff_get_n(v_x_2411, 0, 2); V a_9 = v_hd_246; V a_10 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s539602772x1816710521(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7, a_8, a_9, a_10)); heff_drop(v_name_241); heff_drop(b_7); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_248)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam3, 1, 9, (V[]){v_x_248, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_249, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_str0), heff_dup(heff_rfield(v_x_248, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam2, 1, 8, (V[]){v_x_248, v_hd_246, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_lam1, 1, 7, (V[]){v_hd_246, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563(V v_rep_240, V v_file_241, V v_outPath_242, V v_badL_243, V v_cs_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_244)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_lam0, 1, 5, (V[]){v_cs_244, heff_dup(v_badL_243), v_outPath_242, v_z_245, v_z_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_cs_244 = heff_env(self)[0];
  V v_badL_243 = heff_env(self)[1];
  V v_outPath_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_248);
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_244)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2414;
      if ((heff_dup(v_badL_243) == NTAG(TAG_True))) {
        heff_drop(v_cs_244);
        heff_drop(v_badL_243);
        v_t_2414 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_243);
        v_t_2414 = ({ V a_0 = v_cs_244; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_244); r_; });
      }
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 9);
      V v_t_2416 = (g_list_2emap_24f1927555389x1401173225(heff_get_n(v_c_2413, 7, 14)));
      V v_t_2417 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2415, v_t_2416));
      return ({ V a_0 = v_outPath_242; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_z_245; V a_4 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
    } else {
      heff_drop(v_cs_244);
      heff_drop(v_badL_243);
      heff_drop(v_outPath_242);
      heff_drop(v_field_2411);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_z_245, v_z_246));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    HeffT2 v_t_248 = (g_heff_2ebuild_2eproject_2ereadBuild_24cpr(v_text_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2410;
        V v_t_2413 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str0)));
        V v_str_2414 = ({ V a_0 = v_t_2413; V a_1 = v_text_247; V a_2 = v_p_2412; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_text_247); r_; });
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1, 2, 2, (V[]){v_str_2414, v_acc_242});
      } else {
        heff_drop(v_text_247);
        V v_a_2427 = v_field_2410;
        V v_c_2428 = (g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(v_st_240, heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2427, 2))));
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3, 2, 6, (V[]){v_c_2428, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2427});
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2426 = ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2416;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_str_2414 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2414, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str1)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_2415, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2, 1, 2, (V[]){v_acc_242, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2427 = heff_env(self)[4];
  V v_hd_2429 = heff_env(self)[5];
  V v_k_2430 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2427; V a_5 = v_x_2431; V a_6 = v_hd_2429; V a_7 = v_k_2430; V r_ = (g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2427 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2427, v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str4, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666(V v_rep_240, V v_prog_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_242); r_; });
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam0, 2, 3, (V[]){v_c_243, v_rep_240, v_prog_241});
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str1))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_2417);
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str2), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam4, 1, 2, (V[]){v_hd_244, v_k_245})));
  }
  case TAG_Just: {
    heff_take_n(v_x_246, 0ULL, 1);
    V v_t_2434 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str3)));
    return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_2417; V a_3 = ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_str4); V a_4 = v_t_2434; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2417); r_; });
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam3, 1, 5, (V[]){v_x_246, v_hd_244, v_k_245, v_rep_240, v_prog_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s2031426327x417480666_lam1, 1, 4, (V[]){v_hd_244, v_k_245, v_rep_240, v_prog_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_done_244, V v_progs_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str0)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str1)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_242; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_242, v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_s_2415 = ({ V a_0 = v_st_242; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2415; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_2416); r_; });
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam0, 1, 8, (V[]){v_progs_245, v_prog_241, v_z_246, heff_dup(v_st_242), v_t_243, v_done_244, v_rep_240, v_z_247})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam1(V self, V *args) {
  V v_t_2420 = args[0];
  return v_t_2420;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_next_2424 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  V f_ = v_next_2424;
  heff_room[0] = v_hd_2427;
  heff_room[1] = v_k_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_t_2426 = heff_env(self)[0];
  V v_next_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2426, heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam4, 1, 3, (V[]){v_next_2424, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_done_244 = heff_env(self)[3];
  V v_progs_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), v_done_244, heff_dup(v_progs_245), heff_rfield(v_t_243, 4)));
  V v_next_2424 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), v_t_2423, v_progs_245));
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2422), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2425}));
  V v_t_2430 = ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_242; V a_3 = v_t_243; V a_4 = v_x_2422; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam3, 2, 2, (V[]){v_t_2426, v_next_2424}); V a_6 = v_progs_245; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_242); heff_drop(v_progs_245); r_; });
  V f_ = v_t_2430;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_progs_245 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2418);
  V v_total_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_245));
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_str2), v_total_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2421, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_lam2, 1, 8, (V[]){v_prog_241, v_st_242, v_t_243, v_done_244, v_progs_245, v_rep_240, v_z_246, v_z_247})));
}