// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Among 19600
#define TAG_Args 26338
#define TAG_Dirs 41877
#define TAG_Exit 20279
#define TAG_Files 59123
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35657
#define TAG_Start 63542
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_errors 652506774
#define LBL_explain 1070179126
#define LBL_file 9638467
#define LBL_flag 9641011
#define LBL_fmt 311047
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_lib 316671
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_malg 9839318
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_outPath 1272254166
#define LBL_pos 320718
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_tests 311609915
#define LBL_typeAt 1088337976
#define LBL_values 1123329101
#define LBL_version 583465758
static uint32_t shape_check__run__tests__promote__compile__explain__typeAt__fmt[] = {LBL_check, LBL_run, LBL_tests, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt};
static uint32_t shape_file__outPath__name__backend[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend};
static uint32_t shape_init__get__build__install__publish[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_get(void);
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_get(void);
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_get(void);
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_get(void);
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2eop_24s1120500887x880256022(V, V, V, V, V);
V g_co_2eop_24s1120500887x880256022_entry(V self, V *a);
extern Clo g_co_2eop_24s1120500887x880256022_clo;
V g_co_2eop_24s1289826976x294500243(V, V);
V g_co_2eop_24s1289826976x294500243_entry(V self, V *a);
extern Clo g_co_2eop_24s1289826976x294500243_clo;
V g_co_2eop_24s1733416874x114389617(V, V, V, V);
V g_co_2eop_24s1733416874x114389617_entry(V self, V *a);
extern Clo g_co_2eop_24s1733416874x114389617_clo;
V g_co_2eop_24s1820069742x1229611037(V, V);
V g_co_2eop_24s1820069742x1229611037_entry(V self, V *a);
extern Clo g_co_2eop_24s1820069742x1229611037_clo;
V g_co_2eop_24s384550787x906982552(V, V, V);
V g_co_2eop_24s384550787x906982552_entry(V self, V *a);
extern Clo g_co_2eop_24s384550787x906982552_clo;
V g_co_2eop_24s407208505x1963297453(V, V, V, V, V, V);
V g_co_2eop_24s407208505x1963297453_entry(V self, V *a);
extern Clo g_co_2eop_24s407208505x1963297453_clo;
V g_co_2eop_24s426274043x1882392996(V, V, V);
V g_co_2eop_24s426274043x1882392996_entry(V self, V *a);
extern Clo g_co_2eop_24s426274043x1882392996_clo;
V g_co_2eop_24s812997432x1367073594(V, V, V, V, V);
V g_co_2eop_24s812997432x1367073594_entry(V self, V *a);
extern Clo g_co_2eop_24s812997432x1367073594_clo;
V g_co_2eop_24s854370402x463456077(V, V);
V g_co_2eop_24s854370402x463456077_entry(V self, V *a);
extern Clo g_co_2eop_24s854370402x463456077_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo;
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(V, V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750(V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s787927001x2102341300(V, V);
V g_list_2efoldl_24s787927001x2102341300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s787927001x2102341300_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(void);
V g_std_2eprogress_2equietly_24s1392860441x1460275359(V);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s1392860441x1460275359_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_app_2eheff_2emain_2ehf_str0, 3, ".hf");

static V g_app_2eheff_2emain_2ehf_val;
static HEFF_ONCE g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag_n(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ehf_st)) return g_app_2eheff_2emain_2ehf_val;
  return heff_global(&g_app_2eheff_2emain_2ehf_val, &g_app_2eheff_2emain_2ehf_st, g_app_2eheff_2emain_2ehf_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str0, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str1, 55, "elaborate FILE and what it imports; print its interface");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str3, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str4, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str5, 76, "run FILE's main with ARGS, compiled through C (by zig at -O1, in .heff/run/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str8, 4, "ARGS");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str9, 4, "test");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str10, 265, "check the expectations of the watches (the `-- ...` lines under them) and doc tests (the `-- | ...` lines under them), and run the tests (the definitions of type `Test`, lib/check.hf), of the FILEs (a directory's .hf files), else of the project's tests here (test/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str11, 4, "seed");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str12, 1, "s");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str13, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str14, 64, "the seed the properties draw from (the same seed, the same runs)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str15, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str16, 7, "promote");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str17, 67, "write each watch's and doc test's value under it as its expectation");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str18, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str19, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str20, 7, "compile");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str21, 134, "FILE compiled, by MODE: esm (an ES module), page (a script running the app NAME in a page), c (a C program running NAME, for `zig cc`)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str22, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str23, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str24, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str25, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str26, 4, "name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str27, 1, "n");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str28, 4, "NAME");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str29, 29, "the computation run (page, c)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str30, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str31, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str32, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str33, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str34, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str35, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str36, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str37, 7, "backend");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str38, 1, "b");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str39, 4, "MODE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str40, 22, "what it is compiled to");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str41, 7, "explain");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str42, 21, "the elaboration trace");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str43, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str44, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str45, 7, "type-at");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str46, 67, "what the name at each OFFSET resolved to, and its type, a line each");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str47, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str48, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str49, 6, "OFFSET");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str50, 3, "fmt");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str51, 21, "format FILEs in place");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str52, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str53, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str54, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str55, 32, "only say which are not formatted");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str56, 4, "FILE");
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2423 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2433 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2443 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2481 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2491 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str41), ((V)&g_app_2eheff_2emain_2ebuildCommands_str42), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24104 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str45), ((V)&g_app_2eheff_2emain_2ebuildCommands_str46), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24117 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), ((V)&g_app_2eheff_2emain_2ebuildCommands_str51), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){v_c_240})});
  V v_t_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
  V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_24120})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_24121});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_242 = args[0];
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 2);
    return v_x_243;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_246 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 1)), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 8)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_249;
  heff_room[1] = v_x_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2412 = args[0];
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 2);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2416 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 3)), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2420 = heff_tr(heff_call(heff_take_field(v_s_2411, 3), 1, (V[]){v_t_2419}));
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_s_2411, 0), 1, (V[]){heff_get_n(v_c_240, 1, 8)}));
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2421, v_x_2418}));
  V f_ = heff_get_n(v_s_2411, 1, 4);
  heff_room[0] = v_t_2422;
  heff_room[1] = v_y_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2426 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_s_2424, 2), 1, (V[]){v_t_2426}));
  V v_x_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2425, v_t_2427}));
  V v_t_2429 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_2430 = heff_tr(heff_call(heff_take_field(v_s_2424, 3), 1, (V[]){v_t_2429}));
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_s_2424, 0), 1, (V[]){heff_get_n(v_c_240, 2, 8)}));
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2431, v_x_2428}));
  V f_ = heff_get_n(v_s_2424, 1, 4);
  heff_room[0] = v_t_2432;
  heff_room[1] = v_y_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_x2_2435 = args[0];
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str18);
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    heff_take_n(v_x2_2435, 1ULL, 2);
    return v_x_2436;
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2434, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2439 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_s_2434, 3), 1, (V[]){v_t_2439}));
  V v_x_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2434, 1)), 2, (V[]){v_t_2438, v_t_2440}));
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_s_2434, 0), 1, (V[]){heff_get_n(v_c_240, 3, 8)}));
  V f_ = heff_get_n(v_s_2434, 1, 4);
  heff_room[0] = v_t_2442;
  heff_room[1] = v_x_2441;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_x2_2445 = args[0];
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str22);
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    heff_take_n(v_x2_2445, 1ULL, 2);
    return v_x_2446;
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_x2_2452 = args[0];
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str24);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take_n(v_x2_2452, 1ULL, 2);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_vs_2463 = args[0];
  HeffT2 v_t_2464 = (g_std_2ecli_2elastS_24cpr(v_vs_2463));
  {
    V v_field_2466 = v_t_2464.f[1];
    int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
    if ((v_tag_2465 == ((int64_t)0ULL))) {
      V v_x_2468 = v_field_2466;
      return v_x_2468;
    } else {
      heff_drop(v_field_2466);
      return ((V)&g_app_2eheff_2emain_2ebuildCommands_str30);
    }
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_2449 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 3)), 1, (V[]){v_t_2449}));
  V v_x_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2448, v_t_2450}));
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam9_clo)}));
  V v_t_2456 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str25), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_call(heff_take_field(v_s_2444, 3), 1, (V[]){v_t_2456}));
  V v_y_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2460 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str26), ((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 2)), 1, (V[]){v_t_2460}));
  V v_z_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2459, v_t_2461}));
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Nil)});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str33), v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), NTAG(TAG_Nil)});
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str36), v_t_2472})});
  V v_t_2474 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str37), ((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), v_t_2471, NTAG(TAG_False), NTAG(TAG_True), heff_tag_n(TAG_Among, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_take_field(v_s_2444, 2), 1, (V[]){v_t_2474}));
  V v_w_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2469, v_t_2475}));
  V v_t_2477 = heff_tr(heff_call(heff_take_field(v_s_2444, 0), 1, (V[]){heff_get_n(v_c_240, 4, 8)}));
  V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2477, v_x_2451}));
  V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2478, v_y_2458}));
  V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2444, 1)), 2, (V[]){v_t_2479, v_z_2462}));
  V f_ = heff_get_n(v_s_2444, 1, 4);
  heff_room[0] = v_t_2480;
  heff_room[1] = v_w_2476;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_2483 = args[0];
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str43);
  }
  case TAG_Cons: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    heff_take_n(v_x2_2483, 1ULL, 2);
    return v_x_2484;
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_2482 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2482, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_2487 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str44), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2488 = heff_tr(heff_call(heff_take_field(v_s_2482, 3), 1, (V[]){v_t_2487}));
  V v_x_2489 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2482, 1)), 2, (V[]){v_t_2486, v_t_2488}));
  V v_t_2490 = heff_tr(heff_call(heff_take_field(v_s_2482, 0), 1, (V[]){heff_get_n(v_c_240, 5, 8)}));
  V f_ = heff_get_n(v_s_2482, 1, 4);
  heff_room[0] = v_t_2490;
  heff_room[1] = v_x_2489;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_x2_2493 = args[0];
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str47);
  }
  case TAG_Cons: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    heff_take_n(v_x2_2493, 1ULL, 2);
    return v_x_2494;
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2496 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2492, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_2497 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str48), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2498 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2492, 3)), 1, (V[]){v_t_2497}));
  V v_x_2499 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2492, 1)), 2, (V[]){v_t_2496, v_t_2498}));
  V v_t_24100 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str49), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_24101 = heff_tr(heff_call(heff_take_field(v_s_2492, 3), 1, (V[]){v_t_24100}));
  V v_t_24102 = heff_tr(heff_call(heff_take_field(v_s_2492, 0), 1, (V[]){heff_get_n(v_c_240, 6, 8)}));
  V v_t_24103 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2492, 1)), 2, (V[]){v_t_24102, v_x_2499}));
  V f_ = heff_get_n(v_s_2492, 1, 4);
  heff_room[0] = v_t_24103;
  heff_room[1] = v_y_24101;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_vs_24106 = args[0];
  switch (heff_tag_of(v_vs_24106)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24106, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24106);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24109 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24105, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24110 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str52), ((V)&g_app_2eheff_2emain_2ebuildCommands_str53), ((V)&g_app_2eheff_2emain_2ebuildCommands_str54), ((V)&g_app_2eheff_2emain_2ebuildCommands_str55), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24111 = heff_tr(heff_call(heff_take_field(v_s_24105, 2), 1, (V[]){v_t_24110}));
  V v_x_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24105, 1)), 2, (V[]){v_t_24109, v_t_24111}));
  V v_t_24113 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str56), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24114 = heff_tr(heff_call(heff_take_field(v_s_24105, 3), 1, (V[]){v_t_24113}));
  V v_t_24115 = heff_tr(heff_call(heff_take_field(v_s_24105, 0), 1, (V[]){heff_get_n(v_c_240, 7, 8)}));
  V v_t_24116 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24105, 1)), 2, (V[]){v_t_24115, v_x_24112}));
  V f_ = heff_get_n(v_s_24105, 1, 4);
  heff_room[0] = v_t_24116;
  heff_room[1] = v_y_24114;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str0, 4, "init");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str1, 39, "a new project in DIR (here, without it)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str2, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str3, 3, "get");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str4, 108, "fetch what the project requires, writing heff.sum; with PATH, require it (at VERSION, else its newest) first");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str5, 14, "PATH[@VERSION]");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str6, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str7, 193, "the whole project: every module of src/ checked, then every program, app/NAME/main.hf, compiled as app/NAME/build.hf says, to .heff/bin/ (C by zig at -O1: built quickly, not to run its fastest)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str8, 7, "install");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str9, 264, "the project at DIR (here, without it) built as `heff build` builds it, but to run its fastest (C by zig at -O2), its programs into the heff home's bin/ (HEFF_HOME/bin, else ~/.heff/bin), and what they ship (their build.hf's `ships`) into the heff home, beside bin/");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str10, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str11, 7, "publish");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str12, 56, "check the project, then tag it vVERSION and push the tag");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str14, 7, "VERSION");
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2420 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2432 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2442 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){v_c_240})});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2443})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2444})});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_242 = args[0];
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_ws_242, 0);
    heff_take_n(v_ws_242, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
  }
  default: return heff_nomatch(v_ws_242);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_246 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 1)), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 5)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_249;
  heff_room[1] = v_x_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2412 = args[0];
  switch (heff_tag_of(v_ws_2412)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_ws_2412, 0);
    heff_take_n(v_ws_2412, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_ws_2412);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2416 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_s_2411, 3), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_s_2411, 0), 1, (V[]){heff_get_n(v_c_240, 1, 5)}));
  V f_ = heff_get_n(v_s_2411, 1, 4);
  heff_room[0] = v_t_2419;
  heff_room[1] = v_x_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2421, 0, 4);
  args[0] = heff_get_n(v_c_240, 2, 5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_s_2423, 3), 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 1)), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_s_2423, 0), 1, (V[]){heff_get_n(v_c_240, 3, 5)}));
  V f_ = heff_get_n(v_s_2423, 1, 4);
  heff_room[0] = v_t_2431;
  heff_room[1] = v_x_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2434 = args[0];
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    heff_take_n(v_x2_2434, 1ULL, 2);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2433, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2438 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_s_2433, 3), 1, (V[]){v_t_2438}));
  V v_x_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2433, 1)), 2, (V[]){v_t_2437, v_t_2439}));
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_s_2433, 0), 1, (V[]){heff_get_n(v_c_240, 4, 5)}));
  V f_ = heff_get_n(v_s_2433, 1, 4);
  heff_room[0] = v_t_2441;
  heff_room[1] = v_x_2440;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str0, 3, "lsp");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str1, 34, "a language server, on stdin/stdout");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str2, 5, "FLAGS");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str3, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str4, 68, "which heff this is: its version, as the package.hf it came with says");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str5, 9, "dump-core");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str8, 9, "dump-eval");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str9, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str10, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str11, 4, "FILE");
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_t_245 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_247 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2412 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){v_c_240})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2423})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2424});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_243 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_242}));
  V v_t_244 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 4)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_244;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_246, 0, 4);
  args[0] = heff_get_n(v_c_240, 1, 4);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_2410 = heff_tr(heff_call(heff_take_field(v_s_248, 3), 1, (V[]){v_t_249}));
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_s_248, 0), 1, (V[]){heff_get_n(v_c_240, 2, 4)}));
  V f_ = heff_get_n(v_s_248, 1, 4);
  heff_room[0] = v_t_2411;
  heff_room[1] = v_x_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2414 = args[0];
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str10);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2413, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2418 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_s_2413, 3), 1, (V[]){v_t_2418}));
  V v_x_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2413, 1)), 2, (V[]){v_t_2417, v_t_2419}));
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_s_2413, 0), 1, (V[]){heff_get_n(v_c_240, 3, 4)}));
  V f_ = heff_get_n(v_s_2413, 1, 4);
  heff_room[0] = v_t_2421;
  heff_room[1] = v_x_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_str1, 7, "testing");
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam3(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam0, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam5, 2, 0};
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam9, 4, 0};
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam10, 4, 0};

static V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_st;
static V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_init(void) {
  return heff_rec_n(8, shape_check__run__tests__promote__compile__explain__typeAt__fmt, (V[]){((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam5_clo), ((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam9_clo), ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo), ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam10_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_st)) return g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_val;
  return heff_global(&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_val, &g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_st, g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_init);
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_245); V a_1 = heff_get_n(v_x_247, 0, 2); V a_2 = v_hd_242; V a_3 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam4, 1, 3, (V[]){v_x_245, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam3, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam1(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam0(V self, V *args) {
  V v_file_240 = args[0];
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_240));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam1, 2, 1, (V[]){v_c_241});
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam8(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam7(V self, V *args) {
  V v_x_2413 = args[0];
  V v_seed_248 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_seed_2420;
  switch (heff_tag_of(v_seed_248)) {
  case TAG_Nothing: {
    v_seed_2420 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2414 = heff_field(v_seed_248, 0);
    heff_take_n(v_seed_248, 1ULL, 1);
    HeffT2 v_t_2415 = (g_prelude_2eparseInt_24cpr(v_s_2414));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2417;
        v_seed_2420 = v_x_2419;
      } else {
        heff_drop(v_field_2417);
        v_seed_2420 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_248);
  }
  V v_total_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_str1), v_total_2421, ((V)&g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam8_clo)})});
  return (g_co_2eop_24s407208505x1963297453(v_seed_2420, v_x_2413, heff_dup(v_hd_2411), v_k_2412, v_t_2423, v_hd_2411));
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam6(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_seed_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam7, 1, 3, (V[]){v_seed_248, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam5(V self, V *args) {
  V v_seed_248 = args[0];
  V v_given_249 = args[1];
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(v_given_249));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam6, 2, 2, (V[]){v_c_2410, v_seed_248});
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam9(V self, V *args) {
  V v_file_2424 = args[0];
  V v_outPath_2425 = args[1];
  V v_name_2426 = args[2];
  V v_backend_2427 = args[3];
  return (g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(heff_rec_n(4, shape_file__outPath__name__backend, (V[]){v_file_2424, v_outPath_2425, v_name_2426, v_backend_2427})));
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam11(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intLt_c(MK_INT(0LL), v_x_2432)) {
    V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    return (g_co_2eop_24s954557541x749476273(v_t_2437, v_hd_2430, v_k_2431));
  } else {
    heff_drop(v_hd_2430);
    V f_ = v_k_2431;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam10(V self, V *args) {
  V v_check_2428 = args[0];
  V v_files_2429 = args[1];
  V v_hd_2430 = args[2];
  V v_k_2431 = args[3];
  return ({ V a_0 = v_check_2428; V a_1 = v_files_2429; V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_hd_2430); V a_4 = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_lam11, 1, 2, (V[]){v_hd_2430, v_k_2431}); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_check_2428); heff_drop(v_files_2429); r_; });
}
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_str0, 4, "heff");
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam3, 1, 0};
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam2(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam0, 1, 0};
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam6(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam5(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam4, 3, 0};
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam11(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam10(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam9(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam8(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam7, 1, 0};

static V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_val;
static HEFF_ONCE g_app_2eheff_2emain_2etool_24s1548536003x1865418917_st;
static V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_init(void) {
  return heff_rec_n(4, shape_lsp__version__dumpCore__dumpEval, (V[]){((V)&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo), ((V)&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam4_clo), ((V)&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam7_clo)});
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_st)) return g_app_2eheff_2emain_2etool_24s1548536003x1865418917_val;
  return heff_global(&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_val, &g_app_2eheff_2emain_2etool_24s1548536003x1865418917_st, g_app_2eheff_2emain_2etool_24s1548536003x1865418917_init);
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam3(V self, V *args) {
  V v_a_245 = args[0];
  return v_a_245;
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_AbsPath, 2, (V[]){heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam3_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s812997432x1367073594(v_x_244, heff_dup(v_hd_242), v_k_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), v_hd_242));
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam1(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam0(V self, V *args) {
  V v_flags_240 = args[0];
  heff_drop(v_flags_240);
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam1, 2, 1, (V[]){v_c_241});
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intEq_c(v_x_2414, MK_INT(0LL))) {
    heff_drop(v_hd_249);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s954557541x749476273(v_t_2419, v_hd_249, v_k_2410));
  }
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam5(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = (g_list_2efoldl_24s787927001x2102341300(NTAG(TAG_Nil), v_x_2411));
  V v_c_2413 = ({ V a_0 = v_t_2412; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam6, 1, 2, (V[]){v_k_2410, v_hd_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam4(V self, V *args) {
  V v_paths_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(NTAG(TAG_Nil), v_paths_248, heff_dup(v_hd_249), heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam5, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam11(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_2425); V a_1 = heff_get_n(v_x_2427, 0, 2); V a_2 = v_hd_2422; V a_3 = v_k_2423; V r_ = (g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam10(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_2424));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam11, 1, 3, (V[]){v_x_2425, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam9(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_app_2eheff_2emain_2etool_24s1548536003x1865418917_str0), heff_dup(heff_rfield(v_x_2424, 1)), MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam10, 1, 3, (V[]){v_x_2424, v_hd_2422, v_k_2423})));
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam8(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam9, 1, 2, (V[]){v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam7(V self, V *args) {
  V v_file_2420 = args[0];
  V v_c_2421 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_2420));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_lam8, 2, 1, (V[]){v_c_2421});
}
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str1, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str2, 4, "heff");
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam3, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam4, 4, 0};
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam1, 4, 0};

static V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_val;
static HEFF_ONCE g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_st;
static V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_init(void) {
  V v_t_241 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam0_clo)})});
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  return (g_co_2eop_24s1289826976x294500243(heff_tag_n(TAG_InR, 1, (V[]){v_t_243}), ((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam1_clo)));
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_st)) return g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_val;
  return heff_global(&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_val, &g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_st, g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_init);
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam0(V self, V *args) {
  V v_a_240 = args[0];
  return v_a_240;
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam2(V self, V *args) {
  V v_dir_2411 = args[0];
  V v_t_2413;
  switch (heff_tag_of(v_dir_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_dir_2411, 0);
    heff_take_n(v_dir_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_dir_2411);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam3(V self, V *args) {
  V v_dir_2414 = args[0];
  V v_t_2416;
  switch (heff_tag_of(v_dir_2414)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_dir_2414, 0);
    heff_take_n(v_dir_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_dir_2414);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo);
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam4(V self, V *args) {
  V v_a_2437 = args[0];
  V v_a_2438 = args[1];
  V v_a_2439 = args[2];
  V v_a_2440 = args[3];
  heff_drop(v_a_2439);
  V f_ = v_a_2440;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2438, v_a_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_z_245 = args[1];
  V v_z_246 = args[2];
  V v_z_247 = args[3];
  V v_t_248 = heff_dup(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_get());
  V v_t_249 = heff_dup(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_get());
  V v_t_2410 = (g_app_2eheff_2emain_2ebuildCommands(v_t_248));
  V v_t_2417 = (g_app_2eheff_2emain_2eprojectCommands(heff_rec_n(5, shape_init__get__build__install__publish, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam2_clo), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam3_clo), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo)})));
  V v_t_2418 = (g_app_2eheff_2emain_2etoolCommands(v_t_249));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2419));
  HeffT2 v_t_2421 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_str2), v_t_2420, v_x_244));
  {
    V v_field_2423 = v_t_2421.f[1];
    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
    if ((v_tag_2422 == ((int64_t)0ULL))) {
      V v_text_2425 = v_field_2423;
      V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2425, NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      return (g_co_2eop_24s1120500887x880256022(MK_INT(1LL), v_t_2429, v_z_245, v_z_246, v_z_247));
    } else {
      if ((v_tag_2422 == ((int64_t)1ULL))) {
        V v_text_2431 = v_field_2423;
        V v_t_2432 = heff_tag_n(TAG_Write, 2, (V[]){v_text_2431, NTAG(TAG_MkUnit)});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        return (g_co_2eop_24s1733416874x114389617(v_t_2435, v_z_245, v_z_246, v_z_247));
      } else {
        V v_act_2436 = v_field_2423;
        return heff_tail(v_act_2436, 5, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s1506381720x1028922836_get()), ((V)&g_app_2eheff_2emain_2eprogram_24s1869953317x1473470427_lam4_clo), v_z_245, v_z_246, v_z_247});
      }
    }
  }
}
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str1, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str2, 4, "heff");
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam3, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam4, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam6(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam5, 4, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam7, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam8, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam9, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam11(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam10, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam12, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam13, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam1, 2, 0};

static V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_val;
static HEFF_ONCE g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_st;
static V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_init(void) {
  V v_t_241 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam0_clo)})});
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  return (g_co_2eop_24s854370402x463456077(v_t_243, ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam1_clo)));
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_st)) return g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_val;
  return heff_global(&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_val, &g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_st, g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_init);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam0(V self, V *args) {
  V v_a_240 = args[0];
  return v_a_240;
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam2(V self, V *args) {
  V v_dir_249 = args[0];
  V v_t_2411;
  switch (heff_tag_of(v_dir_249)) {
  case TAG_Nothing: {
    v_t_2411 = ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_dir_249, 0);
    heff_take_n(v_dir_249, 1ULL, 1);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_dir_249);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo);
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam3(V self, V *args) {
  V v_dir_2412 = args[0];
  V v_t_2414;
  switch (heff_tag_of(v_dir_2412)) {
  case TAG_Nothing: {
    v_t_2414 = ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_dir_2412, 0);
    heff_take_n(v_dir_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_dir_2412);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam4(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2434 = args[1];
  V v_a_2435 = args[2];
  heff_drop(v_a_2434);
  V f_ = v_a_2435;
  args[0] = v_a_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam6(V self, V *args) {
  V v_a_2440 = args[0];
  V v_a_2437 = heff_env(self)[0];
  V v_a_2438 = heff_env(self)[1];
  V v_a_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_2437;
  heff_room[0] = v_a_2440;
  heff_room[1] = v_a_2438;
  heff_room[2] = v_a_2439;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam5(V self, V *args) {
  V v_a_2436 = args[0];
  V v_a_2437 = args[1];
  V v_a_2438 = args[2];
  V v_a_2439 = args[3];
  V f_ = v_a_2436;
  args[0] = heff_dup(v_a_2438);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam6, 1, 3, (V[]){v_a_2437, v_a_2438, v_a_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam7(V self, V *args) {
  V v_a_2441 = args[0];
  switch (heff_tag_of(v_a_2441)) {
  case TAG_InL: {
    V v_a_2442 = heff_field(v_a_2441, 0);
    heff_take_n(v_a_2441, 1ULL, 1);
    return ({ V a_0 = v_a_2442; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2442); r_; });
  }
  case TAG_InR: {
    V v_a_2443 = heff_field(v_a_2441, 0);
    heff_take_n(v_a_2441, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s384550787x906982552_clo);
    args[0] = v_a_2443;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2441);
  }
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam8(V self, V *args) {
  V v_a_2444 = args[0];
  V v_a_2445 = args[1];
  V v_a_2446 = args[2];
  heff_drop(v_a_2445);
  V f_ = v_a_2446;
  args[0] = v_a_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam9(V self, V *args) {
  V v_a_2447 = args[0];
  V v_a_2448 = args[1];
  V f_ = v_a_2448;
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam11(V self, V *args) {
  V v_a_2452 = args[0];
  V v_a_2450 = heff_env(self)[0];
  V v_a_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2450;
  heff_room[0] = v_a_2452;
  heff_room[1] = v_a_2451;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam10(V self, V *args) {
  V v_a_2449 = args[0];
  V v_a_2450 = args[1];
  V v_a_2451 = args[2];
  V f_ = v_a_2449;
  args[0] = heff_clo_n(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam11, 1, 2, (V[]){v_a_2450, v_a_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam12(V self, V *args) {
  V v_a_2453 = args[0];
  V v_a_2454 = args[1];
  return heff_perform(v_a_2453, v_a_2454);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam13(V self, V *args) {
  V v_a_2455 = args[0];
  V v_a_2456 = args[1];
  V f_ = v_a_2456;
  args[0] = v_a_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_z_245 = args[1];
  V v_t_246 = heff_dup(g_app_2eheff_2emain_2ebuild_24s1062620717x888327090_get());
  V v_t_247 = heff_dup(g_app_2eheff_2emain_2etool_24s1548536003x1865418917_get());
  V v_t_248 = (g_app_2eheff_2emain_2ebuildCommands(v_t_246));
  V v_t_2415 = (g_app_2eheff_2emain_2eprojectCommands(heff_rec_n(5, shape_init__get__build__install__publish, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam2_clo), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam3_clo), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo)})));
  V v_t_2416 = (g_app_2eheff_2emain_2etoolCommands(v_t_247));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2416));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_t_248, v_t_2417));
  HeffT2 v_t_2419 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_str2), v_t_2418, v_a_244));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_text_2423 = v_field_2421;
      V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2423, NTAG(TAG_MkUnit)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s426274043x1882392996(MK_INT(1LL), heff_tag_n(TAG_InL, 1, (V[]){v_t_2426}), v_z_245));
    } else {
      if ((v_tag_2420 == ((int64_t)1ULL))) {
        V v_text_2428 = v_field_2421;
        V v_t_2429 = heff_tag_n(TAG_Write, 2, (V[]){v_text_2428, NTAG(TAG_MkUnit)});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        return (g_co_2eop_24s1820069742x1229611037(heff_tag_n(TAG_InL, 1, (V[]){v_t_2431}), v_z_245));
      } else {
        V v_act_2432 = v_field_2421;
        return heff_tail(v_act_2432, 5, (V[]){heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam4_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam5_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam7_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam8_clo), heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam9_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam10_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam12_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_lam13_clo), v_z_245});
      }
    }
  }
}