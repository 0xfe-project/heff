// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Among 19600
#define TAG_Args 26338
#define TAG_Dirs 41877
#define TAG_Exit 20279
#define TAG_Files 59123
#define TAG_Interactive 42932
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Some 35657
#define TAG_Start 63542
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bench 294981194
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_dev 308879
#define LBL_devPages 1831184971
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_explain 1070179126
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_filter 672649891
#define LBL_flag 9641011
#define LBL_fmt 311047
#define LBL_form 9644427
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_lib 316671
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_menu 9843238
#define LBL_message 1186782793
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_outPath 1272254166
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_ran 322201
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_typeAt 1088337976
#define LBL_typing 1088343202
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_view 10114924
static uint32_t shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt[] = {LBL_check, LBL_run, LBL_tests, LBL_bench, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt};
static uint32_t shape_file__outPath__name__backend[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend};
static uint32_t shape_init__get__build__install__publish__dev[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish, LBL_dev};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval__devPages[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval, LBL_devPages};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_start__step__view[] = {LBL_start, LBL_step, LBL_view};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258(V, V, V, V, V);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_clo;
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_clo;
V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_clo;
V g_app_2eheff_2emain_2eexplored_24s1499133303x676910618(V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2emain(V, V, V);
V g_app_2eheff_2emain_2emain_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2emain_clo;
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117(V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s92965591x238646117_clo;
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205(V, V, V, V);
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eproject_24s457440104x1206769205_clo;
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942(V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etool_24s1214440417x2108196942_clo;
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544(V, V, V);
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_clo;
V g_app_2eheff_2emain_2eworld_get(void);
V g_co_2eop_24s1278336259x450164198(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1278336259x450164198_entry(V self, V *a);
extern Clo g_co_2eop_24s1278336259x450164198_clo;
V g_co_2eop_24s1594985323x520615696(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1594985323x520615696_entry(V self, V *a);
extern Clo g_co_2eop_24s1594985323x520615696_clo;
V g_co_2eop_24s173284549x1274703393(V, V, V, V, V, V);
V g_co_2eop_24s173284549x1274703393_entry(V self, V *a);
extern Clo g_co_2eop_24s173284549x1274703393_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_co_2eplus(V, V);
V g_co_2eplus_entry(V self, V *a);
extern Clo g_co_2eplus_clo;
V g_co_2eplus_24s1257879563x1568253915(V);
V g_co_2eplus_24s1257879563x1568253915_entry(V self, V *a);
extern Clo g_co_2eplus_24s1257879563x1568253915_clo;
V g_co_2eplus_24s1597160042x1604640811_get(void);
V g_co_2eplus_24s1679086809x1857696200(V);
V g_co_2eplus_24s1679086809x1857696200_entry(V self, V *a);
extern Clo g_co_2eplus_24s1679086809x1857696200_clo;
V g_co_2eplus_24s58116330x1448227934(V);
V g_co_2eplus_24s58116330x1448227934_entry(V self, V *a);
extern Clo g_co_2eplus_24s58116330x1448227934_clo;
V g_co_2eplus_24s860740675x1298266759(V);
V g_co_2eplus_24s860740675x1298266759_entry(V self, V *a);
extern Clo g_co_2eplus_24s860740675x1298266759_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689(V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_clo;
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576(V, V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_clo;
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197(V, V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_list_2efilter_24f75237897x367824150(V, V);
V g_list_2efilter_24f75237897x367824150_entry(V self, V *a);
extern Clo g_list_2efilter_24f75237897x367824150_clo;
V g_list_2efoldl_24s1649248084x1368208491(V, V);
V g_list_2efoldl_24s1649248084x1368208491_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1649248084x1368208491_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2eshown_24s240023447x857982376(V, V, V, V);
V g_std_2eprogress_2eshown_24s240023447x857982376_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s240023447x857982376_clo;
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2einteract_24s1344509824x1570875242(V, V);
V g_std_2eterminal_2einteract_24s1344509824x1570875242_entry(V self, V *a);
extern Clo g_std_2eterminal_2einteract_24s1344509824x1570875242_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);

static V g_app_2eheff_2emain_2eworld_val;
static HEFF_ONCE g_app_2eheff_2emain_2eworld_st;
static V g_app_2eheff_2emain_2eworld_init(void) {
  V v_t_240 = (g_co_2eplus(heff_dup(g_co_2eplus_24s1597160042x1604640811_get()), heff_dup(g_std_2ereactor_2ereactor_get())));
  return (g_co_2eplus_24s1679086809x1857696200(v_t_240));
}
V g_app_2eheff_2emain_2eworld_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2eworld_st)) return g_app_2eheff_2emain_2eworld_val;
  return heff_global(&g_app_2eheff_2emain_2eworld_val, &g_app_2eheff_2emain_2eworld_st, g_app_2eheff_2emain_2eworld_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ehf_str0, 3, ".hf");

static V g_app_2eheff_2emain_2ehf_val;
static HEFF_ONCE g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag_n(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ehf_st)) return g_app_2eheff_2emain_2ehf_val;
  return heff_global(&g_app_2eheff_2emain_2ehf_val, &g_app_2eheff_2emain_2ehf_st, g_app_2eheff_2emain_2ehf_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str0, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str1, 55, "elaborate FILE and what it imports; print its interface");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str3, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str4, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str5, 76, "run FILE's main with ARGS, compiled through C (by zig at -O1, in .heff/run/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str8, 4, "ARGS");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str9, 4, "test");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str10, 263, "check the expectations of the watches (the `-- ...` lines under them) and doc tests (the `-- | ...` lines under them), and run the tests (the definitions of type `Test`, check's), of the FILEs (a directory's .hf files), else of the project's here (src/ and test/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str11, 4, "seed");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str12, 1, "s");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str13, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str14, 64, "the seed the properties draw from (the same seed, the same runs)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str15, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str16, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str17, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str18, 82, "run only the tests whose names it matches, a level each between `/`s: `^lsp/hover`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str19, 4, "jobs");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str20, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str21, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str22, 76, "how many integration tests run at once (HEFF_TEST_JOBS, else half the cores)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str23, 6, "update");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str24, 1, "u");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str25, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str26, 58, "write each golden text the tests keep, not hold them to it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str27, 5, "watch");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str28, 1, "w");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str29, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str30, 127, "then test again at each change of the FILEs, of what they import, and of the project's sources, until ended (not with --update)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str31, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str32, 5, "bench");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str33, 259, "run the benchmarks (the definitions of type `Bench`, bench's) of the FILEs (a directory's .hf files), else of the project's benchmarks here (bench/): each built through C (by zig at -O2), run until a run takes the bench time, and said a line each, as Go's are");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str34, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str35, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str36, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str37, 95, "run only the benchmarks whose names it matches, a level each between `/`s, as `heff test --run`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str38, 4, "time");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str39, 1, "t");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str40, 1, "D");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str41, 92, "how long each is run, at least: a duration (1s, the default; 500ms, 1.5s), or a count (100x)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str42, 5, "count");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str43, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str44, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str45, 33, "run each N times, a line each (1)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str46, 4, "json");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str47, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str48, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str49, 26, "say each as a line of JSON");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str50, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str51, 7, "promote");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str52, 67, "write each watch's and doc test's value under it as its expectation");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str53, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str54, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str55, 7, "compile");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str56, 134, "FILE compiled, by MODE: esm (an ES module), page (a script running the app NAME in a page), c (a C program running NAME, for `zig cc`)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str57, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str58, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str59, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str60, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str61, 4, "name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str62, 1, "n");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str63, 4, "NAME");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str64, 29, "the computation run (page, c)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str65, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str66, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str67, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str68, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str69, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str70, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str71, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str72, 7, "backend");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str73, 1, "b");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str74, 4, "MODE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str75, 22, "what it is compiled to");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str76, 7, "explain");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str77, 21, "the elaboration trace");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str78, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str79, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str80, 7, "type-at");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str81, 67, "what the name at each OFFSET resolved to, and its type, a line each");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str82, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str83, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str84, 6, "OFFSET");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str85, 3, "fmt");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str86, 21, "format FILEs in place");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str87, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str88, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str89, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str90, 32, "only say which are not formatted");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str91, 4, "FILE");
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam18, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam20, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2423 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2459 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2487 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), ((V)&g_app_2eheff_2emain_2ebuildCommands_str33), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2497 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str51), ((V)&g_app_2eheff_2emain_2ebuildCommands_str52), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24135 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24145 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str76), ((V)&g_app_2eheff_2emain_2ebuildCommands_str77), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24158 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str80), ((V)&g_app_2eheff_2emain_2ebuildCommands_str81), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam17, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24171 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str85), ((V)&g_app_2eheff_2emain_2ebuildCommands_str86), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam19, 1, 1, (V[]){v_c_240})});
  V v_t_24172 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24171, NTAG(TAG_Nil)});
  V v_t_24173 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24158, v_t_24172})});
  V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24135, v_t_24173})});
  V v_t_24175 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, v_t_24174})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_24175})});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_242 = args[0];
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 2);
    return v_x_243;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_246 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 1)), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 9)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_249;
  heff_room[1] = v_x_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2412 = args[0];
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 2);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2416 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 3)), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2420 = heff_tr(heff_call(heff_take_field(v_s_2411, 3), 1, (V[]){v_t_2419}));
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_s_2411, 0), 1, (V[]){heff_get_n(v_c_240, 1, 9)}));
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2421, v_x_2418}));
  V f_ = heff_get_n(v_s_2411, 1, 4);
  heff_room[0] = v_t_2422;
  heff_room[1] = v_y_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_vs_2437 = args[0];
  switch (heff_tag_of(v_vs_2437)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2437, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2437);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_vs_2449 = args[0];
  switch (heff_tag_of(v_vs_2449)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2449, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2449);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2426 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 2)), 1, (V[]){v_t_2426}));
  V v_x_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2425, v_t_2427}));
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2430 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), ((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), ((V)&g_app_2eheff_2emain_2ebuildCommands_str18), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 2)), 1, (V[]){v_t_2430}));
  V v_y_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2429, v_t_2431}));
  V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2434 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), ((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), ((V)&g_app_2eheff_2emain_2ebuildCommands_str22), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 2)), 1, (V[]){v_t_2434}));
  V v_z_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2433, v_t_2435}));
  V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam5_clo)}));
  V v_t_2441 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), ((V)&g_app_2eheff_2emain_2ebuildCommands_str24), ((V)&g_app_2eheff_2emain_2ebuildCommands_str25), ((V)&g_app_2eheff_2emain_2ebuildCommands_str26), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 2)), 1, (V[]){v_t_2441}));
  V v_w_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2440, v_t_2442}));
  V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 0)), 1, (V[]){heff_get_n(v_c_240, 2, 9)}));
  V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2444, v_x_2428}));
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2445, v_y_2432}));
  V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2446, v_z_2436}));
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2447, v_w_2443}));
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_s_2424, 0), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2453 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), ((V)&g_app_2eheff_2emain_2ebuildCommands_str30), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2454 = heff_tr(heff_call(heff_take_field(v_s_2424, 2), 1, (V[]){v_t_2453}));
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2452, v_t_2454}));
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2424, 1)), 2, (V[]){v_t_2448, v_t_2455}));
  V v_t_2457 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2458 = heff_tr(heff_call(heff_take_field(v_s_2424, 3), 1, (V[]){v_t_2457}));
  V f_ = heff_get_n(v_s_2424, 1, 4);
  heff_room[0] = v_t_2456;
  heff_room[1] = v_t_2458;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_vs_2473 = args[0];
  switch (heff_tag_of(v_vs_2473)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2473, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2473);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2460 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2462 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), ((V)&g_app_2eheff_2emain_2ebuildCommands_str35), ((V)&g_app_2eheff_2emain_2ebuildCommands_str36), ((V)&g_app_2eheff_2emain_2ebuildCommands_str37), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2463 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 2)), 1, (V[]){v_t_2462}));
  V v_x_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2461, v_t_2463}));
  V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2466 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2467 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 2)), 1, (V[]){v_t_2466}));
  V v_y_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2465, v_t_2467}));
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2470 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str42), ((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), ((V)&g_app_2eheff_2emain_2ebuildCommands_str45), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 2)), 1, (V[]){v_t_2470}));
  V v_z_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2469, v_t_2471}));
  V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_2477 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str46), ((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), ((V)&g_app_2eheff_2emain_2ebuildCommands_str49), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_s_2460, 2), 1, (V[]){v_t_2477}));
  V v_w_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2476, v_t_2478}));
  V v_t_2480 = heff_tr(heff_call(heff_take_field(v_s_2460, 0), 1, (V[]){heff_get_n(v_c_240, 3, 9)}));
  V v_t_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2480, v_x_2464}));
  V v_t_2482 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2481, v_y_2468}));
  V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2482, v_z_2472}));
  V v_t_2484 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2460, 1)), 2, (V[]){v_t_2483, v_w_2479}));
  V v_t_2485 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2486 = heff_tr(heff_call(heff_take_field(v_s_2460, 3), 1, (V[]){v_t_2485}));
  V f_ = heff_get_n(v_s_2460, 1, 4);
  heff_room[0] = v_t_2484;
  heff_room[1] = v_t_2486;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_x2_2489 = args[0];
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str53);
  }
  case TAG_Cons: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    heff_take_n(v_x2_2489, 1ULL, 2);
    return v_x_2490;
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_s_2488 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2488, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_2493 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_s_2488, 3), 1, (V[]){v_t_2493}));
  V v_x_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2488, 1)), 2, (V[]){v_t_2492, v_t_2494}));
  V v_t_2496 = heff_tr(heff_call(heff_take_field(v_s_2488, 0), 1, (V[]){heff_get_n(v_c_240, 4, 9)}));
  V f_ = heff_get_n(v_s_2488, 1, 4);
  heff_room[0] = v_t_2496;
  heff_room[1] = v_x_2495;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_2499 = args[0];
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str57);
  }
  case TAG_Cons: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    heff_take_n(v_x2_2499, 1ULL, 2);
    return v_x_24100;
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_x2_24106 = args[0];
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str59);
  }
  case TAG_Cons: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    heff_take_n(v_x2_24106, 1ULL, 2);
    return v_x_24107;
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_vs_24117 = args[0];
  HeffT2 v_t_24118 = (g_std_2ecli_2elastS_24cpr(v_vs_24117));
  {
    V v_field_24120 = v_t_24118.f[1];
    int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
    if ((v_tag_24119 == ((int64_t)0ULL))) {
      V v_x_24122 = v_field_24120;
      return v_x_24122;
    } else {
      heff_drop(v_field_24120);
      return ((V)&g_app_2eheff_2emain_2ebuildCommands_str65);
    }
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_2498 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_24103 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24104 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 3)), 1, (V[]){v_t_24103}));
  V v_x_24105 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24102, v_t_24104}));
  V v_t_24109 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam13_clo)}));
  V v_t_24110 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str60), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_24111 = heff_tr(heff_call(heff_take_field(v_s_2498, 3), 1, (V[]){v_t_24110}));
  V v_y_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24109, v_t_24111}));
  V v_t_24113 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24114 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str61), ((V)&g_app_2eheff_2emain_2ebuildCommands_str62), ((V)&g_app_2eheff_2emain_2ebuildCommands_str63), ((V)&g_app_2eheff_2emain_2ebuildCommands_str64), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24115 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 2)), 1, (V[]){v_t_24114}));
  V v_z_24116 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24113, v_t_24115}));
  V v_t_24123 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str66), NTAG(TAG_Nil)});
  V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str68), v_t_24124})});
  V v_t_24126 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str69), NTAG(TAG_Nil)});
  V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str70), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str71), v_t_24126})});
  V v_t_24128 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str72), ((V)&g_app_2eheff_2emain_2ebuildCommands_str73), ((V)&g_app_2eheff_2emain_2ebuildCommands_str74), ((V)&g_app_2eheff_2emain_2ebuildCommands_str75), v_t_24125, NTAG(TAG_False), NTAG(TAG_True), heff_tag_n(TAG_Among, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tr(heff_call(heff_take_field(v_s_2498, 2), 1, (V[]){v_t_24128}));
  V v_w_24130 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24123, v_t_24129}));
  V v_t_24131 = heff_tr(heff_call(heff_take_field(v_s_2498, 0), 1, (V[]){heff_get_n(v_c_240, 5, 9)}));
  V v_t_24132 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24131, v_x_24105}));
  V v_t_24133 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24132, v_y_24112}));
  V v_t_24134 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2498, 1)), 2, (V[]){v_t_24133, v_z_24116}));
  V f_ = heff_get_n(v_s_2498, 1, 4);
  heff_room[0] = v_t_24134;
  heff_room[1] = v_w_24130;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_x2_24137 = args[0];
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str78);
  }
  case TAG_Cons: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    heff_take_n(v_x2_24137, 1ULL, 2);
    return v_x_24138;
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24136 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24140 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24136, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24141 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str79), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24142 = heff_tr(heff_call(heff_take_field(v_s_24136, 3), 1, (V[]){v_t_24141}));
  V v_x_24143 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24136, 1)), 2, (V[]){v_t_24140, v_t_24142}));
  V v_t_24144 = heff_tr(heff_call(heff_take_field(v_s_24136, 0), 1, (V[]){heff_get_n(v_c_240, 6, 9)}));
  V f_ = heff_get_n(v_s_24136, 1, 4);
  heff_room[0] = v_t_24144;
  heff_room[1] = v_x_24143;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args) {
  V v_x2_24147 = args[0];
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str82);
  }
  case TAG_Cons: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    heff_take_n(v_x2_24147, 1ULL, 2);
    return v_x_24148;
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args) {
  V v_s_24146 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24150 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24146, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam18_clo)}));
  V v_t_24151 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str83), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24146, 3)), 1, (V[]){v_t_24151}));
  V v_x_24153 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24146, 1)), 2, (V[]){v_t_24150, v_t_24152}));
  V v_t_24154 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str84), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_24155 = heff_tr(heff_call(heff_take_field(v_s_24146, 3), 1, (V[]){v_t_24154}));
  V v_t_24156 = heff_tr(heff_call(heff_take_field(v_s_24146, 0), 1, (V[]){heff_get_n(v_c_240, 7, 9)}));
  V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24146, 1)), 2, (V[]){v_t_24156, v_x_24153}));
  V f_ = heff_get_n(v_s_24146, 1, 4);
  heff_room[0] = v_t_24157;
  heff_room[1] = v_y_24155;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args) {
  V v_vs_24160 = args[0];
  switch (heff_tag_of(v_vs_24160)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24160, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24160);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args) {
  V v_s_24159 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24163 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24159, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam20_clo)}));
  V v_t_24164 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str87), ((V)&g_app_2eheff_2emain_2ebuildCommands_str88), ((V)&g_app_2eheff_2emain_2ebuildCommands_str89), ((V)&g_app_2eheff_2emain_2ebuildCommands_str90), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24165 = heff_tr(heff_call(heff_take_field(v_s_24159, 2), 1, (V[]){v_t_24164}));
  V v_x_24166 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24159, 1)), 2, (V[]){v_t_24163, v_t_24165}));
  V v_t_24167 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str91), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24168 = heff_tr(heff_call(heff_take_field(v_s_24159, 3), 1, (V[]){v_t_24167}));
  V v_t_24169 = heff_tr(heff_call(heff_take_field(v_s_24159, 0), 1, (V[]){heff_get_n(v_c_240, 8, 9)}));
  V v_t_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_24159, 1)), 2, (V[]){v_t_24169, v_x_24166}));
  V f_ = heff_get_n(v_s_24159, 1, 4);
  heff_room[0] = v_t_24170;
  heff_room[1] = v_y_24168;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str0, 4, "init");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str1, 39, "a new project in DIR (here, without it)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str2, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str3, 3, "get");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str4, 108, "fetch what the project requires, writing heff.sum; with PATH, require it (at VERSION, else its newest) first");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str5, 14, "PATH[@VERSION]");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str6, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str7, 193, "the whole project: every module of src/ checked, then every program, app/NAME/main.hf, compiled as app/NAME/build.hf says, to .heff/bin/ (C by zig at -O1: built quickly, not to run its fastest)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str8, 7, "install");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str9, 264, "the project at DIR (here, without it) built as `heff build` builds it, but to run its fastest (C by zig at -O2), its programs into the heff home's bin/ (HEFF_HOME/bin, else ~/.heff/bin), and what they ship (their build.hf's `ships`) into the heff home, beside bin/");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str10, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str11, 7, "publish");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str12, 56, "check the project, then tag it vVERSION and push the tag");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str14, 7, "VERSION");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str15, 3, "dev");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str16, 159, "the project built as `heff build` builds it, its C programs (the APPs, else all) run and its pages served, then built and run again at each change of its files");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str17, 3, "APP");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str18, 4, "port");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str19, 1, "p");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str20, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str21, 57, "where the pages are served: http://127.0.0.1:PORT/ (8000)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str22, 5, "proxy");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str23, 1, "x");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str24, 3, "URL");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str25, 94, "where the pages' server sends what is not a page's: the C program's, http://127.0.0.1:8080 say");
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2420 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2432 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2442 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2457 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str15), ((V)&g_app_2eheff_2emain_2eprojectCommands_str16), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam9, 1, 1, (V[]){v_c_240})});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2459})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2460});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_242 = args[0];
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_ws_242, 0);
    heff_take_n(v_ws_242, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
  }
  default: return heff_nomatch(v_ws_242);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_246 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_241, 1)), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 6)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_249;
  heff_room[1] = v_x_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2412 = args[0];
  switch (heff_tag_of(v_ws_2412)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_ws_2412, 0);
    heff_take_n(v_ws_2412, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_ws_2412);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2416 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_s_2411, 3), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2411, 1)), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_s_2411, 0), 1, (V[]){heff_get_n(v_c_240, 1, 6)}));
  V f_ = heff_get_n(v_s_2411, 1, 4);
  heff_room[0] = v_t_2419;
  heff_room[1] = v_x_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2421, 0, 4);
  args[0] = heff_get_n(v_c_240, 2, 6);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_s_2423, 3), 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 1)), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_s_2423, 0), 1, (V[]){heff_get_n(v_c_240, 3, 6)}));
  V f_ = heff_get_n(v_s_2423, 1, 4);
  heff_room[0] = v_t_2431;
  heff_room[1] = v_x_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2434 = args[0];
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    heff_take_n(v_x2_2434, 1ULL, 2);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2433, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2438 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_s_2433, 3), 1, (V[]){v_t_2438}));
  V v_x_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2433, 1)), 2, (V[]){v_t_2437, v_t_2439}));
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_s_2433, 0), 1, (V[]){heff_get_n(v_c_240, 4, 6)}));
  V f_ = heff_get_n(v_s_2433, 1, 4);
  heff_room[0] = v_t_2441;
  heff_room[1] = v_x_2440;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args) {
  V v_s_2443 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str17), NTAG(TAG_Many), NTAG(TAG_None)});
  V v_x_2445 = heff_tr(heff_call(heff_take_field(v_s_2443, 3), 1, (V[]){v_t_2444}));
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2447 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str18), ((V)&g_app_2eheff_2emain_2eprojectCommands_str19), ((V)&g_app_2eheff_2emain_2eprojectCommands_str20), ((V)&g_app_2eheff_2emain_2eprojectCommands_str21), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 2)), 1, (V[]){v_t_2447}));
  V v_y_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 1)), 2, (V[]){v_t_2446, v_t_2448}));
  V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 0)), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2451 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str22), ((V)&g_app_2eheff_2emain_2eprojectCommands_str23), ((V)&g_app_2eheff_2emain_2eprojectCommands_str24), ((V)&g_app_2eheff_2emain_2eprojectCommands_str25), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_s_2443, 2), 1, (V[]){v_t_2451}));
  V v_z_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 1)), 2, (V[]){v_t_2450, v_t_2452}));
  V v_t_2454 = heff_tr(heff_call(heff_take_field(v_s_2443, 0), 1, (V[]){heff_get_n(v_c_240, 5, 6)}));
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 1)), 2, (V[]){v_t_2454, v_x_2445}));
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2443, 1)), 2, (V[]){v_t_2455, v_y_2449}));
  V f_ = heff_get_n(v_s_2443, 1, 4);
  heff_room[0] = v_t_2456;
  heff_room[1] = v_z_2453;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str0, 3, "lsp");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str1, 34, "a language server, on stdin/stdout");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str2, 5, "FLAGS");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str3, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str4, 68, "which heff this is: its version, as the package.hf it came with says");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str5, 9, "dump-core");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str8, 9, "dump-eval");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str9, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str10, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str11, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str12, 9, "dev-pages");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str14, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str15, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str16, 5, "PROXY");
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam7, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_t_245 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_247 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2412 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2440 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str12), ((V)&g_app_2eheff_2emain_2etoolCommands_str13), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam5, 1, 1, (V[]){v_c_240})});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2441})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2442})});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_243 = heff_tr(heff_call(heff_take_field(v_s_241, 3), 1, (V[]){v_t_242}));
  V v_t_244 = heff_tr(heff_call(heff_take_field(v_s_241, 0), 1, (V[]){heff_get_n(v_c_240, 0, 5)}));
  V f_ = heff_get_n(v_s_241, 1, 4);
  heff_room[0] = v_t_244;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_246, 0, 4);
  args[0] = heff_get_n(v_c_240, 1, 5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_2410 = heff_tr(heff_call(heff_take_field(v_s_248, 3), 1, (V[]){v_t_249}));
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_s_248, 0), 1, (V[]){heff_get_n(v_c_240, 2, 5)}));
  V f_ = heff_get_n(v_s_248, 1, 4);
  heff_room[0] = v_t_2411;
  heff_room[1] = v_x_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2414 = args[0];
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str10);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2413, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2418 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_s_2413, 3), 1, (V[]){v_t_2418}));
  V v_x_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2413, 1)), 2, (V[]){v_t_2417, v_t_2419}));
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_s_2413, 0), 1, (V[]){heff_get_n(v_c_240, 3, 5)}));
  V f_ = heff_get_n(v_s_2413, 1, 4);
  heff_room[0] = v_t_2421;
  heff_room[1] = v_x_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args) {
  V v_x2_2424 = args[0];
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str14);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    heff_take_n(v_x2_2424, 1ULL, 2);
    return v_x_2425;
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args) {
  V v_ws_2431 = args[0];
  switch (heff_tag_of(v_ws_2431)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_ws_2431, 0);
    heff_take_n(v_ws_2431, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2432});
  }
  default: return heff_nomatch(v_ws_2431);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam6_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str15), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 3)), 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 1)), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 0)), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam7_clo)}));
  V v_t_2435 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str16), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_s_2423, 3), 1, (V[]){v_t_2435}));
  V v_y_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 1)), 2, (V[]){v_t_2434, v_t_2436}));
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_s_2423, 0), 1, (V[]){heff_get_n(v_c_240, 4, 5)}));
  V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_s_2423, 1)), 2, (V[]){v_t_2438, v_x_2430}));
  V f_ = heff_get_n(v_s_2423, 1, 4);
  heff_room[0] = v_t_2439;
  heff_room[1] = v_y_2437;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_str1, 7, "testing");
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam3(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam9, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam8(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam12(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam10(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam14(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam16(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam15, 4, 0};
Clo g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_entry, 5, 0};

V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258(V v_rep_240, V v_prog_241, V v_clock_242, V v_rx_243, V v_ex_244) {
top: ;
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s2056889041x480202548_clo), 2, (V[]){heff_dup(v_rep_240), heff_dup(v_prog_241)}));
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo), 1, (V[]){heff_dup(v_rep_240)}));
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo), 1, (V[]){heff_dup(v_rep_240)}));
  V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_clo), 1, (V[]){heff_dup(v_rep_240)}));
  return heff_rec_n(9, shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt, (V[]){heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam0, 1, 1, (V[]){heff_dup(v_rep_240)}), v_t_245, heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam5, 6, 5, (V[]){v_clock_242, v_ex_244, heff_dup(v_prog_241), heff_dup(v_rep_240), v_rx_243}), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam10, 5, 2, (V[]){heff_dup(v_rep_240), v_prog_241}), v_t_246, heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam14, 4, 1, (V[]){v_rep_240}), v_t_247, v_t_248, ((V)&g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam15_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258(a[0], a[1], a[2], a[3], a[4]);
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_rep_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_2414); V a_2 = heff_get_n(v_x_2416, 0, 2); V a_3 = v_hd_2411; V a_4 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2415 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_2413));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam4, 1, 4, (V[]){v_rep_240, v_x_2414, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_str0), heff_dup(heff_rfield(v_x_2413, 1)), MK_INT(0LL), heff_dup(v_hd_2411), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam3, 1, 4, (V[]){v_x_2413, v_hd_2411, v_rep_240, v_k_2412})));
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam2, 1, 3, (V[]){v_hd_2411, v_rep_240, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam0(V self, V *args) {
  V v_file_249 = args[0];
  V v_rep_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_file_249));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam1, 2, 2, (V[]){v_c_2410, v_rep_240});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam9(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_rx_243 = heff_env(self)[2];
  V v_ex_244 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  V v_hd_2424 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2428));
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_str1), v_total_2429, ((V)&g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam9_clo)})}));
  return (g_co_2eop_24s1594985323x520615696(v_rep_240, v_prog_241, v_rx_243, v_ex_244, v_x_2426, v_x_2428, heff_dup(v_hd_2424), v_k_2425, v_t_2431, v_hd_2424));
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_given_2422 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rx_243 = heff_env(self)[4];
  V v_ex_244 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2427 = (g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(v_given_2422));
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam8, 1, 7, (V[]){v_prog_241, v_rep_240, v_rx_243, v_ex_244, v_x_2426, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_given_2422 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rx_243 = heff_env(self)[4];
  V v_ex_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam7, 1, 7, (V[]){v_given_2422, v_hd_2424, v_prog_241, v_rep_240, v_rx_243, v_ex_244, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam5(V self, V *args) {
  V v_seed_2417 = args[0];
  V v_pattern_2418 = args[1];
  V v_jobs_2419 = args[2];
  V v_update_2420 = args[3];
  V v_watch_2421 = args[4];
  V v_given_2422 = args[5];
  V v_clock_242 = heff_env(self)[0];
  V v_ex_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rx_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_watch_2421) == NTAG(TAG_True))) {
    heff_drop(v_watch_2421);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    heff_drop(v_rx_243);
    return ({ V a_0 = v_clock_242; V a_1 = v_ex_244; V a_2 = v_seed_2417; V a_3 = v_pattern_2418; V a_4 = v_jobs_2419; V a_5 = v_update_2420; V a_6 = v_given_2422; V r_ = (g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_seed_2417); heff_drop(v_pattern_2418); heff_drop(v_jobs_2419); heff_drop(v_update_2420); r_; });
  } else {
    heff_drop(v_watch_2421);
    heff_drop(v_clock_242);
    V v_c_2423 = ({ V a_0 = v_seed_2417; V a_1 = v_pattern_2418; V a_2 = v_jobs_2419; V a_3 = v_update_2420; V r_ = (g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(a_0, a_1, a_2, a_3)); heff_drop(v_seed_2417); heff_drop(v_pattern_2418); heff_drop(v_jobs_2419); r_; });
    return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam6, 2, 6, (V[]){v_c_2423, v_given_2422, v_prog_241, v_rep_240, v_rx_243, v_ex_244});
  }
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam13(V self, V *args) {
  V v_x_2442 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_hd_2438 = heff_env(self)[3];
  V v_k_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_x_2440; V a_3 = v_x_2442; V a_4 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_5 = v_hd_2438; V a_6 = v_k_2439; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2442); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam12(V self, V *args) {
  V v_x_2440 = args[0];
  V v_given_2436 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_k_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2441 = (g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888(v_given_2436));
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_2438);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam13, 1, 5, (V[]){v_rep_240, v_prog_241, v_x_2440, v_hd_2438, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam11(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_given_2436 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam12, 1, 5, (V[]){v_given_2436, v_hd_2438, v_rep_240, v_prog_241, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam10(V self, V *args) {
  V v_pattern_2432 = args[0];
  V v_time_2433 = args[1];
  V v_count_2434 = args[2];
  V v_json_2435 = args[3];
  V v_given_2436 = args[4];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2437 = ({ V a_0 = v_pattern_2432; V a_1 = v_time_2433; V a_2 = v_count_2434; V a_3 = v_json_2435; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986(a_0, a_1, a_2, a_3)); heff_drop(v_pattern_2432); r_; });
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam11, 2, 4, (V[]){v_c_2437, v_given_2436, v_rep_240, v_prog_241});
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam14(V self, V *args) {
  V v_file_2443 = args[0];
  V v_outPath_2444 = args[1];
  V v_name_2445 = args[2];
  V v_backend_2446 = args[3];
  V v_rep_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689(v_rep_240, heff_rec_n(4, shape_file__outPath__name__backend, (V[]){v_file_2443, v_outPath_2444, v_name_2445, v_backend_2446})));
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam16(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  V v_k_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intLt_c(MK_INT(0LL), v_x_2451)) {
    V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_hd_2449, v_k_2450));
  } else {
    heff_drop(v_hd_2449);
    V f_ = v_k_2450;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam15(V self, V *args) {
  V v_check_2447 = args[0];
  V v_files_2448 = args[1];
  V v_hd_2449 = args[2];
  V v_k_2450 = args[3];
  return ({ V a_0 = v_check_2447; V a_1 = v_files_2448; V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_hd_2449); V a_4 = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258_lam16, 1, 2, (V[]){v_hd_2449, v_k_2450}); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_check_2447); heff_drop(v_files_2448); r_; });
}
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s457440104x1206769205_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s457440104x1206769205_str1, 1, ".");
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam0, 1, 0};
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eproject_24s457440104x1206769205_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s457440104x1206769205_entry, 4, 0};

V g_app_2eheff_2emain_2eproject_24s457440104x1206769205(V v_rep_240, V v_prog_241, V v_clock_242, V v_ex_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_clo), 1, (V[]){heff_dup(v_prog_241)}));
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_clo), 2, (V[]){heff_dup(v_rep_240), heff_dup(v_prog_241)}));
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_clo), 1, (V[]){heff_dup(v_rep_240)}));
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo), 3, (V[]){heff_dup(v_prog_241), v_clock_242, v_ex_243}));
  return heff_rec_n(6, shape_init__get__build__install__publish__dev, (V[]){((V)&g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam0_clo), v_t_244, v_t_245, heff_clo_n(g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam1, 1, 2, (V[]){v_rep_240, v_prog_241}), v_t_246, v_t_247});
}
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eproject_24s457440104x1206769205(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam0(V self, V *args) {
  V v_dir_248 = args[0];
  V v_t_2410;
  switch (heff_tag_of(v_dir_248)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_app_2eheff_2emain_2eproject_24s457440104x1206769205_str0);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_dir_248, 0);
    heff_take_n(v_dir_248, 1ULL, 1);
    v_t_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_dir_248);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo);
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eproject_24s457440104x1206769205_lam1(V self, V *args) {
  V v_dir_2411 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_dir_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_app_2eheff_2emain_2eproject_24s457440104x1206769205_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_dir_2411, 0);
    heff_take_n(v_dir_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_dir_2411);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_clo);
  heff_room[0] = v_rep_240;
  heff_room[1] = v_prog_241;
  heff_room[2] = v_t_2413;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_str0, 4, "heff");
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam3, 1, 0};
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam2(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam0(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam6(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam5(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam4, 3, 0};
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam11(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam10(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam9(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam8(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam7(V self, V *args);
Clo g_app_2eheff_2emain_2etool_24s1214440417x2108196942_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1214440417x2108196942_entry, 7, 0};

V g_app_2eheff_2emain_2etool_24s1214440417x2108196942(V v_rep_240, V v_wire_241, V v_nt_242, V v_rx_243, V v_web_244, V v_ex_245, V v_nx_246) {
top: ;
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo), 4, (V[]){v_nt_242, v_rx_243, v_web_244, v_nx_246}));
  return heff_rec_n(5, shape_lsp__version__dumpCore__dumpEval__devPages, (V[]){heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam0, 1, 1, (V[]){v_wire_241}), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_clo), ((V)&g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam4_clo), heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam7, 1, 1, (V[]){v_rep_240}), v_t_247});
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_app_2eheff_2emain_2etool_24s1214440417x2108196942(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam3(V self, V *args) {
  V v_a_2413 = args[0];
  return v_a_2413;
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_wire_241 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_tag_n(TAG_AbsPath, 2, (V[]){heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam3_clo)});
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_wire_241), 1, (V[]){v_t_2414}));
  return (g_co_2eop_24s173284549x1274703393(v_wire_241, v_x_2412, heff_dup(v_hd_2410), v_k_2411, v_t_2415, v_hd_2410));
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_wire_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam2, 1, 3, (V[]){v_wire_241, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam0(V self, V *args) {
  V v_flags_248 = args[0];
  V v_wire_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_flags_248);
  V v_c_249 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam1, 2, 2, (V[]){v_c_249, v_wire_241});
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intEq_c(v_x_2422, MK_INT(0LL))) {
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_hd_2417, v_k_2418));
  }
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_list_2efoldl_24s1649248084x1368208491(NTAG(TAG_Nil), v_x_2419));
  V v_c_2421 = ({ V a_0 = v_t_2420; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam6, 1, 2, (V[]){v_k_2418, v_hd_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam4(V self, V *args) {
  V v_paths_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(NTAG(TAG_Nil), v_paths_2416, heff_dup(v_hd_2417), heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam5, 1, 2, (V[]){v_hd_2417, v_k_2418})));
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_rep_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_2436); V a_2 = heff_get_n(v_x_2438, 0, 2); V a_3 = v_hd_2433; V a_4 = v_k_2434; V r_ = (g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam10(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_hd_2433 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2437 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_2435));
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_hd_2433);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam11, 1, 4, (V[]){v_rep_240, v_x_2436, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2433 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_app_2eheff_2emain_2etool_24s1214440417x2108196942_str0), heff_dup(heff_rfield(v_x_2435, 1)), MK_INT(0LL), heff_dup(v_hd_2433), heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam10, 1, 4, (V[]){v_x_2435, v_hd_2433, v_rep_240, v_k_2434})));
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam8(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam9, 1, 3, (V[]){v_hd_2433, v_rep_240, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam7(V self, V *args) {
  V v_file_2431 = args[0];
  V v_rep_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2432 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_file_2431));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1214440417x2108196942_lam8, 2, 2, (V[]){v_c_2432, v_rep_240});
}
HEFF_LIT(g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_str0, 4, "heff");
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_entry, 12, 0};

V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(V v_rep_240, V v_wire_241, V v_prog_242, V v_clock_243, V v_nt_244, V v_rx_245, V v_web_246, V v_ex_247, V v_nx_248, V v_argv_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258(heff_dup(v_rep_240), heff_dup(v_prog_242), heff_dup(v_clock_243), heff_dup(v_rx_245), heff_dup(v_ex_247)));
  V v_t_2413 = (g_app_2eheff_2emain_2eproject_24s457440104x1206769205(heff_dup(v_rep_240), v_prog_242, v_clock_243, heff_dup(v_ex_247)));
  V v_t_2414 = ({ V a_0 = v_rep_240; V a_1 = v_wire_241; V a_2 = v_nt_244; V a_3 = v_rx_245; V a_4 = v_web_246; V a_5 = v_ex_247; V a_6 = v_nx_248; V r_ = (g_app_2eheff_2emain_2etool_24s1214440417x2108196942(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_ex_247); r_; });
  V v_t_2415 = (g_app_2eheff_2emain_2ebuildCommands(v_t_2412));
  V v_t_2416 = (g_app_2eheff_2emain_2eprojectCommands(v_t_2413));
  V v_t_2417 = (g_app_2eheff_2emain_2etoolCommands(v_t_2414));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2418));
  HeffT2 v_t_2420 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_str0), v_t_2419, v_argv_249));
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_text_2424 = v_field_2422;
      V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2424, NTAG(TAG_MkUnit)});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_z_2410), heff_clo_n(g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_lam0, 1, 2, (V[]){v_z_2410, v_z_2411})));
    } else {
      if ((v_tag_2421 == ((int64_t)1ULL))) {
        V v_text_2441 = v_field_2422;
        V v_t_2442 = heff_tag_n(TAG_Write, 2, (V[]){v_text_2441, NTAG(TAG_MkUnit)});
        V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
        V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
        V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
        V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
        V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
        V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
        return (g_co_2eop_24s22628809x1035315751(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_2410, v_z_2411));
      } else {
        V v_act_2449 = v_field_2422;
        return heff_tail(v_act_2449, 2, (V[]){v_z_2410, v_z_2411});
      }
    }
  }
}
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_lam0(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_2410 = heff_env(self)[0];
  V v_z_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_z_2410, v_z_2411));
}
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str0, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str1, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str2, 2, "$ ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str3, 1, "\012");
Clo g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_entry, 12, 0};

V g_app_2eheff_2emain_2eexplored_24s1499133303x676910618(V v_rep_240, V v_wire_241, V v_prog_242, V v_clock_243, V v_nt_244, V v_rx_245, V v_web_246, V v_ex_247, V v_nx_248, V v_chosen_249, V v_z_2410, V v_z_2411) {
top: ;
  switch (heff_tag_of(v_chosen_249)) {
  case TAG_Nothing: {
    heff_drop(v_rep_240);
    heff_drop(v_wire_241);
    heff_drop(v_prog_242);
    heff_drop(v_clock_243);
    heff_drop(v_nt_244);
    heff_drop(v_rx_245);
    heff_drop(v_web_246);
    heff_drop(v_ex_247);
    heff_drop(v_nx_248);
    heff_drop(v_z_2410);
    return heff_tail(v_z_2411, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_chosen1_2412 = heff_field(v_chosen_249, 0);
    V v_ru_24chosen_249_24Just = heff_take_reuse_n(v_chosen_249, 1ULL, 1);
    switch (heff_tag_of(v_chosen1_2412)) {
    case TAG_Nothing: {
      heff_drop(v_rep_240);
      heff_drop(v_wire_241);
      heff_drop(v_prog_242);
      heff_drop(v_clock_243);
      heff_drop(v_nt_244);
      heff_drop(v_rx_245);
      heff_drop(v_web_246);
      heff_drop(v_ex_247);
      heff_drop(v_nx_248);
      heff_drop(v_z_2410);
      heff_drop_cell(v_ru_24chosen_249_24Just, 1);
      return heff_tail(v_z_2411, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_Just: {
      V v_ws_2413 = heff_field(v_chosen1_2412, 0);
      V v_ru_24chosen1_2412_24Just = heff_take_reuse_n(v_chosen1_2412, 1ULL, 1);
      V v_t_2414 = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(((V)&g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str0), ((V)&g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str1), v_ws_2413));
      V v_str_2415 = heff_strAppend(((V)&g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str2), v_t_2414);
      V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2415, ((V)&g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_str3)), NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_at_n(v_ru_24chosen_249_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_at_n(v_ru_24chosen1_2412_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
      return (g_co_2eop_24s1278336259x450164198(v_rep_240, v_wire_241, v_prog_242, v_clock_243, v_nt_244, v_rx_245, v_web_246, v_ex_247, v_nx_248, v_ws_2413, heff_dup(v_z_2410), v_z_2411, heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_z_2410));
    }
    default: return heff_nomatch(v_chosen1_2412);
    }
  }
  default: return heff_nomatch(v_chosen_249);
  }
}
V g_app_2eheff_2emain_2eexplored_24s1499133303x676910618_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eexplored_24s1499133303x676910618(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str2, 4, "heff");
V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_entry, 13, 0};

V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250(V v_rep_240, V v_wire_241, V v_prog_242, V v_con_243, V v_clock_244, V v_nt_245, V v_rx_246, V v_web_247, V v_ex_248, V v_nx_249, V v_x1_2410, V v_z_2411, V v_z_2412) {
top: ;
  if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
    V v_t_2413 = (g_app_2eheff_2emain_2ebuild_24s1073383096x1356684258(heff_dup(v_rep_240), heff_dup(v_prog_242), heff_dup(v_clock_244), heff_dup(v_rx_246), heff_dup(v_ex_248)));
    V v_t_2414 = (g_app_2eheff_2emain_2eproject_24s457440104x1206769205(heff_dup(v_rep_240), heff_dup(v_prog_242), heff_dup(v_clock_244), heff_dup(v_ex_248)));
    V v_t_2415 = (g_app_2eheff_2emain_2etool_24s1214440417x2108196942(heff_dup(v_rep_240), heff_dup(v_wire_241), heff_dup(v_nt_245), heff_dup(v_rx_246), heff_dup(v_web_247), v_ex_248, heff_dup(v_nx_249)));
    V v_t_2416 = (g_app_2eheff_2emain_2ebuildCommands(v_t_2413));
    V v_t_2417 = (g_app_2eheff_2emain_2eprojectCommands(v_t_2414));
    V v_t_2418 = (g_app_2eheff_2emain_2etoolCommands(v_t_2415));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2420 = (g_list_2efilter_24f75237897x367824150(v_t_2416, v_t_2419));
    V v_es_2421 = (g_list_2emap_24s1531382666x123921537(v_t_2420));
    V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2423 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str1)), v_t_2422});
    V v_t_2424 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_str2), v_es_2421, v_t_2423, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), NTAG(TAG_Nothing)});
    V v_c_2425 = (g_std_2eterminal_2einteract_24s1344509824x1570875242(v_con_243, heff_rec_n(3, shape_start__step__view, (V[]){v_t_2424, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)})));
    return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_z_2411), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_lam0, 1, 11, (V[]){v_rep_240, v_wire_241, v_prog_242, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, v_z_2411, v_z_2412})});
  } else {
    heff_drop(v_con_243);
    return (g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(v_rep_240, v_wire_241, v_prog_242, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, NTAG(TAG_Nil), v_z_2411, v_z_2412));
  }
}
V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10, a[11], a[12]); heff_drop(a10); return r;
}
V g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_wire_241 = heff_env(self)[1];
  V v_prog_242 = heff_env(self)[2];
  V v_clock_244 = heff_env(self)[3];
  V v_nt_245 = heff_env(self)[4];
  V v_rx_246 = heff_env(self)[5];
  V v_web_247 = heff_env(self)[6];
  V v_ex_248 = heff_env(self)[7];
  V v_nx_249 = heff_env(self)[8];
  V v_z_2411 = heff_env(self)[9];
  V v_z_2412 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_app_2eheff_2emain_2eexplored_24s1499133303x676910618(v_rep_240, v_wire_241, v_prog_242, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, v_x_2426, v_z_2411, v_z_2412));
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam3(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s92965591x238646117_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s92965591x238646117_entry, 12, 0};

V g_app_2eheff_2emain_2eprogram_24s92965591x238646117(V v_rep_240, V v_wire_241, V v_prog_242, V v_con_243, V v_clock_244, V v_nt_245, V v_rx_246, V v_web_247, V v_ex_248, V v_nx_249, V v_hd_2410, V v_k_2411) {
top: ;
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam0_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_2410), heff_clo_n(g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam1, 1, 12, (V[]){v_con_243, v_hd_2410, v_rep_240, v_wire_241, v_prog_242, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, v_k_2411})));
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s92965591x238646117(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam0(V self, V *args) {
  V v_a_2412 = args[0];
  return v_a_2412;
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam2(V self, V *args) {
  V v_b_2421 = args[0];
  return v_b_2421;
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_wire_241 = heff_env(self)[1];
  V v_prog_242 = heff_env(self)[2];
  V v_con_243 = heff_env(self)[3];
  V v_clock_244 = heff_env(self)[4];
  V v_nt_245 = heff_env(self)[5];
  V v_rx_246 = heff_env(self)[6];
  V v_web_247 = heff_env(self)[7];
  V v_ex_248 = heff_env(self)[8];
  V v_nx_249 = heff_env(self)[9];
  V v_hd_2410 = heff_env(self)[10];
  V v_k_2411 = heff_env(self)[11];
  heff_clo_take(self, 12);
  return ({ V a_0 = v_rep_240; V a_1 = v_wire_241; V a_2 = v_prog_242; V a_3 = v_con_243; V a_4 = v_clock_244; V a_5 = v_nt_245; V a_6 = v_rx_246; V a_7 = v_web_247; V a_8 = v_ex_248; V a_9 = v_nx_249; V a_10 = v_x_2423; V a_11 = v_hd_2410; V a_12 = v_k_2411; V r_ = (g_app_2eheff_2emain_2eexplore_24s1106334960x1368274250(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_x_2423); r_; });
}
V g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_con_243 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_wire_241 = heff_env(self)[3];
  V v_prog_242 = heff_env(self)[4];
  V v_clock_244 = heff_env(self)[5];
  V v_nt_245 = heff_env(self)[6];
  V v_rx_246 = heff_env(self)[7];
  V v_web_247 = heff_env(self)[8];
  V v_ex_248 = heff_env(self)[9];
  V v_nx_249 = heff_env(self)[10];
  V v_k_2411 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nil: {
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_con_243), 1, (V[]){heff_tag_n(TAG_Interactive, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam2_clo)})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2422, heff_dup(v_hd_2410), heff_clo_n(g_app_2eheff_2emain_2eprogram_24s92965591x238646117_lam3, 1, 12, (V[]){v_rep_240, v_wire_241, v_prog_242, v_con_243, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, v_hd_2410, v_k_2411})));
  }
  case TAG_Cons: {
    heff_drop(v_con_243);
    return (g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(v_rep_240, v_wire_241, v_prog_242, v_clock_244, v_nt_245, v_rx_246, v_web_247, v_ex_248, v_nx_249, v_x_2420, v_hd_2410, v_k_2411));
  }
  default: return heff_nomatch(v_x_2420);
  }
}
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str0, 6, "heff: ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str1, 1, "\012");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str2, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str3, 6, "heff: ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str4, 1, "\012");
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam0(V self, V *args);
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_entry, 3, 0};

V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Left = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_strAppend(((V)&g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str0), heff_get_n(v_err_243, 2, 3));
    V v_t_245 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str1)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_241), heff_clo_n(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam0, 1, 2, (V[]){v_p_241, v_p_242}));
  }
  case TAG_Right: {
    V v_x11_2418 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Right = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_err_2419 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_t_2420 = heff_strAppend(((V)&g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str2), heff_take_field(v_err_2419, 2));
      V v_t_2421 = heff_strAppend(heff_get_n(v_err_2419, 1, 3), v_t_2420);
      V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str3), v_t_2421), ((V)&g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_str4));
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_at_n(v_ru_24x1_240_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_p_241), heff_clo_n(g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam1, 1, 2, (V[]){v_p_241, v_p_242}));
    }
    case TAG_Right: {
      heff_take_n(v_x11_2418, 0ULL, 1);
      heff_drop(v_p_241);
      heff_drop_cell(v_ru_24x1_240_24Right, 1);
      return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eunheard_24s2096358522x384508544(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_p_241, v_p_242));
}
V g_app_2eheff_2emain_2eunheard_24s2096358522x384508544_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_p_241, v_p_242));
}
V g_app_2eheff_2emain_2emain_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam0, 1, 0};
V g_app_2eheff_2emain_2emain_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam1, 1, 0};
V g_app_2eheff_2emain_2emain_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam2, 1, 0};
V g_app_2eheff_2emain_2emain_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam3, 1, 0};
V g_app_2eheff_2emain_2emain_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam4, 1, 0};
V g_app_2eheff_2emain_2emain_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam5, 1, 0};
V g_app_2eheff_2emain_2emain_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam6, 1, 0};
V g_app_2eheff_2emain_2emain_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam7, 1, 0};
V g_app_2eheff_2emain_2emain_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam8, 1, 0};
V g_app_2eheff_2emain_2emain_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam9, 1, 0};
V g_app_2eheff_2emain_2emain_lam11(V self, V *args);
V g_app_2eheff_2emain_2emain_lam10(V self, V *args);
Clo g_app_2eheff_2emain_2emain_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_entry, 3, 0};

V g_app_2eheff_2emain_2emain(V v_z_240, V v_z_241, V v_z_242) {
top: ;
  V v_e_243 = (g_co_2eplus_24s58116330x1448227934(heff_dup(g_app_2eheff_2emain_2eworld_get())));
  V v_t_244 = (g_co_2eplus_24s58116330x1448227934(heff_dup(g_app_2eheff_2emain_2eworld_get())));
  V v_e_245 = (g_co_2eplus_24s860740675x1298266759(v_t_244));
  V v_h_246 = (g_co_2eplus_24s1257879563x1568253915(heff_dup(v_e_245)));
  heff_drop(v_h_246);
  V v_hd_247 = (g_exception_2eattempted(v_e_245));
  V v_c_2439 = heff_tr(g_app_2eheff_2emain_2eprogram_24s92965591x238646117(((V)&g_app_2eheff_2emain_2emain_lam0_clo), ((V)&g_app_2eheff_2emain_2emain_lam1_clo), ((V)&g_app_2eheff_2emain_2emain_lam2_clo), ((V)&g_app_2eheff_2emain_2emain_lam3_clo), ((V)&g_app_2eheff_2emain_2emain_lam4_clo), ((V)&g_app_2eheff_2emain_2emain_lam5_clo), ((V)&g_app_2eheff_2emain_2emain_lam6_clo), ((V)&g_app_2eheff_2emain_2emain_lam7_clo), ((V)&g_app_2eheff_2emain_2emain_lam8_clo), ((V)&g_app_2eheff_2emain_2emain_lam9_clo), heff_dup(v_hd_247), heff_get_n(v_hd_247, 0, 3)));
  V v_h_2440 = (g_co_2eplus_24s1257879563x1568253915(heff_dup(v_e_243)));
  heff_drop(v_h_2440);
  V v_hd_2441 = (g_exception_2eattempted(v_e_243));
  V v_c_2442 = heff_tr(heff_call(v_c_2439, 2, (V[]){heff_dup(v_hd_2441), heff_get_n(v_hd_2441, 0, 3)}));
  return (g_std_2eprogress_2eshown_24s240023447x857982376(heff_clo_n(g_app_2eheff_2emain_2emain_lam10, 2, 1, (V[]){v_c_2442}), v_z_240, v_z_241, v_z_242));
}
V g_app_2eheff_2emain_2emain_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2emain(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2emain_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2413});
}
V g_app_2eheff_2emain_2emain_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
}
V g_app_2eheff_2emain_2emain_lam2(V self, V *args) {
  V v_p_2419 = args[0];
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_p_2419})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2420});
}
V g_app_2eheff_2emain_2emain_lam3(V self, V *args) {
  V v_p_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
}
V g_app_2eheff_2emain_2emain_lam4(V self, V *args) {
  V v_p_2425 = args[0];
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2428});
}
V g_app_2eheff_2emain_2emain_lam5(V self, V *args) {
  V v_p_2429 = args[0];
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
}
V g_app_2eheff_2emain_2emain_lam6(V self, V *args) {
  V v_p_2432 = args[0];
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2434});
}
V g_app_2eheff_2emain_2emain_lam7(V self, V *args) {
  V v_p_2435 = args[0];
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2435})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
}
V g_app_2eheff_2emain_2emain_lam8(V self, V *args) {
  V v_p_2437 = args[0];
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_p_2437})});
}
V g_app_2eheff_2emain_2emain_lam9(V self, V *args) {
  V v_p_2438 = args[0];
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_2438});
}
V g_app_2eheff_2emain_2emain_lam11(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2443 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_app_2eheff_2emain_2eunheard_24s2096358522x384508544(v_x_2445, v_hd_2443, v_k_2444));
}
V g_app_2eheff_2emain_2emain_lam10(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2442;
  args[0] = heff_dup(v_hd_2443);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2emain_lam11, 1, 2, (V[]){v_hd_2443, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}