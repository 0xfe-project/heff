// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Among 19600
#define TAG_Begin 41697
#define TAG_Catch 6517
#define TAG_Dirs 41877
#define TAG_Files 59123
#define TAG_Finish 61316
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35658
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bench 294981194
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_dev 308879
#define LBL_devPages 1831184971
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_explain 1070179126
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_filter 672649891
#define LBL_flag 9641011
#define LBL_fmap 9641981
#define LBL_fmt 311047
#define LBL_form 9644427
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_globals 352931696
#define LBL_hmap 9701563
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_lib 316671
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_malg 9839318
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_ran 322201
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_typeAt 1088337976
#define LBL_typing 1088343202
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_view 10114924
static uint32_t shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc[] = {LBL_check, LBL_run, LBL_tests, LBL_bench, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt, LBL_doc};
static uint32_t shape_file__outPath__name__backend[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_init__get__build__install__publish__dev[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish, LBL_dev};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval__devPages[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval, LBL_devPages};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_start__step__view[] = {LBL_start, LBL_step, LBL_view};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_get(void);
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(V, V, V);
V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_clo;
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246(V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_clo;
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_clo;
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380(V, V, V);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_get(void);
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_get(void);
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2eop_24s1964021109x2127220916(V, V, V);
V g_co_2eop_24s1964021109x2127220916_entry(V self, V *a);
extern Clo g_co_2eop_24s1964021109x2127220916_clo;
V g_co_2eop_24s349465857x1414991782(V, V, V, V, V, V);
V g_co_2eop_24s349465857x1414991782_entry(V self, V *a);
extern Clo g_co_2eop_24s349465857x1414991782_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s995775659x1481479477(V, V, V, V, V);
V g_co_2eop_24s995775659x1481479477_entry(V self, V *a);
extern Clo g_co_2eop_24s995775659x1481479477_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_get(void);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462(V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320(V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814(V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_clo;
V g_heff_2ebuild_2edocpages_2edocCmd_24s692738791x410329807(V, V);
V g_heff_2ebuild_2edocpages_2edocCmd_24s692738791x410329807_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocCmd_24s692738791x410329807_clo;
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296(V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562(V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536(V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_clo;
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1271133029x1548514599(V, V);
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1271133029x1548514599_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eprogress_2eroot_get(void);
V g_std_2eterminal_2eloop_24s40037404x625033307(V, V, V, V);
V g_std_2eterminal_2eloop_24s40037404x625033307_entry(V self, V *a);
extern Clo g_std_2eterminal_2eloop_24s40037404x625033307_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
HEFF_LIT(g_app_2eheff_2emain_2ehf_str0, 3, ".hf");

static V g_app_2eheff_2emain_2ehf_val;
static HEFF_ONCE g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag_n(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ehf_st)) return g_app_2eheff_2emain_2ehf_val;
  return heff_global(&g_app_2eheff_2emain_2ehf_val, &g_app_2eheff_2emain_2ehf_st, g_app_2eheff_2emain_2ehf_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str0, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str1, 55, "elaborate FILE and what it imports; print its interface");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str3, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str4, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str5, 76, "run FILE's main with ARGS, compiled through C (by zig at -O1, in .heff/run/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str8, 4, "ARGS");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str9, 4, "test");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str10, 263, "check the expectations of the watches (the `-- ...` lines under them) and doc tests (the `-- | ...` lines under them), and run the tests (the definitions of type `Test`, check's), of the FILEs (a directory's .hf files), else of the project's here (src/ and test/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str11, 4, "seed");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str12, 1, "s");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str13, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str14, 64, "the seed the properties draw from (the same seed, the same runs)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str15, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str16, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str17, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str18, 82, "run only the tests whose names it matches, a level each between `/`s: `^lsp/hover`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str19, 4, "jobs");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str20, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str21, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str22, 76, "how many integration tests run at once (HEFF_TEST_JOBS, else half the cores)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str23, 6, "update");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str24, 1, "u");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str25, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str26, 58, "write each golden text the tests keep, not hold them to it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str27, 5, "watch");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str28, 1, "w");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str29, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str30, 127, "then test again at each change of the FILEs, of what they import, and of the project's sources, until ended (not with --update)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str31, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str32, 5, "bench");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str33, 259, "run the benchmarks (the definitions of type `Bench`, bench's) of the FILEs (a directory's .hf files), else of the project's benchmarks here (bench/): each built through C (by zig at -O2), run until a run takes the bench time, and said a line each, as Go's are");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str34, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str35, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str36, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str37, 95, "run only the benchmarks whose names it matches, a level each between `/`s, as `heff test --run`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str38, 4, "time");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str39, 1, "t");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str40, 1, "D");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str41, 92, "how long each is run, at least: a duration (1s, the default; 500ms, 1.5s), or a count (100x)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str42, 5, "count");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str43, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str44, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str45, 33, "run each N times, a line each (1)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str46, 4, "json");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str47, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str48, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str49, 26, "say each as a line of JSON");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str50, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str51, 7, "promote");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str52, 67, "write each watch's and doc test's value under it as its expectation");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str53, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str54, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str55, 7, "compile");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str56, 134, "FILE compiled, by MODE: esm (an ES module), page (a script running the app NAME in a page), c (a C program running NAME, for `zig cc`)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str57, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str58, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str59, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str60, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str61, 4, "name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str62, 1, "n");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str63, 4, "NAME");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str64, 29, "the computation run (page, c)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str65, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str66, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str67, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str68, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str69, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str70, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str71, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str72, 7, "backend");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str73, 1, "b");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str74, 4, "MODE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str75, 22, "what it is compiled to");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str76, 7, "explain");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str77, 21, "the elaboration trace");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str78, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str79, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str80, 7, "type-at");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str81, 67, "what the name at each OFFSET resolved to, and its type, a line each");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str82, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str83, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str84, 6, "OFFSET");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str85, 3, "fmt");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str86, 21, "format FILEs in place");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str87, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str88, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str89, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str90, 32, "only say which are not formatted");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str91, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str92, 3, "doc");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str93, 235, "a reference page, Markdown, of each module of the FILEs (a directory's .hf files), else of the project's here (src/): its header comment, then each definition it exposes, its signature and its doc comment; printed, or written under DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str94, 3, "out");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str95, 1, "o");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str96, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str97, 113, "write each page under DIR, at its module's path (std.path at DIR/std/path.md), and an index of them, DIR/index.md");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str98, 4, "FILE");
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam18, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam20, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_check_241 = heff_take_field(v_c_240, 0);
  V v_run_242 = heff_take_field(v_c_240, 1);
  V v_tests_243 = heff_take_field(v_c_240, 2);
  V v_bench_244 = heff_take_field(v_c_240, 3);
  V v_promote_245 = heff_take_field(v_c_240, 4);
  V v_compile_246 = heff_take_field(v_c_240, 5);
  V v_explain_247 = heff_take_field(v_c_240, 6);
  V v_typeAt_248 = heff_take_field(v_c_240, 7);
  V v_fmt_249 = heff_take_field(v_c_240, 8);
  V v_doc_2410 = heff_get_n(v_c_240, 9, 10);
  V v_t_2423 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){v_check_241})});
  V v_t_2439 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){v_run_242})});
  V v_t_2479 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){v_tests_243})});
  V v_t_24111 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), ((V)&g_app_2eheff_2emain_2ebuildCommands_str33), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){v_bench_244})});
  V v_t_24124 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str51), ((V)&g_app_2eheff_2emain_2ebuildCommands_str52), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 1, (V[]){v_promote_245})});
  V v_t_24165 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){v_compile_246})});
  V v_t_24178 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str76), ((V)&g_app_2eheff_2emain_2ebuildCommands_str77), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){v_explain_247})});
  V v_t_24194 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str80), ((V)&g_app_2eheff_2emain_2ebuildCommands_str81), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam17, 1, 1, (V[]){v_typeAt_248})});
  V v_t_24211 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str85), ((V)&g_app_2eheff_2emain_2ebuildCommands_str86), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam19, 1, 1, (V[]){v_fmt_249})});
  V v_t_24225 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str92), ((V)&g_app_2eheff_2emain_2ebuildCommands_str93), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam21, 1, 1, (V[]){v_doc_2410})});
  V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24225, NTAG(TAG_Nil)});
  V v_t_24227 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24194, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24211, v_t_24226})});
  V v_t_24228 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24178, v_t_24227})});
  V v_t_24229 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, v_t_24228})});
  V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_24229})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_24230});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_2415 = args[0];
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 2);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_check_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2412 = heff_take_field(v_s_2411, 1);
  V v_give_2413 = heff_take_field(v_s_2411, 0);
  V v_pos_2414 = heff_get_n(v_s_2411, 3, 4);
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_give_2413), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_2419 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2420 = heff_tr(heff_call(v_pos_2414, 1, (V[]){v_t_2419}));
  V v_x_2421 = heff_tr(heff_call(heff_dup(v_ap_2412), 2, (V[]){v_t_2418, v_t_2420}));
  V v_t_2422 = heff_tr(heff_call(v_give_2413, 1, (V[]){v_check_241}));
  V f_ = v_ap_2412;
  heff_room[0] = v_t_2422;
  heff_room[1] = v_x_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2428 = args[0];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    heff_take_n(v_x2_2428, 1ULL, 2);
    return v_x_2429;
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_run_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2425 = heff_take_field(v_s_2424, 1);
  V v_give_2426 = heff_take_field(v_s_2424, 0);
  V v_pos_2427 = heff_get_n(v_s_2424, 3, 4);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_give_2426), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2432 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2433 = heff_tr(heff_call(heff_dup(v_pos_2427), 1, (V[]){v_t_2432}));
  V v_x_2434 = heff_tr(heff_call(heff_dup(v_ap_2425), 2, (V[]){v_t_2431, v_t_2433}));
  V v_t_2435 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2436 = heff_tr(heff_call(v_pos_2427, 1, (V[]){v_t_2435}));
  V v_t_2437 = heff_tr(heff_call(v_give_2426, 1, (V[]){v_run_242}));
  V v_t_2438 = heff_tr(heff_call(heff_dup(v_ap_2425), 2, (V[]){v_t_2437, v_x_2434}));
  V f_ = v_ap_2425;
  heff_room[0] = v_t_2438;
  heff_room[1] = v_y_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_vs_2457 = args[0];
  switch (heff_tag_of(v_vs_2457)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2457, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2457);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_vs_2469 = args[0];
  switch (heff_tag_of(v_vs_2469)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2469, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2469);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2440 = args[0];
  V v_tests_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2441 = heff_take_field(v_s_2440, 1);
  V v_give_2442 = heff_take_field(v_s_2440, 0);
  V v_flag_2443 = heff_take_field(v_s_2440, 2);
  V v_pos_2444 = heff_get_n(v_s_2440, 3, 4);
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2446 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2447 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2446}));
  V v_x_2448 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2445, v_t_2447}));
  V v_t_2449 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2450 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), ((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), ((V)&g_app_2eheff_2emain_2ebuildCommands_str18), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2450}));
  V v_y_2452 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2449, v_t_2451}));
  V v_t_2453 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2454 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), ((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), ((V)&g_app_2eheff_2emain_2ebuildCommands_str22), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2454}));
  V v_z_2456 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2453, v_t_2455}));
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam5_clo)}));
  V v_t_2461 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), ((V)&g_app_2eheff_2emain_2ebuildCommands_str24), ((V)&g_app_2eheff_2emain_2ebuildCommands_str25), ((V)&g_app_2eheff_2emain_2ebuildCommands_str26), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2462 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2461}));
  V v_w_2463 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2460, v_t_2462}));
  V v_t_2464 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){v_tests_243}));
  V v_t_2465 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2464, v_x_2448}));
  V v_t_2466 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2465, v_y_2452}));
  V v_t_2467 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2466, v_z_2456}));
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2467, v_w_2463}));
  V v_t_2472 = heff_tr(heff_call(v_give_2442, 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2473 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), ((V)&g_app_2eheff_2emain_2ebuildCommands_str30), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2474 = heff_tr(heff_call(v_flag_2443, 1, (V[]){v_t_2473}));
  V v_t_2475 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2472, v_t_2474}));
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2468, v_t_2475}));
  V v_t_2477 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2478 = heff_tr(heff_call(v_pos_2444, 1, (V[]){v_t_2477}));
  V f_ = v_ap_2441;
  heff_room[0] = v_t_2476;
  heff_room[1] = v_t_2478;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_vs_2497 = args[0];
  switch (heff_tag_of(v_vs_2497)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2497, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2497);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_bench_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2481 = heff_take_field(v_s_2480, 1);
  V v_give_2482 = heff_take_field(v_s_2480, 0);
  V v_flag_2483 = heff_take_field(v_s_2480, 2);
  V v_pos_2484 = heff_get_n(v_s_2480, 3, 4);
  V v_t_2485 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2486 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), ((V)&g_app_2eheff_2emain_2ebuildCommands_str35), ((V)&g_app_2eheff_2emain_2ebuildCommands_str36), ((V)&g_app_2eheff_2emain_2ebuildCommands_str37), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2487 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2486}));
  V v_x_2488 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2485, v_t_2487}));
  V v_t_2489 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2490 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2491 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2490}));
  V v_y_2492 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2489, v_t_2491}));
  V v_t_2493 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2494 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str42), ((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), ((V)&g_app_2eheff_2emain_2ebuildCommands_str45), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2495 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2494}));
  V v_z_2496 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2493, v_t_2495}));
  V v_t_24100 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_24101 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str46), ((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), ((V)&g_app_2eheff_2emain_2ebuildCommands_str49), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24102 = heff_tr(heff_call(v_flag_2483, 1, (V[]){v_t_24101}));
  V v_w_24103 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24100, v_t_24102}));
  V v_t_24104 = heff_tr(heff_call(v_give_2482, 1, (V[]){v_bench_244}));
  V v_t_24105 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24104, v_x_2488}));
  V v_t_24106 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24105, v_y_2492}));
  V v_t_24107 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24106, v_z_2496}));
  V v_t_24108 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24107, v_w_24103}));
  V v_t_24109 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24110 = heff_tr(heff_call(v_pos_2484, 1, (V[]){v_t_24109}));
  V f_ = v_ap_2481;
  heff_room[0] = v_t_24108;
  heff_room[1] = v_t_24110;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_x2_24116 = args[0];
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str53);
  }
  case TAG_Cons: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    heff_take_n(v_x2_24116, 1ULL, 2);
    return v_x_24117;
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_s_24112 = args[0];
  V v_promote_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24113 = heff_take_field(v_s_24112, 1);
  V v_give_24114 = heff_take_field(v_s_24112, 0);
  V v_pos_24115 = heff_get_n(v_s_24112, 3, 4);
  V v_t_24119 = heff_tr(heff_call(heff_dup(v_give_24114), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_24120 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24121 = heff_tr(heff_call(v_pos_24115, 1, (V[]){v_t_24120}));
  V v_x_24122 = heff_tr(heff_call(heff_dup(v_ap_24113), 2, (V[]){v_t_24119, v_t_24121}));
  V v_t_24123 = heff_tr(heff_call(v_give_24114, 1, (V[]){v_promote_245}));
  V f_ = v_ap_24113;
  heff_room[0] = v_t_24123;
  heff_room[1] = v_x_24122;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_24130 = args[0];
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str57);
  }
  case TAG_Cons: {
    V v_x_24131 = heff_field(v_x2_24130, 0);
    heff_take_n(v_x2_24130, 1ULL, 2);
    return v_x_24131;
  }
  default: return heff_nomatch(v_x2_24130);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_x2_24137 = args[0];
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str59);
  }
  case TAG_Cons: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    heff_take_n(v_x2_24137, 1ULL, 2);
    return v_x_24138;
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_vs_24148 = args[0];
  HeffT2 v_t_24149 = ({ V a_0 = v_vs_24148; HeffT2 r_ = (g_std_2ecli_2elastS_24cpr(a_0)); heff_drop(v_vs_24148); r_; });
  {
    V v_field_24151 = v_t_24149.f[1];
    int64_t v_tag_24150 = ((int64_t)v_t_24149.f[0]);
    if ((v_tag_24150 == ((int64_t)0ULL))) {
      V v_x_24152 = v_field_24151;
      return v_x_24152;
    } else {
      heff_drop(v_field_24151);
      return ((V)&g_app_2eheff_2emain_2ebuildCommands_str65);
    }
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_24125 = args[0];
  V v_compile_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24126 = heff_take_field(v_s_24125, 1);
  V v_give_24127 = heff_take_field(v_s_24125, 0);
  V v_pos_24128 = heff_take_field(v_s_24125, 3);
  V v_flag_24129 = heff_get_n(v_s_24125, 2, 4);
  V v_t_24133 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_24134 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24135 = heff_tr(heff_call(heff_dup(v_pos_24128), 1, (V[]){v_t_24134}));
  V v_x_24136 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24133, v_t_24135}));
  V v_t_24140 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam13_clo)}));
  V v_t_24141 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str60), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_24142 = heff_tr(heff_call(v_pos_24128, 1, (V[]){v_t_24141}));
  V v_y_24143 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24140, v_t_24142}));
  V v_t_24144 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24145 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str61), ((V)&g_app_2eheff_2emain_2ebuildCommands_str62), ((V)&g_app_2eheff_2emain_2ebuildCommands_str63), ((V)&g_app_2eheff_2emain_2ebuildCommands_str64), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24146 = heff_tr(heff_call(heff_dup(v_flag_24129), 1, (V[]){v_t_24145}));
  V v_z_24147 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24144, v_t_24146}));
  V v_t_24153 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_24154 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str66), NTAG(TAG_Nil)});
  V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str68), v_t_24154})});
  V v_t_24156 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str69), NTAG(TAG_Nil)});
  V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str70), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str71), v_t_24156})});
  V v_t_24158 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str72), ((V)&g_app_2eheff_2emain_2ebuildCommands_str73), ((V)&g_app_2eheff_2emain_2ebuildCommands_str74), ((V)&g_app_2eheff_2emain_2ebuildCommands_str75), v_t_24155, NTAG(TAG_False), NTAG(TAG_True), heff_tag_n(TAG_Among, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tr(heff_call(v_flag_24129, 1, (V[]){v_t_24158}));
  V v_w_24160 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24153, v_t_24159}));
  V v_t_24161 = heff_tr(heff_call(v_give_24127, 1, (V[]){v_compile_246}));
  V v_t_24162 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24161, v_x_24136}));
  V v_t_24163 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24162, v_y_24143}));
  V v_t_24164 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24163, v_z_24147}));
  V f_ = v_ap_24126;
  heff_room[0] = v_t_24164;
  heff_room[1] = v_w_24160;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_x2_24170 = args[0];
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str78);
  }
  case TAG_Cons: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    heff_take_n(v_x2_24170, 1ULL, 2);
    return v_x_24171;
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24166 = args[0];
  V v_explain_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24167 = heff_take_field(v_s_24166, 1);
  V v_give_24168 = heff_take_field(v_s_24166, 0);
  V v_pos_24169 = heff_get_n(v_s_24166, 3, 4);
  V v_t_24173 = heff_tr(heff_call(heff_dup(v_give_24168), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24174 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str79), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24175 = heff_tr(heff_call(v_pos_24169, 1, (V[]){v_t_24174}));
  V v_x_24176 = heff_tr(heff_call(heff_dup(v_ap_24167), 2, (V[]){v_t_24173, v_t_24175}));
  V v_t_24177 = heff_tr(heff_call(v_give_24168, 1, (V[]){v_explain_247}));
  V f_ = v_ap_24167;
  heff_room[0] = v_t_24177;
  heff_room[1] = v_x_24176;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args) {
  V v_x2_24183 = args[0];
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str82);
  }
  case TAG_Cons: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    heff_take_n(v_x2_24183, 1ULL, 2);
    return v_x_24184;
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args) {
  V v_s_24179 = args[0];
  V v_typeAt_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24180 = heff_take_field(v_s_24179, 1);
  V v_give_24181 = heff_take_field(v_s_24179, 0);
  V v_pos_24182 = heff_get_n(v_s_24179, 3, 4);
  V v_t_24186 = heff_tr(heff_call(heff_dup(v_give_24181), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam18_clo)}));
  V v_t_24187 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str83), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24188 = heff_tr(heff_call(heff_dup(v_pos_24182), 1, (V[]){v_t_24187}));
  V v_x_24189 = heff_tr(heff_call(heff_dup(v_ap_24180), 2, (V[]){v_t_24186, v_t_24188}));
  V v_t_24190 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str84), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_24191 = heff_tr(heff_call(v_pos_24182, 1, (V[]){v_t_24190}));
  V v_t_24192 = heff_tr(heff_call(v_give_24181, 1, (V[]){v_typeAt_248}));
  V v_t_24193 = heff_tr(heff_call(heff_dup(v_ap_24180), 2, (V[]){v_t_24192, v_x_24189}));
  V f_ = v_ap_24180;
  heff_room[0] = v_t_24193;
  heff_room[1] = v_y_24191;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args) {
  V v_vs_24200 = args[0];
  switch (heff_tag_of(v_vs_24200)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24200, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24200);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args) {
  V v_s_24195 = args[0];
  V v_fmt_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24196 = heff_take_field(v_s_24195, 1);
  V v_give_24197 = heff_take_field(v_s_24195, 0);
  V v_flag_24198 = heff_take_field(v_s_24195, 2);
  V v_pos_24199 = heff_get_n(v_s_24195, 3, 4);
  V v_t_24203 = heff_tr(heff_call(heff_dup(v_give_24197), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam20_clo)}));
  V v_t_24204 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str87), ((V)&g_app_2eheff_2emain_2ebuildCommands_str88), ((V)&g_app_2eheff_2emain_2ebuildCommands_str89), ((V)&g_app_2eheff_2emain_2ebuildCommands_str90), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24205 = heff_tr(heff_call(v_flag_24198, 1, (V[]){v_t_24204}));
  V v_x_24206 = heff_tr(heff_call(heff_dup(v_ap_24196), 2, (V[]){v_t_24203, v_t_24205}));
  V v_t_24207 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str91), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24208 = heff_tr(heff_call(v_pos_24199, 1, (V[]){v_t_24207}));
  V v_t_24209 = heff_tr(heff_call(v_give_24197, 1, (V[]){v_fmt_249}));
  V v_t_24210 = heff_tr(heff_call(heff_dup(v_ap_24196), 2, (V[]){v_t_24209, v_x_24206}));
  V f_ = v_ap_24196;
  heff_room[0] = v_t_24210;
  heff_room[1] = v_y_24208;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args) {
  V v_s_24212 = args[0];
  V v_doc_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24213 = heff_take_field(v_s_24212, 1);
  V v_give_24214 = heff_take_field(v_s_24212, 0);
  V v_flag_24215 = heff_take_field(v_s_24212, 2);
  V v_pos_24216 = heff_get_n(v_s_24212, 3, 4);
  V v_t_24217 = heff_tr(heff_call(heff_dup(v_give_24214), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24218 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str94), ((V)&g_app_2eheff_2emain_2ebuildCommands_str95), ((V)&g_app_2eheff_2emain_2ebuildCommands_str96), ((V)&g_app_2eheff_2emain_2ebuildCommands_str97), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24219 = heff_tr(heff_call(v_flag_24215, 1, (V[]){v_t_24218}));
  V v_x_24220 = heff_tr(heff_call(heff_dup(v_ap_24213), 2, (V[]){v_t_24217, v_t_24219}));
  V v_t_24221 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str98), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24222 = heff_tr(heff_call(v_pos_24216, 1, (V[]){v_t_24221}));
  V v_t_24223 = heff_tr(heff_call(v_give_24214, 1, (V[]){v_doc_2410}));
  V v_t_24224 = heff_tr(heff_call(heff_dup(v_ap_24213), 2, (V[]){v_t_24223, v_x_24220}));
  V f_ = v_ap_24213;
  heff_room[0] = v_t_24224;
  heff_room[1] = v_y_24222;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str0, 4, "init");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str1, 39, "a new project in DIR (here, without it)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str2, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str3, 3, "get");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str4, 190, "fetch what the project requires, writing heff.sum; with PATH, require it (at VERSION or the commit REV names, PATH@REV, else its newest: its newest tag, or its default branch's commit) first");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str5, 14, "PATH[@VERSION]");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str6, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str7, 193, "the whole project: every module of src/ checked, then every program, app/NAME/main.hf, compiled as app/NAME/build.hf says, to .heff/bin/ (C by zig at -O1: built quickly, not to run its fastest)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str8, 7, "install");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str9, 264, "the project at DIR (here, without it) built as `heff build` builds it, but to run its fastest (C by zig at -O2), its programs into the heff home's bin/ (HEFF_HOME/bin, else ~/.heff/bin), and what they ship (their build.hf's `ships`) into the heff home, beside bin/");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str10, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str11, 7, "publish");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str12, 56, "check the project, then tag it vVERSION and push the tag");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str14, 7, "VERSION");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str15, 3, "dev");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str16, 159, "the project built as `heff build` builds it, its C programs (the APPs, else all) run and its pages served, then built and run again at each change of its files");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str17, 3, "APP");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str18, 4, "port");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str19, 1, "p");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str20, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str21, 57, "where the pages are served: http://127.0.0.1:PORT/ (8000)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str22, 5, "proxy");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str23, 1, "x");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str24, 3, "URL");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str25, 94, "where the pages' server sends what is not a page's: the C program's, http://127.0.0.1:8080 say");
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_init_241 = heff_take_field(v_c_240, 0);
  V v_get_242 = heff_take_field(v_c_240, 1);
  V v_build_243 = heff_rget_v(v_c_240, 2);
  V v_install_244 = heff_take_field(v_c_240, 3);
  V v_publish_245 = heff_take_field(v_c_240, 4);
  V v_dev_246 = heff_get_n(v_c_240, 5, 6);
  V v_t_2419 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){v_init_241})});
  V v_t_2432 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){v_get_242})});
  V v_t_2434 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){v_build_243})});
  V v_t_2447 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){v_install_244})});
  V v_t_2460 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){v_publish_245})});
  V v_t_2479 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str15), ((V)&g_app_2eheff_2emain_2eprojectCommands_str16), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam9, 1, 1, (V[]){v_dev_246})});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2481})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2482});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_2411 = args[0];
  switch (heff_tag_of(v_ws_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_ws_2411, 0);
    heff_take_n(v_ws_2411, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  }
  default: return heff_nomatch(v_ws_2411);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_init_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_248 = heff_take_field(v_s_247, 1);
  V v_give_249 = heff_take_field(v_s_247, 0);
  V v_pos_2410 = heff_get_n(v_s_247, 3, 4);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_give_249), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_2415 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2416 = heff_tr(heff_call(v_pos_2410, 1, (V[]){v_t_2415}));
  V v_x_2417 = heff_tr(heff_call(heff_dup(v_ap_248), 2, (V[]){v_t_2414, v_t_2416}));
  V v_t_2418 = heff_tr(heff_call(v_give_249, 1, (V[]){v_init_241}));
  V f_ = v_ap_248;
  heff_room[0] = v_t_2418;
  heff_room[1] = v_x_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_get_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2421 = heff_take_field(v_s_2420, 1);
  V v_give_2422 = heff_take_field(v_s_2420, 0);
  V v_pos_2423 = heff_get_n(v_s_2420, 3, 4);
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_give_2422), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2429 = heff_tr(heff_call(v_pos_2423, 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(v_ap_2421), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2431 = heff_tr(heff_call(v_give_2422, 1, (V[]){v_get_242}));
  V f_ = v_ap_2421;
  heff_room[0] = v_t_2431;
  heff_room[1] = v_x_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_build_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2433, 0, 4);
  args[0] = v_build_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2439 = args[0];
  switch (heff_tag_of(v_ws_2439)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_ws_2439, 0);
    heff_take_n(v_ws_2439, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2440});
  }
  default: return heff_nomatch(v_ws_2439);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_install_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2436 = heff_take_field(v_s_2435, 1);
  V v_give_2437 = heff_take_field(v_s_2435, 0);
  V v_pos_2438 = heff_get_n(v_s_2435, 3, 4);
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_give_2437), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2443 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2444 = heff_tr(heff_call(v_pos_2438, 1, (V[]){v_t_2443}));
  V v_x_2445 = heff_tr(heff_call(heff_dup(v_ap_2436), 2, (V[]){v_t_2442, v_t_2444}));
  V v_t_2446 = heff_tr(heff_call(v_give_2437, 1, (V[]){v_install_244}));
  V f_ = v_ap_2436;
  heff_room[0] = v_t_2446;
  heff_room[1] = v_x_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2452 = args[0];
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take_n(v_x2_2452, 1ULL, 2);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2448 = args[0];
  V v_publish_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2449 = heff_take_field(v_s_2448, 1);
  V v_give_2450 = heff_take_field(v_s_2448, 0);
  V v_pos_2451 = heff_get_n(v_s_2448, 3, 4);
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_give_2450), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2456 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_call(v_pos_2451, 1, (V[]){v_t_2456}));
  V v_x_2458 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_call(v_give_2450, 1, (V[]){v_publish_245}));
  V f_ = v_ap_2449;
  heff_room[0] = v_t_2459;
  heff_room[1] = v_x_2458;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args) {
  V v_s_2461 = args[0];
  V v_dev_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_2462 = heff_take_field(v_s_2461, 3);
  V v_ap_2463 = heff_take_field(v_s_2461, 1);
  V v_give_2464 = heff_take_field(v_s_2461, 0);
  V v_flag_2465 = heff_get_n(v_s_2461, 2, 4);
  V v_t_2466 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str17), NTAG(TAG_Many), NTAG(TAG_None)});
  V v_x_2467 = heff_tr(heff_call(v_pos_2462, 1, (V[]){v_t_2466}));
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_give_2464), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2469 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str18), ((V)&g_app_2eheff_2emain_2eprojectCommands_str19), ((V)&g_app_2eheff_2emain_2eprojectCommands_str20), ((V)&g_app_2eheff_2emain_2eprojectCommands_str21), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2470 = heff_tr(heff_call(heff_dup(v_flag_2465), 1, (V[]){v_t_2469}));
  V v_y_2471 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2468, v_t_2470}));
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_give_2464), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2473 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str22), ((V)&g_app_2eheff_2emain_2eprojectCommands_str23), ((V)&g_app_2eheff_2emain_2eprojectCommands_str24), ((V)&g_app_2eheff_2emain_2eprojectCommands_str25), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2474 = heff_tr(heff_call(v_flag_2465, 1, (V[]){v_t_2473}));
  V v_z_2475 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2472, v_t_2474}));
  V v_t_2476 = heff_tr(heff_call(v_give_2464, 1, (V[]){v_dev_246}));
  V v_t_2477 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2476, v_x_2467}));
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2477, v_y_2471}));
  V f_ = v_ap_2463;
  heff_room[0] = v_t_2478;
  heff_room[1] = v_z_2475;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str0, 3, "lsp");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str1, 34, "a language server, on stdin/stdout");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str2, 5, "FLAGS");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str3, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str4, 68, "which heff this is: its version, as the package.hf it came with says");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str5, 9, "dump-core");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str8, 9, "dump-eval");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str9, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str10, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str11, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str12, 9, "dev-pages");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str14, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str15, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str16, 5, "PROXY");
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam7, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_lsp_241 = heff_take_field(v_c_240, 0);
  V v_version_242 = heff_rget_v(v_c_240, 1);
  V v_dumpCore_243 = heff_take_field(v_c_240, 2);
  V v_dumpEval_244 = heff_take_field(v_c_240, 3);
  V v_devPages_245 = heff_get_n(v_c_240, 4, 5);
  V v_t_2413 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){v_lsp_241})});
  V v_t_2415 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){v_version_242})});
  V v_t_2423 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){v_dumpCore_243})});
  V v_t_2436 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){v_dumpEval_244})});
  V v_t_2457 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str12), ((V)&g_app_2eheff_2emain_2etoolCommands_str13), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam5, 1, 1, (V[]){v_devPages_245})});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2458})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2459})});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lsp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_247 = heff_take_field(v_s_246, 3);
  V v_ap_248 = heff_take_field(v_s_246, 1);
  V v_give_249 = heff_get_n(v_s_246, 0, 4);
  V v_t_2410 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_2411 = heff_tr(heff_call(v_pos_247, 1, (V[]){v_t_2410}));
  V v_t_2412 = heff_tr(heff_call(v_give_249, 1, (V[]){v_lsp_241}));
  V f_ = v_ap_248;
  heff_room[0] = v_t_2412;
  heff_room[1] = v_x_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_version_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2414, 0, 4);
  args[0] = v_version_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_dumpCore_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_2417 = heff_take_field(v_s_2416, 3);
  V v_ap_2418 = heff_take_field(v_s_2416, 1);
  V v_give_2419 = heff_get_n(v_s_2416, 0, 4);
  V v_t_2420 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_2421 = heff_tr(heff_call(v_pos_2417, 1, (V[]){v_t_2420}));
  V v_t_2422 = heff_tr(heff_call(v_give_2419, 1, (V[]){v_dumpCore_243}));
  V f_ = v_ap_2418;
  heff_room[0] = v_t_2422;
  heff_room[1] = v_x_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2428 = args[0];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str10);
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    heff_take_n(v_x2_2428, 1ULL, 2);
    return v_x_2429;
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_dumpEval_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2425 = heff_take_field(v_s_2424, 1);
  V v_give_2426 = heff_take_field(v_s_2424, 0);
  V v_pos_2427 = heff_get_n(v_s_2424, 3, 4);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_give_2426), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2432 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2433 = heff_tr(heff_call(v_pos_2427, 1, (V[]){v_t_2432}));
  V v_x_2434 = heff_tr(heff_call(heff_dup(v_ap_2425), 2, (V[]){v_t_2431, v_t_2433}));
  V v_t_2435 = heff_tr(heff_call(v_give_2426, 1, (V[]){v_dumpEval_244}));
  V f_ = v_ap_2425;
  heff_room[0] = v_t_2435;
  heff_room[1] = v_x_2434;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args) {
  V v_x2_2441 = args[0];
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str14);
  }
  case TAG_Cons: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    heff_take_n(v_x2_2441, 1ULL, 2);
    return v_x_2442;
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args) {
  V v_ws_2448 = args[0];
  switch (heff_tag_of(v_ws_2448)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2449 = heff_field(v_ws_2448, 0);
    heff_take_n(v_ws_2448, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2449});
  }
  default: return heff_nomatch(v_ws_2448);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args) {
  V v_s_2437 = args[0];
  V v_devPages_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2438 = heff_take_field(v_s_2437, 1);
  V v_give_2439 = heff_take_field(v_s_2437, 0);
  V v_pos_2440 = heff_get_n(v_s_2437, 3, 4);
  V v_t_2444 = heff_tr(heff_call(heff_dup(v_give_2439), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam6_clo)}));
  V v_t_2445 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str15), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2446 = heff_tr(heff_call(heff_dup(v_pos_2440), 1, (V[]){v_t_2445}));
  V v_x_2447 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2444, v_t_2446}));
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_give_2439), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam7_clo)}));
  V v_t_2452 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str16), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2453 = heff_tr(heff_call(v_pos_2440, 1, (V[]){v_t_2452}));
  V v_y_2454 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2451, v_t_2453}));
  V v_t_2455 = heff_tr(heff_call(v_give_2439, 1, (V[]){v_devPages_245}));
  V v_t_2456 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2455, v_x_2447}));
  V f_ = v_ap_2438;
  heff_room[0] = v_t_2456;
  heff_room[1] = v_y_2454;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_str1, 7, "testing");
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam3(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam0, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam11, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam10(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam8(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam7, 6, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam15(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam14(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam12, 5, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam16, 4, 0};
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam19(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam18(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam17, 2, 0};

static V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_st;
static V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_init(void) {
  return heff_rec_n(10, shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc, (V[]){((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam7_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam12_clo), ((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam16_clo), ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_clo), ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam17_clo), ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s692738791x410329807_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_st)) return g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_val;
  return heff_global(&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_val, &g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_st, g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_init);
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_badLoad_248 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  V v_cs_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2426);
  if ((heff_dup(v_badLoad_248) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_248);
    heff_drop(v_cs_249);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2410, v_k_2411));
  } else {
    heff_drop(v_badLoad_248);
    V v_t_2427 = ({ V a_0 = v_cs_249; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_249); r_; });
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2410, v_k_2411));
    } else {
      heff_drop_rec(v_hd_2410, 3);
      heff_drop(v_t_2427);
      V f_ = v_k_2411;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_badLoad_248 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2412);
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_c_2416 = v_field_2415;
      V v_str_2417 = (g_heff_2ebuild_2edriver_2einterface(v_c_2416));
      V v_t_2418 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2417, NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      V f_ = heff_dup(heff_rfield(v_hd_2410, 1));
      heff_room[0] = v_t_2425;
      heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam6, 1, 4, (V[]){v_badLoad_248, v_hd_2410, v_k_2411, v_cs_249});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_cs_249);
      heff_drop(v_badLoad_248);
      heff_drop(v_field_2415);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2410, v_k_2411));
    }
  }
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_badLoad_248 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_245, 1));
  heff_drop(v_x_245);
  V v_cs_249 = heff_get_n(v_x_247, 0, 2);
  V v_hd_2410 = v_hd_242;
  V v_k_2411 = v_k_243;
  return ({ V a_0 = v_cs_249; V a_1 = heff_dup(v_hd_2410); V a_2 = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam5, 1, 4, (V[]){heff_dup(v_cs_249), v_hd_2410, v_badLoad_248, v_k_2411}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_249); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam4, 1, 3, (V[]){v_x_245, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam3, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam1(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam0(V self, V *args) {
  V v_file_240 = args[0];
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_240));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam1, 2, 1, (V[]){v_c_241});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam11(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam10(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_hd_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_total_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2439));
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_str1), v_total_2440, ((V)&g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam11_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s349465857x1414991782(v_x_2437, v_x_2439, heff_dup(v_hd_2435), v_k_2436, v_t_2443, v_hd_2435));
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_given_2433 = heff_env(self)[0];
  V v_hd_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2438 = (g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536(v_given_2433));
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_hd_2435);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam10, 1, 3, (V[]){v_x_2437, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_given_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam9, 1, 3, (V[]){v_given_2433, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam7(V self, V *args) {
  V v_seed_2428 = args[0];
  V v_pattern_2429 = args[1];
  V v_jobs_2430 = args[2];
  V v_update_2431 = args[3];
  V v_watch_2432 = args[4];
  V v_given_2433 = args[5];
  if ((heff_dup(v_watch_2432) == NTAG(TAG_True))) {
    heff_drop(v_watch_2432);
    return ({ V a_0 = v_seed_2428; V a_1 = v_pattern_2429; V a_2 = v_jobs_2430; V a_3 = v_update_2431; V a_4 = v_given_2433; V r_ = (g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_seed_2428); heff_drop(v_pattern_2429); heff_drop(v_jobs_2430); heff_drop(v_update_2431); r_; });
  } else {
    heff_drop(v_watch_2432);
    V v_c_2434 = ({ V a_0 = v_seed_2428; V a_1 = v_pattern_2429; V a_2 = v_jobs_2430; V a_3 = v_update_2431; V r_ = (g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(a_0, a_1, a_2, a_3)); heff_drop(v_seed_2428); heff_drop(v_pattern_2429); heff_drop(v_jobs_2430); r_; });
    return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam8, 2, 2, (V[]){v_c_2434, v_given_2433});
  }
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam15(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2452 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_2452; V a_1 = v_x_2454; V a_2 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_3 = v_hd_2450; V a_4 = v_k_2451; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2454); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam14(V self, V *args) {
  V v_x_2452 = args[0];
  V v_given_2448 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2453 = (g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568(v_given_2448));
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam15, 1, 3, (V[]){v_x_2452, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam13(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_given_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = heff_dup(v_hd_2450);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam14, 1, 3, (V[]){v_given_2448, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam12(V self, V *args) {
  V v_pattern_2444 = args[0];
  V v_time_2445 = args[1];
  V v_count_2446 = args[2];
  V v_json_2447 = args[3];
  V v_given_2448 = args[4];
  V v_c_2449 = ({ V a_0 = v_pattern_2444; V a_1 = v_time_2445; V a_2 = v_count_2446; V a_3 = v_json_2447; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702(a_0, a_1, a_2, a_3)); heff_drop(v_pattern_2444); r_; });
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam13, 2, 2, (V[]){v_c_2449, v_given_2448});
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam16(V self, V *args) {
  V v_file_2455 = args[0];
  V v_outPath_2456 = args[1];
  V v_name_2457 = args[2];
  V v_backend_2458 = args[3];
  return (g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087(heff_rec_n(4, shape_file__outPath__name__backend, (V[]){v_file_2455, v_outPath_2456, v_name_2457, v_backend_2458})));
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam19(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intLt_c(MK_INT(0LL), v_x_2464)) {
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2462, v_k_2463));
  } else {
    heff_drop(v_hd_2462);
    V f_ = v_k_2463;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam18(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2461;
  args[0] = heff_dup(v_hd_2462);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam19, 1, 2, (V[]){v_hd_2462, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam17(V self, V *args) {
  V v_check_2459 = args[0];
  V v_files_2460 = args[1];
  V v_c_2461 = ({ V a_0 = v_check_2459; V a_1 = v_files_2460; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(a_0, a_1, a_2)); heff_drop(v_check_2459); heff_drop(v_files_2460); r_; });
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_lam18, 2, 1, (V[]){v_c_2461});
}
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_str1, 1, ".");
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam0, 1, 0};
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam1, 1, 0};

static V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_val;
static HEFF_ONCE g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_st;
static V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_init(void) {
  return heff_rec_n(6, shape_init__get__build__install__publish__dev, (V[]){((V)&g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam0_clo), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_clo), heff_dup(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_get()), ((V)&g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam1_clo), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_clo), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_clo)});
}
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_st)) return g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_val;
  return heff_global(&g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_val, &g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_st, g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_init);
}
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam0(V self, V *args) {
  V v_dir_240 = args[0];
  V v_t_242;
  switch (heff_tag_of(v_dir_240)) {
  case TAG_Nothing: {
    v_t_242 = ((V)&g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_str0);
    break;
  }
  case TAG_Just: {
    V v_x_241 = heff_field(v_dir_240, 0);
    heff_take_n(v_dir_240, 1ULL, 1);
    v_t_242 = v_x_241;
    break;
  }
  default: heff_nomatch(v_dir_240);
  }
  V f_ = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_clo);
  args[0] = v_t_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_lam1(V self, V *args) {
  V v_dir_243 = args[0];
  V v_t_245;
  switch (heff_tag_of(v_dir_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_str1);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_dir_243, 0);
    heff_take_n(v_dir_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_dir_243);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_clo);
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_str1, 1, "#");
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam3, 1, 0};
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam2(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam0, 1, 0};
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam7(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam6(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam5(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam4, 1, 0};
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam14(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam15(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam16(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam13(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam12(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam11(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam10(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam9(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam8, 1, 0};

static V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_val;
static HEFF_ONCE g_app_2eheff_2emain_2etool_24s1072080726x1379308795_st;
static V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_init(void) {
  return heff_rec_n(5, shape_lsp__version__dumpCore__dumpEval__devPages, (V[]){((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo), ((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam4_clo), ((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam8_clo), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_clo)});
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_st)) return g_app_2eheff_2emain_2etool_24s1072080726x1379308795_val;
  return heff_global(&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_val, &g_app_2eheff_2emain_2etool_24s1072080726x1379308795_st, g_app_2eheff_2emain_2etool_24s1072080726x1379308795_init);
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam3(V self, V *args) {
  V v_a_246 = args[0];
  return v_a_246;
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_dup(heff_rfield(v_x_244, 0));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_AbsPath, 2, (V[]){v_t_245, ((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam3_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s995775659x1481479477(v_x_244, heff_dup(v_hd_242), v_k_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_hd_242));
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam1(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam0(V self, V *args) {
  V v_flags_240 = args[0];
  heff_drop(v_flags_240);
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam1, 2, 1, (V[]){v_c_241});
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_intEq_c(v_x_2419, MK_INT(0LL))) {
    heff_drop(v_hd_2414);
    V f_ = v_k_2415;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2414, v_k_2415));
  }
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = (g_list_2efoldl_24s1271133029x1548514599(NTAG(TAG_Nil), v_x_2416));
  V v_c_2418 = ({ V a_0 = v_t_2417; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam7, 1, 2, (V[]){v_k_2415, v_hd_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam6, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam4(V self, V *args) {
  V v_paths_2412 = args[0];
  V v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(NTAG(TAG_Nil), v_paths_2412));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam5, 2, 1, (V[]){v_c_2413});
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam14(V self, V *args) {
  V v_acc_2443 = args[0];
  V v_k_2444 = args[1];
  V v_entries_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = ({ V a_0 = v_entries_2441; V a_1 = v_k_2444; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2441); r_; });
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_e_2448 = v_field_2447;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2444, v_e_2448}), v_acc_2443});
    } else {
      heff_drop(v_k_2444);
      heff_drop(v_field_2447);
      return v_acc_2443;
    }
  }
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam15(V self, V *args) {
  V v_k_2450 = args[0];
  V v_own_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2451 = (g_list_2emap_24s152505078x225062837(v_own_2439));
  V v_t_2452 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_2450}));
  return ({ V a_0 = v_t_2452; V a_1 = v_xs_2451; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2451); r_; });
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam16(V self, V *args) {
  V v_x_2456 = args[0];
  V v_badL_2428 = heff_env(self)[0];
  V v_cs_2429 = heff_env(self)[1];
  V v_hd_2430 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (((heff_dup(v_badL_2428) == NTAG(TAG_True)) || ({ V v_c_2457 = (g_list_2eany_24s1740858080x874135214(v_cs_2429)); int c_ = ((heff_dup(v_c_2457) == NTAG(TAG_True)) || (heff_dup(v_x_2456) == NTAG(TAG_True))); heff_drop(v_c_2457); c_; }))) {
    heff_drop(v_x_2456);
    heff_drop(v_badL_2428);
    heff_drop(v_cs_2429);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2430, v_k_2431));
  } else {
    heff_drop(v_x_2456);
    heff_drop(v_badL_2428);
    heff_drop(v_cs_2429);
    heff_drop(v_hd_2430);
    V f_ = v_k_2431;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam13(V self, V *args) {
  V v_x_2432 = args[0];
  V v_cs_2429 = heff_env(self)[0];
  V v_hd_2430 = heff_env(self)[1];
  V v_badL_2428 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2432);
  HeffT2 v_t_2433 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2429));
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_c_2436 = v_field_2435;
      V v_c_2437 = v_c_2436;
      V v_top_2438 = heff_take_field(v_c_2437, 5);
      V v_own_2439 = heff_get_n(v_c_2437, 7, 14);
      V v_gs_2440 = heff_dup(heff_rfield(v_top_2438, 0));
      V v_entries_2441 = heff_take_field(v_gs_2440, 1);
      V v_order_2442 = heff_get_n(v_gs_2440, 0, 8);
      V v_t_2449 = ({ V a_0 = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam14, 2, 1, (V[]){v_entries_2441}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2442; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_2442); r_; });
      V v_t_2453 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo(heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam15, 1, 1, (V[]){heff_dup(v_own_2439)}), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2449, NTAG(TAG_Nil)));
      V v_t_2454 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_2439; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
      V v_t_2455 = ({ V a_0 = heff_get_n(v_top_2438, 0, 10); V a_1 = v_t_2453; V a_2 = v_t_2454; V r_ = (g_heff_2ebuild_2edriver_2eevalPick(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(v_t_2455, heff_dup(v_hd_2430), heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam16, 1, 4, (V[]){v_badL_2428, v_cs_2429, v_hd_2430, v_k_2431})));
    } else {
      heff_drop(v_cs_2429);
      heff_drop(v_badL_2428);
      heff_drop(v_field_2435);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2430, v_k_2431));
    }
  }
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam12(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_badL_2428 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2425, 1));
  heff_drop(v_x_2425);
  V v_cs_2429 = heff_get_n(v_x_2427, 0, 2);
  V v_hd_2430 = v_hd_2422;
  V v_k_2431 = v_k_2423;
  return ({ V a_0 = v_cs_2429; V a_1 = heff_dup(v_hd_2430); V a_2 = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam13, 1, 4, (V[]){heff_dup(v_cs_2429), v_hd_2430, v_badL_2428, v_k_2431}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_2429); r_; });
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam11(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_2424));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam12, 1, 3, (V[]){v_x_2425, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_app_2eheff_2emain_2etool_24s1072080726x1379308795_str0), heff_dup(heff_rfield(v_x_2424, 1)), MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam11, 1, 3, (V[]){v_x_2424, v_hd_2422, v_k_2423})));
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam9(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam10, 1, 2, (V[]){v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam8(V self, V *args) {
  V v_file_2420 = args[0];
  V v_c_2421 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_2420));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_lam9, 2, 1, (V[]){v_c_2421});
}
HEFF_LIT(g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_str0, 4, "heff");
V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_entry, 3, 0};

V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(V v_argv_240, V v_z_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_get());
  V v_t_244 = heff_dup(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_get());
  V v_t_245 = heff_dup(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_get());
  V v_t_246 = (g_app_2eheff_2emain_2ebuildCommands(v_t_243));
  V v_t_247 = (g_app_2eheff_2emain_2eprojectCommands(v_t_244));
  V v_t_248 = (g_app_2eheff_2emain_2etoolCommands(v_t_245));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
  V v_t_2410 = (g_prelude_2e_2b_2b(v_t_246, v_t_249));
  HeffT2 v_t_2411 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_str0), v_t_2410, v_argv_240));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_text_2414 = v_field_2413;
      V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2414, NTAG(TAG_MkUnit)});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
      return heff_tail(heff_dup(heff_rfield(v_z_241, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_lam0, 1, 2, (V[]){v_z_241, v_z_242})});
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_text_2424 = v_field_2413;
        HEFF_LAST return g_co_2eop_24s1964021109x2127220916(v_text_2424, v_z_241, v_z_242);
      } else {
        V v_act_2425 = v_field_2413;
        return heff_tail(v_act_2425, 2, (V[]){v_z_241, v_z_242});
      }
    }
  }
}
V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_241, v_z_242));
}
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str0, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str1, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str2, 2, "$ ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str3, 1, "\012");
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam0(V self, V *args);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam2(V self, V *args);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam1, 4, 0};
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam4(V self, V *args);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam3(V self, V *args);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam5(V self, V *args);
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam6(V self, V *args);
Clo g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_entry, 3, 0};

V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380(V v_chosen_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_chosen_240)) {
  case TAG_Nothing: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_chosen1_243 = heff_field(v_chosen_240, 0);
    V v_ru_24chosen_240_24Just = heff_take_reuse_n(v_chosen_240, 1ULL, 1);
    switch (heff_tag_of(v_chosen1_243)) {
    case TAG_Nothing: {
      heff_drop(v_z_241);
      heff_drop_cell(v_ru_24chosen_240_24Just, 1);
      return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_Just: {
      V v_ws_244 = heff_field(v_chosen1_243, 0);
      V v_ru_24chosen1_243_24Just = heff_take_reuse_n(v_chosen1_243, 1ULL, 1);
      V v_t_245 = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(((V)&g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str0), ((V)&g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str1), v_ws_244));
      V v_str_246 = heff_strAppend(((V)&g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str2), v_t_245);
      V v_lit_247 = v_ws_244;
      V v_lit_248 = heff_dup(v_z_241);
      V v_lit_249 = v_z_242;
      V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_str3)), NTAG(TAG_MkUnit)});
      V v_t_2411 = heff_tag_at_n(v_ru_24chosen_240_24Just, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24chosen1_243_24Just, TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      V v_p_2417 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
      V v_hd_2418 = v_z_241;
      V v_t_2440;
      switch (heff_tag_of(v_p_2417)) {
      case TAG_InL: {
        V v_x_2419 = heff_field(v_p_2417, 0);
        V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
        V v_t_2426;
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Throw: {
          V v_s_2420 = heff_field(v_x_2419, 0);
          V v_ru_24x_2419_24Throw = heff_take_reuse_n(v_x_2419, 1ULL, 1);
          v_t_2426 = heff_tag_at_n(v_ru_24x_2419_24Throw, TAG_Throw, 1, (V[]){v_s_2420});
          break;
        }
        case TAG_Catch: {
          V v_c_2421 = heff_field(v_x_2419, 0);
          V v_h_2422 = heff_field(v_x_2419, 1);
          V v_ru_24x_2419_24Catch = heff_take_reuse_n(v_x_2419, 3ULL, 2);
          V v_t_2423 = heff_tr(heff_call(v_c_2421, 2, (V[]){heff_dup(v_hd_2418), heff_dup(heff_rfield(v_hd_2418, 0))}));
          v_t_2426 = heff_tag_at_n(v_ru_24x_2419_24Catch, TAG_Catch, 2, (V[]){v_t_2423, heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam0, 1, 2, (V[]){v_h_2422, heff_dup(v_hd_2418)})});
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        v_t_2440 = heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2426});
        break;
      }
      case TAG_InR: {
        V v_y_2427 = heff_field(v_p_2417, 0);
        V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
        V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam3, 2, 1, (V[]){heff_dup(v_hd_2418)})}), heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam5, 1, 1, (V[]){heff_dup(v_hd_2418)}), v_y_2427}));
        v_t_2440 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2439});
        break;
      }
      default: heff_nomatch(v_p_2417);
      }
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2440}));
      return heff_tail(heff_get_n(v_hd_2418, 1, 3), 2, (V[]){v_t_2441, heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam6, 1, 3, (V[]){v_lit_247, v_lit_248, v_lit_249})});
    }
    default: return heff_nomatch(v_chosen1_243);
    }
  }
  default: return heff_nomatch(v_chosen_240);
  }
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eexplored_24s699176061x1498635380(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam0(V self, V *args) {
  V v_s_2424 = args[0];
  V v_h_2422 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2425 = heff_tr(heff_call(v_h_2422, 1, (V[]){v_s_2424}));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_2418);
  heff_room[1] = heff_get_n(v_hd_2418, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_2428 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2433 = heff_tr(heff_call(v_g_2428, 1, (V[]){v_x_2432}));
  V f_ = v_k_2431;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam1(V self, V *args) {
  V v_g_2428 = args[0];
  V v_c_2429 = args[1];
  V v_hd_2430 = args[2];
  V v_k_2431 = args[3];
  V f_ = v_c_2429;
  args[0] = v_hd_2430;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam2, 1, 2, (V[]){v_g_2428, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_g_2434 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_g_2434, 1, (V[]){v_x_2436}));
  V f_ = heff_get_n(v_hd_2418, 0, 3);
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam3(V self, V *args) {
  V v_g_2434 = args[0];
  V v_m_2435 = args[1];
  V v_hd_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
  args[0] = v_m_2435;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam4, 1, 2, (V[]){v_g_2434, v_hd_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam5(V self, V *args) {
  V v_c_2438 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_hd_2418);
  heff_room[1] = heff_get_n(v_hd_2418, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eexplored_24s699176061x1498635380_lam6(V self, V *args) {
  V v_a_2442 = args[0];
  V v_lit_247 = heff_env(self)[0];
  V v_lit_248 = heff_env(self)[1];
  V v_lit_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2442);
  return (g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(v_lit_247, v_lit_248, v_lit_249));
}
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str2, 4, "heff");
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam0(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam1, 1, 0};
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam4(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam3(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam2(V self, V *args);
Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s311687123x228429246_entry, 7, 0};

V g_app_2eheff_2emain_2eexplore_24s311687123x228429246(V v_x1_240, V v_z_241, V v_z_242, V v_z_243, V v_z_244, V v_z_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_247 = heff_dup(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_get());
    V v_t_248 = heff_dup(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_get());
    V v_t_249 = heff_dup(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_get());
    V v_t_2410 = (g_app_2eheff_2emain_2ebuildCommands(v_t_247));
    V v_t_2411 = (g_app_2eheff_2emain_2eprojectCommands(v_t_248));
    V v_t_2412 = (g_app_2eheff_2emain_2etoolCommands(v_t_249));
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
    V v_t_2414 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_2410, v_t_2413));
    V v_es_2415 = (g_list_2emap_24s1531382666x123921537(v_t_2414));
    V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2417 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str1)), v_t_2416});
    V v_t_2418 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_str2), v_es_2415, v_t_2417, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), NTAG(TAG_Nothing)});
    V v_t_2419 = heff_rec_n(3, shape_start__step__view, (V[]){v_t_2418, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)});
    V v_app_2420 = v_t_2419;
    V v_hd_2421 = heff_dup(v_z_241);
    V v_k_2423 = heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam0, 1, 2, (V[]){v_z_241, v_z_242});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 1, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam1_clo)})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2421, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
    return heff_tail(heff_dup(heff_rfield(v_hd_2421, 1)), 6, (V[]){v_t_2429, heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam2, 1, 3, (V[]){v_app_2420, v_hd_2421, v_k_2423}), v_z_243, v_z_244, v_z_245, v_z_246});
  } else {
    V v_t_2443 = heff_tr(g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(NTAG(TAG_Nil), v_z_241, v_z_242));
    return heff_tail(v_t_2443, 4, (V[]){v_z_243, v_z_244, v_z_245, v_z_246});
  }
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_app_2eheff_2emain_2eexplore_24s311687123x228429246(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_app_2eheff_2emain_2eexplored_24s699176061x1498635380(v_x_2422, v_z_241, v_z_242));
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam1(V self, V *args) {
  V v_b_2424 = args[0];
  return v_b_2424;
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V f_ = v_k_2423;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_hd_2432 = v_hd_2421;
  V v_bind_2433 = heff_take_field(v_hd_2432, 1);
  V v_malg_2434 = heff_get_n(v_hd_2432, 2, 3);
  V v_k2_2436 = heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam4, 1, 2, (V[]){v_k_2423, v_x_2431});
  V v_t_2437 = heff_tag_n(TAG_Finish, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(v_malg_2434, 1, (V[]){v_t_2441}));
  V f_ = v_bind_2433;
  heff_room[0] = v_t_2442;
  heff_room[1] = v_k2_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_app_2420 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2430) == NTAG(TAG_True))) {
    heff_drop(v_x_2430);
    return (g_std_2eterminal_2eloop_24s40037404x625033307(heff_dup(v_app_2420), heff_get_n(v_app_2420, 0, 3), heff_dup(v_hd_2421), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_lam3, 1, 2, (V[]){v_hd_2421, v_k_2423})));
  } else {
    heff_drop(v_x_2430);
    heff_drop_rec(v_app_2420, 3);
    heff_drop_rec(v_hd_2421, 3);
    V f_ = v_k_2423;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str2, 4, "heff");
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam0(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam1, 1, 0};
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam4(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam3(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam2(V self, V *args);
Clo g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_entry, 8, 0};

V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1(V v_tok_240, V v_x1_241, V v_z_242, V v_z_243, V v_z_244, V v_z_245, V v_z_246, V v_z_247) {
top: ;
  if ((heff_dup(v_x1_241) == NTAG(TAG_True))) {
    V v_t_248 = heff_dup(g_app_2eheff_2emain_2ebuild_24s1551920681x2022805610_get());
    V v_t_249 = heff_dup(g_app_2eheff_2emain_2eproject_24s1537335119x1009842595_get());
    V v_t_2410 = heff_dup(g_app_2eheff_2emain_2etool_24s1072080726x1379308795_get());
    V v_t_2411 = (g_app_2eheff_2emain_2ebuildCommands(v_t_248));
    V v_t_2412 = (g_app_2eheff_2emain_2eprojectCommands(v_t_249));
    V v_t_2413 = (g_app_2eheff_2emain_2etoolCommands(v_t_2410));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    V v_t_2415 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_2411, v_t_2414));
    V v_es_2416 = (g_list_2emap_24s1531382666x123921537(v_t_2415));
    V v_t_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2418 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str1)), v_t_2417});
    V v_t_2419 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_str2), v_es_2416, v_t_2418, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), NTAG(TAG_Nothing)});
    V v_t_2420 = heff_rec_n(3, shape_start__step__view, (V[]){v_t_2419, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)});
    V v_app_2421 = v_t_2420;
    V v_hd_2422 = heff_dup(v_z_242);
    V v_k_2424 = heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam0, 1, 2, (V[]){v_z_242, v_z_243});
    V v_t_2426 = heff_tag_at_n(v_tok_240, TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 1, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam1_clo)})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
    return heff_tail(heff_dup(heff_rfield(v_hd_2422, 1)), 6, (V[]){v_t_2430, heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam2, 1, 3, (V[]){v_app_2421, v_hd_2422, v_k_2424}), v_z_244, v_z_245, v_z_246, v_z_247});
  } else {
    heff_drop_cell(v_tok_240, 1);
    V v_t_2444 = heff_tr(g_app_2eheff_2emain_2edispatch_24s1949571960x1318033051(NTAG(TAG_Nil), v_z_242, v_z_243));
    return heff_tail(v_t_2444, 4, (V[]){v_z_244, v_z_245, v_z_246, v_z_247});
  }
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); return r;
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_app_2eheff_2emain_2eexplored_24s699176061x1498635380(v_x_2423, v_z_242, v_z_243));
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam1(V self, V *args) {
  V v_b_2425 = args[0];
  return v_b_2425;
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_2424;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_hd_2433 = v_hd_2422;
  V v_bind_2434 = heff_take_field(v_hd_2433, 1);
  V v_malg_2435 = heff_get_n(v_hd_2433, 2, 3);
  V v_k2_2437 = heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam4, 1, 2, (V[]){v_k_2424, v_x_2432});
  V v_t_2438 = heff_tag_n(TAG_Finish, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_call(v_malg_2435, 1, (V[]){v_t_2442}));
  V f_ = v_bind_2434;
  heff_room[0] = v_t_2443;
  heff_room[1] = v_k2_2437;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_app_2421 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2431) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    return (g_std_2eterminal_2eloop_24s40037404x625033307(heff_dup(v_app_2421), heff_get_n(v_app_2421, 0, 3), heff_dup(v_hd_2422), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s311687123x228429246_24tok1_lam3, 1, 2, (V[]){v_hd_2422, v_k_2424})));
  } else {
    heff_drop(v_x_2431);
    heff_drop_rec(v_app_2421, 3);
    heff_drop_rec(v_hd_2422, 3);
    V f_ = v_k_2424;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}