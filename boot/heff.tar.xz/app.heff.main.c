// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ehf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};

static V g_app_2eheff_2emain_2ehf_val;
static int g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (g_app_2eheff_2emain_2ehf_st == 2) return g_app_2eheff_2emain_2ehf_val;
  if (g_app_2eheff_2emain_2ehf_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ehf_st = 1;
  g_app_2eheff_2emain_2ehf_val = heff_tr(g_app_2eheff_2emain_2ehf_init());
  g_app_2eheff_2emain_2ehf_st = 2;
  return g_app_2eheff_2emain_2ehf_val;
}
V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam0, 3, 0};

static V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_val;
static int g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_st;
static V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_init(void) {
  return heff_rec(4, shape_182_370_75_76, (V[]){((V)&g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam0_clo), ((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_clo), ((V)&g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_clo), ((V)&g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_clo)});
}
V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_get(void) {
  if (g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_st == 2) return g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_val;
  if (g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_st = 1;
  g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_val = heff_tr(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_init());
  g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_st = 2;
  return g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_val;
}
V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2eserve_24s985_24s1217_24s1289(v_x_243, v_hd_241, v_k_242));
}
V g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam0(V self, V *args) {
  V v_flags_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_flags_240);
  return (g_heff_2ecommands_2ehostNow_24s861_24s1033(heff_dup(v_hd_241), heff_clo(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam0, 2, 0};
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam3, 4, 0};

static V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_val;
static int g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_st;
static V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_init(void) {
  return heff_rec(8, shape_40_284_335_259_50_93_354_106, (V[]){((V)&g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_clo), ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam0_clo), ((V)&g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam3_clo), ((V)&g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_clo), ((V)&g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_clo), ((V)&g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get(void) {
  if (g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_st == 2) return g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_val;
  if (g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_st = 1;
  g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_val = heff_tr(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_init());
  g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_st = 2;
  return g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_val;
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    V v_x2_247 = (g_prelude_2eparseInt(v_s_246));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2410 = (g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324(v_t_249, v_x_245));
  return heff_tail(v_t_2410, 2, (V[]){v_hd_243, v_k_244});
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam2, 1, 3, (V[]){v_seed_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam0(V self, V *args) {
  V v_seed_240 = args[0];
  V v_given_241 = args[1];
  V v_c_242 = (g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152(v_given_241));
  return heff_clo(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam1, 2, 2, (V[]){v_c_242, v_seed_240});
}
V g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_lam3(V self, V *args) {
  V v_file_2411 = args[0];
  V v_outPath_2412 = args[1];
  V v_name_2413 = args[2];
  V v_backend_2414 = args[3];
  return (g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259(heff_rec(4, shape_100_224_198_18, (V[]){v_file_2411, v_outPath_2412, v_name_2413, v_backend_2414})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam0, 1, 0};
V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam1, 1, 0};

static V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_val;
static int g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_st;
static V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_init(void) {
  return heff_rec(5, shape_140_111_33_144_263, (V[]){((V)&g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam0_clo), ((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_clo), ((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_clo), ((V)&g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam1_clo), ((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_clo)});
}
V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get(void) {
  if (g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_st == 2) return g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_val;
  if (g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_st = 1;
  g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_val = heff_tr(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_init());
  g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_st = 2;
  return g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_val;
}
V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam0(V self, V *args) {
  V v_dir_240 = args[0];
  V v_t_242;
  switch (heff_tag_of(v_dir_240)) {
  case TAG_Nothing: {
    v_t_242 = ((V)&g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_str0);
    break;
  }
  case TAG_Just: {
    V v_x_241 = heff_field(v_dir_240, 0);
    heff_take_n(v_dir_240, 1ULL, 1);
    v_t_242 = v_x_241;
    break;
  }
  default: heff_nomatch(v_dir_240);
  }
  V f_ = ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_clo);
  args[0] = v_t_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_lam1(V self, V *args) {
  V v_dir_243 = args[0];
  V v_t_245;
  switch (heff_tag_of(v_dir_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_str1);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_dir_243, 0);
    heff_take_n(v_dir_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_dir_243);
  }
  V f_ = ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_clo);
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str1 = {{0x80000000u, K_STR, 0}, 55, 55, {101, 108, 97, 98, 111, 114, 97, 116, 101, 32, 70, 73, 76, 69, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 59, 32, 112, 114, 105, 110, 116, 32, 105, 116, 115, 32, 105, 110, 116, 101, 114, 102, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str5 = {{0x80000000u, K_STR, 0}, 47, 47, {114, 117, 110, 32, 70, 73, 76, 69, 39, 115, 32, 109, 97, 105, 110, 32, 119, 105, 116, 104, 32, 65, 82, 71, 83, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 102, 111, 114, 32, 78, 111, 100, 101, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {65, 82, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[211]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str10 = {{0x80000000u, K_STR, 0}, 211, 211, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 39, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 40, 116, 104, 101, 32, 96, 45, 45, 32, 46, 46, 46, 96, 32, 108, 105, 110, 101, 115, 32, 117, 110, 100, 101, 114, 32, 116, 104, 101, 109, 41, 44, 32, 97, 110, 100, 32, 114, 117, 110, 32, 116, 104, 101, 32, 116, 101, 115, 116, 115, 32, 40, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 32, 111, 102, 32, 116, 121, 112, 101, 32, 96, 84, 101, 115, 116, 96, 44, 32, 108, 105, 98, 47, 99, 104, 101, 99, 107, 46, 104, 102, 41, 44, 32, 111, 102, 32, 116, 104, 101, 32, 70, 73, 76, 69, 115, 32, 40, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 39, 115, 32, 46, 104, 102, 32, 102, 105, 108, 101, 115, 41, 44, 32, 101, 108, 115, 101, 32, 111, 102, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 116, 101, 115, 116, 115, 32, 104, 101, 114, 101, 32, 40, 116, 101, 115, 116, 47, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 101, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[64]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str14 = {{0x80000000u, K_STR, 0}, 64, 64, {116, 104, 101, 32, 115, 101, 101, 100, 32, 116, 104, 101, 32, 112, 114, 111, 112, 101, 114, 116, 105, 101, 115, 32, 100, 114, 97, 119, 32, 102, 114, 111, 109, 32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 115, 101, 101, 100, 44, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 114, 117, 110, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str17 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 114, 105, 116, 101, 32, 101, 97, 99, 104, 32, 119, 97, 116, 99, 104, 39, 115, 32, 118, 97, 108, 117, 101, 32, 117, 110, 100, 101, 114, 32, 105, 116, 32, 97, 115, 32, 105, 116, 115, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 109, 112, 105, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[173]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str21 = {{0x80000000u, K_STR, 0}, 173, 173, {70, 73, 76, 69, 32, 99, 111, 109, 112, 105, 108, 101, 100, 44, 32, 98, 121, 32, 77, 79, 68, 69, 58, 32, 101, 115, 109, 32, 40, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 41, 44, 32, 112, 97, 103, 101, 32, 40, 97, 32, 115, 99, 114, 105, 112, 116, 32, 114, 117, 110, 110, 105, 110, 103, 32, 116, 104, 101, 32, 97, 112, 112, 32, 78, 65, 77, 69, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 41, 44, 32, 110, 111, 100, 101, 32, 40, 97, 32, 78, 111, 100, 101, 46, 106, 115, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 41, 44, 32, 99, 32, 40, 97, 32, 67, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 44, 32, 102, 111, 114, 32, 96, 122, 105, 103, 32, 99, 99, 96, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {79, 85, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str28 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 65, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str29 = {{0x80000000u, K_STR, 0}, 32, 32, {116, 104, 101, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 32, 114, 117, 110, 32, 40, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str33 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str35 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str36 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str37 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {98, 97, 99, 107, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str40 = {{0x80000000u, K_STR, 0}, 4, 4, {77, 79, 68, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str41 = {{0x80000000u, K_STR, 0}, 22, 22, {119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 116, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {101, 120, 112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str44 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 104, 101, 32, 101, 108, 97, 98, 111, 114, 97, 116, 105, 111, 110, 32, 116, 114, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str45 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str46 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str47 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 121, 112, 101, 45, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[67]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str48 = {{0x80000000u, K_STR, 0}, 67, 67, {119, 104, 97, 116, 32, 116, 104, 101, 32, 110, 97, 109, 101, 32, 97, 116, 32, 101, 97, 99, 104, 32, 79, 70, 70, 83, 69, 84, 32, 114, 101, 115, 111, 108, 118, 101, 100, 32, 116, 111, 44, 32, 97, 110, 100, 32, 105, 116, 115, 32, 116, 121, 112, 101, 44, 32, 97, 32, 108, 105, 110, 101, 32, 101, 97, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str49 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {79, 70, 70, 83, 69, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str52 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 109, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str53 = {{0x80000000u, K_STR, 0}, 21, 21, {102, 111, 114, 109, 97, 116, 32, 70, 73, 76, 69, 115, 32, 105, 110, 32, 112, 108, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str54 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str56 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str57 = {{0x80000000u, K_STR, 0}, 32, 32, {111, 110, 108, 121, 32, 115, 97, 121, 32, 119, 104, 105, 99, 104, 32, 97, 114, 101, 32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_24s1350_str58 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam0, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam2, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam4, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam5, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam9, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam7, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam11, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam13, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_24s1350_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_24s1350_lam15, 1, 0};

static V g_app_2eheff_2emain_2ebuildCommands_24s1350_val;
static int g_app_2eheff_2emain_2ebuildCommands_24s1350_st;
static V g_app_2eheff_2emain_2ebuildCommands_24s1350_init(void) {
  V v_t_249 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str1), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam0_clo)});
  V v_t_2422 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str5), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam2_clo)});
  V v_t_2432 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str10), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam4_clo)});
  V v_t_2442 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str17), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam5_clo)});
  V v_t_2478 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str21), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam7_clo)});
  V v_t_2488 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str44), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam11_clo)});
  V v_t_24101 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str48), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam13_clo)});
  V v_t_24115 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str52), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str53), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam15_clo)});
  V v_t_24116 = heff_tag(TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
  V v_t_24117 = heff_tag(TAG_Cons, 2, (V[]){v_t_2488, heff_tag(TAG_Cons, 2, (V[]){v_t_24101, v_t_24116})});
  V v_t_24118 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, heff_tag(TAG_Cons, 2, (V[]){v_t_2478, v_t_24117})});
  V v_t_24119 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_tag(TAG_Cons, 2, (V[]){v_t_2432, v_t_24118})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_24119});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_get(void) {
  if (g_app_2eheff_2emain_2ebuildCommands_24s1350_st == 2) return g_app_2eheff_2emain_2ebuildCommands_24s1350_val;
  if (g_app_2eheff_2emain_2ebuildCommands_24s1350_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ebuildCommands_24s1350_st = 1;
  g_app_2eheff_2emain_2ebuildCommands_24s1350_val = heff_tr(g_app_2eheff_2emain_2ebuildCommands_24s1350_init());
  g_app_2eheff_2emain_2ebuildCommands_24s1350_st = 2;
  return g_app_2eheff_2emain_2ebuildCommands_24s1350_val;
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam1(V self, V *args) {
  V v_x2_241 = args[0];
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str2);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return v_x_242;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam1_clo)}));
  V v_t_245 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_pos), 1, (V[]){v_t_245}));
  V v_x_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_ap), 2, (V[]){v_t_244, v_t_246}));
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_check)}));
  return heff_tail(heff_get(v_s_240, LBL_ap), 2, (V[]){v_t_248, v_x_247});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam3(V self, V *args) {
  V v_x2_2411 = args[0];
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str6);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 2);
    return v_x_2412;
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam3_clo)}));
  V v_t_2415 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_pos), 1, (V[]){v_t_2415}));
  V v_x_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_ap), 2, (V[]){v_t_2414, v_t_2416}));
  V v_t_2418 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_pos), 1, (V[]){v_t_2418}));
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_run)}));
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_ap), 2, (V[]){v_t_2420, v_x_2417}));
  return heff_tail(heff_get(v_s_2410, LBL_ap), 2, (V[]){v_t_2421, v_y_2419});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2425 = heff_rec(8, shape_180_303_189_68_368_273_276_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_flag), 1, (V[]){v_t_2425}));
  V v_x_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_ap), 2, (V[]){v_t_2424, v_t_2426}));
  V v_t_2428 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str15), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_pos), 1, (V[]){v_t_2428}));
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_tests)}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_ap), 2, (V[]){v_t_2430, v_x_2427}));
  return heff_tail(heff_get(v_s_2423, LBL_ap), 2, (V[]){v_t_2431, v_y_2429});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam6(V self, V *args) {
  V v_x2_2434 = args[0];
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str18);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    heff_take_n(v_x2_2434, 1ULL, 2);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam5(V self, V *args) {
  V v_s_2433 = args[0];
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam6_clo)}));
  V v_t_2438 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str19), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_pos), 1, (V[]){v_t_2438}));
  V v_x_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_ap), 2, (V[]){v_t_2437, v_t_2439}));
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_promote)}));
  return heff_tail(heff_get(v_s_2433, LBL_ap), 2, (V[]){v_t_2441, v_x_2440});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam8(V self, V *args) {
  V v_x2_2444 = args[0];
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str22);
  }
  case TAG_Cons: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    heff_take_n(v_x2_2444, 1ULL, 2);
    return v_x_2445;
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam9(V self, V *args) {
  V v_x2_2451 = args[0];
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str24);
  }
  case TAG_Cons: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    heff_take_n(v_x2_2451, 1ULL, 2);
    return v_x_2452;
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam10(V self, V *args) {
  V v_vs_2462 = args[0];
  V v_x2_2463 = ({ V a_0 = v_vs_2462; V r_ = (g_std_2ecli_2elastS(a_0)); heff_drop(v_vs_2462); r_; });
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_Nothing: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str30);
  }
  case TAG_Just: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    heff_take_n(v_x2_2463, 1ULL, 1);
    return v_x_2464;
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam8_clo)}));
  V v_t_2448 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str23), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_pos), 1, (V[]){v_t_2448}));
  V v_x_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2447, v_t_2449}));
  V v_t_2454 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam9_clo)}));
  V v_t_2455 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str25), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_pos), 1, (V[]){v_t_2455}));
  V v_y_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2454, v_t_2456}));
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2459 = heff_rec(8, shape_180_303_189_68_368_273_276_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str26), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str29), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_flag), 1, (V[]){v_t_2459}));
  V v_z_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2458, v_t_2460}));
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam10_clo)}));
  V v_t_2466 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str31), NTAG(TAG_Nil)});
  V v_t_2467 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str32), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str33), v_t_2466})});
  V v_t_2468 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str34), NTAG(TAG_Nil)});
  V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str35), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str36), v_t_2468})});
  V v_t_2470 = heff_tag(TAG_Among, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str37), v_t_2469})});
  V v_t_2471 = heff_rec(8, shape_180_303_189_68_368_273_276_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str41), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str42), v_t_2467}), NTAG(TAG_False), NTAG(TAG_True), v_t_2470});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_flag), 1, (V[]){v_t_2471}));
  V v_w_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2465, v_t_2472}));
  V v_t_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_compile)}));
  V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2474, v_x_2450}));
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2475, v_y_2457}));
  V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2443), LBL_ap), 2, (V[]){v_t_2476, v_z_2461}));
  return heff_tail(heff_get(v_s_2443, LBL_ap), 2, (V[]){v_t_2477, v_w_2473});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam12(V self, V *args) {
  V v_x2_2480 = args[0];
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str45);
  }
  case TAG_Cons: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    heff_take_n(v_x2_2480, 1ULL, 2);
    return v_x_2481;
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam11(V self, V *args) {
  V v_s_2479 = args[0];
  V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2479), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam12_clo)}));
  V v_t_2484 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str46), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2479), LBL_pos), 1, (V[]){v_t_2484}));
  V v_x_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2479), LBL_ap), 2, (V[]){v_t_2483, v_t_2485}));
  V v_t_2487 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2479), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_explain)}));
  return heff_tail(heff_get(v_s_2479, LBL_ap), 2, (V[]){v_t_2487, v_x_2486});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam14(V self, V *args) {
  V v_x2_2490 = args[0];
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str49);
  }
  case TAG_Cons: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    heff_take_n(v_x2_2490, 1ULL, 2);
    return v_x_2491;
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam13(V self, V *args) {
  V v_s_2489 = args[0];
  V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam14_clo)}));
  V v_t_2494 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str50), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_pos), 1, (V[]){v_t_2494}));
  V v_x_2496 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_ap), 2, (V[]){v_t_2493, v_t_2495}));
  V v_t_2497 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str51), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_2498 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_pos), 1, (V[]){v_t_2497}));
  V v_t_2499 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_typeAt)}));
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2489), LBL_ap), 2, (V[]){v_t_2499, v_x_2496}));
  return heff_tail(heff_get(v_s_2489, LBL_ap), 2, (V[]){v_t_24100, v_y_2498});
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam16(V self, V *args) {
  V v_vs_24103 = args[0];
  V v_x1_24106;
  switch (heff_tag_of(v_vs_24103)) {
  case TAG_Nil: {
    v_x1_24106 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24103, 0ULL, 2);
    v_x1_24106 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_vs_24103);
  }
  switch (heff_tag_of(v_x1_24106)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_24106);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_24s1350_lam15(V self, V *args) {
  V v_s_24102 = args[0];
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_lam16_clo)}));
  V v_t_24108 = heff_rec(8, shape_180_303_189_68_368_273_276_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str54), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str56), ((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str57), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24109 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_flag), 1, (V[]){v_t_24108}));
  V v_x_24110 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_ap), 2, (V[]){v_t_24107, v_t_24109}));
  V v_t_24111 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24s1350_str58), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24112 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_pos), 1, (V[]){v_t_24111}));
  V v_t_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2ebuild_24s858_24s1030_24s1118_24s1246_24s1323_get()), LBL_fmt)}));
  V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24102), LBL_ap), 2, (V[]){v_t_24113, v_x_24110}));
  return heff_tail(heff_get(v_s_24102, LBL_ap), 2, (V[]){v_t_24114, v_y_24112});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[39]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str1 = {{0x80000000u, K_STR, 0}, 39, 39, {97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32, 68, 73, 82, 32, 40, 104, 101, 114, 101, 44, 32, 119, 105, 116, 104, 111, 117, 116, 32, 105, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {68, 73, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[108]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str4 = {{0x80000000u, K_STR, 0}, 108, 108, {102, 101, 116, 99, 104, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 114, 101, 113, 117, 105, 114, 101, 115, 44, 32, 119, 114, 105, 116, 105, 110, 103, 32, 104, 101, 102, 102, 46, 115, 117, 109, 59, 32, 119, 105, 116, 104, 32, 80, 65, 84, 72, 44, 32, 114, 101, 113, 117, 105, 114, 101, 32, 105, 116, 32, 40, 97, 116, 32, 86, 69, 82, 83, 73, 79, 78, 44, 32, 101, 108, 115, 101, 32, 105, 116, 115, 32, 110, 101, 119, 101, 115, 116, 41, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {80, 65, 84, 72, 91, 64, 86, 69, 82, 83, 73, 79, 78, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[136]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str7 = {{0x80000000u, K_STR, 0}, 136, 136, {116, 104, 101, 32, 119, 104, 111, 108, 101, 32, 112, 114, 111, 106, 101, 99, 116, 58, 32, 101, 118, 101, 114, 121, 32, 109, 111, 100, 117, 108, 101, 32, 111, 102, 32, 115, 114, 99, 47, 32, 99, 104, 101, 99, 107, 101, 100, 44, 32, 116, 104, 101, 110, 32, 101, 118, 101, 114, 121, 32, 112, 114, 111, 103, 114, 97, 109, 44, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 109, 97, 105, 110, 46, 104, 102, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 97, 115, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 98, 117, 105, 108, 100, 46, 104, 102, 32, 115, 97, 121, 115, 44, 32, 116, 111, 32, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 115, 116, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[222]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str9 = {{0x80000000u, K_STR, 0}, 222, 222, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 97, 116, 32, 68, 73, 82, 32, 40, 104, 101, 114, 101, 44, 32, 119, 105, 116, 104, 111, 117, 116, 32, 105, 116, 41, 32, 98, 117, 105, 108, 116, 32, 97, 115, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 44, 32, 105, 116, 115, 32, 112, 114, 111, 103, 114, 97, 109, 115, 32, 105, 110, 116, 111, 32, 116, 104, 101, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 39, 115, 32, 98, 105, 110, 47, 32, 40, 72, 69, 70, 70, 95, 72, 79, 77, 69, 47, 98, 105, 110, 44, 32, 101, 108, 115, 101, 32, 126, 47, 46, 104, 101, 102, 102, 47, 98, 105, 110, 41, 44, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 116, 104, 101, 121, 32, 115, 104, 105, 112, 32, 40, 116, 104, 101, 105, 114, 32, 98, 117, 105, 108, 100, 46, 104, 102, 39, 115, 32, 96, 115, 104, 105, 112, 115, 96, 41, 32, 105, 110, 116, 111, 32, 116, 104, 101, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 44, 32, 98, 101, 115, 105, 100, 101, 32, 98, 105, 110, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {68, 73, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str11 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 117, 98, 108, 105, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str12 = {{0x80000000u, K_STR, 0}, 56, 56, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 44, 32, 116, 104, 101, 110, 32, 116, 97, 103, 32, 105, 116, 32, 118, 86, 69, 82, 83, 73, 79, 78, 32, 97, 110, 100, 32, 112, 117, 115, 104, 32, 116, 104, 101, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_24s1351_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {86, 69, 82, 83, 73, 79, 78}};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam0, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam2, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam4, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam5, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_24s1351_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_24s1351_lam7, 1, 0};

static V g_app_2eheff_2emain_2eprojectCommands_24s1351_val;
static int g_app_2eheff_2emain_2eprojectCommands_24s1351_st;
static V g_app_2eheff_2emain_2eprojectCommands_24s1351_init(void) {
  V v_t_249 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str1), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam0_clo)});
  V v_t_2419 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str4), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam2_clo)});
  V v_t_2421 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str7), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam4_clo)});
  V v_t_2431 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str9), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam5_clo)});
  V v_t_2441 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str12), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam7_clo)});
  V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
  V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, heff_tag(TAG_Cons, 2, (V[]){v_t_2431, v_t_2442})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2419, v_t_2443})});
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_get(void) {
  if (g_app_2eheff_2emain_2eprojectCommands_24s1351_st == 2) return g_app_2eheff_2emain_2eprojectCommands_24s1351_val;
  if (g_app_2eheff_2emain_2eprojectCommands_24s1351_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2eprojectCommands_24s1351_st = 1;
  g_app_2eheff_2emain_2eprojectCommands_24s1351_val = heff_tr(g_app_2eheff_2emain_2eprojectCommands_24s1351_init());
  g_app_2eheff_2emain_2eprojectCommands_24s1351_st = 2;
  return g_app_2eheff_2emain_2eprojectCommands_24s1351_val;
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam1(V self, V *args) {
  V v_ws_241 = args[0];
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_ws_241, 0);
    heff_take_n(v_ws_241, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_242});
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam1_clo)}));
  V v_t_245 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_pos), 1, (V[]){v_t_245}));
  V v_x_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_ap), 2, (V[]){v_t_244, v_t_246}));
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get()), LBL_init)}));
  return heff_tail(heff_get(v_s_240, LBL_ap), 2, (V[]){v_t_248, v_x_247});
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam3(V self, V *args) {
  V v_ws_2411 = args[0];
  switch (heff_tag_of(v_ws_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_2412 = heff_field(v_ws_2411, 0);
    heff_take_n(v_ws_2411, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_2412});
  }
  default: return heff_nomatch(v_ws_2411);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam3_clo)}));
  V v_t_2415 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_pos), 1, (V[]){v_t_2415}));
  V v_x_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_ap), 2, (V[]){v_t_2414, v_t_2416}));
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2410), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get()), LBL_get)}));
  return heff_tail(heff_get(v_s_2410, LBL_ap), 2, (V[]){v_t_2418, v_x_2417});
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  V f_ = heff_get(v_s_2420, LBL_give);
  args[0] = heff_get(heff_dup(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get()), LBL_build);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam6(V self, V *args) {
  V v_ws_2423 = args[0];
  switch (heff_tag_of(v_ws_2423)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_2424 = heff_field(v_ws_2423, 0);
    heff_take_n(v_ws_2423, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_2424});
  }
  default: return heff_nomatch(v_ws_2423);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2422), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam6_clo)}));
  V v_t_2427 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2422), LBL_pos), 1, (V[]){v_t_2427}));
  V v_x_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2422), LBL_ap), 2, (V[]){v_t_2426, v_t_2428}));
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2422), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get()), LBL_install)}));
  return heff_tail(heff_get(v_s_2422, LBL_ap), 2, (V[]){v_t_2430, v_x_2429});
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam8(V self, V *args) {
  V v_x2_2433 = args[0];
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str13);
  }
  case TAG_Cons: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    heff_take_n(v_x2_2433, 1ULL, 2);
    return v_x_2434;
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_24s1351_lam7(V self, V *args) {
  V v_s_2432 = args[0];
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2432), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_lam8_clo)}));
  V v_t_2437 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_24s1351_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2432), LBL_pos), 1, (V[]){v_t_2437}));
  V v_x_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2432), LBL_ap), 2, (V[]){v_t_2436, v_t_2438}));
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2432), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2eproject_24s936_24s1069_24s1179_24s1267_24s1326_get()), LBL_publish)}));
  return heff_tail(heff_get(v_s_2432, LBL_ap), 2, (V[]){v_t_2440, v_x_2439});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 115, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str1 = {{0x80000000u, K_STR, 0}, 34, 34, {97, 32, 108, 97, 110, 103, 117, 97, 103, 101, 32, 115, 101, 114, 118, 101, 114, 44, 32, 111, 110, 32, 115, 116, 100, 105, 110, 47, 115, 116, 100, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 76, 65, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {118, 101, 114, 115, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str4 = {{0x80000000u, K_STR, 0}, 68, 68, {119, 104, 105, 99, 104, 32, 104, 101, 102, 102, 32, 116, 104, 105, 115, 32, 105, 115, 58, 32, 105, 116, 115, 32, 118, 101, 114, 115, 105, 111, 110, 44, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 116, 32, 99, 97, 109, 101, 32, 119, 105, 116, 104, 32, 115, 97, 121, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 99, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 101, 118, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_24s1352_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_24s1352_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_24s1352_lam0, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_24s1352_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_24s1352_lam1, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_24s1352_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_24s1352_lam2, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_24s1352_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_24s1352_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_24s1352_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_24s1352_lam3, 1, 0};

static V g_app_2eheff_2emain_2etoolCommands_24s1352_val;
static int g_app_2eheff_2emain_2etoolCommands_24s1352_st;
static V g_app_2eheff_2emain_2etoolCommands_24s1352_init(void) {
  V v_t_244 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str1), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_lam0_clo)});
  V v_t_246 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str4), NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_lam1_clo)});
  V v_t_2411 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str6), NTAG(TAG_False), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_lam2_clo)});
  V v_t_2421 = heff_rec(4, shape_198_68_304_13, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str9), NTAG(TAG_False), ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_lam3_clo)});
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_246, heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2422})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_2423});
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_get(void) {
  if (g_app_2eheff_2emain_2etoolCommands_24s1352_st == 2) return g_app_2eheff_2emain_2etoolCommands_24s1352_val;
  if (g_app_2eheff_2emain_2etoolCommands_24s1352_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2etoolCommands_24s1352_st = 1;
  g_app_2eheff_2emain_2etoolCommands_24s1352_val = heff_tr(g_app_2eheff_2emain_2etoolCommands_24s1352_init());
  g_app_2eheff_2emain_2etoolCommands_24s1352_st = 2;
  return g_app_2eheff_2emain_2etoolCommands_24s1352_val;
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_t_241 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_242 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_pos), 1, (V[]){v_t_241}));
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_s_240), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_get()), LBL_lsp)}));
  return heff_tail(heff_get(v_s_240, LBL_ap), 2, (V[]){v_t_243, v_x_242});
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V f_ = heff_get(v_s_245, LBL_give);
  args[0] = heff_get(heff_dup(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_get()), LBL_version);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_t_248 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_247), LBL_pos), 1, (V[]){v_t_248}));
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_s_247), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_get()), LBL_dumpCore)}));
  return heff_tail(heff_get(v_s_247, LBL_ap), 2, (V[]){v_t_2410, v_x_249});
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam4(V self, V *args) {
  V v_x2_2413 = args[0];
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str10);
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 2);
    return v_x_2414;
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_app_2eheff_2emain_2etoolCommands_24s1352_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2412), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_lam4_clo)}));
  V v_t_2417 = heff_rec(3, shape_189_14_51, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_24s1352_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2412), LBL_pos), 1, (V[]){v_t_2417}));
  V v_x_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2412), LBL_ap), 2, (V[]){v_t_2416, v_t_2418}));
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2412), LBL_give), 1, (V[]){heff_get(heff_dup(g_app_2eheff_2emain_2etool_24s984_24s1111_24s1216_24s1284_24s1288_get()), LBL_dumpEval)}));
  return heff_tail(heff_get(v_s_2412, LBL_ap), 2, (V[]){v_t_2420, v_x_2419});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam2, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam3, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam5, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam6, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam9, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam11(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam10, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam12, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam14(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam13, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam8(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam17, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam19(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam18, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam20, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam22(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam21(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam21_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam21, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam16(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam15(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_entry, 2, 0};

V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361(V v_k_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  return heff_perform(v_t_245, heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam1, 1, 2, (V[]){v_k_240, v_k_241}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361(a[0], a[1]);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam0(V self, V *args) {
  V v_a_242 = args[0];
  return v_a_242;
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2413 = args[1];
  V f_ = v_k_2413;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_f_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2415, 2, (V[]){v_x_2417, v_k_2416});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam3(V self, V *args) {
  V v_m_2414 = args[0];
  V v_f_2415 = args[1];
  V v_k_2416 = args[2];
  V f_ = v_m_2414;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam4, 1, 2, (V[]){v_f_2415, v_k_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam5(V self, V *args) {
  V v_p_2418 = args[0];
  V v_k_2419 = args[1];
  return heff_perform(v_p_2418, v_k_2419);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V v_x_2426;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_x_2420, 1);
    heff_take_n(v_x_2420, 2ULL, 2);
    v_x_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2422 = heff_tag(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  return heff_perform(heff_tag(TAG_InR, 1, (V[]){v_t_2422}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam7, 1, 2, (V[]){v_x_2420, v_k_2421}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2434 = args[1];
  V f_ = v_k_2434;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_f_2436 = heff_env(self)[0];
  V v_k_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2436, 2, (V[]){v_x_2438, v_k_2437});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam10(V self, V *args) {
  V v_m_2435 = args[0];
  V v_f_2436 = args[1];
  V v_k_2437 = args[2];
  V f_ = v_m_2435;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam11, 1, 2, (V[]){v_f_2436, v_k_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam12(V self, V *args) {
  V v_p_2439 = args[0];
  V v_k_2440 = args[1];
  return heff_perform(v_p_2439, v_k_2440);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam14(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_x_2447;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_MkPair: {
    V v_y_2446 = heff_field(v_x_2441, 1);
    heff_take_n(v_x_2441, 2ULL, 2);
    v_x_2447 = v_y_2446;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_k_2442;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2442 = args[1];
  V v_t_2443 = heff_tag(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  return heff_perform(heff_tag(TAG_InR, 1, (V[]){v_t_2443}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam14, 1, 2, (V[]){v_x_2441, v_k_2442}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_rec(2, shape_201_117, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
  return heff_tail(v_k_240, 5, (V[]){v_x_2431, v_t_2432, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam9_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam10_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam12_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam13_clo), v_k_241});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam17(V self, V *args) {
  V v_x_2458 = args[0];
  V v_k_2459 = args[1];
  V f_ = v_k_2459;
  args[0] = v_x_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam19(V self, V *args) {
  V v_x_2463 = args[0];
  V v_f_2461 = heff_env(self)[0];
  V v_k_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2461, 2, (V[]){v_x_2463, v_k_2462});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam18(V self, V *args) {
  V v_m_2460 = args[0];
  V v_f_2461 = args[1];
  V v_k_2462 = args[2];
  V f_ = v_m_2460;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam19, 1, 2, (V[]){v_f_2461, v_k_2462});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam20(V self, V *args) {
  V v_p_2464 = args[0];
  V v_k_2465 = args[1];
  return heff_perform(v_p_2464, v_k_2465);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam22(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_k_2467 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2469);
  V v_x_2472;
  switch (heff_tag_of(v_x_2466)) {
  case TAG_MkPair: {
    V v_y_2471 = heff_field(v_x_2466, 1);
    heff_take_n(v_x_2466, 2ULL, 2);
    v_x_2472 = v_y_2471;
    break;
  }
  default: heff_nomatch(v_x_2466);
  }
  V f_ = v_k_2467;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam21(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_2467 = args[1];
  V v_t_2468 = heff_tag(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  return heff_perform(heff_tag(TAG_InR, 1, (V[]){v_t_2468}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam22, 1, 2, (V[]){v_x_2466, v_k_2467}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam16(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = heff_rec(2, shape_201_117, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
  return heff_tail(v_k_240, 5, (V[]){v_x_2456, v_t_2457, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam17_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam18_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam20_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam21_clo), v_k_241});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam15(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2455}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam16, 1, 2, (V[]){v_k_240, v_k_241}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_prelude_2econcatList_24s1353(heff_dup(g_app_2eheff_2emain_2eprojectCommands_24s1351_get())));
  V v_t_248 = (g_prelude_2econcatList(heff_dup(g_app_2eheff_2emain_2ebuildCommands_24s1350_get()), v_t_247));
  V v_t_249 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_str0); V a_1 = v_t_248; V a_2 = v_x_246; V r_ = (g_std_2ecli_2ereadLine(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_Run: {
    V v_act_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2411 = heff_rec(2, shape_201_117, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    return heff_tail(v_act_2410, 6, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s846_24s853_get()), v_k_240, v_t_2411, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam2_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam3_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam5_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam6_clo), v_k_241});
  }
  case TAG_Out: {
    V v_text_2427 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Out = heff_take_reuse_n(v_t_249, 1ULL, 1);
    V v_t_2428 = heff_tag(TAG_Write, 2, (V[]){v_text_2427, NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_at(v_ru_24t_249_24Out, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2430}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam8, 1, 2, (V[]){v_k_240, v_k_241}));
  }
  case TAG_Fail: {
    V v_text_2448 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Fail = heff_take_reuse_n(v_t_249, 1ULL, 1);
    V v_t_2449 = heff_tag(TAG_WriteErr, 2, (V[]){v_text_2448, NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_at(v_ru_24t_249_24Fail, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2451}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1356_24s1357_24s1361_lam15, 1, 2, (V[]){v_k_240, v_k_241}));
  }
  default: return heff_nomatch(v_t_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam2, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam3, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam5, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam6, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam7, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam9, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam11(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam10, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam12, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam13, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam14, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam8(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam17, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam19(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam18, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam20, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam21(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam21_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam21, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam22(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam22_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam22, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam16(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam15(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_entry, 1, 0};

V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364(V v_k_240) {
top: ;
  V v_t_242 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam0_clo)})});
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_242})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  return heff_perform(v_t_244, heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam1, 1, 1, (V[]){v_k_240}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364(a[0]);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam0(V self, V *args) {
  V v_a_241 = args[0];
  return v_a_241;
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_2411 = args[1];
  V f_ = v_k_2411;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2413, 2, (V[]){v_x_2415, v_k_2414});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam3(V self, V *args) {
  V v_m_2412 = args[0];
  V v_f_2413 = args[1];
  V v_k_2414 = args[2];
  V f_ = v_m_2412;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam4, 1, 2, (V[]){v_f_2413, v_k_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam5(V self, V *args) {
  V v_p_2416 = args[0];
  V v_k_2417 = args[1];
  return heff_perform(v_p_2416, v_k_2417);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2419 = args[1];
  V f_ = v_k_2419;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  heff_drop(v_x_2420);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam9(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2427 = args[1];
  V f_ = v_k_2427;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam11(V self, V *args) {
  V v_x_2431 = args[0];
  V v_f_2429 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2429, 2, (V[]){v_x_2431, v_k_2430});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam10(V self, V *args) {
  V v_m_2428 = args[0];
  V v_f_2429 = args[1];
  V v_k_2430 = args[2];
  V f_ = v_m_2428;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam11, 1, 2, (V[]){v_f_2429, v_k_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam12(V self, V *args) {
  V v_p_2432 = args[0];
  V v_k_2433 = args[1];
  return heff_perform(v_p_2432, v_k_2433);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam13(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2435 = args[1];
  V f_ = v_k_2435;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam14(V self, V *args) {
  V v_x_2436 = args[0];
  heff_drop(v_x_2436);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_k_240, 4, (V[]){v_x_2425, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam9_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam10_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam12_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam13_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam14_clo)});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam17(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2447 = args[1];
  V f_ = v_k_2447;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam19(V self, V *args) {
  V v_x_2451 = args[0];
  V v_f_2449 = heff_env(self)[0];
  V v_k_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_f_2449, 2, (V[]){v_x_2451, v_k_2450});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam18(V self, V *args) {
  V v_m_2448 = args[0];
  V v_f_2449 = args[1];
  V v_k_2450 = args[2];
  V f_ = v_m_2448;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam19, 1, 2, (V[]){v_f_2449, v_k_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam20(V self, V *args) {
  V v_p_2452 = args[0];
  V v_k_2453 = args[1];
  return heff_perform(v_p_2452, v_k_2453);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam21(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2455 = args[1];
  V f_ = v_k_2455;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam22(V self, V *args) {
  V v_x_2456 = args[0];
  heff_drop(v_x_2456);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_k_240, 4, (V[]){v_x_2445, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam17_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam18_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam20_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam21_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam22_clo)});
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam15(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2444}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam16, 1, 1, (V[]){v_k_240}));
}
V g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_prelude_2econcatList_24s1353(heff_dup(g_app_2eheff_2emain_2eprojectCommands_24s1351_get())));
  V v_t_247 = (g_prelude_2econcatList(heff_dup(g_app_2eheff_2emain_2ebuildCommands_24s1350_get()), v_t_246));
  V v_t_248 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_str0); V a_1 = v_t_247; V a_2 = v_x_245; V r_ = (g_std_2ecli_2ereadLine(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Run: {
    V v_act_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    return heff_tail(v_act_249, 5, (V[]){heff_dup(g_co_2ethrough_24s796_24s850_get()), v_k_240, heff_rec(3, shape_278_23_185, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam2_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam3_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam5_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam6_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam7_clo)});
  }
  case TAG_Out: {
    V v_text_2421 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Out = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2422 = heff_tag(TAG_Write, 2, (V[]){v_text_2421, NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_at(v_ru_24t_248_24Out, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2424}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam8, 1, 1, (V[]){v_k_240}));
  }
  case TAG_Fail: {
    V v_text_2437 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Fail = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2438 = heff_tag(TAG_WriteErr, 2, (V[]){v_text_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_at(v_ru_24t_248_24Fail, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2440}), heff_clo(g_app_2eheff_2emain_2eprogram_24s857_24s1029_24s1117_24s1245_24s1287_24s1322_24s1358_24s1362_24s1364_lam15, 1, 1, (V[]){v_k_240}));
  }
  default: return heff_nomatch(v_t_248);
  }
}