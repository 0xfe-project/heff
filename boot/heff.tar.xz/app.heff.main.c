// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ehf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};

static V g_app_2eheff_2emain_2ehf_val;
static int g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag(TAG_files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (g_app_2eheff_2emain_2ehf_st == 2) return g_app_2eheff_2emain_2ehf_val;
  if (g_app_2eheff_2emain_2ehf_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ehf_st = 1;
  g_app_2eheff_2emain_2ehf_val = heff_tr(g_app_2eheff_2emain_2ehf_init());
  g_app_2eheff_2emain_2ehf_st = 2;
  return g_app_2eheff_2emain_2ehf_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_app_2eheff_2emain_2ebuildCommands_str1 = {{0x80000000u, K_STR, 0}, 55, 55, {101, 108, 97, 98, 111, 114, 97, 116, 101, 32, 70, 73, 76, 69, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 59, 32, 112, 114, 105, 110, 116, 32, 105, 116, 115, 32, 105, 110, 116, 101, 114, 102, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_app_2eheff_2emain_2ebuildCommands_str5 = {{0x80000000u, K_STR, 0}, 47, 47, {114, 117, 110, 32, 70, 73, 76, 69, 39, 115, 32, 109, 97, 105, 110, 32, 119, 105, 116, 104, 32, 65, 82, 71, 83, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 102, 111, 114, 32, 78, 111, 100, 101, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {65, 82, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[213]; } g_app_2eheff_2emain_2ebuildCommands_str10 = {{0x80000000u, K_STR, 0}, 213, 213, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 39, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 40, 116, 104, 101, 32, 96, 45, 45, 32, 46, 46, 46, 96, 32, 108, 105, 110, 101, 115, 32, 117, 110, 100, 101, 114, 32, 116, 104, 101, 109, 41, 44, 32, 97, 110, 100, 32, 114, 117, 110, 32, 116, 104, 101, 32, 116, 101, 115, 116, 115, 32, 40, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 32, 111, 102, 32, 116, 121, 112, 101, 32, 96, 84, 101, 115, 116, 96, 44, 32, 108, 105, 98, 47, 99, 104, 101, 99, 107, 46, 104, 102, 41, 44, 32, 111, 102, 32, 116, 104, 101, 32, 70, 73, 76, 69, 115, 32, 40, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 39, 115, 32, 46, 104, 102, 32, 102, 105, 108, 101, 115, 41, 44, 32, 101, 108, 115, 101, 32, 111, 102, 32, 101, 118, 101, 114, 121, 32, 46, 104, 102, 32, 102, 105, 108, 101, 32, 111, 102, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 101, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[64]; } g_app_2eheff_2emain_2ebuildCommands_str14 = {{0x80000000u, K_STR, 0}, 64, 64, {116, 104, 101, 32, 115, 101, 101, 100, 32, 116, 104, 101, 32, 112, 114, 111, 112, 101, 114, 116, 105, 101, 115, 32, 100, 114, 97, 119, 32, 102, 114, 111, 109, 32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 115, 101, 101, 100, 44, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 114, 117, 110, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_app_2eheff_2emain_2ebuildCommands_str17 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 114, 105, 116, 101, 32, 101, 97, 99, 104, 32, 119, 97, 116, 99, 104, 39, 115, 32, 118, 97, 108, 117, 101, 32, 117, 110, 100, 101, 114, 32, 105, 116, 32, 97, 115, 32, 105, 116, 115, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 109, 112, 105, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[173]; } g_app_2eheff_2emain_2ebuildCommands_str21 = {{0x80000000u, K_STR, 0}, 173, 173, {70, 73, 76, 69, 32, 99, 111, 109, 112, 105, 108, 101, 100, 44, 32, 98, 121, 32, 77, 79, 68, 69, 58, 32, 101, 115, 109, 32, 40, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 41, 44, 32, 112, 97, 103, 101, 32, 40, 97, 32, 115, 99, 114, 105, 112, 116, 32, 114, 117, 110, 110, 105, 110, 103, 32, 116, 104, 101, 32, 97, 112, 112, 32, 78, 65, 77, 69, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 41, 44, 32, 110, 111, 100, 101, 32, 40, 97, 32, 78, 111, 100, 101, 46, 106, 115, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 41, 44, 32, 99, 32, 40, 97, 32, 67, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 44, 32, 102, 111, 114, 32, 96, 122, 105, 103, 32, 99, 99, 96, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {79, 85, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str28 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 65, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_str29 = {{0x80000000u, K_STR, 0}, 32, 32, {116, 104, 101, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 32, 114, 117, 110, 32, 40, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str33 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str35 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str36 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str37 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {98, 97, 99, 107, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str40 = {{0x80000000u, K_STR, 0}, 4, 4, {77, 79, 68, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_app_2eheff_2emain_2ebuildCommands_str41 = {{0x80000000u, K_STR, 0}, 22, 22, {119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 116, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {101, 120, 112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_str44 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 104, 101, 32, 101, 108, 97, 98, 111, 114, 97, 116, 105, 111, 110, 32, 116, 114, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str45 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str46 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str47 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 121, 112, 101, 45, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[67]; } g_app_2eheff_2emain_2ebuildCommands_str48 = {{0x80000000u, K_STR, 0}, 67, 67, {119, 104, 97, 116, 32, 116, 104, 101, 32, 110, 97, 109, 101, 32, 97, 116, 32, 101, 97, 99, 104, 32, 79, 70, 70, 83, 69, 84, 32, 114, 101, 115, 111, 108, 118, 101, 100, 32, 116, 111, 44, 32, 97, 110, 100, 32, 105, 116, 115, 32, 116, 121, 112, 101, 44, 32, 97, 32, 108, 105, 110, 101, 32, 101, 97, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str49 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_app_2eheff_2emain_2ebuildCommands_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {79, 70, 70, 83, 69, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str52 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 109, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_str53 = {{0x80000000u, K_STR, 0}, 21, 21, {102, 111, 114, 109, 97, 116, 32, 70, 73, 76, 69, 115, 32, 105, 110, 32, 112, 108, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_str54 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str56 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_str57 = {{0x80000000u, K_STR, 0}, 32, 32, {111, 110, 108, 121, 32, 115, 97, 121, 32, 119, 104, 105, 99, 104, 32, 97, 114, 101, 32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str58 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2423 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2433 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2443 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2479 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2489 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24102 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24116 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str52), ((V)&g_app_2eheff_2emain_2ebuildCommands_str53), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){v_c_240})});
  V v_t_24117 = heff_tag(TAG_Cons, 2, (V[]){v_t_24116, NTAG(TAG_Nil)});
  V v_t_24118 = heff_tag(TAG_Cons, 2, (V[]){v_t_2489, heff_tag(TAG_Cons, 2, (V[]){v_t_24102, v_t_24117})});
  V v_t_24119 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, heff_tag(TAG_Cons, 2, (V[]){v_t_2479, v_t_24118})});
  V v_t_24120 = heff_tag(TAG_Cons, 2, (V[]){v_t_2423, heff_tag(TAG_Cons, 2, (V[]){v_t_2433, v_t_24119})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_24120});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_242 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take(v_x2_242, 1ULL);
    return v_x_243;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_246 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_ap), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_check)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_249, v_x_248});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2412 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_x2_2412);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take(v_x2_2412, 1ULL);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2416 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_rest), NTAG(TAG_none)});
  V v_y_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2419}));
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_run)}));
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2421, v_x_2418}));
  return heff_tail(heff_get(v_s_2411, LBL_ap), 2, (V[]){v_t_2422, v_y_2420});
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2426 = heff_rec(8, shape_172_288_181_63_353_262_265_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_none)});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_flag), 1, (V[]){v_t_2426}));
  V v_x_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_ap), 2, (V[]){v_t_2425, v_t_2427}));
  V v_t_2429 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), NTAG(TAG_many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_pos), 1, (V[]){v_t_2429}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_tests)}));
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_ap), 2, (V[]){v_t_2431, v_x_2428}));
  return heff_tail(heff_get(v_s_2424, LBL_ap), 2, (V[]){v_t_2432, v_y_2430});
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_x2_2435 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    heff_drop(v_x2_2435);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str18);
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    heff_take(v_x2_2435, 1ULL);
    return v_x_2436;
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2439 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_pos), 1, (V[]){v_t_2439}));
  V v_x_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_ap), 2, (V[]){v_t_2438, v_t_2440}));
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_promote)}));
  return heff_tail(heff_get(v_s_2434, LBL_ap), 2, (V[]){v_t_2442, v_x_2441});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_x2_2445 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    heff_drop(v_x2_2445);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str22);
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    heff_take(v_x2_2445, 1ULL);
    return v_x_2446;
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_x2_2452 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    heff_drop(v_x2_2452);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str24);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take(v_x2_2452, 1ULL);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_vs_2463 = args[0];
  heff_drop(self);
  V v_x2_2464 = ({ V a_0 = v_vs_2463; V r_ = (g_std_2ecli_2elastS(a_0)); heff_drop(v_vs_2463); r_; });
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2464);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str30);
  }
  case TAG_Just: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    heff_take(v_x2_2464, 1ULL);
    return v_x_2465;
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_2449 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_pos), 1, (V[]){v_t_2449}));
  V v_x_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2448, v_t_2450}));
  V v_t_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam9_clo)}));
  V v_t_2456 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str25), NTAG(TAG_one), NTAG(TAG_none)});
  V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_pos), 1, (V[]){v_t_2456}));
  V v_y_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2460 = heff_rec(8, shape_172_288_181_63_353_262_265_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str26), ((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_none)});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_flag), 1, (V[]){v_t_2460}));
  V v_z_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2459, v_t_2461}));
  V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_2467 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Nil)});
  V v_t_2468 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str33), v_t_2467})});
  V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), NTAG(TAG_Nil)});
  V v_t_2470 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str35), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str36), v_t_2469})});
  V v_t_2471 = heff_tag(TAG_among, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str37), v_t_2470})});
  V v_t_2472 = heff_rec(8, shape_172_288_181_63_353_262_265_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str42), v_t_2468}), NTAG(TAG_False), NTAG(TAG_True), v_t_2471});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_flag), 1, (V[]){v_t_2472}));
  V v_w_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2466, v_t_2473}));
  V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_compile)}));
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2475, v_x_2451}));
  V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2476, v_y_2458}));
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2477, v_z_2462}));
  return heff_tail(heff_get(v_s_2444, LBL_ap), 2, (V[]){v_t_2478, v_w_2474});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_2481 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_Nil: {
    heff_drop(v_x2_2481);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str45);
  }
  case TAG_Cons: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    heff_take(v_x2_2481, 1ULL);
    return v_x_2482;
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_2480 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_2485 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str46), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_pos), 1, (V[]){v_t_2485}));
  V v_x_2487 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_ap), 2, (V[]){v_t_2484, v_t_2486}));
  V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_explain)}));
  return heff_tail(heff_get(v_s_2480, LBL_ap), 2, (V[]){v_t_2488, v_x_2487});
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_x2_2491 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_Nil: {
    heff_drop(v_x2_2491);
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str49);
  }
  case TAG_Cons: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    heff_take(v_x2_2491, 1ULL);
    return v_x_2492;
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_s_2490 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_2495 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2496 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_pos), 1, (V[]){v_t_2495}));
  V v_x_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_ap), 2, (V[]){v_t_2494, v_t_2496}));
  V v_t_2498 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str51), NTAG(TAG_some), NTAG(TAG_none)});
  V v_y_2499 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_pos), 1, (V[]){v_t_2498}));
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_typeAt)}));
  V v_t_24101 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_ap), 2, (V[]){v_t_24100, v_x_2497}));
  return heff_tail(heff_get(v_s_2490, LBL_ap), 2, (V[]){v_t_24101, v_y_2499});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_vs_24104 = args[0];
  heff_drop(self);
  V v_x1_24107;
  switch (heff_tag_of(v_vs_24104)) {
  case TAG_Nil: {
    heff_drop(v_vs_24104);
    v_x1_24107 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_vs_24104, 0ULL);
    v_x1_24107 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_vs_24104);
  }
  switch (heff_tag_of(v_x1_24107)) {
  case TAG_True: {
    heff_drop(v_x1_24107);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_24107);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_24107);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24103 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24108 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24109 = heff_rec(8, shape_172_288_181_63_353_262_265_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), ((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), ((V)&g_app_2eheff_2emain_2ebuildCommands_str57), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_none)});
  V v_t_24110 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_flag), 1, (V[]){v_t_24109}));
  V v_x_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_ap), 2, (V[]){v_t_24108, v_t_24110}));
  V v_t_24112 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_pos), 1, (V[]){v_t_24112}));
  V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_fmt)}));
  V v_t_24115 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_ap), 2, (V[]){v_t_24114, v_x_24111}));
  return heff_tail(heff_get(v_s_24103, LBL_ap), 2, (V[]){v_t_24115, v_y_24113});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprojectCommands_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[39]; } g_app_2eheff_2emain_2eprojectCommands_str1 = {{0x80000000u, K_STR, 0}, 39, 39, {97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32, 68, 73, 82, 32, 40, 104, 101, 114, 101, 44, 32, 119, 105, 116, 104, 111, 117, 116, 32, 105, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {68, 73, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[108]; } g_app_2eheff_2emain_2eprojectCommands_str4 = {{0x80000000u, K_STR, 0}, 108, 108, {102, 101, 116, 99, 104, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 114, 101, 113, 117, 105, 114, 101, 115, 44, 32, 119, 114, 105, 116, 105, 110, 103, 32, 104, 101, 102, 102, 46, 115, 117, 109, 59, 32, 119, 105, 116, 104, 32, 80, 65, 84, 72, 44, 32, 114, 101, 113, 117, 105, 114, 101, 32, 105, 116, 32, 40, 97, 116, 32, 86, 69, 82, 83, 73, 79, 78, 44, 32, 101, 108, 115, 101, 32, 105, 116, 115, 32, 110, 101, 119, 101, 115, 116, 41, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_app_2eheff_2emain_2eprojectCommands_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {80, 65, 84, 72, 91, 64, 86, 69, 82, 83, 73, 79, 78, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2eprojectCommands_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[112]; } g_app_2eheff_2emain_2eprojectCommands_str7 = {{0x80000000u, K_STR, 0}, 112, 112, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 112, 114, 111, 103, 114, 97, 109, 115, 32, 40, 116, 104, 101, 32, 78, 65, 77, 69, 100, 32, 111, 110, 101, 115, 44, 32, 101, 108, 115, 101, 32, 97, 108, 108, 41, 58, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 109, 97, 105, 110, 46, 104, 102, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 97, 115, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 98, 117, 105, 108, 100, 46, 104, 102, 32, 115, 97, 121, 115, 44, 32, 116, 111, 32, 98, 105, 110, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprojectCommands_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 65, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_str9 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 117, 98, 108, 105, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_app_2eheff_2emain_2eprojectCommands_str10 = {{0x80000000u, K_STR, 0}, 56, 56, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 44, 32, 116, 104, 101, 110, 32, 116, 97, 103, 32, 105, 116, 32, 118, 86, 69, 82, 83, 73, 79, 78, 32, 97, 110, 100, 32, 112, 117, 115, 104, 32, 116, 104, 101, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprojectCommands_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {86, 69, 82, 83, 73, 79, 78}};
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2420 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2425 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2435 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str9), ((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){v_c_240})});
  V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, heff_tag(TAG_Cons, 2, (V[]){v_t_2425, v_t_2436})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2437});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_242 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    heff_drop(v_ws_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_243 = heff_field(v_ws_242, 0);
    heff_take(v_ws_242, 1ULL);
    return heff_tag(TAG_Just, 1, (V[]){v_w_243});
  }
  default: return heff_nomatch(v_ws_242);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_246 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_optional), NTAG(TAG_dirs)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_ap), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_init)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_249, v_x_248});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2412 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_ws_2412)) {
  case TAG_Nil: {
    heff_drop(v_ws_2412);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_2413 = heff_field(v_ws_2412, 0);
    heff_take(v_ws_2412, 1ULL);
    return heff_tag(TAG_Just, 1, (V[]){v_w_2413});
  }
  default: return heff_nomatch(v_ws_2412);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2416 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_optional), NTAG(TAG_none)});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_get)}));
  return heff_tail(heff_get(v_s_2411, LBL_ap), 2, (V[]){v_t_2419, v_x_2418});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2422 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), NTAG(TAG_many), NTAG(TAG_none)});
  V v_x_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2421), LBL_pos), 1, (V[]){v_t_2422}));
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2421), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_build)}));
  return heff_tail(heff_get(v_s_2421, LBL_ap), 2, (V[]){v_t_2424, v_x_2423});
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_x2_2427 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nil: {
    heff_drop(v_x2_2427);
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str11);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    heff_take(v_x2_2427, 1ULL);
    return v_x_2428;
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2426 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2426), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2431 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_one), NTAG(TAG_none)});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2426), LBL_pos), 1, (V[]){v_t_2431}));
  V v_x_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2426), LBL_ap), 2, (V[]){v_t_2430, v_t_2432}));
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2426), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_publish)}));
  return heff_tail(heff_get(v_s_2426, LBL_ap), 2, (V[]){v_t_2434, v_x_2433});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2etoolCommands_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 115, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_app_2eheff_2emain_2etoolCommands_str1 = {{0x80000000u, K_STR, 0}, 34, 34, {97, 32, 108, 97, 110, 103, 117, 97, 103, 101, 32, 115, 101, 114, 118, 101, 114, 44, 32, 111, 110, 32, 115, 116, 100, 105, 110, 47, 115, 116, 100, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2etoolCommands_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 76, 65, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 99, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 101, 118, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_t_245 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2410 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_False), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2420 = heff_rec(4, shape_190_63_289_12, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str6), ((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_False), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){v_c_240})});
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2421})});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_242 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_rest), NTAG(TAG_none)});
  V v_x_243 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_242}));
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_lsp)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_244, v_x_243});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), NTAG(TAG_many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_246), LBL_pos), 1, (V[]){v_t_247}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_246), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_dumpCore)}));
  return heff_tail(heff_get(v_s_246, LBL_ap), 2, (V[]){v_t_249, v_x_248});
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_x2_2412 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_x2_2412);
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str8);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take(v_x2_2412, 1ULL);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam3_clo)}));
  V v_t_2416 = heff_rec(3, shape_181_13_48, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_one), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_dumpEval)}));
  return heff_tail(heff_get(v_s_2411, LBL_ap), 2, (V[]){v_t_2419, v_x_2418});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam0, 2, 0};
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam3, 4, 0};

static V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_val;
static int g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_st;
static V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_init(void) {
  return heff_rec(8, shape_37_273_319_248_47_88_339_101, (V[]){((V)&g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_clo), ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam0_clo), ((V)&g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam3_clo), ((V)&g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_clo), ((V)&g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_clo), ((V)&g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_get(void) {
  if (g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_st == 2) return g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_val;
  if (g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_st = 1;
  g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_val = heff_tr(g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_init());
  g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_st = 2;
  return g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_val;
}
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_seed_240 = heff_dup(heff_env(self)[0]);
  V v_hd_248 = heff_dup(heff_env(self)[1]);
  V v_k_249 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2414;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    heff_drop(v_seed_240);
    v_t_2414 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
    break;
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_seed_240, 0);
    heff_take(v_seed_240, 1ULL);
    V v_x2_2412 = (g_prelude_2eparseInt(v_s_2411));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2412);
      v_t_2414 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take(v_x2_2412, 1ULL);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2415 = heff_rec(5, shape_330_91_203_319_320, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  V v_t_2416 = ({ V a_0 = v_t_2414; V a_1 = v_x_2410; V a_2 = v_t_2415; V r_ = (g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  return heff_tail(v_t_2416, 2, (V[]){v_hd_248, v_k_249});
}
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_seed_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam2, 1, 3, (V[]){v_seed_240, v_hd_248, v_k_249})});
}
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam0(V self, V *args) {
  V v_seed_240 = args[0];
  V v_given_241 = args[1];
  heff_drop(self);
  V v_c_247;
  switch (heff_tag_of(v_given_241)) {
  case TAG_Nil: {
    heff_drop(v_given_241);
    V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_str0)});
    V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
    v_c_247 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_t_243, NTAG(TAG_Nil)));
    break;
  }
  case TAG_Cons: {
    V v_t_246 = (g_prelude_2emap_24s828(v_given_241));
    v_c_247 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_t_246, NTAG(TAG_Nil)));
    break;
  }
  default: heff_nomatch(v_given_241);
  }
  return heff_clo(g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam1, 2, 2, (V[]){v_c_247, v_seed_240});
}
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_lam3(V self, V *args) {
  V v_file_2417 = args[0];
  V v_outPath_2418 = args[1];
  V v_name_2419 = args[2];
  V v_backend_2420 = args[3];
  heff_drop(self);
  return (g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111(heff_rec(4, shape_95_215_190_17, (V[]){v_file_2417, v_outPath_2418, v_name_2419, v_backend_2420})));
}
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam0, 3, 0};

static V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_val;
static int g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_st;
static V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_init(void) {
  return heff_rec(3, shape_174_70_71, (V[]){((V)&g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam0_clo), ((V)&g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_clo), ((V)&g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_clo)});
}
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_get(void) {
  if (g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_st == 2) return g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_val;
  if (g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_st = 1;
  g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_val = heff_tr(g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_init());
  g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_st = 2;
  return g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_val;
}
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2elsp_2eserve_24s961_24s1151_24s1190(v_x_243, v_hd_241, v_k_242));
}
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam0(V self, V *args) {
  V v_flags_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(self);
  heff_drop(v_flags_240);
  return (g_heff_2ecommands_2ehostNow_24s862_24s1008(heff_dup(v_hd_241), heff_clo(g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam3, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam4, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam6, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam7, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam8, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam9, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam11, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam10, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam1, 1, 0};

static V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_val;
static int g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_st;
static V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_init(void) {
  V v_t_241 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam0_clo)})});
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_241})});
  return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_242}), ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam1_clo));
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_get(void) {
  if (g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_st == 2) return g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_val;
  if (g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_st = 1;
  g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_val = heff_tr(g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_init());
  g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_st = 2;
  return g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_val;
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam0(V self, V *args) {
  V v_a_240 = args[0];
  heff_drop(self);
  return v_a_240;
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam2(V self, V *args) {
  V v_dir_244 = args[0];
  heff_drop(self);
  V v_t_246;
  switch (heff_tag_of(v_dir_244)) {
  case TAG_Nothing: {
    heff_drop(v_dir_244);
    v_t_246 = ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_dir_244, 0);
    heff_take(v_dir_244, 1ULL);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_dir_244);
  }
  return heff_tail(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_clo), 1, (V[]){v_t_246});
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(self);
  return heff_tail(v_k_2416, 1, (V[]){v_x_2415});
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2418 = heff_dup(heff_env(self)[0]);
  V v_k_2419 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_f_2418, 2, (V[]){v_x_2420, v_k_2419});
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam4(V self, V *args) {
  V v_m_2417 = args[0];
  V v_f_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(self);
  return heff_tail(v_m_2417, 1, (V[]){heff_clo(g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam5, 1, 2, (V[]){v_f_2418, v_k_2419})});
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam6(V self, V *args) {
  V v_p_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(self);
  return heff_perform(v_p_2421, v_k_2422);
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(self);
  return heff_tail(v_k_2424, 1, (V[]){v_x_2423});
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  heff_drop(self);
  heff_drop(v_x_2425);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  heff_drop(self);
  heff_drop(v_x_2430);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam11(V self, V *args) {
  V v_x_2439 = args[0];
  heff_drop(self);
  heff_drop(v_x_2439);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  heff_drop(self);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
  return heff_perform(v_t_2438, ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam11_clo));
}
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam1(V self, V *args) {
  V v_x_243 = args[0];
  heff_drop(self);
  V v_c_247 = heff_rec(3, shape_30_247_328, (V[]){heff_dup(g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_get()), heff_rec(4, shape_134_106_30_252, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam2_clo), ((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_clo), ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_clo), ((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_clo)}), heff_dup(g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_get())});
  V v_t_248 = (g_app_2eheff_2emain_2ebuildCommands(heff_get(heff_dup(v_c_247), LBL_build)));
  V v_t_249 = (g_app_2eheff_2emain_2eprojectCommands(heff_get(heff_dup(v_c_247), LBL_project)));
  V v_t_2410 = (g_app_2eheff_2emain_2etoolCommands(heff_get(v_c_247, LBL_tool)));
  V v_t_2411 = (g_prelude_2econcatList(v_t_249, v_t_2410));
  V v_t_2412 = (g_prelude_2econcatList(v_t_248, v_t_2411));
  V v_t_2413 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_str1); V a_1 = v_t_2412; V a_2 = v_x_243; V r_ = (g_std_2ecli_2ereadLine(a_0, a_1, a_2)); heff_drop(v_x_243); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_run: {
    V v_act_2414 = heff_field(v_t_2413, 0);
    heff_take(v_t_2413, 1ULL);
    return heff_tail(v_act_2414, 3, (V[]){heff_rec(3, shape_267_20_177, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam3_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam4_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam6_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam7_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam8_clo)});
  }
  case TAG_out: {
    V v_text_2426 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24out = heff_take_reuse(v_t_2413, 1ULL);
    V v_t_2427 = heff_tag(TAG_Write, 2, (V[]){v_text_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at(v_ru_24t_2413_24out, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    return heff_perform(v_t_2429, ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam9_clo));
  }
  case TAG_fail: {
    V v_text_2431 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24fail = heff_take_reuse(v_t_2413, 1ULL);
    V v_t_2432 = heff_tag(TAG_WriteErr, 2, (V[]){v_text_2431, NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_at(v_ru_24t_2413_24fail, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
    return heff_perform(v_t_2434, ((V)&g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_lam10_clo));
  }
  default: return heff_nomatch(v_t_2413);
  }
}