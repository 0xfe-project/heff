// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_Args 26338
#define TAG_Dirs 41877
#define TAG_Exit 20279
#define TAG_Fail 27959
#define TAG_Files 59123
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Out 27098
#define TAG_Rest 61983
#define TAG_Run 29975
#define TAG_Some 35657
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_doc 309170
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_explain 1070179126
#define LBL_file 9638467
#define LBL_flag 9641011
#define LBL_fmt 311047
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_going 299892244
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_malg 9839318
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_outPath 1272254166
#define LBL_pos 320718
#define LBL_project 2070030684
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_tests 311609915
#define LBL_tool 10061407
#define LBL_typeAt 1088337976
#define LBL_values 1123329101
#define LBL_version 583465758
static uint32_t shape_build__project__tool[] = {LBL_build, LBL_project, LBL_tool};
static uint32_t shape_check__run__tests__promote__compile__explain__typeAt__fmt[] = {LBL_check, LBL_run, LBL_tests, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt};
static uint32_t shape_file__outPath__name__backend[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend};
static uint32_t shape_init__get__build__install__publish[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_get(void);
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369(V);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_clo;
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843(V, V, V, V);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_clo;
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2ethrough_24s1918455300x553827868_get(void);
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273(V, V);
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_clo;
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015(V);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_clo;
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572(V);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_clo;
V g_heff_2ecommands_2edefaultSeed_get(void);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915(V);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_clo;
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381(V);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_clo;
V g_heff_2ecommands_2efmtAll_24s486731757x642131866(V, V, V, V, V);
V g_heff_2ecommands_2efmtAll_24s486731757x642131866_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtAll_24s486731757x642131866_clo;
V g_heff_2ecommands_2egetCmd_24s10896657x118494199(V, V, V);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetCmd_24s10896657x118494199_clo;
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488(V, V);
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo;
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128(V, V, V);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_entry(V self, V *a);
extern Clo g_heff_2ecommands_2einitCmd_24s1172576284x845887128_clo;
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314(V, V, V);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_entry(V self, V *a);
extern Clo g_heff_2ecommands_2einstallCmd_24s141488678x313111314_clo;
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604(V);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_clo;
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439(V);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_clo;
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376(V, V);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_clo;
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634(V, V, V);
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_clo;
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632(V);
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestFiles_24s195001740x1715824632_clo;
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838(V, V);
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_clo;
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198(V, V);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_clo;
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290(V, V);
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eversionCmd_24s622085897x237111290_clo;
V g_heff_2elsp_2eserve_24s1076151099x109167290(V, V, V);
V g_heff_2elsp_2eserve_24s1076151099x109167290_entry(V self, V *a);
extern Clo g_heff_2elsp_2eserve_24s1076151099x109167290_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2ecli_2ereadLine(V, V, V);
V g_std_2ecli_2ereadLine_entry(V self, V *a);
extern Clo g_std_2ecli_2ereadLine_clo;
V g_std_2eprogress_2edrawing_24s1430340132x541078361_get(void);
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ehf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};

static V g_app_2eheff_2emain_2ehf_val;
static int g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (g_app_2eheff_2emain_2ehf_st == 2) return g_app_2eheff_2emain_2ehf_val;
  if (g_app_2eheff_2emain_2ehf_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ehf_st = 1;
  g_app_2eheff_2emain_2ehf_val = heff_tr(g_app_2eheff_2emain_2ehf_init());
  g_app_2eheff_2emain_2ehf_st = 2;
  return g_app_2eheff_2emain_2ehf_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_app_2eheff_2emain_2ebuildCommands_str1 = {{0x80000000u, K_STR, 0}, 55, 55, {101, 108, 97, 98, 111, 114, 97, 116, 101, 32, 70, 73, 76, 69, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 59, 32, 112, 114, 105, 110, 116, 32, 105, 116, 115, 32, 105, 110, 116, 101, 114, 102, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_app_2eheff_2emain_2ebuildCommands_str5 = {{0x80000000u, K_STR, 0}, 47, 47, {114, 117, 110, 32, 70, 73, 76, 69, 39, 115, 32, 109, 97, 105, 110, 32, 119, 105, 116, 104, 32, 65, 82, 71, 83, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 102, 111, 114, 32, 78, 111, 100, 101, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {65, 82, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[211]; } g_app_2eheff_2emain_2ebuildCommands_str10 = {{0x80000000u, K_STR, 0}, 211, 211, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 39, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 40, 116, 104, 101, 32, 96, 45, 45, 32, 46, 46, 46, 96, 32, 108, 105, 110, 101, 115, 32, 117, 110, 100, 101, 114, 32, 116, 104, 101, 109, 41, 44, 32, 97, 110, 100, 32, 114, 117, 110, 32, 116, 104, 101, 32, 116, 101, 115, 116, 115, 32, 40, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 32, 111, 102, 32, 116, 121, 112, 101, 32, 96, 84, 101, 115, 116, 96, 44, 32, 108, 105, 98, 47, 99, 104, 101, 99, 107, 46, 104, 102, 41, 44, 32, 111, 102, 32, 116, 104, 101, 32, 70, 73, 76, 69, 115, 32, 40, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 39, 115, 32, 46, 104, 102, 32, 102, 105, 108, 101, 115, 41, 44, 32, 101, 108, 115, 101, 32, 111, 102, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 116, 101, 115, 116, 115, 32, 104, 101, 114, 101, 32, 40, 116, 101, 115, 116, 47, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 101, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[64]; } g_app_2eheff_2emain_2ebuildCommands_str14 = {{0x80000000u, K_STR, 0}, 64, 64, {116, 104, 101, 32, 115, 101, 101, 100, 32, 116, 104, 101, 32, 112, 114, 111, 112, 101, 114, 116, 105, 101, 115, 32, 100, 114, 97, 119, 32, 102, 114, 111, 109, 32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 115, 101, 101, 100, 44, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 114, 117, 110, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_app_2eheff_2emain_2ebuildCommands_str17 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 114, 105, 116, 101, 32, 101, 97, 99, 104, 32, 119, 97, 116, 99, 104, 39, 115, 32, 118, 97, 108, 117, 101, 32, 117, 110, 100, 101, 114, 32, 105, 116, 32, 97, 115, 32, 105, 116, 115, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 109, 112, 105, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[173]; } g_app_2eheff_2emain_2ebuildCommands_str21 = {{0x80000000u, K_STR, 0}, 173, 173, {70, 73, 76, 69, 32, 99, 111, 109, 112, 105, 108, 101, 100, 44, 32, 98, 121, 32, 77, 79, 68, 69, 58, 32, 101, 115, 109, 32, 40, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 41, 44, 32, 112, 97, 103, 101, 32, 40, 97, 32, 115, 99, 114, 105, 112, 116, 32, 114, 117, 110, 110, 105, 110, 103, 32, 116, 104, 101, 32, 97, 112, 112, 32, 78, 65, 77, 69, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 41, 44, 32, 110, 111, 100, 101, 32, 40, 97, 32, 78, 111, 100, 101, 46, 106, 115, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 41, 44, 32, 99, 32, 40, 97, 32, 67, 32, 112, 114, 111, 103, 114, 97, 109, 32, 114, 117, 110, 110, 105, 110, 103, 32, 78, 65, 77, 69, 44, 32, 102, 111, 114, 32, 96, 122, 105, 103, 32, 99, 99, 96, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {79, 85, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str28 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 65, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_str29 = {{0x80000000u, K_STR, 0}, 32, 32, {116, 104, 101, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 32, 114, 117, 110, 32, 40, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str33 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str35 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str36 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str37 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {98, 97, 99, 107, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str40 = {{0x80000000u, K_STR, 0}, 4, 4, {77, 79, 68, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_app_2eheff_2emain_2ebuildCommands_str41 = {{0x80000000u, K_STR, 0}, 22, 22, {119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 116, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {101, 120, 112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_str44 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 104, 101, 32, 101, 108, 97, 98, 111, 114, 97, 116, 105, 111, 110, 32, 116, 114, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str45 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str46 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2ebuildCommands_str47 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 121, 112, 101, 45, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[67]; } g_app_2eheff_2emain_2ebuildCommands_str48 = {{0x80000000u, K_STR, 0}, 67, 67, {119, 104, 97, 116, 32, 116, 104, 101, 32, 110, 97, 109, 101, 32, 97, 116, 32, 101, 97, 99, 104, 32, 79, 70, 70, 83, 69, 84, 32, 114, 101, 115, 111, 108, 118, 101, 100, 32, 116, 111, 44, 32, 97, 110, 100, 32, 105, 116, 115, 32, 116, 121, 112, 101, 44, 32, 97, 32, 108, 105, 110, 101, 32, 101, 97, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str49 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_app_2eheff_2emain_2ebuildCommands_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {79, 70, 70, 83, 69, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2ebuildCommands_str52 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 109, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_app_2eheff_2emain_2ebuildCommands_str53 = {{0x80000000u, K_STR, 0}, 21, 21, {102, 111, 114, 109, 97, 116, 32, 70, 73, 76, 69, 115, 32, 105, 110, 32, 112, 108, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2ebuildCommands_str54 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2ebuildCommands_str56 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_app_2eheff_2emain_2ebuildCommands_str57 = {{0x80000000u, K_STR, 0}, 32, 32, {111, 110, 108, 121, 32, 115, 97, 121, 32, 119, 104, 105, 99, 104, 32, 97, 114, 101, 32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2ebuildCommands_str58 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2423 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2433 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2443 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2479 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2489 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24102 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_24116 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str52), ((V)&g_app_2eheff_2emain_2ebuildCommands_str53), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){v_c_240})});
  V v_t_24117 = heff_tag(TAG_Cons, 2, (V[]){v_t_24116, NTAG(TAG_Nil)});
  V v_t_24118 = heff_tag(TAG_Cons, 2, (V[]){v_t_2489, heff_tag(TAG_Cons, 2, (V[]){v_t_24102, v_t_24117})});
  V v_t_24119 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, heff_tag(TAG_Cons, 2, (V[]){v_t_2479, v_t_24118})});
  V v_t_24120 = heff_tag(TAG_Cons, 2, (V[]){v_t_2423, heff_tag(TAG_Cons, 2, (V[]){v_t_2433, v_t_24119})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_24120});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_242 = args[0];
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 2);
    return v_x_243;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_246 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_ap), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_check)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_249, v_x_248});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2412 = args[0];
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 2);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2416 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2419}));
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_run)}));
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2421, v_x_2418}));
  return heff_tail(heff_get(v_s_2411, LBL_ap), 2, (V[]){v_t_2422, v_y_2420});
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2426 = heff_rec(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_flag), 1, (V[]){v_t_2426}));
  V v_x_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_ap), 2, (V[]){v_t_2425, v_t_2427}));
  V v_t_2429 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_pos), 1, (V[]){v_t_2429}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_tests)}));
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2424), LBL_ap), 2, (V[]){v_t_2431, v_x_2428}));
  return heff_tail(heff_get(v_s_2424, LBL_ap), 2, (V[]){v_t_2432, v_y_2430});
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_x2_2435 = args[0];
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str18);
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    heff_take_n(v_x2_2435, 1ULL, 2);
    return v_x_2436;
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2439 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_pos), 1, (V[]){v_t_2439}));
  V v_x_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_ap), 2, (V[]){v_t_2438, v_t_2440}));
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2434), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_promote)}));
  return heff_tail(heff_get(v_s_2434, LBL_ap), 2, (V[]){v_t_2442, v_x_2441});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_x2_2445 = args[0];
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str22);
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    heff_take_n(v_x2_2445, 1ULL, 2);
    return v_x_2446;
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_x2_2452 = args[0];
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str24);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take_n(v_x2_2452, 1ULL, 2);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_vs_2463 = args[0];
  V v_x2_2464 = ({ V a_0 = v_vs_2463; V r_ = (g_std_2ecli_2elastS(a_0)); heff_drop(v_vs_2463); r_; });
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_Nothing: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str30);
  }
  case TAG_Just: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    heff_take_n(v_x2_2464, 1ULL, 1);
    return v_x_2465;
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_2449 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_pos), 1, (V[]){v_t_2449}));
  V v_x_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2448, v_t_2450}));
  V v_t_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam9_clo)}));
  V v_t_2456 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str25), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_pos), 1, (V[]){v_t_2456}));
  V v_y_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2460 = heff_rec(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str26), ((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_flag), 1, (V[]){v_t_2460}));
  V v_z_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2459, v_t_2461}));
  V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_2467 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Nil)});
  V v_t_2468 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str33), v_t_2467})});
  V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), NTAG(TAG_Nil)});
  V v_t_2470 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str35), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str36), v_t_2469})});
  V v_t_2471 = heff_tag(TAG_Among, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str37), v_t_2470})});
  V v_t_2472 = heff_rec(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), heff_tag(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str42), v_t_2468}), NTAG(TAG_False), NTAG(TAG_True), v_t_2471});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_flag), 1, (V[]){v_t_2472}));
  V v_w_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2466, v_t_2473}));
  V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_compile)}));
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2475, v_x_2451}));
  V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2476, v_y_2458}));
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2444), LBL_ap), 2, (V[]){v_t_2477, v_z_2462}));
  return heff_tail(heff_get(v_s_2444, LBL_ap), 2, (V[]){v_t_2478, v_w_2474});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_2481 = args[0];
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str45);
  }
  case TAG_Cons: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    heff_take_n(v_x2_2481, 1ULL, 2);
    return v_x_2482;
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_2480 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_2485 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str46), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_pos), 1, (V[]){v_t_2485}));
  V v_x_2487 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_ap), 2, (V[]){v_t_2484, v_t_2486}));
  V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2480), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_explain)}));
  return heff_tail(heff_get(v_s_2480, LBL_ap), 2, (V[]){v_t_2488, v_x_2487});
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_x2_2491 = args[0];
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str49);
  }
  case TAG_Cons: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    heff_take_n(v_x2_2491, 1ULL, 2);
    return v_x_2492;
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_s_2490 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_2495 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2496 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_pos), 1, (V[]){v_t_2495}));
  V v_x_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_ap), 2, (V[]){v_t_2494, v_t_2496}));
  V v_t_2498 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str51), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_2499 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_pos), 1, (V[]){v_t_2498}));
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_typeAt)}));
  V v_t_24101 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2490), LBL_ap), 2, (V[]){v_t_24100, v_x_2497}));
  return heff_tail(heff_get(v_s_2490, LBL_ap), 2, (V[]){v_t_24101, v_y_2499});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_vs_24104 = args[0];
  V v_x1_24107;
  switch (heff_tag_of(v_vs_24104)) {
  case TAG_Nil: {
    v_x1_24107 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24104, 0ULL, 2);
    v_x1_24107 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_vs_24104);
  }
  switch (heff_tag_of(v_x1_24107)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_24107);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24103 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24108 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24109 = heff_rec(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), ((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), ((V)&g_app_2eheff_2emain_2ebuildCommands_str57), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24110 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_flag), 1, (V[]){v_t_24109}));
  V v_x_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_ap), 2, (V[]){v_t_24108, v_t_24110}));
  V v_t_24112 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_pos), 1, (V[]){v_t_24112}));
  V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_fmt)}));
  V v_t_24115 = heff_tr(heff_apply(heff_get(heff_dup(v_s_24103), LBL_ap), 2, (V[]){v_t_24114, v_x_24111}));
  return heff_tail(heff_get(v_s_24103, LBL_ap), 2, (V[]){v_t_24115, v_y_24113});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprojectCommands_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[39]; } g_app_2eheff_2emain_2eprojectCommands_str1 = {{0x80000000u, K_STR, 0}, 39, 39, {97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32, 68, 73, 82, 32, 40, 104, 101, 114, 101, 44, 32, 119, 105, 116, 104, 111, 117, 116, 32, 105, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {68, 73, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[108]; } g_app_2eheff_2emain_2eprojectCommands_str4 = {{0x80000000u, K_STR, 0}, 108, 108, {102, 101, 116, 99, 104, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 114, 101, 113, 117, 105, 114, 101, 115, 44, 32, 119, 114, 105, 116, 105, 110, 103, 32, 104, 101, 102, 102, 46, 115, 117, 109, 59, 32, 119, 105, 116, 104, 32, 80, 65, 84, 72, 44, 32, 114, 101, 113, 117, 105, 114, 101, 32, 105, 116, 32, 40, 97, 116, 32, 86, 69, 82, 83, 73, 79, 78, 44, 32, 101, 108, 115, 101, 32, 105, 116, 115, 32, 110, 101, 119, 101, 115, 116, 41, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_app_2eheff_2emain_2eprojectCommands_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {80, 65, 84, 72, 91, 64, 86, 69, 82, 83, 73, 79, 78, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2eprojectCommands_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[193]; } g_app_2eheff_2emain_2eprojectCommands_str7 = {{0x80000000u, K_STR, 0}, 193, 193, {116, 104, 101, 32, 119, 104, 111, 108, 101, 32, 112, 114, 111, 106, 101, 99, 116, 58, 32, 101, 118, 101, 114, 121, 32, 109, 111, 100, 117, 108, 101, 32, 111, 102, 32, 115, 114, 99, 47, 32, 99, 104, 101, 99, 107, 101, 100, 44, 32, 116, 104, 101, 110, 32, 101, 118, 101, 114, 121, 32, 112, 114, 111, 103, 114, 97, 109, 44, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 109, 97, 105, 110, 46, 104, 102, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 97, 115, 32, 97, 112, 112, 47, 78, 65, 77, 69, 47, 98, 117, 105, 108, 100, 46, 104, 102, 32, 115, 97, 121, 115, 44, 32, 116, 111, 32, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47, 32, 40, 67, 32, 98, 121, 32, 122, 105, 103, 32, 97, 116, 32, 45, 79, 49, 58, 32, 98, 117, 105, 108, 116, 32, 113, 117, 105, 99, 107, 108, 121, 44, 32, 110, 111, 116, 32, 116, 111, 32, 114, 117, 110, 32, 105, 116, 115, 32, 102, 97, 115, 116, 101, 115, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 115, 116, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[264]; } g_app_2eheff_2emain_2eprojectCommands_str9 = {{0x80000000u, K_STR, 0}, 264, 264, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 97, 116, 32, 68, 73, 82, 32, 40, 104, 101, 114, 101, 44, 32, 119, 105, 116, 104, 111, 117, 116, 32, 105, 116, 41, 32, 98, 117, 105, 108, 116, 32, 97, 115, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 44, 32, 98, 117, 116, 32, 116, 111, 32, 114, 117, 110, 32, 105, 116, 115, 32, 102, 97, 115, 116, 101, 115, 116, 32, 40, 67, 32, 98, 121, 32, 122, 105, 103, 32, 97, 116, 32, 45, 79, 50, 41, 44, 32, 105, 116, 115, 32, 112, 114, 111, 103, 114, 97, 109, 115, 32, 105, 110, 116, 111, 32, 116, 104, 101, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 39, 115, 32, 98, 105, 110, 47, 32, 40, 72, 69, 70, 70, 95, 72, 79, 77, 69, 47, 98, 105, 110, 44, 32, 101, 108, 115, 101, 32, 126, 47, 46, 104, 101, 102, 102, 47, 98, 105, 110, 41, 44, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 116, 104, 101, 121, 32, 115, 104, 105, 112, 32, 40, 116, 104, 101, 105, 114, 32, 98, 117, 105, 108, 100, 46, 104, 102, 39, 115, 32, 96, 115, 104, 105, 112, 115, 96, 41, 32, 105, 110, 116, 111, 32, 116, 104, 101, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 44, 32, 98, 101, 115, 105, 100, 101, 32, 98, 105, 110, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2eprojectCommands_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {68, 73, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_str11 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 117, 98, 108, 105, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_app_2eheff_2emain_2eprojectCommands_str12 = {{0x80000000u, K_STR, 0}, 56, 56, {99, 104, 101, 99, 107, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 44, 32, 116, 104, 101, 110, 32, 116, 97, 103, 32, 105, 116, 32, 118, 86, 69, 82, 83, 73, 79, 78, 32, 97, 110, 100, 32, 112, 117, 115, 104, 32, 116, 104, 101, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprojectCommands_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2eprojectCommands_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {86, 69, 82, 83, 73, 79, 78}};
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_t_2410 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2420 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2432 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2442 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){v_c_240})});
  V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_tag(TAG_Cons, 2, (V[]){v_t_2432, v_t_2443})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, heff_tag(TAG_Cons, 2, (V[]){v_t_2420, v_t_2444})});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_242 = args[0];
  switch (heff_tag_of(v_ws_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_243 = heff_field(v_ws_242, 0);
    heff_take_n(v_ws_242, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_243});
  }
  default: return heff_nomatch(v_ws_242);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_246 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_246}));
  V v_x_248 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_ap), 2, (V[]){v_t_245, v_t_247}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_init)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_249, v_x_248});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2412 = args[0];
  switch (heff_tag_of(v_ws_2412)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_2413 = heff_field(v_ws_2412, 0);
    heff_take_n(v_ws_2412, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_2413});
  }
  default: return heff_nomatch(v_ws_2412);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2416 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_pos), 1, (V[]){v_t_2416}));
  V v_x_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_ap), 2, (V[]){v_t_2415, v_t_2417}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2411), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_get)}));
  return heff_tail(heff_get(v_s_2411, LBL_ap), 2, (V[]){v_t_2419, v_x_2418});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_s_2421, LBL_give);
  args[0] = heff_get(v_c_240, LBL_build);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag(TAG_Just, 1, (V[]){v_w_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2428 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_pos), 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_ap), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2423), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_install)}));
  return heff_tail(heff_get(v_s_2423, LBL_ap), 2, (V[]){v_t_2431, v_x_2430});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2434 = args[0];
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    heff_take_n(v_x2_2434, 1ULL, 2);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2438 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_pos), 1, (V[]){v_t_2438}));
  V v_x_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_ap), 2, (V[]){v_t_2437, v_t_2439}));
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2433), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_publish)}));
  return heff_tail(heff_get(v_s_2433, LBL_ap), 2, (V[]){v_t_2441, v_x_2440});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_app_2eheff_2emain_2etoolCommands_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 115, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_app_2eheff_2emain_2etoolCommands_str1 = {{0x80000000u, K_STR, 0}, 34, 34, {97, 32, 108, 97, 110, 103, 117, 97, 103, 101, 32, 115, 101, 114, 118, 101, 114, 44, 32, 111, 110, 32, 115, 116, 100, 105, 110, 47, 115, 116, 100, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_app_2eheff_2emain_2etoolCommands_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 76, 65, 71, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_app_2eheff_2emain_2etoolCommands_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {118, 101, 114, 115, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_app_2eheff_2emain_2etoolCommands_str4 = {{0x80000000u, K_STR, 0}, 68, 68, {119, 104, 105, 99, 104, 32, 104, 101, 102, 102, 32, 116, 104, 105, 115, 32, 105, 115, 58, 32, 105, 116, 115, 32, 118, 101, 114, 115, 105, 111, 110, 44, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 116, 32, 99, 97, 109, 101, 32, 119, 105, 116, 104, 32, 115, 97, 121, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 99, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_app_2eheff_2emain_2etoolCommands_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 117, 109, 112, 45, 101, 118, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2etoolCommands_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2etoolCommands_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {70, 73, 76, 69}};
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_t_245 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_247 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2412 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){heff_dup(v_c_240)})});
  V v_t_2422 = heff_rec(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_False), heff_clo(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){v_c_240})});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, heff_tag(TAG_Cons, 2, (V[]){v_t_2412, v_t_2423})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_t_2424});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_243 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_pos), 1, (V[]){v_t_242}));
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_s_241), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_lsp)}));
  return heff_tail(heff_get(v_s_241, LBL_ap), 2, (V[]){v_t_244, v_x_243});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_s_246, LBL_give);
  args[0] = heff_get(v_c_240, LBL_version);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_s_248), LBL_pos), 1, (V[]){v_t_249}));
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_s_248), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_dumpCore)}));
  return heff_tail(heff_get(v_s_248, LBL_ap), 2, (V[]){v_t_2411, v_x_2410});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2414 = args[0];
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str10);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2413), LBL_give), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2418 = heff_rec(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2413), LBL_pos), 1, (V[]){v_t_2418}));
  V v_x_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2413), LBL_ap), 2, (V[]){v_t_2417, v_t_2419}));
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_s_2413), LBL_give), 1, (V[]){heff_get(v_c_240, LBL_dumpEval)}));
  return heff_tail(heff_get(v_s_2413, LBL_ap), 2, (V[]){v_t_2421, v_x_2420});
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam0, 2, 0};
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam3, 4, 0};
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam4, 2, 0};

static V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_val;
static int g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_st;
static V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_init(void) {
  return heff_rec(8, shape_check__run__tests__promote__compile__explain__typeAt__fmt, (V[]){((V)&g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_clo), ((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam0_clo), ((V)&g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam3_clo), ((V)&g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_clo), ((V)&g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam4_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_get(void) {
  if (g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_st == 2) return g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_val;
  if (g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_st == 1) heff_fail("defined by itself");
  g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_st = 1;
  g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_val = heff_tr(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_init());
  g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_st = 2;
  return g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_val;
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    V v_x2_247 = (g_prelude_2eparseInt(v_s_246));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_dup(g_heff_2ecommands_2edefaultSeed_get());
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2410 = (g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838(v_t_249, v_x_245));
  return heff_tail(v_t_2410, 2, (V[]){v_hd_243, v_k_244});
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam2, 1, 3, (V[]){v_seed_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam0(V self, V *args) {
  V v_seed_240 = args[0];
  V v_given_241 = args[1];
  V v_c_242 = (g_heff_2ecommands_2etestFiles_24s195001740x1715824632(v_given_241));
  return heff_clo(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam1, 2, 2, (V[]){v_c_242, v_seed_240});
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam3(V self, V *args) {
  V v_file_2411 = args[0];
  V v_outPath_2412 = args[1];
  V v_name_2413 = args[2];
  V v_backend_2414 = args[3];
  return (g_heff_2ecommands_2ecompileTo_24s1529513209x792324572(heff_rec(4, shape_file__outPath__name__backend, (V[]){v_file_2411, v_outPath_2412, v_name_2413, v_backend_2414})));
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_intLt(MK_INT(0LL), v_x_2420);
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2425}));
    return heff_tail(heff_get(v_hd_2418, LBL_bind), 2, (V[]){v_t_2426, v_k_2419});
  }
  case TAG_False: {
    heff_drop(v_hd_2418);
    V f_ = v_k_2419;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam6, 1, 2, (V[]){v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam4(V self, V *args) {
  V v_check_2415 = args[0];
  V v_files_2416 = args[1];
  V v_c_2417 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2efmtAll_24s486731757x642131866_clo), 3, (V[]){v_check_2415, v_files_2416, MK_INT(0LL)}));
  return heff_clo(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_lam5, 2, 1, (V[]){v_c_2417});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam3, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam6(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam4, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam9(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam8(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_entry, 4, 0};

V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843(V v_lit_240, V v_k_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam1, 1, 4, (V[]){v_lit_240, v_k_241, v_hd_242, v_k_243})});
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s1810749153x72010843(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam0(V self, V *args) {
  V v_a_244 = args[0];
  return v_a_244;
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam2(V self, V *args) {
  V v_dir_2410 = args[0];
  V v_t_2412;
  switch (heff_tag_of(v_dir_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_dir_2410, 0);
    heff_take_n(v_dir_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_dir_2410);
  }
  V f_ = ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_clo);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam3(V self, V *args) {
  V v_dir_2413 = args[0];
  V v_t_2415;
  switch (heff_tag_of(v_dir_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_dir_2413, 0);
    heff_take_n(v_dir_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_dir_2413);
  }
  V f_ = ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_clo);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2eserve_24s1076151099x109167290(v_x_2420, v_hd_2418, v_k_2419));
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam6, 1, 2, (V[]){v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam4(V self, V *args) {
  V v_flags_2416 = args[0];
  heff_drop(v_flags_2416);
  V v_c_2417 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  return heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam5, 2, 1, (V[]){v_c_2417});
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436 = heff_rec(2, shape_next__going, (V[]){v_lit_240, NTAG(TAG_Nil)});
  return heff_tail(v_k_241, 4, (V[]){v_x_2435, v_t_2436, v_hd_242, v_k_243});
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2448 = heff_rec(2, shape_next__going, (V[]){v_lit_240, NTAG(TAG_Nil)});
  return heff_tail(v_k_241, 4, (V[]){v_x_2447, v_t_2448, v_hd_242, v_k_243});
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2445})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2446, heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam9, 1, 4, (V[]){v_lit_240, v_k_241, v_hd_242, v_k_243})});
}
V g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2421 = heff_rec(3, shape_build__project__tool, (V[]){heff_dup(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_get()), heff_rec(5, shape_init__get__build__install__publish, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam2_clo), ((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_clo), ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam3_clo), ((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_clo)}), heff_rec(4, shape_lsp__version__dumpCore__dumpEval, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam4_clo), ((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_clo), ((V)&g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_clo), ((V)&g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_clo)})});
  V v_t_2422 = (g_app_2eheff_2emain_2ebuildCommands(heff_get(heff_dup(v_c_2421), LBL_build)));
  V v_t_2423 = (g_app_2eheff_2emain_2eprojectCommands(heff_get(heff_dup(v_c_2421), LBL_project)));
  V v_t_2424 = (g_app_2eheff_2emain_2etoolCommands(heff_get(v_c_2421, LBL_tool)));
  V v_t_2425 = (g_prelude_2econcatList(v_t_2423, v_t_2424));
  V v_t_2426 = (g_prelude_2econcatList(v_t_2422, v_t_2425));
  V v_t_2427 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_str2); V a_1 = v_t_2426; V a_2 = v_x_249; V r_ = (g_std_2ecli_2ereadLine(a_0, a_1, a_2)); heff_drop(v_x_249); r_; });
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Run: {
    V v_act_2428 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    V v_t_2429 = heff_rec(2, shape_next__going, (V[]){v_lit_240, NTAG(TAG_Nil)});
    return heff_tail(v_act_2428, 5, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s1430340132x541078361_get()), v_k_241, v_t_2429, v_hd_242, v_k_243});
  }
  case TAG_Out: {
    V v_text_2430 = heff_field(v_t_2427, 0);
    V v_ru_24t_2427_24Out = heff_take_reuse_n(v_t_2427, 1ULL, 1);
    V v_t_2431 = heff_tag(TAG_Write, 2, (V[]){v_text_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_at(v_ru_24t_2427_24Out, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})}));
    return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2434, heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam7, 1, 4, (V[]){v_lit_240, v_k_241, v_hd_242, v_k_243})});
  }
  case TAG_Fail: {
    V v_text_2437 = heff_field(v_t_2427, 0);
    V v_ru_24t_2427_24Fail = heff_take_reuse_n(v_t_2427, 1ULL, 1);
    V v_t_2438 = heff_tag(TAG_WriteErr, 2, (V[]){v_text_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_at(v_ru_24t_2427_24Fail, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})}));
    return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2441, heff_clo(g_app_2eheff_2emain_2eprogram_24s1810749153x72010843_lam8, 1, 4, (V[]){v_hd_242, v_lit_240, v_k_241, v_k_243})});
  }
  default: return heff_nomatch(v_t_2427);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam3, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam6(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam4, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam7, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam9(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam8, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam10, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam11, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam12, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam14, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam16(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam15, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam17, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam18, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam19(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam19_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam19, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam13(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam22(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam22_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam22, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam24(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam23(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam23_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam23, 3, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam25(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam25_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam25, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam26(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam26_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam26, 2, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam27(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam27_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam27, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam21(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam20(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_entry, 1, 0};

V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369(V v_k_240) {
top: ;
  V v_t_242 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam0_clo)})});
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_242})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  return heff_perform(v_t_244, heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam1, 1, 1, (V[]){v_k_240}));
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s1364294205x625005369(a[0]);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam0(V self, V *args) {
  V v_a_241 = args[0];
  return v_a_241;
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam2(V self, V *args) {
  V v_dir_246 = args[0];
  V v_t_248;
  switch (heff_tag_of(v_dir_246)) {
  case TAG_Nothing: {
    v_t_248 = ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str0);
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_dir_246, 0);
    heff_take_n(v_dir_246, 1ULL, 1);
    v_t_248 = v_x_247;
    break;
  }
  default: heff_nomatch(v_dir_246);
  }
  V f_ = ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_clo);
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam3(V self, V *args) {
  V v_dir_249 = args[0];
  V v_t_2411;
  switch (heff_tag_of(v_dir_249)) {
  case TAG_Nothing: {
    v_t_2411 = ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_dir_249, 0);
    heff_take_n(v_dir_249, 1ULL, 1);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_dir_249);
  }
  V f_ = ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_clo);
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2eserve_24s1076151099x109167290(v_x_2416, v_hd_2414, v_k_2415));
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam6, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam4(V self, V *args) {
  V v_flags_2412 = args[0];
  heff_drop(v_flags_2412);
  V v_c_2413 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  return heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam5, 2, 1, (V[]){v_c_2413});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam7(V self, V *args) {
  V v_a_2425 = args[0];
  V v_a_2426 = args[1];
  V f_ = v_a_2426;
  args[0] = v_a_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam9(V self, V *args) {
  V v_a_2430 = args[0];
  V v_a_2428 = heff_env(self)[0];
  V v_a_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_a_2428, 2, (V[]){v_a_2430, v_a_2429});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam8(V self, V *args) {
  V v_a_2427 = args[0];
  V v_a_2428 = args[1];
  V v_a_2429 = args[2];
  V f_ = v_a_2427;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam9, 1, 2, (V[]){v_a_2428, v_a_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam10(V self, V *args) {
  V v_a_2431 = args[0];
  V v_a_2432 = args[1];
  return heff_perform(v_a_2431, v_a_2432);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam11(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2434 = args[1];
  V f_ = v_a_2434;
  args[0] = v_a_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam12(V self, V *args) {
  V v_a_2435 = args[0];
  heff_drop(v_a_2435);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam14(V self, V *args) {
  V v_a_2441 = args[0];
  V v_a_2442 = args[1];
  V f_ = v_a_2442;
  args[0] = v_a_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam16(V self, V *args) {
  V v_a_2446 = args[0];
  V v_a_2444 = heff_env(self)[0];
  V v_a_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_a_2444, 2, (V[]){v_a_2446, v_a_2445});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam15(V self, V *args) {
  V v_a_2443 = args[0];
  V v_a_2444 = args[1];
  V v_a_2445 = args[2];
  V f_ = v_a_2443;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam16, 1, 2, (V[]){v_a_2444, v_a_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam17(V self, V *args) {
  V v_a_2447 = args[0];
  V v_a_2448 = args[1];
  return heff_perform(v_a_2447, v_a_2448);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam18(V self, V *args) {
  V v_a_2449 = args[0];
  V v_a_2450 = args[1];
  V f_ = v_a_2450;
  args[0] = v_a_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam19(V self, V *args) {
  V v_a_2451 = args[0];
  heff_drop(v_a_2451);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam13(V self, V *args) {
  V v_a_2440 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_k_240, 4, (V[]){v_a_2440, heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam14_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam15_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam17_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam18_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam19_clo)});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam22(V self, V *args) {
  V v_a_2461 = args[0];
  V v_a_2462 = args[1];
  V f_ = v_a_2462;
  args[0] = v_a_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam24(V self, V *args) {
  V v_a_2466 = args[0];
  V v_a_2464 = heff_env(self)[0];
  V v_a_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_a_2464, 2, (V[]){v_a_2466, v_a_2465});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam23(V self, V *args) {
  V v_a_2463 = args[0];
  V v_a_2464 = args[1];
  V v_a_2465 = args[2];
  V f_ = v_a_2463;
  args[0] = heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam24, 1, 2, (V[]){v_a_2464, v_a_2465});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam25(V self, V *args) {
  V v_a_2467 = args[0];
  V v_a_2468 = args[1];
  return heff_perform(v_a_2467, v_a_2468);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam26(V self, V *args) {
  V v_a_2469 = args[0];
  V v_a_2470 = args[1];
  V f_ = v_a_2470;
  args[0] = v_a_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam27(V self, V *args) {
  V v_a_2471 = args[0];
  heff_drop(v_a_2471);
  return NTAG(TAG_MkUnit);
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam21(V self, V *args) {
  V v_a_2460 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_k_240, 4, (V[]){v_a_2460, heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam22_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam23_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam25_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam26_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam27_clo)});
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam20(V self, V *args) {
  V v_a_2456 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2456);
  V v_t_2457 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2458})});
  return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2459}), heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam21, 1, 1, (V[]){v_k_240}));
}
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2417 = heff_rec(3, shape_build__project__tool, (V[]){heff_dup(g_app_2eheff_2emain_2ebuild_24s675957751x1496079979_get()), heff_rec(5, shape_init__get__build__install__publish, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam2_clo), ((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_clo), ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam3_clo), ((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_clo)}), heff_rec(4, shape_lsp__version__dumpCore__dumpEval, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam4_clo), ((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_clo), ((V)&g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_clo), ((V)&g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_clo)})});
  V v_t_2418 = (g_app_2eheff_2emain_2ebuildCommands(heff_get(heff_dup(v_c_2417), LBL_build)));
  V v_t_2419 = (g_app_2eheff_2emain_2eprojectCommands(heff_get(heff_dup(v_c_2417), LBL_project)));
  V v_t_2420 = (g_app_2eheff_2emain_2etoolCommands(heff_get(v_c_2417, LBL_tool)));
  V v_t_2421 = (g_prelude_2econcatList(v_t_2419, v_t_2420));
  V v_t_2422 = (g_prelude_2econcatList(v_t_2418, v_t_2421));
  V v_t_2423 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_str2); V a_1 = v_t_2422; V a_2 = v_a_245; V r_ = (g_std_2ecli_2ereadLine(a_0, a_1, a_2)); heff_drop(v_a_245); r_; });
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Run: {
    V v_act_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    return heff_tail(v_act_2424, 5, (V[]){heff_dup(g_co_2ethrough_24s1918455300x553827868_get()), v_k_240, heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam7_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam8_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam10_clo)}), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam11_clo), ((V)&g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam12_clo)});
  }
  case TAG_Out: {
    V v_text_2436 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Out = heff_take_reuse_n(v_t_2423, 1ULL, 1);
    V v_t_2437 = heff_tag(TAG_Write, 2, (V[]){v_text_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at(v_ru_24t_2423_24Out, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2439}), heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam13, 1, 1, (V[]){v_k_240}));
  }
  case TAG_Fail: {
    V v_text_2452 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Fail = heff_take_reuse_n(v_t_2423, 1ULL, 1);
    V v_t_2453 = heff_tag(TAG_WriteErr, 2, (V[]){v_text_2452, NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_at(v_ru_24t_2423_24Fail, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
    return heff_perform(heff_tag(TAG_InL, 1, (V[]){v_t_2455}), heff_clo(g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_lam20, 1, 1, (V[]){v_k_240}));
  }
  default: return heff_nomatch(v_t_2423);
  }
}