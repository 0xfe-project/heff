// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_var 326049
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_clo;
V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_clo;
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
HeffT3 g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2eeffectFits(V, V, V, V, V);
V g_heff_2eelab_2erules_2eeffectFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectFits_clo;
V g_heff_2eelab_2erules_2eerrorOf_24rec0_get(void);
HeffT2 g_heff_2eelab_2erules_2eescapeLevel_24cpr(V);
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2einArguments(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einArguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einArguments_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
HeffT3 g_heff_2eelab_2erules_2ementionsLocal_24cpr(V);
V g_heff_2eelab_2erules_2ementionsTermF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2enamesFor_24dps(V, V);
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo;
V g_heff_2eelab_2erules_2eplainMismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplainMismatch_clo;
HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordOf_24generate0(V, V, V, V);
V g_heff_2eelab_2erules_2erecordOf_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_24generate0_clo;
V g_heff_2eelab_2erules_2erecordOf_24map0(V, V, V);
V g_heff_2eelab_2erules_2erecordOf_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_24map0_clo;
V g_heff_2eelab_2erules_2eresultAfter(V, V, V, V);
V g_heff_2eelab_2erules_2eresultAfter_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresultAfter_clo;
V g_heff_2eelab_2erules_2eselfAdvance_24map0(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_24map0_clo;
V g_heff_2eelab_2erules_2estandsFor_get(void);
V g_heff_2eelab_2erules_2etermParts(V, V);
V g_heff_2eelab_2erules_2etermParts_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etermParts_clo;
V g_heff_2eelab_2erules_2etermSizeGo(V, V, V);
V g_heff_2eelab_2erules_2etermSizeGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etermSizeGo_clo;
V g_heff_2eelab_2erules_2etooLarge(V, V, V, V, V);
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooLarge_clo;
V g_heff_2eelab_2erules_2etooLarge_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2etooLarge_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooLarge_24tok1_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2eundoneTo_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2eundoneTo_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eundoneTo_24tok1_clo;
V g_heff_2eelab_2erules_2eunifiedFirst(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eunifiedFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunifiedFirst_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2evalueFirst(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evalueFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evalueFirst_clo;
HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eworldFirst(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eworldFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eworldFirst_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
HeffT2 g_heff_2eelab_2eunify_2esubstOf_24cpr(V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(V, V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f783067987x1926181389(V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
Clo g_heff_2eelab_2erules_2eanyP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyP_entry, 2, 0};

V g_heff_2eelab_2erules_2eanyP(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eanyP(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTermF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  V v_var_243 = heff_take_field(v_r_240, 2);
  V v_ty_244 = heff_take_field(v_r_240, 1);
  V v_el_245 = heff_get_n(v_r_240, 0, 3);
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    V v_i_246 = heff_field(v_t_242, 0);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return heff_tail(v_var_243, 2, (V[]){v_d_241, heff_dup(v_i_246)});
  }
  case TAG_SGlobal: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_t_242, 0);
    heff_drop(v_var_243);
    heff_drop(v_el_245);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_a_248)});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_t_242, 0);
    V v_a_2410 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_241), heff_dup(v_f_249)}));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_d_241);
      heff_drop(v_el_245);
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_a_2410)});
    }
  }
  case TAG_SLam: {
    V v_dd_2412 = heff_field(v_t_242, 0);
    V v_t2_2413 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    switch (heff_tag_of(v_t2_2413)) {
    case TAG_MkAbs: {
      V v_b_2415 = heff_field(v_t2_2413, 1);
      V v_t_2416 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2412)}));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_el_245);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        return heff_tail(v_el_245, 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2415)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2417 = heff_field(v_t2_2413, 0);
      V v_t_2418 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2412)}));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_el_245);
        heff_drop(v_t_2418);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2418);
        return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_b_2417)});
      }
    }
    default: return heff_nomatch(v_t2_2413);
    }
  }
  case TAG_SCons: {
    V v_dct_2419 = heff_field(v_t_242, 0);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    V v_keys_2420 = heff_dup(heff_rfield(v_dct_2419, 0));
    V v_values_2421 = heff_dup(heff_rfield(v_dct_2419, 2));
    V v_t_2422 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2420), heff_arrayToList(v_values_2421)));
    return ({ V b_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam0, 1, 2, (V[]){v_el_245, v_d_241}); V a_1 = v_t_2422; V r_ = (g_heff_2eelab_2erules_2eanyP(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2422); r_; });
  }
  case TAG_SProj: {
    V v_e_2426 = heff_field(v_t_242, 0);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_e_2426)});
  }
  case TAG_STag: {
    V v_argv_2429 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    V v_t_2430 = heff_tr(heff_call(v_el_245, 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2430; V b_1 = heff_arrayToList(heff_dup(v_argv_2429)); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(v_t_2430); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2431 = heff_field(v_t_242, 0);
    V v_cs_2432 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    V v_keys_2433 = heff_dup(heff_rfield(v_cs_2432, 0));
    V v_values_2434 = heff_dup(heff_rfield(v_cs_2432, 2));
    V v_t_2435 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2431)}));
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_d_241);
      heff_drop(v_el_245);
      heff_drop(v_keys_2433);
      heff_drop(v_values_2434);
      heff_drop(v_t_2435);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2435);
      V v_t_2436 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2433), heff_arrayToList(v_values_2434)));
      return ({ V b_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam1, 1, 2, (V[]){v_d_241, v_el_245}); V a_1 = v_t_2436; V r_ = (g_heff_2eelab_2erules_2eanyP(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2436); r_; });
    }
  }
  case TAG_SSpecialize: {
    V v_e_2443 = heff_field(v_t_242, 0);
    V v_v_2445 = heff_field(v_t_242, 2);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    V v_t_2446 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2443)}));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_d_241);
      heff_drop(v_el_245);
      heff_drop(v_t_2446);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2446);
      return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_v_2445)});
    }
  }
  case TAG_SIs: {
    V v_e_2447 = heff_field(v_t_242, 0);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_e_2447)});
  }
  case TAG_SOpaque: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2448 = heff_field(v_t_242, 0);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_e_2448)});
  }
  case TAG_SFix: {
    V v_dd_2449 = heff_field(v_t_242, 0);
    V v_t2_2450 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    switch (heff_tag_of(v_t2_2450)) {
    case TAG_MkAbs: {
      V v_b_2452 = heff_field(v_t2_2450, 1);
      V v_t_2453 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2449)}));
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_el_245);
        heff_drop(v_t_2453);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2453);
        return heff_tail(v_el_245, 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2452)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2454 = heff_field(v_t2_2450, 0);
      V v_t_2455 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2449)}));
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_el_245);
        heff_drop(v_t_2455);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2455);
        return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_b_2454)});
      }
    }
    default: return heff_nomatch(v_t2_2450);
    }
  }
  case TAG_SImplicit: {
    V v_e_2457 = heff_field(v_t_242, 1);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    return heff_tail(v_el_245, 2, (V[]){v_d_241, heff_dup(v_e_2457)});
  }
  case TAG_SPrim: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2461 = heff_field(v_t_242, 2);
    heff_drop(v_var_243);
    heff_drop(v_el_245);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_ty_2461)});
  }
  case TAG_SLitInt: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_drop(v_d_241);
    heff_drop(v_var_243);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2ementionsTermF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args) {
  V v_x3_2423 = args[0];
  V v_el_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x3_2423)) {
  case TAG_MkPair: {
    V v_v_2425 = heff_field(v_x3_2423, 1);
    heff_take_n(v_x3_2423, 2ULL, 2);
    heff_clo_take(self, 2);
    V f_ = v_el_245;
    heff_room[0] = v_d_241;
    heff_room[1] = v_v_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x3_2423);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args) {
  V v_x3_2437 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_el_245 = heff_env(self)[1];
  switch (heff_tag_of(v_x3_2437)) {
  case TAG_MkPair: {
    V v_x32_2439 = heff_field(v_x3_2437, 1);
    heff_take_n(v_x3_2437, 2ULL, 2);
    switch (heff_tag_of(v_x32_2439)) {
    case TAG_MkPair: {
      V v_xs_2440 = heff_field(v_x32_2439, 0);
      V v_b_2441 = heff_field(v_x32_2439, 1);
      heff_take_n(v_x32_2439, 3ULL, 2);
      heff_clo_take(self, 2);
      V v_t_2442 = heff_intAdd(v_d_241, heff_arrayLength(v_xs_2440));
      V f_ = v_el_245;
      heff_room[0] = v_t_2442;
      heff_room[1] = v_b_2441;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x32_2439);
    }
  }
  default: return heff_nomatch(v_x3_2437);
  }
}
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam2(V self, V *args);

HeffT3 g_heff_2eelab_2erules_2ementionsLocal_24cpr(V v_k_240) {
top: ;
  return ((HeffT3){{heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam1, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam2, 2, 1, (V[]){v_k_240})}});
}
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_d_241; V a_2 = v_t_242; V r_ = (g_heff_2eelab_2erules_2ementionsTermF(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_d_244; V a_2 = v_t_245; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_24cpr_lam2(V self, V *args) {
  V v_d_247 = args[0];
  V v_i_248 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_i_248, heff_intAdd_lent(v_d_247, v_k_240, 0), 2));
  heff_drop(v_d_247);
  heff_drop(v_i_248);
  heff_drop(self);
  return v_ret_24bool;
}
V g_heff_2eelab_2erules_2eerrorOf_24rec0_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24rec0_lam0, 1, 0};

static V g_heff_2eelab_2erules_2eerrorOf_24rec0_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eerrorOf_24rec0_st;
static V g_heff_2eelab_2erules_2eerrorOf_24rec0_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2eerrorOf_24rec0_lam0_clo)});
}
V g_heff_2eelab_2erules_2eerrorOf_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eerrorOf_24rec0_st)) return g_heff_2eelab_2erules_2eerrorOf_24rec0_val;
  return heff_global(&g_heff_2eelab_2erules_2eerrorOf_24rec0_val, &g_heff_2eelab_2erules_2eerrorOf_24rec0_st, g_heff_2eelab_2erules_2eerrorOf_24rec0_init);
}
V g_heff_2eelab_2erules_2eerrorOf_24rec0_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  V v_t_241 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_241});
}
HEFF_LIT(g_heff_2eelab_2erules_2enamesFor_str0, 1, "x");
Clo g_heff_2eelab_2erules_2enamesFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_entry, 1, 0};

V g_heff_2eelab_2erules_2enamesFor(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_t_241 = heff_intShow(heff_intSub_lent(v_n_240, MK_INT(1LL), 2));
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_str0), v_t_241), heff_hole()});
    V v_u_243 = (g_heff_2eelab_2erules_2enamesFor_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_cell_242));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamesFor(a[0]);
}
V g_heff_2eelab_2erules_2eeffectFits_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eeffectFits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectFits_lam0, 1, 0};
V g_heff_2eelab_2erules_2eeffectFits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eeffectFits_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eeffectFits_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectFits_lam4, 1, 0};
V g_heff_2eelab_2erules_2eeffectFits_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eeffectFits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eeffectFits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eeffectFits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eeffectFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectFits_entry, 5, 0};

V g_heff_2eelab_2erules_2eeffectFits(V v_e_240, V v_h_241, V v_w_242, V v_hd_243, V v_k_244) {
top: ;
  V v_globals_245 = heff_take_field(v_e_240, 1);
  V v_scope_246 = heff_get_n(v_e_240, 0, 8);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eeffectFits_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2eeffectFits_lam1, 1, 6, (V[]){v_w_242, v_globals_245, v_scope_246, v_h_241, v_hd_243, v_k_244})});
}
V g_heff_2eelab_2erules_2eeffectFits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeffectFits(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eeffectFits_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return v_c_247;
}
V g_heff_2eelab_2erules_2eeffectFits_lam2(V self, V *args) {
  V v_p_2422 = args[0];
  V v_p_2423 = args[1];
  V v_g_2418 = heff_env(self)[0];
  V v_len_2420 = heff_env(self)[1];
  V v_names_2421 = heff_env(self)[2];
  V v_h_241 = heff_env(self)[3];
  V v_hw_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_2418, heff_rec_n(2, shape_len__names, (V[]){v_len_2420, v_names_2421}), v_h_241, v_hw_2416}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2424, v_p_2422, v_p_2423));
}
V g_heff_2eelab_2erules_2eeffectFits_lam4(V self, V *args) {
  V v_c_2430 = args[0];
  return v_c_2430;
}
V g_heff_2eelab_2erules_2eeffectFits_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_r_2425 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_2427 = heff_env(self)[3];
  heff_drop(v_x_2438);
  V v_x_2443;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_r_2425)) {
  case TAG_Left: {
    heff_take_n(v_r_2425, 0ULL, 1);
    heff_drop_rec(v_x_2434, 9);
    heff_drop_rec(v_x_2411, 9);
    v_x_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_r_2425, 0ULL, 1);
    V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2434, 5, 9); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2411, 5, 9); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    v_x_2443 = heff_bool(heff_intEq_c_lent(v_t_2441, v_t_2442, 0));
    heff_drop(v_t_2441);
    heff_drop(v_t_2442);
    break;
  }
  default: heff_nomatch(v_r_2425);
  }
  V f_ = v_k_2427;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eeffectFits_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_malg_2428 = heff_env(self)[1];
  V v_bind_2429 = heff_env(self)[2];
  V v_r_2425 = heff_env(self)[3];
  V v_k_2427 = heff_env(self)[4];
  V v_t_2435 = heff_tag_n(TAG_Put, 2, (V[]){heff_dup(v_x_2411), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  heff_clo_take(self, 5);
  V v_t_2437 = heff_tr(heff_call(v_malg_2428, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})}));
  V f_ = v_bind_2429;
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eeffectFits_lam6, 1, 4, (V[]){v_r_2425, v_x_2434, v_x_2411, v_k_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eeffectFits_lam3(V self, V *args) {
  V v_r_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  V v_x_2411 = heff_env(self)[0];
  V v_malg_2428 = heff_take_field(v_hd_2426, 2);
  V v_bind_2429 = heff_get_n(v_hd_2426, 1, 3);
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eeffectFits_lam4_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_dup(v_malg_2428), 1, (V[]){v_t_2432}));
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_bind_2429);
  args[0] = v_t_2433;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eeffectFits_lam5, 1, 5, (V[]){v_x_2411, v_malg_2428, v_bind_2429, v_r_2425, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eeffectFits_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_w_242 = heff_env(self)[0];
  V v_globals_245 = heff_env(self)[1];
  V v_scope_246 = heff_env(self)[2];
  V v_h_241 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT3 v_t_2412 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(heff_rfield(v_x_2411, 3), heff_get_n(v_w_242, 3, 6)));
  {
    V v_field_2414 = v_t_2412.f[1];
    V v_field_2415 = v_t_2412.f[2];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_hw_2416 = v_field_2414;
      V v_it12_2417 = v_field_2415;
      heff_drop(v_it12_2417);
      V v_g_2418 = v_globals_245;
      V v_c_2419 = v_scope_246;
      V v_len_2420 = heff_take_field(v_c_2419, 0);
      V v_names_2421 = heff_get_n(v_c_2419, 1, 5);
      return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2eeffectFits_lam2, 2, 5, (V[]){v_g_2418, v_len_2420, v_names_2421, v_h_241, v_hw_2416}), heff_clo_n(g_heff_2eelab_2erules_2eeffectFits_lam3, 3, 1, (V[]){v_x_2411}), v_hd_243, v_k_244));
    } else {
      heff_drop_rec(v_x_2411, 9);
      heff_drop(v_globals_245);
      heff_drop(v_scope_246);
      heff_drop(v_h_241);
      heff_drop_rec(v_hd_243, 3);
      heff_drop(v_field_2414);
      heff_drop(v_field_2415);
      V f_ = v_k_244;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}

HeffT2 g_heff_2eelab_2erules_2eescapeLevel_24cpr(V v_err_240) {
top: ;
  switch (heff_tag_of(v_err_240)) {
  case TAG_UnequalTys: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_UnequalEls: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_UnequalNeus: {
    V v_h1_248 = heff_field(v_err_240, 1);
    V v_h2_2410 = heff_field(v_err_240, 3);
    switch (heff_tag_of(v_h1_248)) {
    case TAG_HLocal: {
      V v_l_2412 = heff_field(v_h1_248, 0);
      switch (heff_tag_of(v_h2_2410)) {
      case TAG_HLocal: {
        V v_l2_2413 = heff_field(v_h2_2410, 0);
        if (heff_intLt_c_lent(v_l2_2413, v_l_2412, 0)) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2412)}});
        } else {
          switch (heff_tag_of(v_h2_2410)) {
          case TAG_HLocal: {
            V v_l_2414 = heff_field(v_h2_2410, 0);
            switch (heff_tag_of(v_h1_248)) {
            case TAG_HLocal: {
              V v_l2_2415 = heff_field(v_h1_248, 0);
              if (heff_intLt_c_lent(v_l2_2415, v_l_2414, 0)) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2414)}});
              } else {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
            case TAG_HGlobal: {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2414)}});
            }
            case TAG_HMeta: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_HError: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
            }
          }
          case TAG_HGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_HMeta: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_HError: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
          }
        }
      }
      case TAG_HGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2412)}});
      }
      case TAG_HMeta: {
        switch (heff_tag_of(v_h2_2410)) {
        case TAG_HLocal: {
          V v_l_2422 = heff_field(v_h2_2410, 0);
          switch (heff_tag_of(v_h1_248)) {
          case TAG_HLocal: {
            V v_l2_2423 = heff_field(v_h1_248, 0);
            if (heff_intLt_c_lent(v_l2_2423, v_l_2422, 0)) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2422)}});
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_HGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2422)}});
          }
          case TAG_HMeta: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_HError: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
          }
        }
        case TAG_HGlobal: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HMeta: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HError: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
        }
      }
      case TAG_HError: {
        switch (heff_tag_of(v_h2_2410)) {
        case TAG_HLocal: {
          V v_l_2428 = heff_field(v_h2_2410, 0);
          switch (heff_tag_of(v_h1_248)) {
          case TAG_HLocal: {
            V v_l2_2429 = heff_field(v_h1_248, 0);
            if (heff_intLt_c_lent(v_l2_2429, v_l_2428, 0)) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2428)}});
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_HGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2428)}});
          }
          case TAG_HMeta: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_HError: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
          }
        }
        case TAG_HGlobal: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HMeta: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HError: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
      }
    }
    case TAG_HGlobal: {
      switch (heff_tag_of(v_h2_2410)) {
      case TAG_HLocal: {
        V v_l_2435 = heff_field(v_h2_2410, 0);
        switch (heff_tag_of(v_h1_248)) {
        case TAG_HLocal: {
          V v_l2_2436 = heff_field(v_h1_248, 0);
          if (heff_intLt_c_lent(v_l2_2436, v_l_2435, 0)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2435)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_HGlobal: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2435)}});
        }
        case TAG_HMeta: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HError: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
        }
      }
      case TAG_HGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HMeta: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
      }
    }
    case TAG_HMeta: {
      switch (heff_tag_of(v_h2_2410)) {
      case TAG_HLocal: {
        V v_l_2442 = heff_field(v_h2_2410, 0);
        switch (heff_tag_of(v_h1_248)) {
        case TAG_HLocal: {
          V v_l2_2443 = heff_field(v_h1_248, 0);
          if (heff_intLt_c_lent(v_l2_2443, v_l_2442, 0)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2442)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_HGlobal: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2442)}});
        }
        case TAG_HMeta: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HError: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
        }
      }
      case TAG_HGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HMeta: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
      }
    }
    case TAG_HError: {
      switch (heff_tag_of(v_h2_2410)) {
      case TAG_HLocal: {
        V v_l_2448 = heff_field(v_h2_2410, 0);
        switch (heff_tag_of(v_h1_248)) {
        case TAG_HLocal: {
          V v_l2_2449 = heff_field(v_h1_248, 0);
          if (heff_intLt_c_lent(v_l2_2449, v_l_2448, 0)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2448)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_HGlobal: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2448)}});
        }
        case TAG_HMeta: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_HError: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
        }
      }
      case TAG_HGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HMeta: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h2_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_h1_248)}});
    }
  }
  case TAG_MentionsError: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Escapes: {
    V v_l_2454 = heff_field(v_err_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_2454)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_err_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eplainMismatch_str0, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2eplainMismatch_str1, 15, ", but got type ");
V g_heff_2eelab_2erules_2eplainMismatch_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eplainMismatch_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eplainMismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplainMismatch_entry, 7, 0};

V g_heff_2eelab_2erules_2eplainMismatch(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_why_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_240), v_a_242, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2eplainMismatch_lam0, 1, 6, (V[]){v_e_240, v_a_27_243, v_hd_245, v_sp_241, v_why_244, v_k_246})));
}
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplainMismatch(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2eplainMismatch_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_why_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eplainMismatch_str0), v_x_247), ((V)&g_heff_2eelab_2erules_2eplainMismatch_str1));
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), heff_strAppend(v_t_249, v_x_248), v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_why_244})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  heff_room[0] = v_t_2413;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eplainMismatch_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_27_243 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_why_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2etyStrZ(v_e_240, v_a_27_243, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2eplainMismatch_lam1, 1, 5, (V[]){v_x_247, v_sp_241, v_why_244, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2erules_2einArguments_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einArguments_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einArguments_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einArguments_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einArguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einArguments_entry, 7, 0};

V g_heff_2eelab_2erules_2einArguments(V v_e_240, V v_mc_241, V v_m_242, V v_t_243, V v_k_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einArguments_lam0, 1, 1, (V[]){v_t_243})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2einArguments_lam1, 1, 6, (V[]){v_k_244, v_k_246, v_mc_241, v_e_240, heff_dup(v_m_242), v_hd_245})});
}
V g_heff_2eelab_2erules_2einArguments_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2einArguments(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2einArguments_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 9); V a_1 = v_t_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2einArguments_lam3(V self, V *args) {
  V v_u_2429 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_drop(v_u_2429);
  heff_clo_take(self, 1);
  return v_dom_2415;
}
V g_heff_2eelab_2erules_2einArguments_lam2(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_drop(v_u_2428);
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2einArguments_lam3, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2einArguments_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_mc_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_m_242 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  if (heff_intLe_c_lent(v_k_244, MK_INT(0LL), 2)) {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_k_244);
    heff_drop(v_mc_241);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_m_242);
    heff_drop_rec(v_hd_245, 3);
    V f_ = v_k_246;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_it_2412 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2411));
    switch (heff_tag_of(v_it_2412)) {
    case TAG_LikeU: {
      heff_take_n(v_it_2412, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeFunction: {
      V v_dom_2415 = heff_field(v_it_2412, 1);
      V v_cod_2416 = heff_field(v_it_2412, 2);
      V v_it4_2417 = heff_field(v_it_2412, 3);
      heff_take_n(v_it_2412, 14ULL, 4);
      switch (heff_tag_of(v_it4_2417)) {
      case TAG_Expl: {
        HeffT3 v_t_2418 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_mc_241)));
        {
          V v_field_2420 = v_t_2418.f[1];
          heff_drop(v_t_2418.f[0]);
          heff_drop(v_t_2418.f[2]);
          V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
          V v_xs_2423 = heff_tr(heff_call(v_field_2420, 3, (V[]){MK_INT(20LL), v_t_2422, heff_dup(v_dom_2415)}));
          V v_t_2424 = ({ V a_0 = v_m_242; V a_1 = v_xs_2423; V r_ = (g_list_2eany_24s781693278x668067139(a_0, a_1)); heff_drop(v_xs_2423); r_; });
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_clo_take(self, 6);
            heff_drop(v_k_244);
            heff_drop(v_mc_241);
            heff_drop_rec(v_e_240, 8);
            heff_drop(v_m_242);
            heff_drop_rec(v_hd_245, 3);
            heff_drop(v_dom_2415);
            heff_drop(v_cod_2416);
            heff_drop(v_t_2424);
            V f_ = v_k_246;
            args[0] = NTAG(TAG_True);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          } else {
            heff_drop(v_t_2424);
            V v_x1_2431;
            switch (heff_tag_of(v_cod_2416)) {
            case TAG_MkClo: {
              V v_vs_2426 = heff_field(v_cod_2416, 1);
              V v_body_2427 = heff_field(v_cod_2416, 2);
              heff_take_n(v_cod_2416, 6ULL, 3);
              v_x1_2431 = heff_tr(heff_call(v_body_2427, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2426, heff_clo_n(g_heff_2eelab_2erules_2einArguments_lam2, 1, 1, (V[]){v_dom_2415})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2430 = heff_field(v_cod_2416, 0);
              heff_take_n(v_cod_2416, 1ULL, 1);
              heff_drop(v_dom_2415);
              v_x1_2431 = v_body_2430;
              break;
            }
            default: heff_nomatch(v_cod_2416);
            }
            V v_t_2435;
            switch (heff_tag_of(v_x1_2431)) {
            case TAG_Nom: {
              V v_x_2432 = heff_field(v_x1_2431, 0);
              heff_take_n(v_x1_2431, 1ULL, 1);
              v_t_2435 = v_x_2432;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2431, 0ULL, 1);
              v_t_2435 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2434 = heff_field(v_x1_2431, 0);
              heff_take_n(v_x1_2431, 1ULL, 1);
              v_t_2435 = v_x_2434;
              break;
            }
            default: heff_nomatch(v_x1_2431);
            }
            heff_clo_take(self, 6);
            return ({ V a_0 = v_e_240; V a_1 = v_mc_241; V a_2 = v_m_242; V a_3 = v_t_2435; V a_4 = heff_intSub(v_k_244, MK_INT(1LL)); V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2eelab_2erules_2einArguments(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_m_242); r_; });
          }
        }
      }
      case TAG_Impl: {
        heff_clo_take(self, 6);
        heff_drop(v_k_244);
        heff_drop(v_mc_241);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_m_242);
        heff_drop_rec(v_hd_245, 3);
        heff_drop(v_dom_2415);
        heff_drop(v_cod_2416);
        V f_ = v_k_246;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Inst: {
        heff_clo_take(self, 6);
        heff_drop(v_k_244);
        heff_drop(v_mc_241);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_m_242);
        heff_drop_rec(v_hd_245, 3);
        heff_drop(v_dom_2415);
        heff_drop(v_cod_2416);
        V f_ = v_k_246;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it4_2417);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_it_2412, 0ULL, 3);
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeSum: {
      heff_take_n(v_it_2412, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeInt: {
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeFloat: {
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeString: {
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeRune: {
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeArray: {
      heff_take_n(v_it_2412, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_it_2412, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_NoRules: {
      heff_clo_take(self, 6);
      heff_drop(v_k_244);
      heff_drop(v_mc_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_m_242);
      heff_drop_rec(v_hd_245, 3);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it_2412);
    }
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyResultFirst_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyResultFirst_lam7, 1, 0};
V g_heff_2eelab_2erules_2eapplyResultFirst_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyResultFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyResultFirst_entry, 6, 0};

V g_heff_2eelab_2erules_2eapplyResultFirst(V v_sp_240, V v_firstSp_241, V v_nominal_242, V v_head_243, V v_n_244, V v_elims_245) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam0, 4, 6, (V[]){v_elims_245, v_head_243, heff_dup(v_nominal_242), v_sp_240, v_firstSp_241, v_n_244})});
}
V g_heff_2eelab_2erules_2eapplyResultFirst_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapplyResultFirst(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam1(V self, V *args) {
  V v_c_2410 = args[0];
  V v_a0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_a0_247; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam4(V self, V *args) {
  V v_c_2460 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_t_2463;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2459)) {
  case TAG_MkPair: {
    V v_y_2462 = heff_field(v_x_2459, 1);
    heff_take_n(v_x_2459, 2ULL, 2);
    v_t_2463 = v_y_2462;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  return ({ V b_0 = heff_get_n(v_c_2460, 3, 9); V a_1 = v_t_2463; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam6(V self, V *args) {
  V v_e2_2481 = args[0];
  V v_hd_2482 = args[1];
  V v_k_2483 = args[2];
  V v_x_2459 = heff_env(self)[0];
  heff_drop(v_e2_2481);
  heff_drop(v_hd_2482);
  heff_clo_take(self, 1);
  V f_ = v_k_2483;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam7(V self, V *args) {
  V v_c_2489 = args[0];
  return heff_get_n(v_c_2489, 4, 9);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam11(V self, V *args) {
  V v_e2_24103 = args[0];
  V v_hd_24104 = args[1];
  V v_k_24105 = args[2];
  V v_x_2498 = heff_env(self)[0];
  heff_drop(v_e2_24103);
  heff_drop(v_hd_24104);
  heff_clo_take(self, 1);
  V f_ = v_k_24105;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam12(V self, V *args) {
  V v_u_24121 = args[0];
  V v_z_24122 = args[1];
  V v_z_24123 = args[2];
  V v_sp_240 = heff_env(self)[0];
  V v_applied_24107 = heff_env(self)[1];
  V v_e_246 = heff_env(self)[2];
  V v_a0_247 = heff_env(self)[3];
  heff_drop(v_u_24121);
  heff_clo_take(self, 4);
  HeffT1 v_t_24124 = ({ V a_0 = v_sp_240; V a_1 = v_applied_24107; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_applied_24107); r_; });
  {
    V v_field_24125 = v_t_24124.f[0];
    V v_f_24126 = v_field_24125;
    V f_ = v_f_24126;
    heff_room[0] = v_e_246;
    heff_room[1] = v_a0_247;
    heff_room[2] = v_z_24122;
    heff_room[3] = v_z_24123;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam16(V self, V *args) {
  V v_x_24136 = args[0];
  V v_x_24132 = heff_env(self)[0];
  V v_k_24131 = heff_env(self)[1];
  heff_drop(v_x_24136);
  V v_t_24139;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_24132)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x_24132, 0);
    heff_take_n(v_x_24132, 1ULL, 2);
    v_t_24139 = v_x_24137;
    break;
  }
  default: heff_nomatch(v_x_24132);
  }
  V f_ = v_k_24131;
  args[0] = v_t_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam15(V self, V *args) {
  V v_x_24132 = args[0];
  V v_hd_24130 = heff_env(self)[0];
  V v_k_24131 = heff_env(self)[1];
  V v_t_24133 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
  V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
  heff_clo_take(self, 2);
  V v_t_24135 = heff_tr(heff_call(heff_take_field(v_hd_24130, 2), 1, (V[]){v_t_24134}));
  V f_ = heff_get_n(v_hd_24130, 1, 3);
  heff_room[0] = v_t_24135;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam16, 1, 2, (V[]){v_x_24132, v_k_24131});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam14(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_c_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24129;
  args[0] = heff_dup(v_hd_24130);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam15, 1, 2, (V[]){v_hd_24130, v_k_24131});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam13(V self, V *args) {
  V v_first_24127 = args[0];
  V v_applied_24107 = heff_env(self)[0];
  V v_e_246 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_a0_247 = heff_env(self)[3];
  if ((heff_dup(v_first_24127) == NTAG(TAG_True))) {
    heff_drop(v_first_24127);
    heff_clo_take(self, 4);
    heff_drop(v_sp_240);
    heff_drop(v_a0_247);
    V v_c_24129;
    switch (heff_tag_of(v_applied_24107)) {
    case TAG_MkSyn: {
      V v_f_24128 = heff_field(v_applied_24107, 0);
      heff_take_n(v_applied_24107, 1ULL, 1);
      v_c_24129 = heff_tr(heff_call(v_f_24128, 1, (V[]){v_e_246}));
      break;
    }
    default: heff_nomatch(v_applied_24107);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam14, 2, 1, (V[]){v_c_24129});
  } else {
    heff_drop(v_first_24127);
    heff_clo_take(self, 4);
    HeffT1 v_t_24140 = ({ V a_0 = v_sp_240; V a_1 = v_applied_24107; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_applied_24107); r_; });
    {
      V v_field_24141 = v_t_24140.f[0];
      V v_f_24142 = v_field_24141;
      V f_ = v_f_24142;
      heff_room[0] = v_e_246;
      heff_room[1] = v_a0_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam18(V self, V *args) {
  V v_x_24149 = args[0];
  V v_f_24143 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_drop(v_x_24149);
  heff_clo_take(self, 3);
  V f_ = v_f_24143;
  heff_room[0] = NTAG(TAG_False);
  heff_room[1] = v_hd_248;
  heff_room[2] = v_k_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam17(V self, V *args) {
  V v_x_24145 = args[0];
  V v_f_24143 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_2498 = heff_env(self)[3];
  V v_e_246 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_x_2493 = heff_env(self)[6];
  V v_n_244 = heff_env(self)[7];
  V v_x_2414 = heff_env(self)[8];
  V v_t_24144 = heff_env(self)[9];
  if ((heff_dup(v_x_24145) == NTAG(TAG_True))) {
    heff_drop(v_x_24145);
    heff_clo_take(self, 10);
    heff_drop(v_x_2498);
    heff_drop(v_e_246);
    heff_drop(v_sp_240);
    heff_drop(v_x_2493);
    heff_drop(v_n_244);
    heff_drop(v_x_2414);
    heff_drop(v_t_24144);
    V f_ = v_f_24143;
    heff_room[0] = NTAG(TAG_True);
    heff_room[1] = v_hd_248;
    heff_room[2] = v_k_249;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_x_24145);
    V v_t_24148;
    heff_clo_take(self, 10);
    switch (heff_tag_of(v_x_2498)) {
    case TAG_MkPair: {
      V v_y_24147 = heff_field(v_x_2498, 1);
      heff_take_n(v_x_2498, 2ULL, 2);
      v_t_24148 = v_y_24147;
      break;
    }
    default: heff_nomatch(v_x_2498);
    }
    return (g_heff_2eelab_2erules_2eworldFirst(v_e_246, v_sp_240, v_x_2493, v_n_244, v_t_24148, v_x_2414, v_t_24144, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam18, 1, 3, (V[]){v_f_24143, v_hd_248, v_k_249})));
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam10(V self, V *args) {
  V v_x_24102 = args[0];
  V v_elims_245 = heff_env(self)[0];
  V v_x_2498 = heff_env(self)[1];
  V v_nominal_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_e_246 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_x_2493 = heff_env(self)[6];
  V v_a0_247 = heff_env(self)[7];
  V v_hd_248 = heff_env(self)[8];
  V v_k_249 = heff_env(self)[9];
  V v_n_244 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24106 = heff_tr(heff_call(v_elims_245, 1, (V[]){heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam11, 3, 1, (V[]){heff_dup(v_x_2498)})})}));
  V v_applied_24107 = ({ V a_0 = v_nominal_242; V a_1 = v_t_24106; V r_ = (g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(a_0, a_1)); heff_drop(v_nominal_242); r_; });
  V v_t_24108 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2414)));
  V v_t_24120;
  switch (heff_tag_of(v_t_24108)) {
  case TAG_LikeU: {
    heff_take_n(v_t_24108, 0ULL, 1);
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_24113 = heff_field(v_t_24108, 3);
    heff_take_n(v_t_24108, 8ULL, 4);
    switch (heff_tag_of(v_implicit_24113)) {
    case TAG_Expl: {
      v_t_24120 = NTAG(TAG_False);
      break;
    }
    case TAG_Impl: {
      v_t_24120 = NTAG(TAG_True);
      break;
    }
    case TAG_Inst: {
      v_t_24120 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_implicit_24113);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_24108, 0ULL, 3);
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_24108, 0ULL, 1);
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeInt: {
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFloat: {
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeString: {
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeRune: {
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_24108, 0ULL, 1);
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_24108, 0ULL, 1);
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  case TAG_NoRules: {
    v_t_24120 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_24108);
  }
  if ((heff_dup(v_t_24120) == NTAG(TAG_True))) {
    heff_drop(v_x_2498);
    heff_drop(v_n_244);
    heff_drop(v_t_24120);
    return ({ V a_0 = heff_dup(v_e_246); V a_1 = heff_dup(v_sp_240); V a_2 = v_x_2493; V a_3 = v_x_2414; V a_4 = v_applied_24107; V a_5 = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam12, 3, 4, (V[]){v_sp_240, heff_dup(v_applied_24107), v_e_246, v_a0_247}); V a_6 = v_x_24102; V a_7 = v_hd_248; V a_8 = v_k_249; V r_ = (g_heff_2eelab_2erules_2evalueFirst(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2493); heff_drop(v_applied_24107); r_; });
  } else {
    heff_drop(v_t_24120);
    V v_f_24143 = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam13, 1, 4, (V[]){v_applied_24107, heff_dup(v_e_246), heff_dup(v_sp_240), v_a0_247});
    switch (heff_tag_of(v_x_24102)) {
    case TAG_Nothing: {
      heff_drop(v_x_2498);
      heff_drop(v_x_2414);
      heff_drop(v_e_246);
      heff_drop(v_sp_240);
      heff_drop(v_x_2493);
      heff_drop(v_n_244);
      V f_ = v_f_24143;
      heff_room[0] = NTAG(TAG_False);
      heff_room[1] = v_hd_248;
      heff_room[2] = v_k_249;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    case TAG_Just: {
      V v_t_24144 = heff_field(v_x_24102, 0);
      heff_take_n(v_x_24102, 1ULL, 1);
      return (g_heff_2eelab_2erules_2eunifiedFirst(heff_dup(v_e_246), heff_dup(v_sp_240), heff_dup(v_x_2414), heff_dup(v_t_24144), heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam17, 1, 10, (V[]){v_f_24143, v_hd_248, v_k_249, v_x_2498, v_e_246, v_sp_240, v_x_2493, v_n_244, v_x_2414, v_t_24144})));
    }
    default: return heff_nomatch(v_x_24102);
    }
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam9(V self, V *args) {
  V v_x_2498 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_elims_245 = heff_env(self)[2];
  V v_nominal_242 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_e_246 = heff_env(self)[5];
  V v_sp_240 = heff_env(self)[6];
  V v_x_2493 = heff_env(self)[7];
  V v_a0_247 = heff_env(self)[8];
  V v_k_249 = heff_env(self)[9];
  V v_t_24101;
  switch (heff_tag_of(v_x_2498)) {
  case TAG_MkPair: {
    V v_y_24100 = heff_dup(heff_field(v_x_2498, 1));
    v_t_24101 = v_y_24100;
    break;
  }
  default: heff_nomatch(v_x_2498);
  }
  heff_clo_take(self, 10);
  return (g_heff_2eelab_2erules_2eresultAfter(v_t_24101, heff_dup(v_n_244), heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam10, 1, 11, (V[]){v_elims_245, v_x_2498, v_nominal_242, v_x_2414, v_e_246, v_sp_240, v_x_2493, v_a0_247, v_hd_248, v_k_249, v_n_244})));
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam8(V self, V *args) {
  V v_x_2493 = args[0];
  V v_nominal_242 = heff_env(self)[0];
  V v_e_246 = heff_env(self)[1];
  V v_x_2459 = heff_env(self)[2];
  V v_firstSp_241 = heff_env(self)[3];
  V v_x_2467 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  V v_n_244 = heff_env(self)[6];
  V v_elims_245 = heff_env(self)[7];
  V v_x_2414 = heff_env(self)[8];
  V v_sp_240 = heff_env(self)[9];
  V v_a0_247 = heff_env(self)[10];
  V v_k_249 = heff_env(self)[11];
  V v_t_2494 = (g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(v_nominal_242, heff_dup(v_e_246)));
  V v_t_2497;
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2459)) {
  case TAG_MkPair: {
    V v_x_2495 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 2);
    v_t_2497 = v_x_2495;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_t_2494, v_firstSp_241, v_t_2497, v_x_2467, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam9, 1, 10, (V[]){v_n_244, v_hd_248, v_elims_245, v_nominal_242, v_x_2414, v_e_246, v_sp_240, v_x_2493, v_a0_247, v_k_249})));
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam5(V self, V *args) {
  V v_x_2467 = args[0];
  V v_elims_245 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_nominal_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_e_246 = heff_env(self)[4];
  V v_a0_247 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  V v_firstSp_241 = heff_env(self)[8];
  V v_n_244 = heff_env(self)[9];
  V v_x_2414 = heff_env(self)[10];
  V v_t_2468 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2467)));
  V v_t_2480;
  switch (heff_tag_of(v_t_2468)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2473 = heff_field(v_t_2468, 3);
    heff_take_n(v_t_2468, 8ULL, 4);
    switch (heff_tag_of(v_implicit_2473)) {
    case TAG_Expl: {
      v_t_2480 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2480 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2480 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2473);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2468, 0ULL, 3);
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeInt: {
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeString: {
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeRune: {
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  case TAG_NoRules: {
    v_t_2480 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2468);
  }
  if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
    heff_drop(v_x_2467);
    heff_clo_take(self, 11);
    heff_drop(v_firstSp_241);
    heff_drop(v_n_244);
    heff_drop(v_x_2414);
    heff_drop(v_t_2480);
    V v_t_2484 = heff_tr(heff_call(v_elims_245, 1, (V[]){heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam6, 3, 1, (V[]){v_x_2459})})}));
    V v_t_2485 = ({ V a_0 = v_nominal_242; V a_1 = v_t_2484; V r_ = (g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(a_0, a_1)); heff_drop(v_nominal_242); r_; });
    HeffT1 v_t_2486 = ({ V a_0 = v_sp_240; V a_1 = v_t_2485; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_2485); r_; });
    {
      V v_field_2487 = v_t_2486.f[0];
      V v_f_2488 = v_field_2487;
      V f_ = v_f_2488;
      heff_room[0] = v_e_246;
      heff_room[1] = v_a0_247;
      heff_room[2] = v_hd_248;
      heff_room[3] = v_k_249;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  } else {
    heff_drop(v_t_2480);
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyResultFirst_lam7_clo)})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){v_t_2491}));
    heff_clo_take(self, 11);
    V f_ = heff_dup(heff_rfield(v_hd_248, 1));
    heff_room[0] = v_t_2492;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam8, 1, 12, (V[]){v_nominal_242, v_e_246, v_x_2459, v_firstSp_241, v_x_2467, v_hd_248, v_n_244, v_elims_245, v_x_2414, v_sp_240, v_a0_247, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_elims_245 = heff_env(self)[1];
  V v_nominal_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_e_246 = heff_env(self)[4];
  V v_a0_247 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  V v_firstSp_241 = heff_env(self)[7];
  V v_n_244 = heff_env(self)[8];
  V v_x_2414 = heff_env(self)[9];
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam4, 1, 1, (V[]){heff_dup(v_x_2459)})})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){v_t_2465}));
  heff_clo_take(self, 10);
  V f_ = heff_dup(heff_rfield(v_hd_248, 1));
  heff_room[0] = v_t_2466;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam5, 1, 11, (V[]){v_elims_245, v_x_2459, v_nominal_242, v_sp_240, v_e_246, v_a0_247, v_hd_248, v_k_249, v_firstSp_241, v_n_244, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_elims_245 = heff_env(self)[0];
  V v_head_243 = heff_env(self)[1];
  V v_nominal_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_e_246 = heff_env(self)[4];
  V v_a0_247 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  V v_firstSp_241 = heff_env(self)[8];
  V v_n_244 = heff_env(self)[9];
  V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2414)));
  V v_t_2427;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2420 = heff_field(v_t_2415, 3);
    heff_take_n(v_t_2415, 8ULL, 4);
    switch (heff_tag_of(v_implicit_2420)) {
    case TAG_Expl: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_Impl: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_Inst: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_implicit_2420);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2415, 0ULL, 3);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeRune: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2450;
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_t_2427);
    v_t_2450 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2427);
    switch (heff_tag_of(v_x_2414)) {
    case TAG_VU: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2429 = heff_dup(heff_field(v_x_2414, 0));
      switch (heff_tag_of(v_t1_2429)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2429, 0ULL, 1);
        v_t_2450 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2429, 0ULL, 1);
        v_t_2450 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2429, 0ULL, 1);
        v_t_2450 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2450 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2429);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
  }
  if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_clo_take(self, 10);
    heff_drop(v_firstSp_241);
    heff_drop(v_n_244);
    heff_drop(v_t_2450);
    V v_t_2451 = heff_tr(heff_call(v_elims_245, 1, (V[]){v_head_243}));
    V v_t_2452 = ({ V a_0 = v_nominal_242; V a_1 = v_t_2451; V r_ = (g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(a_0, a_1)); heff_drop(v_nominal_242); r_; });
    HeffT1 v_t_2453 = ({ V a_0 = v_sp_240; V a_1 = v_t_2452; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    {
      V v_field_2454 = v_t_2453.f[0];
      V v_f_2455 = v_field_2454;
      V f_ = v_f_2455;
      heff_room[0] = v_e_246;
      heff_room[1] = v_a0_247;
      heff_room[2] = v_hd_248;
      heff_room[3] = v_k_249;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  } else {
    heff_drop(v_t_2450);
    V v_e_2456 = (g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(v_nominal_242, heff_dup(v_e_246)));
    V v_c_2458;
    heff_clo_take(self, 10);
    switch (heff_tag_of(v_head_243)) {
    case TAG_MkSyn: {
      V v_f_2457 = heff_field(v_head_243, 0);
      heff_take_n(v_head_243, 1ULL, 1);
      v_c_2458 = heff_tr(heff_call(v_f_2457, 1, (V[]){v_e_2456}));
      break;
    }
    default: heff_nomatch(v_head_243);
    }
    V f_ = v_c_2458;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam3, 1, 10, (V[]){v_hd_248, v_elims_245, v_nominal_242, v_sp_240, v_e_246, v_a0_247, v_k_249, v_firstSp_241, v_n_244, v_x_2414});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_lam0(V self, V *args) {
  V v_e_246 = args[0];
  V v_a0_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V v_elims_245 = heff_env(self)[0];
  V v_head_243 = heff_env(self)[1];
  V v_nominal_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_firstSp_241 = heff_env(self)[4];
  V v_n_244 = heff_env(self)[5];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam1, 1, 1, (V[]){heff_dup(v_a0_247)})})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_248, 1));
  args[0] = v_t_2413;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_lam2, 1, 10, (V[]){v_elims_245, v_head_243, v_nominal_242, v_sp_240, v_e_246, v_a0_247, v_hd_248, v_k_249, v_firstSp_241, v_n_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eautoRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eautoRec_entry, 3, 0};

V g_heff_2eelab_2erules_2eautoRec(V v_sp_240, V v_x_241, V v_c_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eautoRec_lam0, 2, 3, (V[]){heff_dup(v_x_241), v_c_242, v_sp_240})});
}
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eautoRec(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 5);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 3, 5);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 5);
  heff_clo_take(self, 3);
  HeffT3 v_t_248 = ({ V a_0 = v_x_241; V a_1 = v_t_245; V a_2 = v_t_246; V a_3 = v_t_247; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT3 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_241); heff_drop(v_t_245); heff_drop(v_t_246); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_field_2411);
      V v_it1_2412 = v_field_2410;
      switch (heff_tag_of(v_it1_2412)) {
      case TAG_NotInScope: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2413 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2413;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_Delayed2: {
        V v_x1_2414 = (g_heff_2eelab_2evalue_2elevelOf(v_a_244));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Small: {
          HeffT1 v_t_2415 = (g_heff_2eelab_2erules_2erecChk_24cpr(v_sp_240, v_c_242));
          {
            V v_field_2416 = v_t_2415.f[0];
            V v_f_2417 = v_field_2416;
            V f_ = v_f_2417;
            args[0] = v_e_243;
            args[1] = v_a_244;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        }
        case TAG_Large: {
          heff_drop(v_sp_240);
          switch (heff_tag_of(v_c_242)) {
          case TAG_MkChk: {
            V v_f_2418 = heff_field(v_c_242, 0);
            heff_take_n(v_c_242, 1ULL, 1);
            V f_ = v_f_2418;
            args[0] = v_e_243;
            args[1] = v_a_244;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          default: return heff_nomatch(v_c_242);
          }
        }
        case TAG_TopL: {
          heff_drop(v_sp_240);
          switch (heff_tag_of(v_c_242)) {
          case TAG_MkChk: {
            V v_f_2419 = heff_field(v_c_242, 0);
            heff_take_n(v_c_242, 1ULL, 1);
            V f_ = v_f_2419;
            args[0] = v_e_243;
            args[1] = v_a_244;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          default: return heff_nomatch(v_c_242);
          }
        }
        default: return heff_nomatch(v_x1_2414);
        }
      }
      default: return heff_nomatch(v_it1_2412);
      }
    } else {
      heff_drop(v_sp_240);
      V v_x_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){v_field_2410, v_field_2411});
      heff_drop_tag(v_x_2420, 2);
      switch (heff_tag_of(v_c_242)) {
      case TAG_MkChk: {
        V v_f_2421 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 1);
        V f_ = v_f_2421;
        args[0] = v_e_243;
        args[1] = v_a_244;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_c_242);
      }
    }
  }
}
V g_heff_2eelab_2erules_2erecordOf_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordOf_lam1, 1, 0};
V g_heff_2eelab_2erules_2erecordOf_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordOf_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordOf_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordOf(V v_e_240, V v_f_241) {
top: ;
  V v_level_242 = heff_take_field(v_f_241, 0);
  V v_fields_243 = heff_take_field(v_f_241, 1);
  V v_defaults_244 = heff_get_n(v_f_241, 2, 4);
  V v_globals_245 = heff_take_field(v_e_240, 1);
  V v_scope_246 = heff_get_n(v_e_240, 0, 8);
  V v_g_247 = v_globals_245;
  V v_vs_248 = heff_get_n(v_scope_246, 2, 5);
  V v_level_249 = v_level_242;
  V v_pairs_2410 = v_fields_243;
  V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2410)));
  V v_t_2412 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2410));
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_pairs_2410));
  V v_fieldTypes_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2411), v_t_2412, heff_arrayFromList(v_t_2413)});
  V v_pairs_2415 = v_defaults_244;
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2415)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2415));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_pairs_2415));
  V v_defaults_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){heff_dup(v_level_249), heff_dup(v_fieldTypes_2414), heff_dup(v_defaults_2419)}), heff_clo_n(g_heff_2eelab_2erules_2erecordOf_lam0, 1, 5, (V[]){v_fieldTypes_2414, v_g_247, v_level_249, v_vs_248, v_defaults_2419})});
}
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordOf(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordOf_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  heff_drop(v_u_2423);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2erecordOf_lam2(V self, V *args) {
  V v_vs2_2425 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_t_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2426 = ({ V a_0 = v_g_247; V a_1 = NTAG(TAG_N); V a_2 = v_t_2424; V a_3 = v_vs2_2425; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_247); heff_drop(v_vs2_2425); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    V v_t_2432;
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_x_2429 = v_field_2428;
      v_t_2432 = v_x_2429;
    } else {
      if ((v_tag_2427 == ((int64_t)1ULL))) {
        V v_x11_2430 = v_field_2428;
        heff_drop(v_x11_2430);
        v_t_2432 = heff_abandon();
      } else {
        V v_x_2431 = v_field_2428;
        v_t_2432 = v_x_2431;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2432, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2erules_2erecordOf_lam0(V self, V *args) {
  V v_u_2420 = args[0];
  V v_fieldTypes_2414 = heff_env(self)[0];
  V v_g_247 = heff_env(self)[1];
  V v_level_249 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  V v_defaults_2419 = heff_env(self)[4];
  heff_drop(v_u_2420);
  heff_clo_take(self, 5);
  V v_xs_2421 = heff_take_field(v_fieldTypes_2414, 2);
  V v_m_2422 = heff_arrayLength_lent(v_xs_2421, 0);
  V v_t_2435;
  if ((heff_peek_word(v_m_2422) <= ((int64_t)0ULL))) {
    heff_drop(v_g_247);
    heff_drop(v_xs_2421);
    v_t_2435 = heff_arrayGenerate(v_m_2422, ((V)&g_heff_2eelab_2erules_2erecordOf_lam1_clo));
  } else {
    V v_t_2424 = heff_arrayIndex_lent(v_xs_2421, MK_INT(0LL), 2);
    V v_y_2433 = heff_clo_n(g_heff_2eelab_2erules_2erecordOf_lam2, 1, 2, (V[]){heff_dup(v_g_247), v_t_2424});
    V v_t_2434 = heff_arrayKeepsAs_lent(v_xs_2421, v_y_2433, 0);
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_m_2422);
      heff_drop(v_t_2434);
      v_t_2435 = ({ V a_0 = v_g_247; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2421, MK_INT(0LL), v_y_2433); V r_ = (g_heff_2eelab_2erules_2erecordOf_24map0(a_0, a_1, a_2)); heff_drop(v_g_247); r_; });
    } else {
      heff_drop(v_t_2434);
      v_t_2435 = ({ V a_0 = v_xs_2421; V a_1 = v_g_247; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2422, v_y_2433); V r_ = (g_heff_2eelab_2erules_2erecordOf_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2421); heff_drop(v_g_247); r_; });
    }
  }
  V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2414, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_249, v_vs_248, v_t_2436, v_defaults_2419})});
}
V g_heff_2eelab_2erules_2erecordOf_24generate0_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erecordOf_24generate0_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordOf_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordOf_24generate0_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordOf_24generate0(V v_xs_240, V v_g_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_2413 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2erules_2erecordOf_24generate0_lam0, 1, 2, (V[]){heff_dup(v_g_241), v_t_244}));
      V t_0 = v_xs_240;
      V t_1 = v_g_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_2413;
      v_xs_240 = t_0;
      v_g_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_2413 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2erules_2erecordOf_24generate0_lam1, 1, 2, (V[]){heff_dup(v_g_241), v_t_244}));
    V t_0 = v_xs_240;
    V t_1 = v_g_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_2413;
    v_xs_240 = t_0;
    v_g_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erules_2erecordOf_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordOf_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordOf_24generate0_lam0(V self, V *args) {
  V v_vs2_245 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs2_245; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs2_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2412;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2412 = v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        v_t_2412 = heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        v_t_2412 = v_x_2411;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2412, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2erules_2erecordOf_24generate0_lam1(V self, V *args) {
  V v_vs2_245 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs2_245; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs2_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2412;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2412 = v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        v_t_2412 = heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        v_t_2412 = v_x_2411;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2412, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_24map0_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eselfAdvance_24map0_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_24map0_entry, 5, 0};

V g_heff_2eelab_2erules_2eselfAdvance_24map0(V v_done_240, V v_gk_241, V v_a_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_f_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      HeffT2 v_t_246 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_240, v_f_245));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        V v_t_2412;
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_f_245);
          V v_v_249 = v_field_248;
          v_t_2412 = heff_tag_n(TAG_Nom, 1, (V[]){v_v_249});
        } else {
          heff_drop(v_field_248);
          V v_t_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_gk_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_24map0_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
          v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_f_245; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_f_245); r_; });
        }
        V t_0 = v_done_240;
        V t_1 = v_gk_241;
        V t_2 = v_a_242;
        int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
        V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2412);
        v_done_240 = t_0;
        v_gk_241 = t_1;
        v_a_242 = t_2;
        v_i_243 = t_3;
        v_a_244 = t_4;
        goto top_TAG_InRange;
      }
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_f_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    HeffT2 v_t_246 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_240, v_f_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2412;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_f_245);
        V v_v_249 = v_field_248;
        v_t_2412 = heff_tag_n(TAG_Nom, 1, (V[]){v_v_249});
      } else {
        heff_drop(v_field_248);
        V v_t_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_gk_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_24map0_lam1, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
        v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_f_245; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_f_245); r_; });
      }
      V t_0 = v_done_240;
      V t_1 = v_gk_241;
      V t_2 = v_a_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2412);
      v_done_240 = t_0;
      v_gk_241 = t_1;
      v_a_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top;
    }
  } else {
    return v_a_244;
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eselfAdvance_24map0(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eselfAdvance_24map0_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_a_242;
}
V g_heff_2eelab_2erules_2eselfAdvance_24map0_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_a_242;
}
Clo g_heff_2eelab_2erules_2ecodeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecodeAt_entry, 5, 0};

V g_heff_2eelab_2erules_2ecodeAt(V v_n_240, V v_at_241, V v_places_242, V v_m_243, V v_i_244) {
top: ;
  V v_dflt_245 = heff_take_field(v_m_243, 3);
  V v_el_246 = heff_get_n(v_m_243, 2, 5);
  V v_t_247 = v_dflt_245;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_n_240);
    heff_drop(v_t_247);
    V v_t_248 = (g_list_2etake(v_i_244, v_places_242));
    V v_t_249 = (g_heff_2eelab_2erules_2efieldIdxs(v_at_241, v_t_248));
    HeffT2 v_t_2410 = ({ V a_0 = v_t_249; HeffT2 r_ = (g_heff_2eelab_2eunify_2esubstOf_24cpr(a_0)); heff_drop(v_t_249); r_; });
    {
      V v_field_2411 = v_t_2410.f[0];
      heff_drop(v_t_2410.f[1]);
      return heff_tail(v_field_2411, 2, (V[]){MK_INT(0LL), heff_get_n(v_el_246, 0, 2)});
    }
  } else {
    heff_drop(v_places_242);
    heff_drop(v_i_244);
    heff_drop(v_t_247);
    V v_t_2413 = heff_get_n(v_el_246, 0, 2);
    if (heff_intEq_c_lent(v_at_241, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_at_241);
      return v_t_2413;
    } else {
      V v_t_2414 = (g_list_2emap_24f783067987x1926181389(heff_dup(v_n_240), MK_INT(1LL), v_at_241, MK_INT(0LL), heff_intSub(v_n_240, MK_INT(1LL))));
      HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; HeffT2 r_ = (g_heff_2eelab_2eunify_2esubstOf_24cpr(a_0)); heff_drop(v_t_2414); r_; });
      {
        V v_field_2416 = v_t_2415.f[0];
        heff_drop(v_t_2415.f[1]);
        return heff_tail(v_field_2416, 2, (V[]){MK_INT(0LL), v_t_2413});
      }
    }
  }
}
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecodeAt(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2estandsFor_str0, 24, "every tag `_` stands for");

static V g_heff_2eelab_2erules_2estandsFor_val;
static HEFF_ONCE g_heff_2eelab_2erules_2estandsFor_st;
static V g_heff_2eelab_2erules_2estandsFor_init(void) {
  return ((V)&g_heff_2eelab_2erules_2estandsFor_str0);
}
V g_heff_2eelab_2erules_2estandsFor_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2estandsFor_st)) return g_heff_2eelab_2erules_2estandsFor_val;
  return heff_global(&g_heff_2eelab_2erules_2estandsFor_val, &g_heff_2eelab_2erules_2estandsFor_st, g_heff_2eelab_2erules_2estandsFor_init);
}
Clo g_heff_2eelab_2erules_2etermSizeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etermSizeGo_entry, 3, 0};

V g_heff_2eelab_2erules_2etermSizeGo(V v_box_24lim_240, V v_box_24n_241, V v_x3_242) {
  int64_t v_lim_240 = heff_peek_word(v_box_24lim_240);
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_box_word(v_n_241);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if ((v_lim_240 < v_n_241)) {
      heff_drop(v_t_243);
      heff_drop(v_rest_244);
      return heff_box_word(v_n_241);
    } else {
      V v_t_245 = (g_heff_2eelab_2erules_2etermParts(v_t_243, v_rest_244));
      int64_t t_0 = v_lim_240;
      int64_t t_1 = (v_n_241 + ((int64_t)1ULL));
      V t_2 = v_t_245;
      v_lim_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2etermSizeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2etermSizeGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str0, 5, "type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str1, 27, " too large for its universe");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str2, 5, "type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str3, 27, " too large for its universe");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str4, 5, "type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str5, 27, " too large for its universe");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str6, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str7, 22, " at non-universe type ");
V g_heff_2eelab_2erules_2euniverseAt_lam0(V self, V *args);
V g_heff_2eelab_2erules_2euniverseAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseAt_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseAt_entry, 7, 0};

V g_heff_2eelab_2erules_2euniverseAt(V v_sp_240, V v_note_241, V v_e_242, V v_a_243, V v_ty_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_243)));
  switch (heff_tag_of(v_t_247)) {
  case TAG_LikeU: {
    V v_u_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24LikeU = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_a_243);
    V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_ty_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x1_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_t_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2411 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2412 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    switch (heff_tag_of(v_u_248)) {
    case TAG_SmallU: {
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Small: {
        heff_drop(v_sp_240);
        heff_drop(v_note_241);
        heff_drop(v_e_242);
        heff_drop_rec(v_z_245, 3);
        V v_t_2414 = heff_tag_at_n(v_ru_24t_247_24LikeU, TAG_SCode, 1, (V[]){heff_dup(heff_rfield(v_ty_244, 0))});
        return heff_tail(v_z_246, 1, (V[]){({ V rv_0 = v_t_2414; V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2euniverseAt_lam0, 1, 1, (V[]){heff_dup(v_ty_244)}); V rr_ = heff_rec_reuse_nf(v_ty_244, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
      }
      case TAG_Large: {
        V v_t_2417 = (g_heff_2eelab_2erules_2etyStrM(v_e_242, v_ty_244));
        V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str0), v_t_2417), ((V)&g_heff_2eelab_2erules_2euniverseAt_str1));
        return (g_heff_2eelab_2erules_2etooLarge_24tok1(v_ru_24t_247_24LikeU, v_sp_240, v_t_2418, v_note_241, v_z_245, v_z_246));
      }
      case TAG_TopL: {
        V v_t_2419 = (g_heff_2eelab_2erules_2etyStrM(v_e_242, v_ty_244));
        V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str2), v_t_2419), ((V)&g_heff_2eelab_2erules_2euniverseAt_str3));
        return (g_heff_2eelab_2erules_2etooLarge_24tok1(v_ru_24t_247_24LikeU, v_sp_240, v_t_2420, v_note_241, v_z_245, v_z_246));
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    case TAG_LargeU: {
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Small: {
        heff_drop(v_sp_240);
        heff_drop(v_note_241);
        heff_drop(v_e_242);
        heff_drop_rec(v_z_245, 3);
        V v_t_2421 = heff_tag_at_n(v_ru_24t_247_24LikeU, TAG_SCode, 1, (V[]){heff_dup(heff_rfield(v_ty_244, 0))});
        return heff_tail(v_z_246, 1, (V[]){({ V rv_0 = v_t_2421; V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2euniverseAt_lam1, 1, 1, (V[]){heff_dup(v_ty_244)}); V rr_ = heff_rec_reuse_nf(v_ty_244, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
      }
      case TAG_Large: {
        heff_drop(v_sp_240);
        heff_drop(v_note_241);
        heff_drop(v_e_242);
        heff_drop_rec(v_z_245, 3);
        V v_t_2424 = heff_tag_at_n(v_ru_24t_247_24LikeU, TAG_SCode, 1, (V[]){heff_dup(heff_rfield(v_ty_244, 0))});
        return heff_tail(v_z_246, 1, (V[]){({ V rv_0 = v_t_2424; V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2euniverseAt_lam2, 1, 1, (V[]){heff_dup(v_ty_244)}); V rr_ = heff_rec_reuse_nf(v_ty_244, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
      }
      case TAG_TopL: {
        V v_t_2427 = (g_heff_2eelab_2erules_2etyStrM(v_e_242, v_ty_244));
        V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str4), v_t_2427), ((V)&g_heff_2eelab_2erules_2euniverseAt_str5));
        return (g_heff_2eelab_2erules_2etooLarge_24tok1(v_ru_24t_247_24LikeU, v_sp_240, v_t_2428, v_note_241, v_z_245, v_z_246));
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_u_248);
    }
  }
  default: {
    heff_drop(v_note_241);
    heff_drop(v_t_247);
    V v_t_2429 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2430 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str6), v_t_2429), ((V)&g_heff_2eelab_2erules_2euniverseAt_str7));
    V v_msg_2432 = heff_strAppend(v_t_2431, v_t_2430);
    V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2432, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2436, v_z_246});
  }
  }
}
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2euniverseAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2euniverseAt_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_ty_244 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_call(heff_get_n(v_ty_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(v_t_2416));
}
V g_heff_2eelab_2erules_2euniverseAt_lam1(V self, V *args) {
  V v_u_2422 = args[0];
  V v_ty_244 = heff_env(self)[0];
  heff_drop(v_u_2422);
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tr(heff_call(heff_get_n(v_ty_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(v_t_2423));
}
V g_heff_2eelab_2erules_2euniverseAt_lam2(V self, V *args) {
  V v_u_2425 = args[0];
  V v_ty_244 = heff_env(self)[0];
  heff_drop(v_u_2425);
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tr(heff_call(heff_get_n(v_ty_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(v_t_2426));
}
Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_x_247 = v_y_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_249;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eundoneTo_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eundoneTo_24tok1_entry, 5, 0};

V g_heff_2eelab_2erules_2eundoneTo_24tok1(V v_tok_240, V v_before_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eundoneTo_24tok1_lam0, 1, 1, (V[]){v_before_241})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2eundoneTo_24tok1_lam1, 1, 4, (V[]){v_malg_245, v_bind_246, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eundoneTo_24tok1(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_before_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_6 = heff_get_n(v_c_247, 6, 9); V rr_ = heff_rec_reuse_nf(v_before_241, 447ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_drop(v_x_2419);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_malg_245 = heff_env(self)[1];
  V v_bind_246 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_drop(v_x_2415);
  heff_clo_take(self, 4);
  V v_t_2416 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2417}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eundoneTo_24tok1_lam3, 1, 1, (V[]){v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eundoneTo_24tok1_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_t_2412 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(v_bind_246);
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eundoneTo_24tok1_lam2, 1, 4, (V[]){v_waiting_242, v_malg_245, v_bind_246, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}