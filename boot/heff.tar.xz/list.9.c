// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Dim 16148
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_FtAny 18156
#define TAG_HS 9084
#define TAG_ITl 20301
#define TAG_ImplicitParam 51130
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkSegment 38079
#define TAG_Plain 3036
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_TagVariant 25174
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_assoc 294479919
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_field 298786068
#define LBL_filter 672649891
#define LBL_first 298798794
#define LBL_from 9647217
#define LBL_groups 709681407
#define LBL_hidden 729654485
#define LBL_id 10114
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_outcome 1272833429
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_version 583465758
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2ecommands_2ereaches(V, V);
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereaches_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2erepr_2eentered(V, V);
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eentered_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2eworker_2eweighOne(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighOne_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc(V);
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2einlineDoc_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s195269671x277329476(V, V);
V g_list_2eany_24s195269671x277329476_entry(V self, V *a);
extern Clo g_list_2eany_24s195269671x277329476_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s2129318370x1621070635(V, V);
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a);
extern Clo g_list_2eany_24s2129318370x1621070635_clo;
V g_list_2eany_24s698149710x1824282627(V, V, V, V);
V g_list_2eany_24s698149710x1824282627_entry(V self, V *a);
extern Clo g_list_2eany_24s698149710x1824282627_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efilter_24s1623010005x1805617852_24dps(V, V);
V g_list_2efilter_24s1623010005x1805617852_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_24dps_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s2128134357x1680551385_24dps(V, V, V);
V g_list_2efilter_24s2128134357x1680551385_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_24dps_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s50027113x1989932102_24dps(V, V, V);
V g_list_2efilter_24s50027113x1989932102_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_24dps_clo;
V g_list_2efilter_24s501010704x477973552_24dps(V, V, V, V, V);
V g_list_2efilter_24s501010704x477973552_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s501010704x477973552_24dps_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f488322910x556193579(V, V, V);
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a);
extern Clo g_list_2efoldl_24f488322910x556193579_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1022228162x792599878(V, V);
V g_list_2efoldl_24s1022228162x792599878_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1022228162x792599878_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1183026345x1475160630(V, V);
V g_list_2efoldl_24s1183026345x1475160630_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1183026345x1475160630_clo;
V g_list_2efoldl_24s1324334883x853570153(V, V);
V g_list_2efoldl_24s1324334883x853570153_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1324334883x853570153_clo;
V g_list_2efoldl_24s1324334883x853570153_24scalars(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1324334883x853570153_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1324334883x853570153_24scalars_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2efoldl_24s2086705387x1592057803(V, V, V, V, V);
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2086705387x1592057803_clo;
V g_list_2efoldl_24s2119339822x1169006432(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s2119339822x1169006432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2119339822x1169006432_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s270563368x59505005(V, V);
V g_list_2efoldl_24s270563368x59505005_entry(V self, V *a);
extern Clo g_list_2efoldl_24s270563368x59505005_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s560581624x1100110660(V, V, V);
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a);
extern Clo g_list_2efoldl_24s560581624x1100110660_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2emap_24f1016251237x587084191_24dps(V, V, V, V);
V g_list_2emap_24f1016251237x587084191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_24dps_clo;
V g_list_2emap_24f1133029339x682401273_24dps(V, V);
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_24dps_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f1352858702x862623587(V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_clo;
V g_list_2emap_24f1352858702x862623587_24dps(V, V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_24dps_clo;
V g_list_2emap_24f1502491305x440718220(V, V);
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_clo;
V g_list_2emap_24f1502491305x440718220_24dps(V, V, V);
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_24dps_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1093229560x1486136516_24dps(V, V);
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_24dps_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s1266088736x105832553_24dps(V, V, V);
V g_list_2emap_24s1266088736x105832553_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_24dps_clo;
V g_list_2emap_24s1418045490x2076674085(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_clo;
V g_list_2emap_24s1418045490x2076674085_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_24dps_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s1427000880x1925304966_24dps(V, V, V);
V g_list_2emap_24s1427000880x1925304966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_24dps_clo;
V g_list_2emap_24s1498757180x165099811_24dps(V, V);
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_24dps_clo;
V g_list_2emap_24s1727184187x1048417382_24dps(V, V);
V g_list_2emap_24s1727184187x1048417382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1727184187x1048417382_24dps_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1767134203x962737276(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_clo;
V g_list_2emap_24s1767134203x962737276_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_24dps_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1845612977x612508518_24dps(V, V);
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_24dps_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s241620538x329208622_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_24dps_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s275211812x1381242052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s456747242x756515627_24dps(V, V);
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_24dps_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s766426360x2144213627(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_clo;
V g_list_2emap_24s766426360x2144213627_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24s865484684x739952503_24dps(V, V);
V g_list_2emap_24s865484684x739952503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_24dps_clo;
V g_list_2emerge_24s1716485482x1012130009(V, V);
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_clo;
V g_list_2emerge_24s1716485482x1012130009_24dps(V, V, V);
V g_list_2emerge_24s1716485482x1012130009_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_24dps_clo;
V g_list_2emerge_24s1840066165x1513718921(V, V);
V g_list_2emerge_24s1840066165x1513718921_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_clo;
V g_list_2emerge_24s1840066165x1513718921_24dps(V, V, V);
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo;
V g_list_2emerge_24s2063716145x1843377885(V, V);
V g_list_2emerge_24s2063716145x1843377885_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_regex_2ebranchOf(V);
V g_regex_2ebranchOf_entry(V self, V *a);
extern Clo g_regex_2ebranchOf_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24dps(v_f_240, v_xs_244, v_ys_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_list_2ezipWith_24s1876717925x1404326288_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
Clo g_list_2eany_24s2065989517x1307020881_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2065989517x1307020881_entry, 2, 0};

V g_list_2eany_24s2065989517x1307020881(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s2065989517x1307020881(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s120814613x1439363162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s120814613x1439363162_entry, 2, 0};

V g_list_2eany_24s120814613x1439363162(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s120814613x1439363162(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1835183789x486277886_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_24dps_entry, 2, 0};

V g_list_2emap_24s1835183789x486277886_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str0, 6, "import");
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str1, 0, "");
Clo g_list_2emap_24s1845612977x612508518_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1845612977x612508518_24dps_entry, 2, 0};

V g_list_2emap_24s1845612977x612508518_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_242, 2, 3), 1, 2);
    V v_t_246 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s1845612977x612508518_24dps_str0), ((V)&g_list_2emap_24s1845612977x612508518_24dps_str1), v_t_244, v_t_245, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1845612977x612508518_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s1687051711x1677682329_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1687051711x1677682329_entry, 2, 0};

V g_list_2eall_24s1687051711x1677682329(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        v_a_2411 = (g_heff_2esyntax_2epresyntax_2esegmentOdd(v_a_247, v_a_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_a_2412, v_lit_240, 1)) {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_lit_240);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s1687051711x1677682329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1258450377x973220636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_24dps_entry, 2, 0};

V g_list_2emap_24s1258450377x973220636_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1992667171x110340492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_entry, 1, 0};

V g_list_2emap_24s1992667171x110340492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1992667171x110340492_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492(a[0]);
}
Clo g_list_2emap_24s1059370217x1267747283_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_24dps_entry, 2, 0};

V g_list_2emap_24s1059370217x1267747283_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s549405518x243689326_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_entry, 1, 0};

V g_list_2emap_24s549405518x243689326(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_EVar: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_244, 0ULL, 4);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_244, 0ULL, 1);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2439 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2440 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2439, heff_hole()});
    V v_u_2441 = (g_list_2emap_24s549405518x243689326_24dps(v_xs_242, heff_dup(v_cell_2440)));
    heff_drop(v_u_2441);
    return v_cell_2440;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_24dps_entry, 2, 0};

V g_list_2emap_24s73473062x206541869_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1123370502x1982532655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_entry, 1, 0};

V g_list_2emap_24s1123370502x1982532655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1123370502x1982532655_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655(a[0]);
}
Clo g_list_2efoldl_24s2145639387x28888241_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2145639387x28888241_entry, 4, 0};

V g_list_2efoldl_24s2145639387x28888241(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkArm: {
      V v_a_248 = heff_field(v_x_244, 2);
      heff_take_n(v_x_244, 4ULL, 3);
      v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_248}), v_z_242});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2145639387x28888241(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s1583117218x1471782720_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1583117218x1471782720_entry, 2, 0};

V g_list_2efoldl_24s1583117218x1471782720(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s170109517x1206653089(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1583117218x1471782720(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s241620538x329208622_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s241620538x329208622_24dps_entry, 8, 0};

V g_list_2emap_24s241620538x329208622_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s241620538x329208622_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s865198748x12535471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s865198748x12535471_entry, 2, 0};

V g_list_2efoldl_24s865198748x12535471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s865198748x12535471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1729297000x968708966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_entry, 1, 0};

V g_list_2emap_24s1729297000x968708966(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_241, 0), heff_get_n(v_x_241, 2, 5)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1729297000x968708966_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966(a[0]);
}
Clo g_list_2efoldl_24s1183026345x1475160630_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1183026345x1475160630_entry, 2, 0};

V g_list_2efoldl_24s1183026345x1475160630(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2efuse_2econsumerOf_24cpr(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_249;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_248 = v_field_246;
        v_t_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), v_a_248));
      } else {
        heff_drop(v_field_246);
        v_t_249 = v_z_240;
      }
    }
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1183026345x1475160630_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1183026345x1475160630(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s195269671x277329476_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s195269671x277329476_entry, 2, 0};

V g_list_2eany_24s195269671x277329476(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intEq_c_lent(v_t_246, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s195269671x277329476_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s195269671x277329476(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2086705387x1592057803_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2086705387x1592057803_entry, 5, 0};

V g_list_2efoldl_24s2086705387x1592057803(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_heff_2ecompile_2eworker_2eweighOne(heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_z_243, heff_dup(v_x_245)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_247;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_list_2efoldl_24s2086705387x1592057803(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_24dps_entry, 3, 0};

V g_list_2ezipWith_24s151204990x680105425_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_t_248;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = v_x_243;
      } else {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1149721393x617397893_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = heff_strAppend(v_x_244, heff_strAppend(heff_dup(v_lit_240), v_y_246));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s649333309x1802289391_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_24dps_entry, 2, 0};

V g_list_2emap_24s649333309x1802289391_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eemit_2ehostLineOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1427000880x1925304966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1427000880x1925304966_entry, 2, 0};

V g_list_2emap_24s1427000880x1925304966(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2411 = heff_strAppend(v_t_246, heff_strAppend(heff_dup(v_lit_240), v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1427000880x1925304966_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1427000880x1925304966(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_entry, 1, 0};

V g_list_2emap_24s640776339x1223679834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s640776339x1223679834_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834(a[0]);
}
Clo g_list_2emap_24s275211812x1381242052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s275211812x1381242052_24dps_entry, 8, 0};

V g_list_2emap_24s275211812x1381242052_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2417 = heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2416));
    V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), v_t_2417);
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2418), heff_hole()});
    V v_u_2420 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s275211812x1381242052_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s2119339822x1169006432_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2119339822x1169006432_entry, 10, 0};

V g_list_2efoldl_24s2119339822x1169006432(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get_n(v_a_2412, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2414, heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2417;
    if (heff_intLt_c_lent(v_a_2415, v_lit_242, 0)) {
      heff_drop(v_a_2415);
      v_t_2417 = v_a_2414;
    } else {
      v_t_2417 = heff_strSlice_lent(v_a_2414, v_lit_243, v_a_2415, 5);
    }
    V v_a_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2420 = heff_get_n(v_a_2418, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2421 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2420, heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2423;
    if (heff_intLt_c_lent(v_a_2421, v_lit_246, 0)) {
      heff_drop(v_a_2421);
      v_t_2423 = v_a_2420;
    } else {
      v_t_2423 = heff_strSlice_lent(v_a_2420, v_lit_247, v_a_2421, 5);
    }
    HeffT2 v_t_2424 = ({ V a_0 = v_z_248; V a_1 = v_t_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2429;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_a_2428 = v_field_2426;
        v_t_2429 = v_a_2428;
      } else {
        heff_drop(v_field_2426);
        v_t_2429 = NTAG(TAG_Nil);
      }
    }
    V v_t_2430 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_248, v_t_2417, heff_tag_at_n(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2429})));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2430;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s2119339822x1169006432_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a7 = a[7]; V r = g_list_2efoldl_24s2119339822x1169006432(a[0], a[1], a[2], a3, a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a3); heff_drop(a7); return r;
}
Clo g_list_2emap_24s766426360x2144213627_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s766426360x2144213627_entry, 9, 0};

V g_list_2emap_24s766426360x2144213627(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2emodulePart(heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_x_249));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s766426360x2144213627_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24s766426360x2144213627_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24s766426360x2144213627(a[0], a[1], a2, a3, a4, a5, a6, a7, a[8]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2eany_24s698149710x1824282627_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s698149710x1824282627_entry, 4, 0};

V g_list_2eany_24s698149710x1824282627(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s698149710x1824282627_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s698149710x1824282627(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str0, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str1, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str2, 20, "#define HEFF_THREADS");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str3, 20, "#define HEFF_THREADS");
Clo g_list_2eany_24s762674996x1009180162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s762674996x1009180162_entry, 1, 0};

V g_list_2eany_24s762674996x1009180162(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 1));
    V v_t_244 = ({ V b_0 = ((V)&g_list_2eany_24s762674996x1009180162_str0); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2eany_24s762674996x1009180162_str1), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
    V v_t_245 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_list_2eany_24s762674996x1009180162_str2); V b_2 = ((V)&g_list_2eany_24s762674996x1009180162_str3); V a_3 = v_t_244; V r_ = (g_list_2eany_24s698149710x1824282627(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s762674996x1009180162(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1022228162x792599878_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1022228162x792599878_entry, 2, 0};

V g_list_2efoldl_24s1022228162x792599878(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s270563368x59505005(v_z_240, heff_dup(heff_rfield(v_x_242, 0))));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1022228162x792599878_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1022228162x792599878(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1324334883x853570153_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1324334883x853570153_entry, 2, 0};

V g_list_2efoldl_24s1324334883x853570153(V v_z_240, V v_x3_241) {
top: ;
  return (g_list_2efoldl_24s1324334883x853570153_24scalars(heff_dup(heff_rfield(v_z_240, 0)), heff_dup(heff_rfield(v_z_240, 1)), heff_dup(heff_rfield(v_z_240, 2)), heff_dup(heff_rfield(v_z_240, 3)), heff_dup(heff_rfield(v_z_240, 4)), heff_dup(heff_rfield(v_z_240, 5)), heff_dup(heff_rfield(v_z_240, 6)), heff_get_n(v_z_240, 7, 8), v_x3_241));
}
V g_list_2efoldl_24s1324334883x853570153_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1324334883x853570153(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s265594371x763318798_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_24dps_entry, 2, 0};

V g_list_2emap_24s265594371x763318798_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_take_field(v_x_242, 1)});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_242, 0, 4), v_t_244});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s1840066165x1513718921_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1840066165x1513718921_entry, 2, 0};

V g_list_2emerge_24s1840066165x1513718921(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 10);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1840066165x1513718921_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1840066165x1513718921_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1840066165x1513718921_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1840066165x1513718921(a[0], a[1]);
}
Clo g_list_2emap_24s1418045490x2076674085_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418045490x2076674085_entry, 10, 0};

V g_list_2emap_24s1418045490x2076674085(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_take_field(v_x_2410, 1);
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_AssocLeft: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2414 = heff_take_field(v_x_2410, 3);
    V v_t_2415;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(v_lit_245);
    }
    V v_t_2416 = heff_take_field(v_x_2410, 2);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nil: {
      v_t_2419 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      V v_a_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2417; V a_2 = v_a_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2418); r_; });
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_246), v_t_2419));
    V v_t_2421 = heff_strAppend(heff_intShow(v_t_2413), v_t_2420);
    V v_t_2422 = heff_strAppend(heff_get_n(v_x_2410, 0, 5), heff_strAppend(heff_dup(v_lit_240), v_t_2421));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s1418045490x2076674085_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1418045490x2076674085(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s467798769x1763085075_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_entry, 1, 0};

V g_list_2emap_24s467798769x1763085075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s467798769x1763085075_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075(a[0]);
}
Clo g_list_2efoldl_24s560581624x1100110660_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s560581624x1100110660_entry, 3, 0};

V g_list_2efoldl_24s560581624x1100110660(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s560581624x1100110660(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s44351024x1408738471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s44351024x1408738471_entry, 2, 0};

V g_list_2efoldl_24s44351024x1408738471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2eelab_2elocals_2edeclaration(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V t_0 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s44351024x1408738471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1716485482x1012130009_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1716485482x1012130009_entry, 2, 0};

V g_list_2emerge_24s1716485482x1012130009(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1716485482x1012130009_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1716485482x1012130009_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1716485482x1012130009(a[0], a[1]);
}
Clo g_list_2emap_24s1266088736x105832553_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1266088736x105832553_24dps_entry, 3, 0};

V g_list_2emap_24s1266088736x105832553_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_a_246 = heff_take_field(v_x_243, 1);
    V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_243, 0, 2)});
    V v_t_248 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), v_t_247, NTAG(TAG_Nothing)});
    V v_a_249 = heff_take_field(v_a_246, 0);
    V v_a_2410 = heff_intSub(heff_dup(heff_rfield(v_a_246, 1)), heff_strLength_lent(v_a_245, 0));
    V v_t_2412;
    if (heff_intLe_c_lent(v_a_249, v_a_2410, 0)) {
      heff_drop(v_a_249);
      v_t_2412 = v_a_2410;
    } else {
      heff_drop(v_a_2410);
      v_t_2412 = v_a_249;
    }
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_a_246, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_248, v_a_245, v_t_2413}), heff_hole()});
    V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2414;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1266088736x105832553_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1266088736x105832553_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1055307687x247454614_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_entry, 2, 0};

V g_list_2emap_24s1055307687x247454614(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2eequationKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1055307687x247454614_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1055307687x247454614(a[0], a[1]);
}
Clo g_list_2efilter_24s2128134357x1680551385_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2128134357x1680551385_entry, 2, 0};

V g_list_2efilter_24s2128134357x1680551385(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s2128134357x1680551385_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s2128134357x1680551385(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s2128134357x1680551385_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2128134357x1680551385_24dps_entry, 3, 0};

V g_list_2efilter_24s2128134357x1680551385_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2128134357x1680551385_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s2128134357x1680551385_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s50027113x1989932102_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s50027113x1989932102_entry, 2, 0};

V g_list_2efilter_24s50027113x1989932102(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s50027113x1989932102_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s50027113x1989932102(a[0], a[1]);
}
Clo g_list_2efoldl_24s1002907040x997927369_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1002907040x997927369_entry, 2, 0};

V g_list_2efoldl_24s1002907040x997927369(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2418;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_z_240, 0)))) {
      HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_rfield(v_x_242, 1)));
      V v_t_2410;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_a_249 = v_field_247;
          v_t_2410 = v_a_249;
        } else {
          heff_drop(v_field_247);
          v_t_2410 = NTAG(TAG_Nil);
        }
      }
      HeffT2 v_t_2411 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_rfield(v_z_240, 1)));
      V v_t_2416;
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_a_2415 = v_field_2413;
          v_t_2416 = v_a_2415;
        } else {
          heff_drop(v_field_2413);
          v_t_2416 = NTAG(TAG_Nil);
        }
      }
      V v_t_2417 = ({ V a_0 = v_t_2410; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2410); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop_rec(v_z_240, 3);
        heff_drop(v_t_2417);
        v_t_2418 = heff_dup(v_x_242);
      } else {
        heff_drop(v_t_2417);
        v_t_2418 = v_z_240;
      }
    } else {
      v_t_2418 = v_z_240;
    }
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1002907040x997927369(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1727184187x1048417382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1727184187x1048417382_24dps_entry, 2, 0};

V g_list_2emap_24s1727184187x1048417382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_regex_2ebranchOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1727184187x1048417382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1727184187x1048417382_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2129318370x1621070635_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2129318370x1621070635_entry, 2, 0};

V g_list_2eany_24s2129318370x1621070635(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2ereaches(v_lit_240, heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s2129318370x1621070635(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1498757180x165099811_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1498757180x165099811_24dps_entry, 2, 0};

V g_list_2emap_24s1498757180x165099811_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1498757180x165099811_24dps(a[0], a[1]);
}
Clo g_list_2esortBy_24s196358923x1153659155_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s196358923x1153659155_entry, 1, 0};

V g_list_2esortBy_24s196358923x1153659155(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s196358923x1153659155(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = ({ V a_0 = heff_intDiv(v_t_248, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2410 = (g_list_2esortBy_24s196358923x1153659155(v_t_249));
      return (g_list_2emerge_24s2063716145x1843377885(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s196358923x1153659155(a[0]);
}
Clo g_list_2emap_24s1767134203x962737276_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1767134203x962737276_entry, 8, 0};

V g_list_2emap_24s1767134203x962737276(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    HeffT2 v_t_2410 = (g_json_2eat_24cpr(NTAG(TAG_Nil), v_x_248));
    V v_t_2421;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_a_2414 = v_field_2412;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_JNull: {
          v_t_2421 = heff_dup(v_lit_241);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_242);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_243);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_244);
          break;
        }
        case TAG_JString: {
          V v_a_2418 = heff_field(v_a_2414, 0);
          heff_take_n(v_a_2414, 1ULL, 1);
          v_t_2421 = v_a_2418;
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_245);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_246);
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2421 = heff_dup(v_lit_240);
      }
    }
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_hole()});
    V v_u_2423 = (g_list_2emap_24s1767134203x962737276_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2422)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1767134203x962737276(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1767134203x962737276_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1767134203x962737276_24dps_entry, 9, 0};

V g_list_2emap_24s1767134203x962737276_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    HeffT2 v_t_2411 = (g_json_2eat_24cpr(NTAG(TAG_Nil), v_x_249));
    V v_t_2422;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_a_2415 = v_field_2413;
        switch (heff_tag_of(v_a_2415)) {
        case TAG_JNull: {
          v_t_2422 = heff_dup(v_lit_241);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_a_2415, 0ULL, 1);
          v_t_2422 = heff_dup(v_lit_242);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_a_2415, 0ULL, 1);
          v_t_2422 = heff_dup(v_lit_243);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_a_2415, 0ULL, 1);
          v_t_2422 = heff_dup(v_lit_244);
          break;
        }
        case TAG_JString: {
          V v_a_2419 = heff_field(v_a_2415, 0);
          heff_take_n(v_a_2415, 1ULL, 1);
          v_t_2422 = v_a_2419;
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_a_2415, 0ULL, 1);
          v_t_2422 = heff_dup(v_lit_245);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_a_2415, 0ULL, 1);
          v_t_2422 = heff_dup(v_lit_246);
          break;
        }
        default: heff_nomatch(v_a_2415);
        }
      } else {
        heff_drop(v_field_2413);
        v_t_2422 = heff_dup(v_lit_240);
      }
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2423));
    heff_drop(v_u_2424);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2423;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1767134203x962737276_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1767134203x962737276_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s580776739x648604941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_entry, 1, 0};

V g_list_2emap_24s580776739x648604941(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_args_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 5ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_245, v_args_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s580776739x648604941_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941(a[0]);
}
Clo g_list_2efilter_24s1623010005x1805617852_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1623010005x1805617852_entry, 1, 0};

V g_list_2efilter_24s1623010005x1805617852(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1623010005x1805617852_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1623010005x1805617852(a[0]);
}
Clo g_list_2emap_24s456747242x756515627_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456747242x756515627_entry, 1, 0};

V g_list_2emap_24s456747242x756515627(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2einteractive_2eflagSlot(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s456747242x756515627_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s456747242x756515627_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456747242x756515627(a[0]);
}
Clo g_list_2efilter_24s501010704x477973552_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s501010704x477973552_24dps_entry, 5, 0};

V g_list_2efilter_24s501010704x477973552_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 6);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 2)), 0, 2);
    V v_t_248 = heff_strFind(heff_strOfRunes(v_t_247), heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_248, 2)) {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2411 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s501010704x477973552_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efilter_24s501010704x477973552_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s865484684x739952503_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s865484684x739952503_entry, 1, 0};

V g_list_2emap_24s865484684x739952503(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_x_241, NTAG(TAG_Dim)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s865484684x739952503_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s865484684x739952503_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s865484684x739952503(a[0]);
}
Clo g_list_2emap_24s1093229560x1486136516_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1093229560x1486136516_24dps_entry, 2, 0};

V g_list_2emap_24s1093229560x1486136516_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_x_242, NTAG(TAG_Plain)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1093229560x1486136516_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1352858702x862623587_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1352858702x862623587_entry, 5, 0};

V g_list_2emap_24f1352858702x862623587(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_245)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_take_field(v_x_245, 1), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_get_n(v_x_245, 3, 7)});
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_248), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f1352858702x862623587_24dps(v_lit_240, v_lit_241, v_lit_242, v_p_243, v_xs_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f1352858702x862623587_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1352858702x862623587(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f488322910x556193579_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f488322910x556193579_entry, 3, 0};

V g_list_2efoldl_24f488322910x556193579(V v_z_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245});
      V v_t_248 = (g_heff_2ecompile_2erepr_2eentered(v_z_240, v_x_247));
      V t_0 = v_t_248;
      V t_1 = v_xs_244;
      V t_2 = v_ys_246;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f488322910x556193579(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f783067987x1926181389_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_24dps_entry, 6, 0};

V g_list_2emap_24f783067987x1926181389_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244, V v_d_245) {
top: ;
  if (heff_intLt_c_lent(v_b_244, v_a_243, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_247 = heff_intSub(heff_intSub(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_a_243));
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_t_247, heff_dup(v_lit_242)), heff_hole()});
    V v_u_249 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = heff_intAdd(v_a_243, MK_INT(1LL));
    V t_4 = v_b_244;
    V t_5 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_a_243 = t_3;
    v_b_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
}
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1229912102x1467950109_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_24dps_entry, 3, 0};

V g_list_2emap_24f1229912102x1467950109_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_246 = (g_list_2emap_24s2029035892x1571084362(v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f675617784x1820039874_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f675617784x1820039874_entry, 2, 0};

V g_list_2efoldl_24f675617784x1820039874(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f675617784x1820039874(a[0], a[1]);
}
Clo g_list_2emap_24f1502491305x440718220_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1502491305x440718220_entry, 2, 0};

V g_list_2emap_24f1502491305x440718220(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2emap_24s864521685x1610969087(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ehint(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f1502491305x440718220_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1502491305x440718220(a[0], a[1]);
}
Clo g_list_2emap_24f1133029339x682401273_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1133029339x682401273_24dps_entry, 2, 0};

V g_list_2emap_24f1133029339x682401273_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 2, 3);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 3);
      V v_t_247 = heff_rec_n(3, shape_name__field__use, (V[]){v_t_245, v_t_246, heff_get_n(v_x_242, 1, 2)});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1133029339x682401273_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f1160581125x508466714_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1160581125x508466714_entry, 2, 0};

V g_list_2efoldl_24f1160581125x508466714(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = (g_heff_2esyntax_2efmt_2elayout_2einlineDoc(v_x_242));
    V v_t_245 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1160581125x508466714(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str2, 1, " ");
Clo g_list_2emap_24f1016251237x587084191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1016251237x587084191_24dps_entry, 4, 0};

V g_list_2emap_24f1016251237x587084191_24dps(V v_w_240, V v_line_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_24dps_str0), 2)) {
      heff_drop(v_line_241);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      V v_t_247 = (g_list_2emap_24s1093229560x1486136516(NTAG(TAG_Nil)));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_247}));
    }
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x3_242, 0);
    V v_xs_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_24dps_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_248;
      V t_2 = v_xs_249;
      V t_3 = v_d_243;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_xs_2411 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_241))));
      V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2411; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2411); r_; });
      V v_xs_2413 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_248))));
      V v_t_2414 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2413; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2413); r_; });
      V v_t_2415 = heff_intAdd(heff_intAdd(v_t_2412, MK_INT(1LL)), v_t_2414);
      if (heff_intLe_c_lent(v_t_2415, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2417 = heff_strAppend(v_line_241, heff_strAppend(((V)&g_list_2emap_24f1016251237x587084191_24dps_str2), v_x_248));
        V t_0 = v_w_240;
        V t_1 = v_t_2417;
        V t_2 = v_xs_249;
        V t_3 = v_d_243;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_t_2418 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
        V v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
        V v_u_2421 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2420));
        heff_drop(v_u_2421);
        V t_0 = v_w_240;
        V t_1 = v_x_248;
        V t_2 = v_xs_249;
        V t_3 = v_cell_2420;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2emap_24f1016251237x587084191_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1016251237x587084191_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f556306710x2087456230_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f556306710x2087456230_entry, 4, 0};

V g_list_2efoldl_24f556306710x2087456230(V v_lit_240, V v_z_241, V v_f_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_f_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_242), 1, (V[]){heff_dup(v_x_244)}));
    heff_drop(v_x_246);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_f_242;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_f_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f556306710x2087456230(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}