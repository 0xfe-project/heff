// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CDecl 45531
#define TAG_Dim 16148
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_FtAny 18156
#define TAG_HS 9084
#define TAG_ITl 20301
#define TAG_ImplicitParam 51130
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_Plain 3036
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_assoc 294479919
#define LBL_binders 123633223
#define LBL_broken 566525696
#define LBL_col 308218
#define LBL_def 308863
#define LBL_done 9584713
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_escapes 914714193
#define LBL_first 298798794
#define LBL_hidden 729654485
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_outcome 1272833429
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_renames 1324191545
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_version 583465758
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2ecommands_2enameByteOf(V, V);
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo;
V g_heff_2ebuild_2ecommands_2ereaches(V, V);
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereaches_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eelabWith(V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabWith_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667(V);
V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2erepr_2eentered(V, V);
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eentered_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2esimplify_2egivesItBack(V, V);
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo;
V g_heff_2ecompile_2eworker_2eweighOne(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighOne_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc(V);
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2einlineDoc_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s673599783x290475791(V, V);
V g_list_2eall_24s673599783x290475791_entry(V self, V *a);
extern Clo g_list_2eall_24s673599783x290475791_clo;
V g_list_2eany_24s1934959195x1899752489(V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a);
extern Clo g_list_2eany_24s1934959195x1899752489_clo;
V g_list_2eany_24s2129318370x1621070635(V, V);
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a);
extern Clo g_list_2eany_24s2129318370x1621070635_clo;
V g_list_2eany_24s313956312x193471538(V, V, V, V);
V g_list_2eany_24s313956312x193471538_entry(V self, V *a);
extern Clo g_list_2eany_24s313956312x193471538_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V, V);
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f488322910x556193579(V, V, V);
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a);
extern Clo g_list_2efoldl_24f488322910x556193579_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1113296953x161795409(V, V);
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1113296953x161795409_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513567688x204074300(V, V);
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513567688x204074300_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2efoldl_24s1813831864x676242789(V, V, V, V);
V g_list_2efoldl_24s1813831864x676242789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1813831864x676242789_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s2086705387x1592057803(V, V, V, V, V);
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2086705387x1592057803_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s237252239x317103379_24scalars(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s237252239x317103379_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s237252239x317103379_24scalars_clo;
V g_list_2efoldl_24s326537207x242980421(V, V);
V g_list_2efoldl_24s326537207x242980421_entry(V self, V *a);
extern Clo g_list_2efoldl_24s326537207x242980421_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s560581624x1100110660(V, V, V);
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a);
extern Clo g_list_2efoldl_24s560581624x1100110660_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s655928500x1399206842(V, V);
V g_list_2efoldl_24s655928500x1399206842_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655928500x1399206842_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2ekeepIf_24f1622709115x782387749_24dps(V, V, V);
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo;
V g_list_2ekeepIf_24s1201185697x960477413_24dps(V, V, V);
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2ekeepIf_24s122741325x871243494_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo;
V g_list_2ekeepIf_24s1245654234x191876439(V);
V g_list_2ekeepIf_24s1245654234x191876439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_clo;
V g_list_2ekeepIf_24s1245654234x191876439_24dps(V, V);
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo;
V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo;
V g_list_2ekeepIf_24s1674319799x1081446864_24dps(V, V);
V g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_24dps_clo;
V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V, V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo;
V g_list_2ekeepIf_24s2085003797x1793382462(V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_clo;
V g_list_2ekeepIf_24s2085003797x1793382462_24dps(V, V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s479112018x1726839132(V);
V g_list_2ekeepIf_24s479112018x1726839132_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_clo;
V g_list_2ekeepIf_24s479112018x1726839132_24dps(V, V);
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2ekeepIf_24s512765522x2052101617_24dps(V, V, V);
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo;
V g_list_2emap_24f1016251237x587084191_24dps(V, V, V, V);
V g_list_2emap_24f1016251237x587084191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_24dps_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f1340051005x157438530_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24dps_clo;
V g_list_2emap_24f1502491305x440718220(V, V);
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_clo;
V g_list_2emap_24f1502491305x440718220_24dps(V, V, V);
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_24dps_clo;
V g_list_2emap_24f1832335087x1608171547(V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_clo;
V g_list_2emap_24f1832335087x1608171547_24dps(V, V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_24dps_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24f201346761x152404242_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_24dps_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24f869471183x993026796_24dps(V, V, V, V);
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_24dps_clo;
V g_list_2emap_24f889159142x1775976195(V, V, V, V);
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_clo;
V g_list_2emap_24f889159142x1775976195_24dps(V, V, V, V, V);
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_24dps_clo;
V g_list_2emap_24f922554743x1845028609(V, V);
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_clo;
V g_list_2emap_24f922554743x1845028609_24dps(V, V, V);
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_24dps_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1093229560x1486136516_24dps(V, V);
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_24dps_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1193924222x1531824795_24dps(V, V, V, V);
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_24dps_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s1418045490x2076674085(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_clo;
V g_list_2emap_24s1418045490x2076674085_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_24dps_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s1427000880x1925304966_24dps(V, V, V);
V g_list_2emap_24s1427000880x1925304966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_24dps_clo;
V g_list_2emap_24s148260373x1589531897(V, V, V);
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_clo;
V g_list_2emap_24s148260373x1589531897_24dps(V, V, V, V);
V g_list_2emap_24s148260373x1589531897_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_24dps_clo;
V g_list_2emap_24s1498757180x165099811_24dps(V, V);
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_24dps_clo;
V g_list_2emap_24s1681408447x1763680441_24dps(V, V, V, V);
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_24dps_clo;
V g_list_2emap_24s1727184187x1048417382_24dps(V, V);
V g_list_2emap_24s1727184187x1048417382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1727184187x1048417382_24dps_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1767134203x962737276(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_clo;
V g_list_2emap_24s1767134203x962737276_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_24dps_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1845612977x612508518_24dps(V, V);
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_24dps_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s241620538x329208622_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_24dps_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s275211812x1381242052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_24dps_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s319754340x1392149466_24dps(V, V, V, V, V);
V g_list_2emap_24s319754340x1392149466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_24dps_clo;
V g_list_2emap_24s320194436x1336304593_24dps(V, V, V);
V g_list_2emap_24s320194436x1336304593_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s320194436x1336304593_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s456747242x756515627_24dps(V, V);
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_24dps_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24s698037429x265256386_24dps(V, V);
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_24dps_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s766426360x2144213627(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_clo;
V g_list_2emap_24s766426360x2144213627_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24s865484684x739952503_24dps(V, V);
V g_list_2emap_24s865484684x739952503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_24dps_clo;
V g_list_2emerge_24s2063716145x1843377885(V, V);
V g_list_2emerge_24s2063716145x1843377885_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_clo;
V g_list_2emerge_24s2063716145x1843377885_24tok2(V, V, V);
V g_list_2emerge_24s2063716145x1843377885_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_24tok2_clo;
V g_list_2emerge_24s471518711x1508999958_24dps(V, V, V);
V g_list_2emerge_24s471518711x1508999958_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s471518711x1508999958_24dps_clo;
V g_list_2emerge_24s471518711x1508999958_24tok2(V, V, V);
V g_list_2emerge_24s471518711x1508999958_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s471518711x1508999958_24tok2_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_regex_2ebranchOf(V);
V g_regex_2ebranchOf_entry(V self, V *a);
extern Clo g_regex_2ebranchOf_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24dps(v_f_240, v_xs_244, v_ys_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_list_2ezipWith_24s1876717925x1404326288_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
Clo g_list_2emap_24s1835183789x486277886_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_24dps_entry, 2, 0};

V g_list_2emap_24s1835183789x486277886_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s326537207x242980421_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s326537207x242980421_entry, 2, 0};

V g_list_2efoldl_24s326537207x242980421(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = ({ V b_0 = heff_get_n(v_t_246, 4, 5); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_a_247; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_a_247); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s326537207x242980421_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s326537207x242980421(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str0, 6, "import");
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str1, 0, "");
Clo g_list_2emap_24s1845612977x612508518_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1845612977x612508518_24dps_entry, 2, 0};

V g_list_2emap_24s1845612977x612508518_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_242, 2, 3), 1, 2);
    V v_t_246 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s1845612977x612508518_24dps_str0), ((V)&g_list_2emap_24s1845612977x612508518_24dps_str1), v_t_244, v_t_245, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1845612977x612508518_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1674319799x1081446864_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1674319799x1081446864_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
    switch (heff_tag_of(v_a_247)) {
    case TAG_Nil: {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2410 = heff_field(v_a_247, 0);
      heff_take_n(v_a_247, 1ULL, 2);
      switch (heff_tag_of(v_a_2410)) {
      case TAG_At: {
        V v_a_2412 = heff_field(v_a_2410, 0);
        heff_take_n(v_a_2410, 1ULL, 2);
        switch (heff_tag_of(v_a_2412)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2418 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2417));
          heff_drop(v_u_2418);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2417;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2412, 0ULL, 2);
          V v_cell_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2422 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2421));
          heff_drop(v_u_2422);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2421;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtExpr: {
          V v_a_2423 = heff_field(v_a_2412, 0);
          heff_take_n(v_a_2412, 1ULL, 1);
          V v_t_2424 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_a_2423));
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_drop(v_t_2424);
            V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
            V v_u_2426 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2425));
            heff_drop(v_u_2426);
            V t_0 = v_xs_243;
            V t_1 = v_cell_2425;
            v_x2_240 = t_0;
            v_d_241 = t_1;
            goto top;
          } else {
            heff_drop(v_x_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_t_2424);
            V t_0 = v_xs_243;
            V t_1 = v_d_241;
            v_x2_240 = t_0;
            v_d_241 = t_1;
            goto top;
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2430 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
          heff_drop(v_u_2431);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2430;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2436 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2435));
          heff_drop(v_u_2436);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2435;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_2412);
        }
      }
      default: return heff_nomatch(v_a_2410);
      }
    }
    default: return heff_nomatch(v_a_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1674319799x1081446864_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1258450377x973220636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_24dps_entry, 2, 0};

V g_list_2emap_24s1258450377x973220636_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1992667171x110340492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_entry, 1, 0};

V g_list_2emap_24s1992667171x110340492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1992667171x110340492_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492(a[0]);
}
Clo g_list_2emap_24s1059370217x1267747283_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_24dps_entry, 2, 0};

V g_list_2emap_24s1059370217x1267747283_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s549405518x243689326_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_entry, 1, 0};

V g_list_2emap_24s549405518x243689326(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_EVar: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_244, 0ULL, 4);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2445 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2444, heff_hole()});
    V v_u_2446 = (g_list_2emap_24s549405518x243689326_24dps(v_xs_242, heff_dup(v_cell_2445)));
    heff_drop(v_u_2446);
    return v_cell_2445;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326(a[0]);
}
Clo g_list_2eany_24s1934959195x1899752489_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1934959195x1899752489_entry, 10, 0};

V g_list_2eany_24s1934959195x1899752489(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_242);
    heff_drop(v_lit_245);
    heff_drop(v_lit_247);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_a_2412 = heff_strFind_lent(v_lit_240, v_x_2410, v_lit_241, 0);
    V v_t_2413;
    if (heff_intLt_c_lent(v_a_2412, v_lit_242, 0)) {
      heff_drop(v_a_2412);
      v_t_2413 = heff_dup(v_x_2410);
    } else {
      v_t_2413 = heff_strSlice_lent(v_x_2410, v_lit_243, v_a_2412, 4);
    }
    V v_a_2414 = heff_strFind_lent(v_lit_244, v_lit_245, v_lit_246, 0);
    V v_t_2415;
    if (heff_intLt_c_lent(v_a_2414, v_lit_247, 0)) {
      heff_drop(v_a_2414);
      v_t_2415 = heff_dup(v_lit_245);
    } else {
      v_t_2415 = heff_strSlice_lent(v_lit_245, v_lit_248, v_a_2414, 4);
    }
    if (heff_strEq_c(v_t_2413, v_t_2415)) {
      heff_drop(v_lit_242);
      heff_drop(v_lit_245);
      heff_drop(v_lit_247);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_xs_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_x2_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2eany_24s1934959195x1899752489(a0, a1, a[2], a3, a4, a[5], a6, a[7], a8, a9); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); heff_drop(a6); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emap_24s73473062x206541869_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_24dps_entry, 2, 0};

V g_list_2emap_24s73473062x206541869_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1123370502x1982532655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_entry, 1, 0};

V g_list_2emap_24s1123370502x1982532655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1123370502x1982532655_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655(a[0]);
}
Clo g_list_2efoldl_24s1913417976x1327308136_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1913417976x1327308136_entry, 3, 0};

V g_list_2efoldl_24s1913417976x1327308136(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2447;
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2444);
      v_t_2447 = v_z_241;
    } else {
      heff_drop(v_t_2444);
      V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_t_2446 = (g_heff_2ecompile_2eir_2esizeW(heff_dup(v_lit_240), v_t_2445));
      v_t_2447 = heff_intAdd(v_z_241, v_t_2446);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2447;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1913417976x1327308136(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s673599783x290475791_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s673599783x290475791_entry, 2, 0};

V g_list_2eall_24s673599783x290475791(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2egivesItBack(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s673599783x290475791_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s673599783x290475791(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1813831864x676242789_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1813831864x676242789_entry, 4, 0};

V g_list_2efoldl_24s1813831864x676242789(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_x_244, v_lit_240, 0)) {
      V v_t_246 = (g_heff_2ecompile_2erepr_2efourTo(heff_dup(v_x_244)));
      v_t_247 = heff_intAdd(v_z_242, heff_intMul(heff_dup(v_lit_241), v_t_246));
    } else {
      v_t_247 = v_z_242;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1813831864x676242789_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s1813831864x676242789(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s2145639387x28888241_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2145639387x28888241_entry, 4, 0};

V g_list_2efoldl_24s2145639387x28888241(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkArm: {
      V v_a_248 = heff_field(v_x_244, 2);
      heff_take_n(v_x_244, 4ULL, 3);
      v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_248}), v_z_242});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2145639387x28888241(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s479112018x1726839132_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s479112018x1726839132_entry, 1, 0};

V g_list_2ekeepIf_24s479112018x1726839132(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_RepV: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s479112018x1726839132_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s479112018x1726839132_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s479112018x1726839132(a[0]);
}
Clo g_list_2emap_24s698037429x265256386_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698037429x265256386_entry, 1, 0};

V g_list_2emap_24s698037429x265256386(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s698037429x265256386_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s698037429x265256386_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698037429x265256386(a[0]);
}
Clo g_list_2efoldl_24s1513567688x204074300_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1513567688x204074300_entry, 2, 0};

V g_list_2efoldl_24s1513567688x204074300(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2015232937x23400545(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1513567688x204074300(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s215892288x1392224072_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_24dps_entry, 3, 0};

V g_list_2emap_24s215892288x1392224072_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1245654234x191876439_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1245654234x191876439_entry, 1, 0};

V g_list_2ekeepIf_24s1245654234x191876439(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_241)) {
    case TAG_SLocal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2440 = (g_list_2ekeepIf_24s1245654234x191876439_24dps(v_xs_242, heff_dup(v_cell_2439)));
      heff_drop(v_u_2440);
      return v_cell_2439;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2438);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1245654234x191876439_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1245654234x191876439(a[0]);
}
Clo g_list_2efoldl_24s1583117218x1471782720_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1583117218x1471782720_entry, 2, 0};

V g_list_2efoldl_24s1583117218x1471782720(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s170109517x1206653089(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1583117218x1471782720(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s241620538x329208622_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s241620538x329208622_24dps_entry, 8, 0};

V g_list_2emap_24s241620538x329208622_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s241620538x329208622_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s865198748x12535471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s865198748x12535471_entry, 2, 0};

V g_list_2efoldl_24s865198748x12535471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s865198748x12535471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1729297000x968708966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_entry, 1, 0};

V g_list_2emap_24s1729297000x968708966(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_el_244 = heff_get_n(v_x_241, 2, 5);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, v_el_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s1729297000x968708966_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966(a[0]);
}
Clo g_list_2efoldl_24s2086705387x1592057803_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2086705387x1592057803_entry, 5, 0};

V g_list_2efoldl_24s2086705387x1592057803(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_heff_2ecompile_2eworker_2eweighOne(heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_z_243, heff_dup(v_x_245)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_247;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_list_2efoldl_24s2086705387x1592057803(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_24dps_entry, 3, 0};

V g_list_2ezipWith_24s151204990x680105425_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_t_248;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = v_x_243;
      } else {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s512765522x2052101617_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s512765522x2052101617_entry, 2, 0};

V g_list_2ekeepIf_24s512765522x2052101617(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s512765522x2052101617_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s512765522x2052101617(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1149721393x617397893_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = heff_strAppend(v_x_244, heff_strAppend(heff_dup(v_lit_240), v_y_246));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s319754340x1392149466_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s319754340x1392149466_entry, 4, 0};

V g_list_2emap_24s319754340x1392149466(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_246, v_lit_241, v_lit_242, 1))) {
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_a_247});
      } else {
        heff_drop(v_a_247);
        v_t_248 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s319754340x1392149466_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24s319754340x1392149466(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s122741325x871243494_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s122741325x871243494_entry, 4, 0};

V g_list_2ekeepIf_24s122741325x871243494(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_244, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s122741325x871243494_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s122741325x871243494(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s649333309x1802289391_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_24dps_entry, 2, 0};

V g_list_2emap_24s649333309x1802289391_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eemit_2ehostLineOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1427000880x1925304966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1427000880x1925304966_entry, 2, 0};

V g_list_2emap_24s1427000880x1925304966(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2411 = heff_strAppend(v_t_246, heff_strAppend(heff_dup(v_lit_240), v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1427000880x1925304966_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1427000880x1925304966(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_entry, 1, 0};

V g_list_2emap_24s640776339x1223679834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s640776339x1223679834_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834(a[0]);
}
Clo g_list_2emap_24s275211812x1381242052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s275211812x1381242052_24dps_entry, 8, 0};

V g_list_2emap_24s275211812x1381242052_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2417 = heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2416));
    V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), v_t_2417);
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2418), heff_hole()});
    V v_u_2420 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s275211812x1381242052_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s766426360x2144213627_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s766426360x2144213627_entry, 9, 0};

V g_list_2emap_24s766426360x2144213627(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2emodulePart(heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_x_249));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s766426360x2144213627_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24s766426360x2144213627_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24s766426360x2144213627(a[0], a[1], a2, a3, a4, a5, a6, a7, a[8]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str0, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str1, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str2, 20, "#define HEFF_THREADS");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str3, 20, "#define HEFF_THREADS");
Clo g_list_2eany_24s762674996x1009180162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s762674996x1009180162_entry, 1, 0};

V g_list_2eany_24s762674996x1009180162(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 1));
    V v_t_244 = ({ V b_0 = ((V)&g_list_2eany_24s762674996x1009180162_str0); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2eany_24s762674996x1009180162_str1), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
    V v_t_245 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_list_2eany_24s762674996x1009180162_str2); V b_2 = ((V)&g_list_2eany_24s762674996x1009180162_str3); V a_3 = v_t_244; V r_ = (g_list_2eany_24s313956312x193471538(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s762674996x1009180162(a0); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 7);
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s237252239x317103379_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s237252239x317103379_24scalars_entry, 9, 0};

V g_list_2efoldl_24s237252239x317103379_24scalars(V v_order_240, V v_entries_241, V v_aliases_242, V v_broken_243, V v_ambiguous_244, V v_places_245, V v_hidden_246, V v_instances_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nil: {
    return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_240, v_entries_241, v_aliases_242, v_broken_243, v_ambiguous_244, v_places_245, v_hidden_246, v_instances_247});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x3_248, 0);
    V v_xs_2410 = heff_field(v_x3_248, 1);
    V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(v_broken_243, heff_dup(v_x_249), NTAG(TAG_MkUnit)));
    V t_0 = v_order_240;
    V t_1 = v_entries_241;
    V t_2 = v_aliases_242;
    V t_3 = v_t_2411;
    V t_4 = v_ambiguous_244;
    V t_5 = v_places_245;
    V t_6 = v_hidden_246;
    V t_7 = v_instances_247;
    V t_8 = v_xs_2410;
    v_order_240 = t_0;
    v_entries_241 = t_1;
    v_aliases_242 = t_2;
    v_broken_243 = t_3;
    v_ambiguous_244 = t_4;
    v_places_245 = t_5;
    v_hidden_246 = t_6;
    v_instances_247 = t_7;
    v_x3_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x3_248);
  }
}
V g_list_2efoldl_24s237252239x317103379_24scalars_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_list_2efoldl_24s237252239x317103379_24scalars(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8); heff_drop(a8); return r;
}
Clo g_list_2emap_24s265594371x763318798_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_24dps_entry, 2, 0};

V g_list_2emap_24s265594371x763318798_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_key_245 = heff_get_n(v_x_242, 1, 4);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_name_244, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s655928500x1399206842_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s655928500x1399206842_entry, 2, 0};

V g_list_2efoldl_24s655928500x1399206842(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 6)), heff_dup(heff_rfield(v_x_242, 4))));
    V v_t_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 5), v_t_244));
    V v_t_246 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_t_245; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabWith(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    V v_t_247 = (g_heff_2ebuild_2edriver_2elean(v_t_246));
    V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_248));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s655928500x1399206842_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s655928500x1399206842(a[0], a[1]);
}
Clo g_list_2emap_24s1418045490x2076674085_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418045490x2076674085_entry, 10, 0};

V g_list_2emap_24s1418045490x2076674085(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_id_2412 = heff_take_field(v_x_2410, 0);
    V v_assoc_2413 = heff_take_field(v_x_2410, 1);
    V v_loosest_2414 = heff_take_field(v_x_2410, 3);
    V v_ops_2415 = heff_get_n(v_x_2410, 2, 5);
    V v_t_2416;
    switch (heff_tag_of(v_assoc_2413)) {
    case TAG_AssocLeft: {
      v_t_2416 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2416 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2416 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_assoc_2413);
    }
    V v_t_2417;
    if ((heff_dup(v_loosest_2414) == NTAG(TAG_True))) {
      heff_drop(v_loosest_2414);
      v_t_2417 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_loosest_2414);
      v_t_2417 = heff_dup(v_lit_245);
    }
    V v_t_2420;
    switch (heff_tag_of(v_ops_2415)) {
    case TAG_Nil: {
      v_t_2420 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_ops_2415, 0);
      V v_a_2419 = heff_field(v_ops_2415, 1);
      heff_take_n(v_ops_2415, 3ULL, 2);
      v_t_2420 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2418; V a_2 = v_a_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2419); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2415);
    }
    V v_t_2421 = heff_strAppend(v_t_2417, heff_strAppend(heff_dup(v_lit_246), v_t_2420));
    V v_t_2422 = heff_strAppend(heff_intShow(v_t_2416), v_t_2421);
    V v_t_2423 = heff_strAppend(v_id_2412, heff_strAppend(heff_dup(v_lit_240), v_t_2422));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s1418045490x2076674085_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2424)));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1418045490x2076674085(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s467798769x1763085075_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_entry, 1, 0};

V g_list_2emap_24s467798769x1763085075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s467798769x1763085075_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075(a[0]);
}
Clo g_list_2efoldl_24s560581624x1100110660_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s560581624x1100110660_entry, 3, 0};

V g_list_2efoldl_24s560581624x1100110660(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s560581624x1100110660(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s44351024x1408738471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s44351024x1408738471_entry, 2, 0};

V g_list_2efoldl_24s44351024x1408738471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2eelab_2elocals_2edeclaration(heff_dup(v_x_242)));
    V v_binders_245 = heff_take_field(v_a_244, 0);
    V v_uses_246 = heff_get_n(v_a_244, 1, 2);
    V v_t_247 = (g_prelude_2e_2b_2b(heff_take_field(v_z_240, 0), v_binders_245));
    V v_t_248 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 1, 2), v_uses_246));
    V t_0 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_247, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s44351024x1408738471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s148260373x1589531897_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s148260373x1589531897_entry, 3, 0};

V g_list_2emap_24s148260373x1589531897(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_start_245 = heff_take_field(v_x_243, 0);
    V v_end_246 = heff_get_n(v_x_243, 1, 2);
    V v_t_247 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_248 = v_start_245;
    V v_a_249 = heff_intSub(heff_dup(v_end_246), heff_strLength_lent(v_lit_241, 0));
    V v_t_2410;
    if (heff_intLe_c_lent(v_a_248, v_a_249, 0)) {
      heff_drop(v_a_248);
      v_t_2410 = v_a_249;
    } else {
      heff_drop(v_a_249);
      v_t_2410 = v_a_248;
    }
    V v_t_2411 = heff_rec_n(3, shape_target__name__span, (V[]){v_t_247, heff_dup(v_lit_241), heff_rec_n(2, shape_start__end, (V[]){v_t_2410, v_end_246})});
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s148260373x1589531897_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s148260373x1589531897(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s148260373x1589531897_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s148260373x1589531897_24dps_entry, 4, 0};

V g_list_2emap_24s148260373x1589531897_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_start_246 = heff_take_field(v_x_244, 0);
    V v_end_247 = heff_get_n(v_x_244, 1, 2);
    V v_t_248 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_249 = v_start_246;
    V v_a_2410 = heff_intSub(heff_dup(v_end_247), heff_strLength_lent(v_lit_241, 0));
    V v_t_2411;
    if (heff_intLe_c_lent(v_a_249, v_a_2410, 0)) {
      heff_drop(v_a_249);
      v_t_2411 = v_a_2410;
    } else {
      heff_drop(v_a_2410);
      v_t_2411 = v_a_249;
    }
    V v_t_2412 = heff_rec_n(3, shape_target__name__span, (V[]){v_t_248, heff_dup(v_lit_241), heff_rec_n(2, shape_start__end, (V[]){v_t_2411, v_end_247})});
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s148260373x1589531897_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s148260373x1589531897_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_245)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1950790755x1251737354_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1113296953x161795409_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1113296953x161795409_entry, 2, 0};

V g_list_2efoldl_24s1113296953x161795409(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1113296953x161795409(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1055307687x247454614_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_entry, 2, 0};

V g_list_2emap_24s1055307687x247454614(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2eequationKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1055307687x247454614_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1055307687x247454614(a[0], a[1]);
}
Clo g_list_2emap_24s1727184187x1048417382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1727184187x1048417382_24dps_entry, 2, 0};

V g_list_2emap_24s1727184187x1048417382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_regex_2ebranchOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1727184187x1048417382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1727184187x1048417382_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s2085003797x1793382462_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2085003797x1793382462_entry, 2, 0};

V g_list_2ekeepIf_24s2085003797x1793382462(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2085003797x1793382462_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2085003797x1793382462(a[0], a[1]);
}
Clo g_list_2emap_24s1681408447x1763680441_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1681408447x1763680441_24dps_entry, 4, 0};

V g_list_2emap_24s1681408447x1763680441_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 4), heff_dup(v_lit_241));
      v_t_247 = ({ V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_244, 239ULL, 8, shape_module__named__path__shown__source__renames__implicit__library, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      v_t_247 = v_x_244;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1681408447x1763680441_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2eany_24s2129318370x1621070635_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2129318370x1621070635_entry, 2, 0};

V g_list_2eany_24s2129318370x1621070635(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2ereaches(v_lit_240, heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s2129318370x1621070635(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1498757180x165099811_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1498757180x165099811_24dps_entry, 2, 0};

V g_list_2emap_24s1498757180x165099811_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1498757180x165099811_24dps(a[0], a[1]);
}
Clo g_list_2esortBy_24s196358923x1153659155_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s196358923x1153659155_entry, 1, 0};

V g_list_2esortBy_24s196358923x1153659155(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s196358923x1153659155(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s196358923x1153659155(v_t_2411));
      return (g_list_2emerge_24s2063716145x1843377885_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s196358923x1153659155(a[0]);
}
Clo g_list_2emap_24s320194436x1336304593_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s320194436x1336304593_24dps_entry, 3, 0};

V g_list_2emap_24s320194436x1336304593_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2enameByteOf(v_lit_240, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s320194436x1336304593_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s320194436x1336304593_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1193924222x1531824795_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1193924222x1531824795_24dps_entry, 4, 0};

V g_list_2emap_24s1193924222x1531824795_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_240))) {
      v_t_246 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_244, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_246 = v_x_244;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1193924222x1531824795_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1767134203x962737276_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1767134203x962737276_entry, 8, 0};

V g_list_2emap_24s1767134203x962737276(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    HeffT2 v_t_2410 = (g_json_2eat_24cpr(NTAG(TAG_Nil), v_x_248));
    V v_t_2420;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_a_2413 = v_field_2412;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_JNull: {
          v_t_2420 = heff_dup(v_lit_241);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_a_2413, 0ULL, 1);
          v_t_2420 = heff_dup(v_lit_242);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_a_2413, 0ULL, 1);
          v_t_2420 = heff_dup(v_lit_243);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_a_2413, 0ULL, 1);
          v_t_2420 = heff_dup(v_lit_244);
          break;
        }
        case TAG_JString: {
          V v_a_2417 = heff_field(v_a_2413, 0);
          heff_take_n(v_a_2413, 1ULL, 1);
          v_t_2420 = v_a_2417;
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_a_2413, 0ULL, 1);
          v_t_2420 = heff_dup(v_lit_245);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_a_2413, 0ULL, 1);
          v_t_2420 = heff_dup(v_lit_246);
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2420 = heff_dup(v_lit_240);
      }
    }
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = (g_list_2emap_24s1767134203x962737276_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2421)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1767134203x962737276(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1767134203x962737276_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1767134203x962737276_24dps_entry, 9, 0};

V g_list_2emap_24s1767134203x962737276_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    HeffT2 v_t_2411 = (g_json_2eat_24cpr(NTAG(TAG_Nil), v_x_249));
    V v_t_2421;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_a_2414 = v_field_2413;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_JNull: {
          v_t_2421 = heff_dup(v_lit_241);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_242);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_243);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_244);
          break;
        }
        case TAG_JString: {
          V v_a_2418 = heff_field(v_a_2414, 0);
          heff_take_n(v_a_2414, 1ULL, 1);
          v_t_2421 = v_a_2418;
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_245);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_a_2414, 0ULL, 1);
          v_t_2421 = heff_dup(v_lit_246);
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
      } else {
        heff_drop(v_field_2413);
        v_t_2421 = heff_dup(v_lit_240);
      }
    }
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_hole()});
    V v_u_2423 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2422));
    heff_drop(v_u_2423);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2422;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1767134203x962737276_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1767134203x962737276_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s580776739x648604941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_entry, 1, 0};

V g_list_2emap_24s580776739x648604941(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_args_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 5ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_245, v_args_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s580776739x648604941_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941(a[0]);
}
Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1201185697x960477413_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1201185697x960477413_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1201185697x960477413_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1419960935x1367201220_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s456747242x756515627_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456747242x756515627_entry, 1, 0};

V g_list_2emap_24s456747242x756515627(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2einteractive_2eflagSlot(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s456747242x756515627_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s456747242x756515627_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456747242x756515627(a[0]);
}
Clo g_list_2emap_24s865484684x739952503_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s865484684x739952503_entry, 1, 0};

V g_list_2emap_24s865484684x739952503(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_x_241, NTAG(TAG_Dim)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s865484684x739952503_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s865484684x739952503_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s865484684x739952503(a[0]);
}
Clo g_list_2emap_24s1093229560x1486136516_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1093229560x1486136516_24dps_entry, 2, 0};

V g_list_2emap_24s1093229560x1486136516_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_x_242, NTAG(TAG_Plain)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1093229560x1486136516_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f488322910x556193579_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f488322910x556193579_entry, 3, 0};

V g_list_2efoldl_24f488322910x556193579(V v_z_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245});
      V v_t_248 = (g_heff_2ecompile_2erepr_2eentered(v_z_240, v_x_247));
      V t_0 = v_t_248;
      V t_1 = v_xs_244;
      V t_2 = v_ys_246;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f488322910x556193579(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f889159142x1775976195_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f889159142x1775976195_entry, 4, 0};

V g_list_2emap_24f889159142x1775976195(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244;
    if (heff_intEq_c_lent(v_a_242, v_lit_240, 0)) {
      v_t_244 = heff_dup(v_lit_241);
    } else {
      v_t_244 = NTAG(TAG_RepV);
    }
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f889159142x1775976195_24dps(v_lit_240, v_lit_241, heff_box_word((heff_unbox_word(v_a_242) + ((int64_t)1ULL))), v_b_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f889159142x1775976195(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f783067987x1926181389_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_24dps_entry, 6, 0};

V g_list_2emap_24f783067987x1926181389_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244, V v_d_245) {
top: ;
  if (heff_intLt_c_lent(v_b_244, v_a_243, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_a_243));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_t_246, heff_dup(v_lit_242)), heff_hole()});
    V v_u_248 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = heff_intAdd(v_a_243, MK_INT(1LL));
    V t_4 = v_b_244;
    V t_5 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_a_243 = t_3;
    v_b_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
}
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1229912102x1467950109_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_24dps_entry, 3, 0};

V g_list_2emap_24f1229912102x1467950109_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_245 = (g_list_2emap_24s2029035892x1571084362_24tok2(v_ru_24x2_241_24Cons, v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f675617784x1820039874_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f675617784x1820039874_entry, 2, 0};

V g_list_2efoldl_24f675617784x1820039874(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f675617784x1820039874(a[0], a[1]);
}
Clo g_list_2emap_24f869471183x993026796_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f869471183x993026796_24dps_entry, 4, 0};

V g_list_2emap_24f869471183x993026796_24dps(V v_lit_240, V v_box_24lit_241, V v_x2_242, V v_d_243) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_244, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_244), heff_hole()});
      V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f869471183x993026796_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1502491305x440718220_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1502491305x440718220_entry, 2, 0};

V g_list_2emap_24f1502491305x440718220(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2emap_24s864521685x1610969087(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ehint(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f1502491305x440718220_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1502491305x440718220(a[0], a[1]);
}
Clo g_list_2emap_24f922554743x1845028609_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f922554743x1845028609_entry, 2, 0};

V g_list_2emap_24f922554743x1845028609(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
      V v_u_246 = (g_list_2emap_24f922554743x1845028609_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f922554743x1845028609(a[0], a[1]);
}
Clo g_list_2efoldl_24f1160581125x508466714_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1160581125x508466714_entry, 2, 0};

V g_list_2efoldl_24f1160581125x508466714(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = (g_heff_2esyntax_2efmt_2elayout_2einlineDoc(v_x_242));
    V v_t_245 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1160581125x508466714(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f201346761x152404242_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f201346761x152404242_entry, 7, 0};

V g_list_2emap_24f201346761x152404242(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_a_245, V v_b_246) {
top: ;
  if ((heff_peek_word(v_b_246) < heff_peek_word(v_a_245))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return NTAG(TAG_Nil);
  } else {
    V v_t_248;
    if (((heff_peek_word(v_lit_240) <= heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) <= heff_peek_word(v_lit_242)))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) + heff_peek_word(v_lit_243));
      v_t_248 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_247))));
    } else {
      v_t_248 = heff_strSlice(heff_dup(v_lit_241), heff_dup(v_a_245), heff_box_word((heff_peek_word(v_a_245) + heff_peek_word(v_lit_244))));
    }
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24f201346761x152404242_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, heff_box_word((heff_unbox_word(v_a_245) + ((int64_t)1ULL))), v_b_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
}
V g_list_2emap_24f201346761x152404242_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f201346761x152404242(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1340051005x157438530_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_24dps_entry, 5, 0};

V g_list_2emap_24f1340051005x157438530_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
    if (heff_strEq_c_lent(v_t_247, v_lit_242, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_245, heff_dup(v_lit_240)), heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530_24dps(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_24dps_str2, 1, " ");
Clo g_list_2emap_24f1016251237x587084191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1016251237x587084191_24dps_entry, 4, 0};

V g_list_2emap_24f1016251237x587084191_24dps(V v_w_240, V v_line_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_24dps_str0), 2)) {
      heff_drop(v_line_241);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      V v_t_246 = (g_list_2emap_24s1093229560x1486136516(NTAG(TAG_Nil)));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_246}));
    }
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_242, 0);
    V v_xs_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_24dps_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_247;
      V t_2 = v_xs_248;
      V t_3 = v_d_243;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_xs_249 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_241))));
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_249); r_; });
      V v_xs_2411 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_247))));
      V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2411; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2411); r_; });
      V v_t_2413 = heff_intAdd(heff_intAdd(v_t_2410, MK_INT(1LL)), v_t_2412);
      if (heff_intLe_c_lent(v_t_2413, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2414 = heff_strAppend(v_line_241, heff_strAppend(((V)&g_list_2emap_24f1016251237x587084191_24dps_str2), v_x_247));
        V t_0 = v_w_240;
        V t_1 = v_t_2414;
        V t_2 = v_xs_248;
        V t_3 = v_d_243;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_t_2415 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
        V v_u_2418 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_w_240;
        V t_1 = v_x_247;
        V t_2 = v_xs_248;
        V t_3 = v_cell_2417;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2emap_24f1016251237x587084191_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1016251237x587084191_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1832335087x1608171547_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1832335087x1608171547_entry, 4, 0};

V g_list_2emap_24f1832335087x1608171547(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242))) {
      V v_t_247;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
        V v_t_246 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
        v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_247 = v_x_244;
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2emap_24f1832335087x1608171547_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1832335087x1608171547(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f556306710x2087456230_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f556306710x2087456230_entry, 4, 0};

V g_list_2efoldl_24f556306710x2087456230(V v_lit_240, V v_z_241, V v_f_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_f_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_242), 1, (V[]){heff_dup(v_x_244)}));
    heff_drop(v_x_246);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_f_242;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_f_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f556306710x2087456230(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24f1622709115x782387749_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1622709115x782387749_entry, 2, 0};

V g_list_2ekeepIf_24f1622709115x782387749(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2ekeepIf_24s44384897x1267641110(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24f1622709115x782387749_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_ys_241;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24f1622709115x782387749(a[0], a[1]);
}
Clo g_list_2emerge_24s471518711x1508999958_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s471518711x1508999958_24tok2_entry, 3, 0};

V g_list_2emerge_24s471518711x1508999958_24tok2(V v_tok_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_x_243, 2);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (!heff_strLt_c(heff_dup(heff_rfield(v_y_245, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s471518711x1508999958_24dps(v_xs_244, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s471518711x1508999958_24dps(heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24s471518711x1508999958_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s471518711x1508999958_24tok2(a[0], a[1], a[2]);
}