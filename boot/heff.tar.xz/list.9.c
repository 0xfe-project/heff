// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_Flagged 28540
#define TAG_ITl 20301
#define TAG_ImplicitParam 51130
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_Typed 36072
#define LBL_arg 306384
#define LBL_at 9882
#define LBL_b 316
#define LBL_back 9511342
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_front 299063875
#define LBL_input 301716452
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_m 327
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_msg 317947
#define LBL_n 328
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_options 1129866465
#define LBL_outcome 1272833429
#define LBL_owner 307523277
#define LBL_parent 951717845
#define LBL_part 9928890
#define LBL_required 351999471
#define LBL_runs 10007567
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_values 1123329101
#define LBL_xs 10594
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eonce_2ecalleeFresh(V, V, V);
V g_heff_2ecompile_2eonce_2ecalleeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ecalleeFresh_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s852887114x1468859299(V);
V g_list_2eall_24s852887114x1468859299_entry(V self, V *a);
extern Clo g_list_2eall_24s852887114x1468859299_clo;
V g_list_2eany_24s1934959195x1899752489(V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a);
extern Clo g_list_2eany_24s1934959195x1899752489_clo;
V g_list_2eany_24s313956312x193471538(V, V, V, V);
V g_list_2eany_24s313956312x193471538_entry(V self, V *a);
extern Clo g_list_2eany_24s313956312x193471538_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513567688x204074300(V, V);
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513567688x204074300_clo;
V g_list_2efoldl_24s1813831864x676242789(V, V, V, V);
V g_list_2efoldl_24s1813831864x676242789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1813831864x676242789_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s224553292x101133675(V, V);
V g_list_2efoldl_24s224553292x101133675_entry(V self, V *a);
extern Clo g_list_2efoldl_24s224553292x101133675_clo;
V g_list_2efoldl_24s637780307x9274583(V, V);
V g_list_2efoldl_24s637780307x9274583_entry(V self, V *a);
extern Clo g_list_2efoldl_24s637780307x9274583_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2ekeepIf_24f1622709115x782387749_24dps(V, V, V);
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2ekeepIf_24s122741325x871243494_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo;
V g_list_2ekeepIf_24s1245654234x191876439(V);
V g_list_2ekeepIf_24s1245654234x191876439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_clo;
V g_list_2ekeepIf_24s1245654234x191876439_24dps(V, V);
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo;
V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo;
V g_list_2ekeepIf_24s1674319799x1081446864_24dps(V, V);
V g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_24dps_clo;
V g_list_2ekeepIf_24s2085003797x1793382462(V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_clo;
V g_list_2ekeepIf_24s2085003797x1793382462_24dps(V, V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s479112018x1726839132(V);
V g_list_2ekeepIf_24s479112018x1726839132_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_clo;
V g_list_2ekeepIf_24s479112018x1726839132_24dps(V, V);
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2ekeepIf_24s512765522x2052101617_24dps(V, V, V);
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24f201346761x152404242_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_24dps_clo;
V g_list_2emap_24f2053285389x511622380(V, V, V, V, V);
V g_list_2emap_24f2053285389x511622380_entry(V self, V *a);
extern Clo g_list_2emap_24f2053285389x511622380_clo;
V g_list_2emap_24f2053285389x511622380_24dps(V, V, V, V, V, V);
V g_list_2emap_24f2053285389x511622380_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2053285389x511622380_24dps_clo;
V g_list_2emap_24f869471183x993026796_24dps(V, V, V, V);
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_24dps_clo;
V g_list_2emap_24f922554743x1845028609(V, V);
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_clo;
V g_list_2emap_24f922554743x1845028609_24dps(V, V, V);
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_24dps_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1093229560x1486136516_24dps(V, V);
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s148260373x1589531897(V, V, V);
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_clo;
V g_list_2emap_24s148260373x1589531897_24dps(V, V, V, V);
V g_list_2emap_24s148260373x1589531897_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_24dps_clo;
V g_list_2emap_24s1498757180x165099811_24dps(V, V);
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_24dps_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1845612977x612508518_24dps(V, V);
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_24dps_clo;
V g_list_2emap_24s191715292x1660526539_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s191715292x1660526539_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s191715292x1660526539_24dps_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s456747242x756515627_24dps(V, V);
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_24dps_clo;
V g_list_2emap_24s525732339x518706186(V, V, V, V, V, V, V);
V g_list_2emap_24s525732339x518706186_entry(V self, V *a);
extern Clo g_list_2emap_24s525732339x518706186_clo;
V g_list_2emap_24s525732339x518706186_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s525732339x518706186_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s525732339x518706186_24dps_clo;
V g_list_2emap_24s580972671x1254803293_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s580972671x1254803293_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580972671x1254803293_24dps_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s698781565x943874959_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s698781565x943874959_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698781565x943874959_24dps_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24dps(v_f_240, v_xs_244, v_ys_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_list_2ezipWith_24s1876717925x1404326288_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1674319799x1081446864_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1674319799x1081446864_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
    switch (heff_tag_of(v_a_247)) {
    case TAG_Nil: {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2410 = heff_field(v_a_247, 0);
      heff_take_n(v_a_247, 1ULL, 2);
      switch (heff_tag_of(v_a_2410)) {
      case TAG_At: {
        V v_a_2412 = heff_field(v_a_2410, 0);
        heff_take_n(v_a_2410, 1ULL, 2);
        switch (heff_tag_of(v_a_2412)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2418 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2417));
          heff_drop(v_u_2418);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2417;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2412, 0ULL, 2);
          V v_cell_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2422 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2421));
          heff_drop(v_u_2422);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2421;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtExpr: {
          V v_a_2423 = heff_field(v_a_2412, 0);
          heff_take_n(v_a_2412, 1ULL, 1);
          V v_t_2424 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_a_2423));
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_drop(v_t_2424);
            V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
            V v_u_2426 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2425));
            heff_drop(v_u_2426);
            V t_0 = v_xs_243;
            V t_1 = v_cell_2425;
            v_x2_240 = t_0;
            v_d_241 = t_1;
            goto top;
          } else {
            heff_drop(v_x_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_t_2424);
            V t_0 = v_xs_243;
            V t_1 = v_d_241;
            v_x2_240 = t_0;
            v_d_241 = t_1;
            goto top;
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2430 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
          heff_drop(v_u_2431);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2430;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2412, 0ULL, 3);
          V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_2436 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2435));
          heff_drop(v_u_2436);
          V t_0 = v_xs_243;
          V t_1 = v_cell_2435;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_2412);
        }
      }
      default: return heff_nomatch(v_a_2410);
      }
    }
    default: return heff_nomatch(v_a_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1674319799x1081446864_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1992667171x110340492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_entry, 1, 0};

V g_list_2emap_24s1992667171x110340492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_x2_245 = v_a_243;
      V v_t_2423;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x2_245, 0);
        V v_sp_247 = heff_field(v_x2_245, 1);
        V v_t_248 = heff_field(v_x2_245, 2);
        V v_d_249 = heff_field(v_x2_245, 3);
        V v_ru_24x2_245_24DeclareField = heff_take_reuse_n(v_x2_245, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_t_248)) {
        case TAG_At: {
          V v_n_2410 = heff_field(v_t_248, 0);
          V v_sp_2411 = heff_field(v_t_248, 1);
          V v_ru_24t_248_24At = heff_take_reuse_n(v_t_248, 3ULL, 2);
          v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_248_24At, v_sp_2411, v_n_2410));
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        V v_t_2418;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x_241_24At, 2);
          v_t_2418 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2413 = heff_field(v_d_249, 0);
          V v_ru_24d_249_24Just = heff_take_reuse_n(v_d_249, 1ULL, 1);
          V v_t_2417;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_At: {
            V v_n_2414 = heff_field(v_x_2413, 0);
            V v_sp_2415 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 3ULL, 2);
            V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2414));
            v_t_2417 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2416, v_sp_2415});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          v_t_2418 = heff_tag_at_n(v_ru_24d_249_24Just, TAG_Just, 1, (V[]){v_t_2417});
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        v_t_2423 = heff_tag_at_n(v_ru_24x2_245_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_246, v_sp_247, v_t_2412, v_t_2418});
        break;
      }
      case TAG_BadFieldDecl: {
        V v_e_2419 = heff_field(v_x2_245, 0);
        V v_ru_24x2_245_24BadFieldDecl = heff_take_reuse_n(v_x2_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_2422;
        switch (heff_tag_of(v_e_2419)) {
        case TAG_At: {
          V v_n_2420 = heff_field(v_e_2419, 0);
          V v_sp_2421 = heff_field(v_e_2419, 1);
          V v_ru_24e_2419_24At = heff_take_reuse_n(v_e_2419, 3ULL, 2);
          v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24e_2419_24At, v_sp_2421, v_n_2420));
          break;
        }
        default: heff_nomatch(v_e_2419);
        }
        v_t_2423 = heff_tag_at_n(v_ru_24x2_245_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2422});
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = (g_list_2emap_24s1992667171x110340492_24dps(v_xs_242, heff_dup(v_cell_2425)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492(a[0]);
}
Clo g_list_2emap_24s1059370217x1267747283_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_24dps_entry, 2, 0};

V g_list_2emap_24s1059370217x1267747283_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1934959195x1899752489_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1934959195x1899752489_entry, 10, 0};

V g_list_2eany_24s1934959195x1899752489(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_242);
    heff_drop(v_lit_245);
    heff_drop(v_lit_247);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_a_2412 = heff_strFind_lent(v_lit_240, v_x_2410, v_lit_241, 0);
    V v_t_2413;
    if (heff_intLt_c_lent(v_a_2412, v_lit_242, 0)) {
      heff_drop(v_a_2412);
      v_t_2413 = heff_dup(v_x_2410);
    } else {
      v_t_2413 = heff_strSlice_lent(v_x_2410, v_lit_243, v_a_2412, 4);
    }
    V v_a_2414 = heff_strFind_lent(v_lit_244, v_lit_245, v_lit_246, 0);
    V v_t_2415;
    if (heff_intLt_c_lent(v_a_2414, v_lit_247, 0)) {
      heff_drop(v_a_2414);
      v_t_2415 = heff_dup(v_lit_245);
    } else {
      v_t_2415 = heff_strSlice_lent(v_lit_245, v_lit_248, v_a_2414, 4);
    }
    if (heff_strEq_c(v_t_2413, v_t_2415)) {
      heff_drop(v_lit_242);
      heff_drop(v_lit_245);
      heff_drop(v_lit_247);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_xs_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_x2_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2eany_24s1934959195x1899752489(a0, a1, a[2], a3, a4, a[5], a6, a[7], a8, a9); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); heff_drop(a6); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emap_24s73473062x206541869_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_24dps_entry, 2, 0};

V g_list_2emap_24s73473062x206541869_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1913417976x1327308136_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1913417976x1327308136_entry, 3, 0};

V g_list_2efoldl_24s1913417976x1327308136(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2447;
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2444);
      v_t_2447 = v_z_241;
    } else {
      heff_drop(v_t_2444);
      V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_t_2446 = (g_heff_2ecompile_2eir_2esizeW(heff_dup(v_lit_240), v_t_2445));
      v_t_2447 = heff_intAdd(v_z_241, v_t_2446);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2447;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1913417976x1327308136(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1813831864x676242789_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1813831864x676242789_entry, 4, 0};

V g_list_2efoldl_24s1813831864x676242789(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_x_244, v_lit_240, 0)) {
      V v_t_246 = (g_heff_2ecompile_2erepr_2efourTo(heff_dup(v_x_244)));
      v_t_247 = heff_intAdd(v_z_242, heff_intMul(heff_dup(v_lit_241), v_t_246));
    } else {
      v_t_247 = v_z_242;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1813831864x676242789_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s1813831864x676242789(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s2145639387x28888241_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2145639387x28888241_entry, 4, 0};

V g_list_2efoldl_24s2145639387x28888241(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkArm: {
      V v_a_248 = heff_field(v_x_244, 2);
      V v_ru_24x_244_24MkArm = heff_take_reuse_n(v_x_244, 4ULL, 3);
      v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_244_24MkArm, TAG_ITl, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_248}), v_z_242});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2145639387x28888241(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s479112018x1726839132_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s479112018x1726839132_entry, 1, 0};

V g_list_2ekeepIf_24s479112018x1726839132(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_RepV: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s479112018x1726839132_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s479112018x1726839132_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s479112018x1726839132(a[0]);
}
Clo g_list_2efoldl_24s1513567688x204074300_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1513567688x204074300_entry, 2, 0};

V g_list_2efoldl_24s1513567688x204074300(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2efoldl_24s2015232937x23400545(v_z_240, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1513567688x204074300(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s215892288x1392224072_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_24dps_entry, 3, 0};

V g_list_2emap_24s215892288x1392224072_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1245654234x191876439_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1245654234x191876439_entry, 1, 0};

V g_list_2ekeepIf_24s1245654234x191876439(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_241)) {
    case TAG_SLocal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2440 = (g_list_2ekeepIf_24s1245654234x191876439_24dps(v_xs_242, heff_dup(v_cell_2439)));
      heff_drop(v_u_2440);
      return v_cell_2439;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2438);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1245654234x191876439_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1245654234x191876439(a[0]);
}
Clo g_list_2emap_24s191715292x1660526539_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s191715292x1660526539_24dps_entry, 8, 0};

V g_list_2emap_24s191715292x1660526539_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_243));
      V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2413), heff_dup(v_lit_244));
      V v_t_2415 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2411); r_; });
      v_t_2416 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2415), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s191715292x1660526539_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s191715292x1660526539_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_list_2emap_24s525732339x518706186_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str2, 12, "(A.fromList ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str3, 1, ")");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str4, 8, "(MkPair ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s525732339x518706186_str6, 1, ")");
Clo g_list_2emap_24s525732339x518706186_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s525732339x518706186_entry, 7, 0};

V g_list_2emap_24s525732339x518706186(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2411), heff_dup(v_lit_243));
      V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2412), heff_dup(v_lit_244));
      V v_x2_2414 = v_a_2410;
      V v_t_2423;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_xs_2415 = heff_field(v_x2_2414, 0);
        V v_b_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_xs_2417 = (g_list_2emap_24s1397747289x2145601499(heff_arrayToList(v_xs_2415)));
        V v_t_2418 = ({ V a_0 = v_xs_2417; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2417); r_; });
        V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_str0), v_t_2418), ((V)&g_list_2emap_24s525732339x518706186_str1));
        V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_str2), v_t_2419), ((V)&g_list_2emap_24s525732339x518706186_str3));
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s525732339x518706186_str4), v_t_2420), ((V)&g_list_2emap_24s525732339x518706186_str5));
        V v_t_2422 = ({ V a_0 = v_b_2416; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_b_2416); r_; });
        v_t_2423 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2422), ((V)&g_list_2emap_24s525732339x518706186_str6));
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      v_t_2424 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2423), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = (g_list_2emap_24s525732339x518706186_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2425)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s525732339x518706186_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s525732339x518706186(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s865198748x12535471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s865198748x12535471_entry, 2, 0};

V g_list_2efoldl_24s865198748x12535471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s865198748x12535471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s637780307x9274583_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s637780307x9274583_entry, 2, 0};

V g_list_2efoldl_24s637780307x9274583(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_x1_244 = v_z_240;
    V v_x2_245 = v_x_242;
    V v_t_2425;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_m_246 = heff_field(v_x1_244, 0);
      V v_n_247 = heff_field(v_x1_244, 1);
      V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
      switch (heff_tag_of(v_x2_245)) {
      case TAG_MkPair: {
        V v_g_248 = heff_field(v_x2_245, 0);
        V v_c_249 = heff_field(v_x2_245, 1);
        heff_take_n(v_x2_245, 3ULL, 2);
        V v_xs_2410 = heff_take_field(v_c_249, 0);
        V v_b_2411 = heff_get_n(v_c_249, 1, 2);
        V v_t_2412 = v_xs_2410;
        V v_t_2413 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_247, NTAG(TAG_Nil)});
        V v_v_2414 = (g_list_2efoldl_24s690313412x1307839513(v_t_2413, v_t_2412));
        V v_m_2415 = heff_take_field(v_v_2414, 0);
        V v_n_2416 = heff_take_field(v_v_2414, 1);
        V v_xs_2417 = heff_get_n(v_v_2414, 2, 3);
        HeffT2 v_t_2418 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2415, v_n_2416, v_b_2411));
        V v_t_2424;
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_b_27_2421 = v_field_2419;
          V v_n_27_2422 = v_field_2420;
          V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
          v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_ELam, 2, (V[]){v_t_2423, v_b_27_2421}), v_n_27_2422});
        }
        v_t_2425 = (g_heff_2ecompile_2eonce_2ecalleeFresh(v_m_246, v_g_248, v_t_2424));
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V t_0 = v_t_2425;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s637780307x9274583_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s637780307x9274583(a[0], a[1]);
}
Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_24dps_entry, 3, 0};

V g_list_2ezipWith_24s151204990x680105425_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_t_248;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = v_x_243;
      } else {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s512765522x2052101617_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s512765522x2052101617_entry, 2, 0};

V g_list_2ekeepIf_24s512765522x2052101617(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s512765522x2052101617_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s512765522x2052101617(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s122741325x871243494_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s122741325x871243494_entry, 4, 0};

V g_list_2ekeepIf_24s122741325x871243494(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_244, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s122741325x871243494_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s122741325x871243494(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s649333309x1802289391_24dps_str0, 22, "export const $host = \"");
HEFF_LIT(g_list_2emap_24s649333309x1802289391_24dps_str1, 1, "\"");
Clo g_list_2emap_24s649333309x1802289391_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_24dps_entry, 2, 0};

V g_list_2emap_24s649333309x1802289391_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_244 = v_x_242;
    V v_t_249;
    if (heff_strEq_c(heff_strSlice_lent(v_l_244, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_list_2emap_24s649333309x1802289391_24dps_str0))) {
      V v_t_245 = heff_strSlice(heff_dup(v_l_244), MK_INT(22LL), heff_strLength_lent(v_l_244, 0));
      V v_j_246 = heff_strFind(((V)&g_list_2emap_24s649333309x1802289391_24dps_str1), v_t_245, MK_INT(0LL));
      if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
        heff_drop(v_j_246);
        V v_t_247 = heff_strSlice(heff_dup(v_l_244), MK_INT(22LL), heff_strLength(v_l_244));
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
      } else {
        V v_t_248 = heff_strSlice(v_l_244, MK_INT(22LL), heff_intAdd(MK_INT(22LL), v_j_246));
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      }
    } else {
      heff_drop(v_l_244);
      v_t_249 = NTAG(TAG_Nothing);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_entry, 1, 0};

V g_list_2emap_24s640776339x1223679834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s640776339x1223679834_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834(a[0]);
}
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str0, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str1, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str2, 20, "#define HEFF_THREADS");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str3, 20, "#define HEFF_THREADS");
Clo g_list_2eany_24s762674996x1009180162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s762674996x1009180162_entry, 1, 0};

V g_list_2eany_24s762674996x1009180162(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 1));
    V v_t_244 = ({ V a_0 = v_s_243; V b_1 = ((V)&g_list_2eany_24s762674996x1009180162_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2eany_24s762674996x1009180162_str1), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_243); heff_drop(b_1); r_; });
    V v_t_245 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_list_2eany_24s762674996x1009180162_str2); V b_2 = ((V)&g_list_2eany_24s762674996x1009180162_str3); V a_3 = v_t_244; V r_ = (g_list_2eany_24s313956312x193471538(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s762674996x1009180162(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s224553292x101133675_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s224553292x101133675_entry, 2, 0};

V g_list_2efoldl_24s224553292x101133675(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_get_n(v_t_246, 0, 3), v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s224553292x101133675_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s224553292x101133675(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s148260373x1589531897_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s148260373x1589531897_entry, 3, 0};

V g_list_2emap_24s148260373x1589531897(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_246 = heff_take_field(v_x_243, 0);
    V v_a_247 = heff_intSub(heff_dup(heff_rfield(v_x_243, 1)), heff_strLength_lent(v_lit_241, 0));
    V v_t_248;
    if (heff_intLe_c_lent(v_a_246, v_a_247, 0)) {
      heff_drop(v_a_246);
      v_t_248 = v_a_247;
    } else {
      heff_drop(v_a_247);
      v_t_248 = v_a_246;
    }
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_x_243, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_245, heff_dup(v_lit_241), v_t_249}), heff_hole()});
    V v_u_2411 = (g_list_2emap_24s148260373x1589531897_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s148260373x1589531897(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str0, 6, "import");
HEFF_LIT(g_list_2emap_24s1845612977x612508518_24dps_str1, 0, "");
Clo g_list_2emap_24s1845612977x612508518_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1845612977x612508518_24dps_entry, 2, 0};

V g_list_2emap_24s1845612977x612508518_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_242, 2, 3), 1, 2);
    V v_t_246 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s1845612977x612508518_24dps_str0), ((V)&g_list_2emap_24s1845612977x612508518_24dps_str1), v_t_244, v_t_245, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1845612977x612508518_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str7, 9, "(equation");
HEFF_LIT(g_list_2emap_24s1055307687x247454614_str8, 1, ")");
Clo g_list_2emap_24s1055307687x247454614_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_entry, 2, 0};

V g_list_2emap_24s1055307687x247454614(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2424;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_MkEquation: {
        V v_g_248 = heff_field(v_x21_246, 0);
        V v_ps_2410 = heff_field(v_x21_246, 2);
        V v_rhs_2411 = heff_field(v_x21_246, 3);
        heff_take_n(v_x21_246, 13ULL, 4);
        V v_x2_2412 = (g_list_2emap_24s1561756891x1126436879(v_ps_2410));
        V v_t_2415;
        switch (heff_tag_of(v_x2_2412)) {
        case TAG_Nil: {
          v_t_2415 = ((V)&g_list_2emap_24s1055307687x247454614_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_x2_2412, 0);
          V v_xs_2414 = heff_field(v_x2_2412, 1);
          heff_take_n(v_x2_2412, 3ULL, 2);
          v_t_2415 = ({ V a_0 = ((V)&g_list_2emap_24s1055307687x247454614_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2412);
        }
        V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1055307687x247454614_str2), v_t_2415), ((V)&g_list_2emap_24s1055307687x247454614_str3));
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_rhs_2411}));
        V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_parts_2419 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_g_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
        V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1055307687x247454614_str4), v_parts_2419));
        V v_t_2423;
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Nil: {
          v_t_2423 = ((V)&g_list_2emap_24s1055307687x247454614_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_xs_2422 = heff_field(v_x2_2420, 1);
          heff_take_n(v_x2_2420, 3ULL, 2);
          v_t_2423 = ({ V a_0 = ((V)&g_list_2emap_24s1055307687x247454614_str6); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2420);
        }
        v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1055307687x247454614_str7), v_t_2423), ((V)&g_list_2emap_24s1055307687x247454614_str8));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = (g_list_2emap_24s1055307687x247454614_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2425)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1055307687x247454614(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s2085003797x1793382462_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2085003797x1793382462_entry, 2, 0};

V g_list_2ekeepIf_24s2085003797x1793382462(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2085003797x1793382462_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2085003797x1793382462(a[0], a[1]);
}
Clo g_list_2eall_24s852887114x1468859299_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s852887114x1468859299_entry, 1, 0};

V g_list_2eall_24s852887114x1468859299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_front_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_back_244 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_front_243)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_back_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_back_244, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_back_244);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_front_243, 0ULL, 2);
      heff_drop(v_back_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_front_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s852887114x1468859299_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s852887114x1468859299(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s580972671x1254803293_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580972671x1254803293_24dps_entry, 9, 0};

V g_list_2emap_24s580972671x1254803293_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 12);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2411 = heff_dup(heff_rfield(v_lit_241, 4));
    V v_t_2415;
    if (heff_intEq_c_lent(v_a_2411, v_lit_242, 0)) {
      heff_drop(v_a_2411);
      v_t_2415 = heff_dup(v_lit_243);
    } else {
      V v_t_2414;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_dup(heff_field(v_x_249, 1));
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      v_t_2415 = heff_intDiv(heff_intMul(v_t_2414, heff_dup(v_lit_244)), v_a_2411);
    }
    V v_t_2416 = heff_strAppend(heff_intShow(v_t_2415), heff_dup(v_lit_245));
    V v_t_2417 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2416), heff_dup(v_lit_246));
    V v_t_2420;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 2);
      v_t_2420 = v_a_2418;
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2417, v_t_2420), heff_hole()});
    V v_u_2422 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2421;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s580972671x1254803293_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580972671x1254803293_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1498757180x165099811_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1498757180x165099811_24dps_entry, 2, 0};

V g_list_2emap_24s1498757180x165099811_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1498757180x165099811_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s698781565x943874959_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698781565x943874959_24dps_entry, 8, 0};

V g_list_2emap_24s698781565x943874959_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_JNull: {
      v_t_2416 = heff_dup(v_lit_240);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_248, 0ULL, 1);
      v_t_2416 = heff_dup(v_lit_241);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_248, 0ULL, 1);
      v_t_2416 = heff_dup(v_lit_242);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_248, 0ULL, 1);
      v_t_2416 = heff_dup(v_lit_243);
      break;
    }
    case TAG_JString: {
      V v_a_2413 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      v_t_2416 = v_a_2413;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_248, 0ULL, 1);
      v_t_2416 = heff_dup(v_lit_244);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_248, 0ULL, 1);
      v_t_2416 = heff_dup(v_lit_245);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s698781565x943874959_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698781565x943874959_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1419960935x1367201220_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s456747242x756515627_str0, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_str1, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_str2, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_str3, 0, "");
Clo g_list_2emap_24s456747242x756515627_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456747242x756515627_entry, 1, 0};

V g_list_2emap_24s456747242x756515627(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_243 = v_x_241;
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_243, 2)), ((V)&g_list_2emap_24s456747242x756515627_str0))) {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2412 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){heff_dup(g_std_2ecli_2einteractive_2eswitchOptions_get()), MK_INT(0LL)})});
    } else {
      V v_t_244 = heff_dup(heff_rfield(v_f_243, 4));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s456747242x756515627_str1)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_246 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s456747242x756515627_str2)), v_t_245});
        v_t_2412 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_246});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        V v_t_249 = heff_dup(heff_rfield(v_f_243, 6));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_t_249);
          V v_t_2410 = heff_rec_n(2, shape_options__at, (V[]){heff_dup(heff_rfield(v_f_243, 4)), MK_INT(0LL)});
          v_t_2412 = heff_tag_n(TAG_Picked, 1, (V[]){v_t_2410});
        } else {
          heff_drop(v_t_249);
          V v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_list_2emap_24s456747242x756515627_str3), heff_dup(heff_rfield(v_f_243, 4))});
          v_t_2412 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){v_t_2411, MK_INT(0LL)})});
        }
        break;
      }
      default: heff_nomatch(v_t_244);
      }
    }
    V v_t_2413 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_243}), v_t_2412});
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s456747242x756515627_24dps(v_xs_242, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s456747242x756515627_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456747242x756515627(a[0]);
}
Clo g_list_2emap_24s1093229560x1486136516_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1093229560x1486136516_24dps_entry, 2, 0};

V g_list_2emap_24s1093229560x1486136516_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_x_242, NTAG(TAG_Plain)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1093229560x1486136516_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f2053285389x511622380_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2053285389x511622380_entry, 5, 0};

V g_list_2emap_24f2053285389x511622380(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_245)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_a_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_take_field(v_x_245, 3)});
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_get_n(v_x_245, 1, 7));
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(v_t_249, heff_dup(v_lit_242)), v_a_248, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f2053285389x511622380_24dps(v_lit_240, v_lit_241, v_lit_242, v_p_243, v_xs_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f2053285389x511622380_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2053285389x511622380(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f675617784x1820039874_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f675617784x1820039874_entry, 2, 0};

V g_list_2efoldl_24f675617784x1820039874(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f675617784x1820039874(a[0], a[1]);
}
Clo g_list_2emap_24f869471183x993026796_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f869471183x993026796_24dps_entry, 4, 0};

V g_list_2emap_24f869471183x993026796_24dps(V v_lit_240, V v_box_24lit_241, V v_x2_242, V v_d_243) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_244, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_244), heff_hole()});
      V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f869471183x993026796_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f201346761x152404242_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f201346761x152404242_entry, 7, 0};

V g_list_2emap_24f201346761x152404242(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_a_245, V v_b_246) {
top: ;
  if ((heff_peek_word(v_b_246) < heff_peek_word(v_a_245))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return NTAG(TAG_Nil);
  } else {
    V v_t_248;
    if (((heff_peek_word(v_lit_240) <= heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) <= heff_peek_word(v_lit_242)))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) + heff_peek_word(v_lit_243));
      v_t_248 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_247))));
    } else {
      v_t_248 = heff_strSlice_lent(v_lit_241, v_a_245, heff_box_word((heff_peek_word(v_a_245) + heff_peek_word(v_lit_244))), 4);
    }
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24f201346761x152404242_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, heff_box_word((heff_unbox_word(v_a_245) + ((int64_t)1ULL))), v_b_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
}
V g_list_2emap_24f201346761x152404242_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f201346761x152404242(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
Clo g_list_2emap_24f922554743x1845028609_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f922554743x1845028609_entry, 2, 0};

V g_list_2emap_24f922554743x1845028609(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
      V v_u_246 = (g_list_2emap_24f922554743x1845028609_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f922554743x1845028609(a[0], a[1]);
}
Clo g_list_2ekeepIf_24f1622709115x782387749_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1622709115x782387749_entry, 2, 0};

V g_list_2ekeepIf_24f1622709115x782387749(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2ekeepIf_24s44384897x1267641110(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24f1622709115x782387749_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_ys_241;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24f1622709115x782387749(a[0], a[1]);
}