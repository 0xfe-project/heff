// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_FailBecause 16014
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_bug 307438
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_def 308863
#define LBL_deps 9575179
#define LBL_discarded 1490202606
#define LBL_doc 309170
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_expected 956903529
#define LBL_exposes 1070285678
#define LBL_expr 9623228
#define LBL_failure 1292767177
#define LBL_first 298798794
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_groups 709681407
#define LBL_hidden 729654485
#define LBL_holds 300818350
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_large 304101205
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_order 307364712
#define LBL_own 320000
#define LBL_params 951713969
#define LBL_places 961367927
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_to 10466
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_first__again[] = {LBL_first, LBL_again};
static uint32_t shape_from__to__expr__ty__value__expected__holds__expectFrom__expectTo__doc[] = {LBL_from, LBL_to, LBL_expr, LBL_ty, LBL_value, LBL_expected, LBL_holds, LBL_expectFrom, LBL_expectTo, LBL_doc};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_module__alias[] = {LBL_module, LBL_alias};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_name__value__bug[] = {LBL_name, LBL_value, LBL_bug};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2eagainGo(V, V, V);
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eagainGo_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps(V, V);
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_24dps_clo;
V g_heff_2ebuild_2edriver_2ealiasQOne(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eckOf(V);
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eckOf_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2eevalPick_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_24dps_clo;
V g_heff_2ebuild_2edriver_2efieldV(V, V);
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efieldV_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2efixityLines_24acc(V, V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_24acc_clo;
V g_heff_2ebuild_2edriver_2eimportOfGo(V, V, V);
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo;
V g_heff_2ebuild_2edriver_2eimportedFix(V, V);
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportedFix_clo;
V g_heff_2ebuild_2edriver_2eimportsByName(V, V);
V g_heff_2ebuild_2edriver_2eimportsByName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportsByName_clo;
V g_heff_2ebuild_2edriver_2eisBenchTy(V);
V g_heff_2ebuild_2edriver_2eisBenchTy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchTy_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2elistOfV_24dps(V, V);
V g_heff_2ebuild_2edriver_2elistOfV_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_24dps_clo;
V g_heff_2ebuild_2edriver_2emkWatchInfo(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2emkWatchInfo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emkWatchInfo_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eoutcomesOf(V, V, V);
V g_heff_2ebuild_2edriver_2eoutcomesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomesOf_clo;
V g_heff_2ebuild_2edriver_2epickOutcomes(V, V, V, V);
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo;
V g_heff_2ebuild_2edriver_2eplaceAt(V, V);
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eplaceAt_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo(V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(V, V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
HeffT2 g_heff_2ebuild_2edriver_2espanOfName_24cpr(V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo;
V g_heff_2ebuild_2edriver_2estructFieldsGo_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructFieldsGo_24dps_clo;
V g_heff_2ebuild_2edriver_2etwicesGo_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_24dps_clo;
V g_heff_2ebuild_2edriver_2etypeArgsOf(V, V);
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo;
V g_heff_2ebuild_2edriver_2ewithPlace(V, V, V);
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithPlace_clo;
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2esurface_2efixitiesOfText(V, V);
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData(V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eisData_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1547578820x1498276962(V, V);
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a);
extern Clo g_list_2eany_24s1547578820x1498276962_clo;
V g_list_2eany_24s2037198014x392734282(V, V);
V g_list_2eany_24s2037198014x392734282_entry(V self, V *a);
extern Clo g_list_2eany_24s2037198014x392734282_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2eimportsByName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportsByName_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eimportsByName(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_240, heff_rfield(v_o_242, 0)));
    V v_t_2410;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_os_247 = v_field_246;
        V v_t_248 = (g_heff_2ebuild_2edriver_2eanyD_24s1209362624x361966204(heff_dup(v_o_242), v_os_247));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_t_248);
          v_t_2410 = v_os_247;
        } else {
          heff_drop(v_t_248);
          V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_o_242), NTAG(TAG_Nil)});
          v_t_2410 = (g_heff_2ebuild_2edriver_2eappendD(v_os_247, v_t_249));
        }
      } else {
        heff_drop(v_field_246);
        v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_o_242), NTAG(TAG_Nil)});
      }
    }
    V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, heff_get_n(v_o_242, 0, 3), v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_rest_243;
    v_m_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eimportsByName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eimportsByName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str0, 3, "by ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str1, 5, ", at ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str3, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eplaceAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eplaceAt_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eplaceAt(V v_c_240, V v_sp_241) {
top: ;
  V v_module_242 = heff_take_field(v_c_240, 0);
  V v_shown_243 = heff_take_field(v_c_240, 2);
  V v_source_244 = heff_get_n(v_c_240, 3, 14);
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str0), v_module_242), ((V)&g_heff_2ebuild_2edriver_2eplaceAt_str1));
  V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, v_shown_243), ((V)&g_heff_2ebuild_2edriver_2eplaceAt_str2));
  V v_src_247 = v_source_244;
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str3), v_src_247, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  V v_t_2410 = ({ V a_0 = v_src_247; V a_1 = heff_get_n(v_sp_241, 0, 2); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_249; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_247); r_; });
  V v_t_2411 = heff_intAdd(heff_get_n(v_t_2410, 0, 3), MK_INT(1LL));
  return heff_strAppend(v_t_246, heff_intShow(v_t_2411));
}
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eplaceAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithPlace_str0, 3, "by ");
Clo g_heff_2ebuild_2edriver_2ewithPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithPlace_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithPlace(V v_done_240, V v_o_241, V v_g_242) {
top: ;
  V v_module_243 = heff_take_field(v_o_241, 2);
  V v_key_244 = heff_take_field(v_o_241, 1);
  V v_name_245 = heff_get_n(v_o_241, 0, 3);
  HeffT2 v_t_246 = ({ V a_0 = v_done_240; V a_1 = v_module_243; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(a_0, a_1)); heff_drop(v_module_243); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_248;
      V v_k_2410 = v_key_244;
      V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_c_249, 5)), 6, 10);
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_249, 5)), 3, 10);
      V v_t_2413 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2411, v_t_2412));
      HeffT2 v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_name_245; HeffT2 r_ = (g_heff_2ebuild_2edriver_2espanOfName_24cpr(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_name_245); r_; });
      V v_place_2418;
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_sp_2417 = v_field_2416;
          v_place_2418 = (g_heff_2ebuild_2edriver_2eplaceAt(v_c_249, v_sp_2417));
        } else {
          heff_drop(v_field_2416);
          v_place_2418 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ewithPlace_str0), heff_get_n(v_c_249, 0, 14));
        }
      }
      V v_t_2419 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_242, 5), v_k_2410, v_place_2418));
      return ({ V rv_5 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_g_242, 223ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    } else {
      heff_drop(v_key_244);
      heff_drop(v_name_245);
      heff_drop(v_field_248);
      return v_g_242;
    }
  }
}
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ewithPlace(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasQualified_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ealiasQualified(V v_done_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_g_241;
  }
  case TAG_Cons: {
    V v_q_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2ealiasQOne(v_done_240, v_g_241, heff_dup(v_q_243)));
    V t_0 = v_done_240;
    V t_1 = v_t_245;
    V t_2 = v_rest_244;
    v_done_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ealiasQualified(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2edriver_2ealiasPairs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasPairs_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ealiasPairs_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_alias_244 = heff_take_field(v_i_242, 1);
    V v_name_245 = heff_get_n(v_i_242, 0, 3);
    switch (heff_tag_of(v_alias_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_alias_244, 0);
      heff_take_n(v_alias_244, 1ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_module__alias, (V[]){v_name_245, v_a_246}), heff_hole()});
      V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_243;
      V t_1 = v_cell_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_alias_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasPairs_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    heff_drop(v_j_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x51_245, 0);
      V v_t_248 = heff_field(v_x51_245, 1);
      V v_ru_24x51_245_24MkPair = heff_take_reuse_n(v_x51_245, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), heff_dup(v_j_243)), v_t_248}));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, v_t_249}), heff_hole()});
      V v_u_2411 = (g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(v_r_240, v_i_241, v_depth_242, heff_box_word((heff_unbox_word(v_j_243) + ((int64_t)1ULL))), v_rest_246, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseFieldsGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam0(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam0, 1, 0};
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam1(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam1, 1, 0};
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1(V v_xs_240, V v_r_241, V v_i_242, V v_depth_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_xs_246 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_244), 2);
      V v_m_247 = heff_arrayLength_lent(v_xs_246, 0);
      V v_t_2412;
      if ((heff_peek_word(v_m_247) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_246);
        v_t_2412 = heff_arrayGenerate(v_m_247, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam0_clo));
      } else {
        V v_t2_249 = heff_arrayIndex_lent(v_xs_246, MK_INT(0LL), 2);
        V v_y_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t2_249}));
        V v_t_2411 = heff_arrayKeepsAs_lent(v_xs_246, v_y_2410, 0);
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_m_247);
          heff_drop(v_t_2411);
          v_t_2412 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(heff_dup(v_r_241), heff_dup(v_i_242), heff_dup(v_depth_243), MK_INT(1LL), heff_arraySet(v_xs_246, MK_INT(0LL), v_y_2410)));
        } else {
          heff_drop(v_t_2411);
          v_t_2412 = ({ V a_0 = v_xs_246; V a_1 = heff_dup(v_r_241); V a_2 = heff_dup(v_i_242); V a_3 = heff_dup(v_depth_243); V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_247, v_y_2410); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_246); r_; });
        }
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_i_242;
      V t_3 = v_depth_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_2412);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_depth_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_241, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_xs_246 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_244), 2);
    V v_m_247 = heff_arrayLength_lent(v_xs_246, 0);
    V v_t_2412;
    if ((heff_peek_word(v_m_247) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_246);
      v_t_2412 = heff_arrayGenerate(v_m_247, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam1_clo));
    } else {
      V v_t2_249 = heff_arrayIndex_lent(v_xs_246, MK_INT(0LL), 2);
      V v_y_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t2_249}));
      V v_t_2411 = heff_arrayKeepsAs_lent(v_xs_246, v_y_2410, 0);
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_m_247);
        heff_drop(v_t_2411);
        v_t_2412 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(heff_dup(v_r_241), heff_dup(v_i_242), heff_dup(v_depth_243), MK_INT(1LL), heff_arraySet(v_xs_246, MK_INT(0LL), v_y_2410)));
      } else {
        heff_drop(v_t_2411);
        v_t_2412 = ({ V a_0 = v_xs_246; V a_1 = heff_dup(v_r_241); V a_2 = heff_dup(v_i_242); V a_3 = heff_dup(v_depth_243); V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_247, v_y_2410); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_246); r_; });
      }
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_i_242;
    V t_3 = v_depth_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_2412);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_depth_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    heff_drop_rec(v_r_241, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_a_245;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam0(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return heff_abandon();
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_lam1(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return heff_abandon();
}
Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_24map0_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF_24map0(V v_r_240, V v_i_241, V v_depth_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_e2_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_e2_245}));
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_246);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_241);
      heff_drop(v_depth_242);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_e2_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_e2_245}));
    V t_0 = v_r_240;
    V t_1 = v_i_241;
    V t_2 = v_depth_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_246);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_depth_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    return v_a_244;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseTermF_24map0(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructFieldsGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructFieldsGo(V v_idx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_r_243, 0);
    V v_ty_246 = heff_get_n(v_r_243, 2, 4);
    V v_t_247 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_t_247, 0, 2), 3, (V[]){heff_dup(v_i_241), MK_INT(0LL), v_ty_246}));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_245, v_t_248}), heff_hole()});
    V v_u_2410 = (g_heff_2ebuild_2edriver_2estructFieldsGo_24dps(v_idx_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_rest_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2estructFieldsGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2estructFieldsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructFieldsGo_24dps_entry, 4, 0};

V g_heff_2ebuild_2edriver_2estructFieldsGo_24dps(V v_idx_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_name_246 = heff_take_field(v_r_244, 0);
    V v_ty_247 = heff_get_n(v_r_244, 2, 4);
    V v_t_248 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
    V v_t_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 3, (V[]){heff_dup(v_i_241), MK_INT(0LL), v_ty_247}));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_246, v_t_249}), heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_idx_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rest_245;
    V t_3 = v_cell_2410;
    v_idx_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2estructFieldsGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2estructFieldsGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixitiesGo_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efixitiesGo(V v_done_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_done_240);
    return heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_renames_244 = heff_take_field(v_s_242, 5);
    V v_implicit_245 = heff_take_field(v_s_242, 6);
    V v_source_246 = heff_take_field(v_s_242, 4);
    V v_module_247 = heff_get_n(v_s_242, 0, 8);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_module_247);
      V v_t_248 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_implicit_245), heff_dup(v_source_246)));
      V v_t_249 = (g_heff_2esyntax_2eimport_2erenamed(v_renames_244, v_t_248));
      V v_a_2410 = (g_heff_2ebuild_2edriver_2eimportedFix(v_done_240, v_t_249));
      V v_groups_2411 = heff_take_field(v_a_2410, 0);
      V v_above_2412 = heff_get_n(v_a_2410, 1, 2);
      V v_t_2413 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_245, v_source_246));
      V v_imps_2414 = ({ V a_0 = v_renames_244; V a_1 = v_t_2413; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_244); r_; });
      V v_t_2415 = ({ V a_0 = v_done_240; V a_1 = heff_dup(v_imps_2414); V r_ = (g_heff_2ebuild_2edriver_2eimportedFix(a_0, a_1)); heff_drop(v_done_240); r_; });
      V v_b_2416 = (g_heff_2esyntax_2esurface_2efixitiesOfText(v_t_2415, heff_get_n(v_imps_2414, 3, 4)));
      V v_groups_2417 = heff_take_field(v_b_2416, 0);
      V v_above_2418 = heff_get_n(v_b_2416, 1, 2);
      V v_t_2419 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_2411, v_groups_2417));
      V v_t_2420 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2419));
      V v_t_2421 = (g_heff_2esyntax_2efixity_2eappendF(v_above_2412, v_above_2418));
      V v_t_2422 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2421));
      return heff_rec_n(2, shape_groups__above, (V[]){v_t_2420, v_t_2422});
    }
    case TAG_Cons: {
      V v_t_2425 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_245, v_source_246));
      V v_imps_2426 = ({ V a_0 = v_renames_244; V a_1 = v_t_2425; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_244); r_; });
      V v_t_2427 = (g_heff_2ebuild_2edriver_2eimportedFix(v_done_240, heff_dup(v_imps_2426)));
      V v_t_2428 = (g_heff_2esyntax_2esurface_2efixitiesOfText(v_t_2427, heff_get_n(v_imps_2426, 3, 4)));
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_module_247, v_t_2428}), v_done_240});
      V t_0 = v_t_2429;
      V t_1 = v_x22_243;
      v_done_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2efixitiesGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str2, 4, " as ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str3, 21, "` is imported already");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str4, 7, "prelude");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str5, 36, ": every module imports it implicitly");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str6, 54, ": every module imports it implicitly, with the prelude");
HEFF_LIT(g_heff_2ebuild_2edriver_2eagainGo_str7, 0, "");
Clo g_heff_2ebuild_2edriver_2eagainGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eagainGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eagainGo(V v_implicit_240, V v_had_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_implicit_240);
    heff_drop(v_had_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s2037198014x392734282(heff_dup(v_i_243), v_had_241));
    V v_t_2416;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_implicit_246 = heff_dup(v_implicit_240);
      V v_i_247 = heff_dup(v_i_243);
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eagainGo_str0), heff_dup(heff_rfield(v_i_247, 0)));
      V v_t_249 = heff_dup(heff_rfield(v_i_247, 1));
      V v_t_2411;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2eagainGo_str1);
        break;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eagainGo_str2), v_a_2410);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_248, v_t_2411), ((V)&g_heff_2ebuild_2edriver_2eagainGo_str3));
      V v_t_2413 = ({ V a_0 = heff_dup(v_i_247); V a_1 = v_implicit_246; V r_ = (g_list_2eany_24s2037198014x392734282(a_0, a_1)); heff_drop(v_implicit_246); r_; });
      V v_t_2414;
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        if (heff_strEq_c(heff_dup(heff_rfield(v_i_247, 0)), ((V)&g_heff_2ebuild_2edriver_2eagainGo_str4))) {
          v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eagainGo_str5);
        } else {
          v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eagainGo_str6);
        }
      } else {
        heff_drop(v_t_2413);
        v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eagainGo_str7);
      }
      V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(334LL), NTAG(TAG_SError), heff_strAppend(v_t_2412, v_t_2414), heff_get_n(v_i_247, 2, 3), NTAG(TAG_Nothing)});
      v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_245);
      v_t_2416 = NTAG(TAG_Nil);
    }
    V v_t_2417 = (g_heff_2ebuild_2edriver_2eagainGo(v_implicit_240, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_had_241}), v_rest_244));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_2416, v_t_2417));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eagainGo(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2etwicesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwicesGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2edriver_2etwicesGo_24dps(V v_firsts_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_firsts_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_firsts_240, heff_rfield(v_d_243, 0)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_f_248 = v_field_247;
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_first__again, (V[]){v_f_248, v_d_243}), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_firsts_240;
        V t_1 = v_rest_244;
        V t_2 = v_cell_249;
        v_firsts_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_247);
        V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_firsts_240, heff_dup(heff_rfield(v_d_243, 0)), v_d_243));
        V t_0 = v_t_2411;
        V t_1 = v_rest_244;
        V t_2 = v_d_242;
        v_firsts_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etwicesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etwicesGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportOfGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eimportOfGo(V v_done_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_i_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_i_243, 0);
    V v_span_246 = heff_get_n(v_i_243, 2, 3);
    V v_t_247 = v_name_245;
    V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_t_247), NTAG(TAG_Nil)});
    HeffT2 v_t_249 = ({ V a_0 = v_done_240; V a_1 = v_t_247; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_ys_2413;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_c_2412 = v_field_2411;
        v_ys_2413 = heff_get_n(v_c_2412, 8, 14);
      } else {
        heff_drop(v_field_2411);
        v_ys_2413 = NTAG(TAG_Nil);
      }
    }
    V v_t_2414 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, v_t_248, v_ys_2413));
    V v_t_2415 = ({ V a_0 = v_m_241; V a_1 = v_t_2414; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2414); r_; });
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      heff_drop(v_t_2415);
      return v_span_246;
    } else {
      heff_drop(v_span_246);
      heff_drop(v_t_2415);
      V t_0 = v_done_240;
      V t_1 = v_m_241;
      V t_2 = v_rest_244;
      v_done_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eimportOfGo(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 5)), 6, 10);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eprimDeclsGo(heff_dup(v_x_241), heff_dup(heff_rfield(v_x_241, 7)), v_t_243));
    V v_t_245 = (g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eelabNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabNext_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eelabNext(V v_done_240, V v_s_241, V v_thaw_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_241, 6)), heff_dup(heff_rfield(v_s_241, 4))));
  V v_imps_244 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_241, 5), v_t_243));
  V v_t_245 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_244, 0))));
  V v_ms_246 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_245));
  V v_t_247 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, NTAG(TAG_Nil), v_ms_246));
  return ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = v_imps_244; V a_3 = v_thaw_242; V a_4 = v_t_247; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eelabNext(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str0, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str1, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str2, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str3, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str4, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str5, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str6, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str7, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str8, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str9, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str10, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str11, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str12, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str13, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str14, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str15, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str16, 4, "prim");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str17, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str18, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str19, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str20, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str21, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str22, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str23, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str24, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str25, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str26, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str27, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str28, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str29, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str30, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str31, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str32, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str33, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str34, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str35, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str36, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str37, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str38, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str39, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str40, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str41, 4, "prim");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str42, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str43, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str44, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str45, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str46, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str47, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str48, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str49, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str50, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str51, 5, "plain");
Clo g_heff_2ebuild_2edriver_2edefKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2edefKind_entry, 2, 0};

V g_heff_2ebuild_2edriver_2edefKind(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 10);
  V v_entries_243 = heff_take_field(v_g_242, 1);
  V v_aliases_244 = heff_get_n(v_g_242, 2, 8);
  HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_243, v_k_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_entries_243);
      heff_drop(v_aliases_244);
      V v_e_248 = v_field_247;
      V v_t_249 = heff_get_n(v_e_248, 0, 4);
      switch (heff_tag_of(v_t_249)) {
      case TAG_SLocal: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str0);
      }
      case TAG_SGlobal: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str1);
      }
      case TAG_SCode: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str2);
      }
      case TAG_SApp: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str3);
      }
      case TAG_SLam: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str4);
      }
      case TAG_SCons: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str5);
      }
      case TAG_SProj: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str6);
      }
      case TAG_STag: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str7);
      }
      case TAG_SMatch: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str8);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_t_249, 0ULL, 3);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str9);
      }
      case TAG_SIs: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str10);
      }
      case TAG_SOpaque: {
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str11);
      }
      case TAG_SAbandon: {
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str12);
      }
      case TAG_SRec: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str13);
      }
      case TAG_SFix: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str14);
      }
      case TAG_SImplicit: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str15);
      }
      case TAG_SPrim: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str16);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_t_249, 0ULL, 3);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str17);
      }
      case TAG_SLitInt: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str18);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str19);
      }
      case TAG_SLitString: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str20);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str21);
      }
      case TAG_SLitRune: {
        heff_take_n(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str22);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_t_249, 0ULL, 2);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str23);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_t_249, 0ULL, 1);
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str24);
      }
      default: return heff_nomatch(v_t_249);
      }
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_2445 = ({ V a_0 = v_aliases_244; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_244); r_; });
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_k2_2448 = v_field_2447;
          HeffT2 v_t_2449 = ({ V a_0 = v_entries_243; V a_1 = v_k2_2448; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_243); heff_drop(v_k2_2448); r_; });
          {
            V v_field_2451 = v_t_2449.f[1];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            if ((v_tag_2450 == ((int64_t)0ULL))) {
              V v_e_2452 = v_field_2451;
              V v_t_2453 = heff_get_n(v_e_2452, 0, 4);
              switch (heff_tag_of(v_t_2453)) {
              case TAG_SLocal: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str25);
              }
              case TAG_SGlobal: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str26);
              }
              case TAG_SCode: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str27);
              }
              case TAG_SApp: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str28);
              }
              case TAG_SLam: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str29);
              }
              case TAG_SCons: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str30);
              }
              case TAG_SProj: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str31);
              }
              case TAG_STag: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str32);
              }
              case TAG_SMatch: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str33);
              }
              case TAG_SSpecialize: {
                heff_take_n(v_t_2453, 0ULL, 3);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str34);
              }
              case TAG_SIs: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str35);
              }
              case TAG_SOpaque: {
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str36);
              }
              case TAG_SAbandon: {
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str37);
              }
              case TAG_SRec: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str38);
              }
              case TAG_SFix: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str39);
              }
              case TAG_SImplicit: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str40);
              }
              case TAG_SPrim: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str41);
              }
              case TAG_SMetaApp: {
                heff_take_n(v_t_2453, 0ULL, 3);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str42);
              }
              case TAG_SLitInt: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str43);
              }
              case TAG_SLitFloat: {
                heff_take_na(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str44);
              }
              case TAG_SLitString: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str45);
              }
              case TAG_SLitBytes: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str46);
              }
              case TAG_SLitRune: {
                heff_take_n(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str47);
              }
              case TAG_SLitFixed: {
                heff_take_n(v_t_2453, 0ULL, 2);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str48);
              }
              case TAG_SLitFloat32: {
                heff_take_na(v_t_2453, 0ULL, 1);
                return ((V)&g_heff_2ebuild_2edriver_2edefKind_str49);
              }
              default: return heff_nomatch(v_t_2453);
              }
            } else {
              heff_drop(v_field_2451);
              return ((V)&g_heff_2ebuild_2edriver_2edefKind_str50);
            }
          }
        } else {
          heff_drop(v_entries_243);
          heff_drop(v_field_2447);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str51);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2edefKind(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_c_241)}});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str1, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str3, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str4, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str5, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str6, 1, ">");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str7, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str8, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str9, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str10, 1, ">");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str11, 8, "-- | >>>");
Clo g_heff_2ebuild_2edriver_2emkWatchInfo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emkWatchInfo_entry, 6, 0};

V g_heff_2ebuild_2edriver_2emkWatchInfo(V v_c_240, V v_ge_241, V v_w_242, V v_r_243, V v_ex_244, V v_ty_245) {
top: ;
  V v_expected_246 = heff_take_field(v_ex_244, 0);
  V v_from_247 = heff_take_field(v_ex_244, 1);
  V v_to_248 = heff_get_n(v_ex_244, 2, 3);
  V v_source_249 = heff_take_field(v_c_240, 3);
  V v_top_2410 = heff_get_n(v_c_240, 5, 14);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 0, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 1, 2);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 0, 2);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 1, 2);
  V v_s_2415 = heff_strSlice_lent(v_source_249, v_t_2413, v_t_2414, 6);
  V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2415, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_s_2415, 0)) - ((int64_t)1ULL));
  V v_t_2418 = (g_prelude_2eskipSpaces(v_s_2415, heff_box_word(v_t_2417), MK_INT(-1LL)));
  V v_s_2419 = heff_strSlice(v_s_2415, v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
  V v_s_2420;
  if (heff_strEq_c(heff_strSlice_lent(v_s_2419, MK_INT(0LL), MK_INT(6LL), 6), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str0))) {
    v_s_2420 = heff_strSlice(heff_dup(v_s_2419), MK_INT(6LL), heff_strLength(v_s_2419));
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_2419, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str1))) {
      v_s_2420 = heff_strSlice(heff_dup(v_s_2419), MK_INT(8LL), heff_strLength(v_s_2419));
    } else {
      heff_drop(v_s_2419);
      v_s_2420 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str2);
    }
  }
  V v_t_2421 = (g_prelude_2eskipSpaces(v_s_2420, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_s_2420, 0)) - ((int64_t)1ULL));
  V v_t_2423 = (g_prelude_2eskipSpaces(v_s_2420, heff_box_word(v_t_2422), MK_INT(-1LL)));
  V v_t_2424 = heff_strSlice(v_s_2420, v_t_2421, heff_intAdd(v_t_2423, MK_INT(1LL)));
  V v_t_2427;
  switch (heff_tag_of(v_r_243)) {
  case TAG_RSucceeded: {
    V v_v_2425 = heff_dup(heff_field(v_r_243, 0));
    v_t_2427 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2425; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_RAbandoned: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str3);
    break;
  }
  case TAG_RDiverged: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str4);
    break;
  }
  case TAG_RBug: {
    V v_what_2426 = heff_dup(heff_field(v_r_243, 0));
    v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str5), v_what_2426), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str6));
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_ge_2428 = v_ge_241;
  V v_g_2429 = heff_get_n(v_top_2410, 0, 10);
  V v_ty_2430 = heff_dup(v_ty_245);
  V v_r_2431 = heff_dup(v_r_243);
  V v_value_2434;
  switch (heff_tag_of(v_r_243)) {
  case TAG_RSucceeded: {
    V v_v_2432 = heff_field(v_r_243, 0);
    V v_ru_24r_243_24RSucceeded = heff_take_reuse_n(v_r_243, 1ULL, 1);
    v_value_2434 = ({ V a_0 = v_ru_24r_243_24RSucceeded; V b_1 = NTAG(TAG_False); V a_2 = v_v_2432; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    break;
  }
  case TAG_RAbandoned: {
    v_value_2434 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str7);
    break;
  }
  case TAG_RDiverged: {
    v_value_2434 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str8);
    break;
  }
  case TAG_RBug: {
    V v_what_2433 = heff_field(v_r_243, 0);
    heff_take_n(v_r_243, 1ULL, 1);
    v_value_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str9), v_what_2433), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str10));
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_x6_2435 = heff_dup(v_expected_246);
  V v_t_2453;
  switch (heff_tag_of(v_r_2431)) {
  case TAG_RSucceeded: {
    heff_take_n(v_r_2431, 0ULL, 1);
    switch (heff_tag_of(v_x6_2435)) {
    case TAG_Nothing: {
      heff_drop(v_ge_2428);
      heff_drop(v_g_2429);
      heff_drop(v_ty_2430);
      heff_drop(v_value_2434);
      v_t_2453 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      V v_e_2437 = heff_field(v_x6_2435, 0);
      heff_take_n(v_x6_2435, 1ULL, 1);
      if (heff_strEq_c_lent(v_e_2437, v_value_2434, 0)) {
        heff_drop(v_ge_2428);
        heff_drop(v_g_2429);
        heff_drop(v_ty_2430);
        heff_drop(v_value_2434);
        heff_drop(v_e_2437);
        v_t_2453 = NTAG(TAG_True);
      } else {
        HeffT2 v_t_2438 = ({ V a_0 = v_ge_2428; V a_1 = v_g_2429; V a_2 = v_ty_2430; V a_3 = v_e_2437; HeffT2 r_ = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_e_2437); r_; });
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            V v_v_2441 = v_field_2440;
            v_t_2453 = heff_bool(heff_strEq_c_lent(v_v_2441, v_value_2434, 0));
            heff_drop(v_value_2434);
            heff_drop(v_v_2441);
          } else {
            heff_drop(v_value_2434);
            heff_drop(v_field_2440);
            v_t_2453 = NTAG(TAG_False);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x6_2435);
    }
    break;
  }
  case TAG_RAbandoned: {
    switch (heff_tag_of(v_x6_2435)) {
    case TAG_Nothing: {
      heff_drop(v_ge_2428);
      heff_drop(v_g_2429);
      heff_drop(v_ty_2430);
      heff_drop(v_value_2434);
      v_t_2453 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      V v_e_2442 = heff_field(v_x6_2435, 0);
      heff_take_n(v_x6_2435, 1ULL, 1);
      if (heff_strEq_c_lent(v_e_2442, v_value_2434, 0)) {
        heff_drop(v_ge_2428);
        heff_drop(v_g_2429);
        heff_drop(v_ty_2430);
        heff_drop(v_value_2434);
        heff_drop(v_e_2442);
        v_t_2453 = NTAG(TAG_True);
      } else {
        HeffT2 v_t_2443 = ({ V a_0 = v_ge_2428; V a_1 = v_g_2429; V a_2 = v_ty_2430; V a_3 = v_e_2442; HeffT2 r_ = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_e_2442); r_; });
        {
          V v_field_2445 = v_t_2443.f[1];
          int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
          if ((v_tag_2444 == ((int64_t)0ULL))) {
            V v_v_2446 = v_field_2445;
            v_t_2453 = heff_bool(heff_strEq_c_lent(v_v_2446, v_value_2434, 0));
            heff_drop(v_value_2434);
            heff_drop(v_v_2446);
          } else {
            heff_drop(v_value_2434);
            heff_drop(v_field_2445);
            v_t_2453 = NTAG(TAG_False);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x6_2435);
    }
    break;
  }
  case TAG_RDiverged: {
    switch (heff_tag_of(v_x6_2435)) {
    case TAG_Nothing: {
      heff_drop(v_ge_2428);
      heff_drop(v_g_2429);
      heff_drop(v_ty_2430);
      heff_drop(v_value_2434);
      v_t_2453 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      V v_e_2447 = heff_field(v_x6_2435, 0);
      heff_take_n(v_x6_2435, 1ULL, 1);
      if (heff_strEq_c_lent(v_e_2447, v_value_2434, 0)) {
        heff_drop(v_ge_2428);
        heff_drop(v_g_2429);
        heff_drop(v_ty_2430);
        heff_drop(v_value_2434);
        heff_drop(v_e_2447);
        v_t_2453 = NTAG(TAG_True);
      } else {
        HeffT2 v_t_2448 = ({ V a_0 = v_ge_2428; V a_1 = v_g_2429; V a_2 = v_ty_2430; V a_3 = v_e_2447; HeffT2 r_ = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_e_2447); r_; });
        {
          V v_field_2450 = v_t_2448.f[1];
          int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
          if ((v_tag_2449 == ((int64_t)0ULL))) {
            V v_v_2451 = v_field_2450;
            v_t_2453 = heff_bool(heff_strEq_c_lent(v_v_2451, v_value_2434, 0));
            heff_drop(v_value_2434);
            heff_drop(v_v_2451);
          } else {
            heff_drop(v_value_2434);
            heff_drop(v_field_2450);
            v_t_2453 = NTAG(TAG_False);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x6_2435);
    }
    break;
  }
  case TAG_RBug: {
    heff_take_n(v_r_2431, 0ULL, 1);
    heff_drop(v_ge_2428);
    heff_drop(v_g_2429);
    heff_drop(v_ty_2430);
    heff_drop(v_value_2434);
    heff_drop(v_x6_2435);
    v_t_2453 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_r_2431);
  }
  V v_start_2454 = heff_get_n(heff_get_n(v_w_242, 0, 2), 0, 2);
  V v_t_2455 = heff_strSlice(v_source_249, heff_dup(v_start_2454), heff_intAdd(v_start_2454, MK_INT(8LL)));
  V v_t_2456 = heff_bool(heff_strEq_c_lent(v_t_2455, ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str11), 2));
  heff_drop(v_t_2455);
  return heff_rec_n(10, shape_from__to__expr__ty__value__expected__holds__expectFrom__expectTo__doc, (V[]){v_t_2411, v_t_2412, v_t_2424, v_ty_245, v_t_2427, v_expected_246, v_t_2453, v_from_247, v_to_248, v_t_2456});
}
V g_heff_2ebuild_2edriver_2emkWatchInfo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2emkWatchInfo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_24dps_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_24dps_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_24dps_str2, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_24dps_str3, 1, ">");
Clo g_heff_2ebuild_2edriver_2eevalPick_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalPick_24dps_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eevalPick_24dps(V v_g_240, V v_results_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_key_246 = heff_take_field(v_o_244, 1);
    V v_name_247 = heff_get_n(v_o_244, 0, 2);
    HeffT2 v_t_248 = (g_list_2elookup_24s1507486579x90027037_24cpr(v_key_246, v_results_241));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_r_2411 = v_field_2410;
        V v_g_2412 = heff_dup(v_g_240);
        V v_entries_2413 = heff_take_field(v_g_2412, 1);
        V v_aliases_2414 = heff_get_n(v_g_2412, 2, 8);
        V v_k_2415 = v_key_246;
        V v_r_2416 = v_r_2411;
        HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2413, v_k_2415));
        V v_it_2433;
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            heff_drop(v_entries_2413);
            heff_drop(v_aliases_2414);
            heff_drop(v_k_2415);
            V v_e_2420 = v_field_2419;
            V v_t_2421 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_2420, 3, 4)));
            V v_t_2422 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2421));
            v_it_2433 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2422, v_r_2416));
          } else {
            heff_drop(v_field_2419);
            HeffT2 v_t_2423 = ({ V a_0 = v_aliases_2414; V a_1 = v_k_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2414); heff_drop(v_k_2415); r_; });
            {
              V v_field_2425 = v_t_2423.f[1];
              int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
              if ((v_tag_2424 == ((int64_t)0ULL))) {
                V v_k2_2426 = v_field_2425;
                HeffT2 v_t_2427 = ({ V a_0 = v_entries_2413; V a_1 = v_k2_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2413); heff_drop(v_k2_2426); r_; });
                {
                  V v_field_2429 = v_t_2427.f[1];
                  int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                  if ((v_tag_2428 == ((int64_t)0ULL))) {
                    V v_e_2430 = v_field_2429;
                    V v_t_2431 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_2430, 3, 4)));
                    V v_t_2432 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2431));
                    v_it_2433 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2432, v_r_2416));
                  } else {
                    heff_drop(v_field_2429);
                    v_it_2433 = v_r_2416;
                  }
                }
              } else {
                heff_drop(v_entries_2413);
                heff_drop(v_field_2425);
                v_it_2433 = v_r_2416;
              }
            }
          }
        }
        V v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_247));
        V v_t_2437;
        switch (heff_tag_of(v_it_2433)) {
        case TAG_RSucceeded: {
          V v_v_2435 = heff_dup(heff_field(v_it_2433, 0));
          v_t_2437 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2435; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
          break;
        }
        case TAG_RAbandoned: {
          v_t_2437 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_24dps_str0);
          break;
        }
        case TAG_RDiverged: {
          v_t_2437 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_24dps_str1);
          break;
        }
        case TAG_RBug: {
          V v_what_2436 = heff_dup(heff_field(v_it_2433, 0));
          v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eevalPick_24dps_str2), v_what_2436), ((V)&g_heff_2ebuild_2edriver_2eevalPick_24dps_str3));
          break;
        }
        default: heff_nomatch(v_it_2433);
        }
        V v_t_2440;
        switch (heff_tag_of(v_it_2433)) {
        case TAG_RSucceeded: {
          heff_take_n(v_it_2433, 0ULL, 1);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        case TAG_RAbandoned: {
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        case TAG_RDiverged: {
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        case TAG_RBug: {
          heff_take_n(v_it_2433, 0ULL, 1);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it_2433);
        }
        V v_cell_2441 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__value__bug, (V[]){v_t_2434, v_t_2437, v_t_2440}), heff_hole()});
        V v_u_2442 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2441));
        heff_drop(v_u_2442);
        V t_0 = v_g_240;
        V t_1 = v_results_241;
        V t_2 = v_rest_245;
        V t_3 = v_cell_2441;
        v_g_240 = t_0;
        v_results_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_key_246);
        heff_drop(v_name_247);
        heff_drop(v_field_2410);
        V t_0 = v_g_240;
        V t_1 = v_results_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_g_240 = t_0;
        v_results_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eevalPick_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eevalPick_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eisBenchTy_str0, 11, "bench.Bench");
Clo g_heff_2ebuild_2edriver_2eisBenchTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisBenchTy_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eisBenchTy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLocal: {
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      V v_k_244 = heff_field(v_x11_242, 0);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_k_244, ((V)&g_heff_2ebuild_2edriver_2eisBenchTy_str0), 2));
      return v_ret_24bool;
    }
    case TAG_SCode: {
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_SFunction: {
    return NTAG(TAG_False);
  }
  case TAG_SRecord: {
    return NTAG(TAG_False);
  }
  case TAG_SSum: {
    return NTAG(TAG_False);
  }
  case TAG_SIsTy: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    return NTAG(TAG_False);
  }
  case TAG_SFixed: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eisBenchTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eisBenchTy(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2efieldV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efieldV_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efieldV(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return NTAG(TAG_VErased);
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_byName_244 = heff_dup(heff_rfield(v_fs_243, 1));
    V v_values_245 = heff_dup(heff_rfield(v_fs_243, 2));
    HeffT2 v_t_246 = ({ V a_0 = v_byName_244; V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_244); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_i_249 = v_field_248;
        V v_xs_2410 = v_values_245;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_249, 1) && heff_intLt_c(heff_dup(v_i_249), heff_arrayLength_lent(v_xs_2410, 0)))) {
          V v_v_2411 = heff_arrayIndex(v_xs_2410, v_i_249);
          return v_v_2411;
        } else {
          heff_drop(v_i_249);
          heff_drop(v_xs_2410);
          return NTAG(TAG_VErased);
        }
      } else {
        heff_drop(v_values_245);
        heff_drop(v_field_248);
        return NTAG(TAG_VErased);
      }
    }
  }
  case TAG_VTag: {
    return NTAG(TAG_VErased);
  }
  case TAG_VInt: {
    return NTAG(TAG_VErased);
  }
  case TAG_VFloat: {
    return NTAG(TAG_VErased);
  }
  case TAG_VFloat32: {
    return NTAG(TAG_VErased);
  }
  case TAG_VStr: {
    return NTAG(TAG_VErased);
  }
  case TAG_VRune: {
    return NTAG(TAG_VErased);
  }
  case TAG_VArr: {
    return NTAG(TAG_VErased);
  }
  case TAG_VBytes: {
    return NTAG(TAG_VErased);
  }
  case TAG_VBits: {
    return NTAG(TAG_VErased);
  }
  case TAG_VErased: {
    return NTAG(TAG_VErased);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2efieldV(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_24dps_str11, 4, "Cons");
Clo g_heff_2ebuild_2edriver_2elistOfV_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistOfV_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2elistOfV_24dps(V v_v_240, V v_d_241) {
top: ;
  V v_t_2415;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_244 = heff_dup(heff_field(v_v_240, 0));
    v_t_2415 = v_x_244;
    break;
  }
  case TAG_VInt: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2edriver_2elistOfV_24dps_str11))) {
    V v_t_2429;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2419 = heff_dup(heff_field(v_v_240, 1));
      v_t_2429 = v_vs_2419;
      break;
    }
    case TAG_VInt: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2429; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2436;
    {
      V v_field_2432 = v_t_2430.f[1];
      V v_field_2433 = v_t_2430.f[2];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2432;
        V v_x12_2435 = v_field_2433;
        heff_drop(v_x12_2435);
        v_t_2436 = v_x_2434;
      } else {
        heff_drop(v_field_2432);
        heff_drop(v_field_2433);
        v_t_2436 = NTAG(TAG_VErased);
      }
    }
    V v_cell_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, heff_hole()});
    V v_u_2438 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2437));
    heff_drop(v_u_2438);
    V v_t_2452;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2442 = heff_field(v_v_240, 1);
      heff_take_n(v_v_240, 2ULL, 2);
      v_t_2452 = v_vs_2442;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_v_240, 0ULL, 2);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2459;
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2455;
        V v_x12_2458 = v_field_2456;
        heff_drop(v_x12_2458);
        v_t_2459 = v_x_2457;
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        v_t_2459 = NTAG(TAG_VErased);
      }
    }
    V t_0 = v_t_2459;
    V t_1 = v_cell_2437;
    v_v_240 = t_0;
    v_d_241 = t_1;
    goto top;
  } else {
    heff_drop(v_v_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
}
V g_heff_2ebuild_2edriver_2elistOfV_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elistOfV_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str2, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str3, 1, ">");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str4, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str5, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str6, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str7, 1, ">");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str8, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str9, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str10, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str11, 1, ">");
Clo g_heff_2ebuild_2edriver_2eoutcomesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eoutcomesOf_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eoutcomesOf(V v_o_240, V v_seed_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_RSucceeded: {
    V v_v_243 = heff_field(v_r_242, 0);
    heff_take_n(v_r_242, 1ULL, 1);
    heff_drop_rec(v_o_240, 2);
    heff_drop(v_seed_241);
    V v_t_244 = ({ V a_0 = v_v_243; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_v_243); r_; });
    return (g_list_2emap_24s1895313378x47656836(v_t_244));
  }
  case TAG_RAbandoned: {
    V v_name_245 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_get_n(v_o_240, 0, 2)));
    V v_why_248;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_246 = heff_field(v_r_242, 0);
      V v_ru_24r_242_24RSucceeded = heff_take_reuse_n(v_r_242, 1ULL, 1);
      v_why_248 = ({ V a_0 = v_ru_24r_242_24RSucceeded; V b_1 = NTAG(TAG_False); V a_2 = v_v_246; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_248 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str0);
      break;
    }
    case TAG_RDiverged: {
      v_why_248 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str1);
      break;
    }
    case TAG_RBug: {
      V v_what_247 = heff_field(v_r_242, 0);
      heff_take_n(v_r_242, 1ULL, 1);
      v_why_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str2), v_what_247), ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str3));
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_248})});
    V v_t_2410 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_245, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_249, v_seed_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_RDiverged: {
    V v_name_2411 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_get_n(v_o_240, 0, 2)));
    V v_why_2414;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_2412 = heff_field(v_r_242, 0);
      V v_ru_24r_242_24RSucceeded = heff_take_reuse_n(v_r_242, 1ULL, 1);
      v_why_2414 = ({ V a_0 = v_ru_24r_242_24RSucceeded; V b_1 = NTAG(TAG_False); V a_2 = v_v_2412; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_2414 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str4);
      break;
    }
    case TAG_RDiverged: {
      v_why_2414 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str5);
      break;
    }
    case TAG_RBug: {
      V v_what_2413 = heff_field(v_r_242, 0);
      heff_take_n(v_r_242, 1ULL, 1);
      v_why_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str6), v_what_2413), ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str7));
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2414})});
    V v_t_2416 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_2411, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2415, v_seed_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  }
  case TAG_RBug: {
    V v_name_2418 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_get_n(v_o_240, 0, 2)));
    V v_why_2421;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_2419 = heff_field(v_r_242, 0);
      V v_ru_24r_242_24RSucceeded = heff_take_reuse_n(v_r_242, 1ULL, 1);
      v_why_2421 = ({ V a_0 = v_ru_24r_242_24RSucceeded; V b_1 = NTAG(TAG_False); V a_2 = v_v_2419; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_2421 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str8);
      break;
    }
    case TAG_RDiverged: {
      v_why_2421 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str9);
      break;
    }
    case TAG_RBug: {
      V v_what_2420 = heff_field(v_r_242, 0);
      heff_take_n(v_r_242, 1ULL, 1);
      v_why_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str10), v_what_2420), ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str11));
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2421})});
    V v_t_2423 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_2418, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2422, v_seed_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ebuild_2edriver_2eoutcomesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eoutcomesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epickOutcomes_str0, 7, "> test ");
Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epickOutcomes_entry, 4, 0};

V g_heff_2ebuild_2edriver_2epickOutcomes(V v_seed_240, V v_rs_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2epickOutcomes_str0), heff_intShow(heff_dup(v_i_242)));
    HeffT2 v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_rs_241; HeffT2 r_ = (g_list_2elookup_24s1507486579x90027037_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_2411;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_r_2410 = v_field_249;
        v_t_2411 = (g_heff_2ebuild_2edriver_2eoutcomesOf(heff_dup(v_o_244), heff_dup(v_seed_240), v_r_2410));
      } else {
        heff_drop(v_field_249);
        v_t_2411 = NTAG(TAG_Nil);
      }
    }
    V v_t_2412 = (g_heff_2ebuild_2edriver_2epickOutcomes(v_seed_240, v_rs_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245));
    return (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2epickOutcomes(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLines_24acc_str0, 0, "");
Clo g_heff_2ebuild_2edriver_2efixityLines_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLines_24acc_entry, 4, 0};

V g_heff_2ebuild_2edriver_2efixityLines_24acc(V v_fx_240, V v_i_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    return heff_strAppend(v_acc_243, ((V)&g_heff_2ebuild_2edriver_2efixityLines_24acc_str0));
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_t_246 = (g_heff_2ebuild_2edriver_2efixityLine(heff_dup(v_fx_240), heff_dup(v_i_241), heff_dup(v_g_244)));
    V v_s_247 = heff_strAppend(v_acc_243, v_t_246);
    V t_0 = v_fx_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rest_245;
    V t_3 = v_s_247;
    v_fx_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2efixityLines_24acc_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2efixityLines_24acc(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str1, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str4, 9, "instance ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str5, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str7, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str9, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str11, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str12, 1, "\012");
Clo g_heff_2ebuild_2edriver_2esigEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2esigEntry_entry, 3, 0};

V g_heff_2ebuild_2edriver_2esigEntry(V v_c_240, V v_ln_241, V v_o_242) {
top: ;
  V v_key_243 = heff_take_field(v_o_242, 1);
  V v_name_244 = heff_get_n(v_o_242, 0, 2);
  V v_top_245 = heff_take_field(v_c_240, 5);
  V v_exposes_246 = heff_get_n(v_c_240, 13, 14);
  V v_g_247 = heff_dup(heff_rfield(v_top_245, 0));
  V v_entries_248 = heff_take_field(v_g_247, 1);
  V v_aliases_249 = heff_get_n(v_g_247, 2, 8);
  V v_k_2410 = heff_dup(v_key_243);
  HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_248, v_k_2410));
  V v_t_2419;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_entries_248);
      heff_drop(v_aliases_249);
      heff_drop(v_k_2410);
      V v_e_2414 = v_field_2413;
      v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2414});
    } else {
      heff_drop(v_field_2413);
      HeffT2 v_t_2415 = ({ V a_0 = v_aliases_249; V a_1 = v_k_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_249); heff_drop(v_k_2410); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_k2_2418 = v_field_2417;
          v_t_2419 = ({ V a_0 = v_entries_248; V a_1 = v_k2_2418; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_entries_248); heff_drop(v_k2_2418); r_; });
        } else {
          heff_drop(v_entries_248);
          heff_drop(v_field_2417);
          v_t_2419 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    heff_drop(v_ln_241);
    heff_drop(v_key_243);
    heff_drop(v_name_244);
    heff_drop_rec(v_top_245, 10);
    heff_drop(v_exposes_246);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_e_2420 = heff_field(v_t_2419, 0);
    V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
    V v_tySyntax_2421 = heff_take_field(v_e_2420, 1);
    V v_syntax_2422 = heff_get_n(v_e_2420, 0, 4);
    V v_t_2425;
    switch (heff_tag_of(v_exposes_246)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_es_2423 = heff_field(v_exposes_246, 0);
      heff_take_n(v_exposes_246, 1ULL, 1);
      V v_x1_2424 = ({ V a_0 = v_name_244; V a_1 = v_es_2423; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(a_0, a_1)); heff_drop(v_es_2423); r_; });
      if (!(heff_dup(v_x1_2424) == NTAG(TAG_True))) {
        heff_drop(v_x1_2424);
        v_t_2425 = (g_heff_2esyntax_2esurfaceprint_2eisData(heff_dup(v_tySyntax_2421), heff_dup(v_syntax_2422)));
      } else {
        heff_drop(v_x1_2424);
        v_t_2425 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_exposes_246);
    }
    V v_t_2491;
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_key_243);
      heff_drop_rec(v_top_245, 10);
      heff_drop(v_t_2425);
      V v_name_2426 = v_name_244;
      V v_t_2427 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_ln_241)));
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_t_2427, 1, 2), 1, (V[]){v_tySyntax_2421}));
      V v_t_2429 = (g_heff_2eelab_2erename_2erkOf(v_ln_241));
      V v_body_2430 = heff_tr(heff_call(heff_get_n(v_t_2429, 0, 2), 1, (V[]){v_syntax_2422}));
      V v_name_2431 = heff_dup(v_name_2426);
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_2426, NTAG(TAG_Nil)});
      HeffT2 v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(v_t_2428, v_body_2430, v_t_2432, NTAG(TAG_Nil)));
      V v_x2_2456;
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        if ((v_tag_2434 == ((int64_t)0ULL))) {
          V v_tf_2436 = v_field_2435;
          V v_def_2437 = heff_take_field(v_tf_2436, 2);
          V v_large_2438 = heff_take_field(v_tf_2436, 3);
          V v_params_2439 = heff_get_n(v_tf_2436, 0, 4);
          switch (heff_tag_of(v_def_2437)) {
          case TAG_SU: {
            heff_take_n(v_def_2437, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SDecode: {
            heff_take_n(v_def_2437, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SFunction: {
            heff_take_n(v_def_2437, 0ULL, 5);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SRecord: {
            heff_take_n(v_def_2437, 0ULL, 3);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SSum: {
            heff_take_n(v_def_2437, 0ULL, 1);
            if (!(heff_dup(v_large_2438) == NTAG(TAG_True))) {
              heff_drop(v_large_2438);
              V v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2esigEntry_str0); V a_1 = v_name_2431; V a_2 = v_params_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_params_2439); r_; });
              V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str1), v_t_2451), ((V)&g_heff_2ebuild_2edriver_2esigEntry_str2));
              v_x2_2456 = heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){v_t_2452});
            } else {
              heff_drop_cell(v_ru_24t_2419_24Just, 1);
              heff_drop(v_name_2431);
              heff_drop(v_large_2438);
              heff_drop(v_params_2439);
              v_x2_2456 = NTAG(TAG_Nothing);
            }
            break;
          }
          case TAG_SIsTy: {
            heff_take_n(v_def_2437, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimInt: {
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimFloat: {
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimString: {
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimRune: {
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimArray: {
            heff_take_n(v_def_2437, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SFixed: {
            heff_take_n(v_def_2437, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop(v_name_2431);
            heff_drop(v_large_2438);
            heff_drop(v_params_2439);
            v_x2_2456 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_def_2437);
          }
        } else {
          heff_drop_cell(v_ru_24t_2419_24Just, 1);
          heff_drop(v_name_2431);
          heff_drop(v_field_2435);
          v_x2_2456 = NTAG(TAG_Nothing);
        }
      }
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nothing: {
        v_t_2491 = ((V)&g_heff_2ebuild_2edriver_2esigEntry_str3);
        break;
      }
      case TAG_Just: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        heff_take_n(v_x2_2456, 1ULL, 1);
        v_t_2491 = v_x_2457;
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
    } else {
      heff_drop_cell(v_ru_24t_2419_24Just, 1);
      heff_drop(v_t_2425);
      V v_t_2458 = heff_get_n(heff_get_n(v_top_245, 0, 10), 7, 8);
      V v_t_2459 = ({ V a_0 = v_key_243; V a_1 = v_t_2458; V r_ = (g_list_2eany_24s1547578820x1498276962(a_0, a_1)); heff_drop(v_key_243); heff_drop(v_t_2458); r_; });
      if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
        heff_drop(v_syntax_2422);
        heff_drop(v_t_2459);
        V v_shown_2460 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_244));
        V v_t_2461 = (g_heff_2eelab_2erename_2erkOf(v_ln_241));
        V v_t_2462 = heff_tr(heff_call(heff_get_n(v_t_2461, 1, 2), 1, (V[]){v_tySyntax_2421}));
        V v_t_2463 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str4), v_shown_2460), ((V)&g_heff_2ebuild_2edriver_2esigEntry_str5));
        V v_t_2464 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2462; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2462); r_; });
        v_t_2491 = heff_strAppend(heff_strAppend(v_t_2463, v_t_2464), ((V)&g_heff_2ebuild_2edriver_2esigEntry_str6));
      } else {
        heff_drop(v_t_2459);
        V v_name_2465 = heff_dup(v_name_244);
        V v_shown_2466 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_244));
        V v_t_2467 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_ln_241)));
        V v_t_2468 = heff_tr(heff_call(heff_get_n(v_t_2467, 1, 2), 1, (V[]){v_tySyntax_2421}));
        V v_t_2469 = (g_heff_2eelab_2erename_2erkOf(v_ln_241));
        V v_body_2470 = heff_tr(heff_call(heff_get_n(v_t_2469, 0, 2), 1, (V[]){v_syntax_2422}));
        switch (heff_tag_of(v_body_2470)) {
        case TAG_SAbandon: {
          heff_drop(v_name_2465);
          V v_t_2471 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2468; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2468); r_; });
          V v_t_2472 = heff_strAppend(heff_strAppend(v_shown_2466, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str7)), v_t_2471);
          v_t_2491 = heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str8));
          break;
        }
        default: {
          HeffT2 v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_24cpr(v_body_2470));
          {
            V v_field_2475 = v_t_2473.f[1];
            int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
            if ((v_tag_2474 == ((int64_t)0ULL))) {
              heff_drop(v_name_2465);
              heff_drop(v_body_2470);
              V v_x_2476 = v_field_2475;
              heff_drop(v_x_2476);
              V v_t_2477 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2468; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2468); r_; });
              V v_t_2478 = heff_strAppend(heff_strAppend(v_shown_2466, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str9)), v_t_2477);
              v_t_2491 = heff_strAppend(v_t_2478, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str10));
            } else {
              heff_drop(v_field_2475);
              V v_t_2479 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2468));
              V v_t_2480 = heff_strAppend(heff_strAppend(v_shown_2466, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str11)), v_t_2479);
              V v_d_2481 = heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str12));
              V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_2465), NTAG(TAG_Nil)});
              HeffT2 v_t_2483 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(v_t_2468, v_body_2470, v_t_2482, NTAG(TAG_Nil)));
              {
                V v_field_2485 = v_t_2483.f[1];
                int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
                if ((v_tag_2484 == ((int64_t)0ULL))) {
                  V v_tf_2486 = v_field_2485;
                  HeffT2 v_t_2487 = (g_heff_2esyntax_2esurfaceprint_2eformerOf_24s57293002x1220395614_24cpr(MK_INT(0LL), v_name_2465, v_tf_2486));
                  {
                    V v_field_2489 = v_t_2487.f[1];
                    int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
                    if ((v_tag_2488 == ((int64_t)0ULL))) {
                      heff_drop(v_d_2481);
                      V v_x_2490 = v_field_2489;
                      v_t_2491 = v_x_2490;
                    } else {
                      heff_drop(v_field_2489);
                      v_t_2491 = v_d_2481;
                    }
                  }
                } else {
                  heff_drop(v_name_2465);
                  heff_drop(v_field_2485);
                  v_t_2491 = v_d_2481;
                }
              }
            }
          }
          break;
        }
        }
      }
    }
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2491});
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2esigEntry(a[0], a[1], a[2]);
}