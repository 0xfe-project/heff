// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CUndelay 45232
#define TAG_Describe 2650
#define TAG_F32 16337
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkChk 56962
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_ctx 308385
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_witness__instantiated__state[] = {LBL_witness, LBL_instantiated, LBL_state};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2ememoed_2esumM(V);
V g_heff_2eelab_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2esumM_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2eshownForcedRb(V);
V g_heff_2eelab_2ereadback_2eshownForcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownForcedRb_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V, V);
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eapartForced(V, V, V);
V g_heff_2eelab_2erules_2eapartForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartForced_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2eboundGo_24dps(V, V, V, V);
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
HeffT1 g_heff_2eelab_2erules_2efind_24cpr(V, V);
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntro_24cpr(V, V, V);
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstantiate(V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24cpr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2esearchedNow(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esearchedNow_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etupleSyn(V, V, V, V);
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleSyn_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get(void);
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2eelab_2erules_2eanyIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyIdxGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_i_240);
      heff_drop(v_f_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_f_241;
      V t_2 = v_xs_244;
      v_i_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eanyIdxGo(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etyStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_lam0, 1, 0};
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_entry, 4, 0};

V g_heff_2eelab_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_scope_246 = heff_take_field(v_e_240, 0);
  V v_globals_247 = heff_get_n(v_e_240, 1, 6);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etyStrZ_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2410}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam1, 1, 4, (V[]){v_t_241, v_scope_246, v_globals_247, v_k_243})});
}
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args) {
  V v_x_2436 = args[0];
  V v_globals_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2437 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2436)));
  V v_t_2438 = ({ V b_0 = heff_get_n(v_globals_247, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = v_x_2436; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_2436); r_; });
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    if ((v_tag_2440 == ((int64_t)0ULL))) {
      heff_drop(v_d_2437);
      V v_x_2442 = v_field_2441;
      return v_x_2442;
    } else {
      heff_drop(v_field_2441);
      return v_d_2437;
    }
  }
}
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_scope_246 = heff_env(self)[1];
  V v_globals_247 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2424 = heff_dup(heff_field(v_t_241, 5));
    v_t_2432 = v_folded_2424;
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_2433 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_take_field(v_scope_246, 0), v_t_241, v_t_2432));
  V v_t_2434 = ({ V a_0 = v_x_2412; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2412); r_; });
  V v_t_2435 = heff_tr(heff_call(heff_get_n(v_t_2434, 1, 2), 1, (V[]){v_t_2433}));
  V v_t_2443 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam2, 1, 1, (V[]){v_globals_247})));
  V v_t_2444 = heff_tr(heff_call(heff_get_n(v_t_2443, 1, 2), 1, (V[]){v_t_2435}));
  V v_x_2445 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_scope_246, 1, 4); V a_3 = v_t_2444; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2444); r_; });
  V f_ = v_k_243;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2egoalShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egoalShown_entry, 3, 0};

V g_heff_2eelab_2erules_2egoalShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_get_n(v_e_240, 1, 6);
  V v_t_245 = (g_heff_2eelab_2ereadback_2eshownForcedRb(v_mc_241));
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_t_245, 1, 2), 2, (V[]){heff_take_field(v_scope_243, 0), v_goal_242}));
  V v_t_2414 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2egoalShown_lam0, 1, 1, (V[]){v_globals_244})));
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 1, 2), 1, (V[]){v_t_246}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_scope_243, 1, 4); V a_3 = v_t_2415; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
}
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2egoalShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_globals_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = ({ V b_0 = heff_get_n(v_globals_244, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_247; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_247); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_d_248);
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      heff_drop(v_field_2412);
      return v_d_248;
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einstGlobal_str0, 12, "declared by ");
HEFF_LIT(g_heff_2eelab_2erules_2einstGlobal_str1, 12, "declared by ");
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstGlobal_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einstGlobal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstGlobal_entry, 2, 0};

V g_heff_2eelab_2erules_2einstGlobal(V v_e_240, V v_i_241) {
top: ;
  V v_key_242 = heff_take_field(v_i_241, 0);
  V v_module_243 = heff_get_n(v_i_241, 1, 2);
  V v_g_244 = heff_dup(heff_rfield(v_e_240, 1));
  V v_entries_245 = heff_take_field(v_g_244, 1);
  V v_aliases_246 = heff_get_n(v_g_244, 2, 8);
  V v_k_247 = heff_dup(v_key_242);
  HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_245, v_k_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_entries_245);
      heff_drop(v_aliases_246);
      heff_drop(v_k_247);
      V v_e_2411 = v_field_2410;
      V v_type_5f_2412 = heff_take_field(v_e_2411, 3);
      V v_value_2413 = heff_get_n(v_e_2411, 2, 4);
      V v_t_2423 = heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstGlobal_lam0, 1, 2, (V[]){heff_dup(v_key_242), v_e_240}), heff_strAppend(((V)&g_heff_2eelab_2erules_2einstGlobal_str0), v_module_243), NTAG(TAG_True), v_type_5f_2412, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_242}), v_value_2413});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
    } else {
      heff_drop(v_field_2410);
      HeffT2 v_t_2424 = ({ V a_0 = v_aliases_246; V a_1 = v_k_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_246); heff_drop(v_k_247); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_k2_2427 = v_field_2426;
          HeffT2 v_t_2428 = ({ V a_0 = v_entries_245; V a_1 = v_k2_2427; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_245); heff_drop(v_k2_2427); r_; });
          {
            V v_field_2430 = v_t_2428.f[1];
            int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
            if ((v_tag_2429 == ((int64_t)0ULL))) {
              V v_ge_2431 = v_field_2430;
              V v_type_5f_2432 = heff_take_field(v_ge_2431, 3);
              V v_value_2433 = heff_get_n(v_ge_2431, 2, 4);
              V v_t_2443 = heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstGlobal_lam1, 1, 2, (V[]){heff_dup(v_key_242), v_e_240}), heff_strAppend(((V)&g_heff_2eelab_2erules_2einstGlobal_str1), v_module_243), NTAG(TAG_True), v_type_5f_2432, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_242}), v_value_2433});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2443});
            } else {
              heff_drop_rec(v_e_240, 6);
              heff_drop(v_key_242);
              heff_drop(v_module_243);
              heff_drop(v_field_2430);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop_rec(v_e_240, 6);
          heff_drop(v_key_242);
          heff_drop(v_module_243);
          heff_drop(v_entries_245);
          heff_drop(v_field_2426);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstGlobal(a[0], a[1]);
}
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args) {
  V v_u_2414 = args[0];
  V v_key_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2414);
  V v_x_2415 = v_key_242;
  V v_d_2416 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2415)));
  V v_t_2417 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_2417); r_; });
  HeffT2 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_x_2415; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_2415); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      heff_drop(v_d_2416);
      V v_x_2422 = v_field_2421;
      return v_x_2422;
    } else {
      heff_drop(v_field_2421);
      return v_d_2416;
    }
  }
}
V g_heff_2eelab_2erules_2einstGlobal_lam1(V self, V *args) {
  V v_u_2434 = args[0];
  V v_key_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2434);
  V v_x_2435 = v_key_242;
  V v_d_2436 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2435)));
  V v_t_2437 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_2437); r_; });
  HeffT2 v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = v_x_2435; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_2435); r_; });
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    if ((v_tag_2440 == ((int64_t)0ULL))) {
      heff_drop(v_d_2436);
      V v_x_2442 = v_field_2441;
      return v_x_2442;
    } else {
      heff_drop(v_field_2441);
      return v_d_2436;
    }
  }
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam0, 1, 0};
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam2, 1, 0};
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam5, 1, 0};
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam9, 1, 0};
V g_heff_2eelab_2erules_2efits_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_entry, 6, 0};

V g_heff_2eelab_2erules_2efits(V v_e_240, V v_sp_241, V v_goal_242, V v_w_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2efits_lam1, 1, 6, (V[]){v_w_243, v_goal_242, v_k_245, v_hd_244, v_e_240, v_sp_241})});
}
V g_heff_2eelab_2erules_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  return heff_get_n(v_c_246, 3, 8);
}
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  return v_c_2416;
}
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  return heff_get_n(v_c_2423, 3, 8);
}
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args) {
  V v_p_2433 = args[0];
  V v_p_2434 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_len_2429 = heff_env(self)[1];
  V v_names_2430 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_b_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){heff_get_n(v_e_240, 1, 6), heff_rec_n(2, shape_len__names, (V[]){v_len_2429, v_names_2430}), v_goal_242, v_b_2432}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2435, v_p_2433, v_p_2434));
}
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args) {
  V v_c_2441 = args[0];
  return v_c_2441;
}
V g_heff_2eelab_2erules_2efits_lam11(V self, V *args) {
  V v_x_2449 = args[0];
  V v_r_2436 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_x_2445 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2449);
  V v_t_2452;
  switch (heff_tag_of(v_r_2436)) {
  case TAG_Left: {
    heff_take_n(v_r_2436, 0ULL, 1);
    heff_drop_rec(v_w_243, 6);
    heff_drop_rec(v_x_2422, 3);
    heff_drop(v_x_2445);
    v_t_2452 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_ru_24r_2436_24Right = heff_take_reuse_n(v_r_2436, 0ULL, 1);
    v_t_2452 = heff_tag_at_n(v_ru_24r_2436_24Right, TAG_Just, 1, (V[]){heff_rec_n(3, shape_witness__instantiated__state, (V[]){v_w_243, v_x_2422, v_x_2445})});
    break;
  }
  default: heff_nomatch(v_r_2436);
  }
  V f_ = v_k_2438;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efits_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_malg_2440 = heff_env(self)[1];
  V v_bind_2439 = heff_env(self)[2];
  V v_r_2436 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_k_2438 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2446 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(v_malg_2440, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})}));
  V f_ = v_bind_2439;
  heff_room[0] = v_t_2448;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam11, 1, 5, (V[]){v_r_2436, v_w_243, v_x_2422, v_x_2445, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args) {
  V v_r_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k_2438 = args[2];
  V v_x_2420 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2439 = heff_take_field(v_hd_2437, 1);
  V v_malg_2440 = heff_get_n(v_hd_2437, 2, 3);
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam9_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(heff_dup(v_malg_2440), 1, (V[]){v_t_2443}));
  V f_ = heff_dup(v_bind_2439);
  args[0] = v_t_2444;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam10, 1, 7, (V[]){v_x_2420, v_malg_2440, v_bind_2439, v_r_2436, v_w_243, v_x_2422, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2428 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2429 = heff_take_field(v_c_2428, 0);
  V v_names_2430 = heff_get_n(v_c_2428, 1, 4);
  V v_t_2431 = ({ V a_0 = v_x_2427; V a_1 = heff_dup(heff_rfield(v_x_2422, 1)); V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_x_2427); r_; });
  V v_b_2432 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2431));
  return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2efits_lam7, 2, 5, (V[]){v_e_240, v_len_2429, v_names_2430, v_goal_242, v_b_2432}), heff_clo_n(g_heff_2eelab_2erules_2efits_lam8, 3, 3, (V[]){v_x_2420, v_w_243, v_x_2422}), v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2425}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam6, 1, 7, (V[]){v_e_240, v_x_2422, v_goal_242, v_x_2420, v_w_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_243 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2421 = (g_heff_2eelab_2erules_2einstantiate(heff_dup(v_e_240), v_sp_241, heff_dup(v_w_243)));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam4, 1, 6, (V[]){v_hd_244, v_e_240, v_goal_242, v_x_2420, v_w_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_243 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = heff_dup(heff_rfield(v_w_243, 2));
  V v_t_2415;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    V v_t_2412 = (g_heff_2eelab_2erules_2econclusionOf(MK_INT(0LL), heff_dup(heff_rfield(v_w_243, 3))));
    V v_conclusion_2413 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2412));
    V v_t_2414 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2410, heff_dup(v_goal_242)));
    v_t_2415 = ({ V a_0 = v_x_2410; V a_1 = v_t_2414; V a_2 = v_conclusion_2413; V r_ = (g_heff_2eelab_2erules_2eapartForced(a_0, a_1, a_2)); heff_drop(v_x_2410); heff_drop(v_t_2414); heff_drop(v_conclusion_2413); r_; });
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_t_2411);
    v_t_2415 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop_rec(v_w_243, 6);
    heff_drop(v_goal_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_t_2415);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2415);
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam2_clo)})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2418}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2419;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam3, 1, 6, (V[]){v_e_240, v_sp_241, v_w_243, v_hd_244, v_goal_242, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str1, 21, "  [ready at the call]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str2, 23, "  [waits for implicits]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str3, 7, "wanted ");
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam1, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam5, 2, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam7, 2, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam9(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam8(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam11(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam10(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_246; V a_1 = v_t_247; V a_2 = heff_dup(v_goal_242); V a_3 = v_name_243; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_244); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam0, 1, 5, (V[]){v_hd_244, v_e_240, v_goal_242, v_sp_241, v_k_245}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
}
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertInstance(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_ready_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2420);
  V v_t_2421 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_242; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2422;
  if ((heff_dup(v_ready_2419) == NTAG(TAG_True))) {
    heff_drop(v_ready_2419);
    v_t_2422 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str1);
  } else {
    heff_drop(v_ready_2419);
    v_t_2422 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str2);
  }
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2einsertInstance_str3), heff_strAppend(v_t_2421, v_t_2422));
}
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam9(V self, V *args) {
  V v_b_2434 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_take_field(v_x_248, 0);
  V v_t_2471;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2435, 0ULL, 3);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2460 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 3);
    v_t_2471 = v_k_2460;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2471, heff_get_n(v_x_248, 1, 2), v_goal_242, v_b_2434, heff_dup(v_hd_2432), heff_get_n(v_hd_2432, 0, 3)));
}
V g_heff_2eelab_2erules_2einsertInstance_lam8(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2472 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam9, 1, 5, (V[]){v_x_248, v_e_240, v_sp_241, v_goal_242, heff_dup(v_hd_2432)}), NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2473}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2474;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam11(V self, V *args) {
  V v_u_2477 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2477);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_248, 1, 2)});
}
V g_heff_2eelab_2erules_2einsertInstance_lam10(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2476);
  V v_t_2478 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam11, 1, 1, (V[]){heff_dup(v_x_248)}); V rr_ = heff_rec_reuse_nf(v_x_248, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2475;
  if ((heff_dup(v_x_2429) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    heff_drop(v_sp_241);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_goal_242);
    v_t_2475 = ((V)&g_heff_2eelab_2erules_2einsertInstance_lam7_clo);
  } else {
    heff_drop(v_x_2429);
    v_t_2475 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam8, 2, 4, (V[]){v_sp_241, heff_dup(v_x_248), v_e_240, v_goal_242});
  }
  V f_ = v_t_2475;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam10, 1, 2, (V[]){v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ready_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2425);
  V v_t_2428;
  if ((heff_dup(v_ready_2419) == NTAG(TAG_True))) {
    heff_drop(v_ready_2419);
    v_t_2428 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2esearchedNow_clo), 4, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_x_248), heff_dup(v_goal_242)}));
  } else {
    heff_drop(v_ready_2419);
    v_t_2428 = ((V)&g_heff_2eelab_2erules_2einsertInstance_lam5_clo);
  }
  V f_ = v_t_2428;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam6, 1, 6, (V[]){v_sp_241, v_x_248, v_e_240, v_goal_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = (g_heff_2eelab_2eunify_2emetasK(v_x_2413));
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_x1_2416 = heff_tr(heff_call(heff_get_n(v_t_2414, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2415, heff_dup(v_goal_242)}));
  V v_ready_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nil: {
    v_ready_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_ready_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2423 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2einsertInstance_str0), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam3, 1, 4, (V[]){heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242), heff_dup(v_ready_2419)})}), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam4, 1, 7, (V[]){v_ready_2419, v_e_240, v_sp_241, v_x_248, v_goal_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam2, 1, 6, (V[]){v_e_240, v_goal_242, v_sp_241, v_hd_244, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2erules_2efunctionIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntro_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntro(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2efunctionIntro_24cpr(v_sp_240, v_x_241, v_body_242));
  {
    V v_field_244 = v_t_243.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_244});
  }
}
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntro(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFields_entry, 5, 0};

V g_heff_2eelab_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_z_243);
    V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tail(v_z_244, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x31_246, 0);
      V v_g_249 = heff_field(v_x31_246, 1);
      V v_c_2410 = heff_dup(heff_rfield(v_e_240, 0));
      V v_len_2411 = heff_take_field(v_c_2410, 0);
      V v_names_2412 = heff_get_n(v_c_2410, 1, 4);
      V v_a_2442;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VNeu: {
        V v_t_2418 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_241)));
        V v_x1_2419 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2418, v_y_248));
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_Nom: {
          V v_x_2420 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          v_a_2442 = v_x_2420;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          v_a_2442 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2422 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          v_a_2442 = v_x_2422;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        break;
      }
      case TAG_VCode: {
        V v_t_2424 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_241)));
        V v_x1_2425 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2424, v_y_248));
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_Nom: {
          V v_x_2426 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          v_a_2442 = v_x_2426;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2425, 0ULL, 1);
          v_a_2442 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2428 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          v_a_2442 = v_x_2428;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        break;
      }
      case TAG_VLam: {
        V v_t_2431 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_241)));
        V v_x1_2432 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2431, v_y_248));
        switch (heff_tag_of(v_x1_2432)) {
        case TAG_Nom: {
          V v_x_2433 = heff_field(v_x1_2432, 0);
          heff_take_n(v_x1_2432, 1ULL, 1);
          v_a_2442 = v_x_2433;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2432, 0ULL, 1);
          v_a_2442 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2435 = heff_field(v_x1_2432, 0);
          heff_take_n(v_x1_2432, 1ULL, 1);
          v_a_2442 = v_x_2435;
          break;
        }
        default: heff_nomatch(v_x1_2432);
        }
        break;
      }
      case TAG_VCons: {
        V v_t_2437 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_241)));
        V v_x1_2438 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2437, v_y_248));
        switch (heff_tag_of(v_x1_2438)) {
        case TAG_Nom: {
          V v_x_2439 = heff_field(v_x1_2438, 0);
          heff_take_n(v_x1_2438, 1ULL, 1);
          v_a_2442 = v_x_2439;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2438, 0ULL, 1);
          v_a_2442 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2441 = heff_field(v_x1_2438, 0);
          heff_take_n(v_x1_2438, 1ULL, 1);
          v_a_2442 = v_x_2441;
          break;
        }
        default: heff_nomatch(v_x1_2438);
        }
        break;
      }
      case TAG_VOpaque: {
        v_a_2442 = NTAG(TAG_VOpaque);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      V v_t_2443 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), heff_dup(heff_rfield(v_e_240, 1)), heff_rec_n(2, shape_len__names, (V[]){v_len_2411, v_names_2412}), v_a_2442, heff_dup(v_g_249)));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2443, heff_dup(v_z_243), heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam0, 1, 5, (V[]){v_z_244, v_e_240, v_v_241, heff_dup(v_rest_247), v_z_243})));
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2echeckFields(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_err_2445 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_rest_247);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2445});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2444, 0ULL, 1);
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_rest_247; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_247); r_; });
  }
  default: return heff_nomatch(v_x_2444);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str9, 4, " to ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str10, 19, ", whose values are ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str11, 21, " is out of range for ");
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eintAtFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_entry, 5, 0};

V g_heff_2eelab_2erules_2eintAtFixed(V v_sp_240, V v_w_241, V v_i_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_w_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_intShow(heff_dup(v_i_242)), heff_box_f64(heff_from_int_f64(v_i_242))));
    return heff_tail(v_t_246, 2, (V[]){v_z_243, v_z_244});
  } else {
    heff_drop(v_t_245);
    V v_t_247 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
    if ((heff_intLe_c_lent(v_t_247, v_i_242, 0) && ({ V v_t_2421 = (g_heff_2eelab_2efixed_2efixedMax(v_w_241)); int c_ = heff_intLe_c_lent(v_i_242, v_t_2421, 0); heff_drop(v_t_2421); c_; }))) {
      heff_drop(v_sp_240);
      heff_drop_rec(v_z_243, 3);
      heff_drop(v_t_247);
      V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_241, v_i_242}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_lam0_clo)});
      return heff_tail(v_z_244, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_247);
      V v_t_2410;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str0);
        break;
      }
      case TAG_I16: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str1);
        break;
      }
      case TAG_I32: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str2);
        break;
      }
      case TAG_I64: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str3);
        break;
      }
      case TAG_U8: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str4);
        break;
      }
      case TAG_U16: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str5);
        break;
      }
      case TAG_U32: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str6);
        break;
      }
      case TAG_U64: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str7);
        break;
      }
      case TAG_F32: {
        v_t_2410 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str8);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_t_2411 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
      V v_t_2412 = ({ V a_0 = v_w_241; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_241); r_; });
      V v_t_2413 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str9), heff_intShow(v_t_2412));
      V v_t_2414 = heff_strAppend(heff_intShow(v_t_2411), v_t_2413);
      V v_why_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str10), v_t_2414));
      V v_t_2416 = heff_strAppend(heff_intShow(v_i_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str11), v_why_2415));
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2416, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_2419}));
      return heff_tail(heff_get_n(v_z_243, 1, 3), 2, (V[]){v_t_2420, v_z_244});
    }
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
Clo g_heff_2eelab_2erules_2enumLitChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitChk_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitChk(V v_sp_240, V v_lit_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2enumLitChk_24cpr(v_sp_240, v_lit_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitChk(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str0, 16, ", but got value ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str1, 15, "expected value ");
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_lam0, 2, 0};
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args);
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_entry, 4, 0};

V g_heff_2eelab_2erules_2echeckFixed(V v_e_240, V v_sp_241, V v_v_242, V v_x4_243) {
top: ;
  V v_scope_244 = heff_take_field(v_e_240, 0);
  V v_globals_245 = heff_get_n(v_e_240, 1, 6);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_scope_244);
    heff_drop(v_globals_245);
    return ((V)&g_heff_2eelab_2erules_2echeckFixed_lam0_clo);
  }
  case TAG_Just: {
    V v_expected_248 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_c_249 = heff_dup(v_scope_244);
    V v_len_2410 = heff_take_field(v_c_249, 0);
    V v_names_2411 = heff_get_n(v_c_249, 1, 4);
    V v_t_2412 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), heff_dup(v_globals_245), heff_rec_n(2, shape_len__names, (V[]){v_len_2410, v_names_2411}), heff_dup(v_v_242), heff_dup(v_expected_248)));
    return heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam1, 2, 6, (V[]){v_t_2412, v_scope_244, v_globals_245, v_expected_248, v_v_242, v_sp_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckFixed(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_scope_244 = heff_env(self)[0];
  V v_globals_245 = heff_env(self)[1];
  V v_expected_248 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_c_2417 = heff_dup(v_scope_244);
    V v_len_2418 = heff_take_field(v_c_2417, 0);
    V v_names_2419 = heff_get_n(v_c_2417, 1, 4);
    V v_t_2420 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_globals_245), heff_rec_n(2, shape_len__names, (V[]){v_len_2418, v_names_2419}), v_expected_248));
    V v_c_2421 = v_scope_244;
    V v_len_2422 = heff_take_field(v_c_2421, 0);
    V v_names_2423 = heff_get_n(v_c_2421, 1, 4);
    V v_t_2424 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_globals_245), heff_rec_n(2, shape_len__names, (V[]){v_len_2422, v_names_2423}), v_v_242));
    V v_t_2425 = heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str0), v_t_2424));
    V v_msg_2426 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str1), v_t_2425);
    V v_note_2427 = ({ V a_0 = v_globals_245; V a_1 = v_err_2416; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2416); r_; });
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2426, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2427})});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2415_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2430}));
    V f_ = heff_get_n(v_hd_2413, 1, 3);
    heff_room[0] = v_t_2431;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_drop(v_scope_244);
    heff_drop(v_globals_245);
    heff_drop(v_expected_248);
    heff_drop(v_v_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_2413, 3);
    V f_ = v_k_2414;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_scope_244 = heff_env(self)[1];
  V v_globals_245 = heff_env(self)[2];
  V v_expected_248 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam2, 1, 7, (V[]){v_scope_244, v_globals_245, v_expected_248, v_v_242, v_sp_241, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_24acc_entry, 2, 0};

V g_heff_2eelab_2erules_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2erules_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_24acc_str1), heff_dup(v_y_246)));
          return heff_strAppend(v_acc_241, v_t_248);
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2412 = heff_strAppend(v_s_2411, ((V)&g_heff_2eelab_2erules_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2412;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str0, 21, "missing record field ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str1, 6, " got: ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str2, 22, "expected record field ");
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enotGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotGiven_entry, 3, 0};

V g_heff_2eelab_2erules_2enotGiven(V v_it_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_note_243 = (g_heff_2eelab_2erules_2efieldsNote(heff_dup(v_it_240)));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam0, 2, 3, (V[]){v_x_241, v_it_240, v_note_243});
  }
  case TAG_Cons: {
    V v_fs_2412 = heff_field(v_x3_242, 0);
    V v_name_2414 = heff_dup(heff_rfield(v_fs_2412, 0));
    V v_span_2415 = heff_dup(heff_rfield(v_fs_2412, 2));
    V v_note_2416 = (g_heff_2eelab_2erules_2efieldsNote(v_it_240));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam1, 2, 4, (V[]){v_x_241, v_name_2414, v_span_2415, v_note_2416});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enotGiven(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_it_240 = heff_env(self)[1];
  V v_note_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_246 = heff_take_field(v_hd_244, 1);
  V v_malg_247 = heff_get_n(v_hd_244, 2, 3);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str0), v_x_241), heff_get_n(v_it_240, 0, 5), heff_tag_n(TAG_Just, 1, (V[]){v_note_243})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_247, 1, (V[]){v_t_2410}));
  V f_ = v_bind_246;
  args[0] = v_t_2411;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_name_2414 = heff_env(self)[1];
  V v_span_2415 = heff_env(self)[2];
  V v_note_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bind_2419 = heff_take_field(v_hd_2417, 1);
  V v_malg_2420 = heff_get_n(v_hd_2417, 2, 3);
  V v_t_2421 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str1), v_name_2414));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str2), v_t_2421), v_span_2415, heff_tag_n(TAG_Just, 1, (V[]){v_note_2416})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2424}));
  V f_ = v_bind_2419;
  args[0] = v_t_2425;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eboundGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eboundGo(V v_all_240, V v_x2_241, V v_box_24j_242) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_245 = (g_list_2edrop(heff_box_word((v_j_242 + ((int64_t)1ULL))), v_all_240));
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_box_word((v_j_242 + ((int64_t)1ULL))); V a_2 = heff_box_word(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2erules_2eboundGo_24dps(v_all_240, v_rest_244, heff_box_word((v_j_242 + ((int64_t)1ULL))), heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eboundGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2esumFormation(V v_vs_240) {
top: ;
  V v_keys_241 = heff_take_field(v_vs_240, 0);
  V v_values_242 = heff_get_n(v_vs_240, 2, 3);
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam0, 1, 2, (V[]){v_keys_241, v_values_242})});
}
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation(a[0]);
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  V v_scope_244 = heff_env(self)[0];
  V v_globals_245 = heff_env(self)[1];
  V v_lams_246 = heff_env(self)[2];
  V v_self_247 = heff_env(self)[3];
  V v_insts_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sd_2414 = v_scope_244;
  V v_len_2415 = heff_take_field(v_sd_2414, 0);
  V v_names_2416 = heff_take_field(v_sd_2414, 1);
  V v_locals_2417 = heff_take_field(v_sd_2414, 2);
  V v_ctx_2418 = heff_get_n(v_sd_2414, 3, 4);
  switch (heff_tag_of(v_t_2413)) {
  case TAG_MkSmallTyp: {
    V v_f_2419 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2420 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){v_len_2415, v_names_2416, v_locals_2417, heff_tag_n(TAG_CUndelay, 1, (V[]){v_ctx_2418})});
    V v_t_2421 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_t_2420, v_globals_245, NTAG(TAG_ForNominative), v_lams_246, v_self_247, v_insts_248});
    V f_ = v_f_2419;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2411, heff_arrayFromList(v_x_2425)});
  V f_ = v_k_2424;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam4, 1, 2, (V[]){v_k_2411, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_scope_244 = heff_env(self)[0];
  V v_globals_245 = heff_env(self)[1];
  V v_lams_246 = heff_env(self)[2];
  V v_self_247 = heff_env(self)[3];
  V v_insts_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2410)) {
  case TAG_MkPair: {
    V v_k_2411 = heff_field(v_p_2410, 0);
    V v_ts_2412 = heff_field(v_p_2410, 1);
    heff_take_n(v_p_2410, 3ULL, 2);
    V v_c_2422 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam2, 1, 5, (V[]){v_scope_244, v_globals_245, v_lams_246, v_self_247, v_insts_248}), heff_arrayToList(v_ts_2412)));
    return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam3, 2, 2, (V[]){v_c_2422, v_k_2411});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2430)));
  V v_t_2432 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2430));
  V v_t_2433 = (g_list_2emap_24s1173914895x100384474(v_x_2430));
  V v_t_2434 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2431), v_t_2432, heff_arrayFromList(v_t_2433)});
  V v_x_2435 = (g_heff_2eelab_2ememoed_2esumM(v_t_2434));
  V f_ = v_k_2429;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam6, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_keys_241 = heff_env(self)[0];
  V v_values_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_scope_244 = heff_take_field(v_e_243, 0);
  V v_globals_245 = heff_take_field(v_e_243, 1);
  V v_lams_246 = heff_take_field(v_e_243, 3);
  V v_self_247 = heff_take_field(v_e_243, 4);
  V v_insts_248 = heff_get_n(v_e_243, 5, 6);
  V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_241), heff_arrayToList(v_values_242)));
  V v_c_2427 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam1, 1, 5, (V[]){v_scope_244, v_globals_245, v_lams_246, v_self_247, v_insts_248}), v_t_249));
  return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam5, 2, 1, (V[]){v_c_2427});
}
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str0, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str1, 13, " is set twice");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str2, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str3, 13, " is set twice");
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args);
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2egivenTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egivenTwice_entry, 2, 0};

V g_heff_2eelab_2erules_2egivenTwice(V v_fs_240, V v_x_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s924780574x2000457388(v_x_241, v_fs_240));
  HeffT3 v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_f_247 = v_field_245;
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam0, 2, 2, (V[]){v_x_241, v_f_247});
    } else {
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam1, 2, 1, (V[]){v_x_241});
    }
  }
}
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2egivenTwice(a[0], a[1]);
}
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str0), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2egivenTwice_str1)));
  V v_t_2422;
  switch (heff_tag_of(v_f_247)) {
  case TAG_UpdateTo: {
    V v_sp_2416 = heff_field(v_f_247, 2);
    heff_take_n(v_f_247, 4ULL, 4);
    v_t_2422 = v_sp_2416;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2420 = heff_field(v_f_247, 2);
    heff_take_n(v_f_247, 4ULL, 4);
    v_t_2422 = v_sp_2420;
    break;
  }
  default: heff_nomatch(v_f_247);
  }
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2413, v_t_2422, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2425}));
  V f_ = v_bind_2411;
  args[0] = v_t_2426;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2429 = heff_take_field(v_hd_2427, 1);
  V v_malg_2430 = heff_get_n(v_hd_2427, 2, 3);
  V v_t_2431 = heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str2), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2egivenTwice_str3)));
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2431, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(v_malg_2430, 1, (V[]){v_t_2434}));
  V f_ = v_bind_2429;
  args[0] = v_t_2435;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str0, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str1, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str3, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str4, 15, "the fields are ");
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_lam0, 2, 0};
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enoSuchSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_entry, 4, 0};

V g_heff_2eelab_2erules_2enoSuchSetting(V v_e_240, V v_a_241, V v_keys_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    return ((V)&g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_t_2416;
    switch (heff_tag_of(v_f_246)) {
    case TAG_UpdateTo: {
      V v_x_248 = heff_field(v_f_246, 0);
      v_t_2416 = heff_dup(v_x_248);
      break;
    }
    case TAG_UpdateIn: {
      V v_x_2412 = heff_field(v_f_246, 0);
      v_t_2416 = heff_dup(v_x_2412);
      break;
    }
    default: heff_nomatch(v_f_246);
    }
    V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_2416}));
    V v_t_2418 = (g_list_2eany(v_t_2417, v_keys_242));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      V t_0 = v_e_240;
      V t_1 = v_a_241;
      V t_2 = v_keys_242;
      V t_3 = v_rest_247;
      v_e_240 = t_0;
      v_a_241 = t_1;
      v_keys_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2418);
      V v_t_2427;
      switch (heff_tag_of(v_f_246)) {
      case TAG_UpdateTo: {
        V v_x_2419 = heff_field(v_f_246, 0);
        v_t_2427 = heff_dup(v_x_2419);
        break;
      }
      case TAG_UpdateIn: {
        V v_x_2423 = heff_field(v_f_246, 0);
        v_t_2427 = heff_dup(v_x_2423);
        break;
      }
      default: heff_nomatch(v_f_246);
      }
      V v_t_2428 = (g_heff_2eelab_2erules_2etyStr(v_e_240, v_a_241));
      V v_t_2429 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str0), v_t_2428));
      V v_msg_2430 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str1), v_t_2429);
      V v_t_2433;
      switch (heff_tag_of(v_keys_242)) {
      case TAG_Nil: {
        v_t_2433 = ((V)&g_heff_2eelab_2erules_2enoSuchSetting_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2431 = heff_field(v_keys_242, 0);
        V v_xs_2432 = heff_field(v_keys_242, 1);
        v_t_2433 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str3), heff_dup(v_x_2431), v_xs_2432));
        break;
      }
      default: heff_nomatch(v_keys_242);
      }
      V v_note_2434 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str4), v_t_2433);
      return heff_clo_n(g_heff_2eelab_2erules_2enoSuchSetting_lam1, 2, 3, (V[]){heff_dup(v_f_246), v_msg_2430, v_note_2434});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2enoSuchSetting(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k2_2436 = args[1];
  V v_f_246 = heff_env(self)[0];
  V v_msg_2430 = heff_env(self)[1];
  V v_note_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2437 = heff_take_field(v_hd_2435, 1);
  V v_malg_2438 = heff_get_n(v_hd_2435, 2, 3);
  V v_t_2447;
  switch (heff_tag_of(v_f_246)) {
  case TAG_UpdateTo: {
    V v_sp_2441 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2447 = v_sp_2441;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2445 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2447 = v_sp_2445;
    break;
  }
  default: heff_nomatch(v_f_246);
  }
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2430, v_t_2447, heff_tag_n(TAG_Just, 1, (V[]){v_note_2434})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(v_malg_2438, 1, (V[]){v_t_2450}));
  V f_ = v_bind_2437;
  args[0] = v_t_2451;
  args[1] = v_k2_2436;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str0, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str1, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str2, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str3, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str4, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str5, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str6, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str7, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str8, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str9, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str10, 6, "MkPair");
V g_heff_2eelab_2erules_2etupleSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam7(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam8(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam9(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam10(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam11(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam12(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam13(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam14(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam15(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etupleSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etupleSyn_entry, 4, 0};

V g_heff_2eelab_2erules_2etupleSyn(V v_sp_240, V v_s_241, V v_rest_242, V v_p_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_rest_242, heff_dup(v_p_243)})});
}
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2etupleSyn(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2etupleSyn_lam3(V self, V *args) {
  V v_c_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 2ULL, 2);
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 8); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2etupleSyn_lam5(V self, V *args) {
  V v_e2_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2421);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam6(V self, V *args) {
  V v_e2_2433 = args[0];
  V v_hd_2434 = args[1];
  V v_k_2435 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2433);
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam7(V self, V *args) {
  V v_e2_2445 = args[0];
  V v_hd_2446 = args[1];
  V v_k_2447 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2445);
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam8(V self, V *args) {
  V v_e2_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2455);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam9(V self, V *args) {
  V v_e2_2464 = args[0];
  V v_hd_2465 = args[1];
  V v_k_2466 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2464);
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam10(V self, V *args) {
  V v_e2_2473 = args[0];
  V v_hd_2474 = args[1];
  V v_k_2475 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2473);
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam11(V self, V *args) {
  V v_e2_2482 = args[0];
  V v_hd_2483 = args[1];
  V v_k_2484 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2482);
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam12(V self, V *args) {
  V v_e2_2491 = args[0];
  V v_hd_2492 = args[1];
  V v_k_2493 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2491);
  heff_drop(v_hd_2492);
  V f_ = v_k_2493;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam13(V self, V *args) {
  V v_e2_24101 = args[0];
  V v_hd_24102 = args[1];
  V v_k_24103 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_24101);
  heff_drop(v_hd_24102);
  V f_ = v_k_24103;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam14(V self, V *args) {
  V v_e2_24111 = args[0];
  V v_hd_24112 = args[1];
  V v_k_24113 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_24111);
  heff_drop(v_hd_24112);
  V f_ = v_k_24113;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam15(V self, V *args) {
  V v_e2_24120 = args[0];
  V v_hd_24121 = args[1];
  V v_k_24122 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_24120);
  heff_drop(v_hd_24121);
  V f_ = v_k_24122;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2417));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_LikeU: {
    V v_ru_24t_2418_24LikeU = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_drop(v_p_243);
    V v_t_2420 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2etupleSyn_str0)));
    V v_t_2424 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2418_24LikeU, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam5, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2425 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_240); V a_2 = v_t_2420; V a_3 = v_t_2424; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2420); heff_drop(v_t_2424); r_; });
    HeffT1 v_t_2426 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_240; V a_2 = v_t_2425; V a_3 = v_rest_242; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2425); heff_drop(v_rest_242); r_; });
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_f_2428 = v_field_2427;
      V f_ = v_f_2428;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2418, 0ULL, 4);
    V v_t_2436 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam6, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2438 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str1); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2437}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2439 = ({ V a_0 = v_p_243; V a_1 = v_t_2438; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2438); r_; });
    {
      V v_field_2440 = v_t_2439.f[0];
      V v_f_2441 = v_field_2440;
      V f_ = v_f_2441;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2418, 0ULL, 3);
    V v_t_2448 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam7, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2450 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str2); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2449}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2451 = ({ V a_0 = v_p_243; V a_1 = v_t_2450; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2450); r_; });
    {
      V v_field_2452 = v_t_2451.f[0];
      V v_f_2453 = v_field_2452;
      V f_ = v_f_2453;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeSum: {
    V v_ru_24t_2418_24LikeSum = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    V v_t_2458 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2418_24LikeSum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam8, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2460 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str3); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2459}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2461 = ({ V a_0 = v_p_243; V a_1 = v_t_2460; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2460); r_; });
    {
      V v_field_2462 = v_t_2461.f[0];
      V v_f_2463 = v_field_2462;
      V f_ = v_f_2463;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeInt: {
    V v_t_2467 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam9, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2469 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str4); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, v_t_2468}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2470 = ({ V a_0 = v_p_243; V a_1 = v_t_2469; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2469); r_; });
    {
      V v_field_2471 = v_t_2470.f[0];
      V v_f_2472 = v_field_2471;
      V f_ = v_f_2472;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeFloat: {
    V v_t_2476 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam10, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2478 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str5); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2477}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2479 = ({ V a_0 = v_p_243; V a_1 = v_t_2478; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2478); r_; });
    {
      V v_field_2480 = v_t_2479.f[0];
      V v_f_2481 = v_field_2480;
      V f_ = v_f_2481;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeString: {
    V v_t_2485 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam11, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2487 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str6); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_t_2486}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2488 = ({ V a_0 = v_p_243; V a_1 = v_t_2487; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2487); r_; });
    {
      V v_field_2489 = v_t_2488.f[0];
      V v_f_2490 = v_field_2489;
      V f_ = v_f_2490;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeRune: {
    V v_t_2494 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam12, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2496 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str7); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_t_2495}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2497 = ({ V a_0 = v_p_243; V a_1 = v_t_2496; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2496); r_; });
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_f_2499 = v_field_2498;
      V f_ = v_f_2499;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2418_24LikeArray = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    V v_t_24104 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2418_24LikeArray, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam13, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_24106 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str8); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, v_t_24105}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_24107 = ({ V a_0 = v_p_243; V a_1 = v_t_24106; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_24106); r_; });
    {
      V v_field_24108 = v_t_24107.f[0];
      V v_f_24109 = v_field_24108;
      V f_ = v_f_24109;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2418_24LikeFixed = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    V v_t_24114 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2418_24LikeFixed, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam14, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_24116 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str9); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, v_t_24115}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_24117 = ({ V a_0 = v_p_243; V a_1 = v_t_24116; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_24116); r_; });
    {
      V v_field_24118 = v_t_24117.f[0];
      V v_f_24119 = v_field_24118;
      V f_ = v_f_24119;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_NoRules: {
    V v_t_24123 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam15, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_24125 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str10); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, v_t_24124}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_24126 = ({ V a_0 = v_p_243; V a_1 = v_t_24125; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_24125); r_; });
    {
      V v_field_24127 = v_t_24126.f[0];
      V v_f_24128 = v_field_24127;
      V f_ = v_f_24128;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2erules_2etupleSyn_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam3, 1, 1, (V[]){heff_dup(v_x_249)})})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam4, 1, 7, (V[]){v_sp_240, v_x_249, v_rest_242, v_e_244, v_hd_247, v_k_248, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etupleSyn_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam2, 1, 6, (V[]){v_hd_247, v_sp_240, v_rest_242, v_e_244, v_k_248, v_p_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_rest_242, v_e_244, v_p_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str0, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str1, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str2, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str3, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str4, 4, "int8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str5, 5, "int16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str6, 5, "int32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str7, 5, "int64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str8, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str9, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str10, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str11, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str12, 7, "float32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str13, 2, "Eq");
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitEq_entry, 5, 0};

V g_heff_2eelab_2erules_2elitEq(V v_sp_240, V v_x_241, V v_xsp_242, V v_eq_243, V v_lit_244) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam0, 1, 5, (V[]){v_xsp_242, v_x_241, v_eq_243, v_sp_240, heff_dup(v_lit_244)})});
}
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elitEq(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args) {
  V v_c_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  return ({ V b_0 = heff_get_n(v_c_2413, 3, 8); V a_1 = v_t_2416; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args) {
  V v_e2_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k_2438 = args[2];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2436);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_eq_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_xsp_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_hd_2410 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2420));
  V v_t_2434;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2434 = v_eq_243;
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2421, 0ULL, 4);
    v_t_2434 = v_eq_243;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2421, 0ULL, 3);
    v_t_2434 = v_eq_243;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2434 = v_eq_243;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_eq_243);
    v_t_2434 = ((V)&g_heff_2eelab_2erules_2elitEq_str0);
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_eq_243);
    v_t_2434 = ((V)&g_heff_2eelab_2erules_2elitEq_str1);
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_eq_243);
    v_t_2434 = ((V)&g_heff_2eelab_2erules_2elitEq_str2);
    break;
  }
  case TAG_LikeRune: {
    heff_drop(v_eq_243);
    v_t_2434 = ((V)&g_heff_2eelab_2erules_2elitEq_str3);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2434 = v_eq_243;
    break;
  }
  case TAG_LikeFixed: {
    V v_w_2432 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    heff_drop(v_eq_243);
    V v_t_2433;
    switch (heff_tag_of(v_w_2432)) {
    case TAG_I8: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str4);
      break;
    }
    case TAG_I16: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str5);
      break;
    }
    case TAG_I32: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str6);
      break;
    }
    case TAG_I64: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str7);
      break;
    }
    case TAG_U8: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str8);
      break;
    }
    case TAG_U16: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str9);
      break;
    }
    case TAG_U32: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str10);
      break;
    }
    case TAG_U64: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str11);
      break;
    }
    case TAG_F32: {
      v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str12);
      break;
    }
    default: heff_nomatch(v_w_2432);
    }
    v_t_2434 = heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2erules_2elitEq_str13));
    break;
  }
  case TAG_NoRules: {
    v_t_2434 = v_eq_243;
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_callee_2435 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), v_t_2434));
  V v_t_2439 = ({ V a_0 = v_xsp_242; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam5, 3, 1, (V[]){v_x_2412})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2440 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_240); V a_2 = v_callee_2435; V a_3 = v_t_2439; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_callee_2435); heff_drop(v_t_2439); r_; });
  HeffT1 v_t_2441 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_240; V a_2 = v_t_2440; V a_3 = v_lit_244; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2440); heff_drop(v_lit_244); r_; });
  {
    V v_field_2442 = v_t_2441.f[0];
    V v_f_2443 = v_field_2442;
    V f_ = v_f_2443;
    heff_room[0] = v_e_245;
    heff_room[1] = v_hd_2410;
    heff_room[2] = v_k_2411;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam3, 1, 1, (V[]){heff_dup(v_x_2412)})})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2418}));
  V f_ = heff_dup(heff_rfield(v_hd_2410, 1));
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam4, 1, 8, (V[]){v_eq_243, v_sp_240, v_xsp_242, v_x_2412, v_lit_244, v_e_245, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam2, 1, 7, (V[]){v_hd_2410, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_xsp_242 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT1 v_t_246 = (g_heff_2eelab_2erules_2efind_24cpr(heff_dup(v_xsp_242), v_x_241));
  V v_c_249;
  {
    V v_field_247 = v_t_246.f[0];
    V v_f_248 = v_field_247;
    v_c_249 = heff_tr(heff_call(v_f_248, 1, (V[]){heff_dup(v_e_245)}));
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam1, 2, 6, (V[]){v_c_249, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245});
}