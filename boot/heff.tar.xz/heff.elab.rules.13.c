// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_Become 65038
#define TAG_CUndelay 45232
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_F32 16337
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkChk 56962
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SLitFixed 54374
#define TAG_SLitInt 21439
#define TAG_SMetaApp 2372
#define TAG_SSum 9006
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_ctx 308385
#define LBL_digits 615232529
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_evidence 1128105991
#define LBL_exponent 966452320
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_negative 1666250321
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_witness__instantiated__state[] = {LBL_witness, LBL_instantiated, LBL_state};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
float g_float32_2efromDecimal_w(V, V);
V g_float32_2efromDecimal(V, V);
V g_float32_2efromDecimal_entry(V self, V *a);
extern Clo g_float32_2efromDecimal_clo;
V g_heff_2eelab_2eenvironment_2eruledOutAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2eruledOutAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eruledOutAt_clo;
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
HeffT2 g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V, V);
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163(V, V);
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_clo;
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2eboundGo_24dps(V, V, V, V);
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2echeckSetting_24map0(V, V);
V g_heff_2eelab_2erules_2echeckSetting_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_24map0_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
HeffT3 g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
HeffT1 g_heff_2eelab_2erules_2efindOr_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2efracDefault_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_clo;
V g_heff_2eelab_2erules_2efracDefault_24tok1_w(V, V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_24tok1_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efreshMeta_24rec0_get(void);
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
HeffT2 g_heff_2eelab_2erules_2eheldGiven_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2eheldInScope(V, V, V);
V g_heff_2eelab_2erules_2eheldInScope_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldInScope_clo;
V g_heff_2eelab_2erules_2eheldOrNot(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eheldOrNot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldOrNot_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstantiate(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2eisEvidence(V, V);
V g_heff_2eelab_2erules_2eisEvidence_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eisEvidence_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2elocalNamed(V, V);
V g_heff_2eelab_2erules_2elocalNamed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalNamed_clo;
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2emetaOfStx(V);
V g_heff_2eelab_2erules_2emetaOfStx_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOfStx_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_clo;
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2esearchedNow(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esearchedNow_clo;
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(V, V, V, V, V);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate0_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate1(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate1_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate2(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate2_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate3(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate3_clo;
V g_heff_2eelab_2erules_2esumFormation_24map0(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map0_clo;
V g_heff_2eelab_2erules_2esumFormation_24map1(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map1_clo;
V g_heff_2eelab_2erules_2esumFormation_24map2(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map2_clo;
V g_heff_2eelab_2erules_2esumFormation_24map3(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map3_clo;
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etupleSyn(V, V, V, V);
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleSyn_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2eunboundIn(V, V, V);
V g_heff_2eelab_2erules_2eunboundIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunboundIn_clo;
V g_heff_2eelab_2erules_2eunsolvedWorld(V, V);
V g_heff_2eelab_2erules_2eunsolvedWorld_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunsolvedWorld_clo;
V g_heff_2eelab_2erules_2eunsolvedWorldTm(V, V, V);
V g_heff_2eelab_2erules_2eunsolvedWorldTm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunsolvedWorldTm_clo;
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s1082941870x132941142(V, V);
V g_list_2eany_24s1082941870x132941142_entry(V self, V *a);
extern Clo g_list_2eany_24s1082941870x132941142_clo;
V g_list_2eany_24s2135465121x1956745568(V);
V g_list_2eany_24s2135465121x1956745568_entry(V self, V *a);
extern Clo g_list_2eany_24s2135465121x1956745568_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2erules_2eanyIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyIdxGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_i_240);
      heff_drop(v_f_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_f_241;
      V t_2 = v_xs_244;
      v_i_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eanyIdxGo(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etyStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_lam0, 1, 0};
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_entry, 4, 0};

V g_heff_2eelab_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_malg_244 = heff_take_field(v_hd_242, 2);
  V v_bind_245 = heff_get_n(v_hd_242, 1, 3);
  V v_scope_246 = heff_take_field(v_e_240, 0);
  V v_globals_247 = heff_get_n(v_e_240, 1, 8);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etyStrZ_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2410}));
  return heff_tail(v_bind_245, 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam1, 1, 4, (V[]){v_t_241, v_scope_246, v_globals_247, v_k_243})});
}
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 9);
}
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_globals_247 = heff_env(self)[0];
  V v_d_2439 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2438)));
  heff_clo_take(self, 1);
  V v_t_2440 = ({ V b_0 = heff_get_n(v_globals_247, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_x_2438; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2440); heff_drop(v_x_2438); r_; });
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      heff_drop(v_d_2439);
      V v_x_2444 = v_field_2443;
      return v_x_2444;
    } else {
      heff_drop(v_field_2443);
      return v_d_2439;
    }
  }
}
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_scope_246 = heff_env(self)[1];
  V v_globals_247 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2432;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2424 = heff_dup(heff_field(v_t_241, 5));
    v_t_2432 = v_folded_2424;
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_2433 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_take_field(v_scope_246, 0), v_t_241, v_t_2432));
  HeffT2 v_t_2434 = ({ V a_0 = v_x_2412; HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(a_0)); heff_drop(v_x_2412); r_; });
  {
    V v_field_2436 = v_t_2434.f[1];
    heff_drop(v_t_2434.f[0]);
    V v_t_2437 = heff_tr(heff_call(v_field_2436, 1, (V[]){v_t_2433}));
    HeffT2 v_t_2445 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam2, 1, 1, (V[]){v_globals_247})));
    {
      V v_field_2447 = v_t_2445.f[1];
      heff_drop(v_t_2445.f[0]);
      V v_t_2448 = heff_tr(heff_call(v_field_2447, 1, (V[]){v_t_2437}));
      V v_x_2449 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(g_heff_2eelab_2erules_2efreshMeta_24rec0_get()), MK_INT(0LL), heff_get_n(v_scope_246, 1, 5), v_t_2448));
      V f_ = v_k_243;
      args[0] = v_x_2449;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eunsolvedWorld_str0, 6, "co.<+>");
Clo g_heff_2eelab_2erules_2eunsolvedWorld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eunsolvedWorld_entry, 2, 0};

V g_heff_2eelab_2erules_2eunsolvedWorld(V v_mc_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VNeu: {
    V v_v1_242 = heff_field(v_v_241, 0);
    V v_sp_243 = heff_field(v_v_241, 1);
    switch (heff_tag_of(v_v1_242)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_k_248 = heff_field(v_v1_242, 0);
      switch (heff_tag_of(v_sp_243)) {
      case TAG_SpId: {
        return NTAG(TAG_False);
      }
      case TAG_SpApp: {
        V v_sp1_249 = heff_field(v_sp_243, 0);
        V v_b_2410 = heff_field(v_sp_243, 1);
        switch (heff_tag_of(v_sp1_249)) {
        case TAG_SpId: {
          return NTAG(TAG_False);
        }
        case TAG_SpApp: {
          V v_sp11_2411 = heff_field(v_sp1_249, 0);
          V v_a_2412 = heff_field(v_sp1_249, 1);
          switch (heff_tag_of(v_sp11_2411)) {
          case TAG_SpId: {
            if (heff_strEq_c_lent(v_k_248, ((V)&g_heff_2eelab_2erules_2eunsolvedWorld_str0), 2)) {
              V v_t_2413 = (g_heff_2eelab_2erules_2eunsolvedWorld(v_mc_240, v_a_2412));
              if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
                heff_drop(v_t_2413);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2413);
                V t_0 = v_mc_240;
                V t_1 = v_b_2410;
                v_mc_240 = t_0;
                v_v_241 = t_1;
                goto top;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_SpApp: {
            return NTAG(TAG_False);
          }
          case TAG_SpProj: {
            return NTAG(TAG_False);
          }
          case TAG_SpSpec: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_sp11_2411);
          }
        }
        case TAG_SpProj: {
          return NTAG(TAG_False);
        }
        case TAG_SpSpec: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_sp1_249);
        }
      }
      case TAG_SpProj: {
        return NTAG(TAG_False);
      }
      case TAG_SpSpec: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_sp_243);
      }
    }
    case TAG_HMeta: {
      V v_m_2431 = heff_field(v_v1_242, 0);
      HeffT2 v_t_2432 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(v_mc_240, heff_dup(v_m_2431)));
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          V v_entry_2435 = v_field_2434;
          V v_t_2436 = heff_get_n(v_entry_2435, 2, 6);
          switch (heff_tag_of(v_t_2436)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            V v_s_2437 = heff_field(v_t_2436, 0);
            heff_take_n(v_t_2436, 1ULL, 1);
            return (g_heff_2eelab_2erules_2eunsolvedWorldTm(v_mc_240, MK_INT(64LL), v_s_2437));
          }
          default: return heff_nomatch(v_t_2436);
          }
        } else {
          heff_drop(v_field_2434);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_v1_242);
    }
  }
  case TAG_VCode: {
    return NTAG(TAG_False);
  }
  case TAG_VLam: {
    return NTAG(TAG_False);
  }
  case TAG_VCons: {
    return NTAG(TAG_False);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2erules_2eunsolvedWorld_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eunsolvedWorld(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2egoalShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egoalShown_entry, 3, 0};

V g_heff_2eelab_2erules_2egoalShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_get_n(v_e_240, 1, 8);
  HeffT2 v_t_245 = (g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(v_mc_241));
  {
    V v_field_247 = v_t_245.f[1];
    heff_drop(v_t_245.f[0]);
    V v_t_248 = heff_tr(heff_call(v_field_247, 2, (V[]){heff_take_field(v_scope_243, 0), v_goal_242}));
    HeffT2 v_t_2416 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2egoalShown_lam0, 1, 1, (V[]){v_globals_244})));
    {
      V v_field_2418 = v_t_2416.f[1];
      heff_drop(v_t_2416.f[0]);
      V v_t_2419 = heff_tr(heff_call(v_field_2418, 1, (V[]){v_t_248}));
      return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(g_heff_2eelab_2erules_2efreshMeta_24rec0_get()), MK_INT(0LL), heff_get_n(v_scope_243, 1, 5), v_t_2419));
    }
  }
}
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2egoalShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_globals_244 = heff_env(self)[0];
  V v_d_2410 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_249)));
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V b_0 = heff_get_n(v_globals_244, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_x_249; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_x_249); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_d_2410);
      V v_x_2415 = v_field_2414;
      return v_x_2415;
    } else {
      heff_drop(v_field_2414);
      return v_d_2410;
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einstGlobal_str0, 12, "declared by ");
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstGlobal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstGlobal_entry, 2, 0};

V g_heff_2eelab_2erules_2einstGlobal(V v_e_240, V v_i_241) {
top: ;
  V v_key_242 = heff_take_field(v_i_241, 0);
  V v_module_243 = heff_get_n(v_i_241, 1, 2);
  V v_g_244 = heff_dup(heff_rfield(v_e_240, 1));
  V v_entries_245 = heff_take_field(v_g_244, 1);
  V v_aliases_246 = heff_get_n(v_g_244, 2, 8);
  V v_k_247 = heff_dup(v_key_242);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_245, v_k_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2416;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_entries_245);
      heff_drop(v_aliases_246);
      heff_drop(v_k_247);
      V v_e_2411 = v_field_2410;
      v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2411});
    } else {
      heff_drop(v_field_2410);
      HeffT2 v_t_2412 = ({ V a_0 = v_aliases_246; V a_1 = v_k_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_246); heff_drop(v_k_247); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_k2_2415 = v_field_2414;
          v_t_2416 = ({ V a_0 = v_entries_245; V a_1 = v_k2_2415; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_entries_245); heff_drop(v_k2_2415); r_; });
        } else {
          heff_drop(v_entries_245);
          heff_drop(v_field_2414);
          v_t_2416 = NTAG(TAG_Nothing);
        }
      }
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_key_242);
      heff_drop(v_module_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_ge_2417 = heff_field(v_t_2416, 0);
      V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 1ULL, 1);
      V v_value_2418 = heff_take_field(v_ge_2417, 2);
      V v_type_5f_2419 = heff_get_n(v_ge_2417, 3, 4);
      V v_from_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2einstGlobal_str0), v_module_243);
      V v_t_2421 = heff_dup(v_key_242);
      V v_val_2422 = v_value_2418;
      V v_t_2432 = heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstGlobal_lam0, 1, 2, (V[]){v_key_242, v_e_240}), v_from_2420, NTAG(TAG_True), v_type_5f_2419, heff_tag_n(TAG_SGlobal, 1, (V[]){v_t_2421}), v_val_2422});
      return heff_tag_at_n(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){v_t_2432});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
}
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstGlobal(a[0], a[1]);
}
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_key_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_drop(v_u_2423);
  heff_clo_take(self, 2);
  V v_x_2424 = v_key_242;
  V v_d_2425 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2424)));
  V v_t_2426 = heff_get_n(heff_get_n(v_e_240, 1, 8), 2, 8);
  V v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_t_2426); r_; });
  HeffT2 v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2424; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2427); heff_drop(v_x_2424); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      heff_drop(v_d_2425);
      V v_x_2431 = v_field_2430;
      return v_x_2431;
    } else {
      heff_drop(v_field_2430);
      return v_d_2425;
    }
  }
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam0, 1, 0};
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam2, 1, 0};
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam5, 1, 0};
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam9, 1, 0};
V g_heff_2eelab_2erules_2efits_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_entry, 6, 0};

V g_heff_2eelab_2erules_2efits(V v_e_240, V v_sp_241, V v_goal_242, V v_w_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2efits_lam1, 1, 6, (V[]){v_w_243, v_goal_242, v_k_245, v_hd_244, v_e_240, v_sp_241})});
}
V g_heff_2eelab_2erules_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  return heff_get_n(v_c_246, 3, 9);
}
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args) {
  V v_c_2492 = args[0];
  return v_c_2492;
}
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args) {
  V v_c_2498 = args[0];
  return heff_get_n(v_c_2498, 3, 9);
}
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args) {
  V v_p_24109 = args[0];
  V v_p_24110 = args[1];
  V v_g_24103 = heff_env(self)[0];
  V v_len_24105 = heff_env(self)[1];
  V v_names_24106 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_b_24108 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24111 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_24103, heff_rec_n(2, shape_len__names, (V[]){v_len_24105, v_names_24106}), v_goal_242, v_b_24108}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_24111, v_p_24109, v_p_24110));
}
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args) {
  V v_c_24117 = args[0];
  return v_c_24117;
}
V g_heff_2eelab_2erules_2efits_lam11(V self, V *args) {
  V v_x_24125 = args[0];
  V v_r_24112 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2497 = heff_env(self)[2];
  V v_x_24121 = heff_env(self)[3];
  V v_k_24114 = heff_env(self)[4];
  heff_drop(v_x_24125);
  V v_t_24128;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_r_24112)) {
  case TAG_Left: {
    heff_take_n(v_r_24112, 0ULL, 1);
    heff_drop_rec(v_w_243, 6);
    heff_drop_rec(v_x_2497, 3);
    heff_drop(v_x_24121);
    v_t_24128 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_ru_24r_24112_24Right = heff_take_reuse_n(v_r_24112, 0ULL, 1);
    v_t_24128 = heff_tag_at_n(v_ru_24r_24112_24Right, TAG_Just, 1, (V[]){heff_rec_n(3, shape_witness__instantiated__state, (V[]){v_w_243, v_x_2497, v_x_24121})});
    break;
  }
  default: heff_nomatch(v_r_24112);
  }
  V f_ = v_k_24114;
  args[0] = v_t_24128;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efits_lam10(V self, V *args) {
  V v_x_24121 = args[0];
  V v_x_2496 = heff_env(self)[0];
  V v_malg_24115 = heff_env(self)[1];
  V v_bind_24116 = heff_env(self)[2];
  V v_r_24112 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_x_2497 = heff_env(self)[5];
  V v_k_24114 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24122 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2496, NTAG(TAG_MkUnit)});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(v_malg_24115, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})}));
  V f_ = v_bind_24116;
  heff_room[0] = v_t_24124;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam11, 1, 5, (V[]){v_r_24112, v_w_243, v_x_2497, v_x_24121, v_k_24114});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args) {
  V v_r_24112 = args[0];
  V v_hd_24113 = args[1];
  V v_k_24114 = args[2];
  V v_x_2496 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2497 = heff_env(self)[2];
  V v_malg_24115 = heff_take_field(v_hd_24113, 2);
  V v_bind_24116 = heff_get_n(v_hd_24113, 1, 3);
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam9_clo)})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tr(heff_call(heff_dup(v_malg_24115), 1, (V[]){v_t_24119}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(v_bind_24116);
  args[0] = v_t_24120;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam10, 1, 7, (V[]){v_x_2496, v_malg_24115, v_bind_24116, v_r_24112, v_w_243, v_x_2497, v_k_24114});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args) {
  V v_x_24102 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2497 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_x_2496 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_g_24103 = heff_take_field(v_e_240, 1);
  V v_c_24104 = heff_get_n(v_e_240, 0, 8);
  V v_len_24105 = heff_take_field(v_c_24104, 0);
  V v_names_24106 = heff_get_n(v_c_24104, 1, 5);
  V v_t_24107 = ({ V a_0 = v_x_24102; V a_1 = heff_dup(heff_rfield(v_x_2497, 1)); V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_x_24102); r_; });
  V v_b_24108 = (g_heff_2eelab_2erules_2eunspecForced(v_t_24107));
  return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2efits_lam7, 2, 5, (V[]){v_g_24103, v_len_24105, v_names_24106, v_goal_242, v_b_24108}), heff_clo_n(g_heff_2eelab_2erules_2efits_lam8, 3, 3, (V[]){v_x_2496, v_w_243, v_x_2497}), v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args) {
  V v_x_2497 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_x_2496 = heff_env(self)[3];
  V v_w_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam5_clo)})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_24100}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_24101;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam6, 1, 7, (V[]){v_e_240, v_x_2497, v_goal_242, v_x_2496, v_w_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args) {
  V v_x_2496 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_243 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2einstantiate(heff_dup(v_e_240), v_sp_241, heff_dup(v_w_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2efits_lam4, 1, 6, (V[]){v_hd_244, v_e_240, v_goal_242, v_x_2496, v_w_243, v_k_245})));
}
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_243 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_t_2411 = heff_dup(heff_rfield(v_w_243, 2));
  V v_t_2491;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    V v_t_2412 = (g_heff_2eelab_2erules_2econclusionOf(MK_INT(0LL), heff_dup(heff_rfield(v_w_243, 3))));
    V v_conclusion_2413 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2412));
    V v_mc_2414 = heff_dup(v_x_2410);
    V v_t_2415 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_goal_242); V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_x_2410); r_; });
    V v_conclusion_2416 = v_conclusion_2413;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_VDecode: {
      V v_t1_2417 = heff_field(v_t_2415, 0);
      V v_sp_2418 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 3ULL, 5);
      switch (heff_tag_of(v_t1_2417)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2417, 0ULL, 1);
        heff_drop(v_mc_2414);
        heff_drop(v_conclusion_2416);
        heff_drop(v_sp_2418);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k2_2423 = heff_field(v_t1_2417, 0);
        heff_take_n(v_t1_2417, 1ULL, 1);
        switch (heff_tag_of(v_conclusion_2416)) {
        case TAG_VU: {
          heff_take_n(v_conclusion_2416, 0ULL, 1);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VDecode: {
          V v_conclusion1_2425 = heff_field(v_conclusion_2416, 0);
          V v_csp_2426 = heff_field(v_conclusion_2416, 1);
          heff_take_n(v_conclusion_2416, 3ULL, 5);
          switch (heff_tag_of(v_conclusion1_2425)) {
          case TAG_HLocal: {
            heff_take_n(v_conclusion1_2425, 0ULL, 1);
            heff_drop(v_mc_2414);
            heff_drop(v_sp_2418);
            heff_drop(v_k2_2423);
            heff_drop(v_csp_2426);
            v_t_2491 = NTAG(TAG_False);
            break;
          }
          case TAG_HGlobal: {
            V v_k_2431 = heff_field(v_conclusion1_2425, 0);
            heff_take_n(v_conclusion1_2425, 1ULL, 1);
            if (!heff_strEq_c_lent(v_k_2431, v_k2_2423, 0)) {
              heff_drop(v_mc_2414);
              heff_drop(v_sp_2418);
              heff_drop(v_k2_2423);
              heff_drop(v_csp_2426);
              heff_drop(v_k_2431);
              v_t_2491 = NTAG(TAG_True);
            } else {
              heff_drop(v_k2_2423);
              heff_drop(v_k_2431);
              v_t_2491 = ({ V a_0 = v_mc_2414; V a_1 = v_sp_2418; V a_2 = v_csp_2426; V r_ = (g_heff_2eelab_2erules_2eapartSpines(a_0, a_1, a_2)); heff_drop(v_mc_2414); heff_drop(v_sp_2418); heff_drop(v_csp_2426); r_; });
            }
            break;
          }
          case TAG_HMeta: {
            heff_take_n(v_conclusion1_2425, 0ULL, 1);
            heff_drop(v_mc_2414);
            heff_drop(v_sp_2418);
            heff_drop(v_k2_2423);
            heff_drop(v_csp_2426);
            v_t_2491 = NTAG(TAG_False);
            break;
          }
          case TAG_HError: {
            heff_drop(v_mc_2414);
            heff_drop(v_sp_2418);
            heff_drop(v_k2_2423);
            heff_drop(v_csp_2426);
            v_t_2491 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_conclusion1_2425);
          }
          break;
        }
        case TAG_VFunction: {
          heff_take_n(v_conclusion_2416, 0ULL, 6);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_conclusion_2416, 0ULL, 4);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_conclusion_2416, 0ULL, 1);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimInt: {
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimString: {
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimRune: {
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_conclusion_2416, 0ULL, 1);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_conclusion_2416, 0ULL, 1);
          heff_drop(v_mc_2414);
          heff_drop(v_sp_2418);
          heff_drop(v_k2_2423);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_conclusion_2416);
        }
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2417, 0ULL, 1);
        heff_drop(v_mc_2414);
        heff_drop(v_conclusion_2416);
        heff_drop(v_sp_2418);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        heff_drop(v_mc_2414);
        heff_drop(v_conclusion_2416);
        heff_drop(v_sp_2418);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2417);
      }
      break;
    }
    default: {
      heff_drop(v_mc_2414);
      switch (heff_tag_of(v_conclusion_2416)) {
      case TAG_VU: {
        heff_take_n(v_conclusion_2416, 0ULL, 1);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_conclusion1_2448 = heff_field(v_conclusion_2416, 0);
        heff_take_n(v_conclusion_2416, 1ULL, 5);
        switch (heff_tag_of(v_conclusion1_2448)) {
        case TAG_HLocal: {
          heff_take_n(v_conclusion1_2448, 0ULL, 1);
          heff_drop(v_t_2415);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_conclusion1_2448, 0ULL, 1);
          switch (heff_tag_of(v_t_2415)) {
          case TAG_VU: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VDecode: {
            V v_h_2456 = heff_field(v_t_2415, 0);
            heff_take_n(v_t_2415, 1ULL, 5);
            switch (heff_tag_of(v_h_2456)) {
            case TAG_HLocal: {
              heff_take_n(v_h_2456, 0ULL, 1);
              v_t_2491 = NTAG(TAG_True);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_h_2456, 0ULL, 1);
              v_t_2491 = NTAG(TAG_True);
              break;
            }
            case TAG_HMeta: {
              heff_take_n(v_h_2456, 0ULL, 1);
              v_t_2491 = NTAG(TAG_True);
              break;
            }
            case TAG_HError: {
              v_t_2491 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_h_2456);
            }
            break;
          }
          case TAG_VFunction: {
            heff_take_n(v_t_2415, 0ULL, 6);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VRecord: {
            heff_take_n(v_t_2415, 0ULL, 4);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VSum: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VPrimInt: {
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VPrimFloat: {
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VPrimString: {
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VPrimRune: {
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VPrimArray: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_VFixed: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_conclusion1_2448, 0ULL, 1);
          heff_drop(v_t_2415);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_HError: {
          heff_drop(v_t_2415);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_conclusion1_2448);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_conclusion_2416, 0ULL, 6);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        heff_take_n(v_conclusion_2416, 0ULL, 4);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_conclusion_2416, 0ULL, 1);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_conclusion_2416, 0ULL, 1);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        heff_take_n(v_conclusion_2416, 0ULL, 1);
        heff_drop(v_t_2415);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_conclusion_2416);
      }
      break;
    }
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_t_2411);
    v_t_2491 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
    heff_clo_take(self, 6);
    heff_drop_rec(v_w_243, 6);
    heff_drop(v_goal_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_sp_241);
    heff_drop(v_t_2491);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2491);
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam2_clo)})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2494}));
    heff_clo_take(self, 6);
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2495;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam3, 1, 6, (V[]){v_e_240, v_sp_241, v_w_243, v_hd_244, v_goal_242, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2eelab_2erules_2echeckSetting_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_24map0_entry, 2, 0};

V g_heff_2eelab_2erules_2echeckSetting_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_e_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_246;
      switch (heff_tag_of(v_e_242)) {
      case TAG_Nom: {
        V v_x_243 = heff_field(v_e_242, 0);
        heff_take_n(v_e_242, 1ULL, 1);
        v_t_246 = v_x_243;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_e_242, 0ULL, 1);
        v_t_246 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_245 = heff_field(v_e_242, 0);
        heff_take_n(v_e_242, 1ULL, 1);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), v_t_246);
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_e_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_246;
    switch (heff_tag_of(v_e_242)) {
    case TAG_Nom: {
      V v_x_243 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      v_t_246 = v_x_243;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_e_242, 0ULL, 1);
      v_t_246 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_245 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      v_t_246 = v_x_245;
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), v_t_246);
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2echeckSetting_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckSetting_24map0(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str1, 21, "  [ready at the call]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str2, 39, "  [evidence: its one witness, or waits]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str3, 23, "  [waits for implicits]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str4, 7, "wanted ");
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam1, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam5, 2, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam6, 2, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam9, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam10(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam8(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam11(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam11, 2, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam14(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam14, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam17(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam18(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam16(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam15(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam13(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam12(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam20(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam19(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam22(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam21(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam24(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam23(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
  return ({ V a_0 = v_t_246; V a_1 = v_t_247; V a_2 = heff_dup(v_goal_242); V a_3 = v_name_243; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_244); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam0, 1, 5, (V[]){v_hd_244, v_e_240, v_goal_242, v_sp_241, v_k_245}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
}
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertInstance(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 9);
}
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args) {
  V v_u_2424 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_ready_2422 = heff_env(self)[3];
  V v_x_2423 = heff_env(self)[4];
  heff_drop(v_u_2424);
  heff_clo_take(self, 5);
  V v_t_2425 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_242; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2426;
  if ((heff_dup(v_ready_2422) == NTAG(TAG_True))) {
    heff_drop(v_ready_2422);
    heff_drop(v_x_2423);
    v_t_2426 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str1);
  } else {
    heff_drop(v_ready_2422);
    if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2423);
      v_t_2426 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str2);
    } else {
      heff_drop(v_x_2423);
      v_t_2426 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str3);
    }
  }
  return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2einsertInstance_str4), v_t_2425), v_t_2426);
}
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam9(V self, V *args) {
  V v_c_2460 = args[0];
  return heff_get_n(v_c_2460, 3, 9);
}
V g_heff_2eelab_2erules_2einsertInstance_lam10(V self, V *args) {
  V v_x_2464 = args[0];
  V v_final_2457 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_k_2459 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_hd_2458 = heff_env(self)[6];
  if (!(heff_dup(v_final_2457) == NTAG(TAG_True))) {
    HeffT3 v_t_2465 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2464, heff_dup(v_goal_242)));
    {
      V v_field_2467 = v_t_2465.f[1];
      V v_field_2468 = v_t_2465.f[2];
      int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
      if ((v_tag_2466 == ((int64_t)0ULL))) {
        V v_h_2469 = v_field_2467;
        heff_drop(v_h_2469);
        V v_w_2470 = v_field_2468;
        V v_t_2471 = ({ V a_0 = v_x_2464; V a_1 = v_w_2470; V r_ = (g_heff_2eelab_2erules_2eunsolvedWorld(a_0, a_1)); heff_drop(v_x_2464); heff_drop(v_w_2470); r_; });
        if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
          heff_clo_take(self, 7);
          heff_drop(v_final_2457);
          heff_drop(v_goal_242);
          heff_drop_rec(v_x_248, 2);
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_sp_241);
          heff_drop_rec(v_hd_2458, 3);
          heff_drop(v_t_2471);
          V f_ = v_k_2459;
          args[0] = NTAG(TAG_False);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_t_2471);
          V v_t_2472 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_x_248, 0)));
          heff_clo_take(self, 7);
          return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2472, heff_get_n(v_x_248, 1, 2), v_goal_242, v_final_2457, v_hd_2458, v_k_2459));
        }
      } else {
        heff_drop(v_x_2464);
        heff_drop(v_field_2467);
        heff_drop(v_field_2468);
        V v_t_2473 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_x_248, 0)));
        heff_clo_take(self, 7);
        return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2473, heff_get_n(v_x_248, 1, 2), v_goal_242, v_final_2457, v_hd_2458, v_k_2459));
      }
    }
  } else {
    heff_drop(v_x_2464);
    V v_t_2474 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_x_248, 0)));
    heff_clo_take(self, 7);
    return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2474, heff_get_n(v_x_248, 1, 2), v_goal_242, v_final_2457, v_hd_2458, v_k_2459));
  }
}
V g_heff_2eelab_2erules_2einsertInstance_lam8(V self, V *args) {
  V v_final_2457 = args[0];
  V v_hd_2458 = args[1];
  V v_k_2459 = args[2];
  V v_goal_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam9_clo)})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2458, 2)), 1, (V[]){v_t_2462}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_2458, 1));
  args[0] = v_t_2463;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam10, 1, 7, (V[]){v_final_2457, v_goal_242, v_k_2459, v_x_248, v_e_240, v_sp_241, v_hd_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam11(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam14(V self, V *args) {
  V v_c_2484 = args[0];
  return heff_get_n(v_c_2484, 3, 9);
}
V g_heff_2eelab_2erules_2einsertInstance_lam17(V self, V *args) {
  V v_b_24115 = args[0];
  V v_waits_2475 = heff_env(self)[0];
  V v_hd_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_24116 = heff_tr(heff_call(v_waits_2475, 1, (V[]){v_b_24115}));
  V f_ = v_c_24116;
  heff_room[0] = heff_dup(v_hd_2480);
  heff_room[1] = heff_get_n(v_hd_2480, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam18(V self, V *args) {
  V v_x_24120 = args[0];
  V v_k_2483 = heff_env(self)[0];
  heff_drop(v_x_24120);
  heff_clo_take(self, 1);
  V f_ = v_k_2483;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam16(V self, V *args) {
  V v_x_24114 = args[0];
  V v_k_2483 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_waits_2475 = heff_env(self)[2];
  V v_hd_2480 = heff_env(self)[3];
  if ((heff_dup(v_x_24114) == NTAG(TAG_True))) {
    heff_drop(v_x_24114);
    heff_clo_take(self, 4);
    heff_drop(v_sp_241);
    heff_drop_clo(v_waits_2475, 4);
    heff_drop_rec(v_hd_2480, 3);
    V f_ = v_k_2483;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24114);
    heff_clo_take(self, 4);
    V v_t_24117 = heff_tag_n(TAG_Want, 3, (V[]){v_sp_241, heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam17, 1, 2, (V[]){v_waits_2475, heff_dup(v_hd_2480)}), NTAG(TAG_MkUnit)});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_2480, 2), 1, (V[]){v_t_24118}));
    V f_ = heff_get_n(v_hd_2480, 1, 3);
    heff_room[0] = v_t_24119;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam18, 1, 1, (V[]){v_k_2483});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2einsertInstance_lam15(V self, V *args) {
  V v_x_2488 = args[0];
  V v_b_2482 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_hd_2480 = heff_env(self)[5];
  V v_k_2483 = heff_env(self)[6];
  V v_fresh_2449 = heff_env(self)[7];
  V v_waits_2475 = heff_env(self)[8];
  if ((heff_dup(v_b_2482) == NTAG(TAG_True))) {
    heff_drop(v_x_2488);
    heff_clo_take(self, 9);
    heff_drop(v_fresh_2449);
    heff_drop_clo(v_waits_2475, 4);
    V v_t_2489 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_x_248, 0)));
    return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2489, heff_get_n(v_x_248, 1, 2), v_goal_242, v_b_2482, v_hd_2480, v_k_2483));
  } else {
    heff_clo_take(self, 9);
    heff_drop(v_b_2482);
    HeffT3 v_t_2490 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2488, heff_dup(v_goal_242)));
    {
      V v_field_2492 = v_t_2490.f[1];
      V v_field_2493 = v_t_2490.f[2];
      int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
      V v_x1_24109;
      if ((v_tag_2491 == ((int64_t)0ULL))) {
        V v_h_2494 = v_field_2492;
        heff_drop(v_h_2494);
        V v_w_2495 = v_field_2493;
        V v_it_2496 = ({ V a_0 = v_x_2488; V a_1 = v_w_2495; V r_ = (g_heff_2eelab_2evalue_2eforceEl(a_0, a_1)); heff_drop(v_x_2488); r_; });
        switch (heff_tag_of(v_it_2496)) {
        case TAG_VNeu: {
          V v_it1_2497 = heff_field(v_it_2496, 0);
          heff_take_n(v_it_2496, 1ULL, 5);
          switch (heff_tag_of(v_it1_2497)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_2497, 0ULL, 1);
            v_x1_24109 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_2497, 0ULL, 1);
            v_x1_24109 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24104 = heff_field(v_it1_2497, 0);
            V v_ru_24it1_2497_24HMeta = heff_take_reuse_n(v_it1_2497, 1ULL, 1);
            v_x1_24109 = heff_tag_at_n(v_ru_24it1_2497_24HMeta, TAG_Just, 1, (V[]){v_m_24104});
            break;
          }
          case TAG_HError: {
            v_x1_24109 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_2497);
          }
          break;
        }
        case TAG_VCode: {
          heff_take_n(v_it_2496, 0ULL, 1);
          v_x1_24109 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          heff_take_n(v_it_2496, 0ULL, 2);
          v_x1_24109 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_it_2496, 0ULL, 1);
          v_x1_24109 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_x1_24109 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it_2496);
        }
      } else {
        heff_drop(v_x_2488);
        heff_drop(v_field_2492);
        heff_drop(v_field_2493);
        v_x1_24109 = NTAG(TAG_Nothing);
      }
      V v_t_24113;
      switch (heff_tag_of(v_x1_24109)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_fresh_2449)) {
        case TAG_Nothing: {
          v_t_24113 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_fresh_2449, 0ULL, 1);
          v_t_24113 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_fresh_2449);
        }
        break;
      }
      case TAG_Just: {
        V v_x_24111 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        switch (heff_tag_of(v_fresh_2449)) {
        case TAG_Nothing: {
          heff_drop(v_x_24111);
          v_t_24113 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_y_24112 = heff_field(v_fresh_2449, 0);
          heff_take_n(v_fresh_2449, 1ULL, 1);
          v_t_24113 = heff_bool(heff_intEq_c_lent(v_x_24111, v_y_24112, 0));
          heff_drop(v_x_24111);
          heff_drop(v_y_24112);
          break;
        }
        default: heff_nomatch(v_fresh_2449);
        }
        break;
      }
      default: heff_nomatch(v_x1_24109);
      }
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_248, 2);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_sp_241);
        heff_drop(v_goal_242);
        heff_drop_rec(v_hd_2480, 3);
        heff_drop_clo(v_waits_2475, 4);
        heff_drop(v_t_24113);
        V f_ = v_k_2483;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_t_24113);
        return (g_heff_2eelab_2erules_2esearchedNow(v_e_240, heff_dup(v_sp_241), v_x_248, v_goal_242, heff_dup(v_hd_2480), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam16, 1, 4, (V[]){v_k_2483, v_sp_241, v_waits_2475, v_hd_2480})));
      }
    }
  }
}
V g_heff_2eelab_2erules_2einsertInstance_lam13(V self, V *args) {
  V v_b_2482 = args[0];
  V v_hd_2480 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_fresh_2449 = heff_env(self)[5];
  V v_waits_2475 = heff_env(self)[6];
  V v_k_2483 = heff_dup(heff_rfield(v_hd_2480, 0));
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam14_clo)})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2480, 2)), 1, (V[]){v_t_2486}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_2480, 1));
  heff_room[0] = v_t_2487;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam15, 1, 9, (V[]){v_b_2482, v_x_248, v_e_240, v_sp_241, v_goal_242, v_hd_2480, v_k_2483, v_fresh_2449, v_waits_2475});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam12(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_fresh_2449 = heff_env(self)[4];
  V v_waits_2475 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24121 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam13, 1, 7, (V[]){heff_dup(v_hd_2480), v_x_248, v_e_240, v_sp_241, v_goal_242, v_fresh_2449, v_waits_2475}), NTAG(TAG_MkUnit)});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tr(heff_call(heff_take_field(v_hd_2480, 2), 1, (V[]){v_t_24122}));
  V f_ = heff_get_n(v_hd_2480, 1, 3);
  args[0] = v_t_24123;
  args[1] = v_k2_2481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam20(V self, V *args) {
  V v_b_24126 = args[0];
  V v_waits_2475 = heff_env(self)[0];
  V v_hd_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_24127 = heff_tr(heff_call(v_waits_2475, 1, (V[]){v_b_24126}));
  V f_ = v_c_24127;
  heff_room[0] = heff_dup(v_hd_24124);
  heff_room[1] = heff_get_n(v_hd_24124, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k2_24125 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_waits_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_tag_n(TAG_Want, 3, (V[]){v_sp_241, heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam20, 1, 2, (V[]){v_waits_2475, heff_dup(v_hd_24124)}), NTAG(TAG_MkUnit)});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tr(heff_call(heff_take_field(v_hd_24124, 2), 1, (V[]){v_t_24129}));
  V f_ = heff_get_n(v_hd_24124, 1, 3);
  args[0] = v_t_24130;
  args[1] = v_k2_24125;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam22(V self, V *args) {
  V v_b_24133 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_24131 = heff_env(self)[4];
  V v_t_24134 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_x_248, 0)));
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_24134, heff_get_n(v_x_248, 1, 2), v_goal_242, v_b_24133, heff_dup(v_hd_24131), heff_get_n(v_hd_24131, 0, 3)));
}
V g_heff_2eelab_2erules_2einsertInstance_lam21(V self, V *args) {
  V v_hd_24131 = args[0];
  V v_k2_24132 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24135 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam22, 1, 5, (V[]){v_x_248, v_e_240, v_sp_241, v_goal_242, heff_dup(v_hd_24131)}), NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_24131, 2), 1, (V[]){v_t_24136}));
  V f_ = heff_get_n(v_hd_24131, 1, 3);
  args[0] = v_t_24137;
  args[1] = v_k2_24132;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam24(V self, V *args) {
  V v_u_24140 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_drop(v_u_24140);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_248, 1, 2)});
}
V g_heff_2eelab_2erules_2einsertInstance_lam23(V self, V *args) {
  V v_x_24139 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_drop(v_x_24139);
  heff_clo_take(self, 2);
  V v_t_24141 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam24, 1, 1, (V[]){heff_dup(v_x_248)}); V rr_ = heff_rec_reuse_nf(v_x_248, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_24141;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_goal_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_x_2423 = heff_env(self)[4];
  V v_fresh_2449 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_waits_2475 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam8, 3, 4, (V[]){heff_dup(v_goal_242), heff_dup(v_x_248), heff_dup(v_e_240), heff_dup(v_sp_241)});
  V v_t_24138;
  heff_clo_take(self, 8);
  if ((heff_dup(v_x_2456) == NTAG(TAG_True))) {
    heff_drop(v_x_2456);
    heff_drop(v_goal_242);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_sp_241);
    heff_drop(v_x_2423);
    heff_drop(v_fresh_2449);
    heff_drop_clo(v_waits_2475, 4);
    v_t_24138 = ((V)&g_heff_2eelab_2erules_2einsertInstance_lam11_clo);
  } else {
    heff_drop(v_x_2456);
    V v_t_2479;
    if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
      switch (heff_tag_of(v_fresh_2449)) {
      case TAG_Nothing: {
        v_t_2479 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2479 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_fresh_2449);
      }
    } else {
      v_t_2479 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
      heff_drop(v_x_2423);
      heff_drop(v_t_2479);
      v_t_24138 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam12, 2, 6, (V[]){v_sp_241, heff_dup(v_x_248), v_e_240, v_goal_242, v_fresh_2449, v_waits_2475});
    } else {
      heff_drop(v_fresh_2449);
      heff_drop(v_t_2479);
      if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
        heff_drop(v_goal_242);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_x_2423);
        v_t_24138 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam19, 2, 2, (V[]){v_sp_241, v_waits_2475});
      } else {
        heff_drop(v_x_2423);
        heff_drop_clo(v_waits_2475, 4);
        v_t_24138 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam21, 2, 4, (V[]){v_sp_241, heff_dup(v_x_248), v_e_240, v_goal_242});
      }
    }
  }
  V f_ = v_t_24138;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam23, 1, 2, (V[]){v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_ready_2422 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_hd_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_drop(v_x_2429);
  HeffT3 v_t_2430 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2413, heff_dup(v_goal_242)));
  {
    V v_field_2432 = v_t_2430.f[1];
    V v_field_2433 = v_t_2430.f[2];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    V v_fresh_2449;
    heff_clo_take(self, 9);
    if ((v_tag_2431 == ((int64_t)0ULL))) {
      V v_h_2434 = v_field_2432;
      heff_drop(v_h_2434);
      V v_w_2435 = v_field_2433;
      V v_it_2436 = ({ V a_0 = v_x_2413; V a_1 = v_w_2435; V r_ = (g_heff_2eelab_2evalue_2eforceEl(a_0, a_1)); heff_drop(v_x_2413); r_; });
      switch (heff_tag_of(v_it_2436)) {
      case TAG_VNeu: {
        V v_it1_2437 = heff_field(v_it_2436, 0);
        heff_take_n(v_it_2436, 1ULL, 5);
        switch (heff_tag_of(v_it1_2437)) {
        case TAG_HLocal: {
          heff_take_n(v_it1_2437, 0ULL, 1);
          v_fresh_2449 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_it1_2437, 0ULL, 1);
          v_fresh_2449 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2444 = heff_field(v_it1_2437, 0);
          V v_ru_24it1_2437_24HMeta = heff_take_reuse_n(v_it1_2437, 1ULL, 1);
          v_fresh_2449 = heff_tag_at_n(v_ru_24it1_2437_24HMeta, TAG_Just, 1, (V[]){v_m_2444});
          break;
        }
        case TAG_HError: {
          v_fresh_2449 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it1_2437);
        }
        break;
      }
      case TAG_VCode: {
        heff_take_n(v_it_2436, 0ULL, 1);
        v_fresh_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VLam: {
        heff_take_n(v_it_2436, 0ULL, 2);
        v_fresh_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_it_2436, 0ULL, 1);
        v_fresh_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VOpaque: {
        v_fresh_2449 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it_2436);
      }
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2432);
      heff_drop(v_field_2433);
      v_fresh_2449 = NTAG(TAG_Nothing);
    }
    V v_t_2455;
    if (((heff_dup(v_ready_2422) == NTAG(TAG_True)) || (heff_dup(v_x_2423) == NTAG(TAG_True)))) {
      heff_drop(v_ready_2422);
      if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
        switch (heff_tag_of(v_fresh_2449)) {
        case TAG_Nothing: {
          v_t_2455 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2esearchedNow_clo), 4, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_x_248), heff_dup(v_goal_242)}));
          break;
        }
        case TAG_Just: {
          v_t_2455 = ((V)&g_heff_2eelab_2erules_2einsertInstance_lam5_clo);
          break;
        }
        default: heff_nomatch(v_fresh_2449);
        }
      } else {
        v_t_2455 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2esearchedNow_clo), 4, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_x_248), heff_dup(v_goal_242)}));
      }
    } else {
      heff_drop(v_ready_2422);
      v_t_2455 = ((V)&g_heff_2eelab_2erules_2einsertInstance_lam6_clo);
    }
    V f_ = v_t_2455;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam7, 1, 8, (V[]){v_goal_242, v_x_248, v_e_240, v_sp_241, v_x_2423, v_fresh_2449, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  HeffT3 v_t_2414 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_x_2413)));
  {
    V v_field_2416 = v_t_2414.f[1];
    heff_drop(v_t_2414.f[0]);
    heff_drop(v_t_2414.f[2]);
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
    V v_x1_2419 = heff_tr(heff_call(v_field_2416, 3, (V[]){MK_INT(20LL), v_t_2418, heff_dup(v_goal_242)}));
    V v_ready_2422;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      v_ready_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2419, 0ULL, 2);
      v_ready_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    V v_x_2423 = (g_heff_2eelab_2erules_2eisEvidence(v_x_2413, heff_dup(v_goal_242)));
    V v_t_2427 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2einsertInstance_str0), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam3, 1, 5, (V[]){heff_dup(v_e_240), heff_dup(v_x_2413), heff_dup(v_goal_242), heff_dup(v_ready_2422), heff_dup(v_x_2423)})}), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
    heff_clo_take(self, 6);
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam4, 1, 9, (V[]){v_x_2413, v_goal_242, v_ready_2422, v_x_2423, v_e_240, v_sp_241, v_x_248, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam2, 1, 6, (V[]){v_e_240, v_goal_242, v_sp_241, v_hd_244, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2erules_2emetaOfStx_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emetaOfStx_entry, 1, 0};

V g_heff_2eelab_2erules_2emetaOfStx(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SMetaApp: {
    V v_k_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_k_241);
  }
  default: {
    return MK_INT(-1LL);
  }
  }
}
V g_heff_2eelab_2erules_2emetaOfStx_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2emetaOfStx(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args);
V g_heff_2eelab_2erules_2echeckFields_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFields_entry, 5, 0};

V g_heff_2eelab_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_z_243);
    V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tail(v_z_244, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x31_246, 0);
      V v_g_249 = heff_field(v_x31_246, 1);
      V v_g_2410 = heff_dup(heff_rfield(v_e_240, 1));
      V v_c_2411 = heff_dup(heff_rfield(v_e_240, 0));
      V v_len_2412 = heff_take_field(v_c_2411, 0);
      V v_names_2413 = heff_get_n(v_c_2411, 1, 5);
      V v_a_2443;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VNeu: {
        V v_t_2419 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_241));
        V v_x1_2420 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2419, v_y_248));
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_Nom: {
          V v_x_2421 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_a_2443 = v_x_2421;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2420, 0ULL, 1);
          v_a_2443 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2423 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_a_2443 = v_x_2423;
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        break;
      }
      case TAG_VCode: {
        V v_t_2425 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_241));
        V v_x1_2426 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2425, v_y_248));
        switch (heff_tag_of(v_x1_2426)) {
        case TAG_Nom: {
          V v_x_2427 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_a_2443 = v_x_2427;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2426, 0ULL, 1);
          v_a_2443 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2429 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_a_2443 = v_x_2429;
          break;
        }
        default: heff_nomatch(v_x1_2426);
        }
        break;
      }
      case TAG_VLam: {
        V v_t_2432 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_241));
        V v_x1_2433 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2432, v_y_248));
        switch (heff_tag_of(v_x1_2433)) {
        case TAG_Nom: {
          V v_x_2434 = heff_field(v_x1_2433, 0);
          heff_take_n(v_x1_2433, 1ULL, 1);
          v_a_2443 = v_x_2434;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2433, 0ULL, 1);
          v_a_2443 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2436 = heff_field(v_x1_2433, 0);
          heff_take_n(v_x1_2433, 1ULL, 1);
          v_a_2443 = v_x_2436;
          break;
        }
        default: heff_nomatch(v_x1_2433);
        }
        break;
      }
      case TAG_VCons: {
        V v_t_2438 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_241));
        V v_x1_2439 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2438, v_y_248));
        switch (heff_tag_of(v_x1_2439)) {
        case TAG_Nom: {
          V v_x_2440 = heff_field(v_x1_2439, 0);
          heff_take_n(v_x1_2439, 1ULL, 1);
          v_a_2443 = v_x_2440;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2439, 0ULL, 1);
          v_a_2443 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2442 = heff_field(v_x1_2439, 0);
          heff_take_n(v_x1_2439, 1ULL, 1);
          v_a_2443 = v_x_2442;
          break;
        }
        default: heff_nomatch(v_x1_2439);
        }
        break;
      }
      case TAG_VOpaque: {
        v_a_2443 = NTAG(TAG_VOpaque);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam0, 2, 5, (V[]){v_g_2410, v_len_2412, v_names_2413, v_a_2443, heff_dup(v_g_249)}), heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam1, 3, 3, (V[]){v_e_240, heff_dup(v_v_241), heff_dup(v_rest_247)}), v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2echeckFields(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args) {
  V v_p_2444 = args[0];
  V v_p_2445 = args[1];
  V v_g_2410 = heff_env(self)[0];
  V v_len_2412 = heff_env(self)[1];
  V v_names_2413 = heff_env(self)[2];
  V v_a_2443 = heff_env(self)[3];
  V v_g_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_2410, heff_rec_n(2, shape_len__names, (V[]){v_len_2412, v_names_2413}), v_a_2443, v_g_249}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2446, v_p_2444, v_p_2445));
}
V g_heff_2eelab_2erules_2echeckFields_lam1(V self, V *args) {
  V v_r_2447 = args[0];
  V v_z_2448 = args[1];
  V v_z_2449 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  switch (heff_tag_of(v_r_2447)) {
  case TAG_Left: {
    V v_err_2450 = heff_field(v_r_2447, 0);
    heff_take_n(v_r_2447, 1ULL, 1);
    heff_drop(v_z_2448);
    heff_drop(self);
    V f_ = v_z_2449;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2450});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_r_2447, 0ULL, 1);
    heff_clo_take(self, 3);
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_rest_247; V a_3 = v_z_2448; V a_4 = v_z_2449; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_v_241); heff_drop(v_rest_247); r_; });
  }
  default: return heff_nomatch(v_r_2447);
  }
}
Clo g_heff_2eelab_2erules_2eheldOrNot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eheldOrNot_entry, 9, 0};

V g_heff_2eelab_2erules_2eheldOrNot(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_err_244, V v_mc_245, V v_otherwise_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 1, 5);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 3, 5);
  V v_t_2411 = ({ V a_0 = heff_dup(v_mc_245); V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2eheldInScope(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  HeffT2 v_t_2412 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_mc_245; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_t_2411; HeffT2 r_ = (g_heff_2eelab_2erules_2eheldGiven_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_245); heff_drop(v_t_2411); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_otherwise_246);
      V v_it1_2415 = v_field_2414;
      switch (heff_tag_of(v_it1_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_it1_2415, 0);
        V v_it12_2417 = heff_field(v_it1_2415, 1);
        heff_take_n(v_it1_2415, 3ULL, 2);
        switch (heff_tag_of(v_it12_2417)) {
        case TAG_MkPair: {
          V v_l_2418 = heff_field(v_it12_2417, 0);
          V v_t_2419 = heff_field(v_it12_2417, 1);
          heff_take_n(v_it12_2417, 3ULL, 2);
          V v_sc_2420 = heff_dup(heff_rfield(v_e_240, 0));
          V v_names_2421 = heff_take_field(v_sc_2420, 1);
          V v_len_2422 = heff_get_n(v_sc_2420, 0, 5);
          V v_t_2423 = heff_intSub(heff_intSub(v_len_2422, MK_INT(1LL)), v_l_2418);
          V v_t_2424 = ({ V a_0 = v_names_2421; V a_1 = v_t_2423; V r_ = (g_heff_2eelab_2erules_2enameAtGo(a_0, a_1)); heff_drop(v_names_2421); r_; });
          return (g_heff_2eelab_2erules_2eresourceEscapes(v_e_240, v_sp_241, v_t_2424, v_x_2416, v_t_2419, v_z_247, v_z_248));
        }
        default: return heff_nomatch(v_it12_2417);
        }
      }
      default: return heff_nomatch(v_it1_2415);
      }
    } else {
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_sp_241);
      heff_drop(v_field_2414);
      return heff_tail(v_otherwise_246, 2, (V[]){v_z_247, v_z_248});
    }
  }
}
V g_heff_2eelab_2erules_2eheldOrNot_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2eheldOrNot(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8]); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str9, 19, ", whose values are ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str10, 4, " to ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str11, 21, " is out of range for ");
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eintAtFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_entry, 5, 0};

V g_heff_2eelab_2erules_2eintAtFixed(V v_sp_240, V v_w_241, V v_i_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_w_241);
    heff_drop(v_t_245);
    float v_t_246 = (g_float32_2efromDecimal_w(heff_dup(v_i_242), MK_INT(0LL)));
    V v_t_247 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_intShow(v_i_242), heff_box_f64(((double)v_t_246))));
    return heff_tail(v_t_247, 2, (V[]){v_z_243, v_z_244});
  } else {
    heff_drop(v_t_245);
    V v_t_248 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
    if ((heff_intLe_c_lent(v_t_248, v_i_242, 0) && ({ V v_t_2421 = (g_heff_2eelab_2efixed_2efixedMax(v_w_241)); int c_ = heff_intLe_c_lent(v_i_242, v_t_2421, 0); heff_drop(v_t_2421); c_; }))) {
      heff_drop(v_sp_240);
      heff_drop_rec(v_z_243, 3);
      heff_drop(v_t_248);
      V v_t_2410 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_241, v_i_242}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_lam0_clo)});
      return heff_tail(v_z_244, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_t_248);
      V v_t_2411;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str0);
        break;
      }
      case TAG_I16: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str1);
        break;
      }
      case TAG_I32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str2);
        break;
      }
      case TAG_I64: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str3);
        break;
      }
      case TAG_U8: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str4);
        break;
      }
      case TAG_U16: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str5);
        break;
      }
      case TAG_U32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str6);
        break;
      }
      case TAG_U64: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str7);
        break;
      }
      case TAG_F32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str8);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_t_2412 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
      V v_t_2413 = ({ V a_0 = v_w_241; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_241); r_; });
      V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2eelab_2erules_2eintAtFixed_str9)), heff_intShow(v_t_2412));
      V v_why_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2eelab_2erules_2eintAtFixed_str10)), heff_intShow(v_t_2413));
      V v_t_2416 = heff_strAppend(heff_intShow(v_i_242), ((V)&g_heff_2eelab_2erules_2eintAtFixed_str11));
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_t_2416, v_why_2415), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_2419}));
      return heff_tail(heff_get_n(v_z_243, 1, 3), 2, (V[]){v_t_2420, v_z_244});
    }
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args) {
  V v_u_249 = args[0];
  heff_drop(v_u_249);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str0, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str1, 22, ", but got the literal ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str2, 11, ", which is ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str3, 8, "a number");
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_entry, 6, 0};

V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(V v_lit_240, V v_sp_241, V v_e_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_247 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_h_247)) {
    case TAG_HLocal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_lit_240);
    heff_drop(v_sp_241);
    heff_drop(v_e_242);
    heff_drop_rec(v_p_244, 3);
    heff_drop(v_t_2428);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam0, 1, 1, (V[]){v_a_243})});
    return heff_tail(v_p_245, 1, (V[]){v_t_2432});
  } else {
    heff_drop(v_t_2428);
    return (g_heff_2eelab_2erules_2etyStrZ(v_e_242, v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam2, 1, 4, (V[]){v_lit_240, v_sp_241, v_p_244, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam1(V self, V *args) {
  V v_u_2430 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_drop(v_u_2430);
  heff_clo_take(self, 1);
  return v_a_243;
}
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam0(V self, V *args) {
  V v_u_2429 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_drop(v_u_2429);
  heff_clo_take(self, 1);
  V v_t_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam1, 1, 1, (V[]){v_a_243}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2431});
}
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str0), v_x_2433), ((V)&g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str1));
  heff_clo_take(self, 4);
  V v_t_2435 = heff_strAppend(v_t_2434, heff_intShow(v_lit_240));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str2)), ((V)&g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_str3));
  V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2436, v_sp_241, NTAG(TAG_Nothing)});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2439}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2440;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitChk_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitChk_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitChk(V v_sp_240, V v_lit_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam0, 4, 2, (V[]){v_sp_240, v_lit_241})});
}
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitChk(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_lam3(V self, V *args) {
  V v_chk_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k2_2437 = args[2];
  V v_x_2410 = heff_env(self)[0];
  V v_t_2438 = heff_tr(heff_call(v_chk_2435, 2, (V[]){heff_dup(v_hd_2436), heff_dup(heff_rfield(v_hd_2436, 0))}));
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2410, v_t_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2440}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2441;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_2433;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_t1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_t_2433);
    heff_clo_take(self, 5);
    V v_c_2434 = (g_heff_2eelab_2erules_2enumLitWait(MK_INT(1LL), heff_dup(v_sp_240), v_lit_241));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam3, 3, 1, (V[]){heff_dup(v_x_2410)}); V a_1 = v_e_242; V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitChk_str0); V a_4 = v_c_2434; V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2434); r_; });
  } else {
    heff_drop(v_t_2433);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_240, v_e_242, v_x_2410, v_lit_241, v_hd_244, v_k_245));
  }
}
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam2, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str0, 15, "expected value ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str1, 16, ", but got value ");
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args);
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_entry, 6, 0};

V g_heff_2eelab_2erules_2echeckFixed(V v_e_240, V v_sp_241, V v_v_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  V v_globals_246 = heff_take_field(v_e_240, 1);
  V v_scope_247 = heff_get_n(v_e_240, 0, 8);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_p_244);
    heff_drop(v_globals_246);
    heff_drop(v_scope_247);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_expected_248 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_g_249 = heff_dup(v_globals_246);
    V v_c_2410 = heff_dup(v_scope_247);
    V v_len_2411 = heff_take_field(v_c_2410, 0);
    V v_names_2412 = heff_get_n(v_c_2410, 1, 5);
    return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam0, 2, 5, (V[]){v_g_249, v_len_2411, v_names_2412, heff_dup(v_v_242), heff_dup(v_expected_248)}), heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam1, 3, 5, (V[]){v_scope_247, v_globals_246, v_expected_248, v_v_242, v_sp_241}), v_p_244, v_p_245));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckFixed(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_p_2414 = args[1];
  V v_g_249 = heff_env(self)[0];
  V v_len_2411 = heff_env(self)[1];
  V v_names_2412 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_expected_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_249, heff_rec_n(2, shape_len__names, (V[]){v_len_2411, v_names_2412}), v_v_242, v_expected_248}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2415, v_p_2413, v_p_2414));
}
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args) {
  V v_r_2416 = args[0];
  V v_z_2417 = args[1];
  V v_z_2418 = args[2];
  V v_scope_247 = heff_env(self)[0];
  V v_globals_246 = heff_env(self)[1];
  V v_expected_248 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_malg_2419 = heff_take_field(v_z_2417, 2);
  V v_bind_2420 = heff_get_n(v_z_2417, 1, 3);
  switch (heff_tag_of(v_r_2416)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_r_2416, 0);
    V v_ru_24r_2416_24Left = heff_take_reuse_n(v_r_2416, 1ULL, 1);
    V v_c_2422 = heff_dup(v_scope_247);
    V v_len_2423 = heff_take_field(v_c_2422, 0);
    V v_names_2424 = heff_get_n(v_c_2422, 1, 5);
    heff_clo_take(self, 5);
    V v_t_2425 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_globals_246), heff_rec_n(2, shape_len__names, (V[]){v_len_2423, v_names_2424}), v_expected_248));
    V v_c_2426 = v_scope_247;
    V v_len_2427 = heff_take_field(v_c_2426, 0);
    V v_names_2428 = heff_get_n(v_c_2426, 1, 5);
    V v_t_2429 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_globals_246), heff_rec_n(2, shape_len__names, (V[]){v_len_2427, v_names_2428}), v_v_242));
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str0), v_t_2425), ((V)&g_heff_2eelab_2erules_2echeckFixed_str1));
    V v_msg_2431 = heff_strAppend(v_t_2430, v_t_2429);
    V v_note_2432 = ({ V a_0 = v_globals_246; V a_1 = v_err_2421; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2421); r_; });
    V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2431, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2432})});
    V v_t_2434 = heff_tag_at_n(v_ru_24r_2416_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(v_malg_2419, 1, (V[]){v_t_2435}));
    V f_ = v_bind_2420;
    args[0] = v_t_2436;
    args[1] = v_z_2418;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    heff_take_n(v_r_2416, 0ULL, 1);
    heff_drop(self);
    heff_drop(v_malg_2419);
    heff_drop(v_bind_2420);
    V f_ = v_z_2418;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_r_2416);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_24acc_entry, 2, 0};

V g_heff_2eelab_2erules_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2erules_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2eelab_2erules_2eandList_24acc_str1));
          return heff_strAppend(v_t_248, heff_dup(v_y_246));
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2eelab_2erules_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2411;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str0, 21, "missing record field ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str1, 22, "expected record field ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str2, 6, " got: ");
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enotGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotGiven_entry, 3, 0};

V g_heff_2eelab_2erules_2enotGiven(V v_it_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_note_243 = (g_heff_2eelab_2erules_2efieldsNote(heff_dup(v_it_240)));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam0, 2, 3, (V[]){v_x_241, v_it_240, v_note_243});
  }
  case TAG_Cons: {
    V v_fs_2412 = heff_field(v_x3_242, 0);
    V v_name_2414 = heff_dup(heff_rfield(v_fs_2412, 0));
    V v_span_2415 = heff_dup(heff_rfield(v_fs_2412, 2));
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str1), v_x_241), ((V)&g_heff_2eelab_2erules_2enotGiven_str2));
    V v_msg_2417 = heff_strAppend(v_t_2416, v_name_2414);
    V v_note_2418 = (g_heff_2eelab_2erules_2efieldsNote(v_it_240));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam1, 2, 3, (V[]){v_msg_2417, v_span_2415, v_note_2418});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enotGiven(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_it_240 = heff_env(self)[1];
  V v_note_243 = heff_env(self)[2];
  V v_malg_246 = heff_take_field(v_hd_244, 2);
  V v_bind_247 = heff_get_n(v_hd_244, 1, 3);
  heff_clo_take(self, 3);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str0), v_x_241), heff_get_n(v_it_240, 0, 5), heff_tag_n(TAG_Just, 1, (V[]){v_note_243})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2410}));
  V f_ = v_bind_247;
  args[0] = v_t_2411;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_msg_2417 = heff_env(self)[0];
  V v_span_2415 = heff_env(self)[1];
  V v_note_2418 = heff_env(self)[2];
  V v_malg_2421 = heff_take_field(v_hd_2419, 2);
  V v_bind_2422 = heff_get_n(v_hd_2419, 1, 3);
  heff_clo_take(self, 3);
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), v_msg_2417, v_span_2415, heff_tag_n(TAG_Just, 1, (V[]){v_note_2418})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2421, 1, (V[]){v_t_2425}));
  V f_ = v_bind_2422;
  args[0] = v_t_2426;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eboundGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eboundGo(V v_all_240, V v_x2_241, V v_box_24j_242) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_245 = (g_list_2edrop(heff_box_word((v_j_242 + ((int64_t)1ULL))), v_all_240));
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_box_word((v_j_242 + ((int64_t)1ULL))); V a_2 = heff_box_word(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2erules_2eboundGo_24dps(v_all_240, v_rest_244, heff_box_word((v_j_242 + ((int64_t)1ULL))), v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eboundGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_lam7, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_lam8, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_lam10, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_lam11(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_lam11, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_lam12(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2esumFormation(V v_vs_240) {
top: ;
  V v_keys_241 = heff_take_field(v_vs_240, 0);
  V v_values_242 = heff_get_n(v_vs_240, 2, 3);
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam0, 1, 2, (V[]){v_keys_241, v_values_242})});
}
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation(a[0]);
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args) {
  V v_t_2415 = args[0];
  V v_globals_244 = heff_env(self)[0];
  V v_lams_245 = heff_env(self)[1];
  V v_self_246 = heff_env(self)[2];
  V v_insts_247 = heff_env(self)[3];
  V v_named_248 = heff_env(self)[4];
  V v_evidence_249 = heff_env(self)[5];
  V v_scope_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = v_globals_244;
  V v_t_2417 = v_lams_245;
  V v_t_2418 = v_self_246;
  V v_t_2419 = v_insts_247;
  V v_t_2420 = v_named_248;
  V v_t_2421 = v_evidence_249;
  V v_sd_2422 = v_scope_2410;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_MkSmallTyp: {
    V v_f_2423 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24MkSmallTyp = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24t_2415_24MkSmallTyp, TAG_CUndelay, 1, (V[]){heff_dup(heff_rfield(v_sd_2422, 3))});
    V v_t_2425 = ({ V rv_3 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_sd_2422, 23ULL, 5, shape_len__names__locals__ctx__matched, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2426 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){v_t_2425, v_t_2416, NTAG(TAG_ForNominative), v_t_2417, v_t_2418, v_t_2419, v_t_2420, v_t_2421});
    V f_ = v_f_2423;
    args[0] = v_t_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_k_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2413, heff_arrayFromList(v_x_2430)});
  V f_ = v_k_2429;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam4, 1, 2, (V[]){v_k_2413, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args) {
  V v_p_2412 = args[0];
  V v_globals_244 = heff_env(self)[0];
  V v_lams_245 = heff_env(self)[1];
  V v_self_246 = heff_env(self)[2];
  V v_insts_247 = heff_env(self)[3];
  V v_named_248 = heff_env(self)[4];
  V v_evidence_249 = heff_env(self)[5];
  V v_scope_2410 = heff_env(self)[6];
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_k_2413 = heff_field(v_p_2412, 0);
    V v_ts_2414 = heff_field(v_p_2412, 1);
    heff_take_n(v_p_2412, 3ULL, 2);
    heff_clo_take(self, 7);
    V v_c_2427 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam2, 1, 7, (V[]){v_globals_244, v_lams_245, v_self_246, v_insts_247, v_named_248, v_evidence_249, v_scope_2410}), heff_arrayToList(v_ts_2414)));
    return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam3, 2, 2, (V[]){v_c_2427, v_k_2413});
  }
  default: return heff_nomatch(v_p_2412);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam7(V self, V *args) {
  V v_u_2442 = args[0];
  heff_drop(v_u_2442);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_lam8(V self, V *args) {
  V v_u_2445 = args[0];
  heff_drop(v_u_2445);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_lam10(V self, V *args) {
  V v_u_2457 = args[0];
  heff_drop(v_u_2457);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_lam11(V self, V *args) {
  V v_u_2460 = args[0];
  heff_drop(v_u_2460);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_lam12(V self, V *args) {
  V v_u2_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  heff_drop(v_u2_2462);
  heff_clo_take(self, 1);
  V v_x1_2463 = heff_tr(heff_call(heff_get_n(v_m_2461, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_Nom: {
    V v_x_2464 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2464;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2466 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2466;
  }
  default: return heff_nomatch(v_x1_2463);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam9(V self, V *args) {
  V v_u_2453 = args[0];
  V v_st_2439 = heff_env(self)[0];
  heff_drop(v_u_2453);
  heff_clo_take(self, 1);
  V v_vs_2454 = v_st_2439;
  V v_xs_2455 = heff_take_field(v_vs_2454, 2);
  V v_m_2456 = heff_arrayLength_lent(v_xs_2455, 0);
  V v_t_2471;
  if ((heff_peek_word(v_m_2456) <= ((int64_t)0ULL))) {
    heff_drop(v_xs_2455);
    v_t_2471 = heff_arrayGenerate(v_m_2456, ((V)&g_heff_2eelab_2erules_2esumFormation_lam10_clo));
  } else {
    V v_xs_2458 = heff_arrayIndex_lent(v_xs_2455, MK_INT(0LL), 2);
    V v_m_2459 = heff_arrayLength_lent(v_xs_2458, 0);
    V v_y_2469;
    if ((heff_peek_word(v_m_2459) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2458);
      v_y_2469 = heff_arrayGenerate(v_m_2459, ((V)&g_heff_2eelab_2erules_2esumFormation_lam11_clo));
    } else {
      V v_m_2461 = heff_arrayIndex_lent(v_xs_2458, MK_INT(0LL), 2);
      V v_y_2467 = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam12, 1, 1, (V[]){v_m_2461});
      V v_t_2468 = heff_arrayKeepsAs_lent(v_xs_2458, v_y_2467, 0);
      if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
        heff_drop(v_m_2459);
        heff_drop(v_t_2468);
        v_y_2469 = (g_heff_2eelab_2erules_2esumFormation_24map2(MK_INT(1LL), heff_arraySet(v_xs_2458, MK_INT(0LL), v_y_2467)));
      } else {
        heff_drop(v_t_2468);
        v_y_2469 = ({ V a_0 = v_xs_2458; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2459, v_y_2467); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate2(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
      }
    }
    V v_t_2470 = heff_arrayKeepsAs_lent(v_xs_2455, v_y_2469, 0);
    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
      heff_drop(v_m_2456);
      heff_drop(v_t_2470);
      v_t_2471 = (g_heff_2eelab_2erules_2esumFormation_24map3(MK_INT(1LL), heff_arraySet(v_xs_2455, MK_INT(0LL), v_y_2469)));
    } else {
      heff_drop(v_t_2470);
      v_t_2471 = ({ V a_0 = v_xs_2455; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2456, v_y_2469); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate3(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
    }
  }
  V v_t_2472 = ({ V rv_2 = v_t_2471; V rr_ = heff_rec_reuse_nf(v_vs_2454, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_2472})});
}
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_t_2436 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2435)));
  V v_t_2437 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2435));
  V v_t_2438 = (g_list_2emap_24s1173914895x100384474(v_x_2435));
  V v_st_2439 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2436), v_t_2437, heff_arrayFromList(v_t_2438)});
  V v_xs_2440 = heff_dup(heff_rfield(v_st_2439, 2));
  V v_m_2441 = heff_arrayLength_lent(v_xs_2440, 0);
  V v_t_2451;
  if ((heff_peek_word(v_m_2441) <= ((int64_t)0ULL))) {
    heff_drop(v_xs_2440);
    v_t_2451 = heff_arrayGenerate(v_m_2441, ((V)&g_heff_2eelab_2erules_2esumFormation_lam7_clo));
  } else {
    V v_xs_2443 = heff_arrayIndex_lent(v_xs_2440, MK_INT(0LL), 2);
    V v_m_2444 = heff_arrayLength_lent(v_xs_2443, 0);
    V v_y_2449;
    if ((heff_peek_word(v_m_2444) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2443);
      v_y_2449 = heff_arrayGenerate(v_m_2444, ((V)&g_heff_2eelab_2erules_2esumFormation_lam8_clo));
    } else {
      V v_m_2446 = heff_arrayIndex_lent(v_xs_2443, MK_INT(0LL), 2);
      V v_y_2447 = heff_get_n(v_m_2446, 0, 2);
      V v_t_2448 = heff_arrayKeepsAs_lent(v_xs_2443, v_y_2447, 0);
      if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
        heff_drop(v_m_2444);
        heff_drop(v_t_2448);
        v_y_2449 = (g_heff_2eelab_2erules_2esumFormation_24map0(MK_INT(1LL), heff_arraySet(v_xs_2443, MK_INT(0LL), v_y_2447)));
      } else {
        heff_drop(v_t_2448);
        v_y_2449 = ({ V a_0 = v_xs_2443; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2444, v_y_2447); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
      }
    }
    V v_t_2450 = heff_arrayKeepsAs_lent(v_xs_2440, v_y_2449, 0);
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_m_2441);
      heff_drop(v_t_2450);
      v_t_2451 = (g_heff_2eelab_2erules_2esumFormation_24map1(MK_INT(1LL), heff_arraySet(v_xs_2440, MK_INT(0LL), v_y_2449)));
    } else {
      heff_drop(v_t_2450);
      v_t_2451 = ({ V a_0 = v_xs_2440; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2441, v_y_2449); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate1(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
    }
  }
  V v_t_2452 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_st_2439, 0)), heff_dup(heff_rfield(v_st_2439, 1)), v_t_2451});
  V v_x_2473 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_t_2452}), heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam9, 1, 1, (V[]){v_st_2439})});
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2432;
  args[0] = v_hd_2433;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam6, 1, 1, (V[]){v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_keys_241 = heff_env(self)[0];
  V v_values_242 = heff_env(self)[1];
  V v_globals_244 = heff_take_field(v_e_243, 1);
  V v_lams_245 = heff_take_field(v_e_243, 3);
  V v_self_246 = heff_take_field(v_e_243, 4);
  V v_insts_247 = heff_take_field(v_e_243, 5);
  V v_named_248 = heff_take_field(v_e_243, 6);
  V v_evidence_249 = heff_take_field(v_e_243, 7);
  V v_scope_2410 = heff_get_n(v_e_243, 0, 8);
  heff_clo_take(self, 2);
  V v_t_2411 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_241), heff_arrayToList(v_values_242)));
  V v_c_2432 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam1, 1, 7, (V[]){v_globals_244, v_lams_245, v_self_246, v_insts_247, v_named_248, v_evidence_249, v_scope_2410}), v_t_2411));
  return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam5, 2, 1, (V[]){v_c_2432});
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam0, 2, 0};
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam1, 2, 0};
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_entry, 5, 0};

V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(V v_lit_240, V v_sc_241, V v_p_242, V v_what_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_sc_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_what_243);
    return ((V)&g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam0_clo);
  }
  case TAG_Just: {
    V v_at_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_sc_241, 4)), 1, 2);
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_list_2eany_24s2135465121x1956745568(a_0)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_sc_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_what_243);
      heff_drop(v_at_247);
      heff_drop(v_t_249);
      return ((V)&g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam1_clo);
    } else {
      heff_drop(v_t_249);
      switch (heff_tag_of(v_p_242)) {
      case TAG_Nothing: {
        heff_drop_rec(v_sc_241, 5);
        heff_drop(v_what_243);
        return heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam2, 2, 1, (V[]){v_at_247});
      }
      case TAG_Just: {
        V v_p_2425 = heff_field(v_p_242, 0);
        heff_take_n(v_p_242, 1ULL, 1);
        V v_t_2426 = heff_get_n(heff_get_n(v_sc_241, 4, 5), 1, 2);
        V v_x3_2427 = ({ V a_0 = v_t_2426; V a_1 = v_p_2425; V a_2 = v_lit_240; V a_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2eelab_2eenvironment_2eruledOutAt(a_0, a_1, a_2, a_3)); heff_drop(v_t_2426); r_; });
        return heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam5, 2, 3, (V[]){v_x3_2427, v_at_247, v_what_243});
      }
      default: return heff_nomatch(v_p_242);
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam3(V self, V *args) {
  V v_c_2416 = args[0];
  V v_at_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ArmTaken, 1, (V[]){v_at_247}), heff_take_field(v_c_2416, 8)});
  return ({ V rv_8 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_c_2416, 255ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_malg_2414 = heff_env(self)[0];
  V v_bind_2415 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_t_2422 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  heff_clo_take(self, 3);
  V v_t_2424 = heff_tr(heff_call(v_malg_2414, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})}));
  V f_ = v_bind_2415;
  heff_room[0] = v_t_2424;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_at_247 = heff_env(self)[0];
  V v_malg_2414 = heff_take_field(v_hd_2412, 2);
  V v_bind_2415 = heff_get_n(v_hd_2412, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam3, 1, 1, (V[]){v_at_247})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_malg_2414), 1, (V[]){v_t_2419}));
  V f_ = heff_dup(v_bind_2415);
  args[0] = v_t_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam4, 1, 3, (V[]){v_malg_2414, v_bind_2415, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam6(V self, V *args) {
  V v_c_2432 = args[0];
  V v_x3_2427 = heff_env(self)[0];
  V v_at_247 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  V v_t_2434;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x3_2427)) {
  case TAG_Nothing: {
    heff_drop(v_what_243);
    v_t_2434 = heff_tag_n(TAG_ArmTaken, 1, (V[]){v_at_247});
    break;
  }
  case TAG_Just: {
    V v_by_2433 = heff_field(v_x3_2427, 0);
    heff_take_n(v_x3_2427, 1ULL, 1);
    v_t_2434 = heff_tag_n(TAG_ArmRuledOut, 3, (V[]){v_at_247, v_by_2433, v_what_243});
    break;
  }
  default: heff_nomatch(v_x3_2427);
  }
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_take_field(v_c_2432, 8)});
  return ({ V rv_8 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_c_2432, 255ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_malg_2430 = heff_env(self)[0];
  V v_bind_2431 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  V v_t_2440 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  heff_clo_take(self, 3);
  V v_t_2442 = heff_tr(heff_call(v_malg_2430, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})}));
  V f_ = v_bind_2431;
  heff_room[0] = v_t_2442;
  heff_room[1] = v_k_2429;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x3_2427 = heff_env(self)[0];
  V v_at_247 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  V v_malg_2430 = heff_take_field(v_hd_2428, 2);
  V v_bind_2431 = heff_get_n(v_hd_2428, 1, 3);
  heff_clo_take(self, 3);
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam6, 1, 3, (V[]){v_x3_2427, v_at_247, v_what_243})})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(v_malg_2430), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(v_bind_2431);
  args[0] = v_t_2438;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_lam7, 1, 3, (V[]){v_malg_2430, v_bind_2431, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str0, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str1, 13, " is set twice");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str2, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str3, 13, " is set twice");
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args);
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2egivenTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egivenTwice_entry, 2, 0};

V g_heff_2eelab_2erules_2egivenTwice(V v_fs_240, V v_x_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s924780574x2000457388(v_x_241, v_fs_240));
  HeffT3 v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_f_247 = v_field_245;
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam0, 2, 2, (V[]){v_f_247, v_x_241});
    } else {
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam1, 2, 1, (V[]){v_x_241});
    }
  }
}
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2egivenTwice(a[0], a[1]);
}
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_f_247 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_malg_2411 = heff_take_field(v_hd_249, 2);
  V v_bind_2412 = heff_get_n(v_hd_249, 1, 3);
  V v_t_2421;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_247)) {
  case TAG_UpdateTo: {
    V v_sp_2415 = heff_field(v_f_247, 2);
    heff_take_n(v_f_247, 4ULL, 4);
    v_t_2421 = v_sp_2415;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2419 = heff_field(v_f_247, 2);
    heff_take_n(v_f_247, 4ULL, 4);
    v_t_2421 = v_sp_2419;
    break;
  }
  default: heff_nomatch(v_f_247);
  }
  V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str0), v_x_241), ((V)&g_heff_2eelab_2erules_2egivenTwice_str1));
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2422, v_t_2421, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2411, 1, (V[]){v_t_2425}));
  V f_ = v_bind_2412;
  args[0] = v_t_2426;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_malg_2429 = heff_take_field(v_hd_2427, 2);
  V v_bind_2430 = heff_get_n(v_hd_2427, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str2), v_x_241), ((V)&g_heff_2eelab_2erules_2egivenTwice_str3));
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2431, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(v_malg_2429, 1, (V[]){v_t_2434}));
  V f_ = v_bind_2430;
  args[0] = v_t_2435;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str0, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str1, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str3, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str4, 15, "the fields are ");
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_lam0, 2, 0};
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enoSuchSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_entry, 4, 0};

V g_heff_2eelab_2erules_2enoSuchSetting(V v_e_240, V v_a_241, V v_keys_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    return ((V)&g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_t_248 = (g_list_2eany_24s1082941870x132941142(v_f_246, v_keys_242));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V t_0 = v_e_240;
      V t_1 = v_a_241;
      V t_2 = v_keys_242;
      V t_3 = v_rest_247;
      v_e_240 = t_0;
      v_a_241 = t_1;
      v_keys_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_248);
      V v_t_2417;
      switch (heff_tag_of(v_f_246)) {
      case TAG_UpdateTo: {
        V v_x_249 = heff_field(v_f_246, 0);
        v_t_2417 = heff_dup(v_x_249);
        break;
      }
      case TAG_UpdateIn: {
        V v_x_2413 = heff_field(v_f_246, 0);
        v_t_2417 = heff_dup(v_x_2413);
        break;
      }
      default: heff_nomatch(v_f_246);
      }
      V v_t_2418 = (g_heff_2eelab_2erules_2etyStr(v_e_240, v_a_241));
      V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str0), v_t_2417), ((V)&g_heff_2eelab_2erules_2enoSuchSetting_str1));
      V v_msg_2420 = heff_strAppend(v_t_2419, v_t_2418);
      V v_t_2423;
      switch (heff_tag_of(v_keys_242)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2eelab_2erules_2enoSuchSetting_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_keys_242, 0);
        V v_xs_2422 = heff_field(v_keys_242, 1);
        v_t_2423 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str3), heff_dup(v_x_2421), v_xs_2422));
        break;
      }
      default: heff_nomatch(v_keys_242);
      }
      V v_note_2424 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str4), v_t_2423);
      return heff_clo_n(g_heff_2eelab_2erules_2enoSuchSetting_lam1, 2, 3, (V[]){heff_dup(v_f_246), v_msg_2420, v_note_2424});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2enoSuchSetting(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_f_246 = heff_env(self)[0];
  V v_msg_2420 = heff_env(self)[1];
  V v_note_2424 = heff_env(self)[2];
  V v_malg_2427 = heff_take_field(v_hd_2425, 2);
  V v_bind_2428 = heff_get_n(v_hd_2425, 1, 3);
  V v_t_2437;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_f_246)) {
  case TAG_UpdateTo: {
    V v_sp_2431 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2437 = v_sp_2431;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2435 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2437 = v_sp_2435;
    break;
  }
  default: heff_nomatch(v_f_246);
  }
  V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2420, v_t_2437, heff_tag_n(TAG_Just, 1, (V[]){v_note_2424})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(v_malg_2427, 1, (V[]){v_t_2440}));
  V f_ = v_bind_2428;
  args[0] = v_t_2441;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str0, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleSyn_str1, 6, "MkPair");
V g_heff_2eelab_2erules_2etupleSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etupleSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etupleSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etupleSyn_entry, 4, 0};

V g_heff_2eelab_2erules_2etupleSyn(V v_sp_240, V v_s_241, V v_rest_242, V v_p_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_rest_242, heff_dup(v_p_243)})});
}
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2etupleSyn(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2etupleSyn_lam3(V self, V *args) {
  V v_c_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_t_2413;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 2ULL, 2);
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2etupleSyn_lam5(V self, V *args) {
  V v_e2_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_drop(v_e2_2421);
  heff_drop(v_hd_2422);
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam6(V self, V *args) {
  V v_e2_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  V v_x_249 = heff_env(self)[0];
  heff_drop(v_e2_2429);
  heff_drop(v_hd_2430);
  heff_clo_take(self, 1);
  V f_ = v_k_2431;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_t_2418 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2417));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_LikeU: {
    V v_ru_24t_2418_24LikeU = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_p_243);
    V v_t_2420 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2etupleSyn_str0)));
    V v_t_2424 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2418_24LikeU, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam5, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_callee_2425 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = heff_dup(v_sp_240); V a_3 = v_t_2420; V a_4 = v_t_2424; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_t_2420); r_; });
    HeffT1 v_t_2426 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = v_sp_240; V a_3 = v_callee_2425; V a_4 = v_rest_242; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_2425); r_; });
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_f_2428 = v_field_2427;
      V f_ = v_f_2428;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  default: {
    heff_drop(v_t_2418);
    heff_clo_take(self, 7);
    V v_t_2432 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam6, 3, 1, (V[]){v_x_249})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_242, NTAG(TAG_Nil)});
    V v_t_2434 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_240); V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2etupleSyn_str1); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2433}); V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT1 v_t_2435 = ({ V a_0 = v_p_243; V a_1 = v_t_2434; HeffT1 r_ = (g_heff_2eelab_2erules_2eannot_24cpr(a_0, a_1)); heff_drop(v_p_243); heff_drop(v_t_2434); r_; });
    {
      V v_field_2436 = v_t_2435.f[0];
      V v_f_2437 = v_field_2436;
      V f_ = v_f_2437;
      heff_room[0] = v_e_244;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  }
}
V g_heff_2eelab_2erules_2etupleSyn_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam3, 1, 1, (V[]){heff_dup(v_x_249)})})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2415}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam4, 1, 7, (V[]){v_sp_240, v_x_249, v_rest_242, v_e_244, v_hd_247, v_k_248, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etupleSyn_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam2, 1, 6, (V[]){v_hd_247, v_sp_240, v_rest_242, v_e_244, v_k_248, v_p_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2etupleSyn_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_c_246;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2etupleSyn_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_rest_242, v_e_244, v_p_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str0, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str1, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str2, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str3, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str4, 4, "int8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str5, 5, "int16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str6, 5, "int32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str7, 5, "int64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str8, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str9, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str10, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str11, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str12, 7, "float32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str13, 2, "Eq");
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitEq_entry, 5, 0};

V g_heff_2eelab_2erules_2elitEq(V v_sp_240, V v_x_241, V v_xsp_242, V v_eq_243, V v_lit_244) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam0, 1, 5, (V[]){v_x_241, v_xsp_242, v_eq_243, v_sp_240, v_lit_244})});
}
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elitEq(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args) {
  V v_c_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_t_2419;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_x_2415, 1);
    heff_take_n(v_x_2415, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  return ({ V b_0 = heff_get_n(v_c_2416, 3, 9); V a_1 = v_t_2419; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args) {
  V v_e2_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  V v_x_2415 = heff_env(self)[0];
  heff_drop(v_e2_2439);
  heff_drop(v_hd_2440);
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_eq_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_xsp_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2423));
  V v_t_2437;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2437 = v_eq_243;
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2424, 0ULL, 4);
    v_t_2437 = v_eq_243;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_t_2437 = v_eq_243;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2437 = v_eq_243;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_eq_243);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2elitEq_str0);
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_eq_243);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2elitEq_str1);
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_eq_243);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2elitEq_str2);
    break;
  }
  case TAG_LikeRune: {
    heff_drop(v_eq_243);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2elitEq_str3);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2437 = v_eq_243;
    break;
  }
  case TAG_LikeFixed: {
    V v_w_2435 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    heff_drop(v_eq_243);
    V v_t_2436;
    switch (heff_tag_of(v_w_2435)) {
    case TAG_I8: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str4);
      break;
    }
    case TAG_I16: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str5);
      break;
    }
    case TAG_I32: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str6);
      break;
    }
    case TAG_I64: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str7);
      break;
    }
    case TAG_U8: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str8);
      break;
    }
    case TAG_U16: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str9);
      break;
    }
    case TAG_U32: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str10);
      break;
    }
    case TAG_U64: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str11);
      break;
    }
    case TAG_F32: {
      v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str12);
      break;
    }
    default: heff_nomatch(v_w_2435);
    }
    v_t_2437 = heff_strAppend(v_t_2436, ((V)&g_heff_2eelab_2erules_2elitEq_str13));
    break;
  }
  case TAG_NoRules: {
    v_t_2437 = v_eq_243;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_callee_2438 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), v_t_2437));
  V v_t_2442 = ({ V a_0 = v_xsp_242; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam5, 3, 1, (V[]){v_x_2415})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
  V v_callee_2443 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = heff_dup(v_sp_240); V a_3 = v_callee_2438; V a_4 = v_t_2442; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_2438); r_; });
  HeffT1 v_t_2444 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = v_sp_240; V a_3 = v_callee_2443; V a_4 = v_lit_244; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_2443); r_; });
  {
    V v_field_2445 = v_t_2444.f[0];
    V v_f_2446 = v_field_2445;
    V f_ = v_f_2446;
    heff_room[0] = v_e_245;
    heff_room[1] = v_hd_2413;
    heff_room[2] = v_k_2414;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam3, 1, 1, (V[]){heff_dup(v_x_2415)})})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2413, 2)), 1, (V[]){v_t_2421}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_2413, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam4, 1, 8, (V[]){v_eq_243, v_sp_240, v_xsp_242, v_x_2415, v_lit_244, v_e_245, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam2, 1, 7, (V[]){v_hd_2413, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_xsp_242 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_245, 1)), 6, 8);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_x_241; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_heff_2eelab_2erules_2eunboundIn(heff_dup(v_xsp_242), heff_dup(v_x_241), v_t_247));
  heff_clo_take(self, 5);
  HeffT1 v_t_249 = (g_heff_2eelab_2erules_2efindOr_24cpr(heff_dup(v_xsp_242), v_x_241, v_t_248));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_f_2411 = v_field_2410;
    V v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_245)}));
    return heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam1, 2, 6, (V[]){v_c_2412, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2elocalNamed_str0, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2elocalNamed_str1, 9, " in scope");
V g_heff_2eelab_2erules_2elocalNamed_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elocalNamed_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elocalNamed_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elocalNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalNamed_entry, 2, 0};

V g_heff_2eelab_2erules_2elocalNamed(V v_sp_240, V v_x_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elocalNamed_lam0, 1, 2, (V[]){v_x_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2elocalNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elocalNamed(a[0], a[1]);
}
V g_heff_2eelab_2erules_2elocalNamed_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_malg_2413 = heff_take_field(v_hd_2411, 2);
  V v_bind_2414 = heff_get_n(v_hd_2411, 1, 3);
  heff_clo_take(self, 2);
  V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2elocalNamed_str0), v_x_241), ((V)&g_heff_2eelab_2erules_2elocalNamed_str1));
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2415, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2413, 1, (V[]){v_t_2418}));
  V f_ = v_bind_2414;
  args[0] = v_t_2419;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elocalNamed_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_found_2420 = heff_env(self)[0];
  heff_drop(v_hd_2421);
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = v_found_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elocalNamed_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 5);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 3, 5);
  V v_t_245 = heff_get_n(heff_get_n(v_e_242, 0, 8), 2, 5);
  HeffT3 v_t_246 = ({ V a_0 = v_x_241; V a_1 = v_t_243; V a_2 = v_t_244; V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT3 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_243); heff_drop(v_t_244); heff_drop(v_t_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    V v_field_249 = v_t_246.f[2];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_field_249);
      V v_x_2410 = v_field_248;
      heff_drop(v_x_2410);
      heff_clo_take(self, 2);
      return heff_clo_n(g_heff_2eelab_2erules_2elocalNamed_lam1, 2, 2, (V[]){v_x_241, v_sp_240});
    } else {
      heff_drop(self);
      V v_found_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){v_field_248, v_field_249});
      return heff_clo_n(g_heff_2eelab_2erules_2elocalNamed_lam2, 2, 1, (V[]){v_found_2420});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam5, 1, 0};
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(V v_lit_240, V v_n_241, V v_sp_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam0, 4, 3, (V[]){v_lit_240, v_sp_242, v_n_241})});
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 9); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam3(V self, V *args) {
  V v_chk_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k2_2438 = args[2];
  V v_x_2411 = heff_env(self)[0];
  V v_t_2439 = heff_tr(heff_call(v_chk_2436, 2, (V[]){heff_dup(v_hd_2437), heff_dup(heff_rfield(v_hd_2437, 0))}));
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2411, v_t_2439, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_2437, 2), 1, (V[]){v_t_2441}));
  V f_ = heff_get_n(v_hd_2437, 1, 3);
  args[0] = v_t_2442;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam5(V self, V *args) {
  V v_u_2446 = args[0];
  heff_drop(v_u_2446);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam4(V self, V *args) {
  V v_e_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_e_2443);
  heff_drop(v_hd_2444);
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_lit_240}), ((V)&g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam5_clo)});
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, NTAG(TAG_VPrimInt)});
  V f_ = v_k_2445;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_241 = heff_env(self)[5];
  V v_t_2434;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_clo_take(self, 6);
    heff_drop(v_n_241);
    heff_drop(v_t_2434);
    return (g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(v_lit_240, v_sp_242, v_e_243, v_x_2411, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2434);
    heff_clo_take(self, 6);
    if ((((int64_t)0ULL) < heff_peek_word(v_n_241))) {
      V v_c_2435 = (g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(v_lit_240, heff_box_word((heff_unbox_word(v_n_241) - ((int64_t)1ULL))), heff_dup(v_sp_242)));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam3, 3, 1, (V[]){heff_dup(v_x_2411)}); V a_1 = v_e_243; V a_2 = v_sp_242; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_str0); V a_4 = v_c_2435; V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2435); r_; });
    } else {
      heff_drop(v_n_241);
      HeffT1 v_t_2449 = ({ V a_0 = v_sp_242; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam4, 3, 1, (V[]){v_lit_240})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_f_2451 = v_field_2450;
        V f_ = v_f_2451;
        heff_room[0] = v_e_243;
        heff_room[1] = v_x_2411;
        heff_room[2] = v_hd_245;
        heff_room[3] = v_k_246;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_lam2, 1, 6, (V[]){v_lit_240, v_sp_242, v_e_243, v_hd_245, v_k_246, v_n_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229(V v_lit_240, V v_n_241, V v_sp_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam0, 4, 3, (V[]){v_lit_240, v_sp_242, v_n_241})});
}
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 9); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_241 = heff_env(self)[5];
  V v_t_2434;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_clo_take(self, 6);
    heff_drop(v_n_241);
    heff_drop(v_t_2434);
    return (g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(v_lit_240, v_sp_242, v_e_243, v_x_2411, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2434);
    heff_clo_take(self, 6);
    if ((((int64_t)0ULL) < heff_unbox_word(v_n_241))) {
      V v_t_2435 = heff_take_field(v_lit_240, 0);
      double v_t_2437;
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2435);
        double v_x_2436 = (g_std_2emath_2efromDecimal_w(heff_take_field(v_lit_240, 1), heff_get_n(v_lit_240, 2, 3)));
        v_t_2437 = ((-1.0) * v_x_2436);
      } else {
        heff_drop(v_t_2435);
        v_t_2437 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_lit_240, 1)), heff_get_n(v_lit_240, 2, 3)));
      }
      return (g_heff_2eelab_2erules_2efracDefault_w(v_sp_242, v_e_243, v_x_2411, v_t_2437, v_hd_245, v_k_246));
    } else {
      V v_t_2438 = heff_take_field(v_lit_240, 0);
      double v_t_2440;
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_t_2438);
        double v_x_2439 = (g_std_2emath_2efromDecimal_w(heff_take_field(v_lit_240, 1), heff_get_n(v_lit_240, 2, 3)));
        v_t_2440 = ((-1.0) * v_x_2439);
      } else {
        heff_drop(v_t_2438);
        v_t_2440 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_lit_240, 1)), heff_get_n(v_lit_240, 2, 3)));
      }
      return (g_heff_2eelab_2erules_2efracDefault_w(v_sp_242, v_e_243, v_x_2411, v_t_2440, v_hd_245, v_k_246));
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_lam2, 1, 6, (V[]){v_lit_240, v_sp_242, v_e_243, v_hd_245, v_k_246, v_n_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_x_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
    V v_u_2411 = (g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps(v_ys_240, v_xs_243, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163(a[0], a[1]);
}