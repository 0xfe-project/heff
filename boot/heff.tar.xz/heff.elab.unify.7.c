// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_selfKey 62480824
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V, V);
V g_heff_2eelab_2eunify_2epatSpine(V, V, V);
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatSpine_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eunify_2epatStep_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;

HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_244));
    V v_t_246 = (g_heff_2eelab_2eunify_2epatSpine(v_selfKey_240, v_mc_241, v_s_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2epatStep_24cpr(v_selfKey_240, v_t_245, v_t_246);
  }
  case TAG_SpProj: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SpSpec: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2eunify_2esubstTyFields_24dps(v_r_240, v_d_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_rest_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eelab_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = ({ V rv_0 = v_ty_242; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_arity_241; V rr_ = heff_rec_reuse_nf(v_entry_240, 48ULL, 6, shape_ty__sol__solStx__arity__name__span, 3840u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_mc_245 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_c_243, 3), heff_dup(heff_rfield(v_c_243, 4)), v_t_244));
  V v_t_246 = heff_intAdd(heff_take_field(v_c_243, 4), MK_INT(1LL));
  return ({ V rv_3 = v_mc_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_243, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_a_246, v_a_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
      } else {
        heff_drop(v_t_249);
        v_t_2410 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam2, 2, 5, (V[]){v_t_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, v_pr_2411, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_t_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nom: {
    V v_a_2419 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419}));
    break;
  }
  case TAG_Describe: {
    V v_a_2420 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2420}));
    break;
  }
  case TAG_Become: {
    V v_a_2421 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2421});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, v_pr_242, v_a_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_a_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430}));
    break;
  }
  case TAG_Describe: {
    V v_a_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2431}));
    break;
  }
  case TAG_Become: {
    V v_a_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2434 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2433));
  V f_ = v_c_2434;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2436 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_implicit_2439 = heff_env(self)[3];
  V v_dflt_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2436, v_x_2441, v_x_2443, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2437 = heff_env(self)[3];
  V v_cod_2438 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2436 = heff_env(self)[7];
  V v_implicit_2439 = heff_env(self)[8];
  V v_dflt_2440 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2442 = (g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626(v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438));
  V f_ = v_c_2442;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam10, 1, 5, (V[]){v_k_245, v_level_2436, v_x_2441, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_fieldTypes_2446 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2444 = heff_env(self)[2];
  V v_defaults_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = ({ V rv_2 = heff_arrayFromList(v_x_2450); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2446, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2444, v_t_2451, v_defaults_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam13(V self, V *args) {
  V v_a_2459 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tr(heff_call(v_a_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2460;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam15(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2457 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2457, heff_arrayFromList(v_x_2464)});
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam14(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam15, 1, 2, (V[]){v_k_2457, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam12(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_args_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    V v_c_2461 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2458)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam14, 2, 2, (V[]){v_c_2461, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam16(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2467)));
  V v_t_2469 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2467));
  V v_t_2470 = (g_list_2emap_24s1173914895x100384474(v_x_2467));
  V v_t_2471 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2468), v_t_2469, heff_arrayFromList(v_t_2470)});
  V v_x_2472 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2471});
  V f_ = v_k_245;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam17(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2417;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2426, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at_n(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2429}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2430;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam6, 1, 1, (V[]){v_k_245})));
      }
    }
    case TAG_HError: {
      V v_c_2432 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2432;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2436 = heff_field(v_x_249, 0);
    V v_dom_2437 = heff_field(v_x_249, 1);
    V v_cod_2438 = heff_field(v_x_249, 2);
    V v_implicit_2439 = heff_field(v_x_249, 3);
    V v_dflt_2440 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2437), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438, v_hd_244, v_k_245, v_level_2436, v_implicit_2439, v_dflt_2440})));
  }
  case TAG_VRecord: {
    V v_level_2444 = heff_field(v_x_249, 0);
    V v_capture_2445 = heff_field(v_x_249, 1);
    V v_fieldTypes_2446 = heff_field(v_x_249, 2);
    V v_defaults_2447 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2448 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2446, 2)));
    V v_c_2449 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2445, v_t_2448));
    V f_ = v_c_2449;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam11, 1, 4, (V[]){v_fieldTypes_2446, v_k_245, v_level_2444, v_defaults_2447});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2452 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2453 = heff_arrayToList(heff_take_field(v_vs_2452, 0));
    V v_t_2454 = heff_arrayToList(heff_get_n(v_vs_2452, 2, 3));
    V v_t_2455 = (g_heff_2eutil_2edict_2ezipKV(v_t_2453, v_t_2454));
    V v_c_2466 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    V f_ = v_c_2466;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2473 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_240, v_m_241, v_pr_242, v_a_2473, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2475 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2475});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}