// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Escapes 7836
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_MentionsError 719
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SGlobal 8650
#define TAG_SLocal 28569
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_left 9813198
#define LBL_malg 9839318
#define LBL_meta 9843404
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_pairs 307786995
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prefix 967031229
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_rhs 322423
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_syntax 1059664654
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_value 313331083
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_meta__prefix__rhs__pairs[] = {LBL_meta, LBL_prefix, LBL_rhs, LBL_pairs};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_clo;
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_clo;
HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2enominalBody(V);
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enominalBody_clo;
HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V, V);
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24generate1(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24generate1_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate1(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate1_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24map2(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24map2_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map0(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map0_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24SpApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_selfKey_245 = heff_dup(v_selfKey_240);
    V v_v_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_244));
    HeffT2 v_t_247 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_selfKey_240, v_mc_241, v_s_243));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_rest_2410 = v_field_249;
        switch (heff_tag_of(v_v_246)) {
        case TAG_VNeu: {
          V v_v1_2411 = heff_field(v_v_246, 0);
          V v_v2_2412 = heff_field(v_v_246, 1);
          heff_take_n(v_v_246, 3ULL, 5);
          switch (heff_tag_of(v_v1_2411)) {
          case TAG_HLocal: {
            V v_l_2416 = heff_field(v_v1_2411, 0);
            V v_ru_24v1_2411_24HLocal = heff_take_reuse_n(v_v1_2411, 1ULL, 1);
            heff_drop(v_selfKey_245);
            switch (heff_tag_of(v_v2_2412)) {
            case TAG_SpId: {
              V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24SpApp, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v1_2411_24HLocal, TAG_PVar, 1, (V[]){v_l_2416}), v_rest_2410});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
            }
            case TAG_SpApp: {
              heff_take_n(v_v2_2412, 0ULL, 2);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_rest_2410);
              heff_drop(v_l_2416);
              heff_drop_cell(v_ru_24v1_2411_24HLocal, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SpProj: {
              heff_take_n(v_v2_2412, 0ULL, 2);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_rest_2410);
              heff_drop(v_l_2416);
              heff_drop_cell(v_ru_24v1_2411_24HLocal, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SpSpec: {
              heff_take_n(v_v2_2412, 0ULL, 3);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_rest_2410);
              heff_drop(v_l_2416);
              heff_drop_cell(v_ru_24v1_2411_24HLocal, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_v2_2412)}});
            }
          }
          case TAG_HGlobal: {
            V v_k_2425 = heff_field(v_v1_2411, 0);
            heff_take_n(v_v1_2411, 1ULL, 1);
            switch (heff_tag_of(v_v2_2412)) {
            case TAG_SpId: {
              switch (heff_tag_of(v_selfKey_245)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
                heff_drop(v_rest_2410);
                heff_drop(v_k_2425);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_sk_2426 = heff_field(v_selfKey_245, 0);
                heff_take_n(v_selfKey_245, 1ULL, 1);
                if (heff_strEq_c(v_sk_2426, v_k_2425)) {
                  V v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24SpApp, TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_2410});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
                } else {
                  heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
                  heff_drop(v_rest_2410);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_selfKey_245)}});
              }
            }
            case TAG_SpApp: {
              heff_take_n(v_v2_2412, 0ULL, 2);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_selfKey_245);
              heff_drop(v_rest_2410);
              heff_drop(v_k_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SpProj: {
              heff_take_n(v_v2_2412, 0ULL, 2);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_selfKey_245);
              heff_drop(v_rest_2410);
              heff_drop(v_k_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SpSpec: {
              heff_take_n(v_v2_2412, 0ULL, 3);
              heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
              heff_drop(v_selfKey_245);
              heff_drop(v_rest_2410);
              heff_drop(v_k_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_v2_2412)}});
            }
          }
          case TAG_HMeta: {
            heff_take_n(v_v1_2411, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
            heff_drop(v_selfKey_245);
            heff_drop(v_rest_2410);
            heff_drop(v_v2_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_HError: {
            heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
            heff_drop(v_selfKey_245);
            heff_drop(v_rest_2410);
            heff_drop(v_v2_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_v1_2411)}});
          }
        }
        case TAG_VCode: {
          heff_take_n(v_v_246, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
          heff_drop(v_selfKey_245);
          heff_drop(v_rest_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VLam: {
          heff_take_n(v_v_246, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
          heff_drop(v_selfKey_245);
          heff_drop(v_rest_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VCons: {
          heff_take_n(v_v_246, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
          heff_drop(v_selfKey_245);
          heff_drop(v_rest_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VOpaque: {
          heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
          heff_drop(v_selfKey_245);
          heff_drop(v_rest_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v_246)}});
        }
      } else {
        heff_drop_cell(v_ru_24x3_242_24SpApp, 2);
        heff_drop(v_selfKey_245);
        heff_drop(v_v_246);
        heff_drop(v_field_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_selfKey_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SpSpec: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_selfKey_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2esubstTermF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_24generate1_entry, 5, 0};

V g_heff_2eelab_2eunify_2esubstTermF_24generate1(V v_ix_240, V v_d_241, V v_idxs_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_ix_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_i_245 = heff_arrayPeekIn(v_ix_240, heff_box_word(v_i_243));
      V v_t_2412;
      if (heff_intLt_c_lent(v_i_245, v_d_241, 0)) {
        v_t_2412 = heff_dup(v_i_245);
      } else {
        V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_242));
        V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_245), heff_dup(v_d_241)));
        HeffT2 v_t_248 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_242, v_t_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_j_2411 = v_field_2410;
            v_t_2412 = heff_intAdd(v_j_2411, heff_dup(v_d_241));
          } else {
            heff_drop(v_field_2410);
            v_t_2412 = heff_dup(v_i_245);
          }
        }
      }
      V t_0 = v_ix_240;
      V t_1 = v_d_241;
      V t_2 = v_idxs_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2412);
      v_ix_240 = t_0;
      v_d_241 = t_1;
      v_idxs_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_d_241);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_i_245 = heff_arrayPeek(v_ix_240, heff_box_word(v_i_243));
    V v_t_2412;
    if (heff_intLt_c_lent(v_i_245, v_d_241, 0)) {
      v_t_2412 = heff_dup(v_i_245);
    } else {
      V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_242));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_245), heff_dup(v_d_241)));
      HeffT2 v_t_248 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_242, v_t_247));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_j_2411 = v_field_2410;
          v_t_2412 = heff_intAdd(v_j_2411, heff_dup(v_d_241));
        } else {
          heff_drop(v_field_2410);
          v_t_2412 = heff_dup(v_i_245);
        }
      }
    }
    V t_0 = v_ix_240;
    V t_1 = v_d_241;
    V t_2 = v_idxs_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2412);
    v_ix_240 = t_0;
    v_d_241 = t_1;
    v_idxs_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop(v_d_241);
    return v_a_244;
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eunify_2esubstTermF_24generate1(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2eunify_2esubstTyFields_24dps(v_r_240, v_d_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_rest_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_24generate1_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTermF_24generate1(V v_r_240, V v_argv_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_argv_241, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_argv_241, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
      V t_0 = v_r_240;
      V t_1 = v_argv_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_r_240 = t_0;
      v_argv_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_argv_241, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
    V t_0 = v_r_240;
    V t_1 = v_argv_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_r_240 = t_0;
    v_argv_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_24generate1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF_24generate1(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTermF_24map2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_24map2_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF_24map2(V v_r_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_p_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_247;
      switch (heff_tag_of(v_p_243)) {
      case TAG_MkPair: {
        V v_xs_244 = heff_field(v_p_243, 0);
        V v_b_245 = heff_field(v_p_243, 1);
        V v_ru_24p_243_24MkPair = heff_take_reuse_n(v_p_243, 3ULL, 2);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b_245}));
        v_t_247 = heff_tag_at_n(v_ru_24p_243_24MkPair, TAG_MkPair, 2, (V[]){v_xs_244, v_t_246});
        break;
      }
      default: heff_nomatch(v_p_243);
      }
      V t_0 = v_r_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_247);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_p_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_xs_244 = heff_field(v_p_243, 0);
      V v_b_245 = heff_field(v_p_243, 1);
      V v_ru_24p_243_24MkPair = heff_take_reuse_n(v_p_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b_245}));
      v_t_247 = heff_tag_at_n(v_ru_24p_243_24MkPair, TAG_MkPair, 2, (V[]){v_xs_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V t_0 = v_r_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_247);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    return v_a_242;
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_24map2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezonkTermF_24map2(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24map0_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24map0(V v_r_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_243}));
      V t_0 = v_r_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_243}));
    V t_0 = v_r_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    return v_a_242;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezonkTypeF_24map0(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eelab_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = ({ V rv_0 = v_ty_242; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_arity_241; V rr_ = heff_rec_reuse_nf(v_entry_240, 48ULL, 6, shape_ty__sol__solStx__arity__name__span, 3840u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_mc_245 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_c_243, 3), heff_dup(heff_rfield(v_c_243, 4)), v_t_244));
  V v_t_246 = heff_intAdd(heff_take_field(v_c_243, 4), MK_INT(1LL));
  return ({ V rv_3 = v_mc_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_243, 487ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_entry, 5, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(V v_cs_240, V v_l_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  V v_bind_245 = heff_take_field(v_hd_243, 1);
  V v_malg_246 = heff_get_n(v_hd_243, 2, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam0, 1, 3, (V[]){v_cs_240, v_l_241, v_r_242})})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam1, 1, 3, (V[]){v_malg_246, v_bind_245, v_k_244})});
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_240, v_l_241, v_r_242, NTAG(TAG_False)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_take_field(v_c_247, 5)});
  return ({ V rv_5 = v_t_249; V rr_ = heff_rec_reuse_nf(v_c_247, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(v_malg_246, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2414;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam3, 2, 0};
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam4, 2, 0};
Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry, 2, 0};

V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V v_r_240, V v_x2_241) {
top: ;
  V v_ren_242 = heff_take_field(v_r_240, 2);
  V v_cod_243 = heff_get_n(v_r_240, 1, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = ({ V a_0 = v_ren_242; V a_1 = heff_dup(v_l_244); HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_ren_242); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_l_244);
        V v_l_27_248 = v_field_247;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam0, 2, 2, (V[]){v_cod_243, v_l_27_248});
      } else {
        heff_drop(v_cod_243);
        heff_drop(v_field_247);
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam1, 2, 1, (V[]){v_l_244});
      }
    }
  }
  case TAG_HGlobal: {
    V v_x_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_ren_242);
    heff_drop(v_cod_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam2, 2, 1, (V[]){v_x_2418});
  }
  case TAG_HMeta: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ren_242);
    heff_drop(v_cod_243);
    return ((V)&g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam3_clo);
  }
  case TAG_HError: {
    heff_drop(v_ren_242);
    heff_drop(v_cod_243);
    return ((V)&g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam4_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_cod_243 = heff_env(self)[0];
  V v_l_27_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_intSub(heff_intSub(v_cod_243, v_l_27_248), MK_INT(1LL));
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_SLocal, 1, (V[]){v_t_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_l_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2414 = heff_take_field(v_hd_2412, 1);
  V v_malg_2415 = heff_get_n(v_hd_2412, 2, 3);
  V v_t_2416 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_Escapes, 1, (V[]){v_l_244})});
  V v_t_2417 = heff_tr(heff_call(v_malg_2415, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = v_bind_2414;
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_bind_2424 = heff_take_field(v_hd_2422, 1);
  V v_malg_2425 = heff_get_n(v_hd_2422, 2, 3);
  V v_t_2426 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(v_malg_2425, 1, (V[]){v_t_2427}));
  V f_ = v_bind_2424;
  args[0] = v_t_2428;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_bind_2431 = heff_take_field(v_hd_2429, 1);
  V v_malg_2432 = heff_get_n(v_hd_2429, 2, 3);
  V v_t_2433 = heff_tag_n(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
  V v_t_2434 = heff_tr(heff_call(v_malg_2432, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  V f_ = v_bind_2431;
  args[0] = v_t_2434;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam1, 2, 8, (V[]){v_g_240, v_m_241, v_pr_2413, v_ty_2411, v_pr_242, v_i_243, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam3(V self, V *args) {
  V v_u_2418 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return v_v_2419;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2417}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2421 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam4, 1, 1, (V[]){v_v_2419})}), v_rest_249));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam5, 1, 2, (V[]){v_k_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_i_243 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_hd_2414), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2414, v_k_2415})));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam3, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam4, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam5, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam6, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam13(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam13, 1, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam14(V self, V *args);
Clo g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_entry, 6, 0};

V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251(V v_g_240, V v_cs_241, V v_self_242, V v_a_243, V v_hd_244, V v_k_245) {
top: ;
  V v_meta_246 = heff_take_field(v_a_243, 0);
  V v_rhs_247 = heff_take_field(v_a_243, 2);
  V v_prefix_248 = heff_take_field(v_a_243, 1);
  V v_pairs_249 = heff_get_n(v_a_243, 3, 4);
  V v_k_2485 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam0, 1, 9, (V[]){v_g_240, heff_dup(v_meta_246), heff_dup(v_hd_244), v_rhs_247, v_cs_241, v_prefix_248, v_self_242, v_pairs_249, v_k_245});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam13_clo)})});
  V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2487}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2488, heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam14, 1, 3, (V[]){v_meta_246, v_k_2485, v_hd_244})});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_bind_2425 = heff_take_field(v_hd_2423, 1);
  V v_malg_2426 = heff_get_n(v_hd_2423, 2, 3);
  V v_t_2427 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2426, 1, (V[]){v_t_2428}));
  V f_ = v_bind_2425;
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_bind_2434 = heff_take_field(v_hd_2432, 1);
  V v_malg_2435 = heff_get_n(v_hd_2432, 2, 3);
  V v_t_2436 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(v_malg_2435, 1, (V[]){v_t_2437}));
  V f_ = v_bind_2434;
  args[0] = v_t_2438;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam5(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_bind_2442 = heff_take_field(v_hd_2440, 1);
  V v_malg_2443 = heff_get_n(v_hd_2440, 2, 3);
  V v_t_2444 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(v_malg_2443, 1, (V[]){v_t_2445}));
  V f_ = v_bind_2442;
  args[0] = v_t_2446;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_bind_2449 = heff_take_field(v_hd_2447, 1);
  V v_malg_2450 = heff_get_n(v_hd_2447, 2, 3);
  V v_t_2451 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(v_malg_2450, 1, (V[]){v_t_2452}));
  V f_ = v_bind_2449;
  args[0] = v_t_2453;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam10(V self, V *args) {
  V v_c_2465 = args[0];
  V v_meta_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2466 = ({ V b_0 = heff_get_n(v_c_2465, 3, 9); V a_1 = v_meta_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    if ((v_tag_2467 == ((int64_t)0ULL))) {
      V v_e_2469 = v_field_2468;
      V v_t_2470 = heff_get_n(v_e_2469, 1, 6);
      switch (heff_tag_of(v_t_2470)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_2470, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_2470);
      }
    } else {
      heff_drop(v_field_2468);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam12(V self, V *args) {
  V v_p_2475 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478;
  switch (heff_tag_of(v_p_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_dup(heff_field(v_p_2475, 0));
    v_t_2478 = v_x_2476;
    break;
  }
  default: heff_nomatch(v_p_2475);
  }
  V v_t_2481;
  switch (heff_tag_of(v_p_2475)) {
  case TAG_MkPair: {
    V v_y_2480 = heff_field(v_p_2475, 1);
    heff_take_n(v_p_2475, 2ULL, 2);
    v_t_2481 = v_y_2480;
    break;
  }
  default: heff_nomatch(v_p_2475);
  }
  V f_ = ((V)&g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_cs_241;
  heff_room[2] = v_t_2478;
  heff_room[3] = v_t_2481;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam11(V self, V *args) {
  V v_x_2474 = args[0];
  V v_pairs_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2474) == NTAG(TAG_True))) {
    heff_drop(v_x_2474);
    return ({ V a_0 = v_pairs_249; V a_1 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam12, 1, 2, (V[]){v_g_240, v_cs_241}); V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a_0, a_1, a_2, a_3)); heff_drop(v_pairs_249); r_; });
  } else {
    heff_drop(v_x_2474);
    heff_drop(v_pairs_249);
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    V v_t_2482 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2483}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2484;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam9(V self, V *args) {
  V v_x_2464 = args[0];
  V v_meta_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_pairs_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2464);
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam10, 1, 1, (V[]){v_meta_246})})});
  V v_t_2473 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2472}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2473;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam11, 1, 5, (V[]){v_pairs_249, v_g_240, v_cs_241, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_meta_246 = heff_env(self)[2];
  V v_prefix_248 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  V v_self_242 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  V v_pairs_249 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2463);
  return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_meta_246), v_prefix_248, v_rhs_247, v_self_242, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam9, 1, 6, (V[]){v_meta_246, v_hd_244, v_pairs_249, v_g_240, v_cs_241, v_k_245})));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_meta_246 = heff_env(self)[4];
  V v_prefix_248 = heff_env(self)[5];
  V v_rhs_247 = heff_env(self)[6];
  V v_self_242 = heff_env(self)[7];
  V v_pairs_249 = heff_env(self)[8];
  V v_k_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  HeffT2 v_t_2456 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), v_x_2413, NTAG(TAG_LNil)));
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    V v_a_2462;
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      V v_x_2459 = v_field_2458;
      v_a_2462 = v_x_2459;
    } else {
      if ((v_tag_2457 == ((int64_t)1ULL))) {
        V v_x11_2460 = v_field_2458;
        heff_drop(v_x11_2460);
        v_a_2462 = heff_abandon();
      } else {
        V v_x_2461 = v_field_2458;
        v_a_2462 = v_x_2461;
      }
    }
    return (g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(heff_dup(v_g_240), heff_dup(v_cs_241), v_a_2462, v_x_2455, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam8, 1, 9, (V[]){v_g_240, v_cs_241, v_meta_246, v_prefix_248, v_rhs_247, v_self_242, v_hd_244, v_pairs_249, v_k_245})));
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rhs_247 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_meta_246 = heff_env(self)[4];
  V v_prefix_248 = heff_env(self)[5];
  V v_self_242 = heff_env(self)[6];
  V v_pairs_249 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2454;
  switch (heff_tag_of(v_rhs_247)) {
  case TAG_VNeu: {
    V v_ty_2416 = heff_dup(heff_field(v_rhs_247, 2));
    V v_t_2419 = heff_tr(heff_call(v_ty_2416, 1, (V[]){NTAG(TAG_MkUnit)}));
    v_c_2454 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam2, 2, 1, (V[]){v_t_2419});
    break;
  }
  case TAG_VCode: {
    v_c_2454 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam3_clo);
    break;
  }
  case TAG_VLam: {
    v_c_2454 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam4_clo);
    break;
  }
  case TAG_VCons: {
    v_c_2454 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam5_clo);
    break;
  }
  case TAG_VOpaque: {
    v_c_2454 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam6_clo);
    break;
  }
  default: heff_nomatch(v_rhs_247);
  }
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam7, 1, 10, (V[]){v_g_240, v_x_2413, v_cs_241, v_hd_244, v_meta_246, v_prefix_248, v_rhs_247, v_self_242, v_pairs_249, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_meta_246 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_rhs_247 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_prefix_248 = heff_env(self)[5];
  V v_self_242 = heff_env(self)[6];
  V v_pairs_249 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_arity_2411 = heff_take_field(v_x_2410, 3);
  V v_ty_2412 = heff_get_n(v_x_2410, 0, 6);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_meta_246), heff_rec_n(3, shape_dom__cod__ren, (V[]){v_arity_2411, MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get())}), v_ty_2412, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam1, 1, 9, (V[]){v_rhs_247, v_hd_244, v_g_240, v_cs_241, v_meta_246, v_prefix_248, v_self_242, v_pairs_249, v_k_245})));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam13(V self, V *args) {
  V v_c_2486 = args[0];
  return heff_get_n(v_c_2486, 3, 9);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251_lam14(V self, V *args) {
  V v_x_2489 = args[0];
  V v_meta_246 = heff_env(self)[0];
  V v_k_2485 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2490 = ({ V a_0 = v_x_2489; V a_1 = v_meta_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2489); r_; });
  {
    V v_field_2492 = v_t_2490.f[1];
    int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
    if ((v_tag_2491 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_244, 3);
      V v_e_2493 = v_field_2492;
      V f_ = v_k_2485;
      args[0] = v_e_2493;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2492);
      V v_t_2494 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2495}));
      V f_ = heff_get_n(v_hd_244, 1, 3);
      heff_room[0] = v_t_2496;
      heff_room[1] = v_k_2485;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam4, 1, 0};
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_entry, 6, 0};

V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009(V v_g_240, V v_cs_241, V v_left_242, V v_right_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam0, 1, 1, (V[]){v_left_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam1, 1, 5, (V[]){v_right_243, v_hd_244, v_k_245, v_g_240, v_cs_241})});
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_left_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_left_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_right_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_right_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  return heff_get_n(v_c_2414, 3, 9);
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam6(V self, V *args) {
  V v_x_24113 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24113);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_v1_2418 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_v1_2418)) {
    case TAG_HLocal: {
      heff_take_n(v_v1_2418, 0ULL, 1);
      heff_drop(v_x_2417);
      heff_drop(v_g_240);
      heff_drop(v_x_2413);
      heff_drop(v_cs_241);
      heff_drop_rec(v_hd_244, 3);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_HGlobal: {
      heff_take_n(v_v1_2418, 0ULL, 1);
      heff_drop(v_x_2417);
      heff_drop(v_g_240);
      heff_drop(v_x_2413);
      heff_drop(v_cs_241);
      heff_drop_rec(v_hd_244, 3);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_HMeta: {
      V v_m_2435 = heff_field(v_v1_2418, 0);
      V v_ru_24v1_2418_24HMeta = heff_take_reuse_n(v_v1_2418, 1ULL, 1);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        V v_sp_2437 = heff_dup(heff_field(v_x_249, 1));
        V v_g_2441 = heff_dup(v_g_240);
        V v_m_2442 = heff_dup(v_m_2435);
        HeffT2 v_t_2443 = ({ V a_0 = v_x_2417; V a_1 = v_m_2435; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2417); r_; });
        V v_x4_24111;
        {
          V v_field_2445 = v_t_2443.f[1];
          int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
          HeffT2 v_t_2446 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_sp_2437));
          {
            V v_field_2448 = v_t_2446.f[1];
            int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
            V v_rigid_2449 = v_x_2413;
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              V v_e_2450 = v_field_2445;
              if ((v_tag_2447 == ((int64_t)0ULL))) {
                V v_metaArgs_2451 = v_field_2448;
                switch (heff_tag_of(v_rigid_2449)) {
                case TAG_VNeu: {
                  V v_h_2452 = heff_field(v_rigid_2449, 0);
                  V v_sp_2453 = heff_field(v_rigid_2449, 1);
                  heff_take_n(v_rigid_2449, 3ULL, 5);
                  V v_g_2457 = heff_dup(v_g_2441);
                  V v_entries_2458 = heff_take_field(v_g_2457, 1);
                  V v_aliases_2459 = heff_get_n(v_g_2457, 2, 8);
                  V v_h_2460 = v_h_2452;
                  V v_sp_2461 = v_sp_2453;
                  V v_x5_2479;
                  switch (heff_tag_of(v_h_2460)) {
                  case TAG_HLocal: {
                    heff_take_n(v_h_2460, 0ULL, 1);
                    heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                    heff_drop(v_entries_2458);
                    heff_drop(v_aliases_2459);
                    heff_drop(v_sp_2461);
                    v_x5_2479 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_HGlobal: {
                    V v_k_2463 = heff_field(v_h_2460, 0);
                    heff_take_n(v_h_2460, 1ULL, 1);
                    HeffT2 v_t_2464 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2458, v_k_2463));
                    {
                      V v_field_2466 = v_t_2464.f[1];
                      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
                      if ((v_tag_2465 == ((int64_t)0ULL))) {
                        heff_drop(v_entries_2458);
                        heff_drop(v_aliases_2459);
                        V v_e_2467 = v_field_2466;
                        V v_t_2468 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_2467, 0, 4)));
                        if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
                          heff_drop(v_t_2468);
                          v_x5_2479 = heff_tag_at_n(v_ru_24v1_2418_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2463, v_sp_2461})});
                        } else {
                          heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                          heff_drop(v_sp_2461);
                          heff_drop(v_k_2463);
                          heff_drop(v_t_2468);
                          v_x5_2479 = NTAG(TAG_Nothing);
                        }
                      } else {
                        heff_drop(v_field_2466);
                        HeffT2 v_t_2469 = ({ V a_0 = v_aliases_2459; V a_1 = v_k_2463; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2459); r_; });
                        {
                          V v_field_2471 = v_t_2469.f[1];
                          int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                          if ((v_tag_2470 == ((int64_t)0ULL))) {
                            V v_k2_2472 = v_field_2471;
                            HeffT2 v_t_2473 = ({ V a_0 = v_entries_2458; V a_1 = v_k2_2472; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2458); heff_drop(v_k2_2472); r_; });
                            {
                              V v_field_2475 = v_t_2473.f[1];
                              int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                              if ((v_tag_2474 == ((int64_t)0ULL))) {
                                V v_e_2476 = v_field_2475;
                                V v_t_2477 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_2476, 0, 4)));
                                if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
                                  heff_drop(v_t_2477);
                                  v_x5_2479 = heff_tag_at_n(v_ru_24v1_2418_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2463, v_sp_2461})});
                                } else {
                                  heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                                  heff_drop(v_sp_2461);
                                  heff_drop(v_k_2463);
                                  heff_drop(v_t_2477);
                                  v_x5_2479 = NTAG(TAG_Nothing);
                                }
                              } else {
                                heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                                heff_drop(v_sp_2461);
                                heff_drop(v_k_2463);
                                heff_drop(v_field_2475);
                                v_x5_2479 = NTAG(TAG_Nothing);
                              }
                            }
                          } else {
                            heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                            heff_drop(v_entries_2458);
                            heff_drop(v_sp_2461);
                            heff_drop(v_k_2463);
                            heff_drop(v_field_2471);
                            v_x5_2479 = NTAG(TAG_Nothing);
                          }
                        }
                      }
                    }
                    break;
                  }
                  case TAG_HMeta: {
                    heff_take_n(v_h_2460, 0ULL, 1);
                    heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                    heff_drop(v_entries_2458);
                    heff_drop(v_aliases_2459);
                    heff_drop(v_sp_2461);
                    v_x5_2479 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_HError: {
                    heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                    heff_drop(v_entries_2458);
                    heff_drop(v_aliases_2459);
                    heff_drop(v_sp_2461);
                    v_x5_2479 = NTAG(TAG_Nothing);
                    break;
                  }
                  default: heff_nomatch(v_h_2460);
                  }
                  switch (heff_tag_of(v_x5_2479)) {
                  case TAG_Nothing: {
                    heff_drop(v_g_2441);
                    heff_drop(v_m_2442);
                    heff_drop_rec(v_e_2450, 6);
                    heff_drop(v_metaArgs_2451);
                    v_x4_24111 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x51_2480 = heff_field(v_x5_2479, 0);
                    V v_ru_24x5_2479_24Just = heff_take_reuse_n(v_x5_2479, 1ULL, 1);
                    switch (heff_tag_of(v_x51_2480)) {
                    case TAG_MkPair: {
                      V v_key_2481 = heff_field(v_x51_2480, 0);
                      V v_sp_2482 = heff_field(v_x51_2480, 1);
                      heff_take_n(v_x51_2480, 3ULL, 2);
                      HeffT2 v_t_2483 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_sp_2482));
                      {
                        V v_field_2485 = v_t_2483.f[1];
                        int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
                        if ((v_tag_2484 == ((int64_t)0ULL))) {
                          V v_rigidArgs_2486 = v_field_2485;
                          V v_g_2487 = v_g_2441;
                          V v_m_2488 = v_m_2442;
                          V v_t_2489 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_metaArgs_2451));
                          V v_k_2490 = heff_intSub(v_t_2489, heff_get_n(v_e_2450, 3, 6));
                          V v_metaArgs_2491 = v_metaArgs_2451;
                          V v_key_2492 = v_key_2481;
                          V v_rigidArgs_2493 = v_rigidArgs_2486;
                          if ((heff_intLt_c_lent(v_k_2490, MK_INT(1LL), 2) || ({ V v_t_24123 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rigidArgs_2493)); int c_ = heff_intLt_c_lent(v_t_24123, v_k_2490, 0); heff_drop(v_t_24123); c_; }))) {
                            heff_drop_cell(v_ru_24x5_2479_24Just, 1);
                            heff_drop_rec(v_g_2487, 8);
                            heff_drop(v_m_2488);
                            heff_drop(v_k_2490);
                            heff_drop(v_metaArgs_2491);
                            heff_drop(v_key_2492);
                            heff_drop(v_rigidArgs_2493);
                            v_x4_24111 = NTAG(TAG_Nothing);
                          } else {
                            V v_t_2494 = (g_list_2edrop(heff_dup(v_k_2490), v_metaArgs_2491));
                            V v_t_2495 = (g_heff_2eelab_2eunify_2espineRev(v_t_2494));
                            HeffT2 v_t_2496 = ({ V b_0 = heff_get_n(v_g_2487, 1, 8); V a_1 = v_key_2492; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_key_2492); r_; });
                            V v_t_24100;
                            {
                              V v_field_2498 = v_t_2496.f[1];
                              int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
                              if ((v_tag_2497 == ((int64_t)0ULL))) {
                                V v_e_2499 = v_field_2498;
                                v_t_24100 = v_e_2499;
                              } else {
                                heff_drop(v_field_2498);
                                v_t_24100 = heff_abandon();
                              }
                            }
                            V v_t_24101 = (g_list_2edrop(heff_dup(v_k_2490), v_rigidArgs_2493));
                            V v_t_24102 = (g_heff_2eelab_2eunify_2espineRev(v_t_24101));
                            V v_t_24103 = ({ V a_0 = heff_get_n(v_t_24100, 2, 4); V a_1 = v_t_24102; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_t_24102); r_; });
                            V v_t_24104 = (g_list_2etake(heff_dup(v_k_2490), v_metaArgs_2491));
                            V v_t_24105 = (g_list_2etake(v_k_2490, v_rigidArgs_2493));
                            V v_t_24106 = (g_heff_2eelab_2eunify_2ezipL(v_t_24104, v_t_24105));
                            v_x4_24111 = heff_tag_at_n(v_ru_24x5_2479_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_meta__prefix__rhs__pairs, (V[]){v_m_2488, v_t_2495, v_t_24103, v_t_24106})});
                          }
                        } else {
                          heff_drop(v_g_2441);
                          heff_drop(v_m_2442);
                          heff_drop_rec(v_e_2450, 6);
                          heff_drop(v_metaArgs_2451);
                          heff_drop_cell(v_ru_24x5_2479_24Just, 1);
                          heff_drop(v_key_2481);
                          heff_drop(v_field_2485);
                          v_x4_24111 = NTAG(TAG_Nothing);
                        }
                      }
                      break;
                    }
                    default: heff_nomatch(v_x51_2480);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x5_2479);
                  }
                  break;
                }
                case TAG_VCode: {
                  heff_take_n(v_rigid_2449, 0ULL, 1);
                  heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                  heff_drop(v_g_2441);
                  heff_drop(v_m_2442);
                  heff_drop_rec(v_e_2450, 6);
                  heff_drop(v_metaArgs_2451);
                  v_x4_24111 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VLam: {
                  heff_take_n(v_rigid_2449, 0ULL, 2);
                  heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                  heff_drop(v_g_2441);
                  heff_drop(v_m_2442);
                  heff_drop_rec(v_e_2450, 6);
                  heff_drop(v_metaArgs_2451);
                  v_x4_24111 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VCons: {
                  heff_take_n(v_rigid_2449, 0ULL, 1);
                  heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                  heff_drop(v_g_2441);
                  heff_drop(v_m_2442);
                  heff_drop_rec(v_e_2450, 6);
                  heff_drop(v_metaArgs_2451);
                  v_x4_24111 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VOpaque: {
                  heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                  heff_drop(v_g_2441);
                  heff_drop(v_m_2442);
                  heff_drop_rec(v_e_2450, 6);
                  heff_drop(v_metaArgs_2451);
                  v_x4_24111 = NTAG(TAG_Nothing);
                  break;
                }
                default: heff_nomatch(v_rigid_2449);
                }
              } else {
                heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
                heff_drop(v_g_2441);
                heff_drop(v_m_2442);
                heff_drop(v_field_2448);
                heff_drop(v_rigid_2449);
                heff_drop_rec(v_e_2450, 6);
                v_x4_24111 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_cell(v_ru_24v1_2418_24HMeta, 1);
              heff_drop(v_g_2441);
              heff_drop(v_m_2442);
              heff_drop(v_field_2445);
              heff_drop(v_field_2448);
              heff_drop(v_rigid_2449);
              v_x4_24111 = NTAG(TAG_Nothing);
            }
          }
        }
        switch (heff_tag_of(v_x4_24111)) {
        case TAG_Nothing: {
          heff_drop_tag(v_x_249, 5);
          heff_drop(v_g_240);
          heff_drop(v_cs_241);
          heff_drop_rec(v_hd_244, 3);
          V f_ = v_k_245;
          args[0] = NTAG(TAG_False);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_a_24112 = heff_field(v_x4_24111, 0);
          heff_take_n(v_x4_24111, 1ULL, 1);
          return (g_heff_2eelab_2eunify_2eapproxRun_24s934188354x279246251(v_g_240, v_cs_241, v_x_249, v_a_24112, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam6, 1, 1, (V[]){v_k_245})));
        }
        default: return heff_nomatch(v_x4_24111);
        }
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_HError: {
      heff_drop(v_x_2417);
      heff_drop(v_g_240);
      heff_drop(v_x_2413);
      heff_drop(v_cs_241);
      heff_drop_rec(v_hd_244, 3);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    default: return heff_nomatch(v_v1_2418);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_x_249, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_g_240);
    heff_drop(v_x_2413);
    heff_drop(v_cs_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VLam: {
    heff_take_n(v_x_249, 0ULL, 2);
    heff_drop(v_x_2417);
    heff_drop(v_g_240);
    heff_drop(v_x_2413);
    heff_drop(v_cs_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VCons: {
    heff_take_n(v_x_249, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_g_240);
    heff_drop(v_x_2413);
    heff_drop(v_cs_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VOpaque: {
    heff_drop(v_x_2417);
    heff_drop(v_g_240);
    heff_drop(v_x_2413);
    heff_drop(v_cs_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam4_clo)})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam5, 1, 6, (V[]){v_x_249, v_k_245, v_g_240, v_x_2413, v_cs_241, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_right_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam2, 1, 1, (V[]){v_right_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_lam3, 1, 5, (V[]){v_hd_244, v_x_249, v_k_245, v_g_240, v_cs_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}