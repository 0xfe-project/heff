// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Inherited 58190
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkRegex 19093
#define TAG_NotRun 12703
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_diff 9578700
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_end 310101
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_got 312070
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_output 941629484
#define LBL_pieces 958716528
#define LBL_property 1899481104
#define LBL_ret 322331
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_start 311115900
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
V g_co_2eop_24s59066675x636147158(V, V, V);
V g_co_2eop_24s59066675x636147158_entry(V self, V *a);
extern Clo g_co_2eop_24s59066675x636147158_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(V, V);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s580972671x1254803293(V, V, V, V, V, V, V, V);
V g_list_2emap_24s580972671x1254803293_entry(V self, V *a);
extern Clo g_list_2emap_24s580972671x1254803293_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_regex_2ematchAt(V, V, V, V);
V g_regex_2ematchAt_entry(V self, V *a);
extern Clo g_regex_2ematchAt_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592(V);
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1283316583x974970592_clo;
Clo g_heff_2ebuild_2etesting_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_files_242 = heff_take_field(v_b_241, 0);
  V v_expectErrors_243 = heff_take_field(v_b_241, 1);
  V v_total_244 = heff_take_field(v_b_241, 2);
  V v_failed_245 = heff_take_field(v_b_241, 3);
  V v_unchecked_246 = heff_take_field(v_b_241, 4);
  V v_tests_247 = heff_take_field(v_b_241, 5);
  V v_testsFailed_248 = heff_take_field(v_b_241, 6);
  V v_testsSkipped_249 = heff_get_n(v_b_241, 7, 8);
  V v_files_2410 = heff_take_field(v_a_240, 0);
  V v_expectErrors_2411 = heff_take_field(v_a_240, 1);
  V v_total_2412 = heff_take_field(v_a_240, 2);
  V v_failed_2413 = heff_take_field(v_a_240, 3);
  V v_unchecked_2414 = heff_take_field(v_a_240, 4);
  V v_tests_2415 = heff_take_field(v_a_240, 5);
  V v_testsFailed_2416 = heff_take_field(v_a_240, 6);
  V v_testsSkipped_2417 = heff_get_n(v_a_240, 7, 8);
  V v_t_2418 = (g_prelude_2e_2b_2b(v_unchecked_2414, v_unchecked_246));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){heff_intAdd(v_files_2410, v_files_242), heff_intAdd(v_expectErrors_2411, v_expectErrors_243), heff_intAdd(v_total_2412, v_total_244), heff_intAdd(v_failed_2413, v_failed_245), v_t_2418, heff_intAdd(v_tests_2415, v_tests_247), heff_intAdd(v_testsFailed_2416, v_testsFailed_248), heff_intAdd(v_testsSkipped_2417, v_testsSkipped_249)});
}
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eaddRes(a[0], a[1]);
}

static V g_heff_2ebuild_2etesting_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectedRes_st;
static V g_heff_2ebuild_2etesting_2eexpectedRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectedRes_st)) return g_heff_2ebuild_2etesting_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectedRes_val, &g_heff_2ebuild_2etesting_2eexpectedRes_st, g_heff_2ebuild_2etesting_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2etesting_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2elastLines_str0); V a_1 = v_t_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2elastLines_str1), v_t_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2etesting_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elastLines(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2elevelsSelected_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2elevelsSelected_lam0(V self, V *args);
Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_x1_246 = heff_dup(v_r_242);
      V v_s_247 = heff_dup(v_n_244);
      V v_t_2415;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_MkRegex: {
        V v_bs_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2etesting_2elevelsSelected_lam0, 1, 1, (V[]){v_s_247}); V a_1 = v_bs_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_bs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_2415);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2elevelsSelected_lam1(V self, V *args) {
  V v_i_2414 = args[0];
  V v_s_247 = heff_env(self)[0];
  V v_end_2411 = heff_env(self)[1];
  V v_pieces_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_s_247; V a_1 = v_end_2411; V a_2 = v_pieces_2412; V a_3 = v_i_2414; V r_ = (g_regex_2ematchAt(a_0, a_1, a_2, a_3)); heff_drop(v_s_247); heff_drop(v_end_2411); r_; });
}
V g_heff_2ebuild_2etesting_2elevelsSelected_lam0(V self, V *args) {
  V v_b_249 = args[0];
  V v_s_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_start_2410 = heff_take_field(v_b_249, 0);
  V v_end_2411 = heff_take_field(v_b_249, 2);
  V v_pieces_2412 = heff_get_n(v_b_249, 1, 3);
  if ((heff_dup(v_start_2410) == NTAG(TAG_True))) {
    heff_drop(v_start_2410);
    return ({ V a_0 = v_s_247; V a_1 = v_end_2411; V a_2 = v_pieces_2412; V a_3 = MK_INT(0LL); V r_ = (g_regex_2ematchAt(a_0, a_1, a_2, a_3)); heff_drop(v_s_247); heff_drop(v_end_2411); r_; });
  } else {
    heff_drop(v_start_2410);
    V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_s_247, 0)));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2etesting_2elevelsSelected_lam1, 1, 3, (V[]){v_s_247, v_end_2411, v_pieces_2412}); V a_1 = v_t_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2413); r_; });
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str1, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str2, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str3, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str7, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957(V v_argv_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  V v_t_246;
  if (heff_intEq_c_lent(v_n_241, MK_INT(0LL), 2)) {
    v_t_246 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam0_clo);
  } else {
    v_t_246 = heff_tr(heff_call(((V)&g_co_2eop_24s59066675x636147158_clo), 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str0)}));
  }
  return heff_tail(v_t_246, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam1, 1, 4, (V[]){v_p_242, v_argv_240, v_n_241, v_p_243})});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_intAdd(v_n_241, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_2411;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam5, 3, 1, (V[]){v_n_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str1), v_t_2413), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str2));
  V v_t_2415 = heff_get_n(v_x_2412, 0, 3);
  V v_t_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_intEq_c(v_n_2416, MK_INT(0LL))) {
      v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str3);
    } else {
      v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str4);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str5);
    break;
  }
  case TAG_TimedOut: {
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str6);
    break;
  }
  case TAG_NotRun: {
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str7);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2418), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str8));
  V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str9)), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get_n(v_p_242, 1, 3);
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam4, 1, 2, (V[]){v_k_2411, v_n_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2445 = args[1];
  V v_k_2446 = args[2];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2444);
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_intAdd(v_n_241, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V f_ = v_k_2434;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam8, 3, 1, (V[]){v_n_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam6(V self, V *args) {
  V v_s_2433 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_s_2433);
  V v_k_2434 = heff_take_field(v_p_242, 0);
  V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_str10), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
  V f_ = heff_get_n(v_p_242, 1, 3);
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam7, 1, 2, (V[]){v_k_2434, v_n_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_p_242;
  heff_room[2] = v_p_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_argv_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_248, v_argv_240, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2410 = (g_std_2eprocess_2ewithProcess_24s1283316583x974970592(v_t_249));
  V v_k_2411 = heff_dup(heff_rfield(v_p_242, 0));
  V v_t_2432 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam3, 1, 3, (V[]){heff_dup(v_n_241), heff_dup(v_p_242), v_k_2411})}));
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2432, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam6, 1, 2, (V[]){heff_dup(v_p_242), v_n_241})})});
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
  V f_ = heff_dup(heff_rfield(v_p_242, 1));
  heff_room[0] = v_t_2448;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam9, 1, 2, (V[]){v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_argv_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_lam2, 1, 4, (V[]){v_argv_240, v_p_242, v_n_241, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str4, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str6, 5, " runs");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str7, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str8, 1, "%");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str12, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str13, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str14, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str15, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str16, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str17, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str19, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str20, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str21, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str22, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str23, 6, " times");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str24, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str25, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str26, 8, "  skip  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str27, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str28, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str30, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str31, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str32, 17, "        diff     ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str33, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str34, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str36, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str37, 1, "\012");
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam3(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam3, 2, 0};
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_color_240);
    return ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_o_244, 2));
    V v_str_2436;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_o_247 = heff_dup(v_o_244);
      V v_t_248 = heff_dup(heff_rfield(v_o_247, 1));
      V v_t_249;
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        v_t_249 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str0);
      } else {
        heff_drop(v_t_248);
        v_t_249 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str1);
      }
      V v_t_2410 = heff_strAppend(v_t_249, heff_dup(heff_rfield(v_o_247, 0)));
      V v_t_2432;
      if (!(heff_dup(heff_rfield(v_o_247, 3)) == NTAG(TAG_True))) {
        heff_drop_rec(v_o_247, 12);
        v_t_2432 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str2);
      } else {
        V v_t_2411 = heff_dup(heff_rfield(v_o_247, 1));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_o_2412 = v_o_247;
          V v_t_2413 = heff_intShow(heff_dup(heff_rfield(v_o_2412, 4)));
          V v_t_2415;
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_2412, 5)))) {
            V v_t_2414 = heff_intShow(heff_dup(heff_rfield(v_o_2412, 5)));
            v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str3), v_t_2414), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str4));
          } else {
            v_t_2415 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str5);
          }
          V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str6)), v_t_2415);
          V v_x2_2417 = (g_list_2emap_24s580972671x1254803293(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str7), heff_dup(v_o_2412), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str8), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str9), heff_get_n(v_o_2412, 7, 12)));
          V v_t_2420;
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_Nil: {
            v_t_2420 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2418 = heff_field(v_x2_2417, 0);
            V v_xs_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 3ULL, 2);
            v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str11); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2417);
          }
          V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str12), heff_strAppend(v_t_2416, v_t_2420));
          v_t_2432 = heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str13));
        } else {
          heff_drop(v_t_2411);
          V v_t_2422 = heff_intShow(heff_take_field(v_o_247, 4));
          V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str14), v_t_2422), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str15));
          V v_t_2425;
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_247, 5)))) {
            V v_t_2424 = heff_intShow(heff_dup(heff_rfield(v_o_247, 5)));
            v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str16), v_t_2424), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str17));
          } else {
            v_t_2425 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str18);
          }
          V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2423, v_t_2425), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str19));
          V v_n_2427 = heff_take_field(v_o_247, 6);
          V v_t_2429;
          if (heff_intEq_c_lent(v_n_2427, MK_INT(0LL), 2)) {
            heff_drop(v_n_2427);
            v_t_2429 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str20);
          } else {
            if (heff_intEq_c_lent(v_n_2427, MK_INT(1LL), 2)) {
              heff_drop(v_n_2427);
              v_t_2429 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str21);
            } else {
              V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str22), heff_intShow(v_n_2427));
              v_t_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str23));
            }
          }
          V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2426, v_t_2429), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str24));
          V v_t_2431 = heff_intShow(heff_get_n(v_o_247, 10, 12));
          v_t_2432 = heff_strAppend(heff_strAppend(v_t_2430, v_t_2431), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str25));
        }
      }
      v_str_2436 = heff_strAppend(v_t_2410, v_t_2432);
      break;
    }
    case TAG_Just: {
      V v_why_2433 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str26), heff_dup(heff_rfield(v_o_244, 0)));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str27)), v_why_2433);
      v_str_2436 = heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str28));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam1, 2, 4, (V[]){v_str_2436, v_o_244, v_color_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(a[0], a[1]);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam3(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam4(V self, V *args) {
  V v_x_2478 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2478);
  V v_t_2479 = (g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(v_color_240, v_rest_245));
  V f_ = v_t_2479;
  heff_room[0] = v_hd_2437;
  heff_room[1] = v_k_2438;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_take_field(v_o_244, 1);
  V v_c_2477;
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_244, 12);
    heff_drop(v_t_2448);
    v_c_2477 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam3_clo);
  } else {
    heff_drop(v_t_2448);
    V v_t_2451 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str30), heff_take_field(v_o_244, 8)));
    V v_t_2452 = heff_get_n(v_o_244, 9, 12);
    V v_t_2465;
    switch (heff_tag_of(v_t_2452)) {
    case TAG_Nothing: {
      v_t_2465 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2453 = heff_field(v_t_2452, 0);
      heff_take_n(v_t_2452, 1ULL, 1);
      V v_color_2454 = heff_dup(v_color_240);
      V v_x2_2455 = v_f_2453;
      switch (heff_tag_of(v_x2_2455)) {
      case TAG_FailBecause: {
        V v_why_2456 = heff_field(v_x2_2455, 0);
        heff_take_n(v_x2_2455, 1ULL, 1);
        heff_drop(v_color_2454);
        v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str31), v_why_2456), NTAG(TAG_Nil)});
        break;
      }
      case TAG_FailDiffer: {
        V v_expected_2457 = heff_field(v_x2_2455, 0);
        V v_got_2458 = heff_field(v_x2_2455, 1);
        V v_ru_24x2_2455_24FailDiffer = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
        V v_m_2459 = ({ V a_0 = v_color_2454; V a_1 = v_expected_2457; V a_2 = v_got_2458; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_color_2454); heff_drop(v_expected_2457); heff_drop(v_got_2458); r_; });
        V v_expected_2460 = heff_take_field(v_m_2459, 0);
        V v_got_2461 = heff_take_field(v_m_2459, 1);
        V v_diff_2462 = heff_get_n(v_m_2459, 2, 3);
        V v_t_2463 = heff_tag_at_n(v_ru_24x2_2455_24FailDiffer, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str32), v_diff_2462), NTAG(TAG_Nil)});
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str33), v_got_2461), v_t_2463});
        v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str34), v_expected_2460), v_t_2464});
        break;
      }
      default: heff_nomatch(v_x2_2455);
      }
      break;
    }
    default: heff_nomatch(v_t_2452);
    }
    V v_x2_2466 = (g_prelude_2e_2b_2b(v_t_2451, v_t_2465));
    V v_str_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_str_2469 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_str_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str36); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_t_2470 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2469, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str37)), NTAG(TAG_MkUnit)});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
    v_c_2477 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
  }
  V f_ = v_c_2477;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam1(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_str_2436 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2436, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_str29)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  args[0] = v_t_2446;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2437, v_rest_245, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V v_tok_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2418 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_s_2418});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2427 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse_n(v_j_241, 1ULL, 1);
      HeffT2 v_t_2428 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2427); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_p_2431 = v_field_2430;
          V v_t_2434;
          switch (heff_tag_of(v_p_2431)) {
          case TAG_MkPair: {
            V v_y_2433 = heff_field(v_p_2431, 1);
            heff_take_n(v_p_2431, 2ULL, 2);
            v_t_2434 = v_y_2433;
            break;
          }
          default: heff_nomatch(v_p_2431);
          }
          switch (heff_tag_of(v_t_2434)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2439 = heff_field(v_t_2434, 0);
            heff_take_n(v_t_2434, 1ULL, 1);
            switch (heff_tag_of(v_xs_2439)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_241_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2440 = heff_field(v_xs_2439, 0);
              V v_it12_2441 = heff_field(v_xs_2439, 1);
              V v_ru_24xs_2439_24Cons = heff_take_reuse_n(v_xs_2439, 3ULL, 2);
              switch (heff_tag_of(v_it12_2441)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_241_24JObject, 1);
                heff_drop(v_expected_2440);
                heff_drop_cell(v_ru_24xs_2439_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2442 = heff_field(v_it12_2441, 0);
                heff_take_n(v_it12_2441, 1ULL, 2);
                V v_t_2450;
                switch (heff_tag_of(v_expected_2440)) {
                case TAG_JNull: {
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2447 = heff_field(v_expected_2440, 0);
                  heff_take_n(v_expected_2440, 1ULL, 1);
                  v_t_2450 = v_t_2447;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2440);
                }
                V v_t_2457;
                switch (heff_tag_of(v_got_2442)) {
                case TAG_JNull: {
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2454 = heff_field(v_got_2442, 0);
                  heff_take_n(v_got_2442, 1ULL, 1);
                  v_t_2457 = v_t_2454;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13);
                  break;
                }
                default: heff_nomatch(v_got_2442);
                }
                return heff_tag_at_n(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2439_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2450, v_t_2457})});
              }
              default: return heff_nomatch(v_it12_2441);
              }
            }
            default: return heff_nomatch(v_xs_2439);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2434);
          }
        } else {
          heff_drop_cell(v_ru_24j_241_24JObject, 1);
          heff_drop(v_field_2430);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_241);
    }
  }
  case TAG_Just: {
    V v_why_2459 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    heff_drop(v_j_241);
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2459})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(a[0], a[1]);
}