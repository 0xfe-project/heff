// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkRegex 19093
#define TAG_Open 48267
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Start 63542
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_limit 304334805
#define LBL_loaded 849622832
#define LBL_next 9873338
#define LBL_order 307364712
#define LBL_outcome 1272833429
#define LBL_outcomes 803130769
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_place 308106529
#define LBL_reports 1326460931
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_threads 1041404398
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_watches 1357821955
#define LBL_wrong 314763719
static uint32_t shape_file__wrong__reports__outcomes__integrations__loaded__checked[] = {LBL_file, LBL_wrong, LBL_reports, LBL_outcomes, LBL_integrations, LBL_loaded, LBL_checked};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_outcomes__integrations[] = {LBL_outcomes, LBL_integrations};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_seen__threads[] = {LBL_seen, LBL_threads};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(V, V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2edriver_2eaddTests(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eaddTests_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2epickIntegrations(V, V, V);
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo;
V g_heff_2ebuild_2edriver_2epickOutcomes(V, V, V, V);
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2etestsOf(V);
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestsOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
V g_heff_2ebuild_2etesting_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2etesting_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranOutcome_clo;
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_clo;
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_clo;
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo;
V g_heff_2ebuild_2etesting_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestArgs_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_clo;
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_clo;
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287(V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_clo;
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V, V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s344878118x1065108086(V, V, V);
V g_list_2efoldl_24s344878118x1065108086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s344878118x1065108086_clo;
V g_list_2ekeepIf_24s742867582x682687968(V, V);
V g_list_2ekeepIf_24s742867582x682687968_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1848188369x464661008(V, V);
V g_list_2emergeRuns_24s1848188369x464661008_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1848188369x464661008_clo;
V g_list_2erunFrom_24s272018256x1228369023(V, V);
V g_list_2erunFrom_24s272018256x1228369023_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s272018256x1228369023_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2egather(V, V, V, V, V, V);
V g_regex_2egather_entry(V self, V *a);
extern Clo g_regex_2egather_clo;
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_regex_2erunFrom(V, V, V, V, V, V);
V g_regex_2erunFrom_entry(V self, V *a);
extern Clo g_regex_2erunFrom_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2etesting_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_files_242 = heff_take_field(v_b_241, 0);
  V v_expectErrors_243 = heff_take_field(v_b_241, 1);
  V v_total_244 = heff_take_field(v_b_241, 2);
  V v_failed_245 = heff_take_field(v_b_241, 3);
  V v_unchecked_246 = heff_take_field(v_b_241, 4);
  V v_tests_247 = heff_take_field(v_b_241, 5);
  V v_testsFailed_248 = heff_take_field(v_b_241, 6);
  V v_testsSkipped_249 = heff_get_n(v_b_241, 7, 8);
  V v_files_2410 = heff_take_field(v_a_240, 0);
  V v_expectErrors_2411 = heff_take_field(v_a_240, 1);
  V v_total_2412 = heff_take_field(v_a_240, 2);
  V v_failed_2413 = heff_take_field(v_a_240, 3);
  V v_unchecked_2414 = heff_take_field(v_a_240, 4);
  V v_tests_2415 = heff_take_field(v_a_240, 5);
  V v_testsFailed_2416 = heff_take_field(v_a_240, 6);
  V v_testsSkipped_2417 = heff_get_n(v_a_240, 7, 8);
  V v_t_2418 = (g_prelude_2e_2b_2b(v_unchecked_2414, v_unchecked_246));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){heff_intAdd(v_files_2410, v_files_242), heff_intAdd(v_expectErrors_2411, v_expectErrors_243), heff_intAdd(v_total_2412, v_total_244), heff_intAdd(v_failed_2413, v_failed_245), v_t_2418, heff_intAdd(v_tests_2415, v_tests_247), heff_intAdd(v_testsFailed_2416, v_testsFailed_248), heff_intAdd(v_testsSkipped_2417, v_testsSkipped_249)});
}
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eaddRes(a[0], a[1]);
}

static V g_heff_2ebuild_2etesting_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectedRes_st;
static V g_heff_2ebuild_2etesting_2eexpectedRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectedRes_st)) return g_heff_2ebuild_2etesting_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectedRes_val, &g_heff_2ebuild_2etesting_2eexpectedRes_st, g_heff_2ebuild_2etesting_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2etesting_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = ({ V a_0 = v_t_241; V b_1 = ((V)&g_heff_2ebuild_2etesting_2elastLines_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2elastLines_str1), v_t_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2etesting_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elastLines(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_x1_246 = heff_dup(v_r_242);
      V v_s_247 = heff_dup(v_n_244);
      V v_from_248 = MK_INT(0LL);
      V v_t_2418;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_MkRegex: {
        V v_prog_249 = heff_field(v_x1_246, 0);
        V v_groups_2410 = heff_field(v_x1_246, 1);
        heff_take_n(v_x1_246, 3ULL, 2);
        V v_t_2411 = heff_intAdd(heff_intMul(MK_INT(2LL), v_groups_2410), MK_INT(2LL));
        V v_fresh_2412 = heff_arrayReplicate(v_t_2411, MK_INT(-1LL));
        V v_t_2413 = heff_arrayReplicate(heff_arrayLength_lent(v_prog_249, 0), NTAG(TAG_False));
        V v_t_2414 = heff_rec_n(2, shape_seen__threads, (V[]){v_t_2413, NTAG(TAG_Nil)});
        V v_t_2415 = (g_regex_2egather(v_prog_249, v_s_247, heff_dup(v_from_248), MK_INT(0LL), heff_dup(v_fresh_2412), v_t_2414));
        V v_xs_2416 = heff_get_n(v_t_2415, 1, 2);
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
        v_t_2418 = ({ V a_0 = v_prog_249; V a_1 = v_fresh_2412; V a_2 = v_s_247; V a_3 = v_from_248; V a_4 = v_t_2417; V a_5 = NTAG(TAG_Nothing); V r_ = (g_regex_2erunFrom(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_prog_249); heff_drop(v_s_247); r_; });
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_2418, 0ULL, 1);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str0, 46, "heff test: --watch is not given with --update\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str2, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str5, 4, "test");
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_entry, 6, 0};

V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615(V v_e_240, V v_seed_241, V v_pattern_242, V v_jobs_243, V v_x4_244, V v_given_245) {
top: ;
  if ((heff_dup(v_x4_244) == NTAG(TAG_True))) {
    heff_drop(v_given_245);
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam0, 2, 1, (V[]){v_e_240});
  } else {
    V v_c_2423 = (g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(heff_dup(v_e_240), v_seed_241, v_pattern_242, v_jobs_243, NTAG(TAG_False)));
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam2, 2, 6, (V[]){v_c_2423, v_e_240, v_given_245, heff_dup(v_seed_241), heff_dup(v_pattern_242), heff_dup(v_jobs_243)});
  }
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615(a[0], a1, a2, a3, a4, a[5]); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str0), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam1, 1, 3, (V[]){v_e_240, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam5(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam8(V self, V *args) {
  V v_x_2448 = args[0];
  V v_given_245 = heff_env(self)[0];
  V v_seed_241 = heff_env(self)[1];
  V v_pattern_242 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_2438 = heff_env(self)[5];
  V v_x_2446 = heff_env(self)[6];
  V v_hd_2424 = heff_env(self)[7];
  V v_k_2425 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2451;
  switch (heff_tag_of(v_given_245)) {
  case TAG_Nil: {
    v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str5), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_t_2451 = (g_prelude_2e_2b_2b(heff_dup(v_given_245), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_245);
  }
  V v_t_2452 = ({ V a_0 = v_seed_241; V a_1 = v_pattern_242; V a_2 = v_jobs_243; V a_3 = v_given_245; V r_ = (g_heff_2ebuild_2etesting_2etestArgs(a_0, a_1, a_2, a_3)); heff_drop(v_seed_241); heff_drop(v_pattern_242); heff_drop(v_jobs_243); r_; });
  V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_clo), 2, (V[]){heff_dup(v_e_240), v_t_2452}));
  return ({ V a_0 = v_e_240; V a_1 = v_st_2438; V a_2 = v_t_2451; V a_3 = v_t_2453; V a_4 = v_x_2446; V a_5 = v_x_2448; V a_6 = v_hd_2424; V a_7 = v_k_2425; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1928229440x67858440(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2446); heff_drop(v_k_2425); r_; });
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_pattern_242 = heff_env(self)[1];
  V v_jobs_243 = heff_env(self)[2];
  V v_given_245 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_2424 = heff_env(self)[5];
  V v_st_2438 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2446;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Nil: {
    v_x_2446 = ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2444 = heff_field(v_x_2443, 0);
    V v_xs_2445 = heff_field(v_x_2443, 1);
    heff_take_n(v_x_2443, 3ULL, 2);
    v_x_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str4); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  V v_t_2447 = (g_heff_2ebuild_2etesting_2etestArgs(v_seed_241, v_pattern_242, v_jobs_243, heff_dup(v_given_245)));
  return (g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451(heff_dup(v_e_240), v_t_2447, MK_INT(0LL), heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam8, 1, 9, (V[]){v_given_245, v_seed_241, v_pattern_242, v_jobs_243, v_e_240, v_st_2438, v_x_2446, v_hd_2424, v_k_2425})));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_given_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_pattern_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2438;
  if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str1))) {
    v_st_2438 = NTAG(TAG_Windows);
  } else {
    v_st_2438 = NTAG(TAG_Posix);
  }
  V v_paths_2441;
  switch (heff_tag_of(v_given_245)) {
  case TAG_Nil: {
    v_paths_2441 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_str2), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_paths_2441 = (g_prelude_2e_2b_2b(heff_dup(v_given_245), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_245);
  }
  V v_c_2442 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(heff_dup(v_e_240), heff_dup(v_st_2438), NTAG(TAG_Nil), v_paths_2441));
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam7, 1, 8, (V[]){v_seed_241, v_pattern_242, v_jobs_243, v_given_245, v_e_240, v_hd_2424, v_st_2438, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_given_245 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_pattern_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2428);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam5_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2436, heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam6, 1, 7, (V[]){v_given_245, v_e_240, v_hd_2424, v_seed_241, v_pattern_242, v_jobs_243, v_k_2425})));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_given_245 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_pattern_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2426);
  V v_c_2427 = (g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(heff_dup(v_e_240), heff_dup(v_given_245)));
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam4, 1, 7, (V[]){v_e_240, v_hd_2424, v_given_245, v_seed_241, v_pattern_242, v_jobs_243, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_given_245 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_pattern_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_lam3, 1, 7, (V[]){v_e_240, v_given_245, v_hd_2424, v_seed_241, v_pattern_242, v_jobs_243, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str1, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str2, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str3, 8, "subtests");
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam0, 3, 0};
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam3(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam3, 3, 0};
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam5, 3, 0};
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_entry, 5, 0};

V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(V v_e_240, V v_sel_241, V v_j_242, V v_dir_243, V v_ran_244) {
top: ;
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_243)));
  V v_c_246 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_245; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_245); r_; });
  V v_t_247 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2411 = heff_tr(heff_call(v_c_246, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam1, 2, 6, (V[]){v_c_2411, v_dir_243, v_e_240, v_j_242, v_ran_244, heff_dup(v_sel_241)});
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_j_242 = heff_env(self)[0];
  V v_ran_244 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sel_241 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str2), heff_dup(heff_rfield(v_j_242, 3)), heff_rfield(v_j_242, 4)));
  V v_t_2435 = (g_heff_2ebuild_2etesting_2eranOutcome(v_t_2434, heff_dup(heff_rfield(v_j_242, 5)), v_ran_244, heff_dup(v_x_2425)));
  V v_t_2463;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_text_2436 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    V v_t_2437 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_2438 = (g_json_2esteps_24cpr(v_text_2436, v_t_2437));
    {
      V v_field_2440 = v_t_2438.f[1];
      int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
      if ((v_tag_2439 == ((int64_t)0ULL))) {
        V v_why_2441 = v_field_2440;
        heff_drop(v_why_2441);
        v_t_2463 = NTAG(TAG_Nil);
      } else {
        V v_j_2442 = v_field_2440;
        V v_t_2462;
        switch (heff_tag_of(v_j_2442)) {
        case TAG_JNull: {
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_j_2442, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_j_2442, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_j_2442, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_j_2442, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_j_2442, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JObject: {
          V v_fs_2448 = heff_field(v_j_2442, 0);
          heff_take_n(v_j_2442, 1ULL, 1);
          HeffT2 v_t_2449 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str3); V a_1 = v_fs_2448; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2448); r_; });
          {
            V v_field_2451 = v_t_2449.f[1];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            if ((v_tag_2450 == ((int64_t)0ULL))) {
              V v_p_2452 = v_field_2451;
              V v_t_2455;
              switch (heff_tag_of(v_p_2452)) {
              case TAG_MkPair: {
                V v_y_2454 = heff_field(v_p_2452, 1);
                heff_take_n(v_p_2452, 2ULL, 2);
                v_t_2455 = v_y_2454;
                break;
              }
              default: heff_nomatch(v_p_2452);
              }
              switch (heff_tag_of(v_t_2455)) {
              case TAG_JNull: {
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_t_2455, 0ULL, 1);
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_t_2455, 0ULL, 1);
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_t_2455, 0ULL, 1);
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_t_2455, 0ULL, 1);
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_JArray: {
                V v_xs_2460 = heff_field(v_t_2455, 0);
                heff_take_n(v_t_2455, 1ULL, 1);
                v_t_2462 = v_xs_2460;
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_t_2455, 0ULL, 1);
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              default: heff_nomatch(v_t_2455);
              }
            } else {
              heff_drop(v_field_2451);
              v_t_2462 = NTAG(TAG_Nil);
            }
          }
          break;
        }
        default: heff_nomatch(v_j_2442);
        }
        v_t_2463 = (g_list_2emap_24s1113395621x248103432(v_t_2462));
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2464 = ({ V a_0 = v_sel_241; V a_1 = heff_dup(v_j_242); V a_2 = MK_INT(0LL); V a_3 = v_t_2463; V r_ = (g_heff_2ebuild_2etesting_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_241); r_; });
  V v_x_2465 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_242, 0), heff_get_n(v_j_242, 2, 6), v_t_2435, v_t_2464});
  V f_ = v_k_2413;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_ran_244 = heff_env(self)[4];
  V v_sel_241 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_x_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_x_2425 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Just, 1, (V[]){v_y_2424});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_dir_243, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str1))));
  V v_c_2427 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2426; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2426); r_; });
  V v_t_2428 = (g_exception_2eattempted(v_e_240));
  V v_c_2432 = heff_tr(heff_call(v_c_2427, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam5_clo)}));
  V f_ = v_c_2432;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam6, 1, 5, (V[]){v_j_242, v_ran_244, v_x_2425, v_sel_241, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_ran_244 = heff_env(self)[4];
  V v_sel_241 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2414);
  V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_dir_243), ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_str0))));
  V v_c_2416 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2415; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2415); r_; });
  V v_t_2417 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2421 = heff_tr(heff_call(v_c_2416, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam3_clo)}));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam4, 1, 7, (V[]){v_dir_243, v_e_240, v_hd_2412, v_j_242, v_ran_244, v_sel_241, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_dir_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_ran_244 = heff_env(self)[4];
  V v_sel_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_lam2, 1, 7, (V[]){v_dir_243, v_e_240, v_hd_2412, v_j_242, v_ran_244, v_sel_241, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_entry, 7, 0};

V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615(V v_e_240, V v_opts_241, V v_done_242, V v_x3_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_done_242);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){v_acc_244});
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_x3_243, 0);
    V v_rest_248 = heff_field(v_x3_243, 1);
    V v_pending_249 = heff_dup(heff_rfield(v_r_247, 1));
    V v_at_2410 = heff_dup(heff_rfield(v_r_247, 0));
    V v_p_2411 = v_pending_249;
    V v_file_2412 = heff_take_field(v_p_2411, 0);
    V v_outcomes_2413 = heff_take_field(v_p_2411, 3);
    V v_wrong_2414 = heff_take_field(v_p_2411, 1);
    V v_reports_2415 = heff_get_n(v_p_2411, 2, 7);
    V v_x2_2416 = (g_list_2ekeepIf_24s742867582x682687968(v_at_2410, heff_dup(v_done_242)));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_t_2419 = (g_list_2erunFrom_24s272018256x1228369023(v_x_2417, v_xs_2418));
      v_t_2420 = (g_list_2emergeRuns_24s1848188369x464661008(NTAG(TAG_Nil), v_t_2419));
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_more_2421 = (g_list_2emap_24s1498757180x165099811(v_t_2420));
    V v_t_2422 = (g_prelude_2e_2b_2b(v_outcomes_2413, v_more_2421));
    V v_c_2423 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_241, 3), heff_dup(v_file_2412), v_t_2422));
    V v_k_2426 = heff_clo_n(g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam0, 1, 7, (V[]){v_acc_244, heff_dup(v_e_240), heff_dup(v_opts_241), v_done_242, heff_dup(v_rest_248), heff_dup(v_z_245), v_z_246});
    return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam1, 1, 7, (V[]){v_opts_241, v_k_2426, v_e_240, v_file_2412, v_wrong_2414, v_reports_2415, v_z_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2425 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_244, v_x_2424));
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_done_242; V a_3 = v_rest_248; V a_4 = v_t_2425; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rest_248); r_; });
}
V g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_file_2412 = heff_env(self)[3];
  V v_wrong_2414 = heff_env(self)[4];
  V v_reports_2415 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_2427)));
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2427);
    heff_drop(v_e_240);
    heff_drop(v_file_2412);
    heff_drop(v_wrong_2414);
    heff_drop(v_reports_2415);
    heff_drop(v_z_245);
    heff_drop(v_t_2428);
    V f_ = v_k_2426;
    args[0] = heff_dup(g_heff_2ebuild_2etesting_2enoRes_get());
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2428);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, v_file_2412, v_wrong_2414, v_reports_2415, v_x_2427, v_z_245, v_k_2426));
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_str1, 0, "");
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_entry, 6, 0};

V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307(V v_e_240, V v_opts_241, V v_ready_242, V v_acc_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_ready_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam1, 1, 6, (V[]){v_e_240, v_p_244, v_opts_241, v_ready_242, v_acc_243, v_p_245})));
  }
  default: return heff_nomatch(v_ready_242);
  }
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam2(V self, V *args) {
  V v_i_2412 = args[0];
  return v_i_2412;
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_ready_242 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2435);
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_x_2428; V a_3 = v_ready_242; V a_4 = v_acc_243; V a_5 = v_p_244; V a_6 = v_p_245; V r_ = (g_heff_2ebuild_2etesting_2ereportReady_24s656643775x1647117615(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_ready_242, 2); r_; });
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  V v_ready_242 = heff_env(self)[5];
  V v_acc_243 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam6, 1, 7, (V[]){v_e_240, v_opts_241, v_x_2428, v_ready_242, v_acc_243, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_ready_242 = heff_env(self)[5];
  V v_acc_243 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2429 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam5, 1, 8, (V[]){v_x_2411, v_e_240, v_p_244, v_opts_241, v_x_2428, v_ready_242, v_acc_243, v_p_245})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_ready_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_p_2417 = heff_dup(heff_rfield(v_opts_241, 1));
  V v_t_2425;
  if (heff_strEq_c_lent(v_p_2417, ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_str1), 2)) {
    heff_drop(v_p_2417);
    v_t_2425 = NTAG(TAG_Nil);
  } else {
    V v_t_2418 = ({ V a_0 = v_p_2417; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2417); r_; });
    V v_t_2419 = (g_list_2emap_24s1007499915x73800978(v_t_2418));
    HeffT2 v_t_2420 = (g_regex_2eallRead_24cpr(v_t_2419));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_why_2423 = v_field_2422;
        heff_drop(v_why_2423);
        v_t_2425 = NTAG(TAG_Nil);
      } else {
        V v_sel_2424 = v_field_2422;
        v_t_2425 = v_sel_2424;
      }
    }
  }
  V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_242)));
  V v_t_2427 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl_24s344878118x1065108086(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
  return (g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(heff_dup(v_x_2416), heff_dup(v_e_240), v_t_2425, heff_dup(heff_rfield(v_opts_241, 2)), v_t_2427, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam4, 1, 8, (V[]){v_x_2416, v_e_240, v_p_244, v_x_2411, v_opts_241, v_ready_242, v_acc_243, v_p_245})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_ready_242 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_lam3, 1, 7, (V[]){v_opts_241, v_ready_242, v_e_240, v_p_244, v_x_2411, v_acc_243, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str0, 7, "> test ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str2, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str4, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str6, 13, ": not checked");
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam0(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776(V v_e_240, V v_opts_241, V v_f_242, V v_l_243, V v_cs_244, V v_z_245, V v_z_246) {
top: ;
  V v_pattern_247 = heff_take_field(v_opts_241, 1);
  V v_seed_248 = heff_get_n(v_opts_241, 0, 4);
  V v_c_249 = (g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(heff_dup(v_e_240), v_cs_244));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam0, 1, 8, (V[]){heff_dup(v_cs_244), v_l_243, v_pattern_247, v_seed_248, v_f_242, v_z_246, v_e_240, v_z_245})});
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam1(V self, V *args) {
  V v_acc_2431 = args[0];
  V v_k_2432 = args[1];
  V v_entries_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2433 = ({ V a_0 = v_entries_2429; V a_1 = v_k_2432; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2429); r_; });
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_e_2436 = v_field_2435;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2432, v_e_2436}), v_acc_2431});
    } else {
      heff_drop(v_k_2432);
      heff_drop(v_field_2435);
      return v_acc_2431;
    }
  }
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam2(V self, V *args) {
  V v_w_2446 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2414, v_w_2446));
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam3(V self, V *args) {
  V v_w_2467 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2414, v_w_2467));
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam4(V self, V *args) {
  V v_x_2480 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_cs_244 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2480);
  V v_t_2481 = heff_get_n(v_l_243, 1, 5);
  V v_why_2488;
  switch (heff_tag_of(v_t_2481)) {
  case TAG_Nil: {
    HeffT2 v_t_2482 = ({ V a_0 = v_cs_244; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_244); r_; });
    {
      V v_field_2484 = v_t_2482.f[1];
      int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
      if ((v_tag_2483 == ((int64_t)0ULL))) {
        heff_drop(v_f_242);
        V v_x_2485 = v_field_2484;
        v_why_2488 = v_x_2485;
      } else {
        heff_drop(v_field_2484);
        v_why_2488 = heff_strAppend(v_f_242, ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str6));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2486 = heff_field(v_t_2481, 0);
    heff_take_n(v_t_2481, 1ULL, 2);
    heff_drop(v_cs_244);
    heff_drop(v_f_242);
    v_why_2488 = v_why_2486;
    break;
  }
  default: heff_nomatch(v_t_2481);
  }
  V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2488, NTAG(TAG_Nil)});
  V v_x_2490 = heff_tag_n(TAG_Settled, 1, (V[]){heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2489, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)})});
  V f_ = v_z_246;
  args[0] = v_x_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_244 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  V v_pattern_247 = heff_env(self)[2];
  V v_seed_248 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_244));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_e_240);
      heff_drop(v_z_245);
      V v_c_2414 = v_field_2413;
      V v_t_2415 = heff_dup(heff_rfield(v_l_243, 1));
      V v_t_2418;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nil: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2415, 0ULL, 2);
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      V v_x_2471;
      if (((heff_dup(v_t_2418) == NTAG(TAG_True)) && heff_intEq_c_lent(v_x_2410, MK_INT(0LL), 2))) {
        heff_drop(v_x_2410);
        heff_drop(v_cs_244);
        heff_drop(v_t_2418);
        V v_pattern_2419 = heff_dup(v_pattern_247);
        V v_seed_2420 = v_seed_248;
        V v_c_2421 = heff_dup(v_c_2414);
        V v_x1_2422 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_c_2421)));
        V v_run_2441;
        switch (heff_tag_of(v_x1_2422)) {
        case TAG_Nil: {
          heff_drop(v_pattern_2419);
          heff_drop(v_seed_2420);
          heff_drop_rec(v_c_2421, 14);
          v_run_2441 = heff_rec_n(2, shape_outcomes__integrations, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2422, 0ULL, 2);
          V v_ts_2425 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_c_2421)));
          V v_t_2426 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_c_2421)));
          V v_t_2427 = heff_get_n(heff_get_n(v_c_2421, 5, 14), 0, 10);
          V v_gs_2428 = (g_heff_2ebuild_2edriver_2eaddTests(v_pattern_2419, heff_dup(v_seed_2420), MK_INT(0LL), v_t_2426, v_t_2427));
          V v_entries_2429 = heff_take_field(v_gs_2428, 1);
          V v_order_2430 = heff_get_n(v_gs_2428, 0, 8);
          V v_t_2437 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam1, 2, 1, (V[]){v_entries_2429}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_2430); r_; });
          V v_rs_2438 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(7LL); V b_2 = ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str0); V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); V a_4 = v_t_2437; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631(b_0, b_1, b_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
          V v_t_2439 = (g_heff_2ebuild_2edriver_2epickOutcomes(v_seed_2420, v_rs_2438, MK_INT(0LL), v_ts_2425));
          V v_t_2440 = ({ V a_0 = v_rs_2438; V a_1 = MK_INT(0LL); V a_2 = v_ts_2425; V r_ = (g_heff_2ebuild_2edriver_2epickIntegrations(a_0, a_1, a_2)); heff_drop(v_rs_2438); heff_drop(v_ts_2425); r_; });
          v_run_2441 = heff_rec_n(2, shape_outcomes__integrations, (V[]){v_t_2439, v_t_2440});
          break;
        }
        default: heff_nomatch(v_x1_2422);
        }
        V v_outcomes_2442 = heff_take_field(v_run_2441, 0);
        V v_integrations_2443 = heff_get_n(v_run_2441, 1, 2);
        V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 4, 10);
        V v_t_2445 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2414), v_t_2444));
        V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam2, 1, 1, (V[]){heff_dup(v_c_2414)}), v_t_2445));
        V v_t_2448 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2447));
        V v_p_2449 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, NTAG(TAG_Nil), v_t_2448, v_outcomes_2442, v_integrations_2443, v_l_243, v_c_2414});
        if (!heff_strEq_c_lent(v_pattern_247, ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str1), 2)) {
          heff_drop(v_pattern_247);
          V v_t_2450 = heff_dup(heff_rfield(v_p_2449, 3));
          switch (heff_tag_of(v_t_2450)) {
          case TAG_Nil: {
            V v_t_2451 = heff_dup(heff_rfield(v_p_2449, 4));
            switch (heff_tag_of(v_t_2451)) {
            case TAG_Nil: {
              heff_drop_rec(v_p_2449, 7);
              v_x_2471 = heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_t_2451, 0ULL, 2);
              v_x_2471 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2449});
              break;
            }
            default: heff_nomatch(v_t_2451);
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_t_2450, 0ULL, 2);
            v_x_2471 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2449});
            break;
          }
          default: heff_nomatch(v_t_2450);
          }
        } else {
          heff_drop(v_pattern_247);
          v_x_2471 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2449});
        }
      } else {
        heff_drop(v_x_2410);
        heff_drop(v_pattern_247);
        heff_drop(v_seed_248);
        heff_drop(v_t_2418);
        V v_t_2456 = heff_dup(heff_rfield(v_l_243, 1));
        V v_t_2463;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_Nil: {
          HeffT2 v_t_2457 = ({ V a_0 = v_cs_244; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_244); r_; });
          {
            V v_field_2459 = v_t_2457.f[1];
            int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
            if ((v_tag_2458 == ((int64_t)0ULL))) {
              V v_x_2460 = v_field_2459;
              v_t_2463 = v_x_2460;
            } else {
              heff_drop(v_field_2459);
              v_t_2463 = heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str2));
            }
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2461 = heff_field(v_t_2456, 0);
          heff_take_n(v_t_2456, 1ULL, 2);
          heff_drop(v_cs_244);
          v_t_2463 = v_why_2461;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        V v_wrong_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
        V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 4, 10);
        V v_t_2466 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2414), v_t_2465));
        V v_t_2468 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam3, 1, 1, (V[]){heff_dup(v_c_2414)}), v_t_2466));
        V v_t_2469 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2468));
        V v_t_2470 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, v_wrong_2464, v_t_2469, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_243, v_c_2414});
        v_x_2471 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2470});
      }
      V f_ = v_z_246;
      args[0] = v_x_2471;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_pattern_247);
      heff_drop(v_seed_248);
      heff_drop(v_field_2413);
      V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str3), heff_dup(v_f_242)), ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str4));
      V v_t_2473 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_str5)), NTAG(TAG_MkUnit)});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_lam4, 1, 4, (V[]){v_l_243, v_cs_244, v_f_242, v_z_246})));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str3, 1, "\012");
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam0, 3, 0};
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_entry, 3, 0};

V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287(V v_e_240, V v_opts_241, V v_f_242) {
top: ;
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_242)));
  V v_c_244 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_243; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_243); r_; });
  V v_t_245 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_249 = heff_tr(heff_call(v_c_244, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam1, 2, 4, (V[]){v_c_249, v_e_240, v_f_242, v_opts_241});
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_j_2415 = heff_strFind(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str0), ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str1), MK_INT(0LL));
  V v_t_2416;
  if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
    heff_drop(v_j_2415);
    v_t_2416 = MK_INT(0LL);
  } else {
    v_t_2416 = v_j_2415;
  }
  V v_t_2417 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str2), MK_INT(0LL), v_t_2416, 3), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_t_2416);
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_t_2417; V a_4 = v_x_2414; V a_5 = v_hd_2410; V a_6 = v_k_2411; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_y_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_d_2420 = heff_strLength_lent(v_y_2418, 0);
  V v_j_2421 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_str3), v_y_2418, MK_INT(0LL), 5);
  V v_t_2422;
  if (heff_intLt_c_lent(v_j_2421, MK_INT(0LL), 2)) {
    heff_drop(v_j_2421);
    v_t_2422 = v_d_2420;
  } else {
    heff_drop(v_d_2420);
    v_t_2422 = v_j_2421;
  }
  V v_t_2423 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2418, MK_INT(0LL), v_t_2422, 2), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_y_2418);
  heff_drop(v_t_2422);
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_t_2423; V a_4 = v_x_2419; V a_5 = v_hd_2410; V a_6 = v_k_2411; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2423); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_f_242), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam3, 1, 5, (V[]){v_e_240, v_opts_241, v_f_242, v_hd_2410, v_k_2411})));
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_f_242), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam4, 1, 6, (V[]){v_y_2418, v_e_240, v_opts_241, v_f_242, v_hd_2410, v_k_2411})));
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_lam2, 1, 5, (V[]){v_e_240, v_f_242, v_hd_2410, v_opts_241, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V v_tok_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2418 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_s_2418});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2427 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse_n(v_j_241, 1ULL, 1);
      HeffT2 v_t_2428 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2427); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_p_2431 = v_field_2430;
          V v_t_2434;
          switch (heff_tag_of(v_p_2431)) {
          case TAG_MkPair: {
            V v_y_2433 = heff_field(v_p_2431, 1);
            heff_take_n(v_p_2431, 2ULL, 2);
            v_t_2434 = v_y_2433;
            break;
          }
          default: heff_nomatch(v_p_2431);
          }
          switch (heff_tag_of(v_t_2434)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2439 = heff_field(v_t_2434, 0);
            heff_take_n(v_t_2434, 1ULL, 1);
            switch (heff_tag_of(v_xs_2439)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_241_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2440 = heff_field(v_xs_2439, 0);
              V v_it12_2441 = heff_field(v_xs_2439, 1);
              V v_ru_24xs_2439_24Cons = heff_take_reuse_n(v_xs_2439, 3ULL, 2);
              switch (heff_tag_of(v_it12_2441)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_241_24JObject, 1);
                heff_drop(v_expected_2440);
                heff_drop_cell(v_ru_24xs_2439_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2442 = heff_field(v_it12_2441, 0);
                heff_take_n(v_it12_2441, 1ULL, 2);
                V v_t_2450;
                switch (heff_tag_of(v_expected_2440)) {
                case TAG_JNull: {
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2447 = heff_field(v_expected_2440, 0);
                  heff_take_n(v_expected_2440, 1ULL, 1);
                  v_t_2450 = v_t_2447;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2440);
                }
                V v_t_2457;
                switch (heff_tag_of(v_got_2442)) {
                case TAG_JNull: {
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2454 = heff_field(v_got_2442, 0);
                  heff_take_n(v_got_2442, 1ULL, 1);
                  v_t_2457 = v_t_2454;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13);
                  break;
                }
                default: heff_nomatch(v_got_2442);
                }
                return heff_tag_at_n(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2439_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2450, v_t_2457})});
              }
              default: return heff_nomatch(v_it12_2441);
              }
            }
            default: return heff_nomatch(v_xs_2439);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2434);
          }
        } else {
          heff_drop_cell(v_ru_24j_241_24JObject, 1);
          heff_drop(v_field_2430);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_241);
    }
  }
  case TAG_Just: {
    V v_why_2459 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    heff_drop(v_j_241);
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2459})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(a[0], a[1]);
}