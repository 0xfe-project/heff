// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Binds 36386
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EStr 50587
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_OSimple 59809
#define TAG_PatVar 49363
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SSet 8516
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_alias 294261354
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_flags 298871457
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_l 326
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_params 951713969
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_result 1012715336
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_v 336
#define LBL_value 313331083
#define LBL_watch 314261737
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_value__ty__size__flags__span[] = {LBL_value, LBL_ty, LBL_size, LBL_flags, LBL_span};
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edriver_2eintegrationOfV(V);
V g_heff_2ebuild_2edriver_2eintegrationOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eintegrationOfV_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2etwiceDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2easLent(V, V);
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2easLent_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2elazyOf(V, V, V);
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2elazyOf_clo;
V g_heff_2ecompile_2efuse_2etailsOf(V);
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etailsOf_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2eowned_2eokArg(V, V, V);
V g_heff_2ecompile_2eowned_2eokArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokArg_clo;
V g_heff_2ecompile_2eranges_2earityOne(V, V);
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earityOne_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2escalars_2emergeTy(V, V);
V g_heff_2ecompile_2escalars_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2emergeTy_clo;
V g_heff_2ecompile_2esimplify_2ecopyField(V);
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyField_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2eunbox_2eslotFor(V, V, V);
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotFor_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2erules_2epatternCanFail(V, V);
V g_heff_2eelab_2erules_2epatternCanFail_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epatternCanFail_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eall_24s418009941x978041577(V, V, V, V);
V g_list_2eall_24s418009941x978041577_entry(V self, V *a);
extern Clo g_list_2eall_24s418009941x978041577_clo;
V g_list_2eall_24s743242824x1965727204(V);
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a);
extern Clo g_list_2eall_24s743242824x1965727204_clo;
V g_list_2eall_24s751274328x395946890(V, V, V);
V g_list_2eall_24s751274328x395946890_entry(V self, V *a);
extern Clo g_list_2eall_24s751274328x395946890_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1299427137x1247694659(V, V);
V g_list_2eany_24s1299427137x1247694659_entry(V self, V *a);
extern Clo g_list_2eany_24s1299427137x1247694659_clo;
V g_list_2eany_24s2037198014x392734282(V, V);
V g_list_2eany_24s2037198014x392734282_entry(V self, V *a);
extern Clo g_list_2eany_24s2037198014x392734282_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2eany_24s464681941x898021545(V, V);
V g_list_2eany_24s464681941x898021545_entry(V self, V *a);
extern Clo g_list_2eany_24s464681941x898021545_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1986081631x104660098_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f319030394x1380151895(V, V, V);
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a);
extern Clo g_list_2efoldl_24f319030394x1380151895_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1056451377x727850182(V, V);
V g_list_2efoldl_24s1056451377x727850182_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1056451377x727850182_clo;
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1433066060x138395605(V, V);
V g_list_2efoldl_24s1433066060x138395605_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1433066060x138395605_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1722165992x1349408496(V, V);
V g_list_2efoldl_24s1722165992x1349408496_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722165992x1349408496_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s324619290x435523318(V, V);
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a);
extern Clo g_list_2efoldl_24s324619290x435523318_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s878937540x987476648(V, V);
V g_list_2efoldl_24s878937540x987476648_entry(V self, V *a);
extern Clo g_list_2efoldl_24s878937540x987476648_clo;
V g_list_2efoldl_24s932544939x1448830416_24scalars(V, V, V);
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2ekeepIf_24f428638463x2144521938_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo;
V g_list_2ekeepIf_24s1166238673x178798903(V, V);
V g_list_2ekeepIf_24s1166238673x178798903_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_clo;
V g_list_2ekeepIf_24s1166238673x178798903_24dps(V, V, V);
V g_list_2ekeepIf_24s1166238673x178798903_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_24dps_clo;
V g_list_2ekeepIf_24s1613584875x1342487326(V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_clo;
V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V, V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo;
V g_list_2ekeepIf_24s1819141159x1906443669(V);
V g_list_2ekeepIf_24s1819141159x1906443669_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1819141159x1906443669_clo;
V g_list_2ekeepIf_24s1819141159x1906443669_24dps(V, V);
V g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1819141159x1906443669_24dps_clo;
V g_list_2ekeepIf_24s458067099x815639923_24dps(V, V);
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo;
V g_list_2ekeepIf_24s479112018x1726839132_24dps(V, V);
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo;
V g_list_2ekeepIf_24s920421308x594300259_24dps(V, V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2ekeepIf_24s930188071x496633547_24dps(V, V, V);
V g_list_2ekeepIf_24s930188071x496633547_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1141799624x1826918381(V, V, V);
V g_list_2emap_24f1141799624x1826918381_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_clo;
V g_list_2emap_24f1141799624x1826918381_24dps(V, V, V, V);
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_24dps_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24f1176765648x1638512070_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_24dps_clo;
V g_list_2emap_24f1221888634x716224461_24dps(V, V, V);
V g_list_2emap_24f1221888634x716224461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_24dps_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f1457339348x592422294_24dps(V, V, V, V);
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_24dps_clo;
V g_list_2emap_24f1749649202x1754028860(V, V);
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_clo;
V g_list_2emap_24f1749649202x1754028860_24dps(V, V, V);
V g_list_2emap_24f1749649202x1754028860_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_24dps_clo;
V g_list_2emap_24f189927396x2059034600(V);
V g_list_2emap_24f189927396x2059034600_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_clo;
V g_list_2emap_24f189927396x2059034600_24dps(V, V);
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_24dps_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24f565269645x1954016017_24dps(V, V);
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_24dps_clo;
V g_list_2emap_24f869471183x993026796(V, V, V);
V g_list_2emap_24f869471183x993026796_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_clo;
V g_list_2emap_24f869471183x993026796_24dps(V, V, V, V);
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_24dps_clo;
V g_list_2emap_24s1011134518x652437020_24dps(V, V, V);
V g_list_2emap_24s1011134518x652437020_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1011134518x652437020_24dps_clo;
V g_list_2emap_24s1218298322x1569510752(V, V);
V g_list_2emap_24s1218298322x1569510752_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_clo;
V g_list_2emap_24s1218298322x1569510752_24dps(V, V, V);
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_24dps_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1275294336x693095586(V, V);
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1354671438x1264137843(V);
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_clo;
V g_list_2emap_24s1354671438x1264137843_24dps(V, V);
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1611344417x463861413(V, V, V);
V g_list_2emap_24s1611344417x463861413_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_clo;
V g_list_2emap_24s1611344417x463861413_24dps(V, V, V, V);
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_24dps_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s204237290x1967740547_24dps(V, V, V, V, V);
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_24dps_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s275211812x1381242052(V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_clo;
V g_list_2emap_24s275211812x1381242052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_24dps_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s456747242x756515627_24dps(V, V);
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_24dps_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s529174x2075875906_24dps(V, V);
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_24dps_clo;
V g_list_2emap_24s588468714x1874323009_24dps(V, V);
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_24dps_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s763976875x1978337183_24dps(V, V);
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_24dps_clo;
V g_list_2emap_24s777254429x1856211654(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_clo;
V g_list_2emap_24s777254429x1856211654_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_24dps_clo;
V g_list_2emap_24s784191759x2032889081(V);
V g_list_2emap_24s784191759x2032889081_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_clo;
V g_list_2emap_24s784191759x2032889081_24dps(V, V);
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_24dps_clo;
V g_list_2emap_24s886389550x1086668531_24dps(V, V);
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_24dps_clo;
V g_list_2emap_24s892909862x1245535974_24dps(V, V, V, V, V);
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_24dps_clo;
V g_list_2emap_24s903588428x1469638784(V, V);
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_clo;
V g_list_2emap_24s903588428x1469638784_24dps(V, V, V);
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge_24s1081221956x1079757426_24dps(V, V, V);
V g_list_2emerge_24s1081221956x1079757426_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2emerge_24s169102166x1112743251(V, V);
V g_list_2emerge_24s169102166x1112743251_entry(V self, V *a);
extern Clo g_list_2emerge_24s169102166x1112743251_clo;
V g_list_2emerge_24s169102166x1112743251_24tok2(V, V, V);
V g_list_2emerge_24s169102166x1112743251_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s169102166x1112743251_24tok2_clo;
V g_list_2emerge_24s1868670077x962775364(V, V);
V g_list_2emerge_24s1868670077x962775364_entry(V self, V *a);
extern Clo g_list_2emerge_24s1868670077x962775364_clo;
V g_list_2emerge_24s1868670077x962775364_24tok2(V, V, V);
V g_list_2emerge_24s1868670077x962775364_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s1868670077x962775364_24tok2_clo;
V g_list_2emerge_24s2030620912x751826577(V, V);
V g_list_2emerge_24s2030620912x751826577_entry(V self, V *a);
extern Clo g_list_2emerge_24s2030620912x751826577_clo;
V g_list_2emerge_24s2030620912x751826577_24dps(V, V, V);
V g_list_2emerge_24s2030620912x751826577_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2030620912x751826577_24dps_clo;
V g_list_2emerge_24s2063716145x1843377885(V, V);
V g_list_2emerge_24s2063716145x1843377885_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_clo;
V g_list_2emerge_24s2063716145x1843377885_24dps(V, V, V);
V g_list_2emerge_24s2063716145x1843377885_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_24dps_clo;
V g_list_2emerge_24s275559350x890699445_24dps(V, V, V);
V g_list_2emerge_24s275559350x890699445_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_24dps_clo;
V g_list_2emerge_24s275559350x890699445_24tok2(V, V, V);
V g_list_2emerge_24s275559350x890699445_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_24tok2_clo;
V g_list_2esortBy_24s475241097x1080260612(V);
V g_list_2esortBy_24s475241097x1080260612_entry(V self, V *a);
extern Clo g_list_2esortBy_24s475241097x1080260612_clo;
V g_list_2esortBy_24s47865647x1719088929(V);
V g_list_2esortBy_24s47865647x1719088929_entry(V self, V *a);
extern Clo g_list_2esortBy_24s47865647x1719088929_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1023948938x380005785_24dps(V, V, V, V);
V g_list_2ezipWith_24s1023948938x380005785_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1023948938x380005785_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_list_2ezipWith_24s1893966264x617194987_24dps(V, V, V);
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s1958630276x749154843_24dps(V, V, V);
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo;
V g_list_2ezipWith_24s273466373x375450363_24dps(V, V, V);
V g_list_2ezipWith_24s273466373x375450363_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s273466373x375450363_24dps_clo;
V g_list_2ezipWith_24s457513469x1891643252(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_clo;
V g_list_2ezipWith_24s457513469x1891643252_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo;
V g_list_2ezipWith_24s583291244x257539062(V, V);
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_clo;
V g_list_2ezipWith_24s583291244x257539062_24dps(V, V, V);
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s930188071x496633547_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s930188071x496633547_entry, 2, 0};

V g_list_2ekeepIf_24s930188071x496633547(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s930188071x496633547_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s930188071x496633547(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eany_24s2077819594x1842428557_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2077819594x1842428557_entry, 2, 0};

V g_list_2eany_24s2077819594x1842428557(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_lit_240, v_x_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s2077819594x1842428557(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1810610888x1691479932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1810610888x1691479932_entry, 2, 0};

V g_list_2efoldl_24s1810610888x1691479932(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eranges_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1810610888x1691479932(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1613584875x1342487326_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1613584875x1342487326_entry, 2, 0};

V g_list_2ekeepIf_24s1613584875x1342487326(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1613584875x1342487326_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1613584875x1342487326_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1613584875x1342487326(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1166238673x178798903_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1166238673x178798903_entry, 2, 0};

V g_list_2ekeepIf_24s1166238673x178798903(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0))) ? !heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_x_242, 1))) : 1)) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1166238673x178798903_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1166238673x178798903_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1166238673x178798903(a[0], a[1]);
}
Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_24dps_entry, 3, 0};

V g_list_2emerge_24s1347843181x1368204458_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 7);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_y_245, 2)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_247;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_249;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s1081221956x1079757426_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1081221956x1079757426_24dps_entry, 3, 0};

V g_list_2emerge_24s1081221956x1079757426_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 6);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_247;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_249;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1081221956x1079757426_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1081221956x1079757426_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s1414119352x995333365_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1414119352x995333365_entry, 2, 0};

V g_list_2eall_24s1414119352x995333365(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        v_a_2411 = (g_heff_2esyntax_2epresyntax_2esegmentOdd(v_a_247, v_a_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_a_2412, v_lit_240, 1)) {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_lit_240);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s1414119352x995333365(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s529174x2075875906_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_entry, 1, 0};

V g_list_2emap_24s529174x2075875906(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s529174x2075875906_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906(a[0]);
}
Clo g_list_2emap_24s529174x2075875906_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_24dps_entry, 2, 0};

V g_list_2emap_24s529174x2075875906_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s205414595x1692305030_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_24dps_entry, 2, 0};

V g_list_2emap_24s205414595x1692305030_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s205414595x1692305030_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1887874170x1747433177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_entry, 1, 0};

V g_list_2emap_24s1887874170x1747433177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2415;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_245;
        V v_t_249;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_248 = heff_dup(heff_field(v_a_246, 1));
          v_t_249 = v_a_248;
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_246}), v_t_249});
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_2410 = v_field_245;
          V v_t_2413;
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2412 = heff_dup(heff_field(v_a_2410, 1));
            v_t_2413 = v_a_2412;
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_2410}), v_t_2413});
        } else {
          V v_a_2414 = v_field_245;
          v_t_2415 = v_a_2414;
        }
      }
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1887874170x1747433177_24dps(v_xs_242, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177(a[0]);
}
Clo g_list_2emap_24s1230969749x2018313496_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_entry, 1, 0};

V g_list_2emap_24s1230969749x2018313496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1230969749x2018313496_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_24dps_entry, 2, 0};

V g_list_2emap_24s386875578x1005587669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s892909862x1245535974_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s892909862x1245535974_24dps_entry, 5, 0};

V g_list_2emap_24s892909862x1245535974_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkEquation: {
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_ru_24a_247_24MkEquation = heff_take_reuse_n(v_a_247, 14ULL, 4);
        V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
        V v_t_2414 = heff_tag_at_n(v_ru_24x_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_lit_242)}), heff_dup(v_a_2410)});
        V v_t_2415 = heff_tag_at_n(v_ru_24a_247_24MkEquation, TAG_MkEquation, 4, (V[]){v_t_2413, v_a_2410, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_a_2411}), v_a_2412});
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_a_248});
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s892909862x1245535974_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_24dps_entry, 3, 0};

V g_list_2ezipWith_24s738847920x410598254_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_t_2410 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_2412 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 3);
        v_t_2414 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_t_2414, v_y_245}), heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2415;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s591739608x1065283968_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s591739608x1065283968_entry, 2, 0};

V g_list_2efoldl_24s591739608x1065283968(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s591739608x1065283968(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1096141254x104586789_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1096141254x104586789_entry, 2, 0};

V g_list_2efoldl_24s1096141254x104586789(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    if (heff_intLe_c_lent(v_z_240, v_x_242, 0)) {
      v_t_244 = v_z_240;
    } else {
      heff_drop(v_z_240);
      v_t_244 = heff_dup(v_x_242);
    }
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1096141254x104586789(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1347985788x1836008258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1347985788x1836008258_entry, 2, 0};

V g_list_2efoldl_24s1347985788x1836008258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b_24f368057430x559112032(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1347985788x1836008258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s860380051x1466609135_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s860380051x1466609135_entry, 1, 0};

V g_list_2eany_24s860380051x1466609135(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s860380051x1466609135(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s756915015x218492736_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s756915015x218492736_entry, 1, 0};

V g_list_2eany_24s756915015x218492736(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecopyField(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s756915015x218492736_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s756915015x218492736(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1433066060x138395605_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1433066060x138395605_entry, 2, 0};

V g_list_2efoldl_24s1433066060x138395605(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_246 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_key_244, v_body_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1433066060x138395605_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1433066060x138395605(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s583291244x257539062_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s583291244x257539062_entry, 2, 0};

V g_list_2ezipWith_24s583291244x257539062(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_SSet, 2, (V[]){v_x_242, heff_tag_n(TAG_OSimple, 1, (V[]){v_y_244})});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s583291244x257539062_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s583291244x257539062(a[0], a[1]);
}
Clo g_list_2efoldl_24s964765707x1396946999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s964765707x1396946999_entry, 2, 0};

V g_list_2efoldl_24s964765707x1396946999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s964765707x1396946999(a[0], a[1]);
}
Clo g_list_2efoldl_24s1722165992x1349408496_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1722165992x1349408496_entry, 2, 0};

V g_list_2efoldl_24s1722165992x1349408496(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_246 = (g_heff_2ecompile_2efacts_2elazyOf(v_z_240, v_key_244, v_body_245));
    V v_t_247 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_key_244, v_t_246));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1722165992x1349408496_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1722165992x1349408496(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s479112018x1726839132_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s479112018x1726839132_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_RepV: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_249, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s479112018x1726839132_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s751274328x395946890_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s751274328x395946890_entry, 3, 0};

V g_list_2eall_24s751274328x395946890(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2ecompile_2eowned_2eokArg(heff_dup(v_lit_240), v_lit_241, heff_dup(v_x_243)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s751274328x395946890_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2eall_24s751274328x395946890(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1460603830x671758883_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_24dps_entry, 3, 0};

V g_list_2emap_24s1460603830x671758883_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2023159590x14712440_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2023159590x14712440_entry, 2, 0};

V g_list_2efoldl_24s2023159590x14712440(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2023159590x14712440(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1299427137x1247694659_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1299427137x1247694659_entry, 2, 0};

V g_list_2eany_24s1299427137x1247694659(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 4);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_l_245 = heff_dup(heff_rfield(v_x_242, 1));
    if ((heff_strEq_c(heff_dup(v_v_244), heff_dup(heff_rfield(v_lit_240, 0))) && heff_strEq_c(heff_dup(v_l_245), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop_rec(v_lit_240, 4);
      heff_drop(v_v_244);
      heff_drop(v_l_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_v_244);
      heff_drop(v_l_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1299427137x1247694659_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1299427137x1247694659(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s777254429x1856211654_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s777254429x1856211654_entry, 11, 0};

V g_list_2emap_24s777254429x1856211654(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24MkPair = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = ({ V a_0 = v_a_2413; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2413); r_; });
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_list_2emap_24tok2(v_ru_24x_2411_24MkPair, heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)));
      v_t_2422 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, v_t_2421));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s777254429x1856211654_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s777254429x1856211654_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s777254429x1856211654(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2ezipWith_24s273466373x375450363_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s273466373x375450363_24dps_entry, 3, 0};

V g_list_2ezipWith_24s273466373x375450363_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_y_245, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_248 = (g_heff_2eelab_2erules_2epatternCanFail(v_t_247, v_x_243));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s273466373x375450363_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s273466373x375450363_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s324619290x435523318_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s324619290x435523318_entry, 2, 0};

V g_list_2efoldl_24s324619290x435523318(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efuse_2etailsOf(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s324619290x435523318(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1354671438x1264137843_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354671438x1264137843_entry, 1, 0};

V g_list_2emap_24s1354671438x1264137843(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1354671438x1264137843_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354671438x1264137843(a[0]);
}
Clo g_list_2emap_24s784191759x2032889081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s784191759x2032889081_entry, 1, 0};

V g_list_2emap_24s784191759x2032889081(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Given = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_243));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24Given, TAG_Given, 1, (V[]){v_t_244});
      break;
    }
    case TAG_GivenU: {
      V v_a_245 = heff_field(v_x_241, 0);
      V v_a_246 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24GivenU = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_246));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24GivenU, TAG_GivenU, 2, (V[]){v_a_245, v_t_247});
      break;
    }
    case TAG_LentVar: {
      v_t_2412 = v_x_241;
      break;
    }
    case TAG_LentValue: {
      V v_a_2410 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24LentValue = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_2411 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_2410));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24LentValue, TAG_LentValue, 1, (V[]){v_t_2411});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s784191759x2032889081_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s784191759x2032889081_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s784191759x2032889081(a[0]);
}
Clo g_list_2ezipWith_24s1893966264x617194987_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1893966264x617194987_entry, 2, 0};

V g_list_2ezipWith_24s1893966264x617194987(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2escalars_2emergeTy(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1893966264x617194987_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1893966264x617194987(a[0], a[1]);
}
Clo g_list_2eall_24s743242824x1965727204_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s743242824x1965727204_entry, 1, 0};

V g_list_2eall_24s743242824x1965727204(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s743242824x1965727204(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s878937540x987476648_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s878937540x987476648_entry, 2, 0};

V g_list_2efoldl_24s878937540x987476648(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_z_240; V b_1 = heff_get_n(v_t_2412, 0, 3); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2417;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_a_2416 = v_field_2415;
        v_t_2417 = v_a_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = NTAG(TAG_Nil);
      }
    }
    V v_t_2418 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_get_n(v_t_246, 0, 3), heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2417})));
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s878937540x987476648_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s878937540x987476648(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1023948938x380005785_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1023948938x380005785_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1023948938x380005785_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eunbox_2eslotFor(heff_dup(v_lit_240), v_x_244, v_y_246));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1023948938x380005785_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1023948938x380005785_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s932544939x1448830416_24scalars_entry, 3, 0};

V g_list_2efoldl_24s932544939x1448830416_24scalars(V v_params_240, V v_result_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_params__result, (V[]){v_params_240, v_result_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_params_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_result_246 = heff_dup(heff_rfield(v_x_243, 1));
    V v_t_247 = (g_list_2ezipWith_24s151204990x680105425(v_params_240, v_params_245));
    V v_a_248 = v_result_241;
    V v_t_249 = ({ V a_0 = v_a_248; V a_1 = v_result_246; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_246); r_; });
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = v_a_248;
    } else {
      heff_drop(v_a_248);
      heff_drop(v_t_249);
      v_t_2410 = NTAG(TAG_RepV);
    }
    V t_0 = v_t_247;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_params_240 = t_0;
    v_result_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s932544939x1448830416_24scalars(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s510639937x1058700299_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_24dps_entry, 2, 0};

V g_list_2emap_24s510639937x1058700299_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 3, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1027174601x1571638094_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1027174601x1571638094_entry, 4, 0};

V g_list_2eany_24s1027174601x1571638094(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_x_244, v_lit_241, v_lit_242, 0))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s1027174601x1571638094(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2eany_24s331724893x1262243254_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s331724893x1262243254_entry, 1, 0};

V g_list_2eany_24s331724893x1262243254(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s331724893x1262243254(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s457513469x1891643252_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s457513469x1891643252_entry, 9, 0};

V g_list_2ezipWith_24s457513469x1891643252(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
      V v_t_2414 = heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246));
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_strAppend(heff_dup(v_lit_245), v_t_2414));
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2415), heff_hole()});
      V v_u_2417 = (g_list_2ezipWith_24s457513469x1891643252_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s457513469x1891643252(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1275294336x693095586_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_entry, 2, 0};

V g_list_2emap_24s1275294336x693095586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2easLent(v_lit_240, v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1275294336x693095586_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1275294336x693095586(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1218298322x1569510752_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218298322x1569510752_entry, 2, 0};

V g_list_2emap_24s1218298322x1569510752(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1218298322x1569510752_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1218298322x1569510752_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218298322x1569510752(a[0], a[1]);
}
Clo g_list_2emap_24s275211812x1381242052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s275211812x1381242052_entry, 7, 0};

V g_list_2emap_24s275211812x1381242052(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2416 = heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2415));
    V v_t_2417 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), v_t_2416);
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2417), heff_hole()});
    V v_u_2419 = (g_list_2emap_24s275211812x1381242052_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s275211812x1381242052(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s1056451377x727850182_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1056451377x727850182_entry, 2, 0};

V g_list_2efoldl_24s1056451377x727850182(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      v_t_2412 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_249, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1056451377x727850182_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1056451377x727850182(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s886389550x1086668531_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s886389550x1086668531_24dps_entry, 2, 0};

V g_list_2emap_24s886389550x1086668531_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkSegment: {
        V v_v_246 = heff_field(v_x11_244, 0);
        V v_ty_247 = heff_field(v_x11_244, 1);
        V v_size_248 = heff_field(v_x11_244, 2);
        V v_little_249 = heff_field(v_x11_244, 3);
        V v_signed_2410 = heff_field(v_x11_244, 4);
        heff_take_n(v_x11_244, 31ULL, 5);
        int64_t v_t_2411;
        if ((heff_dup(v_little_249) == NTAG(TAG_True))) {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_2410) == NTAG(TAG_True))) {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)0ULL);
        }
        v_t_2413 = heff_rec_n(5, shape_value__ty__size__flags__span, (V[]){v_v_246, v_ty_247, v_size_248, heff_box_word((v_t_2411 + v_t_2412)), v_sp_245});
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s886389550x1086668531_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s337463599x663364213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337463599x663364213_entry, 2, 0};

V g_list_2efoldl_24s337463599x663364213(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s337463599x663364213(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1011134518x652437020_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1011134518x652437020_24dps_entry, 3, 0};

V g_list_2emap_24s1011134518x652437020_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_key_246 = heff_get_n(v_x_243, 1, 2);
    V v_t_247 = heff_rec_n(3, shape_name__key__module, (V[]){v_name_245, v_key_246, heff_dup(heff_rfield(v_lit_240, 0))});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1011134518x652437020_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1011134518x652437020_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s2037198014x392734282_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2037198014x392734282_entry, 2, 0};

V g_list_2eany_24s2037198014x392734282(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_name_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_alias_245 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), v_name_244)) {
      V v_a_246 = v_alias_245;
      V v_t_247 = heff_dup(heff_rfield(v_lit_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_Nothing: {
          heff_drop_rec(v_lit_240, 3);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_a_246, 0ULL, 1);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_246);
        }
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_Nothing: {
          heff_drop(v_a_249);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_strEq_c(v_a_249, v_a_2410)) {
            heff_drop_rec(v_lit_240, 3);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_lit_240;
            V t_1 = v_xs_243;
            v_lit_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_246);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    } else {
      heff_drop(v_alias_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2037198014x392734282_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s2037198014x392734282(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1819141159x1906443669_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1819141159x1906443669_entry, 1, 0};

V g_list_2ekeepIf_24s1819141159x1906443669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_dup(heff_field(v_x_241, 0));
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
        V v_u_2411 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
        V v_u_2418 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, heff_dup(v_cell_2417)));
        heff_drop(v_u_2418);
        return v_cell_2417;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        V v_cell_2423 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
        V v_u_2424 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, heff_dup(v_cell_2423)));
        heff_drop(v_u_2424);
        return v_cell_2423;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        switch (heff_tag_of(v_x_241)) {
        case TAG_At: {
          heff_take_n(v_x_241, 0ULL, 2);
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x_241);
        }
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        V v_cell_2432 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
        V v_u_2433 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, heff_dup(v_cell_2432)));
        heff_drop(v_u_2433);
        return v_cell_2432;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
        V v_u_2436 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, heff_dup(v_cell_2435)));
        heff_drop(v_u_2436);
        return v_cell_2435;
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1819141159x1906443669_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1819141159x1906443669(a[0]);
}
Clo g_list_2ekeepIf_24s1819141159x1906443669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1819141159x1906443669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_dup(heff_field(v_x_242, 0));
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2411;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
        heff_drop(v_u_2419);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2418;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2425 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2424));
        heff_drop(v_u_2425);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2424;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        switch (heff_tag_of(v_x_242)) {
        case TAG_At: {
          heff_take_n(v_x_242, 0ULL, 2);
          V t_0 = v_xs_243;
          V t_1 = v_d_241;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x_242);
        }
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        V v_cell_2433 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2434 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2433));
        heff_drop(v_u_2434);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2433;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        V v_cell_2436 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2437 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2436));
        heff_drop(v_u_2437);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2436;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x11_244);
      }
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1819141159x1906443669_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s204237290x1967740547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s204237290x1967740547_24dps_entry, 5, 0};

V g_list_2emap_24s204237290x1967740547_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ebuild_2edriver_2etwiceDiag(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s204237290x1967740547_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1354328764x1362350361_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_24dps_entry, 2, 0};

V g_list_2emap_24s1354328764x1362350361_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361_24dps(a[0], a[1]);
}
Clo g_list_2esortBy_24s47865647x1719088929_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s47865647x1719088929_entry, 1, 0};

V g_list_2esortBy_24s47865647x1719088929(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s47865647x1719088929(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s47865647x1719088929(v_t_2411));
      return (g_list_2emerge_24s1868670077x962775364_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s47865647x1719088929_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s47865647x1719088929(a[0]);
}
Clo g_list_2emap_24s588468714x1874323009_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588468714x1874323009_24dps_entry, 2, 0};

V g_list_2emap_24s588468714x1874323009_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2eintegrationOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588468714x1874323009_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1611344417x463861413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1611344417x463861413_entry, 3, 0};

V g_list_2emap_24s1611344417x463861413(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_tags_246 = heff_get_n(v_x_243, 1, 3);
    V v_t_247 = (g_heff_2ebuild_2edriver_2elistedName(v_name_245));
    V v_t_248;
    if ((heff_dup(v_tags_246) == NTAG(TAG_True))) {
      heff_drop(v_tags_246);
      v_t_248 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_246);
      v_t_248 = heff_dup(v_lit_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_248), heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1611344417x463861413_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1611344417x463861413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1611344417x463861413(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s2030620912x751826577_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2030620912x751826577_entry, 2, 0};

V g_list_2emerge_24s2030620912x751826577(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_247 = (g_list_2emerge_24s2030620912x751826577_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_249 = (g_list_2emerge_24s2030620912x751826577_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s2030620912x751826577_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2030620912x751826577(a[0], a[1]);
}
Clo g_list_2eany_24s464681941x898021545_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s464681941x898021545_entry, 2, 0};

V g_list_2eany_24s464681941x898021545(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_start_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_end_245 = heff_dup(heff_rfield(v_x_242, 1));
    if ((heff_intLe_c_lent(v_start_244, v_lit_240, 0) && heff_intLe_c_lent(v_lit_240, v_end_245, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s464681941x898021545_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s464681941x898021545(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1516272141x1201056882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1516272141x1201056882_entry, 3, 0};

V g_list_2efoldl_24s1516272141x1201056882(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 5);
        v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_a_247, heff_dup(v_lit_240), v_a_248}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_a_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1516272141x1201056882(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1026998256x1634433314_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1026998256x1634433314_entry, 2, 0};

V g_list_2efoldl_24s1026998256x1634433314(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1026998256x1634433314(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s302194196x751324068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s302194196x751324068_entry, 2, 0};

V g_list_2efoldl_24s302194196x751324068(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s302194196x751324068(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s475241097x1080260612_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s475241097x1080260612_entry, 1, 0};

V g_list_2esortBy_24s475241097x1080260612(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s475241097x1080260612(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s475241097x1080260612(v_t_2411));
      return (g_list_2emerge_24s169102166x1112743251_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s475241097x1080260612_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s475241097x1080260612(a[0]);
}
Clo g_list_2emap_24s725725455x1186198702_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_24dps_entry, 2, 0};

V g_list_2emap_24s725725455x1186198702_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_x_242, heff_strLength_lent(v_x_242, 0)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_242, MK_INT(0LL), v_t_244), heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s510830240x893896831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_entry, 2, 0};

V g_list_2emap_24s510830240x893896831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2eupdateSetKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s510830240x893896831_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831(a[0], a[1]);
}
Clo g_list_2emap_24s903588428x1469638784_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s903588428x1469638784_entry, 2, 0};

V g_list_2emap_24s903588428x1469638784(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(v_x_242, 2, 3);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_a_244, heff_strLength_lent(v_a_244, 0)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice_lent(v_a_244, v_lit_240, v_t_245, 5), heff_hole()});
    V v_u_247 = (g_list_2emap_24s903588428x1469638784_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s903588428x1469638784(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eall_24s418009941x978041577_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s418009941x978041577_entry, 4, 0};

V g_list_2eall_24s418009941x978041577(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_x2_243) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_a_246 = heff_strByteAt_lent(v_lit_240, v_x_244, 0);
    if (((v_lit_241 <= heff_peek_word(v_a_246)) && (heff_peek_word(v_a_246) <= v_lit_242))) {
      heff_drop(v_a_246);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_a_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eall_24s418009941x978041577_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2eall_24s418009941x978041577(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2ezipWith_24s1958630276x749154843_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_entry, 2, 0};

V g_list_2ezipWith_24s1958630276x749154843(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 2), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1958630276x749154843_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1958630276x749154843_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 2), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_str0, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str2, 9, "{ name = ");
Clo g_list_2emap_24s404123879x745642248_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_entry, 1, 0};

V g_list_2emap_24s404123879x745642248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_dir_244 = heff_get_n(v_x_241, 1, 2);
    V v_t_245 = ({ V a_0 = v_name_243; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_243); r_; });
    V v_t_246 = ({ V a_0 = v_dir_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_dir_244); r_; });
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str0), heff_strAppend(v_t_246, ((V)&g_list_2emap_24s404123879x745642248_str1)));
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str2), heff_strAppend(v_t_245, v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s404123879x745642248_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248(a[0]);
}
Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s458067099x815639923_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s458067099x815639923_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_242, 1)) == NTAG(TAG_True))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_xs_243;
      V t_1 = v_cell_244;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 12);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s458067099x815639923_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s2063716145x1843377885_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2063716145x1843377885_entry, 2, 0};

V g_list_2emerge_24s2063716145x1843377885(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 4);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_246 = (g_heff_2ebuild_2ecommands_2eplaceBefore(heff_rfield(v_x_242, 1), heff_rfield(v_y_244, 1)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s2063716145x1843377885_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop(v_t_246);
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s2063716145x1843377885_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s2063716145x1843377885_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2063716145x1843377885(a[0], a[1]);
}
Clo g_list_2emap_24s763976875x1978337183_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s763976875x1978337183_24dps_entry, 2, 0};

V g_list_2emap_24s763976875x1978337183_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edocpages_2epage(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s763976875x1978337183_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1986081631x104660098_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 14);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s920421308x594300259_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s920421308x594300259_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s920421308x594300259_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_249 = heff_strSlice(v_t_248, heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_249, v_lit_241, 1)) {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s920421308x594300259_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s920421308x594300259_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s456747242x756515627_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456747242x756515627_24dps_entry, 2, 0};

V g_list_2emap_24s456747242x756515627_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2einteractive_2eflagSlot(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456747242x756515627_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f189927396x2059034600_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f189927396x2059034600_entry, 1, 0};

V g_list_2emap_24f189927396x2059034600(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_loosest_243 = heff_take_field(v_x_241, 3);
    V v_id_244 = heff_get_n(v_x_241, 0, 5);
    if ((heff_dup(v_loosest_243) == NTAG(TAG_True))) {
      heff_drop(v_loosest_243);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_id_244, heff_hole()});
      V v_u_246 = (g_list_2emap_24f189927396x2059034600_24dps(v_xs_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_loosest_243);
      heff_drop(v_id_244);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f189927396x2059034600_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f189927396x2059034600(a[0]);
}
Clo g_list_2emap_24f1221888634x716224461_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1221888634x716224461_24dps_entry, 3, 0};

V g_list_2emap_24f1221888634x716224461_24dps(V v_lit_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_CondTrue: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondFalse: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondRel: {
    V v_es_244 = heff_field(v_x1_241, 1);
    V v_t_245 = (g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_244)));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
  }
  case TAG_CondRelU: {
    V v_es_247 = heff_field(v_x1_241, 1);
    V v_t_248 = (g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_247)));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_CondBool: {
    V v_e_249 = heff_field(v_x1_241, 0);
    V v_t_2410 = (g_list_2emap_24s215892288x1392224072(heff_dup(v_lit_240), NTAG(TAG_Nil)));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_lit_240, heff_dup(v_e_249)}), v_t_2410});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2411);
  }
  case TAG_CondNot: {
    V v_c_2412 = heff_field(v_x1_241, 0);
    V t_0 = v_lit_240;
    V t_1 = v_c_2412;
    V t_2 = v_d_242;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2413 = heff_field(v_x1_241, 0);
    V v_b_2414 = heff_field(v_x1_241, 1);
    V v_c_2415 = heff_field(v_x1_241, 2);
    V v_t_2416 = (g_heff_2ecompile_2eowned_2econdKids(v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eowned_2econdKids(v_b_2414));
    V v_t_2418 = (g_heff_2ecompile_2eowned_2econdKids(v_c_2415));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2419));
    V v_t_2421 = (g_list_2emap_24s215892288x1392224072(v_lit_240, v_t_2420));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
  }
  case TAG_CondLet: {
    V v_e_2423 = heff_field(v_x1_241, 1);
    V v_c_2424 = heff_field(v_x1_241, 2);
    V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_e_2423)}), heff_hole()});
    V v_u_2427 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_lit_240;
    V t_1 = v_c_2424;
    V t_2 = v_cell_2426;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1221888634x716224461_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f1221888634x716224461_24dps(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1457339348x592422294_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1457339348x592422294_entry, 3, 0};

V g_list_2emap_24f1457339348x592422294(V v_lit_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_243 = heff_intShow(heff_strByteAt_lent(v_lit_240, heff_box_word(v_a_241), 2));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24f1457339348x592422294_24dps(v_lit_240, heff_box_word((v_a_241 + ((int64_t)1ULL))), v_b_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1457339348x592422294(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24f428638463x2144521938_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f428638463x2144521938_entry, 4, 0};

V g_list_2ekeepIf_24f428638463x2144521938(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_xs_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      goto top;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      if (!heff_strEq_c(heff_strSlice_lent(v_x_246, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_248 = (g_list_2ekeepIf_24f428638463x2144521938_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_246);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24f428638463x2144521938(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f869471183x993026796_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f869471183x993026796_entry, 3, 0};

V g_list_2emap_24f869471183x993026796(V v_lit_240, V v_box_24lit_241, V v_x2_242) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
      V v_u_246 = (g_list_2emap_24f869471183x993026796_24dps(v_lit_240, heff_box_word(v_lit_241), v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f869471183x993026796_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f869471183x993026796(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1749649202x1754028860_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1749649202x1754028860_entry, 2, 0};

V g_list_2emap_24f1749649202x1754028860(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_module_244 = heff_take_field(v_x_242, 1);
    V v_key_245 = heff_get_n(v_x_242, 0, 2);
    if (heff_strEq_c(v_module_244, heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_key_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1749649202x1754028860_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_key_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1749649202x1754028860(a[0], a[1]);
}
Clo g_list_2emap_24f565269645x1954016017_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f565269645x1954016017_entry, 1, 0};

V g_list_2emap_24f565269645x1954016017(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_243 = heff_take_field(v_x_241, 0);
    V v_use_244 = heff_get_n(v_x_241, 1, 2);
    V v_t_245 = heff_take_field(v_binder_243, 2);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_rec_n(3, shape_name__field__use, (V[]){heff_take_field(v_binder_243, 0), heff_get_n(v_binder_243, 1, 3), v_use_244});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f565269645x1954016017_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop_rec(v_binder_243, 3);
      heff_drop(v_use_244);
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f565269645x1954016017(a[0]);
}
Clo g_list_2emap_24f1141799624x1826918381_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1141799624x1826918381_entry, 3, 0};

V g_list_2emap_24f1141799624x1826918381(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 0, 8));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f1141799624x1826918381_24dps(v_lit_240, v_p_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1141799624x1826918381_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1141799624x1826918381(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1176765648x1638512070_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1176765648x1638512070_entry, 12, 0};

V g_list_2emap_24f1176765648x1638512070(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2414 = heff_take_field(v_x_2412, 0);
    V v_key_2415 = heff_get_n(v_x_2412, 1, 2);
    V v_a_2416 = heff_dup(v_name_2414);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2416, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2416);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_2414, v_key_2415}), heff_hole()});
      V v_u_2418 = (g_list_2emap_24f1176765648x1638512070_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word(v_lit_243), v_lit_244, v_lit_245, heff_box_word(v_lit_246), heff_box_word(v_lit_247), v_lit_248, v_lit_249, heff_box_word(v_lit_2410), v_xs_2413, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2414);
      heff_drop(v_key_2415);
      heff_drop(v_a_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f1176765648x1638512070(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emap_24f1176765648x1638512070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1176765648x1638512070_24dps_entry, 13, 0};

V g_list_2emap_24f1176765648x1638512070_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_2412, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2415 = heff_take_field(v_x_2413, 0);
    V v_key_2416 = heff_get_n(v_x_2413, 1, 2);
    V v_a_2417 = heff_dup(v_name_2415);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2417, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2417);
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_2415, v_key_2416}), heff_hole()});
      V v_u_2419 = heff_setField(v_d_2412, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2415);
      heff_drop(v_key_2416);
      heff_drop(v_a_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1176765648x1638512070_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f1176765648x1638512070_24dps(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11], a[12]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2efoldl_24f319030394x1380151895_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f319030394x1380151895_entry, 3, 0};

V g_list_2efoldl_24f319030394x1380151895(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 6, 10);
    if (!(heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f319030394x1380151895(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emerge_24s275559350x890699445_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s275559350x890699445_24tok2_entry, 3, 0};

V g_list_2emerge_24s275559350x890699445_24tok2(V v_tok_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_x_243, 14);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s275559350x890699445_24dps(v_xs_244, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s275559350x890699445_24dps(heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24s275559350x890699445_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s275559350x890699445_24tok2(a[0], a[1], a[2]);
}