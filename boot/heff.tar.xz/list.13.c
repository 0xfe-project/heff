// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Binds 36386
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dir 308999
#define LBL_flags 298871457
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_params 951713969
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_version 583465758
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_value__ty__size__flags__span[] = {LBL_value, LBL_ty, LBL_size, LBL_flags, LBL_span};
V g_heff_2ebuild_2edriver_2emetIn(V, V, V, V);
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emetIn_clo;
V g_heff_2ebuild_2edriver_2etwiceDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemitc_2easLent(V, V);
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2easLent_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efuse_2etailsOf(V);
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etailsOf_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eranges_2earityOne(V, V);
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earityOne_clo;
V g_heff_2ecompile_2esimplify_2ecopyField(V);
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyField_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_list_2eany_24s1345968422x916930247(V, V, V);
V g_list_2eany_24s1345968422x916930247_entry(V self, V *a);
extern Clo g_list_2eany_24s1345968422x916930247_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2efilter_24f1668687542x1574966783(V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_clo;
V g_list_2efilter_24f1668687542x1574966783_24dps(V, V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_24dps_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efilter_24s1064353769x1815078842_24dps(V, V);
V g_list_2efilter_24s1064353769x1815078842_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_24dps_clo;
V g_list_2efilter_24s1392550889x861369760(V, V);
V g_list_2efilter_24s1392550889x861369760_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_clo;
V g_list_2efilter_24s1392550889x861369760_24dps(V, V, V);
V g_list_2efilter_24s1392550889x861369760_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_24dps_clo;
V g_list_2efilter_24s1450888590x1561911320_24dps(V, V, V, V, V);
V g_list_2efilter_24s1450888590x1561911320_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1450888590x1561911320_24dps_clo;
V g_list_2efilter_24s1791954930x928584331(V);
V g_list_2efilter_24s1791954930x928584331_entry(V self, V *a);
extern Clo g_list_2efilter_24s1791954930x928584331_clo;
V g_list_2efilter_24s1791954930x928584331_24dps(V, V);
V g_list_2efilter_24s1791954930x928584331_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1791954930x928584331_24dps_clo;
V g_list_2efilter_24s1875062608x222844981_24dps(V, V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_24dps_clo;
V g_list_2efilter_24s2085830190x1097871222_24dps(V, V);
V g_list_2efilter_24s2085830190x1097871222_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2085830190x1097871222_24dps_clo;
V g_list_2efilter_24s337063435x1366313299_24dps(V, V, V, V);
V g_list_2efilter_24s337063435x1366313299_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s337063435x1366313299_24dps_clo;
V g_list_2efilter_24s50027113x1989932102_24dps(V, V, V);
V g_list_2efilter_24s50027113x1989932102_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_24dps_clo;
HeffT2 g_list_2efind_24s1230956425x1562898054_24cpr(V, V);
HeffT2 g_list_2efind_24s1839921325x671097810_24cpr(V, V);
HeffT2 g_list_2efind_24s2097169879x1343877600_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_list_2efind_24s358915833x209356919_24cpr(V, V);
HeffT2 g_list_2efind_24s487054388x274730225_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1472875662x470242985(V, V);
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1472875662x470242985_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s1832274453x1963324019(V, V);
V g_list_2efoldl_24s1832274453x1963324019_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1832274453x1963324019_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s324619290x435523318(V, V);
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a);
extern Clo g_list_2efoldl_24s324619290x435523318_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s688118489x1560799399(V, V, V);
V g_list_2efoldl_24s688118489x1560799399_entry(V self, V *a);
extern Clo g_list_2efoldl_24s688118489x1560799399_clo;
V g_list_2efoldl_24s901304517x253262467(V, V, V);
V g_list_2efoldl_24s901304517x253262467_entry(V self, V *a);
extern Clo g_list_2efoldl_24s901304517x253262467_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1162912426x1278991032(V);
V g_list_2emap_24f1162912426x1278991032_entry(V self, V *a);
extern Clo g_list_2emap_24f1162912426x1278991032_clo;
V g_list_2emap_24f1162912426x1278991032_24dps(V, V);
V g_list_2emap_24f1162912426x1278991032_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1162912426x1278991032_24dps_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f1457339348x592422294_24dps(V, V, V, V);
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_24dps_clo;
V g_list_2emap_24f1819215186x476901667(V, V, V, V);
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_clo;
V g_list_2emap_24f1819215186x476901667_24dps(V, V, V, V, V);
V g_list_2emap_24f1819215186x476901667_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_24dps_clo;
V g_list_2emap_24f2056124927x822823214_24dps(V, V, V, V);
V g_list_2emap_24f2056124927x822823214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_24dps_clo;
V g_list_2emap_24f489129082x766375942(V, V, V, V, V);
V g_list_2emap_24f489129082x766375942_entry(V self, V *a);
extern Clo g_list_2emap_24f489129082x766375942_clo;
V g_list_2emap_24f489129082x766375942_24dps(V, V, V, V, V, V);
V g_list_2emap_24f489129082x766375942_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f489129082x766375942_24dps_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1275294336x693095586(V, V);
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1412546768x2004463577(V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_clo;
V g_list_2emap_24s1412546768x2004463577_24dps(V, V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s204237290x1967740547_24dps(V, V, V, V, V);
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_24dps_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s275211812x1381242052(V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_clo;
V g_list_2emap_24s275211812x1381242052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_24dps_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s529174x2075875906_24dps(V, V);
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s764064723x821001015_24dps(V, V);
V g_list_2emap_24s764064723x821001015_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_24dps_clo;
V g_list_2emap_24s777254429x1856211654(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_clo;
V g_list_2emap_24s777254429x1856211654_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_24dps_clo;
V g_list_2emap_24s886389550x1086668531_24dps(V, V);
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_24dps_clo;
V g_list_2emap_24s903588428x1469638784(V, V);
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_clo;
V g_list_2emap_24s903588428x1469638784_24dps(V, V, V);
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_24dps_clo;
V g_list_2emerge_24s1081221956x1079757426_24dps(V, V, V);
V g_list_2emerge_24s1081221956x1079757426_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s1958630276x749154843_24dps(V, V, V);
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo;
V g_list_2ezipWith_24s457513469x1891643252(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_clo;
V g_list_2ezipWith_24s457513469x1891643252_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_map_2einsert_24s1364630912x1289064055(V, V, V);
V g_map_2einsert_24s1364630912x1289064055_entry(V self, V *a);
extern Clo g_map_2einsert_24s1364630912x1289064055_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_list_2efind_24s2097169879x1343877600_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_x2_2411) {
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_I8: {
      v_a_2414 = heff_dup(v_lit_240);
      break;
    }
    case TAG_I16: {
      v_a_2414 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I32: {
      v_a_2414 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I64: {
      v_a_2414 = heff_dup(v_lit_243);
      break;
    }
    case TAG_U8: {
      v_a_2414 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U16: {
      v_a_2414 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U32: {
      v_a_2414 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U64: {
      v_a_2414 = heff_dup(v_lit_247);
      break;
    }
    case TAG_F32: {
      v_a_2414 = heff_dup(v_lit_248);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2415 = heff_strSlice(heff_dup(v_lit_249), heff_dup(v_lit_2410), heff_strLength_lent(v_a_2414, 0));
    if (heff_strEq_c(v_t_2415, v_a_2414)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      heff_drop(v_lit_2410);
      heff_drop(v_xs_2413);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2412}});
    } else {
      heff_drop(v_x_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2411)}});
  }
}
Clo g_list_2efoldl_24s1832274453x1963324019_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1832274453x1963324019_entry, 2, 0};

V g_list_2efoldl_24s1832274453x1963324019(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1364630912x1289064055(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1832274453x1963324019_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1832274453x1963324019(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1810610888x1691479932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1810610888x1691479932_entry, 2, 0};

V g_list_2efoldl_24s1810610888x1691479932(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eranges_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1810610888x1691479932(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_24dps_entry, 3, 0};

V g_list_2emerge_24s1347843181x1368204458_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 7);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_y_245, 2)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_248;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2410;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s1081221956x1079757426_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1081221956x1079757426_24dps_entry, 3, 0};

V g_list_2emerge_24s1081221956x1079757426_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 6);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_248;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2410;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1081221956x1079757426_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1081221956x1079757426_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s529174x2075875906_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_entry, 1, 0};

V g_list_2emap_24s529174x2075875906(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s529174x2075875906_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906(a[0]);
}
Clo g_list_2emap_24s529174x2075875906_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_24dps_entry, 2, 0};

V g_list_2emap_24s529174x2075875906_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s205414595x1692305030_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_24dps_entry, 2, 0};

V g_list_2emap_24s205414595x1692305030_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s205414595x1692305030_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1887874170x1747433177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_entry, 1, 0};

V g_list_2emap_24s1887874170x1747433177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2417;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_245;
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_249 = heff_dup(heff_field(v_a_247, 1));
          v_t_2410 = v_a_249;
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_247}), v_t_2410});
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_2412 = v_field_245;
          V v_t_2415;
          switch (heff_tag_of(v_a_2412)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_2412, 1));
            v_t_2415 = v_a_2414;
            break;
          }
          default: heff_nomatch(v_a_2412);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_2412}), v_t_2415});
        } else {
          V v_a_2416 = v_field_245;
          v_t_2417 = v_a_2416;
        }
      }
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s1887874170x1747433177_24dps(v_xs_242, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177(a[0]);
}
Clo g_list_2emap_24s1230969749x2018313496_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_entry, 1, 0};

V g_list_2emap_24s1230969749x2018313496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1230969749x2018313496_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_24dps_entry, 2, 0};

V g_list_2emap_24s386875578x1005587669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1347985788x1836008258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1347985788x1836008258_entry, 2, 0};

V g_list_2efoldl_24s1347985788x1836008258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b_24f368057430x559112032(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1347985788x1836008258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s688118489x1560799399_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s688118489x1560799399_entry, 3, 0};

V g_list_2efoldl_24s688118489x1560799399(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2442;
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2439);
      v_t_2442 = v_z_241;
    } else {
      heff_drop(v_t_2439);
      V v_t_2440 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_t_2441 = (g_heff_2ecompile_2eir_2esizeW(heff_dup(v_lit_240), v_t_2440));
      v_t_2442 = heff_intAdd(v_z_241, v_t_2441);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2442;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s688118489x1560799399_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s688118489x1560799399(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s860380051x1466609135_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s860380051x1466609135_entry, 1, 0};

V g_list_2eany_24s860380051x1466609135(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s860380051x1466609135(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s756915015x218492736_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s756915015x218492736_entry, 1, 0};

V g_list_2eany_24s756915015x218492736(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecopyField(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s756915015x218492736_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s756915015x218492736(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s964765707x1396946999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s964765707x1396946999_entry, 2, 0};

V g_list_2efoldl_24s964765707x1396946999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s964765707x1396946999(a[0], a[1]);
}
Clo g_list_2efilter_24s2085830190x1097871222_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2085830190x1097871222_24dps_entry, 2, 0};

V g_list_2efilter_24s2085830190x1097871222_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_243;
      V t_1 = v_cell_249;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2085830190x1097871222_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2085830190x1097871222_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1460603830x671758883_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_24dps_entry, 3, 0};

V g_list_2emap_24s1460603830x671758883_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2023159590x14712440_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2023159590x14712440_entry, 2, 0};

V g_list_2efoldl_24s2023159590x14712440(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2023159590x14712440(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s777254429x1856211654_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s777254429x1856211654_entry, 11, 0};

V g_list_2emap_24s777254429x1856211654(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      heff_take_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2413, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)));
      v_t_2422 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, v_t_2421));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s777254429x1856211654_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s777254429x1856211654_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s777254429x1856211654(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2efoldl_24s324619290x435523318_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s324619290x435523318_entry, 2, 0};

V g_list_2efoldl_24s324619290x435523318(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efuse_2etailsOf(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s324619290x435523318(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_24dps_entry, 3, 0};

V g_list_2ezipWith_24s738847920x410598254_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_t_2410 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_2412 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 3);
        v_t_2414 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_t_2414, v_y_245}), heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2415;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1791954930x928584331_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1791954930x928584331_entry, 1, 0};

V g_list_2efilter_24s1791954930x928584331(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_RepV: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s1791954930x928584331_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1791954930x928584331_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1791954930x928584331(a[0]);
}
Clo g_list_2emap_24s510639937x1058700299_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_24dps_entry, 2, 0};

V g_list_2emap_24s510639937x1058700299_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 3, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s457513469x1891643252_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s457513469x1891643252_entry, 9, 0};

V g_list_2ezipWith_24s457513469x1891643252(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
      V v_t_2414 = heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246));
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_strAppend(heff_dup(v_lit_245), v_t_2414));
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2415), heff_hole()});
      V v_u_2417 = (g_list_2ezipWith_24s457513469x1891643252_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s457513469x1891643252(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1275294336x693095586_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_entry, 2, 0};

V g_list_2emap_24s1275294336x693095586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2easLent(v_lit_240, v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1275294336x693095586_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1275294336x693095586(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s275211812x1381242052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s275211812x1381242052_entry, 7, 0};

V g_list_2emap_24s275211812x1381242052(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2416 = heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2415));
    V v_t_2417 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), v_t_2416);
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2417), heff_hole()});
    V v_u_2419 = (g_list_2emap_24s275211812x1381242052_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s275211812x1381242052(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s886389550x1086668531_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s886389550x1086668531_24dps_entry, 2, 0};

V g_list_2emap_24s886389550x1086668531_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkSegment: {
        V v_v_246 = heff_field(v_x11_244, 0);
        V v_ty_247 = heff_field(v_x11_244, 1);
        V v_size_248 = heff_field(v_x11_244, 2);
        V v_little_249 = heff_field(v_x11_244, 3);
        V v_signed_2410 = heff_field(v_x11_244, 4);
        heff_take_n(v_x11_244, 31ULL, 5);
        int64_t v_t_2411;
        if ((heff_dup(v_little_249) == NTAG(TAG_True))) {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_2410) == NTAG(TAG_True))) {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)0ULL);
        }
        v_t_2413 = heff_rec_n(5, shape_value__ty__size__flags__span, (V[]){v_v_246, v_ty_247, v_size_248, heff_box_word((v_t_2411 + v_t_2412)), v_sp_245});
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s886389550x1086668531_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s901304517x253262467_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s901304517x253262467_entry, 3, 0};

V g_list_2efoldl_24s901304517x253262467(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        if (heff_strEq_c_lent(v_a_247, v_lit_240, 0)) {
          v_t_2421 = v_z_241;
        } else {
          if (heff_strEq_c_lent(v_a_247, v_a_245, 0)) {
            v_t_2421 = v_z_241;
          } else {
            V v_t_2410 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
            v_t_2421 = heff_tr(heff_call(heff_get_n(v_t_2410, 3, 5), 1, (V[]){v_z_241}));
          }
        }
        break;
      }
      case TAG_PTag: {
        v_t_2421 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2421 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2421 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2421 = v_z_241;
        break;
      }
      case TAG_PBin: {
        v_t_2421 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2421;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s901304517x253262467_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s901304517x253262467(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s337463599x663364213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337463599x663364213_entry, 2, 0};

V g_list_2efoldl_24s337463599x663364213(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s337463599x663364213(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s204237290x1967740547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s204237290x1967740547_24dps_entry, 5, 0};

V g_list_2emap_24s204237290x1967740547_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ebuild_2edriver_2etwiceDiag(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s204237290x1967740547_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efilter_24s1450888590x1561911320_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1450888590x1561911320_24dps_entry, 5, 0};

V g_list_2efilter_24s1450888590x1561911320_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ebuild_2edriver_2emetIn(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_x_245)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1450888590x1561911320_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1450888590x1561911320_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1354328764x1362350361_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_24dps_entry, 2, 0};

V g_list_2emap_24s1354328764x1362350361_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1064353769x1815078842_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1064353769x1815078842_entry, 1, 0};

V g_list_2efilter_24s1064353769x1815078842(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1064353769x1815078842_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1064353769x1815078842(a[0]);
}

HeffT2 g_list_2efind_24s1230956425x1562898054_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 13);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 7);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_list_2efind_24s487054388x274730225_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 13);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s725725455x1186198702_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_24dps_entry, 2, 0};

V g_list_2emap_24s725725455x1186198702_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_242), heff_strLength_lent(v_x_242, 0)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_242, MK_INT(0LL), v_t_244), heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s510830240x893896831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_entry, 2, 0};

V g_list_2emap_24s510830240x893896831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2eupdateSetKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s510830240x893896831_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831(a[0], a[1]);
}
Clo g_list_2emap_24s903588428x1469638784_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s903588428x1469638784_entry, 2, 0};

V g_list_2emap_24s903588428x1469638784(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(v_x_242, 2, 3);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_244), heff_strLength_lent(v_a_244, 0)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice_lent(v_a_244, v_lit_240, v_t_245, 5), heff_hole()});
    V v_u_247 = (g_list_2emap_24s903588428x1469638784_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s903588428x1469638784(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_entry, 2, 0};

V g_list_2ezipWith_24s1958630276x749154843(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 2), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1958630276x749154843_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1958630276x749154843_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 2), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_str0, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str2, 9, "{ name = ");
Clo g_list_2emap_24s404123879x745642248_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_entry, 1, 0};

V g_list_2emap_24s404123879x745642248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 1, 2)));
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s404123879x745642248_str1)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str2), heff_strAppend(v_t_243, v_t_245));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s404123879x745642248_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248(a[0]);
}
Clo g_list_2efilter_24s50027113x1989932102_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s50027113x1989932102_24dps_entry, 3, 0};

V g_list_2efilter_24s50027113x1989932102_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s50027113x1989932102_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s50027113x1989932102_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1345968422x916930247_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1345968422x916930247_entry, 3, 0};

V g_list_2eany_24s1345968422x916930247(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1345968422x916930247_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s1345968422x916930247(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_list_2efind_24s358915833x209356919_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 13);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1472875662x470242985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1472875662x470242985_entry, 2, 0};

V g_list_2efoldl_24s1472875662x470242985(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2edocMdStep(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1472875662x470242985(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1516272141x1201056882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1516272141x1201056882_entry, 3, 0};

V g_list_2efoldl_24s1516272141x1201056882(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 5);
        v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_a_247, heff_dup(v_lit_240), v_a_248}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_a_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1516272141x1201056882(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1026998256x1634433314_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1026998256x1634433314_entry, 2, 0};

V g_list_2efoldl_24s1026998256x1634433314(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1026998256x1634433314(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s302194196x751324068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s302194196x751324068_entry, 2, 0};

V g_list_2efoldl_24s302194196x751324068(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s302194196x751324068(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1875062608x222844981_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1875062608x222844981_24dps_entry, 7, 0};

V g_list_2efilter_24s1875062608x222844981_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_249 = heff_dup(heff_rfield(v_x_247, 1));
    V v_t_2410 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_249), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_249, v_lit_243, 2), NTAG(TAG_Nil)));
    V v_t_2411 = (g_list_2emap_24s649333309x1802289391(v_t_2410));
    V v_a_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      V v_u_2414 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_cell_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2415, v_lit_244, 1)) {
        V v_cell_2418 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_2419 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2418));
        heff_drop(v_u_2419);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_cell_2418;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop_rec(v_x_247, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efilter_24s1875062608x222844981_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1875062608x222844981_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s764064723x821001015_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s764064723x821001015_24dps_entry, 2, 0};

V g_list_2emap_24s764064723x821001015_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 1, 2)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s764064723x821001015_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s764064723x821001015_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s337063435x1366313299_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s337063435x1366313299_24dps_entry, 4, 0};

V g_list_2efilter_24s337063435x1366313299_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x_244, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_240, 0)));
    V v_t_247 = heff_strSlice(heff_dup(v_x_244), heff_box_word(v_t_246), heff_strLength_lent(v_x_244, 0));
    if (heff_strEq_c_lent(v_t_247, v_lit_241, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s337063435x1366313299_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s337063435x1366313299_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1392550889x861369760_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1392550889x861369760_entry, 2, 0};

V g_list_2efilter_24s1392550889x861369760(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_x_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1392550889x861369760_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1392550889x861369760_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1392550889x861369760(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1839921325x671097810_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 8);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s1412546768x2004463577_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1412546768x2004463577_entry, 4, 0};

V g_list_2emap_24s1412546768x2004463577(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2413;
    if (heff_strEq_c_lent(v_a_2411, v_lit_240, 0)) {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_248;
    } else {
      v_t_2413 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s1412546768x2004463577_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1412546768x2004463577_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1412546768x2004463577(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1162912426x1278991032_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1162912426x1278991032_entry, 1, 0};

V g_list_2emap_24f1162912426x1278991032(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    V v_t_2438;
    switch (heff_tag_of(v_t_243)) {
    case TAG_EVar: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_243, 0ULL, 3);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_243, 0ULL, 4);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_243, 0ULL, 3);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_243, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_t_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_241, 2)), NTAG(TAG_Nil)});
      V v_t_2440 = (g_heff_2ecompile_2eworker_2enumericW(v_t_2439));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
        V v_u_2442 = (g_list_2emap_24f1162912426x1278991032_24dps(v_xs_242, heff_dup(v_cell_2441)));
        heff_drop(v_u_2442);
        return v_cell_2441;
      } else {
        heff_drop_rec(v_x_241, 3);
        heff_drop(v_t_2440);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2438);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1162912426x1278991032_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1162912426x1278991032(a[0]);
}
Clo g_list_2emap_24f1457339348x592422294_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1457339348x592422294_entry, 3, 0};

V g_list_2emap_24f1457339348x592422294(V v_lit_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_lit_240);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244 = heff_intShow(heff_strByteAt_lent(v_lit_240, heff_box_word(v_a_241), 2));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f1457339348x592422294_24dps(v_lit_240, heff_box_word((v_a_241 + ((int64_t)1ULL))), v_b_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1457339348x592422294(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24f1668687542x1574966783_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f1668687542x1574966783_entry, 4, 0};

V g_list_2efilter_24f1668687542x1574966783(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_xs_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      goto top;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      if (heff_strEq_c(heff_strSlice_lent(v_x_246, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_246);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        goto top;
      } else {
        V v_cell_248 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_249 = (g_list_2efilter_24f1668687542x1574966783_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f1668687542x1574966783(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f489129082x766375942_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f489129082x766375942_entry, 5, 0};

V g_list_2emap_24f489129082x766375942(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_x_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2411 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_242), heff_strLength_lent(v_a_2410, 0));
    V v_t_2416;
    if (heff_strEq_c(v_t_2411, v_a_2410)) {
      V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2414 = heff_strSlice(heff_dup(v_x_249), heff_intAdd(v_t_2413, heff_dup(v_lit_243)), heff_strLength_lent(v_x_249, 0));
      V v_t_2415 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2414, v_x_249, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop(v_x_249);
      v_t_2416 = NTAG(TAG_Nothing);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24f489129082x766375942_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f489129082x766375942_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f489129082x766375942(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f2056124927x822823214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2056124927x822823214_24dps_entry, 4, 0};

V g_list_2emap_24f2056124927x822823214_24dps(V v_lit_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = (g_std_2epath_2elower_2elow_240(heff_dup(v_lit_240), heff_dup(v_a_241)));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
    V t_2 = v_b_242;
    V t_3 = v_cell_246;
    v_lit_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f2056124927x822823214_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2056124927x822823214_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24f1819215186x476901667_str0, 8, "browser.");
Clo g_list_2emap_24f1819215186x476901667_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1819215186x476901667_entry, 4, 0};

V g_list_2emap_24f1819215186x476901667(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_take_field(v_x_244, 6);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_strSlice(heff_dup(heff_rfield(v_x_244, 0)), MK_INT(0LL), MK_INT(8LL));
      if (heff_strEq_c(v_t_247, ((V)&g_list_2emap_24f1819215186x476901667_str0))) {
        V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242));
        V v_t_2410 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_x_244, 0, 7), heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_249), NTAG(TAG_Nothing)});
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
        V v_u_2412 = (g_list_2emap_24f1819215186x476901667_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      } else {
        heff_drop_rec(v_x_244, 7);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_244, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1819215186x476901667(a[0], a[1], a[2], a[3]);
}