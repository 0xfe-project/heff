// Generated from Hippogriff; do not edit.
#define TAG_AbandonWord 191
#define TAG_Abn 119
#define TAG_AbsConst 94
#define TAG_AbsPath 401
#define TAG_Added 378
#define TAG_AlreadyFlat 359
#define TAG_Ann 234
#define TAG_Anonymous 316
#define TAG_App 266
#define TAG_ArgExplicit 195
#define TAG_ArgNamed 196
#define TAG_ArgProject 166
#define TAG_Args 380
#define TAG_ArrayWord 190
#define TAG_Asg 347
#define TAG_AssocLeft 283
#define TAG_AssocNone 285
#define TAG_AssocRight 284
#define TAG_At 124
#define TAG_Atom 244
#define TAG_Await 394
#define TAG_BAnn 249
#define TAG_BDelayedBy 98
#define TAG_BImp 248
#define TAG_BVar 247
#define TAG_BadFieldDecl 203
#define TAG_BadFieldSet 205
#define TAG_BadVariant 207
#define TAG_Become 49
#define TAG_Bin 11
#define TAG_Braced 281
#define TAG_Braces 239
#define TAG_Bracketed 282
#define TAG_CAbandon 192
#define TAG_CAnnLam 208
#define TAG_CBind 97
#define TAG_CEmpty 96
#define TAG_CImplicitLam 212
#define TAG_CInf 193
#define TAG_CLam 211
#define TAG_CLetIn 215
#define TAG_CLocal 216
#define TAG_CMatch 214
#define TAG_CNominal 226
#define TAG_CStruct 213
#define TAG_CTag 197
#define TAG_CType 194
#define TAG_CUndelay 321
#define TAG_Case 252
#define TAG_Cat 353
#define TAG_Catch 103
#define TAG_CloConst 55
#define TAG_Closed 435
#define TAG_Column 356
#define TAG_DData 269
#define TAG_DEqn 275
#define TAG_DFixity 277
#define TAG_DForeign 273
#define TAG_DImport 276
#define TAG_DSig 274
#define TAG_DTest 278
#define TAG_DTheory 272
#define TAG_DType 270
#define TAG_DWatch 279
#define TAG_De 95
#define TAG_DeclDefine 221
#define TAG_DeclEquations 220
#define TAG_DeclPrimitive 223
#define TAG_DeclTest 224
#define TAG_DeclTheory 222
#define TAG_DeclWatch 225
#define TAG_DeclareField 202
#define TAG_Delay 304
#define TAG_Delayed2 323
#define TAG_Describe 48
#define TAG_Div 120
#define TAG_Do 267
#define TAG_EAbandon 335
#define TAG_EAlt 251
#define TAG_EAnn 137
#define TAG_EApp 132
#define TAG_ECall 333
#define TAG_ECon 241
#define TAG_EDo 144
#define TAG_EFSet 240
#define TAG_EField 237
#define TAG_EFix 336
#define TAG_EFloat 129
#define TAG_EGlobal 328
#define TAG_EImplicitVar 126
#define TAG_EInt 128
#define TAG_EInvalid 146
#define TAG_ELam 136
#define TAG_ELet 255
#define TAG_ELetIn 143
#define TAG_ELocal 145
#define TAG_EMatch 142
#define TAG_ENamed 134
#define TAG_EParen 243
#define TAG_EPi 135
#define TAG_EPrim 331
#define TAG_EPrimCall 332
#define TAG_EProj 330
#define TAG_EProject 133
#define TAG_ERecord 329
#define TAG_ESBind 256
#define TAG_ESig 139
#define TAG_ESpec 138
#define TAG_EStr 334
#define TAG_EString 130
#define TAG_EStruct 141
#define TAG_ESum 140
#define TAG_ETag 127
#define TAG_EVar 125
#define TAG_EWord 131
#define TAG_Eqn 287
#define TAG_Exec 385
#define TAG_Exit 384
#define TAG_Expl 227
#define TAG_ExplicitParam 217
#define TAG_Fail 352
#define TAG_FailBecause 326
#define TAG_FailDiffer 325
#define TAG_FlatAlt 350
#define TAG_Flattened 360
#define TAG_FloatWord 188
#define TAG_ForDescriptive 314
#define TAG_ForNominative 313
#define TAG_Get 100
#define TAG_GetEnv 381
#define TAG_HError 53
#define TAG_HGlobal 51
#define TAG_HLocal 50
#define TAG_HMeta 52
#define TAG_IAnn 161
#define TAG_IAnnLam 163
#define TAG_IApp 160
#define TAG_IFloat 158
#define TAG_IInt 157
#define TAG_IInvalid 164
#define TAG_INominal 165
#define TAG_ISpec 162
#define TAG_IString 159
#define TAG_IVar 156
#define TAG_If 253
#define TAG_Impl 228
#define TAG_ImplicitParam 218
#define TAG_Inlined 337
#define TAG_Inst 229
#define TAG_InstB 238
#define TAG_IntWord 187
#define TAG_IntoCons 43
#define TAG_IsCheckable 173
#define TAG_IsInferable 172
#define TAG_IsType 174
#define TAG_JArray 392
#define TAG_JBool 388
#define TAG_JFloat 390
#define TAG_JInt 389
#define TAG_JNull 387
#define TAG_JObject 393
#define TAG_JString 391
#define TAG_LChunkSnoc 17
#define TAG_LList 368
#define TAG_LNil 15
#define TAG_LRec 369
#define TAG_LSnoc 16
#define TAG_LStr 366
#define TAG_LTag 367
#define TAG_Lam 250
#define TAG_LamAnn 210
#define TAG_LamImplicit 209
#define TAG_LamName 170
#define TAG_Large 13
#define TAG_LargeU 37
#define TAG_Leaf 59
#define TAG_Left 105
#define TAG_LikeArray 35
#define TAG_LikeFloat 33
#define TAG_LikeFunction 29
#define TAG_LikeInt 32
#define TAG_LikeRecord 30
#define TAG_LikeString 34
#define TAG_LikeSum 31
#define TAG_LikeU 27
#define TAG_Line 349
#define TAG_Log 396
#define TAG_Looser 109
#define TAG_MentionsError 298
#define TAG_Message 433
#define TAG_MkAbs 93
#define TAG_MkAlt 171
#define TAG_MkArm 327
#define TAG_MkArmJs 345
#define TAG_MkChain 365
#define TAG_MkChk 315
#define TAG_MkClo 54
#define TAG_MkDAlts 268
#define TAG_MkDelayed 302
#define TAG_MkDir 372
#define TAG_MkEquation 219
#define TAG_MkField 46
#define TAG_MkFieldPat 291
#define TAG_MkFields 289
#define TAG_MkLetHead 254
#define TAG_MkPChain 290
#define TAG_MkSaved 310
#define TAG_MkSep 233
#define TAG_MkSmallTyp 324
#define TAG_MkSt 99
#define TAG_MkSyn 320
#define TAG_MkTF 271
#define TAG_MkTyp 319
#define TAG_MkWanted 303
#define TAG_N 92
#define TAG_Named 245
#define TAG_NamedImplicit 317
#define TAG_NamedInstance 318
#define TAG_Nest 354
#define TAG_Nesting 357
#define TAG_NeverFlat 358
#define TAG_NoRules 28
#define TAG_Nom 45
#define TAG_None 348
#define TAG_NotApplicable 44
#define TAG_NotInScope 322
#define TAG_NotInlined 338
#define TAG_Now 397
#define TAG_Ok 118
#define TAG_Op 235
#define TAG_OpRhs 236
#define TAG_Ops 265
#define TAG_PAs 262
#define TAG_PAtom 263
#define TAG_PCon 259
#define TAG_PFalse 340
#define TAG_PField 257
#define TAG_PIf 343
#define TAG_PList 261
#define TAG_PLit 294
#define TAG_PNot 342
#define TAG_POp 260
#define TAG_PParen 264
#define TAG_PRec 258
#define TAG_PRel 341
#define TAG_PSelf 295
#define TAG_PSeq 344
#define TAG_PTag 293
#define TAG_PTrue 339
#define TAG_PVar 292
#define TAG_PatAs 155
#define TAG_PatFloat 151
#define TAG_PatInt 150
#define TAG_PatOp 149
#define TAG_PatRecord 153
#define TAG_PatString 152
#define TAG_PatTag 148
#define TAG_PatVar 147
#define TAG_PatWord 154
#define TAG_PathUri 400
#define TAG_Pending 308
#define TAG_PiAnon 201
#define TAG_PiImplicit 199
#define TAG_PiInstance 200
#define TAG_PiNamed 198
#define TAG_Plain 280
#define TAG_Platform 383
#define TAG_Plus 60
#define TAG_Posix 376
#define TAG_ProgramPath 382
#define TAG_ProjectFiles 398
#define TAG_Put 101
#define TAG_Quit 402
#define TAG_RAbandoned 122
#define TAG_RDiverged 123
#define TAG_RSucceeded 121
#define TAG_ReadDir 373
#define TAG_ReadFile 370
#define TAG_ReadOnly 375
#define TAG_ReadStdin 431
#define TAG_Record 312
#define TAG_Remove 374
#define TAG_Removed 379
#define TAG_Resolve 307
#define TAG_RestoreDelayed 309
#define TAG_RestoreWaiting 300
#define TAG_Ret 346
#define TAG_Right 104
#define TAG_Run 386
#define TAG_SAbandon 73
#define TAG_SApp 64
#define TAG_SCode 63
#define TAG_SCons 66
#define TAG_SDebug 232
#define TAG_SDecode 83
#define TAG_SEmpty 361
#define TAG_SError 230
#define TAG_SFail 362
#define TAG_SFix 75
#define TAG_SFunction 84
#define TAG_SGlobal 62
#define TAG_SImplicit 76
#define TAG_SIs 71
#define TAG_SIsTy 87
#define TAG_SLam 65
#define TAG_SLine 364
#define TAG_SLitFloat 80
#define TAG_SLitInt 79
#define TAG_SLitString 81
#define TAG_SLocal 61
#define TAG_SMatch 69
#define TAG_SMetaApp 78
#define TAG_SOpaque 72
#define TAG_SPrim 77
#define TAG_SPrimArray 91
#define TAG_SPrimFloat 89
#define TAG_SPrimInt 88
#define TAG_SPrimString 90
#define TAG_SProj 67
#define TAG_SRec 74
#define TAG_SRecord 85
#define TAG_SSpecialize 70
#define TAG_SSum 86
#define TAG_STag 68
#define TAG_SText 363
#define TAG_SU 82
#define TAG_SWarning 231
#define TAG_Same 107
#define TAG_SaveDelayed 301
#define TAG_Send 395
#define TAG_SetField 204
#define TAG_Sig 286
#define TAG_Small 12
#define TAG_SmallU 36
#define TAG_SpApp 56
#define TAG_SpId 58
#define TAG_SpProj 47
#define TAG_SpSpec 57
#define TAG_StmtBind 167
#define TAG_StmtExpr 169
#define TAG_StmtLet 168
#define TAG_StringWord 189
#define TAG_Sum 242
#define TAG_TArray 182
#define TAG_TChk 184
#define TAG_TFloat 180
#define TAG_TInf 183
#define TAG_TInt 179
#define TAG_TNominal 185
#define TAG_TPi 175
#define TAG_TSig 176
#define TAG_TString 181
#define TAG_TSum 177
#define TAG_TType 178
#define TAG_TagVariant 206
#define TAG_Text 351
#define TAG_Throw 102
#define TAG_Tighter 108
#define TAG_Timeout 434
#define TAG_Tip 10
#define TAG_TopL 14
#define TAG_Trace 311
#define TAG_Tup 246
#define TAG_TypeWord 186
#define TAG_Undeclared 106
#define TAG_UnequalEls 297
#define TAG_UnequalNeus 299
#define TAG_UnequalTys 296
#define TAG_Union 355
#define TAG_Unrelated 110
#define TAG_UriPath 399
#define TAG_UseColor 432
#define TAG_VArr 116
#define TAG_VCode 39
#define TAG_VCons 41
#define TAG_VDecode 19
#define TAG_VErased 117
#define TAG_VFloat 114
#define TAG_VFun 111
#define TAG_VFunction 20
#define TAG_VInt 113
#define TAG_VLam 40
#define TAG_VNeu 38
#define TAG_VOpaque 42
#define TAG_VPrimArray 26
#define TAG_VPrimFloat 24
#define TAG_VPrimInt 23
#define TAG_VPrimString 25
#define TAG_VRecord 21
#define TAG_VStr 115
#define TAG_VSum 22
#define TAG_VTag 112
#define TAG_VU 18
#define TAG_Wake 306
#define TAG_Want 305
#define TAG_Whole 288
#define TAG_Windows 377
#define TAG_Write 429
#define TAG_WriteErr 430
#define TAG_WriteFile 371
#define TAG_ambiguous 409
#define TAG_among 423
#define TAG_badShape 417
#define TAG_dirs 422
#define TAG_dirsOnly 425
#define TAG_extra 415
#define TAG_fail 426
#define TAG_files 421
#define TAG_filesBy 424
#define TAG_help 412
#define TAG_many 405
#define TAG_missing 416
#define TAG_missingFlag 413
#define TAG_noValue 410
#define TAG_none 420
#define TAG_notIn 414
#define TAG_nothing 419
#define TAG_one 403
#define TAG_optional 404
#define TAG_out 427
#define TAG_rest 407
#define TAG_run 428
#define TAG_some 406
#define TAG_switchValue 411
#define TAG_unknown 408
#define TAG_words 418
#define LBL_above 0
#define LBL_absolute 1
#define LBL_after 2
#define LBL_alias 3
#define LBL_aliases 4
#define LBL_all 5
#define LBL_altDoc 6
#define LBL_ap 7
#define LBL_app 8
#define LBL_appDoc 9
#define LBL_applyTo 10
#define LBL_arg 11
#define LBL_args 12
#define LBL_arity 13
#define LBL_assoc 14
#define LBL_at 15
#define LBL_atom 16
#define LBL_backend 17
#define LBL_base 18
#define LBL_below 19
#define LBL_bind 20
#define LBL_binder 21
#define LBL_binderDoc 22
#define LBL_binders 23
#define LBL_blank 24
#define LBL_body 25
#define LBL_bor 26
#define LBL_borrowed 27
#define LBL_bounce 28
#define LBL_broken 29
#define LBL_build 30
#define LBL_by 31
#define LBL_byName 32
#define LBL_c 33
#define LBL_cached 34
#define LBL_caseE 35
#define LBL_chainOperand 36
#define LBL_check 37
#define LBL_checked 38
#define LBL_children 39
#define LBL_chk 40
#define LBL_closed 41
#define LBL_cmt 42
#define LBL_cod 43
#define LBL_code 44
#define LBL_col 45
#define LBL_comments 46
#define LBL_compile 47
#define LBL_complete 48
#define LBL_count 49
#define LBL_ctx 50
#define LBL_decl 51
#define LBL_decls 52
#define LBL_def 53
#define LBL_defines 54
#define LBL_defs 55
#define LBL_deps 56
#define LBL_detail 57
#define LBL_diags 58
#define LBL_diff 59
#define LBL_dir 60
#define LBL_discarded 61
#define LBL_doE 62
#define LBL_doc 63
#define LBL_docs 64
#define LBL_dom 65
#define LBL_done 66
#define LBL_doneMods 67
#define LBL_drive 68
#define LBL_due 69
#define LBL_dumpCore 70
#define LBL_dumpEval 71
#define LBL_e 72
#define LBL_edits 73
#define LBL_effect 74
#define LBL_el 75
#define LBL_elabFor 76
#define LBL_elseOf 77
#define LBL_end 78
#define LBL_endLine 79
#define LBL_entries 80
#define LBL_entry 81
#define LBL_env 82
#define LBL_err 83
#define LBL_errors 84
#define LBL_expectFrom 85
#define LBL_expectTo 86
#define LBL_expected 87
#define LBL_explain 88
#define LBL_expr 89
#define LBL_f 90
#define LBL_failed 91
#define LBL_failure 92
#define LBL_field 93
#define LBL_fields 94
#define LBL_file 95
#define LBL_first 96
#define LBL_fix 97
#define LBL_fixities 98
#define LBL_flag 99
#define LBL_flags 100
#define LBL_fmt 101
#define LBL_from 102
#define LBL_fs 103
#define LBL_fuel 104
#define LBL_funs 105
#define LBL_get 106
#define LBL_give 107
#define LBL_given 108
#define LBL_global 109
#define LBL_globals 110
#define LBL_go 111
#define LBL_got 112
#define LBL_groups 113
#define LBL_gs 114
#define LBL_hash 115
#define LBL_hashes 116
#define LBL_head 117
#define LBL_heff 118
#define LBL_hfmap 119
#define LBL_hide 120
#define LBL_hmap 121
#define LBL_holds 122
#define LBL_i 123
#define LBL_id 124
#define LBL_ifE 125
#define LBL_ifLink 126
#define LBL_im 127
#define LBL_implicit 128
#define LBL_implicits 129
#define LBL_imports 130
#define LBL_indent 131
#define LBL_inf 132
#define LBL_infos 133
#define LBL_init 134
#define LBL_inl 135
#define LBL_inline 136
#define LBL_inner 137
#define LBL_insts 138
#define LBL_ir 139
#define LBL_isFloat 140
#define LBL_items 141
#define LBL_ix 142
#define LBL_js 143
#define LBL_k 144
#define LBL_key 145
#define LBL_keys 146
#define LBL_kind 147
#define LBL_kinds 148
#define LBL_known 149
#define LBL_label 150
#define LBL_labels 151
#define LBL_lambda 152
#define LBL_lams 153
#define LBL_large 154
#define LBL_lastTok 155
#define LBL_lazy 156
#define LBL_lbls 157
#define LBL_lead 158
#define LBL_left 159
#define LBL_len 160
#define LBL_lenient 161
#define LBL_letE 162
#define LBL_letHead 163
#define LBL_letLink 164
#define LBL_level 165
#define LBL_lib 166
#define LBL_line 167
#define LBL_lineStart 168
#define LBL_lines 169
#define LBL_local 170
#define LBL_locals 171
#define LBL_long 172
#define LBL_looser 173
#define LBL_lsp 174
#define LBL_m 175
#define LBL_made 176
#define LBL_malg 177
#define LBL_match 178
#define LBL_mel 179
#define LBL_member 180
#define LBL_meta 181
#define LBL_metas 182
#define LBL_mod 183
#define LBL_module 184
#define LBL_msg 185
#define LBL_msp 186
#define LBL_mty 187
#define LBL_multi 188
#define LBL_n 189
#define LBL_name 190
#define LBL_nameSpan 191
#define LBL_names 192
#define LBL_nextMeta 193
#define LBL_nlam 194
#define LBL_noLead 195
#define LBL_noTrail 196
#define LBL_note 197
#define LBL_notes 198
#define LBL_nstr 199
#define LBL_occurrences 200
#define LBL_off 201
#define LBL_offset 202
#define LBL_ok 203
#define LBL_on 204
#define LBL_op 205
#define LBL_opExpr 206
#define LBL_opRhsDoc 207
#define LBL_opens 208
#define LBL_ops 209
#define LBL_opsChainDoc 210
#define LBL_opsCut 211
#define LBL_opsRhsDoc 212
#define LBL_order 213
#define LBL_out 214
#define LBL_outPath 215
#define LBL_own 216
#define LBL_owned 217
#define LBL_owner 218
#define LBL_pE 219
#define LBL_package 220
#define LBL_packages 221
#define LBL_params 222
#define LBL_parts 223
#define LBL_pat 224
#define LBL_patAtom 225
#define LBL_patHead 226
#define LBL_patVars 227
#define LBL_path 228
#define LBL_paths 229
#define LBL_pats 230
#define LBL_pattern 231
#define LBL_pending 232
#define LBL_pkg 233
#define LBL_place 234
#define LBL_plain 235
#define LBL_poisoned 236
#define LBL_pos 237
#define LBL_post 238
#define LBL_postponed 239
#define LBL_pre 240
#define LBL_prec 241
#define LBL_prefix 242
#define LBL_prevEnd 243
#define LBL_prim 244
#define LBL_prims 245
#define LBL_program 246
#define LBL_project 247
#define LBL_promote 248
#define LBL_property 249
#define LBL_protos 250
#define LBL_ps 251
#define LBL_publish 252
#define LBL_ra 253
#define LBL_raw 254
#define LBL_recovered 255
#define LBL_ren 256
#define LBL_renEv 257
#define LBL_renEvTy 258
#define LBL_renFlex 259
#define LBL_renTy 260
#define LBL_renames 261
#define LBL_repeated 262
#define LBL_replace 263
#define LBL_require 264
#define LBL_required 265
#define LBL_rest 266
#define LBL_ret 267
#define LBL_rhs 268
#define LBL_rhsField 269
#define LBL_rhsOf 270
#define LBL_right 271
#define LBL_root 272
#define LBL_run 273
#define LBL_runs 274
#define LBL_safe 275
#define LBL_sapp 276
#define LBL_scope 277
#define LBL_scrutinee 278
#define LBL_seed 279
#define LBL_segments 280
#define LBL_selection 281
#define LBL_self 282
#define LBL_selfKey 283
#define LBL_severity 284
#define LBL_sh 285
#define LBL_shape 286
#define LBL_shapes 287
#define LBL_short 288
#define LBL_shown 289
#define LBL_shrinks 290
#define LBL_shutdown 291
#define LBL_simp 292
#define LBL_sol 293
#define LBL_solStx 294
#define LBL_solve 295
#define LBL_source 296
#define LBL_sources 297
#define LBL_sp 298
#define LBL_span 299
#define LBL_spans 300
#define LBL_specs 301
#define LBL_src 302
#define LBL_st 303
#define LBL_stack 304
#define LBL_start 305
#define LBL_startLine 306
#define LBL_status 307
#define LBL_stmtDoc 308
#define LBL_stop 309
#define LBL_strs 310
#define LBL_stx 311
#define LBL_style 312
#define LBL_supply 313
#define LBL_syntax 314
#define LBL_tag 315
#define LBL_tags 316
#define LBL_take 317
#define LBL_target 318
#define LBL_tests 319
#define LBL_testsFailed 320
#define LBL_text 321
#define LBL_tighter 322
#define LBL_tm 323
#define LBL_to 324
#define LBL_tok 325
#define LBL_tokens 326
#define LBL_toks 327
#define LBL_tool 328
#define LBL_top 329
#define LBL_total 330
#define LBL_trace 331
#define LBL_trail 332
#define LBL_tree 333
#define LBL_trmc 334
#define LBL_trying 335
#define LBL_ty 336
#define LBL_tySyntax 337
#define LBL_typ 338
#define LBL_typeAt 339
#define LBL_type_5f 340
#define LBL_ubare 341
#define LBL_uel 342
#define LBL_underLam 343
#define LBL_uri 344
#define LBL_use 345
#define LBL_used 346
#define LBL_userOps 347
#define LBL_uses 348
#define LBL_uty 349
#define LBL_v 350
#define LBL_val 351
#define LBL_value 352
#define LBL_values 353
#define LBL_vars 354
#define LBL_version 355
#define LBL_vs 356
#define LBL_waiting 357
#define LBL_watch 358
#define LBL_watches 359
#define LBL_within 360
#define LBL_x 361
#define LBL_xs 362
// heff's runtime for the C backend (src/heff/emitc.hf), bundled whole
// into each program it compiles, before the program's own code and its
// worlds' providers (`M.provider.c` beside `M.hf`).
//
// A value is a word.  Its low bit set, it is an integer (`n << 1 | 1`,
// 62 bits and a sign); its low bits `10`, a tag with no fields (`id << 2
// | 2`); otherwise it points to an object, whose header says what it
// is.  Tags are numbered (`TAG_x`), the ones the runtime knows first
// (below), the program's after them; record labels too (`LBL_x`), a
// record's fields in the order it was written with them.  Strings are
// UTF-16 code units, as JavaScript's are, so that what a program
// computes with them is what the other backends compute.
//
// An object is counted (Perceus): each owner of it holds a reference,
// `heff_dup` takes one more and `heff_drop` gives one back, the last
// freeing it.  What a function is given it owns: it consumes it (gives
// it to what it calls, keeps it in what it builds) or drops it -- the
// emitter says where (src/heff/emitc.hf, "Reference counts"); every
// primitive and the runtime's calls consume their arguments too.  What
// is static (a string written in the program, a definition's closure) is
// immortal, its count never changed.  A program runs in a thread of its
// own with a large stack, as the Node.js backend's does.  A call last of an unknown
// function counts itself and every so often gives back a bounce (`K_BNC`),
// let go of where the value is asked for (`heff_tr`), as the JavaScript
// backend does (src/heff/emit.hf, "Tail calls").

#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#include <malloc.h>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#else
#include <alloca.h>
#include <poll.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>
extern char **environ;
#endif
#include <math.h>
#include <pthread.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// (the runtime's state: defined once, in the program's first file; a
// program split into parts (`HEFF_PART`, `heff build`) declares it in the
// others, each of which has its own copy of the runtime's functions)
#ifdef HEFF_PART
#define HEFF_VAR(decl) extern decl
#else
#define HEFF_VAR(decl) decl
#endif

typedef uintptr_t V;

// the tags the runtime knows; a program's own are numbered after them
enum {
  TAG_True, TAG_False, TAG_Nil, TAG_Cons, TAG_MkUnit, TAG_Just, TAG_Nothing,
  TAG_MkPair, TAG_InL, TAG_InR, TAG_KNOWN
};

enum { K_TAG, K_REC, K_CLO, K_PAP, K_STR, K_FLT, K_ARR, K_BNC, K_CELL, K_BIG };

typedef struct Obj {
  uint32_t rc;
  uint16_t kind;
  uint16_t tag;
} Obj;

typedef V (*Fn)(V self, V *args);

typedef struct { Obj h; int64_t n; V f[]; } Tag;
typedef struct { Obj h; int64_t n; uint32_t *lbl; V f[]; } Rec;
// (a closure: its code, how many arguments it takes, and what it holds;
// `memo`, once a thunk -- a function of one argument -- is forced, its
// value, or 0)
typedef struct { Obj h; Fn fn; int32_t arity; int32_t nenv; V memo; V env[]; } Clo;
typedef struct { Obj h; V fun; int32_t n; V a[]; } Pap;
typedef struct { Obj h; int64_t len; int64_t cap; uint16_t s[]; } Str;
typedef struct { Obj h; double d; } Flt;
typedef struct { Obj h; int64_t n; V a[]; } Arr;
typedef struct { Obj h; V fun; int32_t n; V a[]; } Bnc;
typedef struct { Obj h; int32_t neg; int32_t n; uint32_t d[]; } Big;

#define IS_INT(v) (((v) & 1) == 1)
#define INT_OF(v) ((int64_t)(v) >> 1)
#define MK_INT(n) ((V)((((uint64_t)(int64_t)(n)) << 1) | 1))
#define IS_NTAG(v) (((v) & 3) == 2)
#define NTAG(id) ((V)(((uintptr_t)(id) << 2) | 2))
#define OBJ(v) ((Obj *)(v))
#define INT_MAX62 ((int64_t)1 << 61)
#define IS_OBJ(v) (((v) & 3) == 0)
#define IMMORTAL 0x80000000u

static void heff_free(V v);

static inline V heff_dup(V v) {
  if (IS_OBJ(v) && !(OBJ(v)->rc & IMMORTAL)) OBJ(v)->rc++;
  return v;
}

static inline void heff_drop(V v) {
  if (IS_OBJ(v) && !(OBJ(v)->rc & IMMORTAL) && --OBJ(v)->rc == 0) heff_free(v);
}

static inline int heff_unique(V v) { return OBJ(v)->rc == 1; }

// (where a value is asked for that may fail -- `heff compile` without
// `--name`, each definition printed -- a failure is caught there, and
// said; otherwise it ends the program)
HEFF_VAR(jmp_buf *heff_catch);
HEFF_VAR(const char *heff_caught);

static void heff_fail(const char *why) {
  if (heff_catch) { heff_caught = why; longjmp(*heff_catch, 1); }
  fflush(stdout);
  fprintf(stderr, "heff: %s\n", why);
  exit(1);
}

static V heff_abandon(void) {
  if (heff_catch) { heff_caught = "heff:abandon"; longjmp(*heff_catch, 1); }
  fflush(stdout);
  fprintf(stderr, "heff:abandon\n");
  exit(1);
}

static V heff_nomatch(V s);

static void *heff_alloc(size_t n) {
  void *p = malloc(n);
  if (!p) heff_fail("out of memory");
  return p;
}

// Objects are small and made and given back all the time (a
// computation's continuations, its operations): those of up to
// `SMALL_MAX` bytes come from free lists, one for each multiple of 8
// bytes, an object given back kept for the next of its size.
// (`-DSMALL_MAX=0`: none kept, every object given back to the system, so
// that AddressSanitizer sees a use after its last reference)
#ifndef SMALL_MAX
#define SMALL_MAX 128
#endif
HEFF_VAR(void *heff_free_list[SMALL_MAX / 8 + 1]);

static inline void *heff_obj_alloc(size_t n) {
  size_t c = (n + 7) / 8;
  if (c <= SMALL_MAX / 8 && heff_free_list[c]) {
    void *p = heff_free_list[c];
    heff_free_list[c] = *(void **)p;
    return p;
  }
  return heff_alloc(c * 8);
}

static inline void heff_obj_free(void *p, size_t n) {
  size_t c = (n + 7) / 8;
  if (c <= SMALL_MAX / 8) {
    *(void **)p = heff_free_list[c];
    heff_free_list[c] = p;
  } else free(p);
}

static inline int heff_tag_of(V v) {
  return IS_NTAG(v) ? (int)(v >> 2) : OBJ(v)->tag;
}

static V heff_tag(int id, int64_t n, V *f) {
  if (n == 0) return NTAG(id);
  Tag *t = heff_obj_alloc(sizeof(Tag) + n * sizeof(V));
  t->h.rc = 1; t->h.kind = K_TAG; t->h.tag = (uint16_t)id; t->n = n;
  memcpy(t->f, f, n * sizeof(V));
  return (V)t;
}

static inline V heff_field(V v, int i) { return ((Tag *)v)->f[i]; }

// (the labels, in the order the record was written, are the program's:
// one array for each)
static V heff_rec(int64_t n, uint32_t *lbl, V *f) {
  Rec *r = heff_obj_alloc(sizeof(Rec) + n * sizeof(V));
  r->h.rc = 1; r->h.kind = K_REC; r->h.tag = 0; r->n = n; r->lbl = lbl;
  memcpy(r->f, f, n * sizeof(V));
  return (V)r;
}

// (a field, the record consumed)
static V heff_get(V v, uint32_t l) {
  Rec *r = (Rec *)v;
  for (int64_t i = 0; i < r->n; i++)
    if (r->lbl[i] == l) {
      V x = heff_dup(r->f[i]);
      heff_drop(v);
      return x;
    }
  heff_fail("no such field");
  return 0;
}

// (a match's scrutinee given up on an arm, which takes the fields in
// `keep` (a bit each): its last reference, its shell freed and the
// other fields dropped; otherwise each kept field counted)
static inline void heff_take(V v, uint64_t keep) {
  if (!IS_OBJ(v)) return;
  Tag *t = (Tag *)v;
  if (t->h.rc == 1) {
    for (int64_t i = 0; i < t->n; i++)
      if (!((keep >> i) & 1)) heff_drop(t->f[i]);
    heff_obj_free(t, sizeof(Tag) + t->n * sizeof(V));
  } else {
    for (int64_t i = 0; i < t->n; i++)
      if ((keep >> i) & 1) heff_dup(t->f[i]);
    if (!(t->h.rc & IMMORTAL)) t->h.rc--;
  }
}

// (as `heff_take`, the cell kept for a tag of its size to be built in
// (`heff_tag_at`): its last reference, the cell itself, its fields
// taken or dropped and blanked; otherwise none, 0)
static inline V heff_take_reuse(V v, uint64_t keep) {
  Tag *t = (Tag *)v;
  if (t->h.rc == 1) {
    for (int64_t i = 0; i < t->n; i++) {
      if (!((keep >> i) & 1)) heff_drop(t->f[i]);
      t->f[i] = MK_INT(0);
    }
    return v;
  }
  for (int64_t i = 0; i < t->n; i++)
    if ((keep >> i) & 1) heff_dup(t->f[i]);
  if (!(t->h.rc & IMMORTAL)) t->h.rc--;
  return MK_INT(0);
}

// (a tag built in the cell `r` kept for it, or a new one)
static inline V heff_tag_at(V r, int id, int64_t n, V *f) {
  if (!IS_OBJ(r)) return heff_tag(id, n, f);
  Tag *t = (Tag *)r;
  t->h.tag = (uint16_t)id;
  memcpy(t->f, f, n * sizeof(V));
  return r;
}

static V heff_clo(Fn fn, int arity, int nenv, V *env) {
  Clo *c = heff_obj_alloc(sizeof(Clo) + nenv * sizeof(V));
  c->h.rc = 1; c->h.kind = K_CLO; c->h.tag = 0;
  c->fn = fn; c->arity = arity; c->nenv = nenv; c->memo = 0;
  if (nenv) memcpy(c->env, env, nenv * sizeof(V));
  return (V)c;
}

static inline V *heff_env(V self) { return ((Clo *)self)->env; }

// (the last reference gone: what it holds given back, then itself)
// (an object's size, from what it is)
static size_t heff_size(V v) {
  Obj *o = OBJ(v);
  switch (o->kind) {
  case K_TAG: return sizeof(Tag) + ((Tag *)v)->n * sizeof(V);
  case K_REC: return sizeof(Rec) + ((Rec *)v)->n * sizeof(V);
  case K_CLO: return sizeof(Clo) + ((Clo *)v)->nenv * sizeof(V);
  case K_PAP: return sizeof(Pap) + ((Pap *)v)->n * sizeof(V);
  case K_STR: return sizeof(Str) + ((Str *)v)->cap * sizeof(uint16_t);
  case K_FLT: return sizeof(Flt);
  case K_ARR: return sizeof(Arr) + ((Arr *)v)->n * sizeof(V);
  case K_BNC: return sizeof(Bnc) + ((Bnc *)v)->n * sizeof(V);
  case K_BIG: return sizeof(Big) + ((Big *)v)->n * sizeof(uint32_t);
  default: return SMALL_MAX + 1;
  }
}

// (what is given back, a stack of it, not a recursion: a long list's
// cells given back one after another, the stack as deep as the list
// never)
HEFF_VAR(V *heff_dead);
HEFF_VAR(size_t heff_ndead);
HEFF_VAR(size_t heff_cdead);

static inline void heff_dead_push(V v) {
  if (!IS_OBJ(v) || (OBJ(v)->rc & IMMORTAL) || --OBJ(v)->rc != 0) return;
  if (heff_ndead == heff_cdead) {
    heff_cdead = heff_cdead ? heff_cdead * 2 : 1024;
    heff_dead = realloc(heff_dead, heff_cdead * sizeof(V));
    if (!heff_dead) heff_fail("out of memory");
  }
  heff_dead[heff_ndead++] = v;
}

__attribute__((noinline)) static void heff_free(V v) {
  size_t base = heff_ndead;
  OBJ(v)->rc = 1;
  heff_dead_push(v);
  while (heff_ndead > base) {
    V w = heff_dead[--heff_ndead];
    Obj *o = OBJ(w);
    switch (o->kind) {
    case K_TAG: { Tag *t = (Tag *)w; for (int64_t i = 0; i < t->n; i++) heff_dead_push(t->f[i]); break; }
    case K_REC: { Rec *r = (Rec *)w; for (int64_t i = 0; i < r->n; i++) heff_dead_push(r->f[i]); break; }
    case K_CLO: { Clo *c = (Clo *)w; for (int i = 0; i < c->nenv; i++) heff_dead_push(c->env[i]); if (c->memo) heff_dead_push(c->memo); break; }
    case K_PAP: { Pap *p = (Pap *)w; heff_dead_push(p->fun); for (int i = 0; i < p->n; i++) heff_dead_push(p->a[i]); break; }
    case K_ARR: { Arr *r = (Arr *)w; for (int64_t i = 0; i < r->n; i++) heff_dead_push(r->a[i]); break; }
    case K_BNC: { Bnc *b = (Bnc *)w; heff_dead_push(b->fun); for (int i = 0; i < b->n; i++) heff_dead_push(b->a[i]); break; }
    default: break;
    }
    heff_obj_free(o, heff_size(w));
  }
}

// Calls of what is not known
// ---------------------------------------------------------------------

HEFF_VAR(long heff_dep);

static V heff_apply(V f, int n, V *a);

static V heff_trs(V r) {
  do {
    Bnc *b = (Bnc *)r;
    heff_dep = 0;
    V fun = b->fun;
    int n = b->n;
    V *a = alloca(n * sizeof(V));
    memcpy(a, b->a, n * sizeof(V));
    heff_obj_free(b, sizeof(Bnc) + n * sizeof(V));
    r = heff_apply(fun, n, a);
  } while (!IS_INT(r) && !IS_NTAG(r) && OBJ(r)->kind == K_BNC);
  return r;
}

static inline V heff_tr(V r) {
  return (!IS_INT(r) && !IS_NTAG(r) && OBJ(r)->kind == K_BNC) ? heff_trs(r) : r;
}

static V heff_bounce(V f, int n, V *a) {
  Bnc *b = heff_obj_alloc(sizeof(Bnc) + n * sizeof(V));
  b->h.rc = 1; b->h.kind = K_BNC; b->h.tag = 0; b->fun = f; b->n = n;
  memcpy(b->a, a, n * sizeof(V));
  return (V)b;
}

// (a call last: counted, and every so often a bounce)
static inline V heff_tail(V f, int n, V *a) {
  if (++heff_dep > 500) return heff_bounce(f, n, a);
  return heff_apply(f, n, a);
}

static V heff_apply(V f, int n, V *a) {
  for (;;) {
    Obj *o = OBJ(f);
    if (o->kind == K_PAP) {
      // (its arguments before the ones given: taken over where it is
      // held only here, else shared)
      Pap *p = (Pap *)f;
      int pn = p->n, m = pn + n;
      V *all = alloca(m * sizeof(V));
      V fun;
      if (heff_unique(f)) {
        memcpy(all, p->a, pn * sizeof(V));
        fun = p->fun;
        heff_obj_free(p, sizeof(Pap) + pn * sizeof(V));
      } else {
        for (int i = 0; i < pn; i++) all[i] = heff_dup(p->a[i]);
        fun = heff_dup(p->fun);
        heff_drop(f);
      }
      memcpy(all + pn, a, n * sizeof(V));
      f = fun; a = all; n = m;
      continue;
    }
    if (o->kind != K_CLO) heff_fail("applying what is not a function");
    Clo *c = (Clo *)f;
    // (a thunk forced: its value kept on it, so that forcing it again does
    // not compute it again -- the language is pure, `f MkUnit` is the same
    // value every time -- as the JavaScript backend's `$force` keeps it)
    if (n == 1 && c->arity == 1 && a[0] == NTAG(TAG_MkUnit)) {
      if (c->memo) {
        V r = heff_dup(c->memo);
        heff_drop(f);
        return r;
      }
      if (heff_unique(f)) return c->fn(f, a);
      heff_dup(f);
      V r = heff_tr(c->fn(f, a));
      c->memo = heff_dup(r);
      heff_drop(f);
      return r;
    }
    if (n == c->arity) return c->fn(f, a);
    if (n < c->arity) {
      Pap *p = heff_obj_alloc(sizeof(Pap) + n * sizeof(V));
      p->h.rc = 1; p->h.kind = K_PAP; p->h.tag = 0; p->fun = f; p->n = n;
      memcpy(p->a, a, n * sizeof(V));
      return (V)p;
    }
    // (more arguments than it takes: the rest given to what it gives --
    // its arity read first, the closure consumed by the call)
    int ar = c->arity;
    V r = heff_tr(c->fn(f, a));
    f = r; a = a + ar; n = n - ar;
  }
}

static inline V heff_app1(V f, V x) { return heff_apply(f, 1, &x); }

// Integers
// ---------------------------------------------------------------------
// An integer is a word while it fits in 62 bits (`MK_INT`); beyond, a
// big one (`K_BIG`): its sign and its magnitude's 32-bit digits, the
// least first.  Each result fitting in a word is one, so that two equal
// integers are both words or both big.

// (an integer's sign and digits, to compute with: a word's in `buf`)
typedef struct { int neg; int n; const uint32_t *d; uint32_t buf[2]; } Num;

static void num_of(V v, Num *x) {
  if (IS_INT(v)) {
    int64_t i = INT_OF(v);
    uint64_t m = i < 0 ? (uint64_t)0 - (uint64_t)i : (uint64_t)i;
    x->neg = i < 0;
    x->buf[0] = (uint32_t)m;
    x->buf[1] = (uint32_t)(m >> 32);
    x->n = x->buf[1] ? 2 : x->buf[0] ? 1 : 0;
    x->d = x->buf;
  } else {
    Big *b = (Big *)v;
    x->neg = b->neg; x->n = b->n; x->d = b->d;
  }
}

// (digits as an integer: a word if they fit)
static V big_make(int neg, const uint32_t *d, int n) {
  while (n > 0 && d[n - 1] == 0) n--;
  if (n <= 2) {
    uint64_t m = n == 0 ? 0 : n == 1 ? d[0] : ((uint64_t)d[1] << 32) | d[0];
    if (m < (uint64_t)INT_MAX62) return MK_INT(neg ? -(int64_t)m : (int64_t)m);
  }
  Big *b = heff_obj_alloc(sizeof(Big) + n * sizeof(uint32_t));
  b->h.rc = 1; b->h.kind = K_BIG; b->h.tag = 0; b->neg = neg; b->n = n;
  memcpy(b->d, d, n * sizeof(uint32_t));
  return (V)b;
}

static V heff_int(int64_t i) {
  if (i < INT_MAX62 && i > -INT_MAX62) return MK_INT(i);
  uint64_t m = i < 0 ? (uint64_t)0 - (uint64_t)i : (uint64_t)i;
  uint32_t d[2] = { (uint32_t)m, (uint32_t)(m >> 32) };
  return big_make(i < 0, d, 2);
}

static int mag_cmp(const uint32_t *a, int an, const uint32_t *b, int bn) {
  if (an != bn) return an < bn ? -1 : 1;
  for (int i = an - 1; i >= 0; i--)
    if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
  return 0;
}

// (`o` has room for max(an, bn) + 1 digits)
static int mag_add(const uint32_t *a, int an, const uint32_t *b, int bn, uint32_t *o) {
  if (an < bn) { const uint32_t *t = a; a = b; b = t; int tn = an; an = bn; bn = tn; }
  uint64_t c = 0;
  for (int i = 0; i < an; i++) {
    c += (uint64_t)a[i] + (i < bn ? b[i] : 0);
    o[i] = (uint32_t)c;
    c >>= 32;
  }
  o[an] = (uint32_t)c;
  return an + 1;
}

// (a - b, a's magnitude not below b's)
static int mag_sub(const uint32_t *a, int an, const uint32_t *b, int bn, uint32_t *o) {
  int64_t c = 0;
  for (int i = 0; i < an; i++) {
    c += (int64_t)a[i] - (i < bn ? b[i] : 0);
    o[i] = (uint32_t)c;
    c = c < 0 ? -1 : 0;
  }
  return an;
}

// (a + b, signed)
static V num_add(const Num *a, int bneg, const Num *b) {
  int n = (a->n > b->n ? a->n : b->n) + 1;
  uint32_t *o = alloca(n * sizeof(uint32_t));
  if (a->neg == bneg) return big_make(a->neg, o, mag_add(a->d, a->n, b->d, b->n, o));
  if (mag_cmp(a->d, a->n, b->d, b->n) >= 0) return big_make(a->neg, o, mag_sub(a->d, a->n, b->d, b->n, o));
  return big_make(bneg, o, mag_sub(b->d, b->n, a->d, a->n, o));
}

// (u divided by v, v's top digit not 0, as Knuth's algorithm D:
// q gets m - n + 1 digits, r n)
static void mag_divmod(const uint32_t *u, int m, const uint32_t *v, int n, uint32_t *q, uint32_t *r) {
  if (m < n) {
    memcpy(r, u, m * sizeof(uint32_t));
    memset(r + m, 0, (n - m) * sizeof(uint32_t));
    return;
  }
  if (n == 1) {
    uint64_t k = 0;
    for (int j = m - 1; j >= 0; j--) {
      uint64_t t = (k << 32) | u[j];
      q[j] = (uint32_t)(t / v[0]);
      k = t - (uint64_t)q[j] * v[0];
    }
    r[0] = (uint32_t)k;
    return;
  }
  int s = __builtin_clz(v[n - 1]);
  uint32_t *vn = alloca(n * sizeof(uint32_t)), *un = alloca((m + 1) * sizeof(uint32_t));
  for (int i = n - 1; i > 0; i--) vn[i] = (v[i] << s) | (s ? v[i - 1] >> (32 - s) : 0);
  vn[0] = v[0] << s;
  un[m] = s ? u[m - 1] >> (32 - s) : 0;
  for (int i = m - 1; i > 0; i--) un[i] = (u[i] << s) | (s ? u[i - 1] >> (32 - s) : 0);
  un[0] = u[0] << s;
  for (int j = m - n; j >= 0; j--) {
    uint64_t num = ((uint64_t)un[j + n] << 32) | un[j + n - 1];
    uint64_t qhat = num / vn[n - 1], rhat = num - qhat * vn[n - 1];
    while (qhat >> 32 || qhat * vn[n - 2] > ((rhat << 32) | un[j + n - 2])) {
      qhat--;
      rhat += vn[n - 1];
      if (rhat >> 32) break;
    }
    int64_t k = 0, t;
    for (int i = 0; i < n; i++) {
      uint64_t p = qhat * vn[i];
      t = (int64_t)un[i + j] - k - (int64_t)(p & 0xFFFFFFFFu);
      un[i + j] = (uint32_t)t;
      k = (int64_t)(p >> 32) - (t >> 32);
    }
    t = (int64_t)un[j + n] - k;
    un[j + n] = (uint32_t)t;
    q[j] = (uint32_t)qhat;
    if (t < 0) {
      q[j]--;
      k = 0;
      for (int i = 0; i < n; i++) {
        t = (int64_t)un[i + j] + vn[i] + k;
        un[i + j] = (uint32_t)t;
        k = t >> 32;
      }
      un[j + n] += (uint32_t)k;
    }
  }
  for (int i = 0; i < n; i++) r[i] = (un[i] >> s) | (s ? un[i + 1] << (32 - s) : 0);
}

// (a divided by b, rounded down, as the other backends round: the
// quotient, or the remainder (b's sign))
static V num_divmod(const Num *a, const Num *b, int want_mod) {
  int qn = a->n - b->n + 1 > 0 ? a->n - b->n + 1 : 1;
  uint32_t *q = alloca((qn + 1) * sizeof(uint32_t)), *r = alloca((b->n + 1) * sizeof(uint32_t));
  memset(q, 0, (qn + 1) * sizeof(uint32_t));
  mag_divmod(a->d, a->n, b->d, b->n, q, r);
  int rn = b->n;
  while (rn > 0 && r[rn - 1] == 0) rn--;
  int down = rn > 0 && a->neg != b->neg;
  if (want_mod) {
    if (!down) return big_make(a->neg, r, rn);
    uint32_t *o = alloca((b->n + 1) * sizeof(uint32_t));
    return big_make(b->neg, o, mag_sub(b->d, b->n, r, rn, o));
  }
  if (!down) return big_make(a->neg != b->neg, q, qn);
  uint32_t one = 1, *o = alloca((qn + 2) * sizeof(uint32_t));
  return big_make(1, o, mag_add(q, qn, &one, 1, o));
}

// (the two integers' operation, both consumed: `big`'s value, or, both
// words, what the rest says)
#define INT2(name, big, ...)                                          \
  static V name(V a, V b) {                                           \
    if (IS_INT(a) && IS_INT(b)) {                                     \
      int64_t x = INT_OF(a), y = INT_OF(b);                           \
      __VA_ARGS__                                                     \
    }                                                                 \
    Num x, y;                                                         \
    num_of(a, &x);                                                    \
    num_of(b, &y);                                                    \
    V r = big;                                                        \
    heff_drop(a);                                                     \
    heff_drop(b);                                                     \
    return r;                                                         \
  }

static V num_mul(const Num *a, const Num *b) {
  int n = a->n + b->n;
  uint32_t *o = alloca((n + 1) * sizeof(uint32_t));
  memset(o, 0, (n + 1) * sizeof(uint32_t));
  for (int i = 0; i < a->n; i++) {
    uint64_t c = 0;
    for (int j = 0; j < b->n; j++) {
      c += (uint64_t)a->d[i] * b->d[j] + o[i + j];
      o[i + j] = (uint32_t)c;
      c >>= 32;
    }
    o[i + b->n] = (uint32_t)c;
  }
  return big_make(a->neg != b->neg, o, n);
}

static int num_cmp(const Num *a, const Num *b) {
  if (a->neg != b->neg) return a->neg ? -1 : 1;
  int c = mag_cmp(a->d, a->n, b->d, b->n);
  return a->neg ? -c : c;
}

INT2(heff_intAdd, num_add(&x, y.neg, &y), return heff_int(x + y);)
INT2(heff_intSub, num_add(&x, !y.neg && y.n > 0, &y), return heff_int(x - y);)
INT2(heff_intMul, num_mul(&x, &y),
     int64_t r;
     if (!__builtin_mul_overflow(x, y, &r)) return heff_int(r);)
INT2(heff_intDiv, y.n == 0 ? heff_abandon() : num_divmod(&x, &y, 0),
     if (y == 0) return heff_abandon();
     int64_t q = x / y, r = x % y;
     if (r != 0 && ((r < 0) != (y < 0))) q -= 1;
     return heff_int(q);)
INT2(heff_intMod, y.n == 0 ? heff_abandon() : num_divmod(&x, &y, 1),
     if (y == 0) return heff_abandon();
     int64_t r = x % y;
     if (r != 0 && ((r < 0) != (y < 0))) r += y;
     return heff_int(r);)

#define heff_bool(b) ((b) ? NTAG(TAG_True) : NTAG(TAG_False))

INT2(heff_intEq, heff_bool(num_cmp(&x, &y) == 0), return heff_bool(x == y);)
INT2(heff_intLt, heff_bool(num_cmp(&x, &y) < 0), return heff_bool(x < y);)
INT2(heff_intLe, heff_bool(num_cmp(&x, &y) <= 0), return heff_bool(x <= y);)

// (an integer's decimal digits, a '-' before a negative one: malloc'd)
static char *heff_int_cstr(V v) {
  Num x;
  num_of(v, &x);
  uint32_t *m = alloca((x.n + 1) * sizeof(uint32_t));
  memcpy(m, x.d, x.n * sizeof(uint32_t));
  int n = x.n;
  size_t cap = (size_t)n * 10 + 3, at = cap;
  char *c = heff_alloc(cap);
  c[--at] = 0;
  do {
    uint64_t k = 0;
    for (int j = n - 1; j >= 0; j--) {
      uint64_t t = (k << 32) | m[j];
      m[j] = (uint32_t)(t / 1000000000u);
      k = t % 1000000000u;
    }
    while (n > 0 && m[n - 1] == 0) n--;
    for (int i = 0; i < 9 && (n > 0 || k > 0 || i == 0); i++) {
      c[--at] = (char)('0' + k % 10);
      k /= 10;
    }
  } while (n > 0);
  if (x.neg) c[--at] = '-';
  memmove(c, c + at, cap - at);
  return c;
}

// (an integer written in the program, beyond a word: made once, kept)
static V heff_big_lit(const char *s) {
  int neg = *s == '-';
  if (neg) s++;
  size_t len = strlen(s);
  int cap = (int)(len / 9) + 2, n = 0;
  uint32_t *d = alloca(cap * sizeof(uint32_t));
  for (size_t i = 0; i < len;) {
    uint64_t chunk = 0, scale = 1;
    for (int k = 0; k < 9 && i < len; k++, i++) { chunk = chunk * 10 + (uint64_t)(s[i] - '0'); scale *= 10; }
    uint64_t c = chunk;
    for (int j = 0; j < n; j++) {
      c += (uint64_t)d[j] * scale;
      d[j] = (uint32_t)c;
      c >>= 32;
    }
    if (c) d[n++] = (uint32_t)c;
  }
  V v = big_make(neg, d, n);
  if (IS_OBJ(v)) OBJ(v)->rc = IMMORTAL;
  return v;
}
#define HEFF_BIG(s) ({ static V heff_lit_; heff_lit_ ? heff_lit_ : (heff_lit_ = heff_big_lit(s)); })

// (a float's integer part, beyond a word if it must be)
static V heff_int_of_double(double f) {
  if (f < (double)INT_MAX62 && f > -(double)INT_MAX62) return MK_INT((int64_t)f);
  int e;
  double fr = frexp(fabs(f), &e);
  uint64_t mant = (uint64_t)ldexp(fr, 53);
  int sh = e - 53, n = sh / 32 + 3;
  uint32_t *d = alloca(n * sizeof(uint32_t));
  memset(d, 0, n * sizeof(uint32_t));
  int w = sh / 32, b = sh % 32;
  unsigned __int128 x = (unsigned __int128)mant << b;
  d[w] = (uint32_t)x;
  d[w + 1] = (uint32_t)(x >> 32);
  d[w + 2] = (uint32_t)(x >> 64);
  return big_make(f < 0, d, n);
}

static double heff_double_of_int(V v) {
  if (IS_INT(v)) return (double)INT_OF(v);
  char *c = heff_int_cstr(v);
  double d = strtod(c, NULL);
  free(c);
  return d;
}

// Strings
// ---------------------------------------------------------------------

static Str *heff_str_new(int64_t len) {
  Str *s = heff_obj_alloc(sizeof(Str) + len * sizeof(uint16_t));
  s->h.rc = 1; s->h.kind = K_STR; s->h.tag = 0; s->len = len; s->cap = len;
  return s;
}

static V heff_str_ascii(const char *c) {
  int64_t n = (int64_t)strlen(c);
  Str *s = heff_str_new(n);
  for (int64_t i = 0; i < n; i++) s->s[i] = (uint16_t)(unsigned char)c[i];
  return (V)s;
}

// (UTF-8 in, as read; UTF-16 kept)
static V heff_str_utf8(const unsigned char *c, int64_t n) {
  Str *s = heff_str_new(n);
  int64_t k = 0;
  for (int64_t i = 0; i < n;) {
    uint32_t u = c[i];
    int extra = u >= 0xF0 ? 3 : u >= 0xE0 ? 2 : u >= 0xC0 ? 1 : 0;
    if (extra) u &= (0x3F >> extra);
    i++;
    for (int j = 0; j < extra && i < n; j++, i++) u = (u << 6) | (c[i] & 0x3F);
    if (u >= 0x10000) {
      u -= 0x10000;
      s->s[k++] = (uint16_t)(0xD800 + (u >> 10));
      s->s[k++] = (uint16_t)(0xDC00 + (u & 0x3FF));
    } else s->s[k++] = (uint16_t)u;
  }
  s->len = k;
  return (V)s;
}

// (UTF-16 out, as UTF-8)
// (a string written out as UTF-8: encoded into a buffer, written a
// buffer at a time, not a byte -- each fputc takes the stream's lock)
static void heff_put(FILE *f, V v) {
  Str *s = (Str *)v;
  unsigned char buf[8192];
  size_t n = 0;
  for (int64_t i = 0; i < s->len; i++) {
    uint32_t u = s->s[i];
    if (u >= 0xD800 && u < 0xDC00 && i + 1 < s->len) {
      uint32_t w = s->s[i + 1];
      if (w >= 0xDC00 && w < 0xE000) { u = 0x10000 + ((u - 0xD800) << 10) + (w - 0xDC00); i++; }
    }
    if (n > sizeof buf - 4) { fwrite(buf, 1, n, f); n = 0; }
    if (u < 0x80) buf[n++] = (unsigned char)u;
    else if (u < 0x800) { buf[n++] = (unsigned char)(0xC0 | (u >> 6)); buf[n++] = (unsigned char)(0x80 | (u & 0x3F)); }
    else if (u < 0x10000) { buf[n++] = (unsigned char)(0xE0 | (u >> 12)); buf[n++] = (unsigned char)(0x80 | ((u >> 6) & 0x3F)); buf[n++] = (unsigned char)(0x80 | (u & 0x3F)); }
    else { buf[n++] = (unsigned char)(0xF0 | (u >> 18)); buf[n++] = (unsigned char)(0x80 | ((u >> 12) & 0x3F)); buf[n++] = (unsigned char)(0x80 | ((u >> 6) & 0x3F)); buf[n++] = (unsigned char)(0x80 | (u & 0x3F)); }
  }
  if (n) fwrite(buf, 1, n, f);
}

// (the first string, its last reference, grown in place, room made for
// twice what it needs -- a string built a piece at a time copied a
// logarithmic number of times, not once a piece)
static V heff_strAppend(V a, V b) {
  Str *x = (Str *)a, *y = (Str *)b;
  int64_t n = x->len + y->len;
  if (x->h.rc == 1) {
    if (n > x->cap) {
      int64_t cap = n > 2 * x->cap ? n : 2 * x->cap;
      size_t was = (sizeof(Str) + x->cap * sizeof(uint16_t) + 7) / 8 * 8;
      // (from the allocator objects are given back to, rounded as it
      // rounds: a block it frees to a free list must be the whole of
      // that list's size)
      Str *g = heff_obj_alloc(sizeof(Str) + cap * sizeof(uint16_t));
      memcpy(g, x, sizeof(Str) + x->len * sizeof(uint16_t));
      heff_obj_free(x, was);
      g->cap = cap;
      x = g;
    }
    memcpy(x->s + x->len, y->s, y->len * sizeof(uint16_t));
    x->len = n;
    heff_drop(b);
    return (V)x;
  }
  Str *s = heff_str_new(n);
  memcpy(s->s, x->s, x->len * sizeof(uint16_t));
  memcpy(s->s + x->len, y->s, y->len * sizeof(uint16_t));
  heff_drop(a);
  heff_drop(b);
  return (V)s;
}

static V heff_strLength(V a) {
  V n = MK_INT(((Str *)a)->len);
  heff_drop(a);
  return n;
}

// (as JavaScript's `slice`: out of range is clamped, negative from the end)
static V heff_strSlice(V a, V i, V j) {
  Str *x = (Str *)a;
  int64_t n = x->len, b = INT_OF(i), e = INT_OF(j);
  if (b < 0) b = b + n < 0 ? 0 : b + n;
  if (e < 0) e = e + n < 0 ? 0 : e + n;
  if (b > n) b = n;
  if (e > n) e = n;
  if (e < b) e = b;
  Str *s = heff_str_new(e - b);
  memcpy(s->s, x->s + b, (e - b) * sizeof(uint16_t));
  heff_drop(a);
  return (V)s;
}

static int heff_str_cmp(V a, V b) {
  Str *x = (Str *)a, *y = (Str *)b;
  int64_t n = x->len < y->len ? x->len : y->len;
  for (int64_t i = 0; i < n; i++)
    if (x->s[i] != y->s[i]) return x->s[i] < y->s[i] ? -1 : 1;
  return x->len == y->len ? 0 : x->len < y->len ? -1 : 1;
}

static V heff_strEq(V a, V b) {
  int c = heff_str_cmp(a, b);
  heff_drop(a);
  heff_drop(b);
  return heff_bool(c == 0);
}

static V heff_strLt(V a, V b) {
  int c = heff_str_cmp(a, b);
  heff_drop(a);
  heff_drop(b);
  return heff_bool(c < 0);
}

static V heff_strCharCode(V a, V i) {
  Str *x = (Str *)a;
  int64_t k = INT_OF(i);
  V r = k >= 0 && k < x->len ? MK_INT(x->s[k]) : MK_INT(-1);
  heff_drop(a);
  return r;
}

static V heff_strFromCharCode(V c) {
  int64_t k = INT_OF(c);
  if (k < 0 || k > 65535) return (V)heff_str_new(0);
  Str *s = heff_str_new(1);
  s->s[0] = (uint16_t)k;
  return (V)s;
}

static V heff_intShow(V a) {
  char *c = heff_int_cstr(a);
  heff_drop(a);
  V s = heff_str_ascii(c);
  free(c);
  return s;
}

// Floats
// ---------------------------------------------------------------------

static V heff_flt(double d) {
  Flt *f = heff_obj_alloc(sizeof(Flt));
  f->h.rc = 1; f->h.kind = K_FLT; f->h.tag = 0; f->d = d;
  return (V)f;
}

#define FLT_OF(v) (((Flt *)(v))->d)

// (two floats' operation, both consumed)
#define FLT2(name, expr) \
  static V name(V a, V b) { double x = FLT_OF(a), y = FLT_OF(b); heff_drop(a); heff_drop(b); return expr; }
FLT2(heff_floatAdd, heff_flt(x + y))
FLT2(heff_floatSub, heff_flt(x - y))
FLT2(heff_floatMul, heff_flt(x * y))
FLT2(heff_floatDiv, heff_flt(x / y))
FLT2(heff_floatEq, heff_bool(x == y))
FLT2(heff_floatLt, heff_bool(x < y))
FLT2(heff_floatLe, heff_bool(x <= y))
static V heff_floatFromInt(V a) { double d = heff_double_of_int(a); heff_drop(a); return heff_flt(d); }
static V heff_floatSqrt(V a) { double x = FLT_OF(a); heff_drop(a); return heff_flt(sqrt(x)); }

static V heff_floatFloor(V a) {
  double d = FLT_OF(a);
  heff_drop(a);
  if (!isfinite(d)) return heff_abandon();
  double f = floor(d);
  return heff_int_of_double(f);
}

// (as JavaScript writes a number: the fewest digits that read back the
// same, in plain or exponent form by its rules (ECMAScript
// Number::toString); then ".0" where that is a whole number)
static void heff_js_number(double d, char *out) {
  if (isnan(d)) { strcpy(out, "NaN"); return; }
  if (isinf(d)) { strcpy(out, d < 0 ? "-Infinity" : "Infinity"); return; }
  if (d == 0) { strcpy(out, "0"); return; }
  char *o = out;
  if (d < 0) { *o++ = '-'; d = -d; }
  char buf[40];
  int p;
  for (p = 1; p <= 17; p++) {
    snprintf(buf, sizeof buf, "%.*e", p - 1, d);
    if (strtod(buf, NULL) == d) break;
  }
  // digits and exponent: d = 0.digits * 10^n, k digits
  char digits[20];
  int k = 0;
  char *c = buf;
  for (; *c && *c != 'e'; c++) if (*c >= '0' && *c <= '9') digits[k++] = *c;
  while (k > 1 && digits[k - 1] == '0') k--;
  int e = atoi(c + 1);
  int n = e + 1;
  if (k <= n && n <= 21) {
    memcpy(o, digits, k); o += k;
    for (int i = k; i < n; i++) *o++ = '0';
  } else if (0 < n && n <= 21) {
    memcpy(o, digits, n); o += n; *o++ = '.';
    memcpy(o, digits + n, k - n); o += k - n;
  } else if (-6 < n && n <= 0) {
    *o++ = '0'; *o++ = '.';
    for (int i = 0; i < -n; i++) *o++ = '0';
    memcpy(o, digits, k); o += k;
  } else {
    *o++ = digits[0];
    if (k > 1) { *o++ = '.'; memcpy(o, digits + 1, k - 1); o += k - 1; }
    o += sprintf(o, "e%c%d", n - 1 < 0 ? '-' : '+', abs(n - 1));
  }
  *o = 0;
}

static V heff_floatShow(V a) {
  char buf[64];
  heff_js_number(FLT_OF(a), buf);
  heff_drop(a);
  if (!strpbrk(buf, ".eNI")) strcat(buf, ".0");
  return heff_str_ascii(buf);
}

// Arrays
// ---------------------------------------------------------------------

static Arr *heff_arr_new(int64_t n) {
  Arr *r = heff_obj_alloc(sizeof(Arr) + n * sizeof(V));
  r->h.rc = 1; r->h.kind = K_ARR; r->h.tag = 0; r->n = n;
  return r;
}

static V heff_arrayLength(V a) {
  V n = MK_INT(((Arr *)a)->n);
  heff_drop(a);
  return n;
}

static V heff_arrayIndex(V a, V i) {
  Arr *r = (Arr *)a;
  int64_t k = INT_OF(i);
  if (k < 0 || k >= r->n) return heff_abandon();
  V x = heff_dup(r->a[k]);
  heff_drop(a);
  return x;
}

// (an array held only here is set in place: it is not seen again)
static V heff_arraySet(V a, V i, V x) {
  Arr *r = (Arr *)a;
  int64_t k = INT_OF(i);
  if (k < 0 || k >= r->n) return heff_abandon();
  if (heff_unique(a)) {
    heff_drop(r->a[k]);
    r->a[k] = x;
    return a;
  }
  Arr *s = heff_arr_new(r->n);
  for (int64_t j = 0; j < r->n; j++) s->a[j] = j == k ? x : heff_dup(r->a[j]);
  heff_drop(a);
  return (V)s;
}

static V heff_arrayGenerate(V n, V f) {
  int64_t m = INT_OF(n) > 0 ? INT_OF(n) : 0;
  Arr *r = heff_arr_new(m);
  for (int64_t k = 0; k < m; k++) r->a[k] = heff_tr(heff_app1(heff_dup(f), MK_INT(k)));
  heff_drop(f);
  return (V)r;
}

static V heff_arrayFromList(V l) {
  int64_t n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  Arr *r = heff_arr_new(n);
  int64_t k = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) r->a[k++] = heff_dup(heff_field(c, 0));
  heff_drop(l);
  return (V)r;
}

static V heff_arrayToList(V a) {
  Arr *r = (Arr *)a;
  V l = NTAG(TAG_Nil);
  for (int64_t k = r->n - 1; k >= 0; k--) {
    V f[2] = { heff_dup(r->a[k]), l };
    l = heff_tag(TAG_Cons, 2, f);
  }
  heff_drop(a);
  return l;
}

// What providers share
// ---------------------------------------------------------------------

// (a string as a C string, UTF-8, to give the system: malloc'd)
static char *heff_cstr(V v) {
  Str *s = (Str *)v;
  char *c = heff_alloc(s->len * 3 + 1), *o = c;
  for (int64_t i = 0; i < s->len; i++) {
    uint32_t u = s->s[i];
    if (u >= 0xD800 && u < 0xDC00 && i + 1 < s->len && s->s[i + 1] >= 0xDC00 && s->s[i + 1] < 0xE000) {
      u = 0x10000 + ((u - 0xD800) << 10) + (s->s[i + 1] - 0xDC00);
      i++;
    }
    if (u < 0x80) *o++ = (char)u;
    else if (u < 0x800) { *o++ = (char)(0xC0 | (u >> 6)); *o++ = (char)(0x80 | (u & 0x3F)); }
    else if (u < 0x10000) { *o++ = (char)(0xE0 | (u >> 12)); *o++ = (char)(0x80 | ((u >> 6) & 0x3F)); *o++ = (char)(0x80 | (u & 0x3F)); }
    else { *o++ = (char)(0xF0 | (u >> 18)); *o++ = (char)(0x80 | ((u >> 12) & 0x3F)); *o++ = (char)(0x80 | ((u >> 6) & 0x3F)); *o++ = (char)(0x80 | (u & 0x3F)); }
  }
  *o = 0;
  return c;
}

// (a C string, UTF-8, as a string)
static V heff_str_c(const char *c) { return heff_str_utf8((const unsigned char *)c, (int64_t)strlen(c)); }

static V heff_just(V x) { return heff_tag(TAG_Just, 1, &x); }
#define heff_nothing NTAG(TAG_Nothing)

static V heff_cons(V x, V rest) {
  V f[2] = { x, rest };
  return heff_tag(TAG_Cons, 2, f);
}

// (C strings, as a list of strings)
static V heff_strs(char **xs, int64_t n) {
  V l = NTAG(TAG_Nil);
  for (int64_t i = n - 1; i >= 0; i--) l = heff_cons(heff_str_c(xs[i]), l);
  return l;
}

// (C strings' order, for qsort)
static int heff_cmp_cstr(const void *a, const void *b) {
  return strcmp(*(char *const *)a, *(char *const *)b);
}

// (a path joined to a name in it, malloc'd)
static char *heff_join(const char *dir, const char *name) {
  size_t a = strlen(dir), b = strlen(name);
  char *p = heff_alloc(a + b + 2);
  memcpy(p, dir, a);
#ifdef _WIN32
  p[a] = '\\';
#else
  p[a] = '/';
#endif
  memcpy(p + a + 1, name, b + 1);
  return p;
}

// (an answer, for an operation's function: given it, its value asked for)
static V heff_answer(V f, V x) { return heff_tr(heff_app1(f, x)); }

// Running
// ---------------------------------------------------------------------

static V heff_nomatch(V s) {
  (void)s;
  heff_fail("no case for a tag");
  return 0;
}

// Values, shown (`heff compile` without `--name`: each definition of
// the file printed as the tests print JavaScript's, test/load-js.mjs)
// ---------------------------------------------------------------------

HEFF_VAR(const char **heff_tag_names);
HEFF_VAR(const char **heff_lbl_names);

typedef struct { char *s; size_t n, cap; } Buf;

static void buf_put(Buf *b, const char *c, size_t n) {
  if (b->n + n + 1 > b->cap) {
    size_t cap = (b->cap ? b->cap * 2 : 256);
    while (cap < b->n + n + 1) cap *= 2;
    char *s = heff_alloc(cap);
    if (b->n) memcpy(s, b->s, b->n);
    free(b->s);
    b->s = s; b->cap = cap;
  }
  memcpy(b->s + b->n, c, n);
  b->n += n;
  b->s[b->n] = 0;
}

static void buf_str(Buf *b, const char *c) { buf_put(b, c, strlen(c)); }

// Commands
// ---------------------------------------------------------------------

#ifdef _WIN32
// (a command line of `as`, each quoted as the C runtime's parser reads it
// back: malloc'd)
static char *heff_command_line(char **as) {
  Buf b = {0};
  for (char **a = as; *a; a++) {
    if (a != as) buf_put(&b, " ", 1);
    const char *s = *a;
    if (*s && !strpbrk(s, " \t\n\v\"")) { buf_str(&b, s); continue; }
    buf_put(&b, "\"", 1);
    for (;;) {
      size_t slashes = 0;
      while (*s == '\\') { s++; slashes++; }
      if (!*s) {
        for (size_t i = 0; i < slashes * 2; i++) buf_put(&b, "\\", 1);
        break;
      }
      size_t k = *s == '"' ? slashes * 2 + 1 : slashes;
      for (size_t i = 0; i < k; i++) buf_put(&b, "\\", 1);
      buf_put(&b, s++, 1);
    }
    buf_put(&b, "\"", 1);
  }
  buf_put(&b, "", 1);
  return b.s;
}

typedef struct { HANDLE h; Buf *b; } HeffDrain;

// (all a pipe gives, until it is closed)
static DWORD WINAPI heff_drain(LPVOID u) {
  HeffDrain *d = u;
  char chunk[65536];
  DWORD got;
  while (ReadFile(d->h, chunk, sizeof chunk, &got, NULL) && got > 0) buf_put(d->b, chunk, got);
  return 0;
}

// (a command started, its stdin this program's, its stdout and stderr
// `out` and `err`, or 0 if it cannot be)
static HANDLE heff_spawn(char **as, HANDLE out, HANDLE err) {
  char *line = heff_command_line(as);
  STARTUPINFOA si;
  memset(&si, 0, sizeof si);
  si.cb = sizeof si;
  si.dwFlags = STARTF_USESTDHANDLES;
  si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  si.hStdOutput = out;
  si.hStdError = err;
  PROCESS_INFORMATION pi;
  int ok = CreateProcessA(NULL, line, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);
  free(line);
  if (!ok) return 0;
  CloseHandle(pi.hThread);
  return pi.hProcess;
}

// (a command's exit code once it has ended)
static int64_t heff_wait(HANDLE h) {
  DWORD code = (DWORD)-1;
  WaitForSingleObject(h, INFINITE);
  GetExitCodeProcess(h, &code);
  CloseHandle(h);
  return (int64_t)code;
}
#else
// (what a command writes, both streams read together, so that neither
// fills its pipe while the other is waited for)
static void heff_read_both(int out, int err, Buf *bo, Buf *be) {
  struct pollfd fds[2] = { { out, POLLIN, 0 }, { err, POLLIN, 0 } };
  int open = 2;
  char chunk[65536];
  while (open > 0) {
    if (poll(fds, 2, -1) < 0) break;
    for (int i = 0; i < 2; i++) {
      if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP))) continue;
      ssize_t got = read(fds[i].fd, chunk, sizeof chunk);
      if (got <= 0) { close(fds[i].fd); fds[i].fd = -1; open--; }
      else buf_put(i == 0 ? bo : be, chunk, (size_t)got);
    }
  }
}

#endif

// (the command `as` (a NULL-ended array, its name first, found on the
// PATH) run, its stdin this program's, what it writes to stdout and
// stderr gathered in `bo` and `be`: its exit status, -1 if it could not
// be run)
static int64_t heff_capture(char **as, Buf *bo, Buf *be) {
  int64_t status = -1;
#ifdef _WIN32
  SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
  HANDLE or_, ow, er, ew;
  if (CreatePipe(&or_, &ow, &sa, 0) && CreatePipe(&er, &ew, &sa, 0)) {
    SetHandleInformation(or_, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(er, HANDLE_FLAG_INHERIT, 0);
    HANDLE h = heff_spawn(as, ow, ew);
    CloseHandle(ow);
    CloseHandle(ew);
    HeffDrain de = { er, be }, dout = { or_, bo };
    HANDLE t = CreateThread(NULL, 0, heff_drain, &de, 0, NULL);
    heff_drain(&dout);
    if (t) { WaitForSingleObject(t, INFINITE); CloseHandle(t); }
    else heff_drain(&de);
    CloseHandle(or_);
    CloseHandle(er);
    if (h) status = heff_wait(h);
  }
#else
  int po[2], pe[2];
  if (pipe(po) == 0 && pipe(pe) == 0) {
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_adddup2(&fa, po[1], 1);
    posix_spawn_file_actions_adddup2(&fa, pe[1], 2);
    posix_spawn_file_actions_addclose(&fa, po[0]);
    posix_spawn_file_actions_addclose(&fa, pe[0]);
    pid_t pid;
    int ok = posix_spawnp(&pid, as[0], &fa, NULL, as, environ) == 0;
    posix_spawn_file_actions_destroy(&fa);
    close(po[1]);
    close(pe[1]);
    heff_read_both(po[0], pe[0], bo, be);
    if (ok) {
      int st;
      if (waitpid(pid, &st, 0) >= 0 && WIFEXITED(st)) status = WEXITSTATUS(st);
    }
  }
#endif
  return status;
}

// (a string as JSON writes one: in quotes, `"` `\` and controls escaped)
static void buf_json_string(Buf *b, V v) {
  Str *s = (Str *)v;
  buf_str(b, "\"");
  for (int64_t i = 0; i < s->len; i++) {
    uint32_t u = s->s[i];
    char tmp[16];
    if (u == '"') buf_str(b, "\\\"");
    else if (u == '\\') buf_str(b, "\\\\");
    else if (u == '\n') buf_str(b, "\\n");
    else if (u == '\t') buf_str(b, "\\t");
    else if (u == '\r') buf_str(b, "\\r");
    else if (u == '\b') buf_str(b, "\\b");
    else if (u == '\f') buf_str(b, "\\f");
    else if (u < 0x20) { snprintf(tmp, sizeof tmp, "\\u%04x", u); buf_str(b, tmp); }
    else {
      if (u >= 0xD800 && u < 0xDC00 && i + 1 < s->len && s->s[i + 1] >= 0xDC00 && s->s[i + 1] < 0xE000) {
        u = 0x10000 + ((u - 0xD800) << 10) + (s->s[i + 1] - 0xDC00);
        i++;
      }
      char o[4]; int k = 0;
      if (u < 0x80) o[k++] = (char)u;
      else if (u < 0x800) { o[k++] = (char)(0xC0 | (u >> 6)); o[k++] = (char)(0x80 | (u & 0x3F)); }
      else if (u < 0x10000) { o[k++] = (char)(0xE0 | (u >> 12)); o[k++] = (char)(0x80 | ((u >> 6) & 0x3F)); o[k++] = (char)(0x80 | (u & 0x3F)); }
      else { o[k++] = (char)(0xF0 | (u >> 18)); o[k++] = (char)(0x80 | ((u >> 12) & 0x3F)); o[k++] = (char)(0x80 | ((u >> 6) & 0x3F)); o[k++] = (char)(0x80 | (u & 0x3F)); }
      buf_put(b, o, k);
    }
  }
  buf_str(b, "\"");
}

static void heff_show(Buf *b, V v, int arg) {
  char tmp[64];
  if (IS_INT(v) || (IS_OBJ(v) && OBJ(v)->kind == K_BIG)) {
    char *c = heff_int_cstr(v);
    if (arg && c[0] == '-') { buf_str(b, "("); buf_str(b, c); buf_str(b, ")"); }
    else buf_str(b, c);
    free(c);
    return;
  }
  int tag = -1, n = 0;
  V *fs = NULL;
  if (IS_NTAG(v)) tag = (int)(v >> 2);
  else {
    Obj *o = OBJ(v);
    switch (o->kind) {
    case K_TAG: tag = o->tag; n = (int)((Tag *)v)->n; fs = ((Tag *)v)->f; break;
    case K_FLT: {
      heff_js_number(FLT_OF(v), tmp);
      if (!strpbrk(tmp, ".eNI")) strcat(tmp, ".0");
      if (arg && tmp[0] == '-') { buf_str(b, "("); buf_str(b, tmp); buf_str(b, ")"); }
      else buf_str(b, tmp);
      return;
    }
    case K_STR: buf_json_string(b, v); return;
    case K_ARR: {
      Arr *r = (Arr *)v;
      buf_str(b, "[");
      for (int64_t i = 0; i < r->n; i++) { if (i) buf_str(b, ", "); heff_show(b, r->a[i], 0); }
      buf_str(b, "]");
      return;
    }
    case K_REC: {
      Rec *r = (Rec *)v;
      buf_str(b, "{ ");
      for (int64_t i = 0; i < r->n; i++) {
        if (i) buf_str(b, ", ");
        buf_str(b, heff_lbl_names[r->lbl[i]]);
        buf_str(b, " = ");
        heff_show(b, r->f[i], 0);
      }
      buf_str(b, " }");
      return;
    }
    default: buf_str(b, "#fun"); return;
    }
  }
  const char *name = heff_tag_names[tag];
  int upper = name[0] >= 'A' && name[0] <= 'Z';
  if (n && arg) buf_str(b, "(");
  if (!upper) buf_str(b, "'");
  buf_str(b, name);
  for (int i = 0; i < n; i++) { buf_str(b, " "); heff_show(b, fs[i], 1); }
  if (n && arg) buf_str(b, ")");
}

// (a definition by its name, the file's own, `heff_globals`; its value
// asked for, the thing it is shown, or why it failed)
typedef struct { const char *name; V (*get)(void); } Global;

static void heff_check_one(Buf *out, const Global *g) {
  jmp_buf here;
  heff_catch = &here;
  Buf b = {0};
  buf_str(out, "\"");
  buf_str(out, g->name);
  buf_str(out, "\": ");
  if (setjmp(here) == 0) {
    V v = heff_tr(g->get());
    heff_show(&b, v, 0);
    buf_str(out, "{\"value\": ");
    Str *s = (Str *)heff_str_utf8((const unsigned char *)b.s, (int64_t)b.n);
    buf_json_string(out, (V)s);
    buf_str(out, "}");
  } else {
    buf_str(out, "{\"threw\": ");
    buf_json_string(out, heff_str_ascii(heff_caught));
    buf_str(out, "}");
  }
  heff_catch = NULL;
}

HEFF_VAR(int heff_argc);
HEFF_VAR(char **heff_argv);
HEFF_VAR(int heff_status);

#ifndef HEFF_PART

#ifdef HEFF_CHECK
static const Global *heff_globals = NULL;
static int heff_nglobals = 0;

// (the program's: its definitions and the names of its tags and labels)
static void heff_check_init(void);

static void *heff_thread(void *u) {
  (void)u;
  heff_check_init();
  Buf out = {0};
  buf_str(&out, "{");
  int first = 1;
  for (int i = 1; i < heff_argc; i++)
    for (int j = 0; j < heff_nglobals; j++)
      if (strcmp(heff_argv[i], heff_globals[j].name) == 0) {
        if (!first) buf_str(&out, ", ");
        first = 0;
        heff_check_one(&out, &heff_globals[j]);
        break;
      }
  buf_str(&out, "}");
  fputs(out.s, stdout);
  return NULL;
}
#else
static V heff_entry(void);

static void *heff_thread(void *u) {
  (void)u;
  heff_tr(heff_entry());
  return NULL;
}
#endif

#ifdef _WIN32
// (the program's thread on Windows: its large stack reserved, not
// committed, and its bytes in and out as they are, not as text)
static DWORD WINAPI heff_win_thread(LPVOID u) {
  heff_thread(u);
  return 0;
}

int main(int argc, char **argv) {
  heff_argc = argc; heff_argv = argv;
  _setmode(_fileno(stdin), _O_BINARY);
  _setmode(_fileno(stdout), _O_BINARY);
  _setmode(_fileno(stderr), _O_BINARY);
  SetConsoleOutputCP(CP_UTF8);
  HANDLE t = CreateThread(NULL, (SIZE_T)1 << 30, heff_win_thread, NULL, STACK_SIZE_PARAM_IS_A_RESERVATION, NULL);
  if (!t) heff_fail("cannot start");
  WaitForSingleObject(t, INFINITE);
  fflush(stdout);
  return heff_status;
}
#else
int main(int argc, char **argv) {
  heff_argc = argc; heff_argv = argv;
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, (size_t)1 << 30);
  pthread_t t;
  if (pthread_create(&t, &attr, heff_thread, NULL) != 0) heff_fail("cannot start");
  pthread_join(t, NULL);
  fflush(stdout);
  return heff_status;
}
#endif
#endif

V heff_perform(V p, V k);
static uint32_t shape_305_78[] = {305, 78};
static uint32_t shape_160_192[] = {160, 192};
static uint32_t shape_146_32_353[] = {146, 32, 353};
static uint32_t shape_213_80_4_29[] = {213, 80, 4, 29};
static uint32_t shape_160_192_171_50[] = {160, 192, 171, 50};
static uint32_t shape_133_255_236_182_193_239_331_283[] = {133, 255, 236, 182, 193, 239, 331, 283};
static uint32_t shape_119_121[] = {119, 121};
static uint32_t shape_113_0[] = {113, 0};
static uint32_t shape_190_3_299[] = {190, 3, 299};
static uint32_t shape_130_321[] = {130, 321};
static uint32_t shape_170_109[] = {170, 109};
static uint32_t shape_117_12[] = {117, 12};
static uint32_t shape_72_51[] = {72, 51};
static uint32_t shape_192_120[] = {192, 120};
static uint32_t shape_189_137[] = {189, 137};
static uint32_t shape_192_23_25[] = {192, 23, 25};
static uint32_t shape_192_266_50[] = {192, 266, 50};
static uint32_t shape_192_214[] = {192, 214};
static uint32_t shape_127_131[] = {127, 131};
static uint32_t shape_222_192_53_154[] = {222, 192, 53, 154};
static uint32_t shape_75_336[] = {75, 336};
static uint32_t shape_167_45[] = {167, 45};
static uint32_t shape_78_140[] = {78, 140};
static uint32_t shape_123_321_41[] = {123, 321, 41};
static uint32_t shape_123_167_168_96_41[] = {123, 167, 168, 96, 41};
static uint32_t shape_147_321_305_78_167_45_96[] = {147, 321, 305, 78, 167, 45, 96};
static uint32_t shape_123_167_168_96_325_83_42[] = {123, 167, 168, 96, 325, 83, 42};
static uint32_t shape_305_78_185[] = {305, 78, 185};
static uint32_t shape_305_78_321[] = {305, 78, 321};
static uint32_t shape_326_84_46[] = {326, 84, 46};
static uint32_t shape_147_321_254_305_78_45_96_142_24[] = {147, 321, 254, 305, 78, 45, 96, 142, 24};
static uint32_t shape_142_167[] = {142, 167};
static uint32_t shape_243_189_327_232_135_158_136_332_155_144[] = {243, 189, 327, 232, 135, 158, 136, 332, 155, 144};
static uint32_t shape_321_24[] = {321, 24};
static uint32_t shape_305_78_325_321_306_79[] = {305, 78, 325, 321, 306, 79};
static uint32_t shape_167_202_214[] = {167, 202, 214};
static uint32_t shape_302_158_136_332_195_196_97[] = {302, 158, 136, 332, 195, 196, 97};
static uint32_t shape_327_82[] = {327, 82};
static uint32_t shape_267_20_177[] = {267, 20, 177};
static uint32_t shape_327_123_329_304_305[] = {327, 123, 329, 304, 305};
static uint32_t shape_44_284_185_299_197[] = {44, 284, 185, 299, 197};
static uint32_t shape_89_206_347_8_16_231_226_225_152_35_125_62_162[] = {89, 206, 347, 8, 16, 231, 226, 225, 152, 35, 125, 62, 162};
static uint32_t shape_327_277_149_23_227_97_161[] = {327, 277, 149, 23, 227, 97, 161};
static uint32_t shape_21_299[] = {21, 299};
static uint32_t shape_209_214[] = {209, 214};
static uint32_t shape_205_72[] = {205, 72};
static uint32_t shape_190_299[] = {190, 299};
static uint32_t shape_90_192_129[] = {90, 192, 129};
static uint32_t shape_190_299_336[] = {190, 299, 336};
static uint32_t shape_72_224_51[] = {72, 224, 51};
static uint32_t shape_0_19_84[] = {0, 19, 84};
static uint32_t shape_14_209_0_19_84_299[] = {14, 209, 0, 19, 84, 299};
static uint32_t shape_322_173[] = {322, 173};
static uint32_t shape_98_58[] = {98, 58};
static uint32_t shape_124_14_209[] = {124, 14, 209};
static uint32_t shape_141_58_29[] = {141, 58, 29};
static uint32_t shape_52_58_98_29[] = {52, 58, 98, 29};
static uint32_t shape_299_185[] = {299, 185};
static uint32_t shape_132_40_338_51[] = {132, 40, 338, 51};
static uint32_t shape_361_350_132_40_338[] = {361, 350, 132, 40, 338};
static uint32_t shape_230_268[] = {230, 268};
static uint32_t shape_315_13_230_299[] = {315, 13, 230, 299};
static uint32_t shape_278_333[] = {278, 333};
static uint32_t shape_311_351[] = {311, 351};
static uint32_t shape_179_187_186[] = {179, 187, 186};
static uint32_t shape_65_43_256[] = {65, 43, 256};
static uint32_t shape_336_293_294_13_190_299[] = {336, 293, 294, 13, 190, 299};
static uint32_t shape_299_147_321[] = {299, 147, 321};
static uint32_t shape_286_159_271_91[] = {286, 159, 271, 91};
static uint32_t shape_349_342_341_295_256_257_260_258_259[] = {349, 342, 341, 295, 256, 257, 260, 258, 259};
static uint32_t shape_13_143[] = {13, 143};
static uint32_t shape_190_336_350[] = {190, 336, 350};
static uint32_t shape_277_110_76_153_282_138[] = {277, 110, 76, 153, 282, 138};
static uint32_t shape_190_336_311_351[] = {190, 336, 311, 351};
static uint32_t shape_299_190_145_180_336[] = {299, 190, 145, 180, 336};
static uint32_t shape_190_338[] = {190, 338};
static uint32_t shape_190_40_299_191[] = {190, 40, 299, 191};
static uint32_t shape_299_190_338_128[] = {299, 190, 338, 128};
static uint32_t shape_190_336_323_244[] = {190, 336, 323, 244};
static uint32_t shape_314_337_352_340[] = {314, 337, 352, 340};
static uint32_t shape_190_145_244_81_91[] = {190, 145, 244, 81, 91};
static uint32_t shape_110_58_146_29_359_319_300_133_331[] = {110, 58, 146, 29, 359, 319, 300, 133, 331};
static uint32_t shape_299_81[] = {299, 81};
static uint32_t shape_190_145_184[] = {190, 145, 184};
static uint32_t shape_190_145[] = {190, 145};
static uint32_t shape_184_3[] = {184, 3};
static uint32_t shape_336_75[] = {336, 75};
static uint32_t shape_190_145_336_165[] = {190, 145, 336, 165};
static uint32_t shape_184_228_296_52_329_58_216_56_208_4_98_34[] = {184, 228, 296, 52, 329, 58, 216, 56, 208, 4, 98, 34};
static uint32_t shape_149_98_161[] = {149, 98, 161};
static uint32_t shape_169_309[] = {169, 309};
static uint32_t shape_87_102_324[] = {87, 102, 324};
static uint32_t shape_102_324_89_336_352_87_122_85_86[] = {102, 324, 89, 336, 352, 87, 122, 85, 86};
static uint32_t shape_190_352[] = {190, 352};
static uint32_t shape_190_203_249_274_61_290_151_198_92_279[] = {190, 203, 249, 274, 61, 290, 151, 198, 92, 279};
static uint32_t shape_214_188_96[] = {214, 188, 96};
static uint32_t shape_190_145_74[] = {190, 145, 74};
static uint32_t shape_145_74[] = {145, 74};
static uint32_t shape_175_189_362[] = {175, 189, 362};
static uint32_t shape_313_104_55_275_330_235_298[] = {313, 104, 55, 275, 330, 235, 298};
static uint32_t shape_5_148_301_176_49_360_335[] = {5, 148, 301, 176, 49, 360, 335};
static uint32_t shape_275_330[] = {275, 330};
static uint32_t shape_49_343[] = {49, 343};
static uint32_t shape_145_190_25[] = {145, 190, 25};
static uint32_t shape_292_10_247_178[] = {292, 10, 247, 178};
static uint32_t shape_55_313[] = {55, 313};
static uint32_t shape_111[] = {111};
static uint32_t shape_139_336[] = {139, 336};
static uint32_t shape_171_82_160_110[] = {171, 82, 160, 110};
static uint32_t shape_33_354[] = {33, 354};
static uint32_t shape_356_214[] = {356, 214};
static uint32_t shape_55_84_313[] = {55, 84, 313};
static uint32_t shape_214_189[] = {214, 189};
static uint32_t shape_55_84[] = {55, 84};
static uint32_t shape_114_192_346_282[] = {114, 192, 346, 282};
static uint32_t shape_143_82[] = {143, 82};
static uint32_t shape_44_241[] = {44, 241};
static uint32_t shape_143_240_82[] = {143, 240, 82};
static uint32_t shape_143_82_240[] = {143, 82, 240};
static uint32_t shape_145_222_334_276[] = {145, 222, 334, 276};
static uint32_t shape_222_25[] = {222, 25};
static uint32_t shape_143_13_156_28[] = {143, 13, 156, 28};
static uint32_t shape_169_110[] = {169, 110};
static uint32_t shape_296_84[] = {296, 84};
static uint32_t shape_218_194_153_250_199_310_287_245[] = {218, 194, 153, 250, 199, 310, 287, 245};
static uint32_t shape_11_240_238[] = {11, 240, 238};
static uint32_t shape_316_157_105_28_282_217_2_27_26[] = {316, 157, 105, 28, 282, 217, 2, 27, 26};
static uint32_t shape_145_222[] = {145, 222};
static uint32_t shape_250_44[] = {250, 44};
static uint32_t shape_242_78[] = {242, 78};
static uint32_t shape_219_270_163_164_126_77_9_36_22_207_212_210_211_6_308_269[] = {219, 270, 163, 164, 126, 77, 9, 36, 22, 207, 212, 210, 211, 6, 308, 269};
static uint32_t shape_130_52_58[] = {130, 52, 58};
static uint32_t shape_15_185[] = {15, 185};
static uint32_t shape_190_228_355[] = {190, 228, 355};
static uint32_t shape_190_60[] = {190, 60};
static uint32_t shape_184_118_264_263[] = {184, 118, 264, 263};
static uint32_t shape_17_273[] = {17, 273};
static uint32_t shape_228_355_115[] = {228, 355, 115};
static uint32_t shape_68_1_280[] = {68, 1, 280};
static uint32_t shape_228_60_302_216_329_118_277[] = {228, 60, 302, 216, 329, 118, 277};
static uint32_t shape_228_18_223_184[] = {228, 18, 223, 184};
static uint32_t shape_66_67_84[] = {66, 67, 84};
static uint32_t shape_297_84_229_220_221[] = {297, 84, 229, 220, 221};
static uint32_t shape_23_348[] = {23, 348};
static uint32_t shape_190_299_93[] = {190, 299, 93};
static uint32_t shape_21_345[] = {21, 345};
static uint32_t shape_190_21_348[] = {190, 21, 348};
static uint32_t shape_190_93_345[] = {190, 93, 345};
static uint32_t shape_150_57[] = {150, 57};
static uint32_t shape_145_180_170[] = {145, 180, 170};
static uint32_t shape_318_190_299[] = {318, 190, 299};
static uint32_t shape_33_190_299[] = {33, 190, 299};
static uint32_t shape_228_296_299[] = {228, 296, 299};
static uint32_t shape_318_190[] = {318, 190};
static uint32_t shape_171_94[] = {171, 94};
static uint32_t shape_321_299[] = {321, 299};
static uint32_t shape_228_296_299_54[] = {228, 296, 299, 54};
static uint32_t shape_190_147_299_281_39[] = {190, 147, 299, 281, 39};
static uint32_t shape_190_147_299[] = {190, 147, 299};
static uint32_t shape_361_73[] = {361, 73};
static uint32_t shape_87_112_59[] = {87, 112, 59};
static uint32_t shape_190_145_299_336_25[] = {190, 145, 299, 336, 25};
static uint32_t shape_98_55_116[] = {98, 55, 116};
static uint32_t shape_66_116[] = {66, 116};
static uint32_t shape_303_201_318[] = {303, 201, 318};
static uint32_t shape_228_318_190_200[] = {228, 318, 190, 200};
static uint32_t shape_344_321[] = {344, 321};
static uint32_t shape_64_38_69_247_358_291_166[] = {64, 38, 69, 247, 358, 291, 166};
static uint32_t shape_100_237[] = {100, 237};
static uint32_t shape_286_317[] = {286, 317};
static uint32_t shape_107_7_99_237[] = {107, 7, 99, 237};
static uint32_t shape_285_253_204_251_103[] = {285, 253, 204, 251, 103};
static uint32_t shape_237_100[] = {237, 100};
static uint32_t shape_204_357_49_108[] = {204, 357, 49, 108};
static uint32_t shape_181_13_48[] = {181, 13, 48};
static uint32_t shape_190_63_289_12[] = {190, 63, 289, 12};
static uint32_t shape_172_288_181_63_353_262_265_48[] = {172, 288, 181, 63, 353, 262, 265, 48};
static uint32_t shape_228_355_233[] = {228, 355, 233};
static uint32_t shape_31_228_355[] = {31, 228, 355};
static uint32_t shape_228_296_234_184[] = {228, 296, 234, 184};
static uint32_t shape_166_183_312[] = {166, 183, 312};
static uint32_t shape_272_302_166_183_312[] = {272, 302, 166, 183, 312};
static uint32_t shape_184_228_296_261[] = {184, 228, 296, 261};
static uint32_t shape_184_321[] = {184, 321};
static uint32_t shape_330_91_203_319_320[] = {330, 91, 203, 319, 320};
static uint32_t shape_218_358[] = {218, 358};
static uint32_t shape_95_215_190_17[] = {95, 215, 190, 17};
static uint32_t shape_37_273_319_248_47_88_339_101[] = {37, 273, 319, 248, 47, 88, 339, 101};
static uint32_t shape_321_246[] = {321, 246};
static uint32_t shape_303_321_246[] = {303, 321, 246};
static uint32_t shape_272_246[] = {272, 246};
static uint32_t shape_303_246[] = {303, 246};
static uint32_t shape_228_200[] = {228, 200};
static uint32_t shape_174_70_71[] = {174, 70, 71};
static uint32_t shape_134_106_30_252[] = {134, 106, 30, 252};
static uint32_t shape_30_247_328[] = {30, 247, 328};
static V prim_intShow_entry(V self, V *a) { (void)self; return heff_intShow(a[0]); }
static Clo prim_intShow_clo = {{0x80000000u, K_CLO, 0}, prim_intShow_entry, 1, 0};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
static V prim_strLt_entry(V self, V *a) { (void)self; return heff_strLt(a[0], a[1]); }
static Clo prim_strLt_clo = {{0x80000000u, K_CLO, 0}, prim_strLt_entry, 2, 0};
V g_intShow_get(void);
V g_prelude_2eshowInt_get(void);
V g_strEq_get(void);
V g_strLt_get(void);
V g_prelude_2emap(V v_f_240, V v_x2_241);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2efoldl(V v_f_240, V v_z_241, V v_x3_242);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s0(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s0_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s0_clo;
V g_prelude_2efilter(V v_p_240, V v_x2_241);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efoldl_24s1(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s1_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1_clo;
V g_prelude_2econcatList(V v_x1_240, V v_ys_241);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2etake(V v_n_240, V v_x2_241);
V g_prelude_2etake_entry(V self, V *a);
extern Clo g_prelude_2etake_clo;
V g_prelude_2edrop(V v_n_240, V v_x2_241);
V g_prelude_2edrop_entry(V self, V *a);
extern Clo g_prelude_2edrop_clo;
V g_prelude_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242);
V g_prelude_2ezipWith_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_clo;
V g_prelude_2eany(V v_p_240, V v_x2_241);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2eall(V v_p_240, V v_x2_241);
V g_prelude_2eall_entry(V self, V *a);
extern Clo g_prelude_2eall_clo;
V g_prelude_2efind(V v_p_240, V v_x2_241);
V g_prelude_2efind_entry(V self, V *a);
extern Clo g_prelude_2efind_clo;
V g_prelude_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242);
V g_prelude_2elookupBy_entry(V self, V *a);
extern Clo g_prelude_2elookupBy_clo;
V g_prelude_2efoldl_24s2(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s2_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2_clo;
V g_prelude_2erange(V v_a_240, V v_b_241);
V g_prelude_2erange_entry(V self, V *a);
extern Clo g_prelude_2erange_clo;
V g_prelude_2ereplicate(V v_n_240, V v_x_241);
V g_prelude_2ereplicate_entry(V self, V *a);
extern Clo g_prelude_2ereplicate_clo;
V g_prelude_2emerge(V v_le_240, V v_xs_241, V v_ys_242);
V g_prelude_2emerge_entry(V self, V *a);
extern Clo g_prelude_2emerge_clo;
V g_prelude_2esortBy(V v_le_240, V v_xs_241);
V g_prelude_2esortBy_entry(V self, V *a);
extern Clo g_prelude_2esortBy_clo;
V g_prelude_2eindexFrom(V v_needle_240, V v_s_241, V v_i_242);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_acc_243);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2efoldl_24s3(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s3_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s3_clo;
V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2efoldl_24s4(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s4_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s4_clo;
V g_prelude_2eskipSpaces(V v_s_240, V v_i_241, V v_step_242);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2edigitsFrom(V v_s_240, V v_i_241, V v_n_242);
V g_prelude_2edigitsFrom_entry(V self, V *a);
extern Clo g_prelude_2edigitsFrom_clo;
V g_prelude_2eparseInt(V v_s_240);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_array_2eempty_get(void);
V g_array_2efoldlFrom(V v_f_240, V v_i_241, V v_acc_242, V v_xs_243);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_map_2eempty_get(void);
V g_map_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243);
V g_map_2ebalance_entry(V self, V *a);
extern Clo g_map_2ebalance_clo;
V g_map_2efindMin(V v_x1_240);
V g_map_2efindMin_entry(V self, V *a);
extern Clo g_map_2efindMin_clo;
V g_map_2edeleteMin(V v_x1_240);
V g_map_2edeleteMin_entry(V self, V *a);
extern Clo g_map_2edeleteMin_clo;
V g_map_2etoListOnto(V v_x1_240, V v_acc_241);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2emap_24s5(V v_x2_240);
V g_prelude_2emap_24s5_entry(V self, V *a);
extern Clo g_prelude_2emap_24s5_clo;
V g_prelude_2emap_24s6(V v_x2_240);
V g_prelude_2emap_24s6_entry(V self, V *a);
extern Clo g_prelude_2emap_24s6_clo;
V g_map_2esize(V v_x1_240);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2einsert_24s7(V v_k_240, V v_v_241, V v_x4_242);
V g_map_2einsert_24s7_entry(V self, V *a);
extern Clo g_map_2einsert_24s7_clo;
V g_heff_2edict_2eindexed(V v_i_240, V v_x2_241);
V g_heff_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2edict_2eindexed_clo;
V g_heff_2edict_2ezipKV(V v_x1_240, V v_x2_241);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_map_2elookup_24s8(V v_k_240, V v_x3_241);
V g_map_2elookup_24s8_entry(V self, V *a);
extern Clo g_map_2elookup_24s8_clo;
V g_map_2elookup_24s9(V v_k_240, V v_x3_241);
V g_map_2elookup_24s9_entry(V self, V *a);
extern Clo g_map_2elookup_24s9_clo;
V g_heff_2eparams_2eeqLevel(V v_a_240, V v_b_241);
V g_heff_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eparams_2eeqLevel_clo;
V g_heff_2eparams_2enoSpan_get(void);
V g_heff_2eparams_2eemptyShape_get(void);
V g_heff_2evalue_2elocalsAt(V v_x1_240, V v_i_241);
V g_heff_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2evalue_2elocalsAt_clo;
V g_heff_2evalue_2ebehavior(V v_x1_240);
V g_heff_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2evalue_2ebehavior_clo;
V g_heff_2evalue_2elevelOf(V v_x1_240);
V g_heff_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2evalue_2elevelOf_clo;
V g_heff_2evalue_2ecoerceToFieldsMaybe(V v_v_240);
V g_heff_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2evalue_2eproj(V v_v_240, V v_x_241);
V g_heff_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2evalue_2eproj_clo;
V g_heff_2evalue_2egoER_24s11(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245);
V g_heff_2evalue_2egoER_24s11_entry(V self, V *a);
extern Clo g_heff_2evalue_2egoER_24s11_clo;
V g_heff_2evalue_2emkNeu_24s10(V v_h_240, V v_spine_241, V v_ty_242, V v_desc_243);
V g_heff_2evalue_2emkNeu_24s10_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s10_clo;
V g_heff_2evalue_2ereflect(V v_h_240, V v_spineTh_241, V v_ty_242, V v_edesc_243);
V g_heff_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2evalue_2ereflect_clo;
V g_heff_2evalue_2eprojAt(V v_v_240, V v_x_241, V v_a_242);
V g_heff_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2evalue_2eprojAt_clo;
V g_heff_2evalue_2edecodeNeu(V v_h_240, V v_sp_241, V v_ty_242, V v_expansion_243, V v_desc_244, V v_u_245, V v_decoded_246);
V g_heff_2evalue_2edecodeNeu_entry(V self, V *a);
extern Clo g_heff_2evalue_2edecodeNeu_clo;
V g_heff_2evalue_2edecodeN(V v_x1_240);
V g_heff_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2evalue_2edecodeN_clo;
V g_heff_2evalue_2eneuAppTy(V v_h_240, V v_t_241, V v_arg_242);
V g_heff_2evalue_2eneuAppTy_entry(V self, V *a);
extern Clo g_heff_2evalue_2eneuAppTy_clo;
V g_heff_2evalue_2eapp(V v_f_240, V v_arg_241);
V g_heff_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2evalue_2eapp_clo;
V g_heff_2evalue_2eaddSpecialization(V v_level_240, V v_capture_241, V v_fieldTypes_242, V v_x_243, V v_v_244);
V g_heff_2evalue_2eaddSpecialization_entry(V self, V *a);
extern Clo g_heff_2evalue_2eaddSpecialization_clo;
V g_heff_2evalue_2especialize(V v_v_240, V v_x_241, V v_f_242);
V g_heff_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2evalue_2especialize_clo;
V g_heff_2evalue_2ereplay(V v_v_240, V v_x2_241);
V g_heff_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2evalue_2ereplay_clo;
V g_map_2elookup_24s12(V v_k_240, V v_x3_241);
V g_map_2elookup_24s12_entry(V self, V *a);
extern Clo g_map_2elookup_24s12_clo;
V g_heff_2evalue_2eforceEl(V v_mc_240, V v_v_241);
V g_heff_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2evalue_2eforceEl_clo;
V g_heff_2evalue_2eforceTy(V v_mc_240, V v_t_241);
V g_heff_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2evalue_2eforceTy_clo;
V g_heff_2evalue_2etypeForProjection(V v_capture_240, V v_fieldTypes_241, V v_x_242, V v_fields_243);
V g_heff_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2evalue_2etypeForProjection_clo;
V g_heff_2evalue_2eprojTyWith(V v_t_240, V v_mf_241, V v_x_242);
V g_heff_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2evalue_2eprojTyWith_clo;
V g_heff_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eglobals_2eaddEntry(V v_x_240, V v_e_241, V v_g_242);
V g_heff_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eglobals_2eaddEntry_clo;
V g_heff_2eglobals_2elookupKey(V v_g_240, V v_x_241);
V g_heff_2eglobals_2elookupKey_entry(V self, V *a);
extern Clo g_heff_2eglobals_2elookupKey_clo;
V g_heff_2eglobals_2elookupEntry(V v_g_240, V v_x_241);
V g_heff_2eglobals_2elookupEntry_entry(V self, V *a);
extern Clo g_heff_2eglobals_2elookupEntry_clo;
V g_heff_2eeffect_2eappendE(V v_x1_240, V v_ys_241);
V g_heff_2eeffect_2eappendE_entry(V self, V *a);
extern Clo g_heff_2eeffect_2eappendE_clo;
V g_heff_2eeffect_2eleaves(V v_x1_240);
V g_heff_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eeffect_2eleaves_clo;
V g_heff_2eeffect_2edropLastD(V v_x1_240);
V g_heff_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eeffect_2edropLastD_clo;
V g_heff_2eeffect_2elastOr(V v_d_240, V v_x2_241);
V g_heff_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eeffect_2elastOr_clo;
V g_prelude_2efoldl_24s13(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s13_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s13_clo;
V g_heff_2eeffect_2eeffectOf(V v_g_240, V v_e_241);
V g_heff_2eeffect_2eeffectOf_entry(V self, V *a);
extern Clo g_heff_2eeffect_2eeffectOf_clo;
V g_heff_2eeffect_2ecomputationEffect(V v_g_240, V v_t_241);
V g_heff_2eeffect_2ecomputationEffect_entry(V self, V *a);
extern Clo g_heff_2eeffect_2ecomputationEffect_clo;
V g_heff_2eeval_2eevalTypeF_24s15(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243);
V g_heff_2eeval_2eevalTypeF_24s15_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_24s15_clo;
V g_heff_2eeval_2eevalTermF_24s14(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243);
V g_heff_2eeval_2eevalTermF_24s14_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTermF_24s14_clo;
V g_heff_2eenvironment_2eemptyScope_get(void);
V g_heff_2eenvironment_2ebindName(V v_x_240, V v_a_241, V v_c_242);
V g_heff_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2ebindName_clo;
V g_heff_2eenvironment_2emultiBind(V v_x1_240, V v_x2_241, V v_s_242);
V g_heff_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2emultiBind_clo;
V g_heff_2eenvironment_2ewithBound(V v_x_240, V v_a_241, V v_c_242, V v_action_243);
V g_heff_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2ewithBound_clo;
V g_heff_2eenvironment_2eemptyCore_get(void);
V g_heff_2eenvironment_2eemptySt_get(void);
V g_co_2eplus_24s16_get(void);
V g_heff_2eenvironment_2emodify(V v_f_240, V v_hd_241, V v_k_242);
V g_heff_2eenvironment_2emodify_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2emodify_clo;
V g_heff_2eenvironment_2etryE(V v_m_240, V v_hd_241, V v_k2_242);
V g_heff_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2etryE_clo;
V g_heff_2efixity_2eemptyFixities_get(void);
V g_heff_2efixity_2enubByG(V v_x1_240);
V g_heff_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByG_clo;
V g_heff_2efixity_2enubByE(V v_x1_240);
V g_heff_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByE_clo;
V g_heff_2efixity_2eappendF(V v_x1_240, V v_ys_241);
V g_heff_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2efixity_2eappendF_clo;
V g_heff_2efixity_2efindG(V v_p_240, V v_x2_241);
V g_heff_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2efixity_2efindG_clo;
V g_prelude_2emap_24s19(V v_x2_240);
V g_prelude_2emap_24s19_entry(V self, V *a);
extern Clo g_prelude_2emap_24s19_clo;
V g_heff_2efixity_2etighterGo(V v_f_240, V v_to_241, V v_x3_242, V v_seen_243);
V g_heff_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2efixity_2etighterGo_clo;
V g_heff_2efixity_2erelate(V v_f_240, V v_op_241, V v_op_27_242);
V g_heff_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2efixity_2erelate_clo;
V g_heff_2efixity_2ereserved_get(void);
V g_heff_2eimport_2enameChar(V v_c_240);
V g_heff_2eimport_2enameChar_entry(V self, V *a);
extern Clo g_heff_2eimport_2enameChar_clo;
V g_heff_2eimport_2eallChars_24s20(V v_s_240, V v_i_241);
V g_heff_2eimport_2eallChars_24s20_entry(V self, V *a);
extern Clo g_heff_2eimport_2eallChars_24s20_clo;
V g_heff_2eimport_2ehasDot(V v_x_240, V v_i_241);
V g_heff_2eimport_2ehasDot_entry(V self, V *a);
extern Clo g_heff_2eimport_2ehasDot_clo;
V g_heff_2eimport_2eisAlias(V v_x_240);
V g_heff_2eimport_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2eimport_2eisAlias_clo;
V g_heff_2eimport_2elineEndAt(V v_src_240, V v_i_241);
V g_heff_2eimport_2elineEndAt_entry(V self, V *a);
extern Clo g_heff_2eimport_2elineEndAt_clo;
V g_heff_2eimport_2etrimEnd(V v_s_240);
V g_heff_2eimport_2etrimEnd_entry(V self, V *a);
extern Clo g_heff_2eimport_2etrimEnd_clo;
V g_heff_2eimport_2etrimStart(V v_s_240);
V g_heff_2eimport_2etrimStart_entry(V self, V *a);
extern Clo g_heff_2eimport_2etrimStart_clo;
V g_heff_2eimport_2ewordsGo(V v_s_240, V v_start_241, V v_i_242, V v_acc_243);
V g_heff_2eimport_2ewordsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2ewordsGo_clo;
V g_heff_2eimport_2espaces(V v_n_240);
V g_heff_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2eimport_2espaces_clo;
V g_heff_2eimport_2eimportOf(V v_i_240, V v_e_241, V v_x3_242);
V g_heff_2eimport_2eimportOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportOf_clo;
V g_prelude_2efoldl_24s21(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s21_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s21_clo;
V g_heff_2eimport_2eimportsGo(V v_src_240, V v_i_241, V v_acc_242);
V g_heff_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsGo_clo;
V g_heff_2eimport_2ebuiltinModule_get(void);
V g_prelude_2eany_24s22(V v_x2_240);
V g_prelude_2eany_24s22_entry(V self, V *a);
extern Clo g_prelude_2eany_24s22_clo;
V g_heff_2eimport_2eimportsOf(V v_m_240, V v_src_241);
V g_heff_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsOf_clo;
V g_heff_2eimport_2erenameTo(V v_x1_240, V v_x_241);
V g_heff_2eimport_2erenameTo_entry(V self, V *a);
extern Clo g_heff_2eimport_2erenameTo_clo;
V g_heff_2einterp_2edeepest_get(void);
V g_heff_2einterp_2eprojV(V v_x1_240, V v_x2_241);
V g_heff_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprojV_clo;
V g_heff_2einterp_2esetAt(V v_x1_240, V v_i_241, V v_x_242);
V g_heff_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2esetAt_clo;
V g_heff_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244);
V g_heff_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2egenGo_clo;
V g_heff_2einterp_2efromListV(V v_x1_240, V v_acc_241);
V g_heff_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2efromListV_clo;
V g_heff_2einterp_2etoListV(V v_x1_240);
V g_heff_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2etoListV_clo;
V g_heff_2einterp_2enthV(V v_x1_240, V v_i_241);
V g_heff_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthV_clo;
V g_heff_2einterp_2eint2_24s23_get(void);
V g_heff_2einterp_2eint2_24s24_get(void);
V g_heff_2einterp_2eint2_24s25_get(void);
V g_heff_2einterp_2eint2_24s26_get(void);
V g_heff_2einterp_2eint2_24s27_get(void);
V g_heff_2einterp_2eint2_24s28_get(void);
V g_heff_2einterp_2eint2_24s29_get(void);
V g_heff_2einterp_2eint2_24s30_get(void);
V g_heff_2einterp_2efloat2_24s31_get(void);
V g_heff_2einterp_2efloat2_24s32_get(void);
V g_heff_2einterp_2efloat2_24s33_get(void);
V g_heff_2einterp_2efloat2_24s34_get(void);
V g_heff_2einterp_2efloat2_24s35_get(void);
V g_heff_2einterp_2efloat2_24s36_get(void);
V g_heff_2einterp_2efloat2_24s37_get(void);
V g_heff_2einterp_2estr2_24s38_get(void);
V g_heff_2einterp_2estr2_24s39_get(void);
V g_heff_2einterp_2estr2_24s40_get(void);
V g_heff_2einterp_2eprim(V v_p_240);
V g_heff_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprim_clo;
V g_prelude_2efoldl_24s41(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s41_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s41_clo;
V g_heff_2einterp_2enthTh(V v_x1_240, V v_i_241);
V g_heff_2einterp_2enthTh_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthTh_clo;
V g_heff_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242);
V g_heff_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalEach_clo;
V g_heff_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242);
V g_heff_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalFields_clo;
V g_heff_2einterp_2eevalIn(V v_d_240, V v_e_241, V v_t_242);
V g_heff_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalIn_clo;
V g_heff_2einterp_2eescAt(V v_s_240, V v_i_241);
V g_heff_2einterp_2eescAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2eescAt_clo;
V g_heff_2einterp_2equoteGo(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2einterp_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2equoteGo_clo;
V g_prelude_2emap_24s42(V v_x2_240);
V g_prelude_2emap_24s42_entry(V self, V *a);
extern Clo g_prelude_2emap_24s42_clo;
V g_prelude_2emap_24s43(V v_x2_240);
V g_prelude_2emap_24s43_entry(V self, V *a);
extern Clo g_prelude_2emap_24s43_clo;
V g_prelude_2emap_24s44(V v_x2_240);
V g_prelude_2emap_24s44_entry(V self, V *a);
extern Clo g_prelude_2emap_24s44_clo;
V g_prelude_2efoldl_24s45(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s45_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s45_clo;
V g_prelude_2efoldl_24s46(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s46_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s46_clo;
V g_heff_2einterp_2eshowValGo(V v_inArg_240, V v_v_241);
V g_heff_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eshowValGo_clo;
V g_heff_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242);
V g_heff_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixThunk_clo;
V g_heff_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243);
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_clo;
V g_heff_2epresyntax_2elastOr(V v_z_240, V v_x2_241);
V g_heff_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2elastOr_clo;
V g_heff_2epresyntax_2eapp(V v_f_240, V v_args_241);
V g_heff_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eapp_clo;
V g_heff_2epresyntax_2espineOf(V v_e_240);
V g_heff_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2espineOf_clo;
V g_heff_2epresyntax_2epatSpineOf(V v_p_240);
V g_heff_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epatSpineOf_clo;
V g_heff_2epresyntax_2einfSpineOf(V v_i_240);
V g_heff_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfSpineOf_clo;
V g_heff_2epresyntax_2einfApp(V v_f_240, V v_args_241);
V g_heff_2epresyntax_2einfApp_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfApp_clo;
V g_heff_2epresyntax_2edoStep(V v_sp_240, V v_x2_241, V v_rest_242);
V g_heff_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edoStep_clo;
V g_heff_2epresyntax_2edoFrom(V v_sp_240, V v_x2_241, V v_e_242);
V g_heff_2epresyntax_2edoFrom_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edoFrom_clo;
V g_heff_2epresyntax_2etoInferable(V v_x1_240);
V g_heff_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etoInferable_clo;
V g_heff_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241);
V g_heff_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ewordOf_clo;
V g_heff_2epresyntax_2eargOf(V v_r_240, V v_e_241);
V g_heff_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_clo;
V g_heff_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243);
V g_heff_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eappOf_clo;
V g_heff_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiBinderOf_clo;
V g_heff_2epresyntax_2ealtOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_clo;
V g_heff_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_clo;
V g_heff_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_clo;
V g_heff_2epresyntax_2evariantOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_clo;
V g_heff_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_b_243, V v_sp_244);
V g_heff_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eannLamOf_clo;
V g_heff_2epresyntax_2eclassifyTermF(V v_r_240, V v_e_241);
V g_heff_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_clo;
V g_heff_2epresyntax_2eparamOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_clo;
V g_heff_2epresyntax_2eequationOf(V v_r_240, V v_x2_241);
V g_heff_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_clo;
V g_heff_2epresyntax_2ewatchOf(V v_c_240);
V g_heff_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ewatchOf_clo;
V g_heff_2epresyntax_2eclassifyDeclF(V v_r_240, V v_d_241);
V g_heff_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2epresyntax_2eclassifier_get(void);
V g_heff_2epresyntax_2eargOf_24s51(V v_e_240);
V g_heff_2epresyntax_2eargOf_24s51_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_24s51_clo;
V g_prelude_2emap_24s52(V v_x2_240);
V g_prelude_2emap_24s52_entry(V self, V *a);
extern Clo g_prelude_2emap_24s52_clo;
V g_prelude_2emap_24s53(V v_x2_240);
V g_prelude_2emap_24s53_entry(V self, V *a);
extern Clo g_prelude_2emap_24s53_clo;
V g_heff_2epresyntax_2eappOf_24s50(V v_h_240, V v_args_241, V v_sp_242);
V g_heff_2epresyntax_2eappOf_24s50_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eappOf_24s50_clo;
V g_heff_2epresyntax_2epiBinderOf_24s54(V v_x2_240);
V g_heff_2epresyntax_2epiBinderOf_24s54_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiBinderOf_24s54_clo;
V g_heff_2epresyntax_2efieldDeclOf_24s55(V v_x2_240);
V g_heff_2epresyntax_2efieldDeclOf_24s55_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_24s55_clo;
V g_prelude_2emap_24s56(V v_x2_240);
V g_prelude_2emap_24s56_entry(V self, V *a);
extern Clo g_prelude_2emap_24s56_clo;
V g_prelude_2emap_24s58(V v_x2_240);
V g_prelude_2emap_24s58_entry(V self, V *a);
extern Clo g_prelude_2emap_24s58_clo;
V g_heff_2epresyntax_2evariantOf_24s57(V v_x2_240);
V g_heff_2epresyntax_2evariantOf_24s57_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_24s57_clo;
V g_prelude_2emap_24s59(V v_x2_240);
V g_prelude_2emap_24s59_entry(V self, V *a);
extern Clo g_prelude_2emap_24s59_clo;
V g_heff_2epresyntax_2efieldSetOf_24s60(V v_x2_240);
V g_heff_2epresyntax_2efieldSetOf_24s60_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_24s60_clo;
V g_prelude_2emap_24s61(V v_x2_240);
V g_prelude_2emap_24s61_entry(V self, V *a);
extern Clo g_prelude_2emap_24s61_clo;
V g_heff_2epresyntax_2ealtOf_24s62(V v_x2_240);
V g_heff_2epresyntax_2ealtOf_24s62_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_24s62_clo;
V g_prelude_2emap_24s63(V v_x2_240);
V g_prelude_2emap_24s63_entry(V self, V *a);
extern Clo g_prelude_2emap_24s63_clo;
V g_heff_2epresyntax_2eclassifyTermF_24s49(V v_e_240);
V g_heff_2epresyntax_2eclassifyTermF_24s49_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_24s49_clo;
V g_heff_2epresyntax_2eequationOf_24s48(V v_x2_240);
V g_heff_2epresyntax_2eequationOf_24s48_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_24s48_clo;
V g_prelude_2emap_24s64(V v_x2_240);
V g_prelude_2emap_24s64_entry(V self, V *a);
extern Clo g_prelude_2emap_24s64_clo;
V g_heff_2epresyntax_2eparamOf_24s65(V v_x2_240);
V g_heff_2epresyntax_2eparamOf_24s65_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_24s65_clo;
V g_prelude_2emap_24s66(V v_x2_240);
V g_prelude_2emap_24s66_entry(V self, V *a);
extern Clo g_prelude_2emap_24s66_clo;
V g_heff_2epresyntax_2eclassifyDeclF_24s47(V v_d_240);
V g_heff_2epresyntax_2eclassifyDeclF_24s47_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyDeclF_24s47_clo;
V g_heff_2epresyntax_2eclassify_get(void);
V g_prelude_2emap_24s68(V v_x2_240);
V g_prelude_2emap_24s68_entry(V self, V *a);
extern Clo g_prelude_2emap_24s68_clo;
V g_prelude_2emap_24s69(V v_x2_240);
V g_prelude_2emap_24s69_entry(V self, V *a);
extern Clo g_prelude_2emap_24s69_clo;
V g_prelude_2emap_24s70(V v_x2_240);
V g_prelude_2emap_24s70_entry(V self, V *a);
extern Clo g_prelude_2emap_24s70_clo;
V g_prelude_2emap_24s72(V v_x2_240);
V g_prelude_2emap_24s72_entry(V self, V *a);
extern Clo g_prelude_2emap_24s72_clo;
V g_heff_2epresyntax_2epiN_24s76(V v_x2_240);
V g_heff_2epresyntax_2epiN_24s76_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiN_24s76_clo;
V g_prelude_2emap_24s77(V v_x2_240);
V g_prelude_2emap_24s77_entry(V self, V *a);
extern Clo g_prelude_2emap_24s77_clo;
V g_prelude_2emap_24s78(V v_x2_240);
V g_prelude_2emap_24s78_entry(V self, V *a);
extern Clo g_prelude_2emap_24s78_clo;
V g_prelude_2emap_24s79(V v_x2_240);
V g_prelude_2emap_24s79_entry(V self, V *a);
extern Clo g_prelude_2emap_24s79_clo;
V g_prelude_2emap_24s81(V v_x2_240);
V g_prelude_2emap_24s81_entry(V self, V *a);
extern Clo g_prelude_2emap_24s81_clo;
V g_heff_2epresyntax_2einfNode_24s80(V v_n_240);
V g_heff_2epresyntax_2einfNode_24s80_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfNode_24s80_clo;
V g_heff_2epresyntax_2etypNode_24s75(V v_n_240);
V g_heff_2epresyntax_2etypNode_24s75_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNode_24s75_clo;
V g_heff_2epresyntax_2etypNom_24s74(V v_sp_240, V v_n_241);
V g_heff_2epresyntax_2etypNom_24s74_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNom_24s74_clo;
V g_prelude_2emap_24s73(V v_x2_240);
V g_prelude_2emap_24s73_entry(V self, V *a);
extern Clo g_prelude_2emap_24s73_clo;
V g_prelude_2emap_24s82(V v_x2_240);
V g_prelude_2emap_24s82_entry(V self, V *a);
extern Clo g_prelude_2emap_24s82_clo;
V g_heff_2epresyntax_2edeclN_24s71(V v_x2_240);
V g_heff_2epresyntax_2edeclN_24s71_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edeclN_24s71_clo;
V g_prelude_2emap_24s83(V v_x2_240);
V g_prelude_2emap_24s83_entry(V self, V *a);
extern Clo g_prelude_2emap_24s83_clo;
V g_heff_2epresyntax_2echkNode_24s67(V v_n_240);
V g_heff_2epresyntax_2echkNode_24s67_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkNode_24s67_clo;
V g_prelude_2emap_24s85(V v_x2_240);
V g_prelude_2emap_24s85_entry(V self, V *a);
extern Clo g_prelude_2emap_24s85_clo;
V g_heff_2epresyntax_2einfDe_24s86(V v_sp_240, V v_n_241);
V g_heff_2epresyntax_2einfDe_24s86_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfDe_24s86_clo;
V g_heff_2epresyntax_2etypDe_24s87(V v_sp_240, V v_n_241);
V g_heff_2epresyntax_2etypDe_24s87_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypDe_24s87_clo;
V g_heff_2epresyntax_2echkDe_24s84(V v_sp_240, V v_n_241);
V g_heff_2epresyntax_2echkDe_24s84_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkDe_24s84_clo;
V g_heff_2epsurface_2earrayNone_get(void);
V g_heff_2epsurface_2eplainImplicits_get(void);
V g_heff_2epsurface_2eescAt(V v_s_240, V v_i_241);
V g_heff_2epsurface_2eescAt_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eescAt_clo;
V g_heff_2epsurface_2equoteGo(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2epsurface_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2equoteGo_clo;
V g_heff_2epsurface_2ewordOf(V v_c_240);
V g_heff_2epsurface_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ewordOf_clo;
V g_heff_2epsurface_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242);
V g_heff_2epsurface_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eoperatorGo_clo;
V g_prelude_2efoldl_24s88(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s88_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s88_clo;
V g_heff_2epsurface_2eisOperator(V v_x_240);
V g_heff_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eisOperator_clo;
V g_heff_2epsurface_2enth(V v_x1_240, V v_i_241);
V g_heff_2epsurface_2enth_entry(V self, V *a);
extern Clo g_heff_2epsurface_2enth_clo;
V g_heff_2epsurface_2elocalName(V v_xs_240, V v_i_241);
V g_heff_2epsurface_2elocalName_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elocalName_clo;
V g_heff_2epsurface_2espineGo(V v_h_240, V v_acc_241);
V g_heff_2epsurface_2espineGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2espineGo_clo;
V g_heff_2epsurface_2eimplicitName(V v_names_240, V v_i_241, V v_a_242);
V g_heff_2epsurface_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eimplicitName_clo;
V g_heff_2epsurface_2elambdas(V v_ys_240, V v_bs_241, V v_e_242);
V g_heff_2epsurface_2elambdas_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elambdas_clo;
V g_heff_2epsurface_2eopApp(V v_c_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eopApp_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_clo;
V g_heff_2epsurface_2eimplicitGroup(V v_names_240, V v_u_241, V v_rest_242, V v_ctx_243);
V g_heff_2epsurface_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eimplicitGroup_clo;
V g_prelude_2efoldl_24s89(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s89_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s89_clo;
V g_heff_2epsurface_2eargStrs_24s93(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244);
V g_heff_2epsurface_2eargStrs_24s93_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_clo;
V g_heff_2epsurface_2eappPlain_24s92(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243);
V g_heff_2epsurface_2eappPlain_24s92_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_clo;
V g_heff_2epsurface_2eappStr_24s91(V v_c_240, V v_p_241, V v_xs_242, V v_t_243);
V g_heff_2epsurface_2eappStr_24s91_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_clo;
V g_heff_2epsurface_2elamStr_24s94(V v_c_240, V v_p_241, V v_xs_242, V v_l_243);
V g_heff_2epsurface_2elamStr_24s94_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_clo;
V g_heff_2epsurface_2ealtLine_24s95(V v_inner_240, V v_xs_241, V v_x4_242);
V g_heff_2epsurface_2ealtLine_24s95_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_clo;
V g_heff_2epsurface_2earrowGrouped_24s98(V v_c_240, V v_xs_241, V v_dom_242, V v_r_243);
V g_heff_2epsurface_2earrowGrouped_24s98_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_clo;
V g_heff_2epsurface_2earrowStr_24s97(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_cod_244, V v_implicit_245);
V g_heff_2epsurface_2earrowStr_24s97_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_clo;
V g_heff_2epsurface_2erecordFields_24s99(V v_c_240, V v_xs_241, V v_fs_242);
V g_heff_2epsurface_2erecordFields_24s99_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_clo;
V g_heff_2epsurface_2evariantStr_24s100(V v_c_240, V v_xs_241, V v_x4_242);
V g_heff_2epsurface_2evariantStr_24s100_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_clo;
V g_heff_2epsurface_2etyF_24s96(V v_c_240, V v_p_241, V v_xs_242, V v_t_243);
V g_heff_2epsurface_2etyF_24s96_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_clo;
V g_heff_2epsurface_2eelF_24s90(V v_c_240, V v_p_241, V v_xs_242, V v_e_243);
V g_heff_2epsurface_2eelF_24s90_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_clo;
V g_heff_2epsurface_2eprimitiveOf(V v_x1_240);
V g_heff_2epsurface_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eprimitiveOf_clo;
V g_heff_2epsurface_2estripIs(V v_e_240);
V g_heff_2epsurface_2estripIs_entry(V self, V *a);
extern Clo g_heff_2epsurface_2estripIs_clo;
V g_heff_2epsurface_2eunIsTy(V v_d_240);
V g_heff_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eunIsTy_clo;
V g_heff_2epsurface_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243);
V g_heff_2epsurface_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerAt_clo;
V g_heff_2epsurface_2eopApp_24s104(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s104_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s104_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s106(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s106_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s106_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s105(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s105_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s105_clo;
V g_heff_2epsurface_2eappStr_24s91_24s103(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s103_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s103_clo;
V g_heff_2epsurface_2elamStr_24s94_24s107(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s107_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s107_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s112(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s112_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s112_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s111(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s111_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s111_clo;
V g_prelude_2efoldl_24s114(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s114_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s114_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s113(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s113_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s113_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s115(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s115_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s115_clo;
V g_heff_2epsurface_2etyF_24s96_24s110(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s110_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s110_clo;
V g_heff_2epsurface_2eopApp_24s117(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s117_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s117_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s119(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s119_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s119_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s118(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s118_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s118_clo;
V g_heff_2epsurface_2eappStr_24s91_24s116(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s116_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s116_clo;
V g_heff_2epsurface_2elamStr_24s94_24s120(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s120_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s120_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s125(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s125_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s125_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s124(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s124_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s124_clo;
V g_prelude_2efoldl_24s127(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s127_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s127_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s126(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s126_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s126_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s128(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s128_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s128_clo;
V g_heff_2epsurface_2etyF_24s96_24s123(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s123_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s123_clo;
V g_heff_2epsurface_2eopApp_24s130(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s130_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s130_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s132(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s132_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s132_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s131(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s131_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s131_clo;
V g_heff_2epsurface_2eappStr_24s91_24s129(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s129_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s129_clo;
V g_heff_2epsurface_2elamStr_24s94_24s133(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s133_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s133_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s138(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s138_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s138_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s137(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s137_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s137_clo;
V g_prelude_2efoldl_24s140(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s140_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s140_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s139(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s139_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s139_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s141(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s141_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s141_clo;
V g_heff_2epsurface_2etyF_24s96_24s136(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s136_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s136_clo;
V g_heff_2epsurface_2eopApp_24s143(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s143_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s143_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s145(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s145_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s145_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s144(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s144_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s144_clo;
V g_heff_2epsurface_2eappStr_24s91_24s142(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s142_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s142_clo;
V g_heff_2epsurface_2elamStr_24s94_24s146(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s146_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s146_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s151(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s151_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s151_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s150(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s150_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s150_clo;
V g_prelude_2efoldl_24s153(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s153_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s153_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s152(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s152_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s152_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s154(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s154_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s154_clo;
V g_heff_2epsurface_2etyF_24s96_24s149(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s149_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s149_clo;
V g_heff_2epsurface_2eopApp_24s156(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s156_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s156_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s158(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s158_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s158_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s157(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s157_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s157_clo;
V g_heff_2epsurface_2eappStr_24s91_24s155(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s155_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s155_clo;
V g_heff_2epsurface_2elamStr_24s94_24s159(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s159_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s159_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s164(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s164_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s164_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s163(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s163_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s163_clo;
V g_prelude_2efoldl_24s166(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s166_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s166_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s165(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s165_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s165_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s167(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s167_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s167_clo;
V g_heff_2epsurface_2etyF_24s96_24s162(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s162_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s162_clo;
V g_heff_2epsurface_2eopApp_24s169(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s169_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s169_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s171(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s171_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s171_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s170(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s170_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s170_clo;
V g_heff_2epsurface_2eappStr_24s91_24s168(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s168_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s168_clo;
V g_heff_2epsurface_2elamStr_24s94_24s172(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s172_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s172_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s176(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s176_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s176_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s177(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s177_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s177_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s178(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s178_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s178_clo;
V g_heff_2epsurface_2etyF_24s96_24s175(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s175_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s175_clo;
V g_heff_2epsurface_2eopApp_24s180(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s180_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s180_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s181(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s181_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s181_clo;
V g_heff_2epsurface_2eappStr_24s91_24s179(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s179_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s179_clo;
V g_heff_2epsurface_2elamStr_24s94_24s182(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s182_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s182_clo;
V g_heff_2epsurface_2eelF_24s90_24s184(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s184_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s184_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s183(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s183_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s183_clo;
V g_heff_2epsurface_2eelF_24s90_24s174(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s174_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s174_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s173(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s173_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s173_clo;
V g_heff_2epsurface_2eelF_24s90_24s161(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s161_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s161_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s160(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s160_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s160_clo;
V g_heff_2epsurface_2eelF_24s90_24s148(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s148_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s148_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s147(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s147_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s147_clo;
V g_heff_2epsurface_2eelF_24s90_24s135(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s135_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s135_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s134(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s134_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s134_clo;
V g_heff_2epsurface_2eelF_24s90_24s122(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s122_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s122_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s121(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s121_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s121_clo;
V g_heff_2epsurface_2eelF_24s90_24s109(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s109_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s109_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s108(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s108_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s108_clo;
V g_heff_2epsurface_2eelF_24s90_24s102(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s102_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s102_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s186(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s186_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s186_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s185(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s185_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s185_clo;
V g_prelude_2efoldl_24s188(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s188_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s188_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s187(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s187_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s187_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s189(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s189_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s189_clo;
V g_heff_2epsurface_2etyF_24s96_24s101(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s101_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s101_clo;
V g_heff_2epsurface_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242);
V g_heff_2epsurface_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerParam_clo;
V g_heff_2epsurface_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243);
V g_heff_2epsurface_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etypeFormer_clo;
V g_prelude_2emap_24s190(V v_x2_240);
V g_prelude_2emap_24s190_entry(V self, V *a);
extern Clo g_prelude_2emap_24s190_clo;
V g_heff_2ereadback_2earrayEmpty_get(void);
V g_heff_2ereadback_2elocalArgs(V v_x1_240);
V g_heff_2ereadback_2elocalArgs_entry(V self, V *a);
extern Clo g_heff_2ereadback_2elocalArgs_clo;
V g_heff_2ereadback_2ereadbSpine_24s195(V v_n_240, V v_x3_241, V v_t_242);
V g_heff_2ereadback_2ereadbSpine_24s195_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbSpine_24s195_clo;
V g_heff_2ereadback_2ereadbBare_24s194(V v_n_240, V v_h_241, V v_sp_242);
V g_heff_2ereadback_2ereadbBare_24s194_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbBare_24s194_clo;
V g_heff_2ereadback_2ereadbCloEl_24s196(V v_n_240, V v_dom_241, V v_x4_242);
V g_heff_2ereadback_2ereadbCloEl_24s196_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbCloEl_24s196_clo;
V g_heff_2ereadback_2ereadbCloTy_24s198(V v_n_240, V v_dom_241, V v_x4_242);
V g_heff_2ereadback_2ereadbCloTy_24s198_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbCloTy_24s198_clo;
V g_heff_2ereadback_2egoRT_24s199(V v_i_240, V v_ls_241, V v_x4_242);
V g_heff_2ereadback_2egoRT_24s199_entry(V self, V *a);
extern Clo g_heff_2ereadback_2egoRT_24s199_clo;
V g_heff_2ereadback_2ereadbTypeF_24s197(V v_n_240, V v_x3_241);
V g_heff_2ereadback_2ereadbTypeF_24s197_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbTypeF_24s197_clo;
V g_heff_2ereadback_2ereadbTermF_24s193(V v_n_240, V v_x3_241);
V g_heff_2ereadback_2ereadbTermF_24s193_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbTermF_24s193_clo;
V g_heff_2ereadback_2ereadbBare_24s200(V v_n_240, V v_h_241, V v_sp_242);
V g_heff_2ereadback_2ereadbBare_24s200_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbBare_24s200_clo;
V g_heff_2erename_2erenameTermF(V v_k_240, V v_r_241, V v_e_242);
V g_heff_2erename_2erenameTermF_entry(V self, V *a);
extern Clo g_heff_2erename_2erenameTermF_clo;
V g_heff_2erename_2erenameTypeF(V v_k_240, V v_r_241, V v_t_242);
V g_heff_2erename_2erenameTypeF_entry(V self, V *a);
extern Clo g_heff_2erename_2erenameTypeF_clo;
V g_heff_2erename_2erkOf(V v_r_240);
V g_heff_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2erename_2erkOf_clo;
V g_heff_2erename_2edescribeKey(V v_x_240);
V g_heff_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2erename_2edescribeKey_clo;
V g_heff_2erename_2enubFirst(V v_x1_240);
V g_heff_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2erename_2enubFirst_clo;
V g_prelude_2efoldl_24s202(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s202_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s202_clo;
V g_prelude_2efoldl_24s203(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s203_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s203_clo;
V g_prelude_2efoldl_24s204(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s204_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s204_clo;
V g_prelude_2efoldl_24s206(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s206_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s206_clo;
V g_prelude_2efoldl_24s207(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s207_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s207_clo;
V g_prelude_2efoldl_24s208(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s208_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s208_clo;
V g_heff_2erename_2eglobalsTypeF_24s205(V v_t_240);
V g_heff_2erename_2eglobalsTypeF_24s205_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTypeF_24s205_clo;
V g_heff_2erename_2eglobalsTermF_24s201(V v_e_240);
V g_heff_2erename_2eglobalsTermF_24s201_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTermF_24s201_clo;
V g_heff_2erename_2efirstAliasOf(V v_x1_240, V v_x_241);
V g_heff_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2erename_2efirstAliasOf_clo;
V g_heff_2erender_2elineColGo(V v_src_240, V v_i_241, V v_l_242, V v_start_243);
V g_heff_2erender_2elineColGo_entry(V self, V *a);
extern Clo g_heff_2erender_2elineColGo_clo;
V g_heff_2erender_2enumDigits(V v_x_240);
V g_heff_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2erender_2enumDigits_clo;
V g_heff_2erender_2erepeated(V v_k_240, V v_c_241);
V g_heff_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2erender_2erepeated_clo;
V g_heff_2erender_2elineStartFrom(V v_src_240, V v_l_241, V v_start_242);
V g_heff_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2erender_2elineStartFrom_clo;
V g_heff_2erender_2eprettyAt(V v_src_240, V v_sp_241, V v_w_242, V v_l_243, V v_lstart_244, V v_lend_245);
V g_heff_2erender_2eprettyAt_entry(V self, V *a);
extern Clo g_heff_2erender_2eprettyAt_clo;
V g_heff_2erender_2eprettyLine(V v_src_240, V v_sp_241, V v_w_242, V v_l_243);
V g_heff_2erender_2eprettyLine_entry(V self, V *a);
extern Clo g_heff_2erender_2eprettyLine_clo;
V g_heff_2erender_2elineRange(V v_src_240, V v_sp_241, V v_w_242, V v_l_243, V v_le_244);
V g_heff_2erender_2elineRange_entry(V self, V *a);
extern Clo g_heff_2erender_2elineRange_clo;
V g_heff_2erender_2elinesPretty(V v_src_240, V v_sp_241);
V g_heff_2erender_2elinesPretty_entry(V self, V *a);
extern Clo g_heff_2erender_2elinesPretty_clo;
V g_heff_2erender_2eprtCode(V v_d_240);
V g_heff_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2erender_2eprtCode_clo;
V g_heff_2erender_2efileDiag(V v_path_240, V v_src_241, V v_d_242);
V g_heff_2erender_2efileDiag_entry(V self, V *a);
extern Clo g_heff_2erender_2efileDiag_clo;
V g_heff_2efmt_2elex_2ekeywords_get(void);
V g_heff_2efmt_2elex_2esymChars_get(void);
V g_heff_2efmt_2elex_2eisNameC(V v_c_240);
V g_heff_2efmt_2elex_2eisNameC_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eisNameC_clo;
V g_heff_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2enameEnd_clo;
V g_heff_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2eplainEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eplainEnd_clo;
V g_heff_2efmt_2elex_2etagEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2etagEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2etagEnd_clo;
V g_heff_2efmt_2elex_2edigitsEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2edigitsEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2edigitsEnd_clo;
V g_heff_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2edashesEnd_clo;
V g_heff_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eeolEnd_clo;
V g_heff_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241);
V g_heff_2efmt_2elex_2esymEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2esymEnd_clo;
V g_heff_2efmt_2elex_2enumExp(V v_s_240, V v_b_241);
V g_heff_2efmt_2elex_2enumExp_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2enumExp_clo;
V g_heff_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241);
V g_heff_2efmt_2elex_2enumFrac_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2enumFrac_clo;
V g_heff_2efmt_2elex_2estrScan(V v_s_240, V v_j_241, V v_acc_242);
V g_heff_2efmt_2elex_2estrScan_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2estrScan_clo;
V g_heff_2efmt_2elex_2eblockScan(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245);
V g_heff_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eblockScan_clo;
V g_heff_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241);
V g_heff_2efmt_2elex_2eoperandBefore_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eoperandBefore_clo;
V g_heff_2efmt_2elex_2enameStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_j_245);
V g_heff_2efmt_2elex_2enameStep_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2enameStep_clo;
V g_heff_2efmt_2elex_2enumStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245);
V g_heff_2efmt_2elex_2enumStep_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2enumStep_clo;
V g_heff_2efmt_2elex_2estrStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245);
V g_heff_2efmt_2elex_2estrStep_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2estrStep_clo;
V g_heff_2efmt_2elex_2eblockCmtStep(V v_src_240, V v_i_241, V v_r_242);
V g_heff_2efmt_2elex_2eblockCmtStep_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2eblockCmtStep_clo;
V g_heff_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_c_246);
V g_heff_2efmt_2elex_2estepAt_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2estepAt_clo;
V g_heff_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244);
V g_heff_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2elex_2elexGo_clo;
V g_heff_2efmt_2eimports_2elineEndFrom(V v_s_240, V v_i_241);
V g_heff_2efmt_2eimports_2elineEndFrom_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2elineEndFrom_clo;
V g_heff_2efmt_2eimports_2enameC(V v_c_240);
V g_heff_2efmt_2eimports_2enameC_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2enameC_clo;
V g_heff_2efmt_2eimports_2eallNameC(V v_s_240, V v_i_241);
V g_heff_2efmt_2eimports_2eallNameC_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2eallNameC_clo;
V g_heff_2efmt_2eimports_2eisAlias(V v_x_240);
V g_heff_2efmt_2eimports_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2eisAlias_clo;
V g_heff_2efmt_2eimports_2espacesOf(V v_n_240);
V g_heff_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2espacesOf_clo;
V g_prelude_2efilter_24s209(V v_x2_240);
V g_prelude_2efilter_24s209_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s209_clo;
V g_heff_2efmt_2eimports_2eimportWords(V v_rest_240);
V g_heff_2efmt_2eimports_2eimportWords_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2eimportWords_clo;
V g_heff_2efmt_2eimports_2eoneImport(V v_i_240, V v_e_241, V v_ws_242);
V g_heff_2efmt_2eimports_2eoneImport_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2eoneImport_clo;
V g_heff_2efmt_2eimports_2eemptyOrComment(V v_line_240);
V g_heff_2efmt_2eimports_2eemptyOrComment_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2eemptyOrComment_clo;
V g_heff_2efmt_2eimports_2ereadGo(V v_src_240, V v_i_241, V v_acc_242);
V g_heff_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2ereadGo_clo;
V g_prelude_2efoldl_24s210(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s210_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s210_clo;
V g_prelude_2emerge_24s212(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s212_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s212_clo;
V g_prelude_2esortBy_24s211(V v_xs_240);
V g_prelude_2esortBy_24s211_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s211_clo;
V g_prelude_2emap_24s213(V v_x2_240);
V g_prelude_2emap_24s213_entry(V self, V *a);
extern Clo g_prelude_2emap_24s213_clo;
V g_heff_2efmt_2etoks_2ecountNl(V v_s_240, V v_a_241, V v_b_242);
V g_heff_2efmt_2etoks_2ecountNl_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2ecountNl_clo;
V g_heff_2efmt_2etoks_2einlineAt(V v_elems_240, V v_k_241, V v_e_242);
V g_heff_2efmt_2etoks_2einlineAt_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2einlineAt_clo;
V g_map_2einsert_24s214(V v_k_240, V v_v_241, V v_x4_242);
V g_map_2einsert_24s214_entry(V self, V *a);
extern Clo g_map_2einsert_24s214_clo;
V g_heff_2efmt_2etoks_2estepTok(V v_src_240, V v_st_241, V v_e_242, V v_blank_243, V v_t_244);
V g_heff_2efmt_2etoks_2estepTok_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2estepTok_clo;
V g_heff_2efmt_2etoks_2estepTrail(V v_st_240, V v_e_241, V v_lt_242);
V g_heff_2efmt_2etoks_2estepTrail_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2estepTrail_clo;
V g_heff_2efmt_2etoks_2estepCmt(V v_elems_240, V v_st_241, V v_e_242, V v_blank_243);
V g_heff_2efmt_2etoks_2estepCmt_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2estepCmt_clo;
V g_heff_2efmt_2etoks_2estep(V v_src_240, V v_elems_241, V v_st_242, V v_e_243);
V g_heff_2efmt_2etoks_2estep_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2estep_clo;
V g_heff_2efmt_2etoks_2elineElem(V v_src_240, V v_acc_241, V v_e_242);
V g_heff_2efmt_2etoks_2elineElem_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2elineElem_clo;
V g_heff_2efmt_2etoks_2eemptyStA_get(void);
V g_prelude_2emerge_24s216(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s216_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s216_clo;
V g_prelude_2esortBy_24s215(V v_xs_240);
V g_prelude_2esortBy_24s215_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s215_clo;
V g_prelude_2emap_24s217(V v_x2_240);
V g_prelude_2emap_24s217_entry(V self, V *a);
extern Clo g_prelude_2emap_24s217_clo;
V g_prelude_2emap_24s218(V v_x2_240);
V g_prelude_2emap_24s218_entry(V self, V *a);
extern Clo g_prelude_2emap_24s218_clo;
V g_heff_2efmt_2etoks_2eattach(V v_src_240, V v_toks_241, V v_comments_242);
V g_heff_2efmt_2etoks_2eattach_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2eattach_clo;
V g_heff_2efmt_2etoks_2eplainGo(V v_n_240, V v_acc_241, V v_x3_242);
V g_heff_2efmt_2etoks_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2etoks_2eplainGo_clo;
V g_heff_2ecst_2ereadSumAlg(V v_x1_240, V v_p_241);
V g_heff_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2ecst_2ereadSumAlg_clo;
V g_heff_2ecst_2ereadH_get(void);
V g_heff_2ecst_2eendBefore(V v_s_240, V v_j_241);
V g_heff_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2ecst_2eendBefore_clo;
V g_heff_2ecst_2eatTok(V v_s_240, V v_j_241, V v_t_242);
V g_heff_2ecst_2eatTok_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatTok_clo;
V g_heff_2ecst_2etokAt(V v_s_240, V v_j_241);
V g_heff_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2etokAt_clo;
V g_heff_2ecst_2ecur(V v_s_240);
V g_heff_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2ecst_2ecur_clo;
V g_heff_2ecst_2enext(V v_hd_240, V v_k_241);
V g_heff_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2ecst_2enext_clo;
V g_heff_2ecst_2enextN(V v_n_240, V v_p_241, V v_p_242);
V g_heff_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2ecst_2enextN_clo;
V g_heff_2ecst_2eatBoundary(V v_hd_240, V v_k2_241);
V g_heff_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatBoundary_clo;
V g_heff_2ecst_2eexpectAnn(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectAnn_clo;
V g_heff_2ecst_2eexpectSym(V v_x_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectSym_clo;
V g_heff_2ecst_2eexpectPunct(V v_x_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectPunct_clo;
V g_heff_2ecst_2eexpectKw(V v_x_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectKw_clo;
V g_heff_2ecst_2eexpectKind(V v_k_240, V v_what_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectKind_clo;
V g_heff_2ecst_2econtinuesBlock(V v_t_240, V v_col_241);
V g_heff_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2ecst_2econtinuesBlock_clo;
V g_heff_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244);
V g_heff_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_clo;
V g_heff_2ecst_2eblock(V v_item_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_clo;
V g_heff_2ecst_2einBrackets(V v_p_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2ecst_2einBrackets_clo;
V g_heff_2ecst_2estartsAtom(V v_t_240);
V g_heff_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2ecst_2estartsAtom_clo;
V g_heff_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2emanyGo_clo;
V g_heff_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245);
V g_heff_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2esepGo_clo;
V g_heff_2ecst_2eexprHead(V v_g_240, V v_t_241);
V g_heff_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprHead_clo;
V g_heff_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprF_clo;
V g_heff_2ecst_2earrowRhsF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2earrowRhsF_entry(V self, V *a);
extern Clo g_heff_2ecst_2earrowRhsF_clo;
V g_heff_2ecst_2eopLoopF(V v_g_240, V v_minPrec_241, V v_lhs_242, V v_hd_243, V v_k_244);
V g_heff_2ecst_2eopLoopF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eopLoopF_clo;
V g_heff_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eoperandsF_clo;
V g_heff_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2efieldsGo_clo;
V g_heff_2ecst_2ebracesF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2ebracesF_entry(V self, V *a);
extern Clo g_heff_2ecst_2ebracesF_clo;
V g_heff_2ecst_2eanonymousSumF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eanonymousSumF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eanonymousSumF_clo;
V g_heff_2ecst_2eparensF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eparensF_clo;
V g_heff_2ecst_2elistOfF_24s219(V v_item_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2elistOfF_24s219_entry(V self, V *a);
extern Clo g_heff_2ecst_2elistOfF_24s219_clo;
V g_heff_2ecst_2eatomBase(V v_g_240, V v_t_241);
V g_heff_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomBase_clo;
V g_heff_2ecst_2eatomF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eatomF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomF_clo;
V g_heff_2ecst_2elamBinderF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2ecst_2elamBinderF_clo;
V g_heff_2ecst_2elamBinders(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2ecst_2elamBinders_clo;
V g_heff_2ecst_2elambdaF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2ecst_2elambdaF_clo;
V g_heff_2ecst_2ecaseExprF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2ecaseExprF_clo;
V g_heff_2ecst_2eifExprF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eifExprF_clo;
V g_heff_2ecst_2eletHeadF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletHeadF_clo;
V g_heff_2ecst_2eletExprF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eletExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletExprF_clo;
V g_heff_2ecst_2eletStmtF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletStmtF_clo;
V g_heff_2ecst_2estatementF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2estatementF_entry(V self, V *a);
extern Clo g_heff_2ecst_2estatementF_clo;
V g_heff_2ecst_2erecordPatF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2erecordPatF_entry(V self, V *a);
extern Clo g_heff_2ecst_2erecordPatF_clo;
V g_heff_2ecst_2epatHeadF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatHeadF_clo;
V g_heff_2ecst_2epatternF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatternF_clo;
V g_heff_2ecst_2elistOfF_24s220(V v_item_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2elistOfF_24s220_entry(V self, V *a);
extern Clo g_heff_2ecst_2elistOfF_24s220_clo;
V g_heff_2ecst_2epatAtomF(V v_g_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatAtomF_clo;
V g_heff_2ecst_2egram_get(void);
V g_heff_2ecst_2eanonymousSumF_24s223(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eanonymousSumF_24s223_entry(V self, V *a);
extern Clo g_heff_2ecst_2eanonymousSumF_24s223_clo;
V g_heff_2ecst_2earrowRhsF_24s228(V v_hd_240, V v_k_241);
V g_heff_2ecst_2earrowRhsF_24s228_entry(V self, V *a);
extern Clo g_heff_2ecst_2earrowRhsF_24s228_clo;
V g_heff_2ecst_2eopLoopF_24s227(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2eopLoopF_24s227_entry(V self, V *a);
extern Clo g_heff_2ecst_2eopLoopF_24s227_clo;
V g_heff_2ecst_2eexprHead_24s226(V v_t_240);
V g_heff_2ecst_2eexprHead_24s226_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprHead_24s226_clo;
V g_heff_2ecst_2eexprF_24s225(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eexprF_24s225_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprF_24s225_clo;
V g_heff_2ecst_2eparensF_24s224(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eparensF_24s224_entry(V self, V *a);
extern Clo g_heff_2ecst_2eparensF_24s224_clo;
V g_heff_2ecst_2ebracesF_24s229(V v_hd_240, V v_k_241);
V g_heff_2ecst_2ebracesF_24s229_entry(V self, V *a);
extern Clo g_heff_2ecst_2ebracesF_24s229_clo;
V g_heff_2ecst_2eatomBase_24s222(V v_t_240);
V g_heff_2ecst_2eatomBase_24s222_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomBase_24s222_clo;
V g_heff_2ecst_2eatomF_24s221(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eatomF_24s221_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomF_24s221_clo;
V g_heff_2ecst_2edataParam(V v_hd_240, V v_k_241);
V g_heff_2ecst_2edataParam_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataParam_clo;
V g_heff_2ecst_2emanyParams(V v_acc_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2ecst_2emanyParams_clo;
V g_heff_2ecst_2edataAlternative(V v_hd_240, V v_k_241);
V g_heff_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataAlternative_clo;
V g_heff_2ecst_2echeckAltNames(V v_name_240, V v_x2_241);
V g_heff_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2ecst_2echeckAltNames_clo;
V g_heff_2ecst_2esepGo_24s230(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244);
V g_heff_2ecst_2esepGo_24s230_entry(V self, V *a);
extern Clo g_heff_2ecst_2esepGo_24s230_clo;
V g_heff_2ecst_2edataDecl(V v_hd_240, V v_k_241);
V g_heff_2ecst_2edataDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataDecl_clo;
V g_heff_2ecst_2etypeDecl(V v_hd_240, V v_k_241);
V g_heff_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2etypeDecl_clo;
V g_heff_2ecst_2etheoryField(V v_hd_240, V v_k_241);
V g_heff_2ecst_2etheoryField_entry(V self, V *a);
extern Clo g_heff_2ecst_2etheoryField_clo;
V g_heff_2ecst_2eblockGo_24s232(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2eblockGo_24s232_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_24s232_clo;
V g_heff_2ecst_2eblock_24s231(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eblock_24s231_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_24s231_clo;
V g_heff_2ecst_2etheoryDecl(V v_hd_240, V v_k_241);
V g_heff_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2etheoryDecl_clo;
V g_heff_2ecst_2eforeignDecl(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eforeignDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2eforeignDecl_clo;
V g_heff_2ecst_2efixityRest(V v_acc_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2efixityRest_entry(V self, V *a);
extern Clo g_heff_2ecst_2efixityRest_clo;
V g_heff_2ecst_2edeclNameLen(V v_t_240, V v_t2_241, V v_t3_242);
V g_heff_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclNameLen_clo;
V g_heff_2ecst_2esigOrEqn(V v_item_240, V v_t_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2ecst_2esigOrEqn_clo;
V g_heff_2ecst_2elocalDecl(V v_st_240, V v_k_241);
V g_heff_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2elocalDecl_clo;
V g_heff_2ecst_2eblockGo_24s235(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243);
V g_heff_2ecst_2eblockGo_24s235_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_24s235_clo;
V g_heff_2ecst_2eblock_24s234(V v_hd_240, V v_k_241);
V g_heff_2ecst_2eblock_24s234_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_24s234_clo;
V g_heff_2ecst_2esigOrEqn_24s233(V v_t_240, V v_hd_241, V v_k_242);
V g_heff_2ecst_2esigOrEqn_24s233_entry(V self, V *a);
extern Clo g_heff_2ecst_2esigOrEqn_24s233_clo;
V g_heff_2ecst_2edeclAt(V v_t_240);
V g_heff_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclAt_clo;
V g_heff_2ecst_2eskipFrom(V v_s_240);
V g_heff_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2ecst_2eskipFrom_clo;
V g_heff_2ecst_2eskipDecl(V v_s_240);
V g_heff_2ecst_2eskipDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2eskipDecl_clo;
V g_heff_2ecst_2erunP_24s236(V v_st_240);
V g_heff_2ecst_2erunP_24s236_entry(V self, V *a);
extern Clo g_heff_2ecst_2erunP_24s236_clo;
V g_heff_2ecst_2edeclaredTwo(V v_t_240, V v_u_241);
V g_heff_2ecst_2edeclaredTwo_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclaredTwo_clo;
V g_heff_2ecst_2edeclaredAt(V v_s_240);
V g_heff_2ecst_2edeclaredAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclaredAt_clo;
V g_heff_2ecst_2eprogramGo(V v_s_240, V v_acc_241);
V g_heff_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2eprogramGo_clo;
V g_heff_2ecst_2efirstP(V v_x1_240);
V g_heff_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstP_clo;
V g_heff_2ecst_2elastP(V v_x1_240);
V g_heff_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastP_clo;
V g_heff_2ecst_2efirstE(V v_x1_240);
V g_heff_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstE_clo;
V g_heff_2ecst_2elastE(V v_x1_240);
V g_heff_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastE_clo;
V g_heff_2ecst_2efirstD(V v_x1_240);
V g_heff_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstD_clo;
V g_heff_2ecst_2edataLast(V v_name_240, V v_params_241, V v_universe_242, V v_x4_243);
V g_heff_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataLast_clo;
V g_heff_2ecst_2elastD(V v_x1_240);
V g_heff_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastD_clo;
V g_heff_2esurface_2eappendS(V v_x1_240, V v_ys_241);
V g_heff_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esurface_2eappendS_clo;
V g_heff_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242);
V g_heff_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esurface_2ewithScope_clo;
V g_heff_2esurface_2etraverseS(V v_f_240, V v_x2_241);
V g_heff_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esurface_2etraverseS_clo;
V g_heff_2esurface_2eblock(V v_f_240, V v_xs_241, V v_st_242);
V g_heff_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esurface_2eblock_clo;
V g_heff_2esurface_2edigitsVal(V v_s_240, V v_i_241, V v_stop_242, V v_n_243);
V g_heff_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esurface_2edigitsVal_clo;
V g_heff_2esurface_2eintOfText(V v_s_240);
V g_heff_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esurface_2eintOfText_clo;
V g_heff_2esurface_2eipow10(V v_k_240);
V g_heff_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esurface_2eipow10_clo;
V g_heff_2esurface_2eexpOf(V v_ex_240);
V g_heff_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eexpOf_clo;
V g_heff_2esurface_2edotAt(V v_s_240, V v_i_241);
V g_heff_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esurface_2edotAt_clo;
V g_heff_2esurface_2esplitExp(V v_s_240, V v_i_241);
V g_heff_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esurface_2esplitExp_clo;
V g_heff_2esurface_2efloatSplit(V v_s_240, V v_eAt_241);
V g_heff_2esurface_2efloatSplit_entry(V self, V *a);
extern Clo g_heff_2esurface_2efloatSplit_clo;
V g_heff_2esurface_2efloatOfText(V v_s_240);
V g_heff_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esurface_2efloatOfText_clo;
V g_heff_2esurface_2epiBinders(V v_x1_240);
V g_heff_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esurface_2epiBinders_clo;
V g_heff_2esurface_2epiImplicits(V v_x1_240);
V g_heff_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esurface_2epiImplicits_clo;
V g_heff_2esurface_2econcatMapS(V v_f_240, V v_x2_241);
V g_heff_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esurface_2econcatMapS_clo;
V g_heff_2esurface_2eboundBy(V v_pv_240, V v_x2_241);
V g_heff_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esurface_2eboundBy_clo;
V g_heff_2esurface_2eisNameE(V v_x1_240);
V g_heff_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esurface_2eisNameE_clo;
V g_heff_2esurface_2easNameE(V v_e_240);
V g_heff_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esurface_2easNameE_clo;
V g_heff_2esurface_2ecatMaybesS(V v_x1_240);
V g_heff_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esurface_2ecatMaybesS_clo;
V g_heff_2esurface_2eidentOf(V v_x1_240);
V g_heff_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eidentOf_clo;
V g_prelude_2emap_24s237(V v_x2_240);
V g_prelude_2emap_24s237_entry(V self, V *a);
extern Clo g_prelude_2emap_24s237_clo;
V g_heff_2esurface_2easBinderOn(V v_e_240, V v_p_241);
V g_heff_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esurface_2easBinderOn_clo;
V g_heff_2esurface_2eallS_24s238(V v_x2_240);
V g_heff_2esurface_2eallS_24s238_entry(V self, V *a);
extern Clo g_heff_2esurface_2eallS_24s238_clo;
V g_prelude_2emap_24s239(V v_x2_240);
V g_prelude_2emap_24s239_entry(V self, V *a);
extern Clo g_prelude_2emap_24s239_clo;
V g_heff_2esurface_2enameBinder(V v_e0_240);
V g_heff_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esurface_2enameBinder_clo;
V g_heff_2esurface_2efoldr(V v_f_240, V v_z_241, V v_x3_242);
V g_heff_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esurface_2efoldr_clo;
V g_heff_2esurface_2eplainBinder(V v_d_240);
V g_heff_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esurface_2eplainBinder_clo;
V g_heff_2esurface_2eallS_24s240(V v_x2_240);
V g_heff_2esurface_2eallS_24s240_entry(V self, V *a);
extern Clo g_heff_2esurface_2eallS_24s240_clo;
V g_heff_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_orig_244);
V g_heff_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esurface_2earrowNames_clo;
V g_heff_2esurface_2earrowBinop(V v_lhs_240, V v_rhs_241);
V g_heff_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esurface_2earrowBinop_clo;
V g_heff_2esurface_2eshortcut(V v_op_240, V v_c_241, V v_a_242, V v_b_243);
V g_heff_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esurface_2eshortcut_clo;
V g_heff_2esurface_2eapplyOp(V v_op_240, V v_l_241, V v_r_242);
V g_heff_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esurface_2eapplyOp_clo;
V g_heff_2esurface_2eapplyPatOp(V v_op_240, V v_l_241, V v_r_242);
V g_heff_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esurface_2eapplyPatOp_clo;
V g_heff_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243);
V g_heff_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esurface_2efirstS_clo;
V g_heff_2esurface_2echeckFixOf(V v_fix_240, V v_lenient_241, V v_x3_242);
V g_heff_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2echeckFixOf_clo;
V g_heff_2esurface_2eeqnsOf(V v_f_240, V v_x2_241);
V g_heff_2esurface_2eeqnsOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eeqnsOf_clo;
V g_heff_2esurface_2eeqnEnd(V v_f_240, V v_x2_241, V v_e_242);
V g_heff_2esurface_2eeqnEnd_entry(V self, V *a);
extern Clo g_heff_2esurface_2eeqnEnd_clo;
V g_heff_2esurface_2eassembleOne(V v_broken_240, V v_items_241, V v_x3_242);
V g_heff_2esurface_2eassembleOne_entry(V self, V *a);
extern Clo g_heff_2esurface_2eassembleOne_clo;
V g_heff_2esurface_2esigNames(V v_x1_240);
V g_heff_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esurface_2esigNames_clo;
V g_heff_2esurface_2eeqnNames(V v_x1_240);
V g_heff_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esurface_2eeqnNames_clo;
V g_heff_2esurface_2eassembleDiagOne(V v_broken_240, V v_sigs_241, V v_eqns_242, V v_x4_243);
V g_heff_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esurface_2eassembleDiagOne_clo;
V g_heff_2esurface_2eatomOf(V v_x1_240);
V g_heff_2esurface_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eatomOf_clo;
V g_heff_2esurface_2esymAtom(V v_x1_240);
V g_heff_2esurface_2esymAtom_entry(V self, V *a);
extern Clo g_heff_2esurface_2esymAtom_clo;
V g_heff_2esurface_2eopRhsOf(V v_e_240);
V g_heff_2esurface_2eopRhsOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eopRhsOf_clo;
V g_heff_2esurface_2ebracedOne(V v_x1_240);
V g_heff_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esurface_2ebracedOne_clo;
V g_heff_2esurface_2esettingsOf(V v_x1_240);
V g_heff_2esurface_2esettingsOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2esettingsOf_clo;
V g_heff_2esurface_2ewordKw(V v_x1_240);
V g_heff_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esurface_2ewordKw_clo;
V g_heff_2esurface_2eatomTok(V v_t_240);
V g_heff_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esurface_2eatomTok_clo;
V g_heff_2esurface_2epatTok(V v_t_240);
V g_heff_2esurface_2epatTok_entry(V self, V *a);
extern Clo g_heff_2esurface_2epatTok_clo;
V g_prelude_2emap_24s241(V v_x2_240);
V g_prelude_2emap_24s241_entry(V self, V *a);
extern Clo g_prelude_2emap_24s241_clo;
V g_heff_2esurface_2econAtom(V v_t_240, V v_fs_241, V v_st_242);
V g_heff_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esurface_2econAtom_clo;
V g_heff_2esurface_2efieldsOf(V v_e_240, V v_acc_241);
V g_heff_2esurface_2efieldsOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2efieldsOf_clo;
V g_heff_2esurface_2earrowAfter(V v_s_240, V v_t_241);
V g_heff_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esurface_2earrowAfter_clo;
V g_heff_2esurface_2elistP(V v_sp_240, V v_xs_241);
V g_heff_2esurface_2elistP_entry(V self, V *a);
extern Clo g_heff_2esurface_2elistP_clo;
V g_heff_2esurface_2edeclarationL(V v_r_240, V v_e_241);
V g_heff_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esurface_2edeclarationL_clo;
V g_heff_2esurface_2efieldDeclOf(V v_d_240);
V g_heff_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2efieldDeclOf_clo;
V g_heff_2esurface_2esettingL(V v_r_240, V v_e_241);
V g_heff_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esurface_2esettingL_clo;
V g_prelude_2emap_24s242(V v_x2_240);
V g_prelude_2emap_24s242_entry(V self, V *a);
extern Clo g_prelude_2emap_24s242_clo;
V g_heff_2esurface_2ebracesL(V v_r_240, V v_o_241, V v_fs_242, V v_c_243);
V g_heff_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esurface_2ebracesL_clo;
V g_heff_2esurface_2econL(V v_r_240, V v_c_241, V v_args_242);
V g_heff_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esurface_2econL_clo;
V g_heff_2esurface_2evariantOf(V v_e_240);
V g_heff_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2evariantOf_clo;
V g_heff_2esurface_2evariantL(V v_r_240, V v_e_241);
V g_heff_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esurface_2evariantL_clo;
V g_heff_2esurface_2elamBinderL(V v_r_240, V v_e_241);
V g_heff_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esurface_2elamBinderL_clo;
V g_heff_2esurface_2econcatMapS_24s243(V v_x2_240);
V g_heff_2esurface_2econcatMapS_24s243_entry(V self, V *a);
extern Clo g_heff_2esurface_2econcatMapS_24s243_clo;
V g_heff_2esurface_2efoldr_24s244(V v_z_240, V v_x3_241);
V g_heff_2esurface_2efoldr_24s244_entry(V self, V *a);
extern Clo g_heff_2esurface_2efoldr_24s244_clo;
V g_heff_2esurface_2elambdaL(V v_r_240, V v_binders_241, V v_body_242);
V g_heff_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esurface_2elambdaL_clo;
V g_heff_2esurface_2ealtL(V v_r_240, V v_e_241);
V g_heff_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esurface_2ealtL_clo;
V g_heff_2esurface_2eifE(V v_sp_240, V v_c_241, V v_a_242, V v_b_243);
V g_heff_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esurface_2eifE_clo;
V g_heff_2esurface_2eletHeadL(V v_r_240, V v_p_241, V v_ann0_242, V v_e_243);
V g_heff_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eletHeadL_clo;
V g_heff_2esurface_2eletBodyL(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244);
V g_heff_2esurface_2eletBodyL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eletBodyL_clo;
V g_heff_2esurface_2eletL(V v_r_240, V v_e_241);
V g_heff_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eletL_clo;
V g_heff_2esurface_2estmtL(V v_r_240, V v_e_241);
V g_heff_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esurface_2estmtL_clo;
V g_heff_2esurface_2eparenL(V v_r_240, V v_o_241, V v_e_242, V v_c_243);
V g_heff_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eparenL_clo;
V g_prelude_2efoldl_24s245(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s245_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s245_clo;
V g_heff_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243);
V g_heff_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eopL_clo;
V g_heff_2esurface_2eargL(V v_r_240, V v_e_241);
V g_heff_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eargL_clo;
V g_heff_2esurface_2epushS_24s248(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243);
V g_heff_2esurface_2epushS_24s248_entry(V self, V *a);
extern Clo g_heff_2esurface_2epushS_24s248_clo;
V g_heff_2esurface_2epushAll_24s247(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243);
V g_heff_2esurface_2epushAll_24s247_entry(V self, V *a);
extern Clo g_heff_2esurface_2epushAll_24s247_clo;
V g_heff_2esurface_2ereduceAll_24s249(V v_st_240);
V g_heff_2esurface_2ereduceAll_24s249_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereduceAll_24s249_clo;
V g_heff_2esurface_2eresolve_24s246(V v_e0_240, V v_rest_241, V v_st_242);
V g_heff_2esurface_2eresolve_24s246_entry(V self, V *a);
extern Clo g_heff_2esurface_2eresolve_24s246_clo;
V g_heff_2esurface_2eexprL(V v_r_240, V v_e0_241);
V g_heff_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eexprL_clo;
V g_heff_2esurface_2epchainOf(V v_p_240);
V g_heff_2esurface_2epchainOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2epchainOf_clo;
V g_heff_2esurface_2efieldPatL(V v_r_240, V v_p_241);
V g_heff_2esurface_2efieldPatL_entry(V self, V *a);
extern Clo g_heff_2esurface_2efieldPatL_clo;
V g_heff_2esurface_2epushS_24s252(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243);
V g_heff_2esurface_2epushS_24s252_entry(V self, V *a);
extern Clo g_heff_2esurface_2epushS_24s252_clo;
V g_heff_2esurface_2epushAll_24s251(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243);
V g_heff_2esurface_2epushAll_24s251_entry(V self, V *a);
extern Clo g_heff_2esurface_2epushAll_24s251_clo;
V g_heff_2esurface_2ereduceAll_24s253(V v_st_240);
V g_heff_2esurface_2ereduceAll_24s253_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereduceAll_24s253_clo;
V g_heff_2esurface_2eresolve_24s250(V v_e0_240, V v_rest_241, V v_st_242);
V g_heff_2esurface_2eresolve_24s250_entry(V self, V *a);
extern Clo g_heff_2esurface_2eresolve_24s250_clo;
V g_heff_2esurface_2epatL(V v_r_240, V v_p0_241);
V g_heff_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esurface_2epatL_clo;
V g_heff_2esurface_2edeclNameOf(V v_x1_240);
V g_heff_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2edeclNameOf_clo;
V g_heff_2esurface_2esigL(V v_r_240, V v_names_241, V v_ty_242);
V g_heff_2esurface_2esigL_entry(V self, V *a);
extern Clo g_heff_2esurface_2esigL_clo;
V g_heff_2esurface_2econcatMapS_24s254(V v_x2_240);
V g_heff_2esurface_2econcatMapS_24s254_entry(V self, V *a);
extern Clo g_heff_2esurface_2econcatMapS_24s254_clo;
V g_heff_2esurface_2ewhereL(V v_r_240, V v_kw_241, V v_ds_242, V v_rhs_243, V v_st_244);
V g_heff_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esurface_2ewhereL_clo;
V g_heff_2esurface_2econcatMapS_24s255(V v_x2_240);
V g_heff_2esurface_2econcatMapS_24s255_entry(V self, V *a);
extern Clo g_heff_2esurface_2econcatMapS_24s255_clo;
V g_heff_2esurface_2econcatMapS_24s256(V v_x2_240);
V g_heff_2esurface_2econcatMapS_24s256_entry(V self, V *a);
extern Clo g_heff_2esurface_2econcatMapS_24s256_clo;
V g_heff_2esurface_2eeqnL(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245);
V g_heff_2esurface_2eeqnL_entry(V self, V *a);
extern Clo g_heff_2esurface_2eeqnL_clo;
V g_heff_2esurface_2enameAnn(V v_x1_240);
V g_heff_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esurface_2enameAnn_clo;
V g_heff_2esurface_2eparamOf(V v_p_240);
V g_heff_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eparamOf_clo;
V g_heff_2esurface_2edataParamOf(V v_r_240, V v_e_241);
V g_heff_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataParamOf_clo;
V g_heff_2esurface_2edataParamL(V v_r_240, V v_e_241);
V g_heff_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataParamL_clo;
V g_prelude_2emap_24s257(V v_x2_240);
V g_prelude_2emap_24s257_entry(V self, V *a);
extern Clo g_prelude_2emap_24s257_clo;
V g_heff_2esurface_2edataL(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_universe_245, V v_alts_246);
V g_heff_2esurface_2edataL_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataL_clo;
V g_heff_2esurface_2etypeL(V v_r_240, V v_kw_241, V v_name_242, V v_params_243, V v_body_244);
V g_heff_2esurface_2etypeL_entry(V self, V *a);
extern Clo g_heff_2esurface_2etypeL_clo;
V g_heff_2esurface_2etheoryFieldL(V v_r_240, V v_x2_241);
V g_heff_2esurface_2etheoryFieldL_entry(V self, V *a);
extern Clo g_heff_2esurface_2etheoryFieldL_clo;
V g_heff_2esurface_2etheoryL(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_fields_245);
V g_heff_2esurface_2etheoryL_entry(V self, V *a);
extern Clo g_heff_2esurface_2etheoryL_clo;
V g_heff_2esurface_2edeclL(V v_r_240, V v_d_241);
V g_heff_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esurface_2edeclL_clo;
V g_heff_2esurface_2elw_get(void);
V g_heff_2esurface_2eprescanGo(V v_ts_240, V v_k_241, V v_acc_242);
V g_heff_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esurface_2eprescanGo_clo;
V g_heff_2esurface_2erestOfDecl(V v_ts_240, V v_j_241, V v_acc_242);
V g_heff_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esurface_2erestOfDecl_clo;
V g_heff_2esurface_2etakeSyms(V v_x1_240);
V g_heff_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esurface_2etakeSyms_clo;
V g_heff_2esurface_2edropN(V v_n_240, V v_x2_241);
V g_heff_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esurface_2edropN_clo;
V g_heff_2esurface_2eabGo(V v_acc_240, V v_x2_241);
V g_heff_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esurface_2eabGo_clo;
V g_heff_2esurface_2elastEnd(V v_t_240, V v_x2_241);
V g_heff_2esurface_2elastEnd_entry(V self, V *a);
extern Clo g_heff_2esurface_2elastEnd_clo;
V g_heff_2esurface_2efixDeclDone(V v_t_240, V v_rest_241, V v_ops_242, V v_r_243);
V g_heff_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDeclDone_clo;
V g_heff_2esurface_2efixDeclOf(V v_ts_240, V v_k_241, V v_t_242);
V g_heff_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDeclOf_clo;
V g_heff_2esurface_2efixDeclAt(V v_ts_240, V v_k_241, V v_t_242);
V g_heff_2esurface_2efixDeclAt_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDeclAt_clo;
V g_heff_2esurface_2efixDecls(V v_ts_240, V v_k_241, V v_acc_242);
V g_heff_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDecls_clo;
V g_prelude_2emap_24s258(V v_x2_240);
V g_prelude_2emap_24s258_entry(V self, V *a);
extern Clo g_prelude_2emap_24s258_clo;
V g_heff_2esurface_2eedgesOf(V v_scope_240, V v_d_241);
V g_heff_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eedgesOf_clo;
V g_heff_2esurface_2eanyS(V v_p_240, V v_x2_241);
V g_heff_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esurface_2eanyS_clo;
V g_prelude_2emap_24s259(V v_x2_240);
V g_prelude_2emap_24s259_entry(V self, V *a);
extern Clo g_prelude_2emap_24s259_clo;
V g_heff_2esurface_2ecycleDiag(V v_all_240, V v_d_241);
V g_heff_2esurface_2ecycleDiag_entry(V self, V *a);
extern Clo g_heff_2esurface_2ecycleDiag_clo;
V g_prelude_2emap_24s260(V v_x2_240);
V g_prelude_2emap_24s260_entry(V self, V *a);
extern Clo g_prelude_2emap_24s260_clo;
V g_prelude_2efilter_24s261(V v_x2_240);
V g_prelude_2efilter_24s261_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s261_clo;
V g_prelude_2emap_24s262(V v_x2_240);
V g_prelude_2emap_24s262_entry(V self, V *a);
extern Clo g_prelude_2emap_24s262_clo;
V g_heff_2esurface_2efixDiagsOf(V v_scope_240, V v_all_241, V v_d_242);
V g_heff_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixDiagsOf_clo;
V g_heff_2esurface_2efixityOut(V v_imported_240, V v_decls_241, V v_groups_242, V v_edges_243);
V g_heff_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixityOut_clo;
V g_prelude_2emap_24s263(V v_x2_240);
V g_prelude_2emap_24s263_entry(V self, V *a);
extern Clo g_prelude_2emap_24s263_clo;
V g_prelude_2efilter_24s264(V v_x2_240);
V g_prelude_2efilter_24s264_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s264_clo;
V g_heff_2esurface_2efixityFrom(V v_imported_240, V v_decls_241);
V g_heff_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixityFrom_clo;
V g_heff_2esurface_2eappendRev(V v_x1_240, V v_acc_241);
V g_heff_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esurface_2eappendRev_clo;
V g_heff_2esurface_2esigL_24s266(V v_names_240, V v_ty_241, V v_st_242);
V g_heff_2esurface_2esigL_24s266_entry(V self, V *a);
extern Clo g_heff_2esurface_2esigL_24s266_clo;
V g_heff_2esurface_2ewhereL_24s268(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243);
V g_heff_2esurface_2ewhereL_24s268_entry(V self, V *a);
extern Clo g_heff_2esurface_2ewhereL_24s268_clo;
V g_heff_2esurface_2eeqnL_24s267(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244);
V g_heff_2esurface_2eeqnL_24s267_entry(V self, V *a);
extern Clo g_heff_2esurface_2eeqnL_24s267_clo;
V g_heff_2esurface_2edeclarationL_24s272(V v_e_240, V v_st_241);
V g_heff_2esurface_2edeclarationL_24s272_entry(V self, V *a);
extern Clo g_heff_2esurface_2edeclarationL_24s272_clo;
V g_heff_2esurface_2edataParamOf_24s271(V v_e_240);
V g_heff_2esurface_2edataParamOf_24s271_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataParamOf_24s271_clo;
V g_heff_2esurface_2edataParamL_24s270(V v_e_240);
V g_heff_2esurface_2edataParamL_24s270_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataParamL_24s270_clo;
V g_heff_2esurface_2etraverseS_24s273(V v_x2_240);
V g_heff_2esurface_2etraverseS_24s273_entry(V self, V *a);
extern Clo g_heff_2esurface_2etraverseS_24s273_clo;
V g_heff_2esurface_2econL_24s275(V v_c_240, V v_args_241);
V g_heff_2esurface_2econL_24s275_entry(V self, V *a);
extern Clo g_heff_2esurface_2econL_24s275_clo;
V g_heff_2esurface_2evariantL_24s274(V v_e_240);
V g_heff_2esurface_2evariantL_24s274_entry(V self, V *a);
extern Clo g_heff_2esurface_2evariantL_24s274_clo;
V g_heff_2esurface_2etraverseS_24s276(V v_x2_240);
V g_heff_2esurface_2etraverseS_24s276_entry(V self, V *a);
extern Clo g_heff_2esurface_2etraverseS_24s276_clo;
V g_heff_2esurface_2edataL_24s269(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245);
V g_heff_2esurface_2edataL_24s269_entry(V self, V *a);
extern Clo g_heff_2esurface_2edataL_24s269_clo;
V g_heff_2esurface_2etypeL_24s277(V v_kw_240, V v_name_241, V v_params_242, V v_body_243);
V g_heff_2esurface_2etypeL_24s277_entry(V self, V *a);
extern Clo g_heff_2esurface_2etypeL_24s277_clo;
V g_heff_2esurface_2etheoryFieldL_24s279(V v_x2_240, V v_p_241);
V g_heff_2esurface_2etheoryFieldL_24s279_entry(V self, V *a);
extern Clo g_heff_2esurface_2etheoryFieldL_24s279_clo;
V g_heff_2esurface_2etraverseS_24s281(V v_x2_240, V v_p_241);
V g_heff_2esurface_2etraverseS_24s281_entry(V self, V *a);
extern Clo g_heff_2esurface_2etraverseS_24s281_clo;
V g_heff_2esurface_2eblock_24s280(V v_xs_240, V v_st_241);
V g_heff_2esurface_2eblock_24s280_entry(V self, V *a);
extern Clo g_heff_2esurface_2eblock_24s280_clo;
V g_heff_2esurface_2etheoryL_24s278(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244);
V g_heff_2esurface_2etheoryL_24s278_entry(V self, V *a);
extern Clo g_heff_2esurface_2etheoryL_24s278_clo;
V g_heff_2esurface_2edeclL_24s265(V v_d_240);
V g_heff_2esurface_2edeclL_24s265_entry(V self, V *a);
extern Clo g_heff_2esurface_2edeclL_24s265_clo;
V g_heff_2esurface_2eprogGo(V v_cs_240, V v_s_241, V v_items_242, V v_diags_243, V v_broken_244);
V g_heff_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esurface_2eprogGo_clo;
V g_heff_2esurface_2einitialSt(V v_o_240, V v_toks_241, V v_declared_242, V v_own_243);
V g_heff_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esurface_2einitialSt_clo;
V g_heff_2esurface_2ereadOut(V v_lexDiags_240, V v_own_241, V v_r_242);
V g_heff_2esurface_2ereadOut_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadOut_clo;
V g_heff_2esurface_2ereadToks(V v_o_240, V v_ltoks_241, V v_toks_242, V v_lexDiags_243);
V g_heff_2esurface_2ereadToks_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadToks_clo;
V g_prelude_2emap_24s282(V v_x2_240);
V g_prelude_2emap_24s282_entry(V self, V *a);
extern Clo g_prelude_2emap_24s282_clo;
V g_heff_2esurface_2ereadProgramWith(V v_o_240, V v_src_241);
V g_heff_2esurface_2ereadProgramWith_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadProgramWith_clo;
V g_heff_2etop_2evalueOf(V v_g_240, V v_k_241, V v_tyStx_242, V v_bodyStx_243);
V g_heff_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2etop_2evalueOf_clo;
V g_heff_2eclauses_2eappendC(V v_x1_240, V v_ys_241);
V g_heff_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eappendC_clo;
V g_heff_2eclauses_2econcatMapC(V v_f_240, V v_x2_241);
V g_heff_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_clo;
V g_heff_2eclauses_2ecatMaybesC(V v_x1_240);
V g_heff_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecatMaybesC_clo;
V g_heff_2eclauses_2etraverseC(V v_f_240, V v_x2_241);
V g_heff_2eclauses_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_clo;
V g_heff_2eclauses_2eforC(V v_x1_240, V v_f_241);
V g_heff_2eclauses_2eforC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eforC_clo;
V g_heff_2eclauses_2enthC(V v_x1_240, V v_i_241);
V g_heff_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2enthC_clo;
V g_heff_2eclauses_2ezipC(V v_x1_240, V v_x2_241);
V g_heff_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ezipC_clo;
V g_heff_2eclauses_2eanyC(V v_p_240, V v_x2_241);
V g_heff_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eanyC_clo;
V g_heff_2eclauses_2eallC(V v_p_240, V v_x2_241);
V g_heff_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eallC_clo;
V g_heff_2eclauses_2enubStr(V v_x1_240);
V g_heff_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eclauses_2enubStr_clo;
V g_heff_2eclauses_2eupToGo(V v_i_240, V v_n_241);
V g_heff_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eupToGo_clo;
V g_heff_2eclauses_2edropAt(V v_i_240, V v_x2_241);
V g_heff_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edropAt_clo;
V g_heff_2eclauses_2etakeC(V v_n_240, V v_x2_241);
V g_heff_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etakeC_clo;
V g_heff_2eclauses_2edropC(V v_n_240, V v_x2_241);
V g_heff_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edropC_clo;
V g_heff_2eclauses_2etraverseC_24s283(V v_x2_240);
V g_heff_2eclauses_2etraverseC_24s283_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_24s283_clo;
V g_heff_2eclauses_2etraverseC_24s284(V v_x2_240);
V g_heff_2eclauses_2etraverseC_24s284_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_24s284_clo;
V g_heff_2eclauses_2epat(V v_p_240);
V g_heff_2eclauses_2epat_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epat_clo;
V g_heff_2eclauses_2esameLit(V v_x1_240, V v_x2_241);
V g_heff_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eclauses_2esameLit_clo;
V g_heff_2eclauses_2elitExpr(V v_x1_240);
V g_heff_2eclauses_2elitExpr_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitExpr_clo;
V g_heff_2eclauses_2etraverseC_24s285(V v_x2_240);
V g_heff_2eclauses_2etraverseC_24s285_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_24s285_clo;
V g_heff_2eclauses_2econcatMapC_24s286(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s286_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s286_clo;
V g_heff_2eclauses_2econcatMapC_24s287(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s287_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s287_clo;
V g_heff_2eclauses_2epatVars(V v_x1_240);
V g_heff_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epatVars_clo;
V g_heff_2eclauses_2econcatMapC_24s288(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s288_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s288_clo;
V g_heff_2eclauses_2econcatMapC_24s289(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s289_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s289_clo;
V g_heff_2eclauses_2epatIdents(V v_p_240);
V g_heff_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epatIdents_clo;
V g_heff_2eclauses_2econcatMapC_24s290(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s290_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s290_clo;
V g_heff_2eclauses_2eidentsInfF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2eidentsInfF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsInfF_clo;
V g_heff_2eclauses_2eidentsChkF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsChkF_clo;
V g_heff_2eclauses_2eidentsTypF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsTypF_clo;
V g_heff_2eclauses_2eidentsDeclF(V v_r_240, V v_d_241);
V g_heff_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsDeclF_clo;
V g_heff_2eclauses_2eidents_get(void);
V g_heff_2eclauses_2econcatMapC_24s292(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s292_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s292_clo;
V g_heff_2eclauses_2econcatMapC_24s293(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s293_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s293_clo;
V g_heff_2eclauses_2econcatMapC_24s295(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s295_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s295_clo;
V g_heff_2eclauses_2econcatMapC_24s297(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s297_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s297_clo;
V g_heff_2eclauses_2econcatMapC_24s298(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s298_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s298_clo;
V g_heff_2eclauses_2eidentsTypF_24s296(V v_n_240);
V g_heff_2eclauses_2eidentsTypF_24s296_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsTypF_24s296_clo;
V g_heff_2eclauses_2eidentsInfF_24s294(V v_n_240);
V g_heff_2eclauses_2eidentsInfF_24s294_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsInfF_24s294_clo;
V g_heff_2eclauses_2eidentsChkF_24s291(V v_n_240);
V g_heff_2eclauses_2eidentsChkF_24s291_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eidentsChkF_24s291_clo;
V g_heff_2eclauses_2efresh(V v_used_240, V v_x_241);
V g_heff_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eclauses_2efresh_clo;
V g_heff_2eclauses_2econcatMapC_24s299(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s299_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s299_clo;
V g_heff_2eclauses_2econcatMapC_24s300(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s300_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s300_clo;
V g_heff_2eclauses_2epatBinds(V v_p_240);
V g_heff_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epatBinds_clo;
V g_heff_2eclauses_2erenameSeq(V v_f_240, V v_b_241, V v_x3_242);
V g_heff_2eclauses_2erenameSeq_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameSeq_clo;
V g_heff_2eclauses_2erenameAlt(V v_r_240, V v_x2_241);
V g_heff_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameAlt_clo;
V g_heff_2eclauses_2erenameEquation(V v_r_240, V v_x2_241);
V g_heff_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameEquation_clo;
V g_heff_2eclauses_2erenameDecl(V v_r_240, V v_d_241);
V g_heff_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameDecl_clo;
V g_heff_2eclauses_2erenamePi(V v_r_240, V v_x2_241);
V g_heff_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenamePi_clo;
V g_heff_2eclauses_2erenameInfF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameInfF_clo;
V g_heff_2eclauses_2erenameChkF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2erenameChkF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameChkF_clo;
V g_heff_2eclauses_2erenameTypF(V v_r_240, V v_n_241);
V g_heff_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenameTypF_clo;
V g_heff_2eclauses_2erenamer(V v_x_240, V v_v_241);
V g_heff_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenamer_clo;
V g_heff_2eclauses_2efindTagLit(V v_x1_240, V v_i_241);
V g_heff_2eclauses_2efindTagLit_entry(V self, V *a);
extern Clo g_heff_2eclauses_2efindTagLit_clo;
V g_heff_2eclauses_2enubTagRows(V v_x1_240);
V g_heff_2eclauses_2enubTagRows_entry(V self, V *a);
extern Clo g_heff_2eclauses_2enubTagRows_clo;
V g_heff_2eclauses_2earmSubName(V v_used_240, V v_bound_241, V v_v_242, V v_i_243, V v_x5_244);
V g_heff_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eclauses_2earmSubName_clo;
V g_heff_2eclauses_2earmSub(V v_used_240, V v_bound_241, V v_t_242, V v_v_243, V v_i_244);
V g_heff_2eclauses_2earmSub_entry(V self, V *a);
extern Clo g_heff_2eclauses_2earmSub_clo;
V g_heff_2eclauses_2ebadArity(V v_c_240, V v_t_241, V v_row_242);
V g_heff_2eclauses_2ebadArity_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ebadArity_clo;
V g_prelude_2emap_24s301(V v_x2_240);
V g_prelude_2emap_24s301_entry(V self, V *a);
extern Clo g_prelude_2emap_24s301_clo;
V g_heff_2eclauses_2earmSpecializeV(V v_c_240, V v_t_241, V v_ys_242, V v_v_243, V v_r_244);
V g_heff_2eclauses_2earmSpecializeV_entry(V self, V *a);
extern Clo g_heff_2eclauses_2earmSpecializeV_clo;
V g_heff_2eclauses_2elitYesOne(V v_c_240, V v_l_241, V v_v_242, V v_r_243, V v_acc_244);
V g_heff_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitYesOne_clo;
V g_heff_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243);
V g_heff_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitYes_clo;
V g_heff_2eclauses_2elitNoOne(V v_c_240, V v_l_241, V v_r_242, V v_acc_243);
V g_heff_2eclauses_2elitNoOne_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitNoOne_clo;
V g_heff_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242);
V g_heff_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitNo_clo;
V g_heff_2eclauses_2elitChecks(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244);
V g_heff_2eclauses_2elitChecks_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elitChecks_clo;
V g_heff_2eclauses_2enoLitHere(V v_sp_240, V v_c_241, V v_rows_242);
V g_heff_2eclauses_2enoLitHere_entry(V self, V *a);
extern Clo g_heff_2eclauses_2enoLitHere_clo;
V g_heff_2eclauses_2elookupField(V v_f_240, V v_x2_241);
V g_heff_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eclauses_2elookupField_clo;
V g_heff_2eclauses_2enoRecMix(V v_rows_240, V v_c_241);
V g_heff_2eclauses_2enoRecMix_entry(V self, V *a);
extern Clo g_heff_2eclauses_2enoRecMix_clo;
V g_heff_2eclauses_2erecFieldVar(V v_c_240, V v_rows_241, V v_f_242);
V g_heff_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erecFieldVar_clo;
V g_heff_2eclauses_2erecSubName(V v_used_240, V v_bound_241, V v_x3_242, V v_f_243);
V g_heff_2eclauses_2erecSubName_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erecSubName_clo;
V g_heff_2eclauses_2erecSubs(V v_used_240, V v_bound_241, V v_c_242, V v_rows_243);
V g_heff_2eclauses_2erecSubs_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erecSubs_clo;
V g_heff_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243);
V g_heff_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erecSpecialize_clo;
V g_heff_2eclauses_2eletFields(V v_sp_240, V v_v_241, V v_x3_242, V v_body_243);
V g_heff_2eclauses_2eletFields_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eletFields_clo;
V g_heff_2eclauses_2epeelAs(V v_v_240, V v_p_241, V v_e_242);
V g_heff_2eclauses_2epeelAs_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epeelAs_clo;
V g_heff_2eclauses_2epeelCols(V v_x1_240, V v_ps_241, V v_e_242);
V g_heff_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eclauses_2epeelCols_clo;
V g_prelude_2efoldl_24s302(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s302_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s302_clo;
V g_heff_2eclauses_2ecolPick(V v_used_240, V v_i_241, V v_xs_242);
V g_heff_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecolPick_clo;
V g_heff_2eclauses_2ecolName(V v_used_240, V v_params_241, V v_rows_242, V v_i_243);
V g_heff_2eclauses_2ecolName_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecolName_clo;
V g_heff_2eclauses_2efoldr2(V v_f_240, V v_z_241, V v_x3_242);
V g_heff_2eclauses_2efoldr2_entry(V self, V *a);
extern Clo g_heff_2eclauses_2efoldr2_clo;
V g_heff_2eclauses_2earmOf_24s305(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_v_246, V v_t_247);
V g_heff_2eclauses_2earmOf_24s305_entry(V self, V *a);
extern Clo g_heff_2eclauses_2earmOf_24s305_clo;
V g_heff_2eclauses_2edefaultOf_24s307(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246);
V g_heff_2eclauses_2edefaultOf_24s307_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edefaultOf_24s307_clo;
V g_heff_2eclauses_2edefaultArm_24s306(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245);
V g_heff_2eclauses_2edefaultArm_24s306_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edefaultArm_24s306_clo;
V g_heff_2eclauses_2eliteralOf_24s308(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246);
V g_heff_2eclauses_2eliteralOf_24s308_entry(V self, V *a);
extern Clo g_heff_2eclauses_2eliteralOf_24s308_clo;
V g_heff_2eclauses_2erecordOf_24s309(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245);
V g_heff_2eclauses_2erecordOf_24s309_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erecordOf_24s309_clo;
V g_heff_2eclauses_2ecompileAt_24s304(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_p_246);
V g_heff_2eclauses_2ecompileAt_24s304_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecompileAt_24s304_clo;
V g_heff_2eclauses_2ecompilePeeled_24s303(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244);
V g_heff_2eclauses_2ecompilePeeled_24s303_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecompilePeeled_24s303_clo;
V g_heff_2eclauses_2edesugarBody(V v_f_240, V v_params_241, V v_sp_242, V v_rows_243, V v_arity_244, V v_used_245);
V g_heff_2eclauses_2edesugarBody_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edesugarBody_clo;
V g_heff_2eclauses_2etraverseC_24s310(V v_x2_240);
V g_heff_2eclauses_2etraverseC_24s310_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_24s310_clo;
V g_heff_2eclauses_2econcatMapC_24s311(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s311_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s311_clo;
V g_heff_2eclauses_2econcatMapC_24s312(V v_x2_240);
V g_heff_2eclauses_2econcatMapC_24s312_entry(V self, V *a);
extern Clo g_heff_2eclauses_2econcatMapC_24s312_clo;
V g_heff_2eclauses_2edesugar(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243);
V g_heff_2eclauses_2edesugar_entry(V self, V *a);
extern Clo g_heff_2eclauses_2edesugar_clo;
V g_heff_2eclauses_2ecaseTreeOf(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243);
V g_heff_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eclauses_2etraverseC_24s313(V v_x2_240);
V g_heff_2eclauses_2etraverseC_24s313_entry(V self, V *a);
extern Clo g_heff_2eclauses_2etraverseC_24s313_clo;
V g_heff_2econversion_2eeqHead(V v_x1_240, V v_x2_241);
V g_heff_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2econversion_2eeqHead_clo;
V g_heff_2econversion_2ecanon(V v_v_240);
V g_heff_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2econversion_2ecanon_clo;
V g_heff_2ememoed_2ecode(V v_g_240);
V g_heff_2ememoed_2ecode_entry(V self, V *a);
extern Clo g_heff_2ememoed_2ecode_clo;
V g_heff_2ememoed_2eapp(V v_g0_240, V v_g1_241);
V g_heff_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eapp_clo;
V g_heff_2ememoed_2eiapp(V v_x_240, V v_g0_241, V v_g1_242);
V g_heff_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eiapp_clo;
V g_heff_2ememoed_2elam(V v_c_240, V v_g_241, V v_vs_242, V v_gdom_243, V v_x5_244);
V g_heff_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2ememoed_2elam_clo;
V g_heff_2ememoed_2econs(V v_c_240, V v_d_241);
V g_heff_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2ememoed_2econs_clo;
V g_heff_2ememoed_2eproj(V v_g_240, V v_x_241);
V g_heff_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eproj_clo;
V g_heff_2ememoed_2eprojAt(V v_g_240, V v_x_241, V v_a_242);
V g_heff_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eprojAt_clo;
V g_heff_2ememoed_2especializeM(V v_g_240, V v_x_241, V v_g_27_242);
V g_heff_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2especializeM_clo;
V g_heff_2ememoed_2eabandonM_get(void);
V g_heff_2ememoed_2edecode(V v_g_240);
V g_heff_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2ememoed_2edecode_clo;
V g_heff_2ememoed_2efunctionI(V v_implicit_240, V v_g_241, V v_vs_242, V v_dom_243, V v_x5_244);
V g_heff_2ememoed_2efunctionI_entry(V self, V *a);
extern Clo g_heff_2ememoed_2efunctionI_clo;
V g_heff_2ememoed_2erecordM(V v_g_240, V v_vs_241, V v_level_242, V v_fieldTypes_243);
V g_heff_2ememoed_2erecordM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2erecordM_clo;
V g_heff_2eparams_2evariantsMap_24s314(V v_vs_240);
V g_heff_2eparams_2evariantsMap_24s314_entry(V self, V *a);
extern Clo g_heff_2eparams_2evariantsMap_24s314_clo;
V g_heff_2ememoed_2esumM(V v_st_240);
V g_heff_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2esumM_clo;
V g_heff_2ememoed_2eprimInt_get(void);
V g_heff_2ememoed_2eprimFloat_get(void);
V g_heff_2ememoed_2eprimString_get(void);
V g_heff_2eunify_2euModify(V v_w_240, V v_ms_241, V v_uf_242, V v_f_243);
V g_heff_2eunify_2euModify_entry(V self, V *a);
extern Clo g_heff_2eunify_2euModify_clo;
V g_heff_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241);
V g_heff_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eunify_2eeqPatArgs_clo;
V g_heff_2eunify_2epatVarsOf(V v_x1_240);
V g_heff_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatVarsOf_clo;
V g_heff_2eunify_2edistinct(V v_x1_240);
V g_heff_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eunify_2edistinct_clo;
V g_heff_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242);
V g_heff_2eunify_2epatStep_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatStep_clo;
V g_heff_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242);
V g_heff_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatSpine_clo;
V g_heff_2eunify_2enth(V v_x1_240, V v_i_241);
V g_heff_2eunify_2enth_entry(V self, V *a);
extern Clo g_heff_2eunify_2enth_clo;
V g_heff_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242);
V g_heff_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_clo;
V g_heff_2eunify_2ezipL(V v_x1_240, V v_x2_241);
V g_heff_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezipL_clo;
V g_heff_2eunify_2ecatMaybes(V v_x1_240);
V g_heff_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eunify_2ecatMaybes_clo;
V g_heff_2eunify_2eanyL(V v_p_240, V v_x2_241);
V g_heff_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eunify_2eanyL_clo;
V g_heff_2eunify_2eappendL(V v_x1_240, V v_ys_241);
V g_heff_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eunify_2eappendL_clo;
V g_heff_2eunify_2econcatMapL(V v_f_240, V v_x2_241);
V g_heff_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eunify_2econcatMapL_clo;
V g_heff_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244);
V g_heff_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eunify_2eforU_clo;
V g_heff_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244);
V g_heff_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasTermF_clo;
V g_heff_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244);
V g_heff_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasTypeF_clo;
V g_heff_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244);
V g_heff_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasSpF_clo;
V g_heff_2eunify_2emetasK(V v_mc_240);
V g_heff_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasK_clo;
V g_prelude_2efoldl_24s315(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s315_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s315_clo;
V g_heff_2eunify_2epoisonEl(V v_w_240, V v_ms_241, V v_uf_242, V v_len_243, V v_v_244);
V g_heff_2eunify_2epoisonEl_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonEl_clo;
V g_heff_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243);
V g_heff_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTermF_clo;
V g_heff_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243);
V g_heff_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTyFields_clo;
V g_heff_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243);
V g_heff_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTypeF_clo;
V g_heff_2eunify_2esubstOf(V v_idxs_240);
V g_heff_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstOf_clo;
V g_heff_2eunify_2estripLams(V v_n_240, V v_t_241);
V g_heff_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eunify_2estripLams_clo;
V g_heff_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242);
V g_heff_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonkTermF_clo;
V g_heff_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242);
V g_heff_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonkTypeF_clo;
V g_heff_2eunify_2ezonker(V v_mc_240);
V g_heff_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonker_clo;
V g_heff_2eunify_2eiterateLift(V v_i_240, V v_rr_241);
V g_heff_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eunify_2eiterateLift_clo;
V g_heff_2eunify_2elamsU(V v_k_240, V v_body_241);
V g_heff_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eunify_2elamsU_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s319(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s319_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s319_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s318(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s318_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s318_clo;
V g_prelude_2efoldl_24s321(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s321_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s321_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s320(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s320_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s320_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s322(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s322_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s322_clo;
V g_heff_2epsurface_2etyF_24s96_24s317(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s317_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s317_clo;
V g_heff_2epsurface_2eopApp_24s324(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s324_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s324_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s326(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s326_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s326_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s325(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s325_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s325_clo;
V g_heff_2epsurface_2eappStr_24s91_24s323(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s323_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s323_clo;
V g_heff_2epsurface_2elamStr_24s94_24s327(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s327_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s327_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s332(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s332_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s332_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s331(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s331_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s331_clo;
V g_prelude_2efoldl_24s334(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s334_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s334_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s333(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s333_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s333_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s335(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s335_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s335_clo;
V g_heff_2epsurface_2etyF_24s96_24s330(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s330_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s330_clo;
V g_heff_2epsurface_2eopApp_24s337(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s337_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s337_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s339(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s339_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s339_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s338(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s338_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s338_clo;
V g_heff_2epsurface_2eappStr_24s91_24s336(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s336_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s336_clo;
V g_heff_2epsurface_2elamStr_24s94_24s340(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s340_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s340_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s345(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s345_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s345_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s344(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s344_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s344_clo;
V g_prelude_2efoldl_24s347(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s347_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s347_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s346(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s346_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s346_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s348(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s348_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s348_clo;
V g_heff_2epsurface_2etyF_24s96_24s343(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s343_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s343_clo;
V g_heff_2epsurface_2eopApp_24s350(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s350_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s350_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s352(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s352_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s352_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s351(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s351_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s351_clo;
V g_heff_2epsurface_2eappStr_24s91_24s349(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s349_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s349_clo;
V g_heff_2epsurface_2elamStr_24s94_24s353(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s353_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s353_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s358(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s358_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s358_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s357(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s357_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s357_clo;
V g_prelude_2efoldl_24s360(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s360_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s360_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s359(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s359_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s359_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s361(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s361_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s361_clo;
V g_heff_2epsurface_2etyF_24s96_24s356(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s356_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s356_clo;
V g_heff_2epsurface_2eopApp_24s363(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s363_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s363_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s365(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s365_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s365_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s364(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s364_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s364_clo;
V g_heff_2epsurface_2eappStr_24s91_24s362(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s362_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s362_clo;
V g_heff_2epsurface_2elamStr_24s94_24s366(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s366_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s366_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s371(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s371_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s371_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s370(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s370_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s370_clo;
V g_prelude_2efoldl_24s373(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s373_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s373_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s372(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s372_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s372_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s374(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s374_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s374_clo;
V g_heff_2epsurface_2etyF_24s96_24s369(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s369_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s369_clo;
V g_heff_2epsurface_2eopApp_24s376(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s376_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s376_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s378(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s378_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s378_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s377(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s377_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s377_clo;
V g_heff_2epsurface_2eappStr_24s91_24s375(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s375_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s375_clo;
V g_heff_2epsurface_2elamStr_24s94_24s379(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s379_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s379_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s384(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s384_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s384_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s383(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s383_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s383_clo;
V g_prelude_2efoldl_24s386(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s386_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s386_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s385(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s385_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s385_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s387(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s387_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s387_clo;
V g_heff_2epsurface_2etyF_24s96_24s382(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s382_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s382_clo;
V g_heff_2epsurface_2eopApp_24s389(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s389_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s389_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s391(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s391_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s391_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s390(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s390_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s390_clo;
V g_heff_2epsurface_2eappStr_24s91_24s388(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s388_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s388_clo;
V g_heff_2epsurface_2elamStr_24s94_24s392(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s392_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s392_clo;
V g_heff_2epsurface_2earrowGrouped_24s98_24s397(V v_xs_240, V v_dom_241, V v_r_242);
V g_heff_2epsurface_2earrowGrouped_24s98_24s397_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s98_24s397_clo;
V g_heff_2epsurface_2earrowStr_24s97_24s396(V v_xs_240, V v_level_241, V v_dom_242, V v_cod_243, V v_implicit_244);
V g_heff_2epsurface_2earrowStr_24s97_24s396_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s97_24s396_clo;
V g_prelude_2efoldl_24s399(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s399_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s399_clo;
V g_heff_2epsurface_2erecordFields_24s99_24s398(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s99_24s398_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s99_24s398_clo;
V g_heff_2epsurface_2evariantStr_24s100_24s400(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s100_24s400_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s100_24s400_clo;
V g_heff_2epsurface_2etyF_24s96_24s395(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s395_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s395_clo;
V g_heff_2epsurface_2eopApp_24s402(V v_xs_240, V v_sp_241);
V g_heff_2epsurface_2eopApp_24s402_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_24s402_clo;
V g_heff_2epsurface_2eargStrs_24s93_24s404(V v_xs_240, V v_names_241, V v_i_242, V v_x6_243);
V g_heff_2epsurface_2eargStrs_24s93_24s404_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s93_24s404_clo;
V g_heff_2epsurface_2eappPlain_24s92_24s403(V v_p_240, V v_xs_241, V v_sp_242);
V g_heff_2epsurface_2eappPlain_24s92_24s403_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s92_24s403_clo;
V g_heff_2epsurface_2eappStr_24s91_24s401(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s401_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s401_clo;
V g_heff_2epsurface_2elamStr_24s94_24s405(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s405_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s405_clo;
V g_heff_2epsurface_2etyF_24s96_24s408(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2etyF_24s96_24s408_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s96_24s408_clo;
V g_heff_2epsurface_2eappStr_24s91_24s409(V v_p_240, V v_xs_241, V v_t_242);
V g_heff_2epsurface_2eappStr_24s91_24s409_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s91_24s409_clo;
V g_heff_2epsurface_2elamStr_24s94_24s410(V v_p_240, V v_xs_241, V v_l_242);
V g_heff_2epsurface_2elamStr_24s94_24s410_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s94_24s410_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s411(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s411_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s411_clo;
V g_heff_2epsurface_2eelF_24s90_24s407(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s407_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s407_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s406(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s406_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s406_clo;
V g_heff_2epsurface_2eelF_24s90_24s394(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s394_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s394_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s393(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s393_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s393_clo;
V g_heff_2epsurface_2eelF_24s90_24s381(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s381_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s381_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s380(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s380_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s380_clo;
V g_heff_2epsurface_2eelF_24s90_24s368(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s368_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s368_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s367(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s367_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s367_clo;
V g_heff_2epsurface_2eelF_24s90_24s355(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s355_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s355_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s354(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s354_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s354_clo;
V g_heff_2epsurface_2eelF_24s90_24s342(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s342_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s342_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s341(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s341_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s341_clo;
V g_heff_2epsurface_2eelF_24s90_24s329(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s329_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s329_clo;
V g_heff_2epsurface_2ealtLine_24s95_24s328(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2ealtLine_24s95_24s328_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s95_24s328_clo;
V g_heff_2epsurface_2eelF_24s90_24s316(V v_p_240, V v_xs_241, V v_e_242);
V g_heff_2epsurface_2eelF_24s90_24s316_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s90_24s316_clo;
V g_heff_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243);
V g_heff_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eunify_2enewMetaIn_clo;
V g_heff_2eunify_2emapWithIndexL_24s412(V v_i_240, V v_x3_241);
V g_heff_2eunify_2emapWithIndexL_24s412_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_24s412_clo;
V g_map_2elookup_24s413(V v_k_240, V v_x3_241);
V g_map_2elookup_24s413_entry(V self, V *a);
extern Clo g_map_2elookup_24s413_clo;
V g_prelude_2efoldl_24s414(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s414_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s414_clo;
V g_heff_2eunify_2emapWithIndexL_24s415(V v_i_240, V v_x3_241);
V g_heff_2eunify_2emapWithIndexL_24s415_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_24s415_clo;
V g_heff_2eunify_2euTyRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a_246, V v_b_247);
V g_heff_2eunify_2euTyRigid_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTyRigid_clo;
V g_heff_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_ca_246, V v_cb_247, V v_a_248, V v_b_249);
V g_heff_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eunify_2euElRigid_clo;
V g_heff_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247);
V g_heff_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTermF_clo;
V g_heff_2eunify_2emsEv(V v_p_240);
V g_heff_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eunify_2emsEv_clo;
V g_heff_2eunify_2eufEv(V v_p_240);
V g_heff_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eunify_2eufEv_clo;
V g_heff_2eunify_2euAlg(V v_x1_240, V v_p_241);
V g_heff_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eunify_2euAlg_clo;
V g_heff_2eunify_2euH_get(void);
V g_heff_2emeta_2eliftU(V v_u_240, V v_hd_241, V v_k_242);
V g_heff_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2emeta_2eliftU_clo;
V g_heff_2eunify_2euModify_24s419(V v_f_240, V v_hd_241, V v_k_242);
V g_heff_2eunify_2euModify_24s419_entry(V self, V *a);
extern Clo g_heff_2eunify_2euModify_24s419_clo;
V g_heff_2eunify_2epoisonTy_24s418(V v_len_240, V v_t_241, V v_hd_242, V v_k_243);
V g_heff_2eunify_2epoisonTy_24s418_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonTy_24s418_clo;
V g_heff_2eunify_2estoreSol_24s422(V v_m_240, V v_sol_241, V v_stx_242);
V g_heff_2eunify_2estoreSol_24s422_entry(V self, V *a);
extern Clo g_heff_2eunify_2estoreSol_24s422_clo;
V g_heff_2eunify_2epoisonEl_24s423(V v_len_240, V v_v_241, V v_hd_242, V v_k_243);
V g_heff_2eunify_2epoisonEl_24s423_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonEl_24s423_clo;
V g_heff_2eunify_2etraceSolve_24s424(V v_m_240, V v_stx_241);
V g_heff_2eunify_2etraceSolve_24s424_entry(V self, V *a);
extern Clo g_heff_2eunify_2etraceSolve_24s424_clo;
V g_heff_2eunify_2erenameHead_24s426(V v_r_240, V v_x2_241);
V g_heff_2eunify_2erenameHead_24s426_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameHead_24s426_clo;
V g_heff_2eunify_2erenameSpine_24s427(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244);
V g_heff_2eunify_2erenameSpine_24s427_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameSpine_24s427_clo;
V g_heff_2eunify_2erenameEvF_24s429(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243);
V g_heff_2eunify_2erenameEvF_24s429_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameEvF_24s429_clo;
V g_heff_2eunify_2erenameClo_24s428(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244);
V g_heff_2eunify_2erenameClo_24s428_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameClo_24s428_clo;
V g_heff_2eunify_2etraverseU_24s430(V v_f_240, V v_x2_241);
V g_heff_2eunify_2etraverseU_24s430_entry(V self, V *a);
extern Clo g_heff_2eunify_2etraverseU_24s430_clo;
V g_heff_2eunify_2emetaEntry_24s432(V v_m_240, V v_hd_241, V v_k_242);
V g_heff_2eunify_2emetaEntry_24s432_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetaEntry_24s432_clo;
V g_heff_2eunify_2erenameEvTypeF_24s436(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243);
V g_heff_2eunify_2erenameEvTypeF_24s436_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameEvTypeF_24s436_clo;
V g_heff_2eunify_2erenameCloTy_24s435(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244);
V g_heff_2eunify_2erenameCloTy_24s435_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameCloTy_24s435_clo;
V g_heff_2eunify_2erenameRecordFields_24s437(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245);
V g_heff_2eunify_2erenameRecordFields_24s437_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameRecordFields_24s437_clo;
V g_heff_2eunify_2erenameTypeF_24s434(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245);
V g_heff_2eunify_2erenameTypeF_24s434_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameTypeF_24s434_clo;
V g_heff_2eunify_2esolveWithPruned_24s433(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247);
V g_heff_2eunify_2esolveWithPruned_24s433_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveWithPruned_24s433_clo;
V g_heff_2eunify_2erenameFlexF_24s431(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246);
V g_heff_2eunify_2erenameFlexF_24s431_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameFlexF_24s431_clo;
V g_heff_2eunify_2erenameF_24s425(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245);
V g_heff_2eunify_2erenameF_24s425_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameF_24s425_clo;
V g_heff_2eunify_2esolveRhs_24s421(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244);
V g_heff_2eunify_2esolveRhs_24s421_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveRhs_24s421_clo;
V g_heff_2eunify_2esolveF_24s420(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247);
V g_heff_2eunify_2esolveF_24s420_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveF_24s420_clo;
V g_heff_2eunify_2euTypeF_24s417(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245);
V g_heff_2eunify_2euTypeF_24s417_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTypeF_24s417_clo;
V g_heff_2eunify_2euBareF_24s438(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245);
V g_heff_2eunify_2euBareF_24s438_entry(V self, V *a);
extern Clo g_heff_2eunify_2euBareF_24s438_clo;
V g_heff_2eunify_2euk_24s416_get(void);
V g_heff_2emeta_2eblockedFlex(V v_ps_240, V v_a_241);
V g_heff_2emeta_2eblockedFlex_entry(V self, V *a);
extern Clo g_heff_2emeta_2eblockedFlex_clo;
V g_heff_2emeta_2eblockedTy(V v_a0_240, V v_hd_241, V v_k_242);
V g_heff_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2emeta_2eblockedTy_clo;
V g_prelude_2efoldl_24s439(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s439_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s439_clo;
V g_heff_2emeta_2ekeepFailed(V v_p_240, V v_x2_241, V v_p_242, V v_p_243);
V g_heff_2emeta_2ekeepFailed_entry(V self, V *a);
extern Clo g_heff_2emeta_2ekeepFailed_clo;
V g_heff_2emeta_2eundoTo(V v_before_240, V v_c_241);
V g_heff_2emeta_2eundoTo_entry(V self, V *a);
extern Clo g_heff_2emeta_2eundoTo_clo;
V g_heff_2emeta_2eundoIfFailed(V v_before_240, V v_waiting_241, V v_x3_242, V v_p_243, V v_p_244);
V g_heff_2emeta_2eundoIfFailed_entry(V self, V *a);
extern Clo g_heff_2emeta_2eundoIfFailed_clo;
V g_heff_2emeta_2eattempt(V v_m_240, V v_hd_241, V v_k_242);
V g_heff_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2emeta_2eattempt_clo;
V g_heff_2emeta_2eretryEach(V v_g_240, V v_x2_241);
V g_heff_2emeta_2eretryEach_entry(V self, V *a);
extern Clo g_heff_2emeta_2eretryEach_clo;
V g_heff_2emeta_2eretryGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243);
V g_heff_2emeta_2eretryGo_entry(V self, V *a);
extern Clo g_heff_2emeta_2eretryGo_clo;
V g_heff_2emeta_2edelayedReady(V v_mc_240, V v_all_241, V v_x3_242);
V g_heff_2emeta_2edelayedReady_entry(V self, V *a);
extern Clo g_heff_2emeta_2edelayedReady_clo;
V g_heff_2emeta_2eanyDelayed(V v_mc_240, V v_x2_241);
V g_heff_2emeta_2eanyDelayed_entry(V self, V *a);
extern Clo g_heff_2emeta_2eanyDelayed_clo;
V g_heff_2emeta_2eresolveKept(V v_x1_240);
V g_heff_2emeta_2eresolveKept_entry(V self, V *a);
extern Clo g_heff_2emeta_2eresolveKept_clo;
V g_prelude_2eany_24s440(V v_x2_240);
V g_prelude_2eany_24s440_entry(V self, V *a);
extern Clo g_prelude_2eany_24s440_clo;
V g_heff_2emeta_2erunEachS(V v_x1_240, V v_p_241);
V g_heff_2emeta_2erunEachS_entry(V self, V *a);
extern Clo g_heff_2emeta_2erunEachS_clo;
V g_heff_2emeta_2ewakeS(V v_all_240, V v_st_241);
V g_heff_2emeta_2ewakeS_entry(V self, V *a);
extern Clo g_heff_2emeta_2ewakeS_clo;
V g_heff_2emeta_2eresolveListS(V v_final_240, V v_x2_241, V v_p_242);
V g_heff_2emeta_2eresolveListS_entry(V self, V *a);
extern Clo g_heff_2emeta_2eresolveListS_clo;
V g_heff_2emeta_2eresolveS(V v_final_240, V v_st_241);
V g_heff_2emeta_2eresolveS_entry(V self, V *a);
extern Clo g_heff_2emeta_2eresolveS_clo;
V g_heff_2emeta_2edeferAlg(V v_x1_240, V v_p_241);
V g_heff_2emeta_2edeferAlg_entry(V self, V *a);
extern Clo g_heff_2emeta_2edeferAlg_clo;
V g_heff_2emeta_2enotesAlg(V v_x1_240, V v_p_241);
V g_heff_2emeta_2enotesAlg_entry(V self, V *a);
extern Clo g_heff_2emeta_2enotesAlg_clo;
V g_heff_2emeta_2ealg2(V v_x1_240, V v_p_241);
V g_heff_2emeta_2ealg2_entry(V self, V *a);
extern Clo g_heff_2emeta_2ealg2_clo;
V g_heff_2emeta_2eelabH_get(void);
V g_heff_2emeta_2esettleGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243);
V g_heff_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2emeta_2esettleGo_clo;
V g_heff_2eprims_2eprims_get(void);
V g_heff_2eprims_2einternal_get(void);
V g_heff_2eprims_2eallPrims_get(void);
V g_heff_2eprims_2eprimArityGo(V v_p_240, V v_x2_241);
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2eprims_2eprimArityGo_clo;
V g_heff_2eprint_2eescChar(V v_c_240);
V g_heff_2eprint_2eescChar_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescChar_clo;
V g_heff_2eprint_2eescFrom(V v_s_240, V v_i_241);
V g_heff_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescFrom_clo;
V g_heff_2eprint_2ecommaSep(V v_x1_240);
V g_heff_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eprint_2ecommaSep_clo;
V g_heff_2eprint_2edictOf(V v_f_240, V v_d_241);
V g_heff_2eprint_2edictOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2edictOf_clo;
V g_heff_2eprint_2eabsOf(V v_f_240, V v_x2_241);
V g_heff_2eprint_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2eabsOf_clo;
V g_prelude_2emap_24s441(V v_x2_240);
V g_prelude_2emap_24s441_entry(V self, V *a);
extern Clo g_prelude_2emap_24s441_clo;
V g_heff_2eprint_2earmOf(V v_r_240, V v_x2_241);
V g_heff_2eprint_2earmOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_clo;
V g_prelude_2emap_24s442(V v_x2_240);
V g_prelude_2emap_24s442_entry(V self, V *a);
extern Clo g_prelude_2emap_24s442_clo;
V g_heff_2eprint_2eshowTermF(V v_r_240, V v_x2_241);
V g_heff_2eprint_2eshowTermF_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_clo;
V g_heff_2eprint_2eshowTypeF(V v_r_240, V v_x2_241);
V g_heff_2eprint_2eshowTypeF_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_clo;
V g_heff_2eprint_2epr_get(void);
V g_heff_2eprint_2earmOf_24s444(V v_x2_240);
V g_heff_2eprint_2earmOf_24s444_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_24s444_clo;
V g_prelude_2emap_24s446(V v_x2_240);
V g_prelude_2emap_24s446_entry(V self, V *a);
extern Clo g_prelude_2emap_24s446_clo;
V g_heff_2eprint_2edictOf_24s445(V v_d_240);
V g_heff_2eprint_2edictOf_24s445_entry(V self, V *a);
extern Clo g_heff_2eprint_2edictOf_24s445_clo;
V g_prelude_2emap_24s449(V v_x2_240);
V g_prelude_2emap_24s449_entry(V self, V *a);
extern Clo g_prelude_2emap_24s449_clo;
V g_heff_2eprint_2edictOf_24s448(V v_d_240);
V g_heff_2eprint_2edictOf_24s448_entry(V self, V *a);
extern Clo g_heff_2eprint_2edictOf_24s448_clo;
V g_heff_2eprint_2eshowTypeF_24s447(V v_x2_240);
V g_heff_2eprint_2eshowTypeF_24s447_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_24s447_clo;
V g_heff_2eprint_2eshowTermF_24s443(V v_x2_240);
V g_heff_2eprint_2eshowTermF_24s443_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_24s443_clo;
V g_heff_2erules_2eintoSilent(V v_e_240, V v_implicit_241, V v_y_242, V v_dom_243, V v_sc_244, V v_v_245, V v_counted_246);
V g_heff_2erules_2eintoSilent_entry(V self, V *a);
extern Clo g_heff_2erules_2eintoSilent_clo;
V g_heff_2evalue_2emkNeu_24s10_24s450(V v_h_240, V v_spine_241, V v_desc_242);
V g_heff_2evalue_2emkNeu_24s10_24s450_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s10_24s450_clo;
V g_heff_2erules_2eerrorOf_get(void);
V g_heff_2erules_2edownFrom(V v_n_240);
V g_heff_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2erules_2edownFrom_clo;
V g_heff_2erules_2enamesFor(V v_n_240);
V g_heff_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2erules_2enamesFor_clo;
V g_heff_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246);
V g_heff_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2erules_2efreshMeta_clo;
V g_heff_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245);
V g_heff_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2erules_2efillHole_clo;
V g_heff_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247);
V g_heff_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2erules_2esolveHole_clo;
V g_heff_2erules_2etyStr(V v_e_240, V v_t_241);
V g_heff_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2erules_2etyStr_clo;
V g_heff_2erules_2etyStrM(V v_e_240, V v_m_241);
V g_heff_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2erules_2etyStrM_clo;
V g_heff_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242);
V g_heff_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2erules_2eeqTyStr_clo;
V g_heff_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242);
V g_heff_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2erules_2eeqElStr_clo;
V g_heff_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243);
V g_heff_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2erules_2eeqBareStr_clo;
V g_heff_2erules_2eprettyEqErr(V v_g_240, V v_x2_241);
V g_heff_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2erules_2eprettyEqErr_clo;
V g_heff_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243);
V g_heff_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2erules_2etyStrZ_clo;
V g_heff_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244);
V g_heff_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2erules_2ekeepRecovered_clo;
V g_heff_2erules_2erecoverWith(V v_e_240, V v_a_241, V v_d_242, V v_saved_243, V v_waiting_244, V v_hd_245, V v_k_246);
V g_heff_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2erules_2erecoverWith_clo;
V g_heff_2erules_2erecovering(V v_c_240);
V g_heff_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2erules_2erecovering_clo;
V g_heff_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242);
V g_heff_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2erules_2einstShown_clo;
V g_heff_2erules_2ewitnessMatches(V v_e_240, V v_goal_241, V v_x3_242);
V g_heff_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2erules_2ewitnessMatches_clo;
V g_prelude_2emap_24s451(V v_x2_240);
V g_prelude_2emap_24s451_entry(V self, V *a);
extern Clo g_prelude_2emap_24s451_clo;
V g_heff_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_final_245, V v_hd_246, V v_k_247);
V g_heff_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2erules_2eresolveWanted_clo;
V g_heff_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245);
V g_heff_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2erules_2einsertInstance_clo;
V g_heff_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245);
V g_heff_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2erules_2einsertImplicits_clo;
V g_heff_2erules_2efunctionFormation(V v_x1_240, V v_cod_241);
V g_heff_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionFormation_clo;
V g_heff_2erules_2eimplicitLams(V v_c_240);
V g_heff_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2erules_2eimplicitLams_clo;
V g_heff_2erules_2efunctionIntro(V v_sp_240, V v_x_241, V v_body_242);
V g_heff_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionIntro_clo;
V g_heff_2erules_2efunctionIntroSyn(V v_x_240, V v_dom_241, V v_body_242);
V g_heff_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionIntroSyn_clo;
V g_heff_2erules_2erequireAgree(V v_e_240, V v_sp_241, V v_x3_242);
V g_heff_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2erules_2erequireAgree_clo;
V g_heff_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243);
V g_heff_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionIntroAnn_clo;
V g_heff_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242);
V g_heff_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionIntroImplicit_clo;
V g_heff_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247);
V g_heff_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2erules_2enamedGo_clo;
V g_heff_2erules_2enamedGo_2enoArgNamed_240(V v_sp_240, V v_x_241, V v_hd_242, V v_k2_243);
V g_heff_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246);
V g_heff_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2erules_2edelayedCheck_clo;
V g_heff_2erules_2edelayChkOn(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_keyTy_244, V v_ty_245, V v_hd_246, V v_k_247);
V g_heff_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2erules_2edelayChkOn_clo;
V g_heff_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244);
V g_heff_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2erules_2eelimPlain_clo;
V g_heff_2erules_2eelimGo(V v_checksOnly_240, V v_sp_241, V v_arg_242, V v_e_243, V v_x5_244);
V g_heff_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2erules_2eelimGo_clo;
V g_heff_2erules_2efunctionElimC(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243);
V g_heff_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2erules_2efunctionElimC_clo;
V g_heff_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242);
V g_heff_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2erules_2echeckFields_clo;
V g_heff_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249);
V g_heff_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2erules_2especializedGo_clo;
V g_heff_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244);
V g_heff_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2erules_2especialized_clo;
V g_heff_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243);
V g_heff_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2erules_2eapplyGo_clo;
V g_heff_2erules_2eapply(V v_sp_240, V v_syn_241);
V g_heff_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2erules_2eapply_clo;
V g_heff_2erules_2eannot(V v_typ_240, V v_chk_241);
V g_heff_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2erules_2eannot_clo;
V g_heff_2erules_2erecChk(V v_sp_240, V v_c_241);
V g_heff_2erules_2erecChk_entry(V self, V *a);
extern Clo g_heff_2erules_2erecChk_clo;
V g_heff_2erules_2evarGo(V v_x_240, V v_names_241, V v_ctx_242, V v_locals_243, V v_n_244, V v_i_245);
V g_heff_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2erules_2evarGo_clo;
V g_heff_2erules_2eautoRec(V v_sp_240, V v_x_241, V v_c_242);
V g_heff_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2erules_2eautoRec_clo;
V g_heff_2erules_2eabandonChk(V v_sp_240);
V g_heff_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2erules_2eabandonChk_clo;
V g_heff_2erules_2eprimInt_get(void);
V g_heff_2erules_2eprimFloat_get(void);
V g_heff_2erules_2eprimArray(V v_a_240);
V g_heff_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2erules_2eprimArray_clo;
V g_heff_2erules_2eprimString_get(void);
V g_heff_2erules_2eformGo(V v_e_27_240, V v_x2_241);
V g_heff_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2erules_2eformGo_clo;
V g_heff_2erules_2erecordFormation(V v_fieldTyps_240);
V g_heff_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordFormation_clo;
V g_heff_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246);
V g_heff_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordName_clo;
V g_heff_2erules_2eappendP(V v_x1_240, V v_ys_241);
V g_heff_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2erules_2eappendP_clo;
V g_heff_2erules_2elookupP(V v_x1_240, V v_x_241);
V g_heff_2erules_2elookupP_entry(V self, V *a);
extern Clo g_heff_2erules_2elookupP_clo;
V g_heff_2erules_2erebottom(V v_v_240, V v_x2_241);
V g_heff_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2erules_2erebottom_clo;
V g_heff_2erules_2eadvanceSelf(V v_gk_240, V v_a_241, V v_fieldTypes_242, V v_done_243);
V g_heff_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2erules_2eadvanceSelf_clo;
V g_heff_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244);
V g_heff_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2erules_2eselfAdvance_clo;
V g_heff_2erules_2echeckFixed(V v_e_240, V v_fs_241, V v_v_242, V v_x4_243);
V g_heff_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2erules_2echeckFixed_clo;
V g_heff_2erules_2eintroGo(V v_e_240, V v_a_241, V v_done_242, V v_vs_243, V v_x5_244);
V g_heff_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2erules_2eintroGo_clo;
V g_heff_2erules_2ezipP(V v_x1_240, V v_x2_241);
V g_heff_2erules_2ezipP_entry(V self, V *a);
extern Clo g_heff_2erules_2ezipP_clo;
V g_heff_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241);
V g_heff_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordIntro_clo;
V g_heff_2erules_2eanyP(V v_p_240, V v_x2_241);
V g_heff_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2erules_2eanyP_clo;
V g_heff_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242);
V g_heff_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2erules_2eanyIdxGo_clo;
V g_heff_2erules_2ementionsTermF_24s453(V v_d_240, V v_t_241);
V g_heff_2erules_2ementionsTermF_24s453_entry(V self, V *a);
extern Clo g_heff_2erules_2ementionsTermF_24s453_clo;
V g_heff_2erules_2ementionsTypeF_24s452(V v_d_240, V v_t_241);
V g_heff_2erules_2ementionsTypeF_24s452_entry(V self, V *a);
extern Clo g_heff_2erules_2ementionsTypeF_24s452_clo;
V g_heff_2erules_2efieldTyAt(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245);
V g_heff_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2erules_2efieldTyAt_clo;
V g_heff_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242);
V g_heff_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordElim_clo;
V g_heff_2evalue_2egoER_24s454(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245);
V g_heff_2evalue_2egoER_24s454_entry(V self, V *a);
extern Clo g_heff_2evalue_2egoER_24s454_clo;
V g_heff_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243);
V g_heff_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordSpec_clo;
V g_heff_2erules_2etraverseE(V v_f_240, V v_x2_241);
V g_heff_2erules_2etraverseE_entry(V self, V *a);
extern Clo g_heff_2erules_2etraverseE_clo;
V g_heff_2erules_2esumFormation(V v_vs_240);
V g_heff_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2erules_2esumFormation_clo;
V g_heff_2erules_2etagText(V v_t_240);
V g_heff_2erules_2etagText_entry(V self, V *a);
extern Clo g_heff_2erules_2etagText_clo;
V g_heff_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242);
V g_heff_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2erules_2etagArgsGo_clo;
V g_heff_2erules_2esumIntroNow(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243);
V g_heff_2erules_2esumIntroNow_entry(V self, V *a);
extern Clo g_heff_2erules_2esumIntroNow_clo;
V g_heff_2erules_2esumIntro(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243);
V g_heff_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2erules_2esumIntro_clo;
V g_heff_2erules_2erecordTagIn(V v_e_240, V v_a_241, V v_vs_242, V v_x_243, V v_tsp_244);
V g_heff_2erules_2erecordTagIn_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordTagIn_clo;
V g_heff_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243);
V g_heff_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2erules_2erecordTags_clo;
V g_prelude_2emap_24s455(V v_x2_240);
V g_prelude_2emap_24s455_entry(V self, V *a);
extern Clo g_prelude_2emap_24s455_clo;
V g_prelude_2emap_24s456(V v_x2_240);
V g_prelude_2emap_24s456_entry(V self, V *a);
extern Clo g_prelude_2emap_24s456_clo;
V g_heff_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_x_244, V v_ts_245, V v_casesChk_246);
V g_heff_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2erules_2ecaseArm_clo;
V g_heff_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247);
V g_heff_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2erules_2ecasesAt_clo;
V g_heff_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244);
V g_heff_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2erules_2ematchLater_clo;
V g_heff_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243);
V g_heff_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2erules_2esumElim_clo;
V g_heff_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242);
V g_heff_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2erules_2ecaseLet_clo;
V g_heff_2erules_2efixEnv(V v_e_240, V v_x_241, V v_a_242);
V g_heff_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2erules_2efixEnv_clo;
V g_heff_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243);
V g_heff_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2erules_2elocalDef_clo;
V g_heff_2erules_2euniverseIntro(V v_sp_240, V v_typ_241);
V g_heff_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2erules_2euniverseIntro_clo;
V g_heff_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241);
V g_heff_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2erules_2euniverseElimSyn_clo;
V g_heff_2erules_2easSmall(V v_sp_240, V v_typ_241);
V g_heff_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2erules_2easSmall_clo;
V g_heff_2erules_2eindexOfName(V v_x1_240, V v_x_241, V v_i_242);
V g_heff_2erules_2eindexOfName_entry(V self, V *a);
extern Clo g_heff_2erules_2eindexOfName_clo;
V g_heff_2erules_2efind(V v_sp_240, V v_x_241);
V g_heff_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2erules_2efind_clo;
V g_heff_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243);
V g_heff_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eselfTermF_clo;
V g_heff_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243);
V g_heff_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eselfTypeF_clo;
V g_heff_2etoplevel_2eselfWalk(V v_k_240);
V g_heff_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eselfWalk_clo;
V g_heff_2etoplevel_2enominalSyn(V v_j_240);
V g_heff_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2enominalSyn_clo;
V g_heff_2etoplevel_2enominalChk(V v_j_240);
V g_heff_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2enominalChk_clo;
V g_heff_2etoplevel_2enominalTyp(V v_j_240);
V g_heff_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2enominalTyp_clo;
V g_heff_2etoplevel_2echecksOnly(V v_c_240);
V g_heff_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2echecksOnly_clo;
V g_heff_2etoplevel_2erecoveringChk(V v_m_240, V v_hd_241, V v_k_242);
V g_heff_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2erecoveringChk_clo;
V g_heff_2etoplevel_2etraverseEL(V v_f_240, V v_x2_241);
V g_heff_2etoplevel_2etraverseEL_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_clo;
V g_heff_2etoplevel_2epatName(V v_p_240);
V g_heff_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2epatName_clo;
V g_heff_2etoplevel_2etraverseEL_24s457(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s457_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s457_clo;
V g_heff_2etoplevel_2edoPat(V v_p_240);
V g_heff_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2edoPat_clo;
V g_heff_2etoplevel_2eannotatesData(V v_x1_240);
V g_heff_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eannotatesData_clo;
V g_heff_2etoplevel_2eallL_24s458(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s458_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s458_clo;
V g_heff_2etoplevel_2eflatPat(V v_gr_240);
V g_heff_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eflatPat_clo;
V g_heff_2etoplevel_2etagSpans(V v_x1_240);
V g_heff_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etagSpans_clo;
V g_heff_2etoplevel_2elamsOf(V v_n_240, V v_b_241);
V g_heff_2etoplevel_2elamsOf_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2elamsOf_clo;
V g_heff_2etoplevel_2eparamsOf(V v_i_240, V v_e_241, V v_x3_242);
V g_heff_2etoplevel_2eparamsOf_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eparamsOf_clo;
V g_heff_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242);
V g_heff_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eparamsInOrder_clo;
V g_heff_2etoplevel_2etagSynonym(V v_ge_240);
V g_heff_2etoplevel_2etagSynonym_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etagSynonym_clo;
V g_heff_2etoplevel_2eallL_24s459(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s459_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s459_clo;
V g_heff_2etoplevel_2eallL_24s460(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s460_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s460_clo;
V g_heff_2etoplevel_2ehasOpPat(V v_p_240);
V g_heff_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ehasOpPat_clo;
V g_heff_2etoplevel_2eopPat(V v_g_240, V v_p_241);
V g_heff_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eopPat_clo;
V g_heff_2etoplevel_2eallL_24s461(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s461_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s461_clo;
V g_heff_2etoplevel_2eallL_24s462(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s462_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s462_clo;
V g_heff_2etoplevel_2eallL_24s463(V v_x2_240);
V g_heff_2etoplevel_2eallL_24s463_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eallL_24s463_clo;
V g_heff_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241);
V g_heff_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2echkHeadOf_clo;
V g_heff_2etoplevel_2ebinderF_24s465(V v_x2_240);
V g_heff_2etoplevel_2ebinderF_24s465_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ebinderF_24s465_clo;
V g_heff_2etoplevel_2efieldDeclF_24s466(V v_x2_240);
V g_heff_2etoplevel_2efieldDeclF_24s466_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2efieldDeclF_24s466_clo;
V g_heff_2etoplevel_2etraverseEL_24s467(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s467_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s467_clo;
V g_heff_2etoplevel_2etraverseEL_24s469(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s469_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s469_clo;
V g_heff_2etoplevel_2evariantF_24s468(V v_x2_240);
V g_heff_2etoplevel_2evariantF_24s468_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2evariantF_24s468_clo;
V g_heff_2etoplevel_2etraverseEL_24s470(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s470_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s470_clo;
V g_heff_2etoplevel_2etraverseEL_24s476(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s476_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s476_clo;
V g_heff_2etoplevel_2efieldSetF_24s477(V v_x2_240);
V g_heff_2etoplevel_2efieldSetF_24s477_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2efieldSetF_24s477_clo;
V g_heff_2etoplevel_2etraverseEL_24s478(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s478_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s478_clo;
V g_heff_2etoplevel_2edoCase_24s479(V v_x2_240);
V g_heff_2etoplevel_2edoCase_24s479_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2edoCase_24s479_clo;
V g_heff_2etoplevel_2etraverseEL_24s480(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s480_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s480_clo;
V g_heff_2etoplevel_2elocalBody_24s482(V v_f_240, V v_eqs_241, V v_sp_242);
V g_heff_2etoplevel_2elocalBody_24s482_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2elocalBody_24s482_clo;
V g_heff_2etoplevel_2elocalsJ_24s481(V v_x2_240, V v_body_241);
V g_heff_2etoplevel_2elocalsJ_24s481_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2elocalsJ_24s481_clo;
V g_heff_2etoplevel_2erawF_24s475(V v_n_240);
V g_heff_2etoplevel_2erawF_24s475_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2erawF_24s475_clo;
V g_heff_2etoplevel_2echkF_24s474(V v_n_240);
V g_heff_2etoplevel_2echkF_24s474_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2echkF_24s474_clo;
V g_heff_2etoplevel_2eelimF_24s473(V v_start_240, V v_s_241, V v_x4_242);
V g_heff_2etoplevel_2eelimF_24s473_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelimF_24s473_clo;
V g_heff_2etoplevel_2eelimAll_24s472(V v_start_240, V v_s_241, V v_x4_242);
V g_heff_2etoplevel_2eelimAll_24s472_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelimAll_24s472_clo;
V g_heff_2etoplevel_2einfF_24s471(V v_n_240);
V g_heff_2etoplevel_2einfF_24s471_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2einfF_24s471_clo;
V g_heff_2etoplevel_2etypF_24s464(V v_n_240);
V g_heff_2etoplevel_2etypF_24s464_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etypF_24s464_clo;
V g_heff_2etoplevel_2eargBinding(V v_x1_240);
V g_heff_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eargBinding_clo;
V g_heff_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241);
V g_heff_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewithOne_clo;
V g_heff_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241);
V g_heff_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewithArgs_clo;
V g_heff_2etoplevel_2etraverseEL_24s483(V v_x2_240);
V g_heff_2etoplevel_2etraverseEL_24s483_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etraverseEL_24s483_clo;
V g_heff_2etoplevel_2etheoryD(V v_name_240, V v_params_241, V v_bodyN_242);
V g_heff_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etheoryD_clo;
V g_heff_2etoplevel_2eexplicitNames(V v_x1_240);
V g_heff_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eexplicitNames_clo;
V g_heff_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243);
V g_heff_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2edefineD_clo;
V g_heff_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243);
V g_heff_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eequationsBody_clo;
V g_heff_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243);
V g_heff_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eequationsD_clo;
V g_heff_2etoplevel_2edeclJ(V v_d_240);
V g_heff_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2edeclJ_clo;
V g_heff_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241);
V g_heff_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2erecoveredCheck_clo;
V g_heff_2etoplevel_2eanyL(V v_p_240, V v_x2_241);
V g_heff_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eanyL_clo;
V g_heff_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241);
V g_heff_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2epoisonedLeft_clo;
V g_heff_2etoplevel_2eappendM(V v_x1_240, V v_ys_241);
V g_heff_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eappendM_clo;
V g_heff_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241);
V g_heff_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2econcatMapM_clo;
V g_heff_2etoplevel_2espineVals(V v_x1_240);
V g_heff_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2espineVals_clo;
V g_heff_2etoplevel_2emetasInV(V v_mc_240, V v_v_241);
V g_heff_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2emetasInV_clo;
V g_heff_2etoplevel_2enubInt(V v_x1_240);
V g_heff_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2enubInt_clo;
V g_heff_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243);
V g_heff_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eshownV_clo;
V g_heff_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244);
V g_heff_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2estuckWith_clo;
V g_heff_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243);
V g_heff_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2estuckAt_clo;
V g_heff_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244);
V g_heff_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eentryFor_clo;
V g_heff_2etoplevel_2eerrEntry(V v_g_240, V v_k_241, V v_tyStx_242);
V g_heff_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eerrEntry_clo;
V g_heff_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244);
V g_heff_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2echeckStuck_clo;
V g_heff_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242);
V g_heff_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2echeckUnsolved_clo;
V g_heff_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243);
V g_heff_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ebodyEnv_clo;
V g_co_2ebind_24s484(V v_f_240, V v_hd_241, V v_k_242);
V g_co_2ebind_24s484_entry(V self, V *a);
extern Clo g_co_2ebind_24s484_clo;
V g_heff_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244);
V g_heff_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ebodyPhase_clo;
V g_heff_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_tyStx_243, V v_mc_244, V v_x6_245);
V g_heff_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabOut_clo;
V g_heff_2etoplevel_2eprimNames_get(void);
V g_heff_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241);
V g_heff_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eprimKnown_clo;
V g_heff_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244);
V g_heff_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabBody_clo;
V g_heff_2etoplevel_2ewatchSyn(V v_w_240);
V g_heff_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewatchSyn_clo;
V g_heff_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243);
V g_heff_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewatchEntry_clo;
V g_heff_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244);
V g_heff_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewatchPhase_clo;
V g_heff_2etoplevel_2eelabWatch(V v_g_240, V v_n_241);
V g_heff_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabWatch_clo;
V g_heff_2etoplevel_2eappendT(V v_x1_240, V v_ys_241);
V g_heff_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eappendT_clo;
V g_heff_2etoplevel_2econcatMapT_24s485(V v_x2_240);
V g_heff_2etoplevel_2econcatMapT_24s485_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2econcatMapT_24s485_clo;
V g_heff_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243);
V g_heff_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopBroken_clo;
V g_heff_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241);
V g_heff_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ekeepSt_clo;
V g_heff_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243);
V g_heff_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopTake_clo;
V g_heff_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242);
V g_heff_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ewatchTake_clo;
V g_heff_2etoplevel_2erecoveredCheck_24s487(V v_k_240, V v_st_241);
V g_heff_2etoplevel_2erecoveredCheck_24s487_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2erecoveredCheck_24s487_clo;
V g_heff_2etoplevel_2eelabDecl_24s486(V v_key_240, V v_g_241, V v_n_242, V v_st_243);
V g_heff_2etoplevel_2eelabDecl_24s486_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabDecl_24s486_clo;
V g_heff_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242);
V g_heff_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopOne_clo;
V g_heff_2etoplevel_2etopGo(V v_kf_240, V v_acc_241, V v_x3_242);
V g_heff_2etoplevel_2etopGo_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopGo_clo;
V g_heff_2etoplevel_2eelabOut_24s492(V v_g_240, V v_d_241, V v_tyStx_242, V v_mc_243, V v_x6_244);
V g_heff_2etoplevel_2eelabOut_24s492_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabOut_24s492_clo;
V g_heff_2etoplevel_2eelabBody_24s491(V v_g_240, V v_n_241, V v_d_242, V v_a_243);
V g_heff_2etoplevel_2eelabBody_24s491_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabBody_24s491_clo;
V g_heff_2etoplevel_2eelabDecl_24s486_24s490(V v_g_240, V v_n_241, V v_st_242);
V g_heff_2etoplevel_2eelabDecl_24s486_24s490_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eelabDecl_24s486_24s490_clo;
V g_heff_2etoplevel_2etopBroken_24s494(V v_acc_240, V v_n_241, V v_diags_242);
V g_heff_2etoplevel_2etopBroken_24s494_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopBroken_24s494_clo;
V g_heff_2etoplevel_2etopTake_24s493(V v_acc_240, V v_n_241, V v_x4_242);
V g_heff_2etoplevel_2etopTake_24s493_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopTake_24s493_clo;
V g_heff_2etoplevel_2etopOne_24s489(V v_acc_240, V v_n_241);
V g_heff_2etoplevel_2etopOne_24s489_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopOne_24s489_clo;
V g_heff_2etoplevel_2etopGo_24s488(V v_acc_240, V v_x3_241);
V g_heff_2etoplevel_2etopGo_24s488_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2etopGo_24s488_clo;
V g_heff_2etoplevel_2eisForeignB(V v_x1_240);
V g_heff_2etoplevel_2eisForeignB_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2eisForeignB_clo;
V g_heff_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241);
V g_heff_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ethawGlobals_clo;
V g_heff_2etoplevel_2ethawOne(V v_acc_240, V v_d_241);
V g_heff_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ethawOne_clo;
V g_heff_2etoplevel_2ethawDone(V v_acc_240);
V g_heff_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ethawDone_clo;
V g_prelude_2efoldl_24s495(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s495_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s495_clo;
V g_heff_2edriver_2eimportsOfSource(V v_s_240);
V g_heff_2edriver_2eimportsOfSource_entry(V self, V *a);
extern Clo g_heff_2edriver_2eimportsOfSource_clo;
V g_heff_2edriver_2eappendD(V v_x1_240, V v_ys_241);
V g_heff_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2edriver_2eappendD_clo;
V g_heff_2edriver_2enubStrD(V v_x1_240);
V g_heff_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubStrD_clo;
V g_heff_2edriver_2efindChecked(V v_x1_240, V v_m_241);
V g_heff_2edriver_2efindChecked_entry(V self, V *a);
extern Clo g_heff_2edriver_2efindChecked_clo;
V g_heff_2edriver_2eclosureGo(V v_done_240, V v_seen_241, V v_x3_242);
V g_heff_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2eclosureGo_clo;
V g_prelude_2efoldl_24s496(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s496_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s496_clo;
V g_heff_2edriver_2eenvOne(V v_c_240, V v_g_241);
V g_heff_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eenvOne_clo;
V g_prelude_2efoldl_24s497(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s497_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s497_clo;
V g_heff_2edriver_2ecatMaybesD(V v_x1_240);
V g_heff_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecatMaybesD_clo;
V g_heff_2edriver_2eanyD(V v_p_240, V v_x2_241);
V g_heff_2edriver_2eanyD_entry(V self, V *a);
extern Clo g_heff_2edriver_2eanyD_clo;
V g_heff_2edriver_2ewithoutGiven(V v_all_240);
V g_heff_2edriver_2ewithoutGiven_entry(V self, V *a);
extern Clo g_heff_2edriver_2ewithoutGiven_clo;
V g_heff_2edriver_2econcatMapD_24s498(V v_x2_240);
V g_heff_2edriver_2econcatMapD_24s498_entry(V self, V *a);
extern Clo g_heff_2edriver_2econcatMapD_24s498_clo;
V g_heff_2edriver_2ebrokenIn(V v_c_240);
V g_heff_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2edriver_2ebrokenIn_clo;
V g_heff_2edriver_2enubByName(V v_x1_240);
V g_heff_2edriver_2enubByName_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubByName_clo;
V g_heff_2edriver_2eclashMap(V v_m_240, V v_x2_241);
V g_heff_2edriver_2eclashMap_entry(V self, V *a);
extern Clo g_heff_2edriver_2eclashMap_clo;
V g_heff_2edriver_2ejoinComma(V v_x1_240);
V g_heff_2edriver_2ejoinComma_entry(V self, V *a);
extern Clo g_heff_2edriver_2ejoinComma_clo;
V g_prelude_2emap_24s499(V v_x2_240);
V g_prelude_2emap_24s499_entry(V self, V *a);
extern Clo g_prelude_2emap_24s499_clo;
V g_heff_2edriver_2eclashDiag(V v_imported_240, V v_o_241);
V g_heff_2edriver_2eclashDiag_entry(V self, V *a);
extern Clo g_heff_2edriver_2eclashDiag_clo;
V g_heff_2edriver_2ealiasOpen(V v_clashes_240, V v_g_241, V v_x3_242);
V g_heff_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2edriver_2ealiasOpen_clo;
V g_heff_2edriver_2ealiasQOne(V v_done_240, V v_g_241, V v_q_242);
V g_heff_2edriver_2ealiasQOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2ealiasQOne_clo;
V g_heff_2edriver_2ealiasQualified(V v_done_240, V v_g_241, V v_x3_242);
V g_heff_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2edriver_2ealiasQualified_clo;
V g_heff_2edriver_2ewithParseBroken(V v_key_240, V v_g_241, V v_x3_242);
V g_heff_2edriver_2ewithParseBroken_entry(V self, V *a);
extern Clo g_heff_2edriver_2ewithParseBroken_clo;
V g_heff_2edriver_2eownOf(V v_modName_240, V v_keys_241);
V g_heff_2edriver_2eownOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eownOf_clo;
V g_heff_2edriver_2eopenNames(V v_x1_240);
V g_heff_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2edriver_2eopenNames_clo;
V g_heff_2edriver_2ealiasPairs(V v_x1_240);
V g_heff_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2edriver_2ealiasPairs_clo;
V g_prelude_2efoldl_24s500(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s500_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s500_clo;
V g_heff_2edriver_2estructIdxGo(V v_i_240, V v_x2_241, V v_m_242);
V g_heff_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2estructIdxGo_clo;
V g_heff_2edriver_2ecloseFieldsGo(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244);
V g_heff_2edriver_2ecloseFieldsGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecloseFieldsGo_clo;
V g_heff_2edriver_2ecloseTypeF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_t_244);
V g_heff_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecloseTypeF_clo;
V g_heff_2edriver_2ecloseTermF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_e_244);
V g_heff_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecloseTermF_clo;
V g_heff_2edriver_2eckOf(V v_idx_240);
V g_heff_2edriver_2eckOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eckOf_clo;
V g_heff_2edriver_2estructFieldsGo(V v_idx_240, V v_i_241, V v_x3_242);
V g_heff_2edriver_2estructFieldsGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2estructFieldsGo_clo;
V g_prelude_2emap_24s501(V v_x2_240);
V g_prelude_2emap_24s501_entry(V self, V *a);
extern Clo g_prelude_2emap_24s501_clo;
V g_heff_2edriver_2estructBody(V v_mkey_240, V v_es_241, V v_g_27_242);
V g_heff_2edriver_2estructBody_entry(V self, V *a);
extern Clo g_heff_2edriver_2estructBody_clo;
V g_heff_2edriver_2estructAdd(V v_mkey_240, V v_g_241, V v_es_242, V v_idx_243);
V g_heff_2edriver_2estructAdd_entry(V self, V *a);
extern Clo g_heff_2edriver_2estructAdd_clo;
V g_heff_2edriver_2emoduleStruct(V v_mkey_240, V v_own_241, V v_g_242);
V g_heff_2edriver_2emoduleStruct_entry(V self, V *a);
extern Clo g_heff_2edriver_2emoduleStruct_clo;
V g_prelude_2efoldl_24s502(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s502_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s502_clo;
V g_heff_2edriver_2efixOf(V v_x1_240, V v_m_241);
V g_heff_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixOf_clo;
V g_heff_2edriver_2eimportedFix(V v_done_240, V v_imps_241);
V g_heff_2edriver_2eimportedFix_entry(V self, V *a);
extern Clo g_heff_2edriver_2eimportedFix_clo;
V g_heff_2edriver_2eownFixOf(V v_done_240, V v_imps_241);
V g_heff_2edriver_2eownFixOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eownFixOf_clo;
V g_heff_2edriver_2efixitiesGo(V v_done_240, V v_x2_241);
V g_heff_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixitiesGo_clo;
V g_heff_2edriver_2ehint(V v_d_240);
V g_heff_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2edriver_2ehint_clo;
V g_heff_2edriver_2ethawedChecked(V v_s_240, V v_imps_241, V v_th_242, V v_t_243);
V g_heff_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2edriver_2ethawedChecked_clo;
V g_prelude_2emap_24s503(V v_x2_240);
V g_prelude_2emap_24s503_entry(V self, V *a);
extern Clo g_prelude_2emap_24s503_clo;
V g_heff_2edriver_2eelabTop(V v_s_240, V v_imps_241, V v_direct_242, V v_r_243, V v_t_244);
V g_heff_2edriver_2eelabTop_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabTop_clo;
V g_heff_2edriver_2eelabRead(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245);
V g_heff_2edriver_2eelabRead_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabRead_clo;
V g_heff_2edriver_2eelabFrom(V v_done_240, V v_s_241, V v_imps_242, V v_x4_243, V v_direct_244, V v_g0_245);
V g_heff_2edriver_2eelabFrom_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabFrom_clo;
V g_heff_2edriver_2econcatMapD_24s504(V v_x2_240);
V g_heff_2edriver_2econcatMapD_24s504_entry(V self, V *a);
extern Clo g_heff_2edriver_2econcatMapD_24s504_clo;
V g_heff_2edriver_2eelabAliased(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245, V v_imported_246);
V g_heff_2edriver_2eelabAliased_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabAliased_clo;
V g_heff_2edriver_2eelabNeeding(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_reached_244);
V g_heff_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabNeeding_clo;
V g_prelude_2efoldl_24s505(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s505_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s505_clo;
V g_prelude_2emap_24s506(V v_x2_240);
V g_prelude_2emap_24s506_entry(V self, V *a);
extern Clo g_prelude_2emap_24s506_clo;
V g_heff_2edriver_2elean(V v_c_240);
V g_heff_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2edriver_2elean_clo;
V g_heff_2edriver_2etraceless(V v_c_240);
V g_heff_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2edriver_2etraceless_clo;
V g_prelude_2efoldl_24s507(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s507_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s507_clo;
V g_prelude_2emap_24s508(V v_x2_240);
V g_prelude_2emap_24s508_entry(V self, V *a);
extern Clo g_prelude_2emap_24s508_clo;
V g_prelude_2emap_24s509(V v_x2_240);
V g_prelude_2emap_24s509_entry(V self, V *a);
extern Clo g_prelude_2emap_24s509_clo;
V g_heff_2edriver_2edefKind(V v_c_240, V v_k_241);
V g_heff_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2edriver_2edefKind_clo;
V g_heff_2edriver_2edumpLines(V v_c_240, V v_k_241);
V g_heff_2edriver_2edumpLines_entry(V self, V *a);
extern Clo g_heff_2edriver_2edumpLines_clo;
V g_heff_2edriver_2elastChecked(V v_x1_240);
V g_heff_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2edriver_2elastChecked_clo;
V g_prelude_2efoldl_24s510(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s510_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s510_clo;
V g_heff_2edriver_2eshowTySx(V v_g_240, V v_t_241);
V g_heff_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2edriver_2eshowTySx_clo;
V g_heff_2edriver_2eexpectLineAt(V v_src_240, V v_i_241, V v_line_242);
V g_heff_2edriver_2eexpectLineAt_entry(V self, V *a);
extern Clo g_heff_2edriver_2eexpectLineAt_clo;
V g_heff_2edriver_2eexpectLine(V v_src_240, V v_i_241);
V g_heff_2edriver_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2edriver_2eexpectLine_clo;
V g_heff_2edriver_2eexpectGo(V v_src_240, V v_i_241, V v_acc_242);
V g_heff_2edriver_2eexpectGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2eexpectGo_clo;
V g_heff_2edriver_2eexpectation(V v_src_240, V v_end_241);
V g_heff_2edriver_2eexpectation_entry(V self, V *a);
extern Clo g_heff_2edriver_2eexpectation_clo;
V g_heff_2edriver_2eevalWatch(V v_name_240, V v_g_241);
V g_heff_2edriver_2eevalWatch_entry(V self, V *a);
extern Clo g_heff_2edriver_2eevalWatch_clo;
V g_heff_2edriver_2ereadExpRead(V v_g_240, V v_r_241);
V g_heff_2edriver_2ereadExpRead_entry(V self, V *a);
extern Clo g_heff_2edriver_2ereadExpRead_clo;
V g_heff_2edriver_2eholdsOf(V v_g_240, V v_ty_241, V v_value_242, V v_x4_243);
V g_heff_2edriver_2eholdsOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eholdsOf_clo;
V g_heff_2edriver_2emkWatchInfo(V v_c_240, V v_w_241, V v_value_242, V v_ex_243, V v_ty_244);
V g_heff_2edriver_2emkWatchInfo_entry(V self, V *a);
extern Clo g_heff_2edriver_2emkWatchInfo_clo;
V g_heff_2edriver_2ewatchInfo(V v_c_240, V v_i_241, V v_w_242);
V g_heff_2edriver_2ewatchInfo_entry(V self, V *a);
extern Clo g_heff_2edriver_2ewatchInfo_clo;
V g_heff_2edriver_2ewatchesGo(V v_c_240, V v_i_241, V v_x3_242);
V g_heff_2edriver_2ewatchesGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2ewatchesGo_clo;
V g_prelude_2emap_24s511(V v_x2_240);
V g_prelude_2emap_24s511_entry(V self, V *a);
extern Clo g_prelude_2emap_24s511_clo;
V g_heff_2edriver_2eownerOf(V v_c_240, V v_from_241);
V g_heff_2edriver_2eownerOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eownerOf_clo;
V g_heff_2edriver_2eevalPick(V v_results_240, V v_x2_241);
V g_heff_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2edriver_2eevalPick_clo;
V g_heff_2edriver_2eevaluate(V v_c_240);
V g_heff_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2edriver_2eevaluate_clo;
V g_prelude_2emap_24s512(V v_x2_240);
V g_prelude_2emap_24s512_entry(V self, V *a);
extern Clo g_prelude_2emap_24s512_clo;
V g_heff_2edriver_2epromoteAt(V v_s_240, V v_from_241, V v_to_242, V v_lines_243);
V g_heff_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2edriver_2epromoteAt_clo;
V g_prelude_2emap_24s513(V v_x2_240);
V g_prelude_2emap_24s513_entry(V self, V *a);
extern Clo g_prelude_2emap_24s513_clo;
V g_prelude_2efoldl_24s514(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s514_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s514_clo;
V g_heff_2edriver_2eisTestTy(V v_x1_240);
V g_heff_2edriver_2eisTestTy_entry(V self, V *a);
extern Clo g_heff_2edriver_2eisTestTy_clo;
V g_heff_2edriver_2efieldV(V v_x1_240, V v_x_241);
V g_heff_2edriver_2efieldV_entry(V self, V *a);
extern Clo g_heff_2edriver_2efieldV_clo;
V g_heff_2edriver_2elistOfV(V v_v_240);
V g_heff_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2elistOfV_clo;
V g_heff_2edriver_2elabelOfV(V v_v_240);
V g_heff_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2elabelOfV_clo;
V g_heff_2edriver_2efailureOfV(V v_v_240);
V g_heff_2edriver_2efailureOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2efailureOfV_clo;
V g_prelude_2emap_24s515(V v_x2_240);
V g_prelude_2emap_24s515_entry(V self, V *a);
extern Clo g_prelude_2emap_24s515_clo;
V g_prelude_2emap_24s516(V v_x2_240);
V g_prelude_2emap_24s516_entry(V self, V *a);
extern Clo g_prelude_2emap_24s516_clo;
V g_heff_2edriver_2eoutcomeOfV(V v_v_240);
V g_heff_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2eoutcomeOfV_clo;
V g_prelude_2emap_24s517(V v_x2_240);
V g_prelude_2emap_24s517_entry(V self, V *a);
extern Clo g_prelude_2emap_24s517_clo;
V g_heff_2edriver_2eoutcomesOf(V v_o_240, V v_seed_241, V v_r_242);
V g_heff_2edriver_2eoutcomesOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eoutcomesOf_clo;
V g_heff_2edriver_2eaddTests(V v_seed_240, V v_i_241, V v_x3_242, V v_g_243);
V g_heff_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2edriver_2eaddTests_clo;
V g_heff_2edriver_2epickOutcomes(V v_seed_240, V v_rs_241, V v_i_242, V v_x4_243);
V g_heff_2edriver_2epickOutcomes_entry(V self, V *a);
extern Clo g_heff_2edriver_2epickOutcomes_clo;
V g_heff_2einterp_2eevalGlobalsGo_24s518(V v_ge_240, V v_x3_241, V v_acc_242);
V g_heff_2einterp_2eevalGlobalsGo_24s518_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_24s518_clo;
V g_heff_2edriver_2erunTests(V v_seed_240, V v_c_241);
V g_heff_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2edriver_2erunTests_clo;
V g_prelude_2efilter_24s519(V v_x2_240);
V g_prelude_2efilter_24s519_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s519_clo;
V g_heff_2edriver_2eearlierGo(V v_x1_240, V v_i_241, V v_x_242, V v_j_243);
V g_heff_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2eearlierGo_clo;
V g_heff_2edriver_2efixityLine(V v_fx_240, V v_i_241, V v_g_242);
V g_heff_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixityLine_clo;
V g_heff_2edriver_2efixityLines(V v_fx_240, V v_i_241, V v_x3_242);
V g_heff_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixityLines_clo;
V g_heff_2edriver_2eglueOne(V v_acc_240, V v_d_241);
V g_heff_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eglueOne_clo;
V g_heff_2epsurface_2erecordFields_24s191_24s522(V v_xs_240, V v_fs_241);
V g_heff_2epsurface_2erecordFields_24s191_24s522_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordFields_24s191_24s522_clo;
V g_heff_2epsurface_2evariantStr_24s192_24s523(V v_xs_240, V v_x4_241);
V g_heff_2epsurface_2evariantStr_24s192_24s523_entry(V self, V *a);
extern Clo g_heff_2epsurface_2evariantStr_24s192_24s523_clo;
V g_heff_2epsurface_2eformerOf_24s521(V v_name_240, V v_tf_241);
V g_heff_2epsurface_2eformerOf_24s521_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerOf_24s521_clo;
V g_heff_2epsurface_2eprintSig_24s520(V v_name_240, V v_shown_241, V v_t_242, V v_body_243);
V g_heff_2epsurface_2eprintSig_24s520_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eprintSig_24s520_clo;
V g_heff_2edriver_2esigEntry(V v_c_240, V v_ln_241, V v_o_242);
V g_heff_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2edriver_2esigEntry_clo;
V g_prelude_2emap_24s524(V v_x2_240);
V g_prelude_2emap_24s524_entry(V self, V *a);
extern Clo g_prelude_2emap_24s524_clo;
V g_prelude_2efilter_24s525(V v_x2_240);
V g_prelude_2efilter_24s525_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s525_clo;
V g_prelude_2emap_24s526(V v_x2_240);
V g_prelude_2emap_24s526_entry(V self, V *a);
extern Clo g_prelude_2emap_24s526_clo;
V g_prelude_2efilter_24s527(V v_x2_240);
V g_prelude_2efilter_24s527_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s527_clo;
V g_prelude_2efoldl_24s528(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s528_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s528_clo;
V g_heff_2edriver_2einterface(V v_c_240);
V g_heff_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2edriver_2einterface_clo;
V g_heff_2edriver_2ecandidatesOf(V v_c_240);
V g_heff_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecandidatesOf_clo;
V g_heff_2edriver_2eappendLv(V v_x1_240, V v_ys_241);
V g_heff_2edriver_2eappendLv_entry(V self, V *a);
extern Clo g_heff_2edriver_2eappendLv_clo;
V g_heff_2edriver_2ecandLeaves(V v_x1_240);
V g_heff_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecandLeaves_clo;
V g_heff_2edriver_2efits(V v_handled_240, V v_r_241);
V g_heff_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2edriver_2efits_clo;
V g_heff_2edriver_2efindNamed(V v_handled_240, V v_c_241, V v_x_242, V v_o_243);
V g_heff_2edriver_2efindNamed_entry(V self, V *a);
extern Clo g_heff_2edriver_2efindNamed_clo;
V g_heff_2edriver_2efindFirst(V v_handled_240, V v_cands_241);
V g_heff_2edriver_2efindFirst_entry(V self, V *a);
extern Clo g_heff_2edriver_2efindFirst_clo;
V g_heff_2edriver_2efindRunnable(V v_handled_240, V v_c_241, V v_x3_242);
V g_heff_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2edriver_2efindRunnable_clo;
V g_heff_2eir_2ebaseGo(V v_x_240, V v_i_241);
V g_heff_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2eir_2ebaseGo_clo;
V g_heff_2eir_2eappendI(V v_x1_240, V v_ys_241);
V g_heff_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2eir_2eappendI_clo;
V g_heff_2eir_2enubI(V v_x1_240);
V g_heff_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2eir_2enubI_clo;
V g_heff_2eir_2efreshBindOne(V v_acc_240, V v_x_241);
V g_heff_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshBindOne_clo;
V g_prelude_2efoldl_24s529(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s529_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s529_clo;
V g_heff_2eir_2efreshMany_24s531(V v_m_240, V v_n_241, V v_x4_242);
V g_heff_2eir_2efreshMany_24s531_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshMany_24s531_clo;
V g_heff_2eir_2efreshFields_24s532(V v_m_240, V v_n_241, V v_x4_242);
V g_heff_2eir_2efreshFields_24s532_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshFields_24s532_clo;
V g_heff_2eir_2efreshArms_24s533(V v_m_240, V v_n_241, V v_x4_242);
V g_heff_2eir_2efreshArms_24s533_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshArms_24s533_clo;
V g_heff_2eir_2efreshGo_24s530(V v_m_240, V v_n_241, V v_e_242);
V g_heff_2eir_2efreshGo_24s530_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshGo_24s530_clo;
V g_heff_2eir_2esubstGo(V v_m_240, V v_e_241);
V g_heff_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2eir_2esubstGo_clo;
V g_heff_2eir_2epushArms(V v_x1_240, V v_rest_241);
V g_heff_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2eir_2epushArms_clo;
V g_heff_2eir_2epushFields(V v_x1_240, V v_rest_241);
V g_heff_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2eir_2epushFields_clo;
V g_heff_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242);
V g_heff_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2eir_2ecountW_clo;
V g_heff_2eir_2elamW(V v_x_240, V v_x2_241);
V g_heff_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2eir_2elamW_clo;
V g_heff_2eir_2esizeW(V v_n_240, V v_x2_241);
V g_heff_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2eir_2esizeW_clo;
V g_heff_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242);
V g_heff_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2eir_2esizeB_clo;
V g_heff_2eir_2econcatMapI_24s534(V v_x2_240);
V g_heff_2eir_2econcatMapI_24s534_entry(V self, V *a);
extern Clo g_heff_2eir_2econcatMapI_24s534_clo;
V g_heff_2eir_2econcatMapI_24s535(V v_x2_240);
V g_heff_2eir_2econcatMapI_24s535_entry(V self, V *a);
extern Clo g_heff_2eir_2econcatMapI_24s535_clo;
V g_heff_2eir_2econcatMapI_24s536(V v_x2_240);
V g_heff_2eir_2econcatMapI_24s536_entry(V self, V *a);
extern Clo g_heff_2eir_2econcatMapI_24s536_clo;
V g_heff_2eir_2eglobalsGo(V v_e_240);
V g_heff_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2eir_2eglobalsGo_clo;
V g_heff_2eir_2eallI(V v_x1_240);
V g_heff_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2eir_2eallI_clo;
V g_prelude_2emap_24s537(V v_x2_240);
V g_prelude_2emap_24s537_entry(V self, V *a);
extern Clo g_prelude_2emap_24s537_clo;
V g_prelude_2emap_24s538(V v_x2_240);
V g_prelude_2emap_24s538_entry(V self, V *a);
extern Clo g_prelude_2emap_24s538_clo;
V g_heff_2eir_2eisValue(V v_e_240);
V g_heff_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2eir_2eisValue_clo;
V g_heff_2eir_2espine(V v_e_240);
V g_heff_2eir_2espine_entry(V self, V *a);
extern Clo g_heff_2eir_2espine_clo;
V g_heff_2espec_2eelemS(V v_x_240, V v_x2_241);
V g_heff_2espec_2eelemS_entry(V self, V *a);
extern Clo g_heff_2espec_2eelemS_clo;
V g_heff_2espec_2eappendS(V v_x1_240, V v_ys_241);
V g_heff_2espec_2eappendS_entry(V self, V *a);
extern Clo g_heff_2espec_2eappendS_clo;
V g_heff_2espec_2eallS(V v_p_240, V v_x2_241);
V g_heff_2espec_2eallS_entry(V self, V *a);
extern Clo g_heff_2espec_2eallS_clo;
V g_prelude_2emap_24s539(V v_x2_240);
V g_prelude_2emap_24s539_entry(V self, V *a);
extern Clo g_prelude_2emap_24s539_clo;
V g_heff_2espec_2eclosedIn(V v_env_240, V v_x2_241);
V g_heff_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2espec_2eclosedIn_clo;
V g_heff_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242);
V g_heff_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2espec_2eposGo_clo;
V g_prelude_2efoldl_24s540(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s540_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s540_clo;
V g_heff_2espec_2ekeyGo(V v_env_240, V v_x2_241);
V g_heff_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ekeyGo_clo;
V g_heff_2espec_2eheadUses(V v_go_240, V v_f_241);
V g_heff_2espec_2eheadUses_entry(V self, V *a);
extern Clo g_heff_2espec_2eheadUses_clo;
V g_prelude_2emap_24s541(V v_x2_240);
V g_prelude_2emap_24s541_entry(V self, V *a);
extern Clo g_prelude_2emap_24s541_clo;
V g_heff_2espec_2eusesOf(V v_g_240, V v_x2_241);
V g_heff_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2espec_2eusesOf_clo;
V g_heff_2espec_2enthS(V v_i_240, V v_x2_241);
V g_heff_2espec_2enthS_entry(V self, V *a);
extern Clo g_heff_2espec_2enthS_clo;
V g_heff_2espec_2ehandsOn(V v_x_240, V v_i_241, V v_x3_242);
V g_heff_2espec_2ehandsOn_entry(V self, V *a);
extern Clo g_heff_2espec_2ehandsOn_clo;
V g_heff_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242);
V g_heff_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2espec_2estaticGo_clo;
V g_heff_2espec_2edropAt(V v_x1_240, V v_as_241);
V g_heff_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2espec_2edropAt_clo;
V g_heff_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243);
V g_heff_2espec_2eselfHead_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfHead_clo;
V g_heff_2espec_2eselfTo(V v_g_240, V v_h_241, V v_ds_242, V v_e_243);
V g_heff_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfTo_clo;
V g_heff_2esimplify_2ebudget_get(void);
V g_heff_2esimplify_2etraverseS(V v_f_240, V v_x2_241);
V g_heff_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etraverseS_clo;
V g_heff_2esimplify_2eappendL(V v_x1_240, V v_ys_241);
V g_heff_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eappendL_clo;
V g_heff_2esimplify_2eelemStr(V v_x_240, V v_x2_241);
V g_heff_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eelemStr_clo;
V g_heff_2esimplify_2ezipL(V v_x1_240, V v_x2_241);
V g_heff_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ezipL_clo;
V g_heff_2esimplify_2etakeL(V v_n_240, V v_x2_241);
V g_heff_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etakeL_clo;
V g_heff_2esimplify_2edropL(V v_n_240, V v_x2_241);
V g_heff_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2edropL_clo;
V g_heff_2esimplify_2eletsOf(V v_x1_240, V v_body_241);
V g_heff_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletsOf_clo;
V g_heff_2esimplify_2eknown(V v_g_240, V v_s_241);
V g_heff_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknown_clo;
V g_heff_2esimplify_2etrying(V v_d_240, V v_s_241);
V g_heff_2esimplify_2etrying_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etrying_clo;
V g_heff_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242);
V g_heff_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eattempt_clo;
V g_heff_2esimplify_2efailing_get(void);
V g_heff_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242);
V g_heff_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epureIn_clo;
V g_heff_2esimplify_2eflat(V v_b_240);
V g_heff_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eflat_clo;
V g_heff_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242);
V g_heff_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esgFlat_clo;
V g_prelude_2efoldl_24s542(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s542_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s542_clo;
V g_heff_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242);
V g_heff_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epartialOf_clo;
V g_heff_2esimplify_2epartialIn(V v_s_240, V v_x2_241);
V g_heff_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epartialIn_clo;
V g_prelude_2emap_24s543(V v_x2_240);
V g_prelude_2emap_24s543_entry(V self, V *a);
extern Clo g_prelude_2emap_24s543_clo;
V g_heff_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242);
V g_heff_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eintOp_clo;
V g_heff_2esimplify_2eunOp(V v_p_240, V v_x2_241);
V g_heff_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eunOp_clo;
V g_heff_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242);
V g_heff_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ebinOp_clo;
V g_heff_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242);
V g_heff_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprimAppN_clo;
V g_heff_2esimplify_2emkApp(V v_f_240, V v_as_241);
V g_heff_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emkApp_clo;
V g_heff_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242);
V g_heff_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esubstCopies_clo;
V g_heff_2esimplify_2elam(V v_xs_240, V v_e_241);
V g_heff_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2elam_clo;
V g_heff_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244);
V g_heff_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletPure_clo;
V g_heff_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244);
V g_heff_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletIn_clo;
V g_heff_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242);
V g_heff_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etakesMore_clo;
V g_heff_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241);
V g_heff_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eparamsAre_clo;
V g_heff_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242);
V g_heff_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eetaHead_clo;
V g_heff_2esimplify_2eeta(V v_kinds_240, V v_e_241);
V g_heff_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eeta_clo;
V g_heff_2esimplify_2esimpF(V v_r_240, V v_e_241);
V g_heff_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esimpF_clo;
V g_prelude_2emap_24s544(V v_x2_240);
V g_prelude_2emap_24s544_entry(V self, V *a);
extern Clo g_prelude_2emap_24s544_clo;
V g_heff_2esimplify_2einlineMax_get(void);
V g_heff_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244);
V g_heff_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2einlineCall_clo;
V g_prelude_2efoldl_24s545(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s545_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s545_clo;
V g_prelude_2efoldl_24s546(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s546_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s546_clo;
V g_heff_2esimplify_2efreshParams(V v_k_240, V v_s_241);
V g_heff_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efreshParams_clo;
V g_heff_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242);
V g_heff_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eremember_clo;
V g_prelude_2emap_24s547(V v_x2_240);
V g_prelude_2emap_24s547_entry(V self, V *a);
extern Clo g_prelude_2emap_24s547_clo;
V g_heff_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244);
V g_heff_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eplainCall_clo;
V g_heff_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244);
V g_heff_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ecallOf_clo;
V g_heff_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243);
V g_heff_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eapplyLam_clo;
V g_heff_2esimplify_2evarsAre(V v_x1_240, V v_x2_241);
V g_heff_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2esimplify_2evarsAre_clo;
V g_heff_2esimplify_2especArgSize_get(void);
V g_heff_2esimplify_2especBodySize_get(void);
V g_heff_2esimplify_2especLimit_get(void);
V g_heff_2esimplify_2especDepth_get(void);
V g_heff_2esimplify_2eknownArg(V v_kinds_240, V v_x2_241);
V g_heff_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknownArg_clo;
V g_heff_2esimplify_2enthE(V v_i_240, V v_x2_241);
V g_heff_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2esimplify_2enthE_clo;
V g_heff_2esimplify_2emarkGo(V v_all_240, V v_as_241, V v_x3_242, V v_i_243);
V g_heff_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emarkGo_clo;
V g_prelude_2emap_24s548(V v_x2_240);
V g_prelude_2emap_24s548_entry(V self, V *a);
extern Clo g_prelude_2emap_24s548_clo;
V g_prelude_2ezipWith_24s549(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s549_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s549_clo;
V g_heff_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241);
V g_heff_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ekeepParams_clo;
V g_heff_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243);
V g_heff_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esubstMarked_clo;
V g_heff_2esimplify_2epushSpec(V v_k_240, V v_h_241, V v_s_242);
V g_heff_2esimplify_2epushSpec_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epushSpec_clo;
V g_heff_2esimplify_2epreKnown(V v_h_240, V v_b_241, V v_s_242);
V g_heff_2esimplify_2epreKnown_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epreKnown_clo;
V g_heff_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242);
V g_heff_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emarkSafe_clo;
V g_heff_2esimplify_2epopSpec(V v_h_240, V v_b_241, V v_s_242);
V g_heff_2esimplify_2epopSpec_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epopSpec_clo;
V g_heff_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_as_243, V v_lam1_244);
V g_heff_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especBody_clo;
V g_heff_2esimplify_2echeap(V v_safe_240, V v_x2_241);
V g_heff_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2esimplify_2echeap_clo;
V g_prelude_2efoldl_24s550(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s550_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s550_clo;
V g_heff_2esimplify_2elamsOut(V v_safe_240, V v_x2_241);
V g_heff_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2esimplify_2elamsOut_clo;
V g_heff_2esimplify_2estripLams(V v_zs_240, V v_e_241);
V g_heff_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2estripLams_clo;
V g_heff_2esimplify_2eraise(V v_e_240, V v_p_241);
V g_heff_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eraise_clo;
V g_heff_2esimplify_2emakeSpec(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_k_246, V v_s_247);
V g_heff_2esimplify_2emakeSpec_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emakeSpec_clo;
V g_prelude_2eany_24s551(V v_x2_240);
V g_prelude_2eany_24s551_entry(V self, V *a);
extern Clo g_prelude_2eany_24s551_clo;
V g_heff_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_s_246);
V g_heff_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especMarked_clo;
V g_heff_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245);
V g_heff_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especLam_clo;
V g_heff_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243);
V g_heff_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etrySpec_clo;
V g_heff_2esimplify_2estillCall(V v_g_240, V v_x2_241);
V g_heff_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2estillCall_clo;
V g_heff_2esimplify_2efieldIn(V v_l_240, V v_x2_241);
V g_heff_2esimplify_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efieldIn_clo;
V g_heff_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242);
V g_heff_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknownField_clo;
V g_heff_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242);
V g_heff_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eapplyToF_clo;
V g_heff_2esimplify_2efindField(V v_l_240, V v_x2_241);
V g_heff_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efindField_clo;
V g_heff_2esimplify_2eothersPure(V v_l_240, V v_x2_241);
V g_heff_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eothersPure_clo;
V g_heff_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_e_242);
V g_heff_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprojectF_clo;
V g_heff_2esimplify_2efindArm(V v_t_240, V v_x2_241);
V g_heff_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efindArm_clo;
V g_heff_2esimplify_2ecaseBudget_get(void);
V g_heff_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243);
V g_heff_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epushArm_clo;
V g_prelude_2eany_24s552(V v_x2_240);
V g_prelude_2eany_24s552_entry(V self, V *a);
extern Clo g_prelude_2eany_24s552_clo;
V g_heff_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243);
V g_heff_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ecaseOfCase_clo;
V g_heff_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242);
V g_heff_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ematchF_clo;
V g_heff_2esimplify_2esk_get(void);
V g_heff_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242);
V g_heff_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2esimplify_2erecordAll_clo;
V g_heff_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242);
V g_heff_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2esimplify_2erecordDef_clo;
V g_heff_2esimplify_2etakeMade(V v_s_240);
V g_heff_2esimplify_2etakeMade_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etakeMade_clo;
V g_heff_2esimplify_2eoneDef(V v_d_240, V v_s_241);
V g_heff_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eoneDef_clo;
V g_heff_2esimplify_2econcatDefs(V v_x1_240);
V g_heff_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2esimplify_2econcatDefs_clo;
V g_heff_2esimplify_2etraverseS_24s553(V v_x2_240, V v_p_241);
V g_heff_2esimplify_2etraverseS_24s553_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etraverseS_24s553_clo;
V g_heff_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241);
V g_heff_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esimplifyProgram_clo;
V g_heff_2eanf_2eelemA(V v_x_240, V v_x2_241);
V g_heff_2eanf_2eelemA_entry(V self, V *a);
extern Clo g_heff_2eanf_2eelemA_clo;
V g_heff_2eanf_2evalue(V v_e_240);
V g_heff_2eanf_2evalue_entry(V self, V *a);
extern Clo g_heff_2eanf_2evalue_clo;
V g_heff_2eanf_2eallA_24s554(V v_x2_240);
V g_heff_2eanf_2eallA_24s554_entry(V self, V *a);
extern Clo g_heff_2eanf_2eallA_24s554_clo;
V g_heff_2eanf_2eallA_24s555(V v_x2_240);
V g_heff_2eanf_2eallA_24s555_entry(V self, V *a);
extern Clo g_heff_2eanf_2eallA_24s555_clo;
V g_heff_2eanf_2einPlace(V v_e_240);
V g_heff_2eanf_2einPlace_entry(V self, V *a);
extern Clo g_heff_2eanf_2einPlace_clo;
V g_heff_2eanf_2ebindAs(V v_e_240, V v_k_241);
V g_heff_2eanf_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2eanf_2ebindAs_clo;
V g_heff_2eanf_2ebindAtom(V v_e_240, V v_k_241);
V g_heff_2eanf_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2eanf_2ebindAtom_clo;
V g_heff_2eanf_2eoperandsWith(V v_go_240, V v_x2_241, V v_k_242);
V g_heff_2eanf_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2eanf_2eoperandsWith_clo;
V g_heff_2eanf_2eflatLet(V v_x_240, V v_a_241, V v_b_242);
V g_heff_2eanf_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2eanf_2eflatLet_clo;
V g_heff_2eanf_2elastOf(V v_x1_240);
V g_heff_2eanf_2elastOf_entry(V self, V *a);
extern Clo g_heff_2eanf_2elastOf_clo;
V g_heff_2eanf_2einitOf(V v_x1_240);
V g_heff_2eanf_2einitOf_entry(V self, V *a);
extern Clo g_heff_2eanf_2einitOf_clo;
V g_heff_2eanf_2etagN(V v_go_240, V v_t_241, V v_as_242, V v_x4_243);
V g_heff_2eanf_2etagN_entry(V self, V *a);
extern Clo g_heff_2eanf_2etagN_clo;
V g_heff_2eanf_2eappendRight(V v_go_240, V v_e_241, V v_k_242);
V g_heff_2eanf_2eappendRight_entry(V self, V *a);
extern Clo g_heff_2eanf_2eappendRight_clo;
V g_heff_2eanf_2eprimN(V v_go_240, V v_p_241, V v_as_242);
V g_heff_2eanf_2eprimN_entry(V self, V *a);
extern Clo g_heff_2eanf_2eprimN_clo;
V g_prelude_2ezipWith_24s556(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s556_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s556_clo;
V g_heff_2eanf_2etraverseN_24s557(V v_x2_240);
V g_heff_2eanf_2etraverseN_24s557_entry(V self, V *a);
extern Clo g_heff_2eanf_2etraverseN_24s557_clo;
V g_heff_2eanf_2enorm(V v_e_240);
V g_heff_2eanf_2enorm_entry(V self, V *a);
extern Clo g_heff_2eanf_2enorm_clo;
V g_heff_2eanf_2etraverseN_24s558(V v_x2_240);
V g_heff_2eanf_2etraverseN_24s558_entry(V self, V *a);
extern Clo g_heff_2eanf_2etraverseN_24s558_clo;
V g_prelude_2efoldl_24s559(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s559_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s559_clo;
V g_heff_2earity_2etakeA(V v_n_240, V v_x2_241);
V g_heff_2earity_2etakeA_entry(V self, V *a);
extern Clo g_heff_2earity_2etakeA_clo;
V g_heff_2earity_2edropA(V v_n_240, V v_x2_241);
V g_heff_2earity_2edropA_entry(V self, V *a);
extern Clo g_heff_2earity_2edropA_clo;
V g_heff_2earity_2ecallOf(V v_r_240, V v_ar_241, V v_h_242, V v_as_243);
V g_heff_2earity_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2earity_2ecallOf_clo;
V g_heff_2earity_2esatGo(V v_r_240, V v_ar_241, V v_e_242);
V g_heff_2earity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2earity_2esatGo_clo;
V g_heff_2earity_2esatOf(V v_ar_240);
V g_heff_2earity_2esatOf_entry(V self, V *a);
extern Clo g_heff_2earity_2esatOf_clo;
V g_heff_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242);
V g_heff_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2eerase_2eextend_clo;
V g_heff_2eerase_2eisType(V v_lvl_240, V v_t_241);
V g_heff_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2eerase_2eisType_clo;
V g_heff_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243);
V g_heff_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2eerase_2eprojTyInWith_clo;
V g_heff_2eerase_2eprojWith(V v_x1_240, V v_v_241, V v_l_242);
V g_heff_2eerase_2eprojWith_entry(V self, V *a);
extern Clo g_heff_2eerase_2eprojWith_clo;
V g_heff_2eerase_2ematchVariants(V v_sty_240);
V g_heff_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2eerase_2ematchVariants_clo;
V g_heff_2eerase_2eargTysOf(V v_vs_240, V v_tag_241);
V g_heff_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2eerase_2eargTysOf_clo;
V g_heff_2eerase_2ezipE(V v_x1_240, V v_x2_241);
V g_heff_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2eerase_2ezipE_clo;
V g_heff_2eerase_2earmBindGo(V v_acc_240, V v_x2_241);
V g_heff_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmBindGo_clo;
V g_heff_2eerase_2enthLocal(V v_x1_240, V v_i_241);
V g_heff_2eerase_2enthLocal_entry(V self, V *a);
extern Clo g_heff_2eerase_2enthLocal_clo;
V g_heff_2eerase_2etraverseM(V v_f_240, V v_x2_241);
V g_heff_2eerase_2etraverseM_entry(V self, V *a);
extern Clo g_heff_2eerase_2etraverseM_clo;
V g_heff_2eerase_2ecatMaybesE(V v_x1_240);
V g_heff_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2eerase_2ecatMaybesE_clo;
V g_heff_2eerase_2echkDField_24s562(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244);
V g_heff_2eerase_2echkDField_24s562_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDField_24s562_clo;
V g_heff_2eerase_2echkDFields_24s561(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244);
V g_heff_2eerase_2echkDFields_24s561_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDFields_24s561_clo;
V g_heff_2eerase_2echkLam_24s564(V v_c_240, V v_abs_241, V v_ty_242);
V g_heff_2eerase_2echkLam_24s564_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkLam_24s564_clo;
V g_heff_2eerase_2echkFieldsGo_24s565(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244);
V g_heff_2eerase_2echkFieldsGo_24s565_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkFieldsGo_24s565_clo;
V g_heff_2eerase_2echkTagArg_24s566(V v_c_240, V v_x3_241);
V g_heff_2eerase_2echkTagArg_24s566_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkTagArg_24s566_clo;
V g_heff_2eerase_2earmOf_24s567(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243);
V g_heff_2eerase_2earmOf_24s567_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmOf_24s567_clo;
V g_heff_2eerase_2earmsTy_24s569(V v_c_240, V v_vs_241, V v_x4_242);
V g_heff_2eerase_2earmsTy_24s569_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmsTy_24s569_clo;
V g_heff_2eerase_2esynF_24s568(V v_c_240, V v_t_241);
V g_heff_2eerase_2esynF_24s568_entry(V self, V *a);
extern Clo g_heff_2eerase_2esynF_24s568_clo;
V g_heff_2eerase_2echkF_24s563(V v_c_240, V v_t_241, V v_ty_242);
V g_heff_2eerase_2echkF_24s563_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkF_24s563_clo;
V g_heff_2eerase_2echkDF_24s560(V v_c_240, V v_t_241, V v_ty_242, V v_v_243);
V g_heff_2eerase_2echkDF_24s560_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDF_24s560_clo;
V g_heff_2eerase_2eeraseOne(V v_g_240, V v_acc_241, V v_x3_242);
V g_heff_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2eerase_2eeraseOne_clo;
V g_heff_2eerase_2eeraseProgram(V v_g_240);
V g_heff_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2eerase_2eeraseProgram_clo;
V g_heff_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242);
V g_heff_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2elift_2efreeGo_clo;
V g_heff_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242);
V g_heff_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2elift_2ereplaceGo_clo;
V g_heff_2elift_2eliftMany(V v_k_240, V v_d_241, V v_acc_242, V v_x4_243);
V g_heff_2elift_2eliftMany_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftMany_clo;
V g_prelude_2ezipWith_24s570(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s570_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s570_clo;
V g_heff_2elift_2ewithParams(V v_fvs_240, V v_b_241);
V g_heff_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2elift_2ewithParams_clo;
V g_heff_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244);
V g_heff_2elift_2eliftedDef_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftedDef_clo;
V g_heff_2elift_2eliftFixDef(V v_k_240, V v_acc_241, V v_fvs_242, V v_ld_243);
V g_heff_2elift_2eliftFixDef_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_clo;
V g_heff_2elift_2eliftFix(V v_k_240, V v_d_241, V v_acc_242, V v_f_243, V v_body_244);
V g_heff_2elift_2eliftFix_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_clo;
V g_heff_2elift_2eoneParam(V v_e_240);
V g_heff_2elift_2eoneParam_entry(V self, V *a);
extern Clo g_heff_2elift_2eoneParam_clo;
V g_heff_2elift_2eliftRedex(V v_k_240, V v_d_241, V v_acc_242, V v_x_243, V v_b_244, V v_a_245);
V g_heff_2elift_2eliftRedex_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_clo;
V g_heff_2elift_2eliftApp(V v_k_240, V v_d_241, V v_acc_242, V v_f_243, V v_as_244);
V g_heff_2elift_2eliftApp_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_clo;
V g_heff_2elift_2eliftGo(V v_k_240, V v_d_241, V v_acc_242, V v_e_243);
V g_heff_2elift_2eliftGo_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_clo;
V g_heff_2elift_2elk_get(void);
V g_heff_2elift_2eliftFixDef_24s578(V v_acc_240, V v_fvs_241, V v_ld_242);
V g_heff_2elift_2eliftFixDef_24s578_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_24s578_clo;
V g_heff_2elift_2eliftFix_24s577(V v_d_240, V v_acc_241, V v_f_242, V v_body_243);
V g_heff_2elift_2eliftFix_24s577_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_24s577_clo;
V g_heff_2elift_2eliftRedex_24s576(V v_d_240, V v_acc_241, V v_x_242, V v_b_243, V v_a_244);
V g_heff_2elift_2eliftRedex_24s576_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_24s576_clo;
V g_heff_2elift_2eliftApp_24s575(V v_d_240, V v_acc_241, V v_f_242, V v_as_243);
V g_heff_2elift_2eliftApp_24s575_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_24s575_clo;
V g_heff_2elift_2eliftGo_24s574(V v_d_240, V v_acc_241, V v_e_242);
V g_heff_2elift_2eliftGo_24s574_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s574_clo;
V g_heff_2elift_2eliftMany_24s573(V v_d_240, V v_acc_241, V v_x4_242);
V g_heff_2elift_2eliftMany_24s573_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftMany_24s573_clo;
V g_heff_2elift_2eliftGo_24s592(V v_d_240, V v_e_241);
V g_heff_2elift_2eliftGo_24s592_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s592_clo;
V g_heff_2elift_2eliftFixDef_24s591(V v_fvs_240, V v_ld_241);
V g_heff_2elift_2eliftFixDef_24s591_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_24s591_clo;
V g_heff_2elift_2eliftFix_24s590(V v_d_240, V v_f_241, V v_body_242);
V g_heff_2elift_2eliftFix_24s590_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_24s590_clo;
V g_heff_2elift_2eliftRedex_24s589(V v_d_240, V v_x_241, V v_b_242, V v_a_243);
V g_heff_2elift_2eliftRedex_24s589_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_24s589_clo;
V g_heff_2elift_2eliftApp_24s588(V v_d_240, V v_f_241, V v_as_242);
V g_heff_2elift_2eliftApp_24s588_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_24s588_clo;
V g_heff_2elift_2eliftGo_24s587(V v_d_240, V v_e_241);
V g_heff_2elift_2eliftGo_24s587_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s587_clo;
V g_heff_2elift_2eliftFixDef_24s586(V v_fvs_240, V v_ld_241);
V g_heff_2elift_2eliftFixDef_24s586_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_24s586_clo;
V g_heff_2elift_2eliftFix_24s585(V v_d_240, V v_f_241, V v_body_242);
V g_heff_2elift_2eliftFix_24s585_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_24s585_clo;
V g_heff_2elift_2eliftRedex_24s584(V v_d_240, V v_x_241, V v_b_242, V v_a_243);
V g_heff_2elift_2eliftRedex_24s584_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_24s584_clo;
V g_heff_2elift_2eliftApp_24s583(V v_d_240, V v_f_241, V v_as_242);
V g_heff_2elift_2eliftApp_24s583_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_24s583_clo;
V g_heff_2elift_2eliftGo_24s582(V v_d_240, V v_e_241);
V g_heff_2elift_2eliftGo_24s582_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s582_clo;
V g_heff_2elift_2eliftFixDef_24s581(V v_fvs_240, V v_ld_241);
V g_heff_2elift_2eliftFixDef_24s581_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_24s581_clo;
V g_heff_2elift_2eliftFix_24s580(V v_d_240, V v_f_241, V v_body_242);
V g_heff_2elift_2eliftFix_24s580_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_24s580_clo;
V g_heff_2elift_2eliftRedex_24s579(V v_d_240, V v_x_241, V v_b_242, V v_a_243);
V g_heff_2elift_2eliftRedex_24s579_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_24s579_clo;
V g_heff_2elift_2eliftApp_24s572(V v_d_240, V v_f_241, V v_as_242);
V g_heff_2elift_2eliftApp_24s572_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_24s572_clo;
V g_heff_2elift_2eliftGo_24s571(V v_d_240, V v_e_241);
V g_heff_2elift_2eliftGo_24s571_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s571_clo;
V g_prelude_2efoldl_24s594(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s594_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s594_clo;
V g_prelude_2econcatMap_24s593(V v_xs_240);
V g_prelude_2econcatMap_24s593_entry(V self, V *a);
extern Clo g_prelude_2econcatMap_24s593_clo;
V g_prelude_2efoldl_24s595(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s595_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s595_clo;
V g_heff_2eshake_2eappendK(V v_x1_240, V v_ys_241);
V g_heff_2eshake_2eappendK_entry(V self, V *a);
extern Clo g_heff_2eshake_2eappendK_clo;
V g_heff_2eshake_2ereachGo(V v_bodies_240, V v_seen_241, V v_x3_242);
V g_heff_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2eshake_2ereachGo_clo;
V g_heff_2elower_2elowerSimplified(V v_roots_240, V v_errors_241, V v_si_242);
V g_heff_2elower_2elowerSimplified_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerSimplified_clo;
V g_heff_2elower_2elowerErased(V v_roots_240, V v_er_241);
V g_heff_2elower_2elowerErased_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerErased_clo;
V g_heff_2elower_2eentryKey_get(void);
V g_heff_2elower_2eentryBody(V v_key_240, V v_n_241);
V g_heff_2elower_2eentryBody_entry(V self, V *a);
extern Clo g_heff_2elower_2eentryBody_clo;
V g_heff_2elower_2elowerProgram(V v_g_240, V v_key_241);
V g_heff_2elower_2elowerProgram_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerProgram_clo;
V g_heff_2elower_2eanfKept(V v_supply_240, V v_kept_241, V v_errors_242);
V g_heff_2elower_2eanfKept_entry(V self, V *a);
extern Clo g_heff_2elower_2eanfKept_clo;
V g_heff_2elower_2eanfSimplified(V v_roots_240, V v_errors_241, V v_si_242);
V g_heff_2elower_2eanfSimplified_entry(V self, V *a);
extern Clo g_heff_2elower_2eanfSimplified_clo;
V g_heff_2elower_2eanfLowered(V v_roots_240, V v_er_241);
V g_heff_2elower_2eanfLowered_entry(V self, V *a);
extern Clo g_heff_2elower_2eanfLowered_clo;
V g_heff_2elower_2elowerProgramAnf(V v_g_240, V v_key_241);
V g_heff_2elower_2elowerProgramAnf_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerProgramAnf_clo;
V g_heff_2eemit_2ecatMaybesL(V v_x1_240);
V g_heff_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecatMaybesL_clo;
V g_heff_2eemit_2enubGo(V v_seen_240, V v_x2_241);
V g_heff_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2enubGo_clo;
V g_heff_2eemit_2eunsnocGo(V v_x1_240, V v_y_241);
V g_heff_2eemit_2eunsnocGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eunsnocGo_clo;
V g_heff_2eemit_2eescAt(V v_s_240, V v_i_241);
V g_heff_2eemit_2eescAt_entry(V self, V *a);
extern Clo g_heff_2eemit_2eescAt_clo;
V g_heff_2eemit_2equoteGo(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2equoteGo_clo;
V g_heff_2eemit_2ewordOf(V v_c_240);
V g_heff_2eemit_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ewordOf_clo;
V g_heff_2eemit_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242);
V g_heff_2eemit_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eoperatorGo_clo;
V g_heff_2eemit_2elastDotFrom(V v_s_240, V v_i_241);
V g_heff_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastDotFrom_clo;
V g_heff_2eemit_2espellAt(V v_k_240, V v_x2_241);
V g_heff_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2eemit_2espellAt_clo;
V g_heff_2eemit_2ereserved_get(void);
V g_heff_2eemit_2eisWordCode(V v_c_240);
V g_heff_2eemit_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2eemit_2eisWordCode_clo;
V g_heff_2eemit_2esafeChars(V v_x_240, V v_i_241, V v_acc_242);
V g_heff_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeChars_clo;
V g_heff_2eemit_2esafeRes(V v_s_240);
V g_heff_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeRes_clo;
V g_heff_2eemit_2eisIdent(V v_x_240);
V g_heff_2eemit_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2eemit_2eisIdent_clo;
V g_prelude_2efoldl_24s596(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s596_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s596_clo;
V g_prelude_2efoldl_24s597(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s597_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s597_clo;
V g_prelude_2efoldl_24s598(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s598_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s598_clo;
V g_heff_2eemit_2evalueRefs(V v_e_240);
V g_heff_2eemit_2evalueRefs_entry(V self, V *a);
extern Clo g_heff_2eemit_2evalueRefs_clo;
V g_prelude_2eany_24s599(V v_x2_240);
V g_prelude_2eany_24s599_entry(V self, V *a);
extern Clo g_prelude_2eany_24s599_clo;
V g_heff_2eemit_2etailApp(V v_e_240);
V g_heff_2eemit_2etailApp_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailApp_clo;
V g_prelude_2efoldl_24s600(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s600_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s600_clo;
V g_heff_2eemit_2etailGlobals(V v_e_240);
V g_heff_2eemit_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailGlobals_clo;
V g_heff_2eemit_2ebodyBounces(V v_set_240, V v_d_241);
V g_heff_2eemit_2ebodyBounces_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebodyBounces_clo;
V g_heff_2eemit_2ebounceGo(V v_defs_240, V v_set_241);
V g_heff_2eemit_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebounceGo_clo;
V g_heff_2eemit_2eappendEnd(V v_key_240, V v_n_241, V v_e_242);
V g_heff_2eemit_2eappendEnd_entry(V self, V *a);
extern Clo g_heff_2eemit_2eappendEnd_clo;
V g_heff_2eemit_2eappendSelf(V v_key_240, V v_n_241, V v_e_242);
V g_heff_2eemit_2eappendSelf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eappendSelf_clo;
V g_heff_2eemit_2econsLast(V v_key_240, V v_n_241, V v_x3_242);
V g_heff_2eemit_2econsLast_entry(V self, V *a);
extern Clo g_heff_2eemit_2econsLast_clo;
V g_heff_2eemit_2econsSelf(V v_key_240, V v_n_241, V v_e_242);
V g_heff_2eemit_2econsSelf_entry(V self, V *a);
extern Clo g_heff_2eemit_2econsSelf_clo;
V g_heff_2eemit_2etailSelf(V v_key_240, V v_n_241, V v_e_242);
V g_heff_2eemit_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailSelf_clo;
V g_heff_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243);
V g_heff_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebindFrom_clo;
V g_heff_2eemit_2ebindName(V v_env_240, V v_x_241);
V g_heff_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebindName_clo;
V g_prelude_2efoldl_24s601(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s601_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s601_clo;
V g_heff_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242);
V g_heff_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimBin_clo;
V g_heff_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242);
V g_heff_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimTest_clo;
V g_prelude_2emap_24s602(V v_x2_240);
V g_prelude_2emap_24s602_entry(V self, V *a);
extern Clo g_prelude_2emap_24s602_clo;
V g_heff_2eemit_2eprimOp(V v_x1_240);
V g_heff_2eemit_2eprimOp_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimOp_clo;
V g_heff_2eemit_2eprimUnary(V v_x1_240);
V g_heff_2eemit_2eprimUnary_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimUnary_clo;
V g_heff_2eemit_2eprimCall(V v_p_240, V v_as_241);
V g_heff_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimCall_clo;
V g_heff_2eemit_2econdIf(V v_c_240, V v_t_241, V v_e_242);
V g_heff_2eemit_2econdIf_entry(V self, V *a);
extern Clo g_heff_2eemit_2econdIf_clo;
V g_heff_2eemit_2econdCode(V v_p_240);
V g_heff_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2eemit_2econdCode_clo;
V g_heff_2eemit_2eseqsOf(V v_p_240);
V g_heff_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eseqsOf_clo;
V g_heff_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241);
V g_heff_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2eemit_2eletDeclarations_clo;
V g_heff_2eemit_2eprimRel(V v_x1_240);
V g_heff_2eemit_2eprimRel_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimRel_clo;
V g_heff_2eemit_2earmNamed(V v_t_240, V v_x2_241);
V g_heff_2eemit_2earmNamed_entry(V self, V *a);
extern Clo g_heff_2eemit_2earmNamed_clo;
V g_heff_2eemit_2econdShaped(V v_e_240);
V g_heff_2eemit_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2eemit_2econdShaped_clo;
V g_heff_2eemit_2ecallName(V v_env_240, V v_g_241);
V g_heff_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecallName_clo;
V g_prelude_2emap_24s603(V v_x2_240);
V g_prelude_2emap_24s603_entry(V self, V *a);
extern Clo g_prelude_2emap_24s603_clo;
V g_heff_2eemit_2eisUnitArgs(V v_x1_240);
V g_heff_2eemit_2eisUnitArgs_entry(V self, V *a);
extern Clo g_heff_2eemit_2eisUnitArgs_clo;
V g_heff_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243);
V g_heff_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2edeclsOf_clo;
V g_heff_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242);
V g_heff_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2esharedGo_clo;
V g_heff_2eemit_2estmtsReturnCond(V v_ind_240, V v_c_241);
V g_heff_2eemit_2estmtsReturnCond_entry(V self, V *a);
extern Clo g_heff_2eemit_2estmtsReturnCond_clo;
V g_heff_2eemit_2ebounceDepth_get(void);
V g_heff_2eemit_2eatomGo(V v_c_240, V v_i_241);
V g_heff_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eatomGo_clo;
V g_heff_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242);
V g_heff_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2eemit_2enamedAs_clo;
V g_heff_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243);
V g_heff_2eemit_2enamed_entry(V self, V *a);
extern Clo g_heff_2eemit_2enamed_clo;
V g_heff_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242);
V g_heff_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebounceGive_clo;
V g_heff_2eemit_2enamed_24s604(V v_env_240, V v_ind_241, V v_base_242);
V g_heff_2eemit_2enamed_24s604_entry(V self, V *a);
extern Clo g_heff_2eemit_2enamed_24s604_clo;
V g_heff_2eemit_2ewrapper(V v_curried_240, V v_key_241, V v_i_242, V v_js_243);
V g_heff_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2eemit_2ewrapper_clo;
V g_prelude_2emap_24s605(V v_x2_240);
V g_prelude_2emap_24s605_entry(V self, V *a);
extern Clo g_prelude_2emap_24s605_clo;
V g_prelude_2ezipWith_24s606(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s606_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s606_clo;
V g_heff_2eemit_2estmtsLet2_24s608(V v_ind_240, V v_b_241, V v_ac_242, V v_nb_243);
V g_heff_2eemit_2estmtsLet2_24s608_entry(V self, V *a);
extern Clo g_heff_2eemit_2estmtsLet2_24s608_clo;
V g_heff_2eemit_2epredOfPrim_24s614(V v_env_240, V v_ind_241, V v_e_242, V v_p_243, V v_as_244);
V g_heff_2eemit_2epredOfPrim_24s614_entry(V self, V *a);
extern Clo g_heff_2eemit_2epredOfPrim_24s614_clo;
V g_heff_2eemit_2epredOf_24s613(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2epredOf_24s613_entry(V self, V *a);
extern Clo g_heff_2eemit_2epredOf_24s613_clo;
V g_heff_2eemit_2eblockF_24s615(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2eblockF_24s615_entry(V self, V *a);
extern Clo g_heff_2eemit_2eblockF_24s615_clo;
V g_heff_2eemit_2eexprTest_24s612(V v_env_240, V v_ind_241, V v_e_242, V v_s_243, V v_t_244, V v_f_245);
V g_heff_2eemit_2eexprTest_24s612_entry(V self, V *a);
extern Clo g_heff_2eemit_2eexprTest_24s612_clo;
V g_heff_2eemit_2ebodyF_24s616(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2ebodyF_24s616_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebodyF_24s616_clo;
V g_heff_2eemit_2eexprGo_24s611(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2eexprGo_24s611_entry(V self, V *a);
extern Clo g_heff_2eemit_2eexprGo_24s611_clo;
V g_heff_2eemit_2escrutBound_24s610(V v_env_240, V v_ind_241, V v_s_242, V v_b_243);
V g_heff_2eemit_2escrutBound_24s610_entry(V self, V *a);
extern Clo g_heff_2eemit_2escrutBound_24s610_clo;
V g_heff_2eemit_2escrutOf_24s609(V v_env_240, V v_ind_241, V v_s_242);
V g_heff_2eemit_2escrutOf_24s609_entry(V self, V *a);
extern Clo g_heff_2eemit_2escrutOf_24s609_clo;
V g_heff_2eemit_2earmBound_24s619(V v_sc_240, V v_ind_241, V v_tag_242, V v_bdy_243, V v_rb_244);
V g_heff_2eemit_2earmBound_24s619_entry(V self, V *a);
extern Clo g_heff_2eemit_2earmBound_24s619_clo;
V g_heff_2eemit_2earmJs_24s618(V v_sc_240, V v_ind_241, V v_x4_242);
V g_heff_2eemit_2earmJs_24s618_entry(V self, V *a);
extern Clo g_heff_2eemit_2earmJs_24s618_clo;
V g_heff_2eemit_2estmtsMatch2_24s617(V v_ind_240, V v_arms_241, V v_sc_242);
V g_heff_2eemit_2estmtsMatch2_24s617_entry(V self, V *a);
extern Clo g_heff_2eemit_2estmtsMatch2_24s617_clo;
V g_heff_2eemit_2estmtsIf_24s620(V v_env_240, V v_ind_241, V v_c_242, V v_t_243, V v_f_244);
V g_heff_2eemit_2estmtsIf_24s620_entry(V self, V *a);
extern Clo g_heff_2eemit_2estmtsIf_24s620_clo;
V g_heff_2eemit_2ereturnLines_24s621(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2ereturnLines_24s621_entry(V self, V *a);
extern Clo g_heff_2eemit_2ereturnLines_24s621_clo;
V g_heff_2eemit_2elastTrmc_24s624(V v_env_240, V v_ind_241, V v_e_242, V v_rr_243);
V g_heff_2eemit_2elastTrmc_24s624_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastTrmc_24s624_clo;
V g_heff_2eemit_2elastOther_24s623(V v_env_240, V v_s_241, V v_ind_242, V v_e_243);
V g_heff_2eemit_2elastOther_24s623_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastOther_24s623_clo;
V g_heff_2eemit_2eagain_24s627(V v_env_240, V v_s_241, V v_ind_242, V v_as_243);
V g_heff_2eemit_2eagain_24s627_entry(V self, V *a);
extern Clo g_heff_2eemit_2eagain_24s627_clo;
V g_heff_2eemit_2elastCell_24s626(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_ini_244, V v_bs_245, V v_rr_246);
V g_heff_2eemit_2elastCell_24s626_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastCell_24s626_clo;
V g_heff_2eemit_2elastTag_24s625(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_as_244, V v_x7_245);
V g_heff_2eemit_2elastTag_24s625_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastTag_24s625_clo;
V g_heff_2eemit_2elastSelf_24s622(V v_env_240, V v_s_241, V v_ind_242, V v_e_243);
V g_heff_2eemit_2elastSelf_24s622_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastSelf_24s622_clo;
V g_heff_2eemit_2estmtsF_24s607(V v_env_240, V v_ind_241, V v_e_242);
V g_heff_2eemit_2estmtsF_24s607_entry(V self, V *a);
extern Clo g_heff_2eemit_2estmtsF_24s607_clo;
V g_heff_2eemit_2elooped(V v_key_240, V v_i_241, V v_b_242, V v_r_243, V v_trmc_244, V v_sapp_245);
V g_heff_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2eemit_2elooped_clo;
V g_heff_2eemit_2edefFun(V v_curried_240, V v_key_241, V v_i_242, V v_xs_243, V v_b_244, V v_r_245);
V g_heff_2eemit_2edefFun_entry(V self, V *a);
extern Clo g_heff_2eemit_2edefFun_clo;
V g_heff_2eemit_2edefBody(V v_gs_240, V v_curried_241, V v_globalNames_242, V v_d_243, V v_i_244);
V g_heff_2eemit_2edefBody_entry(V self, V *a);
extern Clo g_heff_2eemit_2edefBody_clo;
V g_heff_2eemit_2etrampolineStr_get(void);
V g_heff_2eemit_2eextStr_get(void);
V g_heff_2eemit_2eruntime(V v_code_240);
V g_heff_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2eemit_2eruntime_clo;
V g_heff_2eemit_2euncurryGo(V v_ps_240, V v_s_241);
V g_heff_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2euncurryGo_clo;
V g_prelude_2efoldl_24s628(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s628_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s628_clo;
V g_prelude_2efoldl_24s629(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s629_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s629_clo;
V g_heff_2eemit_2eprimUses(V v_m_240, V v_e_241);
V g_heff_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimUses_clo;
V g_heff_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242);
V g_heff_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimHelperU_clo;
V g_prelude_2efoldl_24s630(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s630_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s630_clo;
V g_heff_2eemit_2eprimHelpers(V v_defs_240);
V g_heff_2eemit_2eprimHelpers_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimHelpers_clo;
V g_prelude_2emap_24s631(V v_x2_240);
V g_prelude_2emap_24s631_entry(V self, V *a);
extern Clo g_prelude_2emap_24s631_clo;
V g_heff_2eemit_2ejsPick(V v_shorts_240, V v_key_241, V v_s_242);
V g_heff_2eemit_2ejsPick_entry(V self, V *a);
extern Clo g_heff_2eemit_2ejsPick_clo;
V g_heff_2eemit_2ejsNameOf(V v_shorts_240, V v_key_241);
V g_heff_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ejsNameOf_clo;
V g_heff_2eemit_2elazyOf(V v_acc_240, V v_key_241, V v_b_242, V v_ar_243);
V g_heff_2eemit_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2elazyOf_clo;
V g_heff_2eemit_2einfoOne(V v_shorts_240, V v_bnc_241, V v_acc_242, V v_d_243);
V g_heff_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2eemit_2einfoOne_clo;
V g_prelude_2efoldl_24s632(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s632_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s632_clo;
V g_heff_2eemit_2eemitCode(V v_defs_240, V v_info_241, V v_curried_242, V v_globalNames_243);
V g_heff_2eemit_2eemitCode_entry(V self, V *a);
extern Clo g_heff_2eemit_2eemitCode_clo;
V g_prelude_2efoldl_24s633(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s633_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s633_clo;
V g_heff_2eemit_2eemitWithShorts(V v_defs_240, V v_roots_241, V v_shorts_242);
V g_heff_2eemit_2eemitWithShorts_entry(V self, V *a);
extern Clo g_heff_2eemit_2eemitWithShorts_clo;
V g_heff_2eemit_2erunStr_get(void);
V g_heff_2eemit_2esumStr_get(void);
V g_heff_2eemit_2eexportNameOf(V v_l_240);
V g_heff_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eexportNameOf_clo;
V g_prelude_2efilter_24s634(V v_x2_240);
V g_prelude_2efilter_24s634_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s634_clo;
V g_prelude_2emap_24s635(V v_x2_240);
V g_prelude_2emap_24s635_entry(V self, V *a);
extern Clo g_prelude_2emap_24s635_clo;
V g_heff_2eemit_2ehostLineOf(V v_l_240);
V g_heff_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ehostLineOf_clo;
V g_prelude_2emap_24s636(V v_x2_240);
V g_prelude_2emap_24s636_entry(V self, V *a);
extern Clo g_prelude_2emap_24s636_clo;
V g_prelude_2emap_24s637(V v_x2_240);
V g_prelude_2emap_24s637_entry(V self, V *a);
extern Clo g_prelude_2emap_24s637_clo;
V g_prelude_2efilter_24s638(V v_x2_240);
V g_prelude_2efilter_24s638_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s638_clo;
V g_heff_2eemit_2ebundleProvider(V v_i_240, V v_p_241);
V g_heff_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebundleProvider_clo;
V g_heff_2eemit_2ebundleAll(V v_i_240, V v_x2_241);
V g_heff_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebundleAll_clo;
V g_heff_2eemit_2eruntimeFor(V v_hasTr_240, V v_provs_241, V v_eff_242);
V g_heff_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2eemit_2eruntimeFor_clo;
V g_heff_2eemit_2eprovIndexGo(V v_i_240, V v_md_241, V v_x3_242);
V g_heff_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprovIndexGo_clo;
V g_heff_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241);
V g_heff_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ehandlerOf_clo;
V g_heff_2eemit_2efindProv(V v_md_240, V v_x2_241);
V g_heff_2eemit_2efindProv_entry(V self, V *a);
extern Clo g_heff_2eemit_2efindProv_clo;
V g_heff_2eemit_2eprovsForGo(V v_available_240, V v_x2_241);
V g_heff_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprovsForGo_clo;
V g_prelude_2emap_24s639(V v_x2_240);
V g_prelude_2emap_24s639_entry(V self, V *a);
extern Clo g_prelude_2emap_24s639_clo;
V g_prelude_2efilter_24s640(V v_x2_240);
V g_prelude_2efilter_24s640_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s640_clo;
V g_heff_2eemit_2eimportLinesOf(V v_x1_240);
V g_heff_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eimportLinesOf_clo;
V g_heff_2eemit_2enodeHead_get(void);
V g_heff_2eemit_2enodeRun(V v_run_240);
V g_heff_2eemit_2enodeRun_entry(V self, V *a);
extern Clo g_heff_2eemit_2enodeRun_clo;
V g_prelude_2eany_24s641(V v_x2_240);
V g_prelude_2eany_24s641_entry(V self, V *a);
extern Clo g_prelude_2eany_24s641_clo;
V g_heff_2eemit_2erunSource(V v_host_240, V v_provs_241, V v_eff_242, V v_key_243, V v_m_244);
V g_heff_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2eemit_2erunSource_clo;
V g_heff_2eemit_2ecompileProgram(V v_host_240, V v_available_241, V v_g_242, V v_key_243, V v_eff_244);
V g_heff_2eemit_2ecompileProgram_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecompileProgram_clo;
V g_heff_2eemit_2egetterOf(V v_gs_240, V v_o_241);
V g_heff_2eemit_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2egetterOf_clo;
V g_heff_2eemit_2ejsSource(V v_exports_240, V v_m_241);
V g_heff_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2eemit_2ejsSource_clo;
V g_heff_2eemit_2ecompileJsWith(V v_g_240, V v_exports_241);
V g_heff_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecompileJsWith_clo;
V g_prelude_2emap_24s642(V v_x2_240);
V g_prelude_2emap_24s642_entry(V self, V *a);
extern Clo g_prelude_2emap_24s642_clo;
V g_heff_2eemit_2ecompileJs(V v_g_240, V v_exports0_241);
V g_heff_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecompileJs_clo;
V g_heff_2eemitc_2eisAlnum(V v_c_240);
V g_heff_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eisAlnum_clo;
V g_heff_2eemitc_2emangleChar(V v_c_240);
V g_heff_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleChar_clo;
V g_heff_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243);
V g_heff_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleW_clo;
V g_heff_2eemitc_2eknownTags_get(void);
V g_heff_2eemitc_2eelemS(V v_x_240, V v_x2_241);
V g_heff_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemS_clo;
V g_prelude_2emap_24s643(V v_x2_240);
V g_prelude_2emap_24s643_entry(V self, V *a);
extern Clo g_prelude_2emap_24s643_clo;
V g_prelude_2emap_24s644(V v_x2_240);
V g_prelude_2emap_24s644_entry(V self, V *a);
extern Clo g_prelude_2emap_24s644_clo;
V g_prelude_2efoldl_24s645(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s645_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s645_clo;
V g_heff_2eemitc_2etagsLbls(V v_x1_240);
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etagsLbls_clo;
V g_heff_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242);
V g_heff_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eidentAt_clo;
V g_heff_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243);
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enamesInGo_clo;
V g_heff_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242);
V g_heff_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enumbered_clo;
V g_heff_2eemitc_2etraverseC(V v_f_240, V v_x2_241);
V g_heff_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etraverseC_clo;
V g_heff_2eemitc_2estrDef(V v_name_240, V v_str_241);
V g_heff_2eemitc_2estrDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estrDef_clo;
V g_heff_2eemitc_2estrLit(V v_str_240, V v_s_241);
V g_heff_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estrLit_clo;
V g_heff_2eemitc_2eshapeLit(V v_ids_240, V v_s_241);
V g_heff_2eemitc_2eshapeLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eshapeLit_clo;
V g_heff_2eemitc_2eprimLit(V v_p_240, V v_s_241);
V g_heff_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimLit_clo;
V g_heff_2eemitc_2enewLam(V v_s_240);
V g_heff_2eemitc_2enewLam_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enewLam_clo;
V g_heff_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242);
V g_heff_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eaddLam_clo;
V g_prelude_2efoldl_24s646(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s646_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s646_clo;
V g_heff_2eemitc_2efvW(V v_bs_240, V v_ms_241, V v_x3_242);
V g_heff_2eemitc_2efvW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efvW_clo;
V g_heff_2eemitc_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243);
V g_heff_2eemitc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeGo_clo;
V g_heff_2eemitc_2efreeOf(V v_xs_240, V v_b_241);
V g_heff_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeOf_clo;
V g_prelude_2efoldl_24s647(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s647_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s647_clo;
V g_heff_2eemitc_2evarUse(V v_lent_240, V v_live_241, V v_x_242);
V g_heff_2eemitc_2evarUse_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evarUse_clo;
V g_prelude_2emap_24s648(V v_x2_240);
V g_prelude_2emap_24s648_entry(V self, V *a);
extern Clo g_prelude_2emap_24s648_clo;
V g_heff_2eemitc_2eelemI(V v_i_240, V v_x2_241);
V g_heff_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemI_clo;
V g_heff_2eemitc_2elentVar(V v_ce_240, V v_live_241, V v_x_242);
V g_heff_2eemitc_2elentVar_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentVar_clo;
V g_prelude_2eall_24s649(V v_x2_240);
V g_prelude_2eall_24s649_entry(V self, V *a);
extern Clo g_prelude_2eall_24s649_clo;
V g_prelude_2emap_24s650(V v_x2_240);
V g_prelude_2emap_24s650_entry(V self, V *a);
extern Clo g_prelude_2emap_24s650_clo;
V g_prelude_2ezipWith_24s651(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s651_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s651_clo;
V g_prelude_2efoldl_24s652(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s652_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s652_clo;
V g_prelude_2efoldl_24s653(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s653_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s653_clo;
V g_heff_2eemitc_2ecallText(V v_g_240, V v_tr_241, V v_ls_242);
V g_heff_2eemitc_2ecallText_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecallText_clo;
V g_prelude_2ezipWith_24s654(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s654_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s654_clo;
V g_prelude_2ezipWith_24s655(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s655_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s655_clo;
V g_heff_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_dead_243, V v_body_244);
V g_heff_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamLines_clo;
V g_heff_2eemitc_2ereusePrim_get(void);
V g_prelude_2ezipWith_24s656(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s656_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s656_clo;
V g_prelude_2ezipWith_24s657(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s657_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s657_clo;
V g_heff_2eemitc_2eagain(V v_ce_240, V v_vs_241);
V g_heff_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eagain_clo;
V g_heff_2eemitc_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243);
V g_heff_2eemitc_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etakenFv_clo;
V g_heff_2eemitc_2efieldLine(V v_sv_240, V v_plain_241, V v_used_242, V v_x4_243);
V g_heff_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efieldLine_clo;
V g_heff_2eemitc_2epow2(V v_n_240);
V g_heff_2eemitc_2epow2_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epow2_clo;
V g_heff_2eemitc_2efieldMask(V v_used_240, V v_i_241, V v_x3_242);
V g_heff_2eemitc_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efieldMask_clo;
V g_heff_2eemitc_2ereuseArgs(V v_go_240, V v_es_241);
V g_heff_2eemitc_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseArgs_clo;
V g_heff_2eemitc_2eletReuse(V v_go_240, V v_x_241, V v_a_242, V v_b_243, V v_x5_244);
V g_heff_2eemitc_2eletReuse_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eletReuse_clo;
V g_prelude_2eany_24s658(V v_x2_240);
V g_prelude_2eany_24s658_entry(V self, V *a);
extern Clo g_prelude_2eany_24s658_clo;
V g_heff_2eemitc_2ereuseIn(V v_ru_240, V v_n_241, V v_e_242);
V g_heff_2eemitc_2ereuseIn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseIn_clo;
V g_heff_2eemitc_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243);
V g_heff_2eemitc_2ereusing_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereusing_clo;
V g_prelude_2ezipWith_24s659(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s659_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s659_clo;
V g_prelude_2efoldl_24s660(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s660_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s660_clo;
V g_prelude_2emap_24s661(V v_x2_240);
V g_prelude_2emap_24s661_entry(V self, V *a);
extern Clo g_prelude_2emap_24s661_clo;
V g_heff_2eemitc_2eparamsAt(V v_want_240, V v_bi_241, V v_xs_242);
V g_heff_2eemitc_2eparamsAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eparamsAt_clo;
V g_prelude_2emap_24s662(V v_x2_240);
V g_prelude_2emap_24s662_entry(V self, V *a);
extern Clo g_prelude_2emap_24s662_clo;
V g_prelude_2emap_24s663(V v_x2_240);
V g_prelude_2emap_24s663_entry(V self, V *a);
extern Clo g_prelude_2emap_24s663_clo;
V g_heff_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242);
V g_heff_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eentryCall_clo;
V g_heff_2eemitc_2elamBody_24s668(V v_ce_240, V v_xs_241, V v_b_242, V v_fv_243);
V g_heff_2eemitc_2elamBody_24s668_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamBody_24s668_clo;
V g_heff_2eemitc_2elamWith_24s667(V v_ce_240, V v_live_241, V v_xs_242, V v_b_243, V v_fv_244, V v_s_245);
V g_heff_2eemitc_2elamWith_24s667_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamWith_24s667_clo;
V g_heff_2eemitc_2ereuseVal_24s669(V v_ce_240, V v_live_241, V v_x4_242);
V g_heff_2eemitc_2ereuseVal_24s669_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseVal_24s669_clo;
V g_heff_2eemitc_2elentOne_24s672(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244);
V g_heff_2eemitc_2elentOne_24s672_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentOne_24s672_clo;
V g_heff_2eemitc_2elentOperands_24s671(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244);
V g_heff_2eemitc_2elentOperands_24s671_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentOperands_24s671_clo;
V g_heff_2eemitc_2ecompF_24s670(V v_ce_240, V v_live_241, V v_e_242);
V g_heff_2eemitc_2ecompF_24s670_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecompF_24s670_clo;
V g_heff_2eemitc_2evalF_24s666(V v_ce_240, V v_live_241, V v_e_242);
V g_heff_2eemitc_2evalF_24s666_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evalF_24s666_clo;
V g_heff_2eemitc_2eoperandsF_24s665(V v_ce_240, V v_live_241, V v_x4_242);
V g_heff_2eemitc_2eoperandsF_24s665_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eoperandsF_24s665_clo;
V g_heff_2eemitc_2ebindTo_24s674(V v_ce_240, V v_x_241, V v_a_242);
V g_heff_2eemitc_2ebindTo_24s674_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebindTo_24s674_clo;
V g_heff_2eemitc_2eletWith_24s673(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_fa_245, V v_wb_246);
V g_heff_2eemitc_2eletWith_24s673_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eletWith_24s673_clo;
V g_heff_2eemitc_2escrutF_24s675(V v_ce_240, V v_e_241);
V g_heff_2eemitc_2escrutF_24s675_entry(V self, V *a);
extern Clo g_heff_2eemitc_2escrutF_24s675_clo;
V g_heff_2eemitc_2earmKept_24s677(V v_ce_240, V v_dest_241, V v_sv_242, V v_taken_243, V v_lent_244, V v_t_245, V v_vs_246, V v_b_247, V v_fb_248, V v_x11_249);
V g_heff_2eemitc_2earmKept_24s677_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earmKept_24s677_clo;
V g_heff_2eemitc_2earmLines_24s676(V v_ce_240, V v_dest_241, V v_sv_242, V v_held_243, V v_lent_244, V v_x7_245);
V g_heff_2eemitc_2earmLines_24s676_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earmLines_24s676_clo;
V g_heff_2eemitc_2estmtsF_24s664(V v_ce_240, V v_dest_241, V v_e_242);
V g_heff_2eemitc_2estmtsF_24s664_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estmtsF_24s664_clo;
V g_heff_2eemitc_2efunDef(V v_ce_240, V v_d_241, V v_xs_242, V v_b_243);
V g_heff_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efunDef_clo;
V g_heff_2eemitc_2evalDef(V v_ce_240, V v_d_241);
V g_heff_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evalDef_clo;
V g_heff_2eemitc_2edefC(V v_ce_240, V v_d_241);
V g_heff_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edefC_clo;
V g_heff_2eemitc_2eplusDone(V v_n_240, V v_la_241, V v_na_242, V v_x4_243);
V g_heff_2eemitc_2eplusDone_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eplusDone_clo;
V g_heff_2eemitc_2eperformNodes(V v_x1_240, V v_n_241);
V g_heff_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eperformNodes_clo;
V g_heff_2eemitc_2eprimCloDef(V v_p_240);
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimCloDef_clo;
V g_heff_2eemitc_2edefOwn(V v_ce_240, V v_d_241);
V g_heff_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edefOwn_clo;
V g_heff_2eemitc_2eemptyCS_get(void);
V g_prelude_2emap_24s678(V v_x2_240);
V g_prelude_2emap_24s678_entry(V self, V *a);
extern Clo g_prelude_2emap_24s678_clo;
V g_prelude_2emerge_24s680(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s680_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s680_clo;
V g_prelude_2esortBy_24s679(V v_xs_240);
V g_prelude_2esortBy_24s679_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s679_clo;
V g_heff_2eemitc_2erunEnd(V v_eff_240, V v_ce_241);
V g_heff_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2eemitc_2erunEnd_clo;
V g_heff_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241);
V g_heff_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eglobalGet_clo;
V g_heff_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242);
V g_heff_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2eemitc_2echeckEnd_clo;
V g_heff_2eemitc_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242);
V g_heff_2eemitc_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eonlyLent_clo;
V g_heff_2eemitc_2ebuildsSize(V v_n_240, V v_x2_241);
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebuildsSize_clo;
V g_prelude_2eany_24s681(V v_x2_240);
V g_prelude_2eany_24s681_entry(V self, V *a);
extern Clo g_prelude_2eany_24s681_clo;
V g_heff_2eemitc_2ereuses(V v_p_240, V v_x2_241);
V g_heff_2eemitc_2ereuses_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuses_clo;
V g_heff_2eemitc_2elentVars(V v_ds_240, V v_x2_241);
V g_heff_2eemitc_2elentVars_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentVars_clo;
V g_heff_2eemitc_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243);
V g_heff_2eemitc_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eloopLent_clo;
V g_heff_2eemitc_2eborDef(V v_bor_240, V v_d_241);
V g_heff_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborDef_clo;
V g_prelude_2emap_24s682(V v_x2_240);
V g_prelude_2emap_24s682_entry(V self, V *a);
extern Clo g_prelude_2emap_24s682_clo;
V g_prelude_2efoldl_24s683(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s683_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s683_clo;
V g_heff_2eemitc_2eborFix(V v_defs_240, V v_size_241, V v_bor_242);
V g_heff_2eemitc_2eborFix_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborFix_clo;
V g_heff_2eemitc_2eborAll(V v_m_240, V v_d_241);
V g_heff_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborAll_clo;
V g_prelude_2efoldl_24s684(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s684_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s684_clo;
V g_prelude_2emap_24s685(V v_x2_240);
V g_prelude_2emap_24s685_entry(V self, V *a);
extern Clo g_prelude_2emap_24s685_clo;
V g_prelude_2efilter_24s686(V v_x2_240);
V g_prelude_2efilter_24s686_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s686_clo;
V g_prelude_2emap_24s687(V v_x2_240);
V g_prelude_2emap_24s687_entry(V self, V *a);
extern Clo g_prelude_2emap_24s687_clo;
V g_prelude_2emap_24s688(V v_x2_240);
V g_prelude_2emap_24s688_entry(V self, V *a);
extern Clo g_prelude_2emap_24s688_clo;
V g_prelude_2efoldl_24s689(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s689_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s689_clo;
V g_prelude_2efoldl_24s690(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s690_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s690_clo;
V g_prelude_2efoldl_24s691(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s691_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s691_clo;
V g_heff_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244);
V g_heff_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprogramCE_clo;
V g_prelude_2efoldl_24s692(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s692_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s692_clo;
V g_prelude_2efoldl_24s693(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s693_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s693_clo;
V g_prelude_2efoldl_24s694(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s694_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s694_clo;
V g_heff_2eemitc_2eceOf(V v_provs_240, V v_defs_241, V v_names_242);
V g_heff_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eceOf_clo;
V g_heff_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242);
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elastDotGo_clo;
V g_heff_2eemitc_2epubLine(V v_l_240);
V g_heff_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epubLine_clo;
V g_prelude_2emap_24s695(V v_x2_240);
V g_prelude_2emap_24s695_entry(V self, V *a);
extern Clo g_prelude_2emap_24s695_clo;
V g_heff_2eemitc_2epartHead(V v_runtime_240, V v_ending_241, V v_ce_242, V v_s_243, V v_ems_244);
V g_heff_2eemitc_2epartHead_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epartHead_clo;
V g_prelude_2efoldl_24s696(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s696_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s696_clo;
V g_prelude_2emap_24s697(V v_x2_240);
V g_prelude_2emap_24s697_entry(V self, V *a);
extern Clo g_prelude_2emap_24s697_clo;
V g_prelude_2emap_24s698(V v_x2_240);
V g_prelude_2emap_24s698_entry(V self, V *a);
extern Clo g_prelude_2emap_24s698_clo;
V g_prelude_2efilter_24s699(V v_x2_240);
V g_prelude_2efilter_24s699_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s699_clo;
V g_heff_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244);
V g_heff_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eownLines_clo;
V g_prelude_2efoldl_24s700(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s700_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s700_clo;
V g_heff_2eemitc_2ezipDE(V v_x1_240, V v_x2_241);
V g_heff_2eemitc_2ezipDE_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ezipDE_clo;
V g_heff_2eemitc_2emodulePart(V v_head_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_x6_245);
V g_heff_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emodulePart_clo;
V g_heff_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245);
V g_heff_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epartsWith_clo;
V g_prelude_2emap_24s701(V v_x2_240);
V g_prelude_2emap_24s701_entry(V self, V *a);
extern Clo g_prelude_2emap_24s701_clo;
V g_heff_2eemitc_2eprogramParts(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243);
V g_heff_2eemitc_2eprogramParts_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprogramParts_clo;
V g_heff_2eemitc_2eoutputOf(V v_runtime_240, V v_provs_241, V v_ending_242, V v_l_243);
V g_heff_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eoutputOf_clo;
V g_heff_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242);
V g_heff_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2eemitc_2echeckOut_clo;
V g_heff_2eemitc_2ecatMaybesC(V v_x1_240);
V g_heff_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecatMaybesC_clo;
V g_prelude_2emap_24s702(V v_x2_240);
V g_prelude_2emap_24s702_entry(V self, V *a);
extern Clo g_prelude_2emap_24s702_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
V g_std_2edoc_2e_3c_3e(V v_x1_240, V v_x2_241);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eflatten(V v_other_240);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2echanges(V v_x1_240);
V g_std_2edoc_2echanges_entry(V self, V *a);
extern Clo g_std_2edoc_2echanges_clo;
V g_std_2edoc_2egroup(V v_d_240);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2espacesInto(V v_n_240, V v_acc_241);
V g_std_2edoc_2espacesInto_entry(V self, V *a);
extern Clo g_std_2edoc_2espacesInto_clo;
V g_std_2edoc_2efitsGo(V v_rem_240, V v_s_241);
V g_std_2edoc_2efitsGo_entry(V self, V *a);
extern Clo g_std_2edoc_2efitsGo_clo;
V g_std_2edoc_2ebest(V v_w_240, V v_nl_241, V v_k_242, V v_x4_243);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2edisplayInto(V v_acc_240, V v_x2_241);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_heff_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_e_241);
V g_heff_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ertrimEnd_clo;
V g_prelude_2efoldl_24s703(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s703_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s703_clo;
V g_heff_2efmt_2elayout_2eblankLine_get(void);
V g_prelude_2efoldl_24s704(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s704_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s704_clo;
V g_heff_2efmt_2elayout_2etrailOf(V v_env_240, V v_t_241);
V g_heff_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2etrailOf_clo;
V g_prelude_2emap_24s705(V v_x2_240);
V g_prelude_2emap_24s705_entry(V self, V *a);
extern Clo g_prelude_2emap_24s705_clo;
V g_prelude_2emap_24s706(V v_x2_240);
V g_prelude_2emap_24s706_entry(V self, V *a);
extern Clo g_prelude_2emap_24s706_clo;
V g_heff_2efmt_2elayout_2etok(V v_env_240, V v_t_241);
V g_heff_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2etok_clo;
V g_heff_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241);
V g_heff_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243);
V g_heff_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eitem_clo;
V g_heff_2efmt_2elayout_2ehangs(V v_e_240);
V g_heff_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ehangs_clo;
V g_heff_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241);
V g_heff_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2esameOp_clo;
V g_heff_2efmt_2elayout_2echain(V v_e_240);
V g_heff_2efmt_2elayout_2echain_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2echain_clo;
V g_heff_2efmt_2elayout_2eanyArrow(V v_x1_240);
V g_heff_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244);
V g_heff_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2epListGo_clo;
V g_heff_2efmt_2elayout_2epP(V v_env_240, V v_x2_241);
V g_heff_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2epP_clo;
V g_heff_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241);
V g_heff_2efmt_2elayout_2eopsOf_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eopsOf_clo;
V g_heff_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242);
V g_heff_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242);
V g_heff_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eisSameIn_clo;
V g_std_2edoc_2econcatWith_24s707(V v_x2_240);
V g_std_2edoc_2econcatWith_24s707_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s707_clo;
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709(V v_env_240, V v_i_241, V v_x6_242);
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_clo;
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710(V v_env_240, V v_i_241, V v_x6_242);
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_clo;
V g_heff_2efmt_2elayout_2elay_get(void);
V g_heff_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242);
V g_heff_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2esig_clo;
V g_heff_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241);
V g_heff_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2efmt_2elayout_2edeclsGo_24s712(V v_env_240, V v_i_241, V v_x4_242);
V g_heff_2efmt_2elayout_2edeclsGo_24s712_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2edeclsGo_24s712_clo;
V g_heff_2efmt_2elayout_2ewhereDoc_24s711(V v_env_240, V v_rhsLast_241, V v_x4_242);
V g_heff_2efmt_2elayout_2ewhereDoc_24s711_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ewhereDoc_24s711_clo;
V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714(V v_env_240, V v_i_241, V v_x6_242);
V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_clo;
V g_heff_2efmt_2elayout_2epD(V v_env_240, V v_x2_241);
V g_heff_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2epD_clo;
V g_heff_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241);
V g_heff_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2efmt_2elayout_2edeclsGo_24s715(V v_env_240, V v_i_241, V v_x4_242);
V g_heff_2efmt_2elayout_2edeclsGo_24s715_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2edeclsGo_24s715_clo;
V g_heff_2efmt_2elayout_2ekeptLines(V v_x1_240);
V g_heff_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ekeptLines_clo;
V g_prelude_2emap_24s716(V v_x2_240);
V g_prelude_2emap_24s716_entry(V self, V *a);
extern Clo g_prelude_2emap_24s716_clo;
V g_heff_2efmt_2elayout_2erender2(V v_d_240);
V g_heff_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2erender2_clo;
V g_heff_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241);
V g_heff_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2efmt_2elayout_2efmtLexed(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243);
V g_heff_2efmt_2elayout_2efmtLexed_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2efmtLexed_clo;
V g_heff_2efmt_2elayout_2eformatUncheckedIn(V v_f_240, V v_src_241);
V g_heff_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_prelude_2emap_24s717(V v_x2_240);
V g_prelude_2emap_24s717_entry(V self, V *a);
extern Clo g_prelude_2emap_24s717_clo;
V g_prelude_2emap_24s718(V v_x2_240);
V g_prelude_2emap_24s718_entry(V self, V *a);
extern Clo g_prelude_2emap_24s718_clo;
V g_heff_2eformat_2epatKey(V v_p_240);
V g_heff_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2epatKey_clo;
V g_heff_2eformat_2eparamKey(V v_r_240, V v_x2_241);
V g_heff_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2eparamKey_clo;
V g_heff_2eformat_2ekeyTermF(V v_r_240, V v_n_241);
V g_heff_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2eformat_2ekeyTermF_clo;
V g_prelude_2emap_24s719(V v_x2_240);
V g_prelude_2emap_24s719_entry(V self, V *a);
extern Clo g_prelude_2emap_24s719_clo;
V g_heff_2eformat_2ekeyDeclF(V v_r_240, V v_d_241);
V g_heff_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2eformat_2ekeyDeclF_clo;
V g_heff_2eformat_2ekeys_get(void);
V g_heff_2esurface_2efixityOut_24s723(V v_decls_240, V v_groups_241, V v_edges_242);
V g_heff_2esurface_2efixityOut_24s723_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixityOut_24s723_clo;
V g_heff_2esurface_2efixityFrom_24s722(V v_decls_240);
V g_heff_2esurface_2efixityFrom_24s722_entry(V self, V *a);
extern Clo g_heff_2esurface_2efixityFrom_24s722_clo;
V g_heff_2esurface_2ereadToks_24s721(V v_ltoks_240, V v_toks_241, V v_lexDiags_242);
V g_heff_2esurface_2ereadToks_24s721_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadToks_24s721_clo;
V g_heff_2esurface_2ereadProgramWith_24s720(V v_src_240);
V g_heff_2esurface_2ereadProgramWith_24s720_entry(V self, V *a);
extern Clo g_heff_2esurface_2ereadProgramWith_24s720_clo;
V g_prelude_2emap_24s724(V v_x2_240);
V g_prelude_2emap_24s724_entry(V self, V *a);
extern Clo g_prelude_2emap_24s724_clo;
V g_prelude_2emap_24s725(V v_x2_240);
V g_prelude_2emap_24s725_entry(V self, V *a);
extern Clo g_prelude_2emap_24s725_clo;
V g_heff_2eformat_2estrsEq(V v_x1_240, V v_x2_241);
V g_heff_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2eformat_2estrsEq_clo;
V g_heff_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243);
V g_heff_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2eformat_2esameMeaning_clo;
V g_heff_2eformat_2echeck(V v_src_240, V v_out_241);
V g_heff_2eformat_2echeck_entry(V self, V *a);
extern Clo g_heff_2eformat_2echeck_clo;
V g_heff_2eformat_2eformat(V v_src_240);
V g_heff_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2eformat_2eformat_clo;
V g_heff_2eproject_2enextDecl(V v_ts_240, V v_i_241);
V g_heff_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2eproject_2enextDecl_clo;
V g_heff_2eproject_2eitemsGo_24s727(V v_ts_240, V v_i_241, V v_acc_242);
V g_heff_2eproject_2eitemsGo_24s727_entry(V self, V *a);
extern Clo g_heff_2eproject_2eitemsGo_24s727_clo;
V g_heff_2eproject_2efieldsGo_24s728(V v_ts_240, V v_i_241, V v_acc_242);
V g_heff_2eproject_2efieldsGo_24s728_entry(V self, V *a);
extern Clo g_heff_2eproject_2efieldsGo_24s728_clo;
V g_heff_2eproject_2elitF_24s726(V v_ts_240, V v_i_241);
V g_heff_2eproject_2elitF_24s726_entry(V self, V *a);
extern Clo g_heff_2eproject_2elitF_24s726_clo;
V g_heff_2eproject_2edeclsGo(V v_file_240, V v_name_241, V v_ts_242, V v_i_243, V v_found_244);
V g_heff_2eproject_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2edeclsGo_clo;
V g_heff_2eproject_2erangeFrom(V v_i_240, V v_n_241);
V g_heff_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2eproject_2erangeFrom_clo;
V g_prelude_2eall_24s729(V v_x2_240);
V g_prelude_2eall_24s729_entry(V self, V *a);
extern Clo g_prelude_2eall_24s729_clo;
V g_heff_2eproject_2eisNumber(V v_s_240);
V g_heff_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2eproject_2eisNumber_clo;
V g_prelude_2emap_24s730(V v_x2_240);
V g_prelude_2emap_24s730_entry(V self, V *a);
extern Clo g_prelude_2emap_24s730_clo;
V g_heff_2eproject_2eversion(V v_v_240);
V g_heff_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2eproject_2eversion_clo;
V g_heff_2eproject_2ecompatible(V v_x1_240, V v_x2_241);
V g_heff_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2eproject_2ecompatible_clo;
V g_prelude_2eall_24s731(V v_x2_240);
V g_prelude_2eall_24s731_entry(V self, V *a);
extern Clo g_prelude_2eall_24s731_clo;
V g_heff_2eproject_2eisName(V v_x_240);
V g_heff_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2eproject_2eisName_clo;
V g_heff_2eproject_2esameNames(V v_x1_240, V v_x2_241);
V g_heff_2eproject_2esameNames_entry(V self, V *a);
extern Clo g_heff_2eproject_2esameNames_clo;
V g_heff_2eproject_2efieldsAre(V v_names_240, V v_x_241);
V g_heff_2eproject_2efieldsAre_entry(V self, V *a);
extern Clo g_heff_2eproject_2efieldsAre_clo;
V g_heff_2eproject_2estr(V v_x_240);
V g_heff_2eproject_2estr_entry(V self, V *a);
extern Clo g_heff_2eproject_2estr_clo;
V g_heff_2eproject_2eitems(V v_x_240);
V g_heff_2eproject_2eitems_entry(V self, V *a);
extern Clo g_heff_2eproject_2eitems_clo;
V g_heff_2eproject_2eversionOf(V v_x_240);
V g_heff_2eproject_2eversionOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2eversionOf_clo;
V g_heff_2eproject_2enameOf(V v_x_240);
V g_heff_2eproject_2enameOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2enameOf_clo;
V g_heff_2eproject_2emajorMismatch(V v_path_240, V v_v_241);
V g_heff_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2eproject_2emajorMismatch_clo;
V g_heff_2eproject_2erequireOf(V v_x_240);
V g_heff_2eproject_2erequireOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2erequireOf_clo;
V g_heff_2eproject_2ereplaceOf(V v_x_240);
V g_heff_2eproject_2ereplaceOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2ereplaceOf_clo;
V g_heff_2eproject_2etwiceGo(V v_seen_240, V v_x2_241);
V g_heff_2eproject_2etwiceGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2etwiceGo_clo;
V g_prelude_2ezipWith_24s732(V v_xs_240, V v_ys_241);
V g_prelude_2ezipWith_24s732_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s732_clo;
V g_heff_2eproject_2eunrequired(V v_names_240, V v_x2_241);
V g_heff_2eproject_2eunrequired_entry(V self, V *a);
extern Clo g_heff_2eproject_2eunrequired_clo;
V g_heff_2eproject_2echeckNames(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243);
V g_heff_2eproject_2echeckNames_entry(V self, V *a);
extern Clo g_heff_2eproject_2echeckNames_clo;
V g_heff_2eproject_2eallOf_24s733(V v_x2_240);
V g_heff_2eproject_2eallOf_24s733_entry(V self, V *a);
extern Clo g_heff_2eproject_2eallOf_24s733_clo;
V g_heff_2eproject_2eallOf_24s734(V v_x2_240);
V g_heff_2eproject_2eallOf_24s734_entry(V self, V *a);
extern Clo g_heff_2eproject_2eallOf_24s734_clo;
V g_heff_2eproject_2epackageOf4(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243);
V g_heff_2eproject_2epackageOf4_entry(V self, V *a);
extern Clo g_heff_2eproject_2epackageOf4_clo;
V g_heff_2eproject_2epackageOf(V v_x_240);
V g_heff_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2epackageOf_clo;
V g_heff_2eproject_2ereadPackage(V v_src_240);
V g_heff_2eproject_2ereadPackage_entry(V self, V *a);
extern Clo g_heff_2eproject_2ereadPackage_clo;
V g_heff_2eproject_2ebackendOf(V v_x_240);
V g_heff_2eproject_2ebackendOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2ebackendOf_clo;
V g_heff_2eproject_2ebuildOf(V v_x_240);
V g_heff_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2ebuildOf_clo;
V g_heff_2eproject_2ereadBuild(V v_src_240);
V g_heff_2eproject_2ereadBuild_entry(V self, V *a);
extern Clo g_heff_2eproject_2ereadBuild_clo;
V g_heff_2eproject_2enewerGo(V v_x1_240, V v_x2_241);
V g_heff_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2enewerGo_clo;
V g_heff_2eproject_2erepoOf(V v_path_240);
V g_heff_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2erepoOf_clo;
V g_heff_2eproject_2esumLine(V v_at_240, V v_line_241);
V g_heff_2eproject_2esumLine_entry(V self, V *a);
extern Clo g_heff_2eproject_2esumLine_clo;
V g_heff_2eproject_2esumGo(V v_at_240, V v_x2_241);
V g_heff_2eproject_2esumGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2esumGo_clo;
V g_heff_2eproject_2esumBefore(V v_a_240, V v_b_241);
V g_heff_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2eproject_2esumBefore_clo;
V g_prelude_2emap_24s735(V v_x2_240);
V g_prelude_2emap_24s735_entry(V self, V *a);
extern Clo g_prelude_2emap_24s735_clo;
V g_prelude_2emerge_24s737(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s737_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s737_clo;
V g_prelude_2esortBy_24s736(V v_xs_240);
V g_prelude_2esortBy_24s736_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s736_clo;
V g_prelude_2efoldl_24s738(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s738_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s738_clo;
V g_prelude_2efoldl_24s739(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s739_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s739_clo;
V g_heff_2eproject_2equoted(V v_s_240);
V g_heff_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2eproject_2equoted_clo;
V g_prelude_2emap_24s740(V v_x2_240);
V g_prelude_2emap_24s740_entry(V self, V *a);
extern Clo g_prelude_2emap_24s740_clo;
V g_prelude_2emap_24s741(V v_x2_240);
V g_prelude_2emap_24s741_entry(V self, V *a);
extern Clo g_prelude_2emap_24s741_clo;
V g_heff_2eproject_2eshowPackage(V v_pk_240);
V g_heff_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2eproject_2eshowPackage_clo;
V g_heff_2eproject_2espanGo(V v_ts_240, V v_i_241);
V g_heff_2eproject_2espanGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2espanGo_clo;
V g_heff_2eproject_2ewithPackage(V v_src_240, V v_pk_241);
V g_heff_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2eproject_2ewithPackage_clo;
V g_std_2efilesystem_2efs_get(void);
V g_prelude_2efoldl_24s742(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s742_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s742_clo;
V g_std_2epath_2elower_2elow_240(V v_s_240, V v_i_241);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
V g_std_2epath_2edriveOf(V v_x1_240, V v_s_241);
V g_std_2epath_2edriveOf_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_clo;
V g_std_2epath_2edriveOf_2eunc_240(V v_s_240, V v_x1_241);
V g_std_2epath_2edriveOf_2eunc_240_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_2eunc_240_clo;
V g_std_2epath_2eparse(V v_st_240, V v_s_241);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2eparse_2ekeep_240(V v_x1_240);
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_2ekeep_240_clo;
V g_std_2epath_2erender(V v_st_240, V v_p_241);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2erender_2eslashesTo_240(V v_st_240, V v_s_241);
V g_std_2epath_2erender_2eslashesTo_240_entry(V self, V *a);
extern Clo g_std_2epath_2erender_2eslashesTo_240_clo;
V g_std_2epath_2ecollapse(V v_absolute_240, V v_xs_241);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ecollapse_2estep_240(V v_absolute_240, V v_acc_241, V v_x_242);
V g_std_2epath_2ecollapse_2estep_240_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_2estep_240_clo;
V g_std_2epath_2ejoin_2eonto_240(V v_p_240, V v_q_241);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2esameDrive(V v_x1_240, V v_a_241, V v_b_242);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2eunshared(V v_st_240, V v_xs_241, V v_ys_242);
V g_std_2epath_2eunshared_entry(V self, V *a);
extern Clo g_std_2epath_2eunshared_clo;
V g_std_2epath_2erelative(V v_st_240, V v_from_241, V v_to_242);
V g_std_2epath_2erelative_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_clo;
V g_prelude_2emap_24s744(V v_x2_240);
V g_prelude_2emap_24s744_entry(V self, V *a);
extern Clo g_prelude_2emap_24s744_clo;
V g_std_2epath_2erelative_2ego_240(V v_st_240, V v_p_241, V v_q_242);
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_2ego_240_clo;
V g_std_2epath_2eisUnder(V v_st_240, V v_dir_241, V v_s_242);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_heff_2eload_2eunder(V v_ps_240, V v_d_241, V v_p_242);
V g_heff_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2eload_2eunder_clo;
V g_heff_2eload_2emoduleOf(V v_ps_240, V v_path_241);
V g_heff_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2eload_2emoduleOf_clo;
V g_heff_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242);
V g_heff_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2eload_2eproblemMsg_clo;
V g_prelude_2emap_24s745(V v_x2_240);
V g_prelude_2emap_24s745_entry(V self, V *a);
extern Clo g_prelude_2emap_24s745_clo;
V g_heff_2eload_2epkgByPath(V v_x1_240, V v_p_241);
V g_heff_2eload_2epkgByPath_entry(V self, V *a);
extern Clo g_heff_2eload_2epkgByPath_clo;
V g_heff_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242);
V g_heff_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2eload_2ecachedDir_clo;
V g_prelude_2efoldl_24s746(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s746_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s746_clo;
V g_prelude_2efoldl_24s747(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s747_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s747_clo;
V g_heff_2eload_2etakeUntil(V v_x_240, V v_x2_241);
V g_heff_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2eload_2etakeUntil_clo;
V g_heff_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242);
V g_heff_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2eload_2ecycleAmong_clo;
V g_prelude_2emap_24s748(V v_x2_240);
V g_prelude_2emap_24s748_entry(V self, V *a);
extern Clo g_prelude_2emap_24s748_clo;
V g_heff_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242);
V g_heff_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2eload_2efreeName_clo;
V g_heff_2eload_2enamedGo(V v_taken_240, V v_x2_241);
V g_heff_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eload_2enamedGo_clo;
V g_prelude_2efoldl_24s749(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s749_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s749_clo;
V g_heff_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243);
V g_heff_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2eload_2epkgOfGo_clo;
V g_heff_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244);
V g_heff_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2eload_2erequiredPlace_clo;
V g_heff_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243);
V g_heff_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2eload_2eplacesOf_clo;
V g_heff_2eload_2esameButCase(V v_a_240, V v_b_241);
V g_heff_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2eload_2esameButCase_clo;
V g_heff_2eload_2ecasesIn(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243);
V g_heff_2eload_2ecasesIn_entry(V self, V *a);
extern Clo g_heff_2eload_2ecasesIn_clo;
V g_heff_2eload_2eemptySt_get(void);
V g_prelude_2emap_24s750(V v_x2_240);
V g_prelude_2emap_24s750_entry(V self, V *a);
extern Clo g_prelude_2emap_24s750_clo;
V g_prelude_2efoldl_24s751(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s751_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s751_clo;
V g_heff_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243);
V g_heff_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadDone_clo;
V g_heff_2elocals_2enone_get(void);
V g_heff_2elocals_2efindBinder(V v_x_240, V v_x2_241);
V g_heff_2elocals_2efindBinder_entry(V self, V *a);
extern Clo g_heff_2elocals_2efindBinder_clo;
V g_prelude_2efoldl_24s752(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s752_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s752_clo;
V g_prelude_2efoldl_24s753(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s753_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s753_clo;
V g_heff_2elocals_2epatternBinders(V v_p_240);
V g_heff_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2epatternBinders_clo;
V g_heff_2elocals_2eimplicitsOf(V v_x1_240);
V g_heff_2elocals_2eimplicitsOf_entry(V self, V *a);
extern Clo g_heff_2elocals_2eimplicitsOf_clo;
V g_heff_2elocals_2elamBinders(V v_x1_240);
V g_heff_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2elamBinders_clo;
V g_heff_2elocals_2eequationF_24s757(V v_env_240, V v_x3_241);
V g_heff_2elocals_2eequationF_24s757_entry(V self, V *a);
extern Clo g_heff_2elocals_2eequationF_24s757_clo;
V g_heff_2elocals_2eparamWalk_24s759(V v_env_240, V v_x3_241);
V g_heff_2elocals_2eparamWalk_24s759_entry(V self, V *a);
extern Clo g_heff_2elocals_2eparamWalk_24s759_clo;
V g_heff_2elocals_2edeclF_24s758(V v_env_240, V v_d_241);
V g_heff_2elocals_2edeclF_24s758_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclF_24s758_clo;
V g_heff_2elocals_2elocalDefF_24s756(V v_env_240, V v_d_241);
V g_heff_2elocals_2elocalDefF_24s756_entry(V self, V *a);
extern Clo g_heff_2elocals_2elocalDefF_24s756_clo;
V g_heff_2elocals_2elocalsF_24s755(V v_env_240, V v_x3_241, V v_body_242);
V g_heff_2elocals_2elocalsF_24s755_entry(V self, V *a);
extern Clo g_heff_2elocals_2elocalsF_24s755_clo;
V g_heff_2elocals_2esigBlockF_24s760(V v_env_240, V v_x3_241);
V g_heff_2elocals_2esigBlockF_24s760_entry(V self, V *a);
extern Clo g_heff_2elocals_2esigBlockF_24s760_clo;
V g_heff_2elocals_2edoBlockF_24s761(V v_env_240, V v_x3_241);
V g_heff_2elocals_2edoBlockF_24s761_entry(V self, V *a);
extern Clo g_heff_2elocals_2edoBlockF_24s761_clo;
V g_heff_2elocals_2ewalkF_24s754(V v_env_240, V v_n_241);
V g_heff_2elocals_2ewalkF_24s754_entry(V self, V *a);
extern Clo g_heff_2elocals_2ewalkF_24s754_clo;
V g_heff_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242);
V g_heff_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2elocals_2earguments_clo;
V g_heff_2elocals_2eequationF_24s762(V v_env_240, V v_x3_241);
V g_heff_2elocals_2eequationF_24s762_entry(V self, V *a);
extern Clo g_heff_2elocals_2eequationF_24s762_clo;
V g_heff_2elocals_2edeclaration(V v_d_240);
V g_heff_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclaration_clo;
V g_prelude_2emap_24s763(V v_x2_240);
V g_prelude_2emap_24s763_entry(V self, V *a);
extern Clo g_prelude_2emap_24s763_clo;
V g_heff_2elocals_2emkLocal(V v_us_240, V v_b_241);
V g_heff_2elocals_2emkLocal_entry(V self, V *a);
extern Clo g_heff_2elocals_2emkLocal_clo;
V g_prelude_2efilter_24s764(V v_x2_240);
V g_prelude_2efilter_24s764_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s764_clo;
V g_prelude_2emap_24s765(V v_x2_240);
V g_prelude_2emap_24s765_entry(V self, V *a);
extern Clo g_prelude_2emap_24s765_clo;
V g_prelude_2efilter_24s766(V v_x2_240);
V g_prelude_2efilter_24s766_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s766_clo;
V g_prelude_2efoldl_24s767(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s767_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s767_clo;
V g_heff_2equery_2ecatMaybesQ(V v_x1_240);
V g_heff_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2equery_2ecatMaybesQ_clo;
V g_heff_2equery_2eisNameChar(V v_c_240);
V g_heff_2equery_2eisNameChar_entry(V self, V *a);
extern Clo g_heff_2equery_2eisNameChar_clo;
V g_heff_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242);
V g_heff_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2equery_2ewordAt_clo;
V g_heff_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243);
V g_heff_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2equery_2enameInGo_clo;
V g_heff_2equery_2enubByStart(V v_x1_240);
V g_heff_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2equery_2enubByStart_clo;
V g_prelude_2emerge_24s769(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s769_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s769_clo;
V g_prelude_2esortBy_24s768(V v_xs_240);
V g_prelude_2esortBy_24s768_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s768_clo;
V g_heff_2equery_2eatLine(V v_src_240, V v_sp_241);
V g_heff_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2equery_2eatLine_clo;
V g_heff_2equery_2eexplain(V v_c_240);
V g_heff_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2equery_2eexplain_clo;
V g_prelude_2emerge_24s771(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s771_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s771_clo;
V g_prelude_2esortBy_24s770(V v_xs_240);
V g_prelude_2esortBy_24s770_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s770_clo;
V g_heff_2equery_2einfoAt(V v_c_240, V v_off_241);
V g_heff_2equery_2einfoAt_entry(V self, V *a);
extern Clo g_heff_2equery_2einfoAt_clo;
V g_heff_2equery_2etypeAt(V v_c_240, V v_off_241);
V g_heff_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2equery_2etypeAt_clo;
V g_heff_2equery_2eisTypedChar(V v_c_240);
V g_heff_2equery_2eisTypedChar_entry(V self, V *a);
extern Clo g_heff_2equery_2eisTypedChar_clo;
V g_heff_2equery_2etypedFrom(V v_src_240, V v_i_241);
V g_heff_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2equery_2etypedFrom_clo;
V g_heff_2equery_2elastDot(V v_s_240, V v_i_241);
V g_heff_2equery_2elastDot_entry(V self, V *a);
extern Clo g_heff_2equery_2elastDot_clo;
V g_heff_2equery_2ecompletionDetail(V v_c_240, V v_x_241);
V g_heff_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2equery_2ecompletionDetail_clo;
V g_heff_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243);
V g_heff_2equery_2ecompletionOf_entry(V self, V *a);
extern Clo g_heff_2equery_2ecompletionOf_clo;
V g_prelude_2emerge_24s773(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s773_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s773_clo;
V g_prelude_2esortBy_24s772(V v_xs_240);
V g_prelude_2esortBy_24s772_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s772_clo;
V g_heff_2equery_2ecompletionsAt(V v_c_240, V v_offset_241);
V g_heff_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2equery_2ecompletionsAt_clo;
V g_heff_2equery_2eeqTarget(V v_a_240, V v_b_241);
V g_heff_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2equery_2eeqTarget_clo;
V g_heff_2equery_2eglobalSites(V v_c_240, V v_x_241, V v_sps_242);
V g_heff_2equery_2eglobalSites_entry(V self, V *a);
extern Clo g_heff_2equery_2eglobalSites_clo;
V g_heff_2equery_2ememberSites(V v_c_240, V v_x_241, V v_ms_242);
V g_heff_2equery_2ememberSites_entry(V self, V *a);
extern Clo g_heff_2equery_2ememberSites_clo;
V g_prelude_2emap_24s774(V v_x2_240);
V g_prelude_2emap_24s774_entry(V self, V *a);
extern Clo g_prelude_2emap_24s774_clo;
V g_heff_2equery_2esumTags(V v_x1_240);
V g_heff_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2equery_2esumTags_clo;
V g_prelude_2emap_24s775(V v_x2_240);
V g_prelude_2emap_24s775_entry(V self, V *a);
extern Clo g_prelude_2emap_24s775_clo;
V g_prelude_2emap_24s776(V v_x2_240);
V g_prelude_2emap_24s776_entry(V self, V *a);
extern Clo g_prelude_2emap_24s776_clo;
V g_heff_2equery_2edeclSites(V v_c_240, V v_d_241);
V g_heff_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2equery_2edeclSites_clo;
V g_heff_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243);
V g_heff_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2equery_2edefinesGo_clo;
V g_heff_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242);
V g_heff_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2equery_2edefinitionIn_clo;
V g_heff_2equery_2edefinitionAt(V v_program_240, V v_off_241);
V g_heff_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2equery_2edefinitionAt_clo;
V g_heff_2equery_2eownNameOf(V v_x1_240, V v_k_241);
V g_heff_2equery_2eownNameOf_entry(V self, V *a);
extern Clo g_heff_2equery_2eownNameOf_clo;
V g_heff_2equery_2esiteFound(V v_program_240, V v_c_241, V v_off_242);
V g_heff_2equery_2esiteFound_entry(V self, V *a);
extern Clo g_heff_2equery_2esiteFound_clo;
V g_heff_2equery_2efieldFound(V v_program_240, V v_c_241, V v_ls_242, V v_off_243);
V g_heff_2equery_2efieldFound_entry(V self, V *a);
extern Clo g_heff_2equery_2efieldFound_clo;
V g_heff_2equery_2eatLocal(V v_off_240, V v_l_241);
V g_heff_2equery_2eatLocal_entry(V self, V *a);
extern Clo g_heff_2equery_2eatLocal_clo;
V g_heff_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243);
V g_heff_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2equery_2etargetIn_clo;
V g_heff_2equery_2etargetAt(V v_program_240, V v_off_241);
V g_heff_2equery_2etargetAt_entry(V self, V *a);
extern Clo g_heff_2equery_2etargetAt_clo;
V g_heff_2equery_2euseOf(V v_t_240, V v_name_241, V v_i_242);
V g_heff_2equery_2euseOf_entry(V self, V *a);
extern Clo g_heff_2equery_2euseOf_clo;
V g_heff_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243);
V g_heff_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2equery_2ewordsOf_clo;
V g_prelude_2emap_24s777(V v_x2_240);
V g_prelude_2emap_24s777_entry(V self, V *a);
extern Clo g_prelude_2emap_24s777_clo;
V g_heff_2equery_2efixityWords(V v_name_240, V v_ws_241);
V g_heff_2equery_2efixityWords_entry(V self, V *a);
extern Clo g_heff_2equery_2efixityWords_clo;
V g_heff_2equery_2ewordsIn(V v_name_240, V v_src_241, V v_i_242, V v_to_243, V v_acc_244);
V g_heff_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2equery_2ewordsIn_clo;
V g_heff_2equery_2eexpectedIn(V v_name_240, V v_c_241);
V g_heff_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2equery_2eexpectedIn_clo;
V g_heff_2equery_2efieldUsesOf(V v_ss_240, V v_ls_241);
V g_heff_2equery_2efieldUsesOf_entry(V self, V *a);
extern Clo g_heff_2equery_2efieldUsesOf_clo;
V g_heff_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242);
V g_heff_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2equery_2emoreIn_clo;
V g_heff_2equery_2einFileFound(V v_t_240, V v_name_241, V v_c_242, V v_ss_243, V v_found_244);
V g_heff_2equery_2einFileFound_entry(V self, V *a);
extern Clo g_heff_2equery_2einFileFound_clo;
V g_heff_2equery_2einFileSites(V v_t_240, V v_name_241, V v_c_242, V v_ss_243);
V g_heff_2equery_2einFileSites_entry(V self, V *a);
extern Clo g_heff_2equery_2einFileSites_clo;
V g_heff_2equery_2enubByPath(V v_x1_240);
V g_heff_2equery_2enubByPath_entry(V self, V *a);
extern Clo g_heff_2equery_2enubByPath_clo;
V g_heff_2equery_2elocalOccurrences(V v_c_240, V v_b_241);
V g_heff_2equery_2elocalOccurrences_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalOccurrences_clo;
V g_heff_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242);
V g_heff_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2equery_2eoccurrences_clo;
V g_heff_2equery_2epunctuation(V v_d_240);
V g_heff_2equery_2epunctuation_entry(V self, V *a);
extern Clo g_heff_2equery_2epunctuation_clo;
V g_heff_2equery_2eallChars_24s778(V v_s_240, V v_i_241);
V g_heff_2equery_2eallChars_24s778_entry(V self, V *a);
extern Clo g_heff_2equery_2eallChars_24s778_clo;
V g_heff_2equery_2eallChars_24s779(V v_s_240, V v_i_241);
V g_heff_2equery_2eallChars_24s779_entry(V self, V *a);
extern Clo g_heff_2equery_2eallChars_24s779_clo;
V g_heff_2equery_2enameClass(V v_x_240);
V g_heff_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2equery_2enameClass_clo;
V g_heff_2equery_2erenameRefused(V v_t_240, V v_old_241, V v_new_242);
V g_heff_2equery_2erenameRefused_entry(V self, V *a);
extern Clo g_heff_2equery_2erenameRefused_clo;
V g_heff_2equery_2ebrokenSymbol(V v_c_240, V v_x2_241);
V g_heff_2equery_2ebrokenSymbol_entry(V self, V *a);
extern Clo g_heff_2equery_2ebrokenSymbol_clo;
V g_prelude_2efoldl_24s780(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s780_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s780_clo;
V g_prelude_2efind_24s781(V v_x2_240);
V g_prelude_2efind_24s781_entry(V self, V *a);
extern Clo g_prelude_2efind_24s781_clo;
V g_prelude_2efilter_24s782(V v_x2_240);
V g_prelude_2efilter_24s782_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s782_clo;
V g_prelude_2efoldl_24s786(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s786_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s786_clo;
V g_prelude_2efoldl_24s787(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s787_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s787_clo;
V g_prelude_2efoldl_24s788(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s788_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s788_clo;
V g_prelude_2efoldl_24s789(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s789_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s789_clo;
V g_prelude_2efoldl_24s790(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s790_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s790_clo;
V g_prelude_2efoldl_24s791(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s791_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s791_clo;
V g_prelude_2efoldl_24s792(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s792_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s792_clo;
V g_heff_2equery_2elocalTermF_24s785(V v_n_240);
V g_heff_2equery_2elocalTermF_24s785_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalTermF_24s785_clo;
V g_prelude_2efoldl_24s784(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s784_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s784_clo;
V g_prelude_2efoldl_24s793(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s793_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s793_clo;
V g_heff_2equery_2elocalDeclF_24s783(V v_d_240);
V g_heff_2equery_2elocalDeclF_24s783_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalDeclF_24s783_clo;
V g_heff_2equery_2esymbolWith(V v_c_240, V v_o_241, V v_sp_242, V v_own_243);
V g_heff_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2equery_2esymbolWith_clo;
V g_heff_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243);
V g_heff_2equery_2esymbolsGo_entry(V self, V *a);
extern Clo g_heff_2equery_2esymbolsGo_clo;
V g_prelude_2emerge_24s795(V v_xs_240, V v_ys_241);
V g_prelude_2emerge_24s795_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s795_clo;
V g_prelude_2esortBy_24s794(V v_xs_240);
V g_prelude_2esortBy_24s794_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s794_clo;
V g_heff_2equery_2esymbols(V v_c_240);
V g_heff_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2equery_2esymbols_clo;
V g_heff_2ediff_2esnake(V v_eq_240, V v_xs_241, V v_ys_242, V v_x_243, V v_y_244, V v_acc_245);
V g_heff_2ediff_2esnake_entry(V self, V *a);
extern Clo g_heff_2ediff_2esnake_clo;
V g_heff_2ediff_2estepOnto(V v_eq_240, V v_xs_241, V v_ys_242, V v_k_243, V v_v_244);
V g_heff_2ediff_2estepOnto_entry(V self, V *a);
extern Clo g_heff_2ediff_2estepOnto_clo;
V g_heff_2ediff_2ediagonals(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_k_244, V v_v_245, V v_acc_246);
V g_heff_2ediff_2ediagonals_entry(V self, V *a);
extern Clo g_heff_2ediff_2ediagonals_clo;
V g_heff_2ediff_2erounds(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_v_244);
V g_heff_2ediff_2erounds_entry(V self, V *a);
extern Clo g_heff_2ediff_2erounds_clo;
V g_heff_2ediff_2ediffBy(V v_eq_240, V v_as_241, V v_bs_242);
V g_heff_2ediff_2ediffBy_entry(V self, V *a);
extern Clo g_heff_2ediff_2ediffBy_clo;
V g_heff_2ediff_2eisWordCode(V v_c_240);
V g_heff_2ediff_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2ediff_2eisWordCode_clo;
V g_heff_2ediff_2eisBlankCode(V v_c_240);
V g_heff_2ediff_2eisBlankCode_entry(V self, V *a);
extern Clo g_heff_2ediff_2eisBlankCode_clo;
V g_heff_2ediff_2erunEnd_24s796(V v_s_240, V v_i_241);
V g_heff_2ediff_2erunEnd_24s796_entry(V self, V *a);
extern Clo g_heff_2ediff_2erunEnd_24s796_clo;
V g_heff_2ediff_2erunEnd_24s797(V v_s_240, V v_i_241);
V g_heff_2ediff_2erunEnd_24s797_entry(V self, V *a);
extern Clo g_heff_2ediff_2erunEnd_24s797_clo;
V g_heff_2ediff_2etokenEnd(V v_s_240, V v_i_241);
V g_heff_2ediff_2etokenEnd_entry(V self, V *a);
extern Clo g_heff_2ediff_2etokenEnd_clo;
V g_heff_2ediff_2ewordsFrom(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2ediff_2ewordsFrom_entry(V self, V *a);
extern Clo g_heff_2ediff_2ewordsFrom_clo;
V g_heff_2ediff_2ejoinEdit(V v_x1_240, V v_x2_241);
V g_heff_2ediff_2ejoinEdit_entry(V self, V *a);
extern Clo g_heff_2ediff_2ejoinEdit_clo;
V g_heff_2ediff_2ejoinRunsGo(V v_e_240, V v_x2_241);
V g_heff_2ediff_2ejoinRunsGo_entry(V self, V *a);
extern Clo g_heff_2ediff_2ejoinRunsGo_clo;
V g_heff_2ereport_2econtext_get(void);
V g_heff_2ereport_2ecut(V v_s_240, V v_first_241, V v_last_242);
V g_heff_2ereport_2ecut_entry(V self, V *a);
extern Clo g_heff_2ereport_2ecut_clo;
V g_heff_2ereport_2emismatchGo(V v_color_240, V v_i_241, V v_n_242, V v_x4_243, V v_m_244);
V g_heff_2ereport_2emismatchGo_entry(V self, V *a);
extern Clo g_heff_2ereport_2emismatchGo_clo;
V g_heff_2ereport_2emismatch(V v_color_240, V v_expected_241, V v_got_242);
V g_heff_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2ereport_2emismatch_clo;
V g_heff_2eserial_2eencodeListGo_24s798(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s798_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s798_clo;
V g_heff_2eserial_2eencodeListGo_24s801(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s801_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s801_clo;
V g_heff_2eserial_2eencodeDict_24s800(V v_d_240, V v_rest_241);
V g_heff_2eserial_2eencodeDict_24s800_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeDict_24s800_clo;
V g_heff_2eserial_2eencodeListGo_24s802(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s802_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s802_clo;
V g_heff_2eserial_2eencodeListGo_24s804(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s804_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s804_clo;
V g_heff_2eserial_2eencodeDict_24s803(V v_d_240, V v_rest_241);
V g_heff_2eserial_2eencodeDict_24s803_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeDict_24s803_clo;
V g_heff_2eserial_2eencodeListGo_24s807(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s807_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s807_clo;
V g_heff_2eserial_2eencodeDict_24s806(V v_d_240, V v_rest_241);
V g_heff_2eserial_2eencodeDict_24s806_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeDict_24s806_clo;
V g_heff_2eserial_2eencodeListGo_24s808(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s808_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s808_clo;
V g_heff_2eserial_2eencodeListGo_24s810(V v_x2_240, V v_rest_241);
V g_heff_2eserial_2eencodeListGo_24s810_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeListGo_24s810_clo;
V g_heff_2eserial_2eencodeDict_24s809(V v_d_240, V v_rest_241);
V g_heff_2eserial_2eencodeDict_24s809_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeDict_24s809_clo;
V g_heff_2eserial_2eencodeTypeF_24s805(V v_t_240, V v_rest_241);
V g_heff_2eserial_2eencodeTypeF_24s805_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeTypeF_24s805_clo;
V g_heff_2eserial_2eencodeTermF_24s799(V v_e_240, V v_rest_241);
V g_heff_2eserial_2eencodeTermF_24s799_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeTermF_24s799_clo;
V g_heff_2eserial_2ewordEnd(V v_s_240, V v_i_241);
V g_heff_2eserial_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2eserial_2ewordEnd_clo;
V g_heff_2eserial_2etakeWord(V v_s_240, V v_i_241);
V g_heff_2eserial_2etakeWord_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeWord_clo;
V g_heff_2eserial_2ecolonAt(V v_s_240, V v_i_241);
V g_heff_2eserial_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2eserial_2ecolonAt_clo;
V g_heff_2eserial_2etakeStrAt(V v_s_240, V v_j_241, V v_n_242);
V g_heff_2eserial_2etakeStrAt_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeStrAt_clo;
V g_heff_2eserial_2etakeStr(V v_s_240, V v_i_241);
V g_heff_2eserial_2etakeStr_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeStr_clo;
V g_heff_2eserial_2etakePlicity(V v_s_240, V v_i_241);
V g_heff_2eserial_2etakePlicity_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakePlicity_clo;
V g_heff_2eserial_2etakeLevel(V v_s_240, V v_i_241);
V g_heff_2eserial_2etakeLevel_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeLevel_clo;
V g_heff_2eserial_2etakeAbs(V v_s_240, V v_f_241, V v_i_242);
V g_heff_2eserial_2etakeAbs_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeAbs_clo;
V g_heff_2eserial_2etakeManyG(V v_f_240, V v_n_241, V v_i_242);
V g_heff_2eserial_2etakeManyG_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeManyG_clo;
V g_heff_2eserial_2etakeDict(V v_s_240, V v_f_241, V v_i_242);
V g_heff_2eserial_2etakeDict_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeDict_clo;
V g_heff_2eserial_2etakeAlt(V v_s_240, V v_k_241, V v_i_242);
V g_heff_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeAlt_clo;
V g_heff_2eserial_2edecodeTermF(V v_k_240, V v_s_241, V v_i_242);
V g_heff_2eserial_2edecodeTermF_entry(V self, V *a);
extern Clo g_heff_2eserial_2edecodeTermF_clo;
V g_heff_2eserial_2edecodeTypeF(V v_k_240, V v_s_241, V v_i_242);
V g_heff_2eserial_2edecodeTypeF_entry(V self, V *a);
extern Clo g_heff_2eserial_2edecodeTypeF_clo;
V g_heff_2eserial_2edkOf(V v_s_240);
V g_heff_2eserial_2edkOf_entry(V self, V *a);
extern Clo g_heff_2eserial_2edkOf_clo;
V g_heff_2ecache_2eversion_get(void);
V g_heff_2ecache_2eversionDir_get(void);
V g_heff_2ecache_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243);
V g_heff_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecache_2ehashGo_clo;
V g_heff_2ecache_2enubCa(V v_x1_240);
V g_heff_2ecache_2enubCa_entry(V self, V *a);
extern Clo g_heff_2ecache_2enubCa_clo;
V g_heff_2ecache_2edefHashOne(V v_m_240, V v_c_241, V v_o_242);
V g_heff_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ecache_2edefHashOne_clo;
V g_heff_2ecache_2ewholeHash(V v_m_240, V v_c_241);
V g_heff_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ecache_2ewholeHash_clo;
V g_prelude_2efoldl_24s811(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s811_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s811_clo;
V g_prelude_2emap_24s812(V v_x2_240);
V g_prelude_2emap_24s812_entry(V self, V *a);
extern Clo g_prelude_2emap_24s812_clo;
V g_prelude_2emap_24s813(V v_x2_240);
V g_prelude_2emap_24s813_entry(V self, V *a);
extern Clo g_prelude_2emap_24s813_clo;
V g_prelude_2efoldl_24s814(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s814_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s814_clo;
V g_heff_2ecache_2efixSig(V v_f_240);
V g_heff_2ecache_2efixSig_entry(V self, V *a);
extern Clo g_heff_2ecache_2efixSig_clo;
V g_prelude_2efoldl_24s815(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s815_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s815_clo;
V g_prelude_2efoldl_24s816(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s816_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s816_clo;
V g_prelude_2efoldl_24s817(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s817_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s817_clo;
V g_heff_2ecache_2efreezeFix(V v_f_240);
V g_heff_2ecache_2efreezeFix_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreezeFix_clo;
V g_heff_2ecache_2ensOf(V v_done_240, V v_m_241);
V g_heff_2ecache_2ensOf_entry(V self, V *a);
extern Clo g_heff_2ecache_2ensOf_clo;
V g_heff_2ecache_2eneedsOf(V v_c_240);
V g_heff_2ecache_2eneedsOf_entry(V self, V *a);
extern Clo g_heff_2ecache_2eneedsOf_clo;
V g_heff_2ecache_2efreezeDef(V v_hashes_240, V v_c_241, V v_x3_242);
V g_heff_2ecache_2efreezeDef_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreezeDef_clo;
V g_heff_2ecache_2ezipCa(V v_x1_240, V v_x2_241);
V g_heff_2ecache_2ezipCa_entry(V self, V *a);
extern Clo g_heff_2ecache_2ezipCa_clo;
V g_heff_2ecache_2eallJust(V v_x1_240);
V g_heff_2ecache_2eallJust_entry(V self, V *a);
extern Clo g_heff_2ecache_2eallJust_clo;
V g_heff_2ecache_2efreeze(V v_hashes_240, V v_done_241, V v_s_242, V v_c_243);
V g_heff_2ecache_2efreeze_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreeze_clo;
V g_heff_2ecache_2emeltFixGroup(V v_s_240, V v_i_241);
V g_heff_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltFixGroup_clo;
V g_heff_2ecache_2emeltFix(V v_s_240, V v_i_241);
V g_heff_2ecache_2emeltFix_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltFix_clo;
V g_heff_2ecache_2emeltDef(V v_s_240, V v_i_241);
V g_heff_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltDef_clo;
V g_heff_2ecache_2epairsHold(V v_p_240, V v_x2_241);
V g_heff_2ecache_2epairsHold_entry(V self, V *a);
extern Clo g_heff_2ecache_2epairsHold_clo;
V g_prelude_2emap_24s818(V v_x2_240);
V g_prelude_2emap_24s818_entry(V self, V *a);
extern Clo g_prelude_2emap_24s818_clo;
V g_heff_2ecache_2emelt(V v_hashes_240, V v_done_241, V v_s_242, V v_text_243);
V g_heff_2ecache_2emelt_entry(V self, V *a);
extern Clo g_heff_2ecache_2emelt_clo;
V g_heff_2esession_2ecacheDir(V v_ps_240);
V g_heff_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2esession_2ecacheDir_clo;
V g_heff_2esession_2ecacheKeep(V v_acc_240, V v_th_241, V v_c_242);
V g_heff_2esession_2ecacheKeep_entry(V self, V *a);
extern Clo g_heff_2esession_2ecacheKeep_clo;
V g_heff_2esession_2ecacheStep(V v_acc_240, V v_s_241, V v_th_242);
V g_heff_2esession_2ecacheStep_entry(V self, V *a);
extern Clo g_heff_2esession_2ecacheStep_clo;
V g_heff_2esession_2ecacheStepLean(V v_acc_240, V v_s_241, V v_th_242);
V g_heff_2esession_2ecacheStepLean_entry(V self, V *a);
extern Clo g_heff_2esession_2ecacheStepLean_clo;
V g_heff_2esession_2ezipSC(V v_x1_240, V v_x2_241);
V g_heff_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2esession_2ezipSC_clo;
V g_std_2eprocess_2eprocess_get(void);
V g_heff_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244);
V g_heff_2ecommands_2eheffVersions_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eheffVersions_clo;
V g_heff_2ecommands_2eheffErrors(V v_running_240, V v_x2_241);
V g_heff_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eheffErrors_clo;
V g_prelude_2efoldl_24s819(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s819_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s819_clo;
V g_heff_2ecommands_2eelemStrM(V v_x_240, V v_x2_241);
V g_heff_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eelemStrM_clo;
V g_heff_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241);
V g_heff_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enubStrGo_clo;
V g_heff_2ecommands_2epathOfModule(V v_x1_240, V v_m_241);
V g_heff_2ecommands_2epathOfModule_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epathOfModule_clo;
V g_heff_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241);
V g_heff_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprovidesLeaf_clo;
V g_prelude_2eany_24s820(V v_x2_240);
V g_prelude_2eany_24s820_entry(V self, V *a);
extern Clo g_prelude_2eany_24s820_clo;
V g_heff_2ecommands_2erunDir(V v_paths_240);
V g_heff_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunDir_clo;
V g_heff_2ecommands_2erunPath(V v_paths_240, V v_file_241);
V g_heff_2ecommands_2erunPath_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunPath_clo;
V g_prelude_2emap_24s821(V v_x2_240);
V g_prelude_2emap_24s821_entry(V self, V *a);
extern Clo g_prelude_2emap_24s821_clo;
V g_heff_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241);
V g_heff_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprovidesLeafC_clo;
V g_prelude_2emap_24s822(V v_x2_240);
V g_prelude_2emap_24s822_entry(V self, V *a);
extern Clo g_prelude_2emap_24s822_clo;
V g_prelude_2efilter_24s823(V v_x2_240);
V g_prelude_2efilter_24s823_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s823_clo;
V g_heff_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242);
V g_heff_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efailLine_clo;
V g_prelude_2efilter_24s824(V v_x2_240);
V g_prelude_2efilter_24s824_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s824_clo;
V g_heff_2ecommands_2estatistic(V v_o_240);
V g_heff_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ecommands_2estatistic_clo;
V g_heff_2ecommands_2eoutcomeLine(V v_o_240);
V g_heff_2ecommands_2eoutcomeLine_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eoutcomeLine_clo;
V g_heff_2ecommands_2efailLines(V v_color_240, V v_x2_241);
V g_heff_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efailLines_clo;
V g_prelude_2emap_24s825(V v_x2_240);
V g_prelude_2emap_24s825_entry(V self, V *a);
extern Clo g_prelude_2emap_24s825_clo;
V g_prelude_2efilter_24s826(V v_x2_240);
V g_prelude_2efilter_24s826_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s826_clo;
V g_prelude_2efilter_24s827(V v_x2_240);
V g_prelude_2efilter_24s827_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s827_clo;
V g_prelude_2emap_24s828(V v_x2_240);
V g_prelude_2emap_24s828_entry(V self, V *a);
extern Clo g_prelude_2emap_24s828_clo;
V g_heff_2ecommands_2edefaultSeed_get(void);
V g_heff_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242);
V g_heff_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprojectName_clo;
V g_heff_2ecommands_2eprojectFiles(V v_name_240, V v_v_241);
V g_heff_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprojectFiles_clo;
V g_heff_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243);
V g_heff_2ecommands_2erequiring_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erequiring_clo;
V g_heff_2ejson_2eescapeAt(V v_s_240, V v_i_241);
V g_heff_2ejson_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2ejson_2eescapeAt_clo;
V g_heff_2ejson_2eescapeGo(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2ejson_2eescapeGo_clo;
V g_prelude_2emap_24s829(V v_x2_240);
V g_prelude_2emap_24s829_entry(V self, V *a);
extern Clo g_prelude_2emap_24s829_clo;
V g_heff_2ejson_2estringify(V v_j_240);
V g_heff_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2ejson_2estringify_clo;
V g_heff_2ejson_2eat(V v_x1_240, V v_j_241);
V g_heff_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2ejson_2eat_clo;
V g_heff_2erpc_2erpc_get(void);
V g_heff_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244);
V g_heff_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2eposition(V v_src_240, V v_i_241);
V g_heff_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2eposition_clo;
V g_heff_2elsp_2erange(V v_src_240, V v_sp_241);
V g_heff_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2erange_clo;
V g_heff_2elsp_2eoffsetIn(V v_src_240, V v_params_241);
V g_heff_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2ediagnostic(V v_src_240, V v_d_241);
V g_heff_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2eloadError(V v_imports_240, V v_e_241);
V g_heff_2elsp_2eloadError_entry(V self, V *a);
extern Clo g_heff_2elsp_2eloadError_clo;
V g_heff_2elsp_2ebrokenImport(V v_imports_240, V v_c_241);
V g_heff_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2ecatMaybesL(V v_x1_240);
V g_heff_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242);
V g_heff_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ediagsOf_clo;
V g_prelude_2emap_24s830(V v_x2_240);
V g_prelude_2emap_24s830_entry(V self, V *a);
extern Clo g_prelude_2emap_24s830_clo;
V g_heff_2elsp_2ekeptOf(V v_program_240);
V g_heff_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2edependentsOf(V v_st_240, V v_f_241);
V g_heff_2elsp_2edependentsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2edependentsOf_clo;
V g_map_2edelete_24s831(V v_k_240, V v_x3_241);
V g_map_2edelete_24s831_entry(V self, V *a);
extern Clo g_map_2edelete_24s831_clo;
V g_heff_2elsp_2enubPaths(V v_x1_240);
V g_heff_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubPaths_clo;
V g_heff_2elsp_2enubSources(V v_x1_240);
V g_heff_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubSources_clo;
V g_heff_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2ehoverOf(V v_a_240, V v_p_241);
V g_heff_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2echildJson(V v_src_240, V v_m_241);
V g_heff_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2echildJson_clo;
V g_heff_2elsp_2edocSymbol(V v_src_240, V v_y_241);
V g_heff_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242);
V g_heff_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elowerGo_clo;
V g_heff_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244);
V g_heff_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2etargetIn_clo;
V g_heff_2elsp_2erenamedText(V v_new_240, V v_os_241);
V g_heff_2elsp_2erenamedText_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamedText_clo;
V g_heff_2elsp_2enubCheckedPaths(V v_x1_240);
V g_heff_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubCheckedPaths_clo;
V g_prelude_2efoldl_24s832(V v_z_240, V v_x3_241);
V g_prelude_2efoldl_24s832_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s832_clo;
V g_heff_2elsp_2eshiftOf(V v_t_240, V v_new_241, V v_b_242);
V g_heff_2elsp_2eshiftOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2eshiftOf_clo;
V g_heff_2elsp_2erenamedTarget(V v_t_240, V v_new_241);
V g_heff_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245);
V g_heff_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242);
V g_heff_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2enubRoots(V v_x1_240);
V g_heff_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubRoots_clo;
V g_prelude_2emap_24s833(V v_x2_240);
V g_prelude_2emap_24s833_entry(V self, V *a);
extern Clo g_prelude_2emap_24s833_clo;
V g_heff_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elastChange(V v_p_240);
V g_heff_2elsp_2elastChange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elastChange_clo;
V g_heff_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242);
V g_heff_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2echanged_clo;
V g_heff_2elsp_2eclosed(V v_st_240, V v_f_241);
V g_heff_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2eclosed_clo;
V g_prelude_2efind_24s834(V v_x2_240);
V g_prelude_2efind_24s834_entry(V self, V *a);
extern Clo g_prelude_2efind_24s834_clo;
V g_prelude_2efind_24s835(V v_x2_240);
V g_prelude_2efind_24s835_entry(V self, V *a);
extern Clo g_prelude_2efind_24s835_clo;
V g_std_2ecli_2elastS(V v_x1_240);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2ecli_2elookupL(V v_k_240, V v_x2_241);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2edupOf(V v_x1_240);
V g_std_2ecli_2edupOf_entry(V self, V *a);
extern Clo g_std_2ecli_2edupOf_clo;
V g_std_2ecli_2elastOnly(V v_x1_240);
V g_std_2ecli_2elastOnly_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOnly_clo;
V g_prelude_2emap_24s836(V v_x2_240);
V g_prelude_2emap_24s836_entry(V self, V *a);
extern Clo g_prelude_2emap_24s836_clo;
V g_prelude_2emap_24s837(V v_x2_240);
V g_prelude_2emap_24s837_entry(V self, V *a);
extern Clo g_prelude_2emap_24s837_clo;
V g_prelude_2eany_24s838(V v_x2_240);
V g_prelude_2eany_24s838_entry(V self, V *a);
extern Clo g_prelude_2eany_24s838_clo;
V g_prelude_2eany_24s839(V v_x2_240);
V g_prelude_2eany_24s839_entry(V self, V *a);
extern Clo g_prelude_2eany_24s839_clo;
V g_prelude_2eany_24s840(V v_x2_240);
V g_prelude_2eany_24s840_entry(V self, V *a);
extern Clo g_prelude_2eany_24s840_clo;
V g_std_2ecli_2eshapeProblem(V v_sh_240);
V g_std_2ecli_2eshapeProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eshapeProblem_clo;
V g_std_2ecli_2elongNamed(V v_sh_240, V v_x_241);
V g_std_2ecli_2elongNamed_entry(V self, V *a);
extern Clo g_std_2ecli_2elongNamed_clo;
V g_std_2ecli_2ecellOf(V v_a_240, V v_c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2enextGo(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2edistance(V v_a_240, V v_b_241);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
V g_std_2ecli_2enearest(V v_sh_240, V v_x_241);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2erestIndex(V v_x1_240, V v_i_241);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2elongF_24s842(V v_at_240, V v_ws_241, V v_body_242);
V g_std_2ecli_2elongF_24s842_entry(V self, V *a);
extern Clo g_std_2ecli_2elongF_24s842_clo;
V g_std_2ecli_2eshortF_24s843(V v_at_240, V v_ws_241, V v_cl_242);
V g_std_2ecli_2eshortF_24s843_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortF_24s843_clo;
V g_std_2ecli_2ewordsF_24s841(V v_at_240, V v_x3_241);
V g_std_2ecli_2ewordsF_24s841_entry(V self, V *a);
extern Clo g_std_2ecli_2ewordsF_24s841_clo;
V g_std_2ecli_2eflagProblem(V v_fs_240, V v_f_241);
V g_std_2ecli_2eflagProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagProblem_clo;
V g_std_2ecli_2efirstJust(V v_g_240, V v_x2_241);
V g_std_2ecli_2efirstJust_entry(V self, V *a);
extern Clo g_std_2ecli_2efirstJust_clo;
V g_std_2ecli_2egroupsGo(V v_x1_240, V v_ws_241);
V g_std_2ecli_2egroupsGo_entry(V self, V *a);
extern Clo g_std_2ecli_2egroupsGo_clo;
V g_std_2ecli_2eparse(V v_t_240, V v_ws_241);
V g_std_2ecli_2eparse_entry(V self, V *a);
extern Clo g_std_2ecli_2eparse_clo;
V g_std_2ecli_2eshortWhere(V v_sh_240, V v_st_241, V v_cl_242);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;
V g_std_2ecli_2ewhereGo(V v_sh_240, V v_ra_241, V v_st_242, V v_x4_243);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;
V g_std_2ecli_2eposAt(V v_x1_240, V v_i_241);
V g_std_2ecli_2eposAt_entry(V self, V *a);
extern Clo g_std_2ecli_2eposAt_clo;
V g_prelude_2emap_24s844(V v_x2_240);
V g_prelude_2emap_24s844_entry(V self, V *a);
extern Clo g_prelude_2emap_24s844_clo;
V g_std_2ecli_2ecompleteAt(V v_sh_240, V v_st_241, V v_cur_242);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2eflagWord(V v_f_240);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_prelude_2emap_24s845(V v_x2_240);
V g_prelude_2emap_24s845_entry(V self, V *a);
extern Clo g_prelude_2emap_24s845_clo;
V g_prelude_2emap_24s846(V v_x2_240);
V g_prelude_2emap_24s846_entry(V self, V *a);
extern Clo g_prelude_2emap_24s846_clo;
V g_std_2ecli_2eheadOf(V v_k_240);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V v_x_240, V v_doc_241);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_prelude_2emap_24s847(V v_x2_240);
V g_prelude_2emap_24s847_entry(V self, V *a);
extern Clo g_prelude_2emap_24s847_clo;
V g_prelude_2efilter_24s848(V v_x2_240);
V g_prelude_2efilter_24s848_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s848_clo;
V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
V g_std_2ecli_2eflagLine(V v_f_240);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_prelude_2emap_24s849(V v_x2_240);
V g_prelude_2emap_24s849_entry(V self, V *a);
extern Clo g_prelude_2emap_24s849_clo;
V g_std_2ecli_2ehelpOf(V v_prog_240, V v_k_241);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2eorList(V v_x1_240);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_prelude_2emap_24s850(V v_x2_240);
V g_prelude_2emap_24s850_entry(V self, V *a);
extern Clo g_prelude_2emap_24s850_clo;
V g_std_2ecli_2eproblemSaid(V v_x1_240);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2ecandidatesText(V v_sh_240, V v_x2_241);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_prelude_2emap_24s851(V v_x2_240);
V g_prelude_2emap_24s851_entry(V self, V *a);
extern Clo g_prelude_2emap_24s851_clo;
V g_prelude_2emap_24s852(V v_x2_240);
V g_prelude_2emap_24s852_entry(V self, V *a);
extern Clo g_prelude_2emap_24s852_clo;
V g_std_2ecli_2ecommandsText(V v_cs_240, V v_cur_241);
V g_std_2ecli_2ecommandsText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecommandsText_clo;
V g_prelude_2emap_24s853(V v_x2_240);
V g_prelude_2emap_24s853_entry(V self, V *a);
extern Clo g_prelude_2emap_24s853_clo;
V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2einitOf(V v_x1_240);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2elastOf(V v_x1_240);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
V g_std_2ecli_2efishScript(V v_prog_240);
V g_std_2ecli_2efishScript_entry(V self, V *a);
extern Clo g_std_2ecli_2efishScript_clo;
V g_std_2ecli_2ebashScript(V v_prog_240);
V g_std_2ecli_2ebashScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ebashScript_clo;
V g_std_2ecli_2ezshScript(V v_prog_240);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;
V g_std_2ecli_2eoutcomeOf(V v_prog_240, V v_k_241, V v_ws_242);
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eoutcomeOf_clo;
V g_std_2ecli_2ereadLine(V v_prog_240, V v_cs_241, V v_x3_242);
V g_std_2ecli_2ereadLine_entry(V self, V *a);
extern Clo g_std_2ecli_2ereadLine_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2ebuildCommands(V v_c_240);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2eprojectCommands(V v_c_240);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etoolCommands(V v_c_240);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2eplus_24s854_get(void);
V g_co_2eplus_24s855_get(void);
V g_co_2eplus_24s857_get(void);
V g_heff_2eload_2eversionsGo_24s878(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244);
V g_heff_2eload_2eversionsGo_24s878_entry(V self, V *a);
extern Clo g_heff_2eload_2eversionsGo_24s878_clo;
V g_heff_2eload_2eversionsOf_24s877(V v_rd_240, V v_root_241);
V g_heff_2eload_2eversionsOf_24s877_entry(V self, V *a);
extern Clo g_heff_2eload_2eversionsOf_24s877_clo;
V g_heff_2eload_2ereadEvery_24s884(V v_read_240, V v_x2_241);
V g_heff_2eload_2ereadEvery_24s884_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadEvery_24s884_clo;
V g_heff_2ecommands_2eprintErrs_24s887(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244);
V g_heff_2ecommands_2eprintErrs_24s887_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintErrs_24s887_clo;
V g_heff_2ecommands_2eputFileDiags_24s894(V v_x1_240);
V g_heff_2ecommands_2eputFileDiags_24s894_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eputFileDiags_24s894_clo;
V g_heff_2ecommands_2eemitErrs_24s902(V v_x1_240, V v_p_241, V v_p_242);
V g_heff_2ecommands_2eemitErrs_24s902_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eemitErrs_24s902_clo;
V g_heff_2ecommands_2ediagCount_24s907(V v_x1_240);
V g_heff_2ecommands_2ediagCount_24s907_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ediagCount_24s907_clo;
V g_heff_2ecommands_2eprintFails_24s909(V v_f_240, V v_color_241, V v_x3_242);
V g_heff_2ecommands_2eprintFails_24s909_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintFails_24s909_clo;
V g_heff_2ecommands_2eprintOutcomes_24s910(V v_color_240, V v_x2_241);
V g_heff_2ecommands_2eprintOutcomes_24s910_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintOutcomes_24s910_clo;
V g_heff_2ecommands_2eprintLines_24s928(V v_x1_240, V v_p_241, V v_p_242);
V g_heff_2ecommands_2eprintLines_24s928_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintLines_24s928_clo;
V g_heff_2ecommands_2eprintDefs_24s1000(V v_c_240, V v_x2_241);
V g_heff_2ecommands_2eprintDefs_24s1000_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintDefs_24s1000_clo;
V g_heff_2ecommands_2eprintAll_24s999(V v_x1_240, V v_bad_241);
V g_heff_2ecommands_2eprintAll_24s999_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintAll_24s999_clo;
V g_heff_2ecommands_2eprintEvals_24s1003(V v_x1_240, V v_p_241, V v_p_242);
V g_heff_2ecommands_2eprintEvals_24s1003_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintEvals_24s1003_clo;
V g_heff_2ecommands_2estyleNow_24s864_24s1010(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2estyleNow_24s864_24s1010_entry(V self, V *a);
extern Clo g_heff_2ecommands_2estyleNow_24s864_24s1010_clo;
V g_heff_2ecommands_2elibDir_24s863_24s1009(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2elibDir_24s863_24s1009_entry(V self, V *a);
extern Clo g_heff_2ecommands_2elibDir_24s863_24s1009_clo;
V g_heff_2ecommands_2emodDir_24s865_24s1011(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2emodDir_24s865_24s1011_entry(V self, V *a);
extern Clo g_heff_2ecommands_2emodDir_24s865_24s1011_clo;
V g_heff_2ecommands_2ehostNow_24s862_24s1008(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2ehostNow_24s862_24s1008_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ehostNow_24s862_24s1008_clo;
V g_heff_2ecommands_2echeckLast_24s893_24s1013(V v_badLoad_240, V v_cs_241);
V g_heff_2ecommands_2echeckLast_24s893_24s1013_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckLast_24s893_24s1013_clo;
V g_heff_2ecommands_2egetFails_24s938_24s1045(V v_why_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2egetFails_24s938_24s1045_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetFails_24s938_24s1045_clo;
V g_heff_2ecommands_2enewestTag_24s943_24s1049(V v_path_240);
V g_heff_2ecommands_2enewestTag_24s943_24s1049_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enewestTag_24s943_24s1049_clo;
V g_heff_2ecommands_2enodeDone_24s950_24s1055(V v_st_240, V v_x_241, V v_next_242);
V g_heff_2ecommands_2enodeDone_24s950_24s1055_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enodeDone_24s950_24s1055_clo;
V g_heff_2ecommands_2epublishFails_24s952_24s1057(V v_why_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2epublishFails_24s952_24s1057_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishFails_24s952_24s1057_clo;
V g_heff_2ecommands_2epublishFails_24s952_24s1058(V v_why_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2epublishFails_24s952_24s1058_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishFails_24s952_24s1058_clo;
V g_heff_2ecommands_2egitOk_24s959_24s1065(V v_what_240, V v_as_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2egitOk_24s959_24s1065_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egitOk_24s959_24s1065_clo;
V g_heff_2ecommands_2epublishTag_24s958_24s1064(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2epublishTag_24s958_24s1064_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishTag_24s958_24s1064_clo;
V g_heff_2ecommands_2epublishTested_24s957_24s1063(V v_v_240, V v_pk_241, V v_r_242);
V g_heff_2ecommands_2epublishTested_24s957_24s1063_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishTested_24s957_24s1063_clo;
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070(V v_badL_240, V v_cs_241);
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eevalDiags_24s1002_24s1070_clo;
V g_heff_2esession_2ethawTry_24s890_24s1076(V v_ps_240, V v_s_241, V v_acc_242);
V g_heff_2esession_2ethawTry_24s890_24s1076_entry(V self, V *a);
extern Clo g_heff_2esession_2ethawTry_24s890_24s1076_clo;
V g_heff_2esession_2ecachedGo_24s889_24s1075(V v_ps_240, V v_x2_241, V v_acc_242);
V g_heff_2esession_2ecachedGo_24s889_24s1075_entry(V self, V *a);
extern Clo g_heff_2esession_2ecachedGo_24s889_24s1075_clo;
V g_heff_2esession_2efreezeOne_24s892_24s1078(V v_ps_240, V v_acc_241, V v_x3_242);
V g_heff_2esession_2efreezeOne_24s892_24s1078_entry(V self, V *a);
extern Clo g_heff_2esession_2efreezeOne_24s892_24s1078_clo;
V g_heff_2esession_2efreezeAll_24s891_24s1077(V v_ps_240, V v_acc_241, V v_x3_242);
V g_heff_2esession_2efreezeAll_24s891_24s1077_entry(V self, V *a);
extern Clo g_heff_2esession_2efreezeAll_24s891_24s1077_clo;
V g_heff_2esession_2ecachedProgram_24s888_24s1074(V v_l_240);
V g_heff_2esession_2ecachedProgram_24s888_24s1074_entry(V self, V *a);
extern Clo g_heff_2esession_2ecachedProgram_24s888_24s1074_clo;
V g_heff_2eload_2eisRoot_24s870_24s1084(V v_st_240, V v_d_241);
V g_heff_2eload_2eisRoot_24s870_24s1084_entry(V self, V *a);
extern Clo g_heff_2eload_2eisRoot_24s870_24s1084_clo;
V g_heff_2eload_2erootFrom_24s869_24s1083(V v_h_240, V v_start_241, V v_d_242);
V g_heff_2eload_2erootFrom_24s869_24s1083_entry(V self, V *a);
extern Clo g_heff_2eload_2erootFrom_24s869_24s1083_clo;
V g_heff_2eload_2epathsFor_24s868_24s1082(V v_h_240, V v_file_241);
V g_heff_2eload_2epathsFor_24s868_24s1082_entry(V self, V *a);
extern Clo g_heff_2eload_2epathsFor_24s868_24s1082_clo;
V g_heff_2eload_2ereadPackageAt_24s871_24s1085(V v_ps_240);
V g_heff_2eload_2ereadPackageAt_24s871_24s1085_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadPackageAt_24s871_24s1085_clo;
V g_heff_2eload_2ereadSumAt_24s874_24s1088(V v_ps_240);
V g_heff_2eload_2ereadSumAt_24s874_24s1088_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadSumAt_24s874_24s1088_clo;
V g_heff_2eload_2ereadPkgAt_24s876_24s1090(V v_ps_240, V v_dir_241, V v_path_242);
V g_heff_2eload_2ereadPkgAt_24s876_24s1090_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadPkgAt_24s876_24s1090_clo;
V g_heff_2eload_2ecachedPkg_24s875_24s1089(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245);
V g_heff_2eload_2ecachedPkg_24s875_24s1089_entry(V self, V *a);
extern Clo g_heff_2eload_2ecachedPkg_24s875_24s1089_clo;
V g_heff_2eload_2eownDir_24s881_24s1093(V v_ps_240, V v_src_241, V v_hd_242, V v_k_243);
V g_heff_2eload_2eownDir_24s881_24s1093_entry(V self, V *a);
extern Clo g_heff_2eload_2eownDir_24s881_24s1093_clo;
V g_heff_2eload_2epkgOf_24s880_24s1092(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243);
V g_heff_2eload_2epkgOf_24s880_24s1092_entry(V self, V *a);
extern Clo g_heff_2eload_2epkgOf_24s880_24s1092_clo;
V g_heff_2eload_2epkgsOf_24s879_24s1091(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244);
V g_heff_2eload_2epkgsOf_24s879_24s1091_entry(V self, V *a);
extern Clo g_heff_2eload_2epkgsOf_24s879_24s1091_clo;
V g_heff_2eload_2ereachAll_24s873_24s1087(V v_ps_240, V v_root_241);
V g_heff_2eload_2ereachAll_24s873_24s1087_entry(V self, V *a);
extern Clo g_heff_2eload_2ereachAll_24s873_24s1087_clo;
V g_heff_2eload_2etopNames_24s882_24s1094(V v_d_240, V v_hd_241, V v_k_242);
V g_heff_2eload_2etopNames_24s882_24s1094_entry(V self, V *a);
extern Clo g_heff_2eload_2etopNames_24s882_24s1094_clo;
V g_heff_2eload_2epackagesOf_24s872_24s1086(V v_ps_240, V v_x2_241);
V g_heff_2eload_2epackagesOf_24s872_24s1086_entry(V self, V *a);
extern Clo g_heff_2eload_2epackagesOf_24s872_24s1086_clo;
V g_heff_2eload_2ereadEvery_24s884_24s1096(V v_x2_240, V v_p_241, V v_p_242);
V g_heff_2eload_2ereadEvery_24s884_24s1096_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadEvery_24s884_24s1096_clo;
V g_heff_2eload_2epartsNamed_24s885_24s1097(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244);
V g_heff_2eload_2epartsNamed_24s885_24s1097_entry(V self, V *a);
extern Clo g_heff_2eload_2epartsNamed_24s885_24s1097_clo;
V g_heff_2eload_2eloadMany_24s883_24s1095(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_x6_244, V v_st_245, V v_rs_246);
V g_heff_2eload_2eloadMany_24s883_24s1095_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadMany_24s883_24s1095_clo;
V g_heff_2eload_2eloadProgramWith_24s867_24s1081(V v_h_240, V v_file_241);
V g_heff_2eload_2eloadProgramWith_24s867_24s1081_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadProgramWith_24s867_24s1081_clo;
V g_heff_2eload_2eloadProgram_24s866_24s1080_get(void);
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_clo;
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079(V v_file_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eload_24s861_24s1007_24s1079_clo;
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073(V v_file_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_clo;
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103(V v_sources_240, V v_m_241);
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_clo;
V g_heff_2ecommands_2ereadProviders_24s898_24s1102(V v_sources_240, V v_x2_241);
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviders_24s898_24s1102_clo;
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244);
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_clo;
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104(V v_host_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246);
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_clo;
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246);
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_clo;
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_cs_247);
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_clo;
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099(V v_file_240, V v_progArgs_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_clo;
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(V v_x1_240, V v_acc_241);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_clo;
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110(V v_file_240, V v_badL_241, V v_cs_242);
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_clo;
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109(V v_file_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_clo;
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246);
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo;
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244);
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_clo;
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243);
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_clo;
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113(V v_file_240, V v_outPath_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_clo;
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120(V v_sources_240, V v_m_241);
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviderC_24s921_24s1120_clo;
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119(V v_sources_240, V v_x2_241);
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_clo;
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243);
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_clo;
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244);
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_clo;
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121(V v_file_240, V v_name_241, V v_outPath_242, V v_runtime_243, V v_done_244, V v_c_245, V v_available_246);
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_clo;
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_clo;
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118(V v_sources_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_cs_245);
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_clo;
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243, V v_hd_244, V v_k_245);
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_clo;
V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116(V v_name_240, V v_outPath_241, V v_file_242);
V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_clo;
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111(V v_o_240);
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_clo;
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125(V v_file_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_clo;
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126(V v_file_240, V v_offs_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_clo;
V g_heff_2ecommands_2efmtSrc_24s933_24s1130(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtSrc_24s933_24s1130_clo;
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_clo;
V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244);
V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_clo;
V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127(V v_check_240, V v_files_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_clo;
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_clo;
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243);
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_clo;
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131(V v_dir_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_entry(V self, V *a);
extern Clo g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_clo;
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137(V v_ps_240, V v_path_241, V v_v_242);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_clo;
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245);
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_clo;
V g_heff_2ecommands_2esumsOf_24s942_24s1138(V v_ps_240, V v_root_241, V v_x3_242);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_entry(V self, V *a);
extern Clo g_heff_2ecommands_2esumsOf_24s942_24s1138_clo;
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135(V v_hd_240, V v_k_241);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_clo;
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_clo;
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134(V v_spec_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_clo;
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141(V v_st_240, V v_x2_241);
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprogramsIn_24s946_24s1141_clo;
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144(V v_st_240, V v_x_241, V v_next_242);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_clo;
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143(V v_st_240, V v_x_241, V v_a_242, V v_next_243);
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_clo;
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142(V v_st_240, V v_x2_241);
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_clo;
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140(V v_names_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_clo;
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(V v_x1_240, V v_acc_241);
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_clo;
V g_heff_2elsp_2ereadOpen_24s970_24s1158(V v_st_240, V v_p_241);
V g_heff_2elsp_2ereadOpen_24s970_24s1158_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereadOpen_24s970_24s1158_clo;
V g_heff_2eload_2eloadMany_24s883_24s1160(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x6_245, V v_st_246, V v_rs_247);
V g_heff_2eload_2eloadMany_24s883_24s1160_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadMany_24s883_24s1160_clo;
V g_heff_2eload_2eloadProgramWith_24s867_24s1159(V v_read_240, V v_h_241, V v_file_242);
V g_heff_2eload_2eloadProgramWith_24s867_24s1159_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadProgramWith_24s867_24s1159_clo;
V g_heff_2elsp_2erootsOf_24s978_24s1164(V v_st_240, V v_x2_241);
V g_heff_2elsp_2erootsOf_24s978_24s1164_entry(V self, V *a);
extern Clo g_heff_2elsp_2erootsOf_24s978_24s1164_clo;
V g_heff_2elsp_2eloadAll_24s983_24s1169(V v_read_240, V v_lib_241, V v_x3_242);
V g_heff_2elsp_2eloadAll_24s983_24s1169_entry(V self, V *a);
extern Clo g_heff_2elsp_2eloadAll_24s983_24s1169_clo;
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176(V v_x1_240, V v_p_241, V v_p_242);
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_clo;
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175(V v_paths_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_clo;
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177(V v_file_240, V v_hd_241, V v_k_242);
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_clo;
V g_heff_2ecommands_2etestReport_24s908_24s1183(V v_f_240, V v_bad_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245);
V g_heff_2ecommands_2etestReport_24s908_24s1183_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestReport_24s908_24s1183_clo;
V g_heff_2ecommands_2etestOneC_24s906_24s1182(V v_seed_240, V v_f_241, V v_bad0_242, V v_cs_243);
V g_heff_2ecommands_2etestOneC_24s906_24s1182_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestOneC_24s906_24s1182_clo;
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181(V v_seed_240, V v_f_241, V v_hd_242, V v_k_243);
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_clo;
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180(V v_seed_240, V v_x2_241, V v_acc_242);
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_clo;
V g_app_2eheff_2emain_2ebuild_24s859_24s1005_24s1072_24s1179_get(void);
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187(V v_x1_240, V v_acc_241, V v_p_242, V v_p_243);
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_clo;
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244);
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_clo;
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185(V v_v_240, V v_l_241, V v_pk_242);
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_clo;
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184(V v_v_240);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_clo;
V g_heff_2erpc_2eawait_24s963_24s1192(V v_ms_240);
V g_heff_2erpc_2eawait_24s963_24s1192_entry(V self, V *a);
extern Clo g_heff_2erpc_2eawait_24s963_24s1192_clo;
V g_heff_2elsp_2edocPath_24s967_24s1196(V v_p_240);
V g_heff_2elsp_2edocPath_24s967_24s1196_entry(V self, V *a);
extern Clo g_heff_2elsp_2edocPath_24s967_24s1196_clo;
V g_heff_2elsp_2enotify_24s971_24s1199(V v_method_240, V v_params_241);
V g_heff_2elsp_2enotify_24s971_24s1199_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotify_24s971_24s1199_clo;
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198(V v_st_240, V v_f_241);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeck_24s969_24s1157_24s1198_clo;
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(V v_st_240, V v_x2_241);
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_clo;
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(V v_st_240, V v_f_241);
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_clo;
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195(V v_st_240, V v_m_241, V v_p_242);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotified_24s966_24s1155_24s1195_clo;
V g_heff_2elsp_2enotification_24s965_24s1154_24s1194(V v_st_240, V v_m_241, V v_p_242);
V g_heff_2elsp_2enotification_24s965_24s1154_24s1194_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotification_24s965_24s1154_24s1194_clo;
V g_heff_2elsp_2ereplyError_24s973_24s1201(V v_id_240, V v_code_241, V v_msg_242);
V g_heff_2elsp_2ereplyError_24s973_24s1201_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereplyError_24s973_24s1201_clo;
V g_heff_2elsp_2ereply_24s975_24s1203(V v_id_240, V v_result_241);
V g_heff_2elsp_2ereply_24s975_24s1203_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereply_24s975_24s1203_clo;
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(V v_st_240, V v_p_241);
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_entry(V self, V *a);
extern Clo g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_clo;
V g_heff_2elsp_2euriOf_24s977_24s1205(V v_st_240, V v_p_241);
V g_heff_2elsp_2euriOf_24s977_24s1205_entry(V self, V *a);
extern Clo g_heff_2elsp_2euriOf_24s977_24s1205_clo;
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209(V v_read_240, V v_lib_241, V v_root_242, V v_f_243, V v_hd_244, V v_k_245);
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_entry(V self, V *a);
extern Clo g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_clo;
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244);
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_clo;
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207(V v_st_240, V v_f_241);
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_entry(V self, V *a);
extern Clo g_heff_2elsp_2eproject_24s980_24s1166_24s1207_clo;
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206(V v_st_240, V v_x2_241);
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_clo;
V g_heff_2elsp_2esymbolJson_24s986_24s1212(V v_st_240, V v_c_241, V v_y_242);
V g_heff_2elsp_2esymbolJson_24s986_24s1212_entry(V self, V *a);
extern Clo g_heff_2elsp_2esymbolJson_24s986_24s1212_clo;
V g_heff_2elsp_2eeachSymbol_24s985_24s1211(V v_st_240, V v_c_241, V v_x3_242);
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_entry(V self, V *a);
extern Clo g_heff_2elsp_2eeachSymbol_24s985_24s1211_clo;
V g_heff_2elsp_2esymbolsJson_24s984_24s1210(V v_st_240, V v_query_241, V v_x3_242);
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_entry(V self, V *a);
extern Clo g_heff_2elsp_2esymbolsJson_24s984_24s1210_clo;
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(V v_st_240, V v_p_241);
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_entry(V self, V *a);
extern Clo g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_clo;
V g_heff_2elsp_2elocationOf_24s989_24s1215(V v_st_240, V v_o_241);
V g_heff_2elsp_2elocationOf_24s989_24s1215_entry(V self, V *a);
extern Clo g_heff_2elsp_2elocationOf_24s989_24s1215_clo;
V g_heff_2elsp_2elocations_24s988_24s1214(V v_st_240, V v_x2_241);
V g_heff_2elsp_2elocations_24s988_24s1214_entry(V self, V *a);
extern Clo g_heff_2elsp_2elocations_24s988_24s1214_clo;
V g_heff_2elsp_2eprepared_24s990_24s1216(V v_id_240, V v_tg_241);
V g_heff_2elsp_2eprepared_24s990_24s1216_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprepared_24s990_24s1216_clo;
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218(V v_st_240, V v_t_241, V v_new_242);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_clo;
V g_heff_2elsp_2echangesOf_24s993_24s1219(V v_st_240, V v_new_241, V v_x3_242);
V g_heff_2elsp_2echangesOf_24s993_24s1219_entry(V self, V *a);
extern Clo g_heff_2elsp_2echangesOf_24s993_24s1219_clo;
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217(V v_id_240, V v_new_241, V v_tg_242);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_clo;
V g_heff_2elsp_2eformattedIn_24s995_24s1221(V v_st_240, V v_id_241, V v_d_242, V v_fix_243);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_entry(V self, V *a);
extern Clo g_heff_2elsp_2eformattedIn_24s995_24s1221_clo;
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220(V v_st_240, V v_id_241, V v_p_242);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_entry(V self, V *a);
extern Clo g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_clo;
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202(V v_st_240, V v_m_241, V v_id_242, V v_p_243);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_entry(V self, V *a);
extern Clo g_heff_2elsp_2erequest_24s974_24s1162_24s1202_clo;
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193(V v_st_240, V v_msg_241);
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_entry(V self, V *a);
extern Clo g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_clo;
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222(V v_st_240, V v_x2_241);
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_clo;
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(V v_st_240, V v_hd_241, V v_k_242);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_entry(V self, V *a);
extern Clo g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_clo;
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190(V v_h0_240, V v_hd_241, V v_k_242);
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_entry(V self, V *a);
extern Clo g_heff_2elsp_2eserve_24s961_24s1151_24s1190_clo;
V g_app_2eheff_2emain_2etool_24s960_24s1066_24s1150_24s1189_get(void);
V g_app_2eheff_2emain_2eprogram_24s858_24s1004_24s1071_24s1178_24s1188_24s1223_24s1224_get(void);
V g_run_24entry_get(void);