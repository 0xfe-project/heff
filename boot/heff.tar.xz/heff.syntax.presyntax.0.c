// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatVar 49363
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2earmT(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econdT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2edoT_get(void);
V g_heff_2esyntax_2epresyntax_2eelseLeaving(V, V);
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str1, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2epackE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackE(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), v_sp_240});
    }
    case TAG_Cons: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str1)}), heff_dup(v_sp_240)});
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2epackE(v_sp_240, v_x22_243));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epackE(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str0, 12, "builtin.Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str1, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str3, 14, "prelude.typeOf");
Clo g_heff_2esyntax_2epresyntax_2epackTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackTy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackTy(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str1)}), heff_dup(v_sp_240)});
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), v_sp_240});
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246);
    }
    case TAG_Cons: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str2)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str3)}), heff_dup(v_sp_240)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2412));
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_x22_243));
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epackTy(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str2, 1, "`");
V g_heff_2esyntax_2epresyntax_2earmT_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2earmT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmT_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2earmT(V v_t_240, V v_cx_241, V v_end_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_xs_246 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_244)));
    HeffT2 v_t_248 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2earmT_lam0, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_246));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_240, 1);
        heff_drop_rec(v_cx_241, 6);
        heff_drop(v_end_242);
        heff_drop(v_ss_245);
        V v_x_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_p_244, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_str0), heff_strAppend(heff_dup(v_x_2411), ((V)&g_heff_2esyntax_2epresyntax_2earmT_str1)));
        V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_str2), heff_strAppend(v_x_2411, v_t_2415));
        V v_t_2417 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2416}), heff_dup(v_t_2414)});
        V v_t_2420;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2419 = heff_dup(heff_field(v_p_244, 1));
          v_t_2420 = v_s_2419;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2414, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2420, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_2417}), v_t_2421});
      } else {
        heff_drop(v_field_2410);
        V v_e_2422 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_ss_245, v_end_242}));
        V v_t_2425;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_p_244, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2428;
        switch (heff_tag_of(v_e_2422)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_e_2422, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_e_2422);
        }
        V v_t_2429 = ({ V rv_1 = heff_get_n(v_t_2428, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2425, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_e_2422}), v_t_2429});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmT(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2earmT_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_247; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_247); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str0, 7, "recover");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str1, 3, "err");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str2, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2etryScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryScope_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2etryScope(V v_t_240, V v_cx_241, V v_sp_242, V v_x4_243, V v_end_244) {
top: ;
  V v_names_245 = heff_take_field(v_cx_241, 0);
  V v_sp_246 = heff_take_field(v_cx_241, 3);
  V v_muts_247 = heff_take_field(v_cx_241, 1);
  V v_loop_248 = heff_take_field(v_cx_241, 2);
  V v_depth_249 = heff_take_field(v_cx_241, 4);
  V v_giving_2410 = heff_get_n(v_cx_241, 5, 6);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkTry: {
    V v_err_2411 = heff_field(v_x4_243, 0);
    V v_body_2412 = heff_field(v_x4_243, 1);
    V v_h_2413 = heff_field(v_x4_243, 2);
    V v_t_2414 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_names_245, 0))});
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str0)}), heff_dup(v_sp_242)});
    V v_t_2421;
    switch (heff_tag_of(v_err_2411)) {
    case TAG_Nothing: {
      v_t_2421 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_ty_2416 = heff_field(v_err_2411, 0);
      V v_t_2419;
      switch (heff_tag_of(v_ty_2416)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_ty_2416, 1);
        v_t_2419 = heff_dup(v_s_2418);
        break;
      }
      default: heff_nomatch(v_ty_2416);
      }
      V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENamed, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str1), heff_dup(v_ty_2416)}), v_t_2419});
      v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_err_2411);
    }
    V v_t_2422 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(v_names_245), heff_dup(v_muts_247), heff_dup(v_loop_248), heff_dup(v_sp_246), heff_intAdd(heff_dup(v_depth_249), MK_INT(1LL)), heff_dup(v_giving_2410)});
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_t_240, 0)), 3, (V[]){v_t_2422, heff_dup(v_body_2412), heff_dup(v_end_244)}));
    V v_t_2428;
    switch (heff_tag_of(v_h_2413)) {
    case TAG_MkCatchArm: {
      V v_b_2424 = heff_field(v_h_2413, 0);
      V v_ss_2425 = heff_field(v_h_2413, 1);
      V v_t_2426 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){v_names_245, v_muts_247, v_loop_248, heff_dup(v_sp_246), heff_intAdd(v_depth_249, MK_INT(1LL)), v_giving_2410});
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2426, heff_dup(v_ss_2425), v_end_244}));
      v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_b_2424), v_t_2427}), heff_dup(v_sp_242)});
      break;
    }
    default: heff_nomatch(v_h_2413);
    }
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2429})));
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2430));
    V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str2)}), v_sp_242});
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_246}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2433})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2etryScope(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str3, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str4, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str6, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str7, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str9, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str10, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str12, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str13, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str15, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str16, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str17, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str18, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str19, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str21, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str22, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str24, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str25, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str27, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str28, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str30, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str31, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str33, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str34, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str36, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str37, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str39, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str40, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str42, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str43, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str45, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str46, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str47, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str48, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str49, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str51, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str52, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str53, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str54, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str55, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str57, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str58, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str59, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str60, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str61, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str63, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str64, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str65, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str66, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str67, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str69, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str70, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str71, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str72, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str73, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str75, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str76, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str77, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str78, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str79, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str81, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str82, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str83, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str84, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str85, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str87, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str88, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str89, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str90, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str91, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str92, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str93, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str94, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str95, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str96, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str97, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str98, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str99, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str100, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str101, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str102, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str103, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str104, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str105, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str106, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str107, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str108, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str109, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str110, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str111, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str112, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str113, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str114, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str115, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str116, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str117, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str118, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str119, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str120, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str121, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str122, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str123, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str124, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str125, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str126, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str127, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str128, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str129, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str130, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str131, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str132, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str133, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str134, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str135, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str136, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str137, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str138, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str139, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str140, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str141, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str142, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str143, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str144, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str145, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str146, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str147, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str148, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str149, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str150, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str151, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str152, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str153, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str154, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str155, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str156, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str157, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str158, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str159, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str160, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str161, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str162, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str163, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str164, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str165, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str166, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str167, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str168, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str169, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str170, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str171, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str172, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str173, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str174, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str175, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str176, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str177, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str178, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str179, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str180, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str181, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str182, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str183, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str184, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str185, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str186, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str187, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str188, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str189, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str190, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str191, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str192, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str193, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str194, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str195, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str196, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str197, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str198, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str199, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str200, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str201, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str202, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str203, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str204, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str205, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str206, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str207, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str208, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str209, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str210, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str211, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str212, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str213, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str214, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str215, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str216, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str217, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str218, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str219, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str220, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str221, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str222, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str223, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str224, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str225, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str226, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str227, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str228, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str229, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str230, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str231, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str232, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str233, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str234, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str235, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str236, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str237, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str238, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str239, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str240, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str241, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str242, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str243, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str244, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str245, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str246, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str247, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str248, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str249, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str250, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str251, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str252, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str253, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str254, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str255, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str256, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str257, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str258, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str259, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str260, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str261, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str262, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str263, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str264, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str265, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str266, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str267, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str268, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str269, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str270, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str271, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str272, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str273, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str274, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str275, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str276, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str277, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str278, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str279, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str280, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str281, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str282, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str283, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str284, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str285, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str286, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str287, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str288, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str289, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str290, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str291, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str292, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str293, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str294, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str295, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str296, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str297, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str298, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str299, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str300, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str301, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str302, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str303, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str304, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str305, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str306, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str307, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str308, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str309, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str310, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str311, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str312, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str313, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str314, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str315, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str316, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str317, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str318, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str319, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str320, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str321, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str322, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str323, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str324, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str325, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str326, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str327, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str328, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str329, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str330, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str331, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str332, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str333, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str334, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str335, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str336, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str337, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str338, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str339, 1, "_");
V g_heff_2esyntax_2epresyntax_2estmtT_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam3(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam4(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam5(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam6(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam7(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam8(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam9(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam10(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam11(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam12(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam13(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam14(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam15(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam16(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam17(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam18(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam19(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam20(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam21(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam22(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam23(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam24(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam25(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam26(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam27(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam28(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam29(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam30(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam31(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam32(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam33(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam34(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam35(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam36(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam37(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam38(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam39(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam40(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam41(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam42(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam43(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam44(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam45(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam46(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam47(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam48(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam49(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam50(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam51(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam52(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam53(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam54(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam55(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam56(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam57(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam58(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam59(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam60(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam61(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam62(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam63(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam64(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam65(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam66(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam67(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam68(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam69(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam70(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam71(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam72(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam73(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2estmtT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtT_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2estmtT(V v_t_240, V v_cx_241, V v_x3_242, V v_rest_243, V v_end_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_sp_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_StmtBind: {
      V v_x_247 = heff_field(v_x31_245, 0);
      V v_xsp_248 = heff_field(v_x31_245, 1);
      V v_x313_249 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      heff_drop_rec(v_sp_246, 2);
      switch (heff_tag_of(v_x313_249)) {
      case TAG_At: {
        V v_x3131_2410 = heff_dup(heff_field(v_x313_249, 0));
        switch (heff_tag_of(v_x3131_2410)) {
        case TAG_EVar: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_2413 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2413);
            V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str0), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str1)));
            V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str2), heff_strAppend(v_x_247, v_t_2414));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2415}), v_xsp_248});
          } else {
            heff_drop(v_t_2413);
            V v_t_2416 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2416}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2418 = v_t_2417.f[0];
              V v_field_2419 = v_t_2417.f[1];
              V v_x_2420 = v_field_2418;
              V v_y_2421 = v_field_2419;
              V v_rest_2422 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_2424 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2423}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2425 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2422)});
              V v_t_2428;
              switch (heff_tag_of(v_rest_2422)) {
              case TAG_At: {
                V v_s_2427 = heff_field(v_rest_2422, 1);
                heff_take_n(v_rest_2422, 2ULL, 2);
                v_t_2428 = v_s_2427;
                break;
              }
              default: heff_nomatch(v_rest_2422);
              }
              V v_t_2429 = ({ V rv_1 = heff_get_n(v_t_2428, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2429}), NTAG(TAG_Nil)});
              V v_t_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2421, v_t_2430})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2420; V a_2 = v_t_2431; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2420); r_; });
            }
          }
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_2433 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2433);
            V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str3), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str4)));
            V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str5), heff_strAppend(v_x_247, v_t_2434));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2435}), v_xsp_248});
          } else {
            heff_drop(v_t_2433);
            V v_t_2436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2436}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2438 = v_t_2437.f[0];
              V v_field_2439 = v_t_2437.f[1];
              V v_x_2440 = v_field_2438;
              V v_y_2441 = v_field_2439;
              V v_rest_2442 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_2444 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2443}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2445 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2442)});
              V v_t_2448;
              switch (heff_tag_of(v_rest_2442)) {
              case TAG_At: {
                V v_s_2447 = heff_field(v_rest_2442, 1);
                heff_take_n(v_rest_2442, 2ULL, 2);
                v_t_2448 = v_s_2447;
                break;
              }
              default: heff_nomatch(v_rest_2442);
              }
              V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2449}), NTAG(TAG_Nil)});
              V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2441, v_t_2450})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2440; V a_2 = v_t_2451; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
            }
          }
        }
        case TAG_ETag: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_2453 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2453);
            V v_t_2454 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str6), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str7)));
            V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str8), heff_strAppend(v_x_247, v_t_2454));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2455}), v_xsp_248});
          } else {
            heff_drop(v_t_2453);
            V v_t_2456 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2456}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2458 = v_t_2457.f[0];
              V v_field_2459 = v_t_2457.f[1];
              V v_x_2460 = v_field_2458;
              V v_y_2461 = v_field_2459;
              V v_rest_2462 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_2464 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2463}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2465 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2462)});
              V v_t_2468;
              switch (heff_tag_of(v_rest_2462)) {
              case TAG_At: {
                V v_s_2467 = heff_field(v_rest_2462, 1);
                heff_take_n(v_rest_2462, 2ULL, 2);
                v_t_2468 = v_s_2467;
                break;
              }
              default: heff_nomatch(v_rest_2462);
              }
              V v_t_2469 = ({ V rv_1 = heff_get_n(v_t_2468, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_t_2469}), NTAG(TAG_Nil)});
              V v_t_2471 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2464, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2461, v_t_2470})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2460; V a_2 = v_t_2471; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2460); r_; });
            }
          }
        }
        case TAG_EInt: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_2473 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2473);
            V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str9), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str10)));
            V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str11), heff_strAppend(v_x_247, v_t_2474));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2475}), v_xsp_248});
          } else {
            heff_drop(v_t_2473);
            V v_t_2476 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2477 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2476}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2478 = v_t_2477.f[0];
              V v_field_2479 = v_t_2477.f[1];
              V v_x_2480 = v_field_2478;
              V v_y_2481 = v_field_2479;
              V v_rest_2482 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2483 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_2484 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2483}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2485 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2482)});
              V v_t_2488;
              switch (heff_tag_of(v_rest_2482)) {
              case TAG_At: {
                V v_s_2487 = heff_field(v_rest_2482, 1);
                heff_take_n(v_rest_2482, 2ULL, 2);
                v_t_2488 = v_s_2487;
                break;
              }
              default: heff_nomatch(v_rest_2482);
              }
              V v_t_2489 = ({ V rv_1 = heff_get_n(v_t_2488, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2485, v_t_2489}), NTAG(TAG_Nil)});
              V v_t_2491 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2484, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2481, v_t_2490})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2480; V a_2 = v_t_2491; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2480); r_; });
            }
          }
        }
        case TAG_EFloat: {
          heff_take_na(v_x3131_2410, 0ULL, 1);
          V v_t_2493 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2493);
            V v_t_2494 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str12), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str13)));
            V v_t_2495 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str14), heff_strAppend(v_x_247, v_t_2494));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2495}), v_xsp_248});
          } else {
            heff_drop(v_t_2493);
            V v_t_2496 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2496}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2498 = v_t_2497.f[0];
              V v_field_2499 = v_t_2497.f[1];
              V v_x_24100 = v_field_2498;
              V v_y_24101 = v_field_2499;
              V v_rest_24102 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24103 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24104 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24103}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24105 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24102)});
              V v_t_24108;
              switch (heff_tag_of(v_rest_24102)) {
              case TAG_At: {
                V v_s_24107 = heff_field(v_rest_24102, 1);
                heff_take_n(v_rest_24102, 2ULL, 2);
                v_t_24108 = v_s_24107;
                break;
              }
              default: heff_nomatch(v_rest_24102);
              }
              V v_t_24109 = ({ V rv_1 = heff_get_n(v_t_24108, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24105, v_t_24109}), NTAG(TAG_Nil)});
              V v_t_24111 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24104, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24101, v_t_24110})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24100; V a_2 = v_t_24111; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24100); r_; });
            }
          }
        }
        case TAG_EString: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24113 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24113);
            V v_t_24114 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str15), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str16)));
            V v_t_24115 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str17), heff_strAppend(v_x_247, v_t_24114));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24115}), v_xsp_248});
          } else {
            heff_drop(v_t_24113);
            V v_t_24116 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24116}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24118 = v_t_24117.f[0];
              V v_field_24119 = v_t_24117.f[1];
              V v_x_24120 = v_field_24118;
              V v_y_24121 = v_field_24119;
              V v_rest_24122 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24123 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24124 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24123}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24125 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24122)});
              V v_t_24128;
              switch (heff_tag_of(v_rest_24122)) {
              case TAG_At: {
                V v_s_24127 = heff_field(v_rest_24122, 1);
                heff_take_n(v_rest_24122, 2ULL, 2);
                v_t_24128 = v_s_24127;
                break;
              }
              default: heff_nomatch(v_rest_24122);
              }
              V v_t_24129 = ({ V rv_1 = heff_get_n(v_t_24128, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24125, v_t_24129}), NTAG(TAG_Nil)});
              V v_t_24131 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24124, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24121, v_t_24130})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24120; V a_2 = v_t_24131; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24120); r_; });
            }
          }
        }
        case TAG_EBinary: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24133 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24133);
            V v_t_24134 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str18), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str19)));
            V v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str20), heff_strAppend(v_x_247, v_t_24134));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24135}), v_xsp_248});
          } else {
            heff_drop(v_t_24133);
            V v_t_24136 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24137 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24136}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24138 = v_t_24137.f[0];
              V v_field_24139 = v_t_24137.f[1];
              V v_x_24140 = v_field_24138;
              V v_y_24141 = v_field_24139;
              V v_rest_24142 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24143 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24144 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24143}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24145 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24142)});
              V v_t_24148;
              switch (heff_tag_of(v_rest_24142)) {
              case TAG_At: {
                V v_s_24147 = heff_field(v_rest_24142, 1);
                heff_take_n(v_rest_24142, 2ULL, 2);
                v_t_24148 = v_s_24147;
                break;
              }
              default: heff_nomatch(v_rest_24142);
              }
              V v_t_24149 = ({ V rv_1 = heff_get_n(v_t_24148, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24145, v_t_24149}), NTAG(TAG_Nil)});
              V v_t_24151 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24144, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24141, v_t_24150})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24140; V a_2 = v_t_24151; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24140); r_; });
            }
          }
        }
        case TAG_ERune: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24153 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24153) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24153);
            V v_t_24154 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str21), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str22)));
            V v_t_24155 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str23), heff_strAppend(v_x_247, v_t_24154));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24155}), v_xsp_248});
          } else {
            heff_drop(v_t_24153);
            V v_t_24156 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24157 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24156}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24158 = v_t_24157.f[0];
              V v_field_24159 = v_t_24157.f[1];
              V v_x_24160 = v_field_24158;
              V v_y_24161 = v_field_24159;
              V v_rest_24162 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24163 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24164 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24163}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24165 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24162)});
              V v_t_24168;
              switch (heff_tag_of(v_rest_24162)) {
              case TAG_At: {
                V v_s_24167 = heff_field(v_rest_24162, 1);
                heff_take_n(v_rest_24162, 2ULL, 2);
                v_t_24168 = v_s_24167;
                break;
              }
              default: heff_nomatch(v_rest_24162);
              }
              V v_t_24169 = ({ V rv_1 = heff_get_n(v_t_24168, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24170 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24165, v_t_24169}), NTAG(TAG_Nil)});
              V v_t_24171 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24164, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24161, v_t_24170})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24160; V a_2 = v_t_24171; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24160); r_; });
            }
          }
        }
        case TAG_EWord: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24173 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24173) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24173);
            V v_t_24174 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str24), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str25)));
            V v_t_24175 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str26), heff_strAppend(v_x_247, v_t_24174));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24175}), v_xsp_248});
          } else {
            heff_drop(v_t_24173);
            V v_t_24176 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24177 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24176}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24178 = v_t_24177.f[0];
              V v_field_24179 = v_t_24177.f[1];
              V v_x_24180 = v_field_24178;
              V v_y_24181 = v_field_24179;
              V v_rest_24182 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24183 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24184 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24183}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24185 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24182)});
              V v_t_24188;
              switch (heff_tag_of(v_rest_24182)) {
              case TAG_At: {
                V v_s_24187 = heff_field(v_rest_24182, 1);
                heff_take_n(v_rest_24182, 2ULL, 2);
                v_t_24188 = v_s_24187;
                break;
              }
              default: heff_nomatch(v_rest_24182);
              }
              V v_t_24189 = ({ V rv_1 = heff_get_n(v_t_24188, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24190 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24185, v_t_24189}), NTAG(TAG_Nil)});
              V v_t_24191 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24184, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24181, v_t_24190})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24180; V a_2 = v_t_24191; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24180); r_; });
            }
          }
        }
        case TAG_EApp: {
          V v_ru_24x3131_2410_24EApp = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24194 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24194) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EApp, 2);
            heff_drop(v_t_24194);
            V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str27), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str28)));
            V v_t_24196 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str29), heff_strAppend(v_x_247, v_t_24195));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24196}), v_xsp_248});
          } else {
            heff_drop(v_t_24194);
            V v_t_24197 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24198 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24197}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24199 = v_t_24198.f[0];
              V v_field_24200 = v_t_24198.f[1];
              V v_x_24201 = v_field_24199;
              V v_y_24202 = v_field_24200;
              V v_rest_24203 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24204 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24205 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24204}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24206 = heff_tag_at_n(v_ru_24x3131_2410_24EApp, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24203)});
              V v_t_24209;
              switch (heff_tag_of(v_rest_24203)) {
              case TAG_At: {
                V v_s_24208 = heff_field(v_rest_24203, 1);
                heff_take_n(v_rest_24203, 2ULL, 2);
                v_t_24209 = v_s_24208;
                break;
              }
              default: heff_nomatch(v_rest_24203);
              }
              V v_t_24210 = ({ V rv_1 = heff_get_n(v_t_24209, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24211 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24206, v_t_24210}), NTAG(TAG_Nil)});
              V v_t_24212 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24205, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24202, v_t_24211})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24201; V a_2 = v_t_24212; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24201); r_; });
            }
          }
        }
        case TAG_EProject: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24214 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24214) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24214);
            V v_t_24215 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str30), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str31)));
            V v_t_24216 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str32), heff_strAppend(v_x_247, v_t_24215));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24216}), v_xsp_248});
          } else {
            heff_drop(v_t_24214);
            V v_t_24217 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24218 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24217}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24219 = v_t_24218.f[0];
              V v_field_24220 = v_t_24218.f[1];
              V v_x_24221 = v_field_24219;
              V v_y_24222 = v_field_24220;
              V v_rest_24223 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24224 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24225 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24224}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24226 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24223)});
              V v_t_24229;
              switch (heff_tag_of(v_rest_24223)) {
              case TAG_At: {
                V v_s_24228 = heff_field(v_rest_24223, 1);
                heff_take_n(v_rest_24223, 2ULL, 2);
                v_t_24229 = v_s_24228;
                break;
              }
              default: heff_nomatch(v_rest_24223);
              }
              V v_t_24230 = ({ V rv_1 = heff_get_n(v_t_24229, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24226, v_t_24230}), NTAG(TAG_Nil)});
              V v_t_24232 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24225, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24222, v_t_24231})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24221; V a_2 = v_t_24232; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24221); r_; });
            }
          }
        }
        case TAG_ENamed: {
          V v_ru_24x3131_2410_24ENamed = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24235 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24235) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ENamed, 2);
            heff_drop(v_t_24235);
            V v_t_24236 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str33), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str34)));
            V v_t_24237 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str35), heff_strAppend(v_x_247, v_t_24236));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24237}), v_xsp_248});
          } else {
            heff_drop(v_t_24235);
            V v_t_24238 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24239 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24238}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24240 = v_t_24239.f[0];
              V v_field_24241 = v_t_24239.f[1];
              V v_x_24242 = v_field_24240;
              V v_y_24243 = v_field_24241;
              V v_rest_24244 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24245 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24246 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24245}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24247 = heff_tag_at_n(v_ru_24x3131_2410_24ENamed, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24244)});
              V v_t_24250;
              switch (heff_tag_of(v_rest_24244)) {
              case TAG_At: {
                V v_s_24249 = heff_field(v_rest_24244, 1);
                heff_take_n(v_rest_24244, 2ULL, 2);
                v_t_24250 = v_s_24249;
                break;
              }
              default: heff_nomatch(v_rest_24244);
              }
              V v_t_24251 = ({ V rv_1 = heff_get_n(v_t_24250, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24252 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24247, v_t_24251}), NTAG(TAG_Nil)});
              V v_t_24253 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24246, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24243, v_t_24252})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24242; V a_2 = v_t_24253; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24242); r_; });
            }
          }
        }
        case TAG_EPi: {
          V v_ru_24x3131_2410_24EPi = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24256 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24256) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EPi, 2);
            heff_drop(v_t_24256);
            V v_t_24257 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str36), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str37)));
            V v_t_24258 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str38), heff_strAppend(v_x_247, v_t_24257));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24258}), v_xsp_248});
          } else {
            heff_drop(v_t_24256);
            V v_t_24259 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24260 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24259}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24261 = v_t_24260.f[0];
              V v_field_24262 = v_t_24260.f[1];
              V v_x_24263 = v_field_24261;
              V v_y_24264 = v_field_24262;
              V v_rest_24265 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24266 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24267 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24266}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24268 = heff_tag_at_n(v_ru_24x3131_2410_24EPi, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24265)});
              V v_t_24271;
              switch (heff_tag_of(v_rest_24265)) {
              case TAG_At: {
                V v_s_24270 = heff_field(v_rest_24265, 1);
                heff_take_n(v_rest_24265, 2ULL, 2);
                v_t_24271 = v_s_24270;
                break;
              }
              default: heff_nomatch(v_rest_24265);
              }
              V v_t_24272 = ({ V rv_1 = heff_get_n(v_t_24271, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24273 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24268, v_t_24272}), NTAG(TAG_Nil)});
              V v_t_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24267, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24264, v_t_24273})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24263; V a_2 = v_t_24274; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24263); r_; });
            }
          }
        }
        case TAG_ELam: {
          V v_ru_24x3131_2410_24ELam = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24277 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24277) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELam, 2);
            heff_drop(v_t_24277);
            V v_t_24278 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str39), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str40)));
            V v_t_24279 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str41), heff_strAppend(v_x_247, v_t_24278));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24279}), v_xsp_248});
          } else {
            heff_drop(v_t_24277);
            V v_t_24280 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24281 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24280}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24282 = v_t_24281.f[0];
              V v_field_24283 = v_t_24281.f[1];
              V v_x_24284 = v_field_24282;
              V v_y_24285 = v_field_24283;
              V v_rest_24286 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24287 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24288 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24287}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24289 = heff_tag_at_n(v_ru_24x3131_2410_24ELam, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24286)});
              V v_t_24292;
              switch (heff_tag_of(v_rest_24286)) {
              case TAG_At: {
                V v_s_24291 = heff_field(v_rest_24286, 1);
                heff_take_n(v_rest_24286, 2ULL, 2);
                v_t_24292 = v_s_24291;
                break;
              }
              default: heff_nomatch(v_rest_24286);
              }
              V v_t_24293 = ({ V rv_1 = heff_get_n(v_t_24292, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24294 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24289, v_t_24293}), NTAG(TAG_Nil)});
              V v_t_24295 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24288, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24285, v_t_24294})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24284; V a_2 = v_t_24295; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24284); r_; });
            }
          }
        }
        case TAG_EAnn: {
          V v_ru_24x3131_2410_24EAnn = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24298 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24298) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EAnn, 2);
            heff_drop(v_t_24298);
            V v_t_24299 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str42), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str43)));
            V v_t_24300 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str44), heff_strAppend(v_x_247, v_t_24299));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24300}), v_xsp_248});
          } else {
            heff_drop(v_t_24298);
            V v_t_24301 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24302 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24301}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24303 = v_t_24302.f[0];
              V v_field_24304 = v_t_24302.f[1];
              V v_x_24305 = v_field_24303;
              V v_y_24306 = v_field_24304;
              V v_rest_24307 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24308 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24309 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24308}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24310 = heff_tag_at_n(v_ru_24x3131_2410_24EAnn, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24307)});
              V v_t_24313;
              switch (heff_tag_of(v_rest_24307)) {
              case TAG_At: {
                V v_s_24312 = heff_field(v_rest_24307, 1);
                heff_take_n(v_rest_24307, 2ULL, 2);
                v_t_24313 = v_s_24312;
                break;
              }
              default: heff_nomatch(v_rest_24307);
              }
              V v_t_24314 = ({ V rv_1 = heff_get_n(v_t_24313, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24315 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24310, v_t_24314}), NTAG(TAG_Nil)});
              V v_t_24316 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24309, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24306, v_t_24315})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24305; V a_2 = v_t_24316; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24305); r_; });
            }
          }
        }
        case TAG_ESpec: {
          heff_take_n(v_x3131_2410, 0ULL, 4);
          V v_t_24321 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24321) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24321);
            V v_t_24322 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str45), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str46)));
            V v_t_24323 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str47), heff_strAppend(v_x_247, v_t_24322));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24323}), v_xsp_248});
          } else {
            heff_drop(v_t_24321);
            V v_t_24324 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24325 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24324}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24326 = v_t_24325.f[0];
              V v_field_24327 = v_t_24325.f[1];
              V v_x_24328 = v_field_24326;
              V v_y_24329 = v_field_24327;
              V v_rest_24330 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24331 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24332 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24331}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24333 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24330)});
              V v_t_24336;
              switch (heff_tag_of(v_rest_24330)) {
              case TAG_At: {
                V v_s_24335 = heff_field(v_rest_24330, 1);
                heff_take_n(v_rest_24330, 2ULL, 2);
                v_t_24336 = v_s_24335;
                break;
              }
              default: heff_nomatch(v_rest_24330);
              }
              V v_t_24337 = ({ V rv_1 = heff_get_n(v_t_24336, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24338 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24333, v_t_24337}), NTAG(TAG_Nil)});
              V v_t_24339 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24332, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24329, v_t_24338})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24328; V a_2 = v_t_24339; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24328); r_; });
            }
          }
        }
        case TAG_ESig: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24341 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24341) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24341);
            V v_t_24342 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str48), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str49)));
            V v_t_24343 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str50), heff_strAppend(v_x_247, v_t_24342));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24343}), v_xsp_248});
          } else {
            heff_drop(v_t_24341);
            V v_t_24344 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24345 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24344}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24346 = v_t_24345.f[0];
              V v_field_24347 = v_t_24345.f[1];
              V v_x_24348 = v_field_24346;
              V v_y_24349 = v_field_24347;
              V v_rest_24350 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24351 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24352 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24351}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24353 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24350)});
              V v_t_24356;
              switch (heff_tag_of(v_rest_24350)) {
              case TAG_At: {
                V v_s_24355 = heff_field(v_rest_24350, 1);
                heff_take_n(v_rest_24350, 2ULL, 2);
                v_t_24356 = v_s_24355;
                break;
              }
              default: heff_nomatch(v_rest_24350);
              }
              V v_t_24357 = ({ V rv_1 = heff_get_n(v_t_24356, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24358 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24353, v_t_24357}), NTAG(TAG_Nil)});
              V v_t_24359 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24352, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24349, v_t_24358})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24348; V a_2 = v_t_24359; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24348); r_; });
            }
          }
        }
        case TAG_ESum: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24361 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24361) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24361);
            V v_t_24362 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str51), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str52)));
            V v_t_24363 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str53), heff_strAppend(v_x_247, v_t_24362));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24363}), v_xsp_248});
          } else {
            heff_drop(v_t_24361);
            V v_t_24364 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24365 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24364}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24366 = v_t_24365.f[0];
              V v_field_24367 = v_t_24365.f[1];
              V v_x_24368 = v_field_24366;
              V v_y_24369 = v_field_24367;
              V v_rest_24370 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24371 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24372 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24371}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24373 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24370)});
              V v_t_24376;
              switch (heff_tag_of(v_rest_24370)) {
              case TAG_At: {
                V v_s_24375 = heff_field(v_rest_24370, 1);
                heff_take_n(v_rest_24370, 2ULL, 2);
                v_t_24376 = v_s_24375;
                break;
              }
              default: heff_nomatch(v_rest_24370);
              }
              V v_t_24377 = ({ V rv_1 = heff_get_n(v_t_24376, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24378 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24373, v_t_24377}), NTAG(TAG_Nil)});
              V v_t_24379 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24372, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24369, v_t_24378})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24368; V a_2 = v_t_24379; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24368); r_; });
            }
          }
        }
        case TAG_EStruct: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24381 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24381) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24381);
            V v_t_24382 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str54), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str55)));
            V v_t_24383 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str56), heff_strAppend(v_x_247, v_t_24382));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24383}), v_xsp_248});
          } else {
            heff_drop(v_t_24381);
            V v_t_24384 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24385 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24384}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24386 = v_t_24385.f[0];
              V v_field_24387 = v_t_24385.f[1];
              V v_x_24388 = v_field_24386;
              V v_y_24389 = v_field_24387;
              V v_rest_24390 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24391 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24392 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24391}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24393 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24390)});
              V v_t_24396;
              switch (heff_tag_of(v_rest_24390)) {
              case TAG_At: {
                V v_s_24395 = heff_field(v_rest_24390, 1);
                heff_take_n(v_rest_24390, 2ULL, 2);
                v_t_24396 = v_s_24395;
                break;
              }
              default: heff_nomatch(v_rest_24390);
              }
              V v_t_24397 = ({ V rv_1 = heff_get_n(v_t_24396, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24398 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24393, v_t_24397}), NTAG(TAG_Nil)});
              V v_t_24399 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24392, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24389, v_t_24398})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24388; V a_2 = v_t_24399; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24388); r_; });
            }
          }
        }
        case TAG_EUpdate: {
          V v_ru_24x3131_2410_24EUpdate = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24402 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24402) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EUpdate, 2);
            heff_drop(v_t_24402);
            V v_t_24403 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str57), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str58)));
            V v_t_24404 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str59), heff_strAppend(v_x_247, v_t_24403));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24404}), v_xsp_248});
          } else {
            heff_drop(v_t_24402);
            V v_t_24405 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24406 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24405}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24407 = v_t_24406.f[0];
              V v_field_24408 = v_t_24406.f[1];
              V v_x_24409 = v_field_24407;
              V v_y_24410 = v_field_24408;
              V v_rest_24411 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24412 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24413 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24412}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24414 = heff_tag_at_n(v_ru_24x3131_2410_24EUpdate, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24411)});
              V v_t_24417;
              switch (heff_tag_of(v_rest_24411)) {
              case TAG_At: {
                V v_s_24416 = heff_field(v_rest_24411, 1);
                heff_take_n(v_rest_24411, 2ULL, 2);
                v_t_24417 = v_s_24416;
                break;
              }
              default: heff_nomatch(v_rest_24411);
              }
              V v_t_24418 = ({ V rv_1 = heff_get_n(v_t_24417, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24414, v_t_24418}), NTAG(TAG_Nil)});
              V v_t_24420 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24413, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24410, v_t_24419})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24409; V a_2 = v_t_24420; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24409); r_; });
            }
          }
        }
        case TAG_EMatch: {
          V v_ru_24x3131_2410_24EMatch = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24423 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24423) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EMatch, 2);
            heff_drop(v_t_24423);
            V v_t_24424 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str60), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str61)));
            V v_t_24425 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str62), heff_strAppend(v_x_247, v_t_24424));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24425}), v_xsp_248});
          } else {
            heff_drop(v_t_24423);
            V v_t_24426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24426}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24428 = v_t_24427.f[0];
              V v_field_24429 = v_t_24427.f[1];
              V v_x_24430 = v_field_24428;
              V v_y_24431 = v_field_24429;
              V v_rest_24432 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24433 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24434 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24433}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24435 = heff_tag_at_n(v_ru_24x3131_2410_24EMatch, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24432)});
              V v_t_24438;
              switch (heff_tag_of(v_rest_24432)) {
              case TAG_At: {
                V v_s_24437 = heff_field(v_rest_24432, 1);
                heff_take_n(v_rest_24432, 2ULL, 2);
                v_t_24438 = v_s_24437;
                break;
              }
              default: heff_nomatch(v_rest_24432);
              }
              V v_t_24439 = ({ V rv_1 = heff_get_n(v_t_24438, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24435, v_t_24439}), NTAG(TAG_Nil)});
              V v_t_24441 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24434, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24431, v_t_24440})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24430; V a_2 = v_t_24441; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24430); r_; });
            }
          }
        }
        case TAG_ELetIn: {
          V v_ru_24x3131_2410_24ELetIn = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24444 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24444) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELetIn, 2);
            heff_drop(v_t_24444);
            V v_t_24445 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str63), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str64)));
            V v_t_24446 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str65), heff_strAppend(v_x_247, v_t_24445));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24446}), v_xsp_248});
          } else {
            heff_drop(v_t_24444);
            V v_t_24447 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24448 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24447}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24449 = v_t_24448.f[0];
              V v_field_24450 = v_t_24448.f[1];
              V v_x_24451 = v_field_24449;
              V v_y_24452 = v_field_24450;
              V v_rest_24453 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24454 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24455 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24454}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24456 = heff_tag_at_n(v_ru_24x3131_2410_24ELetIn, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24453)});
              V v_t_24459;
              switch (heff_tag_of(v_rest_24453)) {
              case TAG_At: {
                V v_s_24458 = heff_field(v_rest_24453, 1);
                heff_take_n(v_rest_24453, 2ULL, 2);
                v_t_24459 = v_s_24458;
                break;
              }
              default: heff_nomatch(v_rest_24453);
              }
              V v_t_24460 = ({ V rv_1 = heff_get_n(v_t_24459, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24456, v_t_24460}), NTAG(TAG_Nil)});
              V v_t_24462 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24455, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24452, v_t_24461})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24451; V a_2 = v_t_24462; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24451); r_; });
            }
          }
        }
        case TAG_EDo: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24464 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24464) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24464);
            V v_t_24465 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str66), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str67)));
            V v_t_24466 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str68), heff_strAppend(v_x_247, v_t_24465));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24466}), v_xsp_248});
          } else {
            heff_drop(v_t_24464);
            V v_t_24467 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24468 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24467}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24469 = v_t_24468.f[0];
              V v_field_24470 = v_t_24468.f[1];
              V v_x_24471 = v_field_24469;
              V v_y_24472 = v_field_24470;
              V v_rest_24473 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24474 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24475 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24474}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24476 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24473)});
              V v_t_24479;
              switch (heff_tag_of(v_rest_24473)) {
              case TAG_At: {
                V v_s_24478 = heff_field(v_rest_24473, 1);
                heff_take_n(v_rest_24473, 2ULL, 2);
                v_t_24479 = v_s_24478;
                break;
              }
              default: heff_nomatch(v_rest_24473);
              }
              V v_t_24480 = ({ V rv_1 = heff_get_n(v_t_24479, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24476, v_t_24480}), NTAG(TAG_Nil)});
              V v_t_24482 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24475, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24472, v_t_24481})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24471; V a_2 = v_t_24482; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24471); r_; });
            }
          }
        }
        case TAG_ELocal: {
          V v_ru_24x3131_2410_24ELocal = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24485 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24485) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELocal, 2);
            heff_drop(v_t_24485);
            V v_t_24486 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str69), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str70)));
            V v_t_24487 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str71), heff_strAppend(v_x_247, v_t_24486));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24487}), v_xsp_248});
          } else {
            heff_drop(v_t_24485);
            V v_t_24488 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24489 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24488}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24490 = v_t_24489.f[0];
              V v_field_24491 = v_t_24489.f[1];
              V v_x_24492 = v_field_24490;
              V v_y_24493 = v_field_24491;
              V v_rest_24494 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24495 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24496 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24495}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24497 = heff_tag_at_n(v_ru_24x3131_2410_24ELocal, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24494)});
              V v_t_24500;
              switch (heff_tag_of(v_rest_24494)) {
              case TAG_At: {
                V v_s_24499 = heff_field(v_rest_24494, 1);
                heff_take_n(v_rest_24494, 2ULL, 2);
                v_t_24500 = v_s_24499;
                break;
              }
              default: heff_nomatch(v_rest_24494);
              }
              V v_t_24501 = ({ V rv_1 = heff_get_n(v_t_24500, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24502 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24497, v_t_24501}), NTAG(TAG_Nil)});
              V v_t_24503 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24496, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24493, v_t_24502})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24492; V a_2 = v_t_24503; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24492); r_; });
            }
          }
        }
        case TAG_EInvalid: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24505 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24505) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24505);
            V v_t_24506 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str72), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str73)));
            V v_t_24507 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str74), heff_strAppend(v_x_247, v_t_24506));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24507}), v_xsp_248});
          } else {
            heff_drop(v_t_24505);
            V v_t_24508 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24509 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24508}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24510 = v_t_24509.f[0];
              V v_field_24511 = v_t_24509.f[1];
              V v_x_24512 = v_field_24510;
              V v_y_24513 = v_field_24511;
              V v_rest_24514 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24515 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24516 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24515}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24517 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24514)});
              V v_t_24520;
              switch (heff_tag_of(v_rest_24514)) {
              case TAG_At: {
                V v_s_24519 = heff_field(v_rest_24514, 1);
                heff_take_n(v_rest_24514, 2ULL, 2);
                v_t_24520 = v_s_24519;
                break;
              }
              default: heff_nomatch(v_rest_24514);
              }
              V v_t_24521 = ({ V rv_1 = heff_get_n(v_t_24520, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24522 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24517, v_t_24521}), NTAG(TAG_Nil)});
              V v_t_24523 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24516, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24513, v_t_24522})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24512; V a_2 = v_t_24523; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24512); r_; });
            }
          }
        }
        case TAG_EAssign: {
          heff_take_n(v_x3131_2410, 0ULL, 3);
          V v_t_24527 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24527) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24527);
            V v_t_24528 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str75), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str76)));
            V v_t_24529 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str77), heff_strAppend(v_x_247, v_t_24528));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24529}), v_xsp_248});
          } else {
            heff_drop(v_t_24527);
            V v_t_24530 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24531 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24530}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24532 = v_t_24531.f[0];
              V v_field_24533 = v_t_24531.f[1];
              V v_x_24534 = v_field_24532;
              V v_y_24535 = v_field_24533;
              V v_rest_24536 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24537 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24538 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24537}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24539 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24536)});
              V v_t_24542;
              switch (heff_tag_of(v_rest_24536)) {
              case TAG_At: {
                V v_s_24541 = heff_field(v_rest_24536, 1);
                heff_take_n(v_rest_24536, 2ULL, 2);
                v_t_24542 = v_s_24541;
                break;
              }
              default: heff_nomatch(v_rest_24536);
              }
              V v_t_24543 = ({ V rv_1 = heff_get_n(v_t_24542, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24544 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24539, v_t_24543}), NTAG(TAG_Nil)});
              V v_t_24545 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24538, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24535, v_t_24544})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24534; V a_2 = v_t_24545; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24534); r_; });
            }
          }
        }
        case TAG_EWhile: {
          V v_ru_24x3131_2410_24EWhile = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24548 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24548) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EWhile, 2);
            heff_drop(v_t_24548);
            V v_t_24549 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str78), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str79)));
            V v_t_24550 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str80), heff_strAppend(v_x_247, v_t_24549));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24550}), v_xsp_248});
          } else {
            heff_drop(v_t_24548);
            V v_t_24551 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24552 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24551}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24553 = v_t_24552.f[0];
              V v_field_24554 = v_t_24552.f[1];
              V v_x_24555 = v_field_24553;
              V v_y_24556 = v_field_24554;
              V v_rest_24557 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24558 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24559 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24558}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24560 = heff_tag_at_n(v_ru_24x3131_2410_24EWhile, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24557)});
              V v_t_24563;
              switch (heff_tag_of(v_rest_24557)) {
              case TAG_At: {
                V v_s_24562 = heff_field(v_rest_24557, 1);
                heff_take_n(v_rest_24557, 2ULL, 2);
                v_t_24563 = v_s_24562;
                break;
              }
              default: heff_nomatch(v_rest_24557);
              }
              V v_t_24564 = ({ V rv_1 = heff_get_n(v_t_24563, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24565 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24560, v_t_24564}), NTAG(TAG_Nil)});
              V v_t_24566 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24559, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24556, v_t_24565})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24555; V a_2 = v_t_24566; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24555); r_; });
            }
          }
        }
        case TAG_EFor: {
          V v_q_24567 = heff_field(v_x3131_2410, 0);
          V v_c_24568 = heff_field(v_x3131_2410, 1);
          V v_body_24569 = heff_field(v_x3131_2410, 2);
          heff_take_n(v_x3131_2410, 7ULL, 3);
          switch (heff_tag_of(v_x313_249)) {
          case TAG_At: {
            V v_fsp_24571 = heff_field(v_x313_249, 1);
            V v_ru_24x313_249_24At = heff_take_reuse_n(v_x313_249, 2ULL, 2);
            V v_t_24572 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
            if ((heff_dup(v_t_24572) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop(v_q_24567);
              heff_drop(v_c_24568);
              heff_drop(v_body_24569);
              heff_drop(v_fsp_24571);
              heff_drop_cell(v_ru_24x313_249_24At, 2);
              heff_drop(v_t_24572);
              V v_t_24573 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str81), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str82)));
              V v_t_24574 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str83), heff_strAppend(v_x_247, v_t_24573));
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24574}), v_xsp_248});
            } else {
              heff_drop(v_t_24572);
              V v_t_24575 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_247}), v_xsp_248});
              V v_t_24576 = (g_heff_2esyntax_2epresyntax_2egathered(v_t_24575, v_fsp_24571, v_q_24567, v_c_24568, v_body_24569));
              V v_t_24577 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x313_249_24At, v_t_24576, v_rest_243));
              return heff_tail(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_t_24577, v_end_244});
            }
          }
          default: return heff_nomatch(v_x313_249);
          }
        }
        case TAG_EIfThen: {
          V v_ru_24x3131_2410_24EIfThen = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          V v_t_24580 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24580) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EIfThen, 2);
            heff_drop(v_t_24580);
            V v_t_24581 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str84), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str85)));
            V v_t_24582 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str86), heff_strAppend(v_x_247, v_t_24581));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24582}), v_xsp_248});
          } else {
            heff_drop(v_t_24580);
            V v_t_24583 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24584 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24583}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24585 = v_t_24584.f[0];
              V v_field_24586 = v_t_24584.f[1];
              V v_x_24587 = v_field_24585;
              V v_y_24588 = v_field_24586;
              V v_rest_24589 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24590 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24591 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24590}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24592 = heff_tag_at_n(v_ru_24x3131_2410_24EIfThen, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24589)});
              V v_t_24595;
              switch (heff_tag_of(v_rest_24589)) {
              case TAG_At: {
                V v_s_24594 = heff_field(v_rest_24589, 1);
                heff_take_n(v_rest_24589, 2ULL, 2);
                v_t_24595 = v_s_24594;
                break;
              }
              default: heff_nomatch(v_rest_24589);
              }
              V v_t_24596 = ({ V rv_1 = heff_get_n(v_t_24595, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24597 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24592, v_t_24596}), NTAG(TAG_Nil)});
              V v_t_24598 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24591, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24588, v_t_24597})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24587; V a_2 = v_t_24598; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24587); r_; });
            }
          }
        }
        case TAG_EBreak: {
          V v_t_24599 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24599) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24599);
            V v_t_24600 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str87), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str88)));
            V v_t_24601 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str89), heff_strAppend(v_x_247, v_t_24600));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24601}), v_xsp_248});
          } else {
            heff_drop(v_t_24599);
            V v_t_24602 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24603 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24602}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24604 = v_t_24603.f[0];
              V v_field_24605 = v_t_24603.f[1];
              V v_x_24606 = v_field_24604;
              V v_y_24607 = v_field_24605;
              V v_rest_24608 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24609 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24610 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24609}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24611 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24608)});
              V v_t_24614;
              switch (heff_tag_of(v_rest_24608)) {
              case TAG_At: {
                V v_s_24613 = heff_field(v_rest_24608, 1);
                heff_take_n(v_rest_24608, 2ULL, 2);
                v_t_24614 = v_s_24613;
                break;
              }
              default: heff_nomatch(v_rest_24608);
              }
              V v_t_24615 = ({ V rv_1 = heff_get_n(v_t_24614, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24616 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24611, v_t_24615}), NTAG(TAG_Nil)});
              V v_t_24617 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24610, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24607, v_t_24616})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24606; V a_2 = v_t_24617; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24606); r_; });
            }
          }
        }
        case TAG_EContinue: {
          V v_t_24618 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24618) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24618);
            V v_t_24619 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str90), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str91)));
            V v_t_24620 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str92), heff_strAppend(v_x_247, v_t_24619));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24620}), v_xsp_248});
          } else {
            heff_drop(v_t_24618);
            V v_t_24621 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24622 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24621}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24623 = v_t_24622.f[0];
              V v_field_24624 = v_t_24622.f[1];
              V v_x_24625 = v_field_24623;
              V v_y_24626 = v_field_24624;
              V v_rest_24627 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24628 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24629 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24628}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24630 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24627)});
              V v_t_24633;
              switch (heff_tag_of(v_rest_24627)) {
              case TAG_At: {
                V v_s_24632 = heff_field(v_rest_24627, 1);
                heff_take_n(v_rest_24627, 2ULL, 2);
                v_t_24633 = v_s_24632;
                break;
              }
              default: heff_nomatch(v_rest_24627);
              }
              V v_t_24634 = ({ V rv_1 = heff_get_n(v_t_24633, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24635 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24630, v_t_24634}), NTAG(TAG_Nil)});
              V v_t_24636 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24629, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24626, v_t_24635})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24625; V a_2 = v_t_24636; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24625); r_; });
            }
          }
        }
        case TAG_EReturn: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24638 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24638) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24638);
            V v_t_24639 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str93), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str94)));
            V v_t_24640 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str95), heff_strAppend(v_x_247, v_t_24639));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24640}), v_xsp_248});
          } else {
            heff_drop(v_t_24638);
            V v_t_24641 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24642 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24641}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24643 = v_t_24642.f[0];
              V v_field_24644 = v_t_24642.f[1];
              V v_x_24645 = v_field_24643;
              V v_y_24646 = v_field_24644;
              V v_rest_24647 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24648 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24649 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24648}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24650 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24647)});
              V v_t_24653;
              switch (heff_tag_of(v_rest_24647)) {
              case TAG_At: {
                V v_s_24652 = heff_field(v_rest_24647, 1);
                heff_take_n(v_rest_24647, 2ULL, 2);
                v_t_24653 = v_s_24652;
                break;
              }
              default: heff_nomatch(v_rest_24647);
              }
              V v_t_24654 = ({ V rv_1 = heff_get_n(v_t_24653, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24655 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24650, v_t_24654}), NTAG(TAG_Nil)});
              V v_t_24656 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24649, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24646, v_t_24655})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24645; V a_2 = v_t_24656; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24645); r_; });
            }
          }
        }
        case TAG_ENest: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24658 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24658) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24658);
            V v_t_24659 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str96), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str97)));
            V v_t_24660 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str98), heff_strAppend(v_x_247, v_t_24659));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24660}), v_xsp_248});
          } else {
            heff_drop(v_t_24658);
            V v_t_24661 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24662 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24661}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24663 = v_t_24662.f[0];
              V v_field_24664 = v_t_24662.f[1];
              V v_x_24665 = v_field_24663;
              V v_y_24666 = v_field_24664;
              V v_rest_24667 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24668 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24669 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24668}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24670 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24667)});
              V v_t_24673;
              switch (heff_tag_of(v_rest_24667)) {
              case TAG_At: {
                V v_s_24672 = heff_field(v_rest_24667, 1);
                heff_take_n(v_rest_24667, 2ULL, 2);
                v_t_24673 = v_s_24672;
                break;
              }
              default: heff_nomatch(v_rest_24667);
              }
              V v_t_24674 = ({ V rv_1 = heff_get_n(v_t_24673, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24675 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24670, v_t_24674}), NTAG(TAG_Nil)});
              V v_t_24676 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24669, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24666, v_t_24675})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24665; V a_2 = v_t_24676; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24665); r_; });
            }
          }
        }
        case TAG_ELazy: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24678 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24678) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24678);
            V v_t_24679 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str99), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str100)));
            V v_t_24680 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str101), heff_strAppend(v_x_247, v_t_24679));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24680}), v_xsp_248});
          } else {
            heff_drop(v_t_24678);
            V v_t_24681 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24682 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24681}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24683 = v_t_24682.f[0];
              V v_field_24684 = v_t_24682.f[1];
              V v_x_24685 = v_field_24683;
              V v_y_24686 = v_field_24684;
              V v_rest_24687 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24688 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24689 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24688}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24690 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24687)});
              V v_t_24693;
              switch (heff_tag_of(v_rest_24687)) {
              case TAG_At: {
                V v_s_24692 = heff_field(v_rest_24687, 1);
                heff_take_n(v_rest_24687, 2ULL, 2);
                v_t_24693 = v_s_24692;
                break;
              }
              default: heff_nomatch(v_rest_24687);
              }
              V v_t_24694 = ({ V rv_1 = heff_get_n(v_t_24693, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24695 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24690, v_t_24694}), NTAG(TAG_Nil)});
              V v_t_24696 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24689, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24686, v_t_24695})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24685; V a_2 = v_t_24696; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24685); r_; });
            }
          }
        }
        case TAG_ETuple: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24698 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24698) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24698);
            V v_t_24699 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str102), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str103)));
            V v_t_24700 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str104), heff_strAppend(v_x_247, v_t_24699));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24700}), v_xsp_248});
          } else {
            heff_drop(v_t_24698);
            V v_t_24701 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24702 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24701}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24703 = v_t_24702.f[0];
              V v_field_24704 = v_t_24702.f[1];
              V v_x_24705 = v_field_24703;
              V v_y_24706 = v_field_24704;
              V v_rest_24707 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24708 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24709 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24708}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24710 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24707)});
              V v_t_24713;
              switch (heff_tag_of(v_rest_24707)) {
              case TAG_At: {
                V v_s_24712 = heff_field(v_rest_24707, 1);
                heff_take_n(v_rest_24707, 2ULL, 2);
                v_t_24713 = v_s_24712;
                break;
              }
              default: heff_nomatch(v_rest_24707);
              }
              V v_t_24714 = ({ V rv_1 = heff_get_n(v_t_24713, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24715 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24710, v_t_24714}), NTAG(TAG_Nil)});
              V v_t_24716 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24709, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24706, v_t_24715})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24705; V a_2 = v_t_24716; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24705); r_; });
            }
          }
        }
        case TAG_ETry: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          V v_t_24718 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24718) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24718);
            V v_t_24719 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str105), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str106)));
            V v_t_24720 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str107), heff_strAppend(v_x_247, v_t_24719));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24720}), v_xsp_248});
          } else {
            heff_drop(v_t_24718);
            V v_t_24721 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24722 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24721}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24723 = v_t_24722.f[0];
              V v_field_24724 = v_t_24722.f[1];
              V v_x_24725 = v_field_24723;
              V v_y_24726 = v_field_24724;
              V v_rest_24727 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24728 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24729 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24728}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24730 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24727)});
              V v_t_24733;
              switch (heff_tag_of(v_rest_24727)) {
              case TAG_At: {
                V v_s_24732 = heff_field(v_rest_24727, 1);
                heff_take_n(v_rest_24727, 2ULL, 2);
                v_t_24733 = v_s_24732;
                break;
              }
              default: heff_nomatch(v_rest_24727);
              }
              V v_t_24734 = ({ V rv_1 = heff_get_n(v_t_24733, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24735 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24730, v_t_24734}), NTAG(TAG_Nil)});
              V v_t_24736 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24729, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24726, v_t_24735})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24725; V a_2 = v_t_24736; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24725); r_; });
            }
          }
        }
        case TAG_EWith: {
          heff_take_n(v_x3131_2410, 0ULL, 4);
          V v_t_24741 = (g_list_2eany_24s2077819594x1842428557(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24741) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 6);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24741);
            V v_t_24742 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str108), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str109)));
            V v_t_24743 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str110), heff_strAppend(v_x_247, v_t_24742));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24743}), v_xsp_248});
          } else {
            heff_drop(v_t_24741);
            V v_t_24744 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24745 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24744}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24746 = v_t_24745.f[0];
              V v_field_24747 = v_t_24745.f[1];
              V v_x_24748 = v_field_24746;
              V v_y_24749 = v_field_24747;
              V v_rest_24750 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24751 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
              V v_t_24752 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24751}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24753 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24750)});
              V v_t_24756;
              switch (heff_tag_of(v_rest_24750)) {
              case TAG_At: {
                V v_s_24755 = heff_field(v_rest_24750, 1);
                heff_take_n(v_rest_24750, 2ULL, 2);
                v_t_24756 = v_s_24755;
                break;
              }
              default: heff_nomatch(v_rest_24750);
              }
              V v_t_24757 = ({ V rv_1 = heff_get_n(v_t_24756, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24758 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24753, v_t_24757}), NTAG(TAG_Nil)});
              V v_t_24759 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24752, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24749, v_t_24758})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24748; V a_2 = v_t_24759; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24748); r_; });
            }
          }
        }
        default: return heff_nomatch(v_x3131_2410);
        }
      }
      default: return heff_nomatch(v_x313_249);
      }
    }
    case TAG_StmtLet: {
      V v_p_24760 = heff_field(v_x31_245, 0);
      V v_x312_24761 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24StmtLet = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      switch (heff_tag_of(v_x312_24761)) {
      case TAG_At: {
        V v_x3121_24762 = heff_dup(heff_field(v_x312_24761, 0));
        switch (heff_tag_of(v_x3121_24762)) {
        case TAG_EVar: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24765 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24767 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam0, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24765));
          {
            V v_field_24769 = v_t_24767.f[1];
            int64_t v_tag_24768 = ((int64_t)v_t_24767.f[0]);
            if ((v_tag_24768 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24770 = v_field_24769;
              V v_t_24771 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str111), heff_strAppend(heff_dup(v_x_24770), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str112)));
              V v_t_24772 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str113), heff_strAppend(v_x_24770, v_t_24771));
              V v_t_24775;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24774 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24775 = v_s_24774;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24772}), v_t_24775});
            } else {
              heff_drop(v_field_24769);
              V v_t_24776 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24777 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24776}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24778 = v_t_24777.f[0];
                V v_field_24779 = v_t_24777.f[1];
                V v_x_24780 = v_field_24778;
                V v_y_24781 = v_field_24779;
                V v_body_24782 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24785;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24784 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24785 = v_s_24784;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24788;
                switch (heff_tag_of(v_body_24782)) {
                case TAG_At: {
                  V v_s_24787 = heff_dup(heff_field(v_body_24782, 1));
                  v_t_24788 = v_s_24787;
                  break;
                }
                default: heff_nomatch(v_body_24782);
                }
                V v_t_24789 = ({ V rv_1 = heff_get_n(v_t_24788, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24785, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24790 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24782)}), v_t_24789});
                V v_t_24793;
                switch (heff_tag_of(v_body_24782)) {
                case TAG_At: {
                  V v_s_24792 = heff_field(v_body_24782, 1);
                  heff_take_n(v_body_24782, 2ULL, 2);
                  v_t_24793 = v_s_24792;
                  break;
                }
                default: heff_nomatch(v_body_24782);
                }
                V v_t_24794 = ({ V rv_1 = heff_get_n(v_t_24793, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24795 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24781, v_t_24790}), v_t_24794});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24780; V a_2 = v_t_24795; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24780); r_; });
              }
            }
          }
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24797 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24799 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam1, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24797));
          {
            V v_field_24801 = v_t_24799.f[1];
            int64_t v_tag_24800 = ((int64_t)v_t_24799.f[0]);
            if ((v_tag_24800 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24802 = v_field_24801;
              V v_t_24803 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str114), heff_strAppend(heff_dup(v_x_24802), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str115)));
              V v_t_24804 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str116), heff_strAppend(v_x_24802, v_t_24803));
              V v_t_24807;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24806 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24807 = v_s_24806;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24804}), v_t_24807});
            } else {
              heff_drop(v_field_24801);
              V v_t_24808 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24809 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24808}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24810 = v_t_24809.f[0];
                V v_field_24811 = v_t_24809.f[1];
                V v_x_24812 = v_field_24810;
                V v_y_24813 = v_field_24811;
                V v_body_24814 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24817;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24816 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24817 = v_s_24816;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24820;
                switch (heff_tag_of(v_body_24814)) {
                case TAG_At: {
                  V v_s_24819 = heff_dup(heff_field(v_body_24814, 1));
                  v_t_24820 = v_s_24819;
                  break;
                }
                default: heff_nomatch(v_body_24814);
                }
                V v_t_24821 = ({ V rv_1 = heff_get_n(v_t_24820, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24817, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24822 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24814)}), v_t_24821});
                V v_t_24825;
                switch (heff_tag_of(v_body_24814)) {
                case TAG_At: {
                  V v_s_24824 = heff_field(v_body_24814, 1);
                  heff_take_n(v_body_24814, 2ULL, 2);
                  v_t_24825 = v_s_24824;
                  break;
                }
                default: heff_nomatch(v_body_24814);
                }
                V v_t_24826 = ({ V rv_1 = heff_get_n(v_t_24825, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24827 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24813, v_t_24822}), v_t_24826});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24812; V a_2 = v_t_24827; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24812); r_; });
              }
            }
          }
        }
        case TAG_ETag: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24829 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24831 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam2, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24829));
          {
            V v_field_24833 = v_t_24831.f[1];
            int64_t v_tag_24832 = ((int64_t)v_t_24831.f[0]);
            if ((v_tag_24832 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24834 = v_field_24833;
              V v_t_24835 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str117), heff_strAppend(heff_dup(v_x_24834), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str118)));
              V v_t_24836 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str119), heff_strAppend(v_x_24834, v_t_24835));
              V v_t_24839;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24838 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24839 = v_s_24838;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24836}), v_t_24839});
            } else {
              heff_drop(v_field_24833);
              V v_t_24840 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24841 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24840}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24842 = v_t_24841.f[0];
                V v_field_24843 = v_t_24841.f[1];
                V v_x_24844 = v_field_24842;
                V v_y_24845 = v_field_24843;
                V v_body_24846 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24849;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24848 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24849 = v_s_24848;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24852;
                switch (heff_tag_of(v_body_24846)) {
                case TAG_At: {
                  V v_s_24851 = heff_dup(heff_field(v_body_24846, 1));
                  v_t_24852 = v_s_24851;
                  break;
                }
                default: heff_nomatch(v_body_24846);
                }
                V v_t_24853 = ({ V rv_1 = heff_get_n(v_t_24852, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24849, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24854 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24846)}), v_t_24853});
                V v_t_24857;
                switch (heff_tag_of(v_body_24846)) {
                case TAG_At: {
                  V v_s_24856 = heff_field(v_body_24846, 1);
                  heff_take_n(v_body_24846, 2ULL, 2);
                  v_t_24857 = v_s_24856;
                  break;
                }
                default: heff_nomatch(v_body_24846);
                }
                V v_t_24858 = ({ V rv_1 = heff_get_n(v_t_24857, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24859 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24845, v_t_24854}), v_t_24858});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24844; V a_2 = v_t_24859; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24844); r_; });
              }
            }
          }
        }
        case TAG_EInt: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24861 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24863 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam3, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24861));
          {
            V v_field_24865 = v_t_24863.f[1];
            int64_t v_tag_24864 = ((int64_t)v_t_24863.f[0]);
            if ((v_tag_24864 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24866 = v_field_24865;
              V v_t_24867 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str120), heff_strAppend(heff_dup(v_x_24866), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str121)));
              V v_t_24868 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str122), heff_strAppend(v_x_24866, v_t_24867));
              V v_t_24871;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24870 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24871 = v_s_24870;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24868}), v_t_24871});
            } else {
              heff_drop(v_field_24865);
              V v_t_24872 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24873 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24872}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24874 = v_t_24873.f[0];
                V v_field_24875 = v_t_24873.f[1];
                V v_x_24876 = v_field_24874;
                V v_y_24877 = v_field_24875;
                V v_body_24878 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24881;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24880 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24881 = v_s_24880;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24884;
                switch (heff_tag_of(v_body_24878)) {
                case TAG_At: {
                  V v_s_24883 = heff_dup(heff_field(v_body_24878, 1));
                  v_t_24884 = v_s_24883;
                  break;
                }
                default: heff_nomatch(v_body_24878);
                }
                V v_t_24885 = ({ V rv_1 = heff_get_n(v_t_24884, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24881, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24886 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24878)}), v_t_24885});
                V v_t_24889;
                switch (heff_tag_of(v_body_24878)) {
                case TAG_At: {
                  V v_s_24888 = heff_field(v_body_24878, 1);
                  heff_take_n(v_body_24878, 2ULL, 2);
                  v_t_24889 = v_s_24888;
                  break;
                }
                default: heff_nomatch(v_body_24878);
                }
                V v_t_24890 = ({ V rv_1 = heff_get_n(v_t_24889, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24891 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24877, v_t_24886}), v_t_24890});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24876; V a_2 = v_t_24891; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24876); r_; });
              }
            }
          }
        }
        case TAG_EFloat: {
          heff_take_na(v_x3121_24762, 0ULL, 1);
          V v_xs_24893 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24895 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam4, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24893));
          {
            V v_field_24897 = v_t_24895.f[1];
            int64_t v_tag_24896 = ((int64_t)v_t_24895.f[0]);
            if ((v_tag_24896 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24898 = v_field_24897;
              V v_t_24899 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str123), heff_strAppend(heff_dup(v_x_24898), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str124)));
              V v_t_24900 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str125), heff_strAppend(v_x_24898, v_t_24899));
              V v_t_24903;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24902 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24903 = v_s_24902;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24900}), v_t_24903});
            } else {
              heff_drop(v_field_24897);
              V v_t_24904 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24905 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24904}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24906 = v_t_24905.f[0];
                V v_field_24907 = v_t_24905.f[1];
                V v_x_24908 = v_field_24906;
                V v_y_24909 = v_field_24907;
                V v_body_24910 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24913;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24912 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24913 = v_s_24912;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24916;
                switch (heff_tag_of(v_body_24910)) {
                case TAG_At: {
                  V v_s_24915 = heff_dup(heff_field(v_body_24910, 1));
                  v_t_24916 = v_s_24915;
                  break;
                }
                default: heff_nomatch(v_body_24910);
                }
                V v_t_24917 = ({ V rv_1 = heff_get_n(v_t_24916, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24913, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24918 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24910)}), v_t_24917});
                V v_t_24921;
                switch (heff_tag_of(v_body_24910)) {
                case TAG_At: {
                  V v_s_24920 = heff_field(v_body_24910, 1);
                  heff_take_n(v_body_24910, 2ULL, 2);
                  v_t_24921 = v_s_24920;
                  break;
                }
                default: heff_nomatch(v_body_24910);
                }
                V v_t_24922 = ({ V rv_1 = heff_get_n(v_t_24921, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24923 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24909, v_t_24918}), v_t_24922});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24908; V a_2 = v_t_24923; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24908); r_; });
              }
            }
          }
        }
        case TAG_EString: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24925 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24927 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam5, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24925));
          {
            V v_field_24929 = v_t_24927.f[1];
            int64_t v_tag_24928 = ((int64_t)v_t_24927.f[0]);
            if ((v_tag_24928 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24930 = v_field_24929;
              V v_t_24931 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str126), heff_strAppend(heff_dup(v_x_24930), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str127)));
              V v_t_24932 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str128), heff_strAppend(v_x_24930, v_t_24931));
              V v_t_24935;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24934 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24935 = v_s_24934;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24932}), v_t_24935});
            } else {
              heff_drop(v_field_24929);
              V v_t_24936 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24937 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24936}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24938 = v_t_24937.f[0];
                V v_field_24939 = v_t_24937.f[1];
                V v_x_24940 = v_field_24938;
                V v_y_24941 = v_field_24939;
                V v_body_24942 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24945;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24944 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24945 = v_s_24944;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24948;
                switch (heff_tag_of(v_body_24942)) {
                case TAG_At: {
                  V v_s_24947 = heff_dup(heff_field(v_body_24942, 1));
                  v_t_24948 = v_s_24947;
                  break;
                }
                default: heff_nomatch(v_body_24942);
                }
                V v_t_24949 = ({ V rv_1 = heff_get_n(v_t_24948, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24945, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24950 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24942)}), v_t_24949});
                V v_t_24953;
                switch (heff_tag_of(v_body_24942)) {
                case TAG_At: {
                  V v_s_24952 = heff_field(v_body_24942, 1);
                  heff_take_n(v_body_24942, 2ULL, 2);
                  v_t_24953 = v_s_24952;
                  break;
                }
                default: heff_nomatch(v_body_24942);
                }
                V v_t_24954 = ({ V rv_1 = heff_get_n(v_t_24953, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24955 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24941, v_t_24950}), v_t_24954});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24940; V a_2 = v_t_24955; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24940); r_; });
              }
            }
          }
        }
        case TAG_EBinary: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24957 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24959 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam6, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24957));
          {
            V v_field_24961 = v_t_24959.f[1];
            int64_t v_tag_24960 = ((int64_t)v_t_24959.f[0]);
            if ((v_tag_24960 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24962 = v_field_24961;
              V v_t_24963 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str129), heff_strAppend(heff_dup(v_x_24962), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str130)));
              V v_t_24964 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str131), heff_strAppend(v_x_24962, v_t_24963));
              V v_t_24967;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24966 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24967 = v_s_24966;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24964}), v_t_24967});
            } else {
              heff_drop(v_field_24961);
              V v_t_24968 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24969 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24968}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_24970 = v_t_24969.f[0];
                V v_field_24971 = v_t_24969.f[1];
                V v_x_24972 = v_field_24970;
                V v_y_24973 = v_field_24971;
                V v_body_24974 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24977;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_24976 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_24977 = v_s_24976;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_24980;
                switch (heff_tag_of(v_body_24974)) {
                case TAG_At: {
                  V v_s_24979 = heff_dup(heff_field(v_body_24974, 1));
                  v_t_24980 = v_s_24979;
                  break;
                }
                default: heff_nomatch(v_body_24974);
                }
                V v_t_24981 = ({ V rv_1 = heff_get_n(v_t_24980, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24977, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24982 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_24974)}), v_t_24981});
                V v_t_24985;
                switch (heff_tag_of(v_body_24974)) {
                case TAG_At: {
                  V v_s_24984 = heff_field(v_body_24974, 1);
                  heff_take_n(v_body_24974, 2ULL, 2);
                  v_t_24985 = v_s_24984;
                  break;
                }
                default: heff_nomatch(v_body_24974);
                }
                V v_t_24986 = ({ V rv_1 = heff_get_n(v_t_24985, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24987 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24973, v_t_24982}), v_t_24986});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24972; V a_2 = v_t_24987; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24972); r_; });
              }
            }
          }
        }
        case TAG_ERune: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_24989 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_24991 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam7, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24989));
          {
            V v_field_24993 = v_t_24991.f[1];
            int64_t v_tag_24992 = ((int64_t)v_t_24991.f[0]);
            if ((v_tag_24992 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24994 = v_field_24993;
              V v_t_24995 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str132), heff_strAppend(heff_dup(v_x_24994), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str133)));
              V v_t_24996 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str134), heff_strAppend(v_x_24994, v_t_24995));
              V v_t_24999;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_24998 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_24999 = v_s_24998;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24996}), v_t_24999});
            } else {
              heff_drop(v_field_24993);
              V v_t_241000 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241001 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241000}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241002 = v_t_241001.f[0];
                V v_field_241003 = v_t_241001.f[1];
                V v_x_241004 = v_field_241002;
                V v_y_241005 = v_field_241003;
                V v_body_241006 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241009;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241008 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241009 = v_s_241008;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241012;
                switch (heff_tag_of(v_body_241006)) {
                case TAG_At: {
                  V v_s_241011 = heff_dup(heff_field(v_body_241006, 1));
                  v_t_241012 = v_s_241011;
                  break;
                }
                default: heff_nomatch(v_body_241006);
                }
                V v_t_241013 = ({ V rv_1 = heff_get_n(v_t_241012, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241009, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241014 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241006)}), v_t_241013});
                V v_t_241017;
                switch (heff_tag_of(v_body_241006)) {
                case TAG_At: {
                  V v_s_241016 = heff_field(v_body_241006, 1);
                  heff_take_n(v_body_241006, 2ULL, 2);
                  v_t_241017 = v_s_241016;
                  break;
                }
                default: heff_nomatch(v_body_241006);
                }
                V v_t_241018 = ({ V rv_1 = heff_get_n(v_t_241017, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241019 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241005, v_t_241014}), v_t_241018});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241004; V a_2 = v_t_241019; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241004); r_; });
              }
            }
          }
        }
        case TAG_EWord: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241021 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241023 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam8, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241021));
          {
            V v_field_241025 = v_t_241023.f[1];
            int64_t v_tag_241024 = ((int64_t)v_t_241023.f[0]);
            if ((v_tag_241024 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241026 = v_field_241025;
              V v_t_241027 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str135), heff_strAppend(heff_dup(v_x_241026), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str136)));
              V v_t_241028 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str137), heff_strAppend(v_x_241026, v_t_241027));
              V v_t_241031;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241030 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241031 = v_s_241030;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241028}), v_t_241031});
            } else {
              heff_drop(v_field_241025);
              V v_t_241032 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241033 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241032}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241034 = v_t_241033.f[0];
                V v_field_241035 = v_t_241033.f[1];
                V v_x_241036 = v_field_241034;
                V v_y_241037 = v_field_241035;
                V v_body_241038 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241041;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241040 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241041 = v_s_241040;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241044;
                switch (heff_tag_of(v_body_241038)) {
                case TAG_At: {
                  V v_s_241043 = heff_dup(heff_field(v_body_241038, 1));
                  v_t_241044 = v_s_241043;
                  break;
                }
                default: heff_nomatch(v_body_241038);
                }
                V v_t_241045 = ({ V rv_1 = heff_get_n(v_t_241044, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241041, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241046 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241038)}), v_t_241045});
                V v_t_241049;
                switch (heff_tag_of(v_body_241038)) {
                case TAG_At: {
                  V v_s_241048 = heff_field(v_body_241038, 1);
                  heff_take_n(v_body_241038, 2ULL, 2);
                  v_t_241049 = v_s_241048;
                  break;
                }
                default: heff_nomatch(v_body_241038);
                }
                V v_t_241050 = ({ V rv_1 = heff_get_n(v_t_241049, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241051 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241037, v_t_241046}), v_t_241050});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241036; V a_2 = v_t_241051; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241036); r_; });
              }
            }
          }
        }
        case TAG_EApp: {
          V v_ru_24x3121_24762_24EApp = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241054 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EApp, heff_dup(v_p_24760)));
          HeffT2 v_t_241056 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam9, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241054));
          {
            V v_field_241058 = v_t_241056.f[1];
            int64_t v_tag_241057 = ((int64_t)v_t_241056.f[0]);
            if ((v_tag_241057 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241059 = v_field_241058;
              V v_t_241060 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str138), heff_strAppend(heff_dup(v_x_241059), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str139)));
              V v_t_241061 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str140), heff_strAppend(v_x_241059, v_t_241060));
              V v_t_241064;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241063 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241064 = v_s_241063;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241061}), v_t_241064});
            } else {
              heff_drop(v_field_241058);
              V v_t_241065 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241066 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241065}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241067 = v_t_241066.f[0];
                V v_field_241068 = v_t_241066.f[1];
                V v_x_241069 = v_field_241067;
                V v_y_241070 = v_field_241068;
                V v_body_241071 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241074;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241073 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241074 = v_s_241073;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241077;
                switch (heff_tag_of(v_body_241071)) {
                case TAG_At: {
                  V v_s_241076 = heff_dup(heff_field(v_body_241071, 1));
                  v_t_241077 = v_s_241076;
                  break;
                }
                default: heff_nomatch(v_body_241071);
                }
                V v_t_241078 = ({ V rv_1 = heff_get_n(v_t_241077, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241074, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241079 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241071)}), v_t_241078});
                V v_t_241082;
                switch (heff_tag_of(v_body_241071)) {
                case TAG_At: {
                  V v_s_241081 = heff_field(v_body_241071, 1);
                  heff_take_n(v_body_241071, 2ULL, 2);
                  v_t_241082 = v_s_241081;
                  break;
                }
                default: heff_nomatch(v_body_241071);
                }
                V v_t_241083 = ({ V rv_1 = heff_get_n(v_t_241082, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241084 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241070, v_t_241079}), v_t_241083});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241069; V a_2 = v_t_241084; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241069); r_; });
              }
            }
          }
        }
        case TAG_EProject: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241086 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241088 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam10, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241086));
          {
            V v_field_241090 = v_t_241088.f[1];
            int64_t v_tag_241089 = ((int64_t)v_t_241088.f[0]);
            if ((v_tag_241089 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241091 = v_field_241090;
              V v_t_241092 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str141), heff_strAppend(heff_dup(v_x_241091), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str142)));
              V v_t_241093 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str143), heff_strAppend(v_x_241091, v_t_241092));
              V v_t_241096;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241095 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241096 = v_s_241095;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241093}), v_t_241096});
            } else {
              heff_drop(v_field_241090);
              V v_t_241097 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241098 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241097}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241099 = v_t_241098.f[0];
                V v_field_241100 = v_t_241098.f[1];
                V v_x_241101 = v_field_241099;
                V v_y_241102 = v_field_241100;
                V v_body_241103 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241106;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241105 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241106 = v_s_241105;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241109;
                switch (heff_tag_of(v_body_241103)) {
                case TAG_At: {
                  V v_s_241108 = heff_dup(heff_field(v_body_241103, 1));
                  v_t_241109 = v_s_241108;
                  break;
                }
                default: heff_nomatch(v_body_241103);
                }
                V v_t_241110 = ({ V rv_1 = heff_get_n(v_t_241109, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241106, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241111 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241103)}), v_t_241110});
                V v_t_241114;
                switch (heff_tag_of(v_body_241103)) {
                case TAG_At: {
                  V v_s_241113 = heff_field(v_body_241103, 1);
                  heff_take_n(v_body_241103, 2ULL, 2);
                  v_t_241114 = v_s_241113;
                  break;
                }
                default: heff_nomatch(v_body_241103);
                }
                V v_t_241115 = ({ V rv_1 = heff_get_n(v_t_241114, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241116 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241102, v_t_241111}), v_t_241115});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241101; V a_2 = v_t_241116; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241101); r_; });
              }
            }
          }
        }
        case TAG_ENamed: {
          V v_ru_24x3121_24762_24ENamed = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241119 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24ENamed, heff_dup(v_p_24760)));
          HeffT2 v_t_241121 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam11, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241119));
          {
            V v_field_241123 = v_t_241121.f[1];
            int64_t v_tag_241122 = ((int64_t)v_t_241121.f[0]);
            if ((v_tag_241122 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241124 = v_field_241123;
              V v_t_241125 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str144), heff_strAppend(heff_dup(v_x_241124), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str145)));
              V v_t_241126 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str146), heff_strAppend(v_x_241124, v_t_241125));
              V v_t_241129;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241128 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241129 = v_s_241128;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241126}), v_t_241129});
            } else {
              heff_drop(v_field_241123);
              V v_t_241130 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241131 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241130}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241132 = v_t_241131.f[0];
                V v_field_241133 = v_t_241131.f[1];
                V v_x_241134 = v_field_241132;
                V v_y_241135 = v_field_241133;
                V v_body_241136 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241139;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241138 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241139 = v_s_241138;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241142;
                switch (heff_tag_of(v_body_241136)) {
                case TAG_At: {
                  V v_s_241141 = heff_dup(heff_field(v_body_241136, 1));
                  v_t_241142 = v_s_241141;
                  break;
                }
                default: heff_nomatch(v_body_241136);
                }
                V v_t_241143 = ({ V rv_1 = heff_get_n(v_t_241142, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241139, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241144 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241136)}), v_t_241143});
                V v_t_241147;
                switch (heff_tag_of(v_body_241136)) {
                case TAG_At: {
                  V v_s_241146 = heff_field(v_body_241136, 1);
                  heff_take_n(v_body_241136, 2ULL, 2);
                  v_t_241147 = v_s_241146;
                  break;
                }
                default: heff_nomatch(v_body_241136);
                }
                V v_t_241148 = ({ V rv_1 = heff_get_n(v_t_241147, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241149 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241135, v_t_241144}), v_t_241148});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241134; V a_2 = v_t_241149; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241134); r_; });
              }
            }
          }
        }
        case TAG_EPi: {
          V v_ru_24x3121_24762_24EPi = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241152 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EPi, heff_dup(v_p_24760)));
          HeffT2 v_t_241154 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam12, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241152));
          {
            V v_field_241156 = v_t_241154.f[1];
            int64_t v_tag_241155 = ((int64_t)v_t_241154.f[0]);
            if ((v_tag_241155 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241157 = v_field_241156;
              V v_t_241158 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str147), heff_strAppend(heff_dup(v_x_241157), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str148)));
              V v_t_241159 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str149), heff_strAppend(v_x_241157, v_t_241158));
              V v_t_241162;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241161 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241162 = v_s_241161;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241159}), v_t_241162});
            } else {
              heff_drop(v_field_241156);
              V v_t_241163 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241164 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241163}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241165 = v_t_241164.f[0];
                V v_field_241166 = v_t_241164.f[1];
                V v_x_241167 = v_field_241165;
                V v_y_241168 = v_field_241166;
                V v_body_241169 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241172;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241171 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241172 = v_s_241171;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241175;
                switch (heff_tag_of(v_body_241169)) {
                case TAG_At: {
                  V v_s_241174 = heff_dup(heff_field(v_body_241169, 1));
                  v_t_241175 = v_s_241174;
                  break;
                }
                default: heff_nomatch(v_body_241169);
                }
                V v_t_241176 = ({ V rv_1 = heff_get_n(v_t_241175, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241172, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241177 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241169)}), v_t_241176});
                V v_t_241180;
                switch (heff_tag_of(v_body_241169)) {
                case TAG_At: {
                  V v_s_241179 = heff_field(v_body_241169, 1);
                  heff_take_n(v_body_241169, 2ULL, 2);
                  v_t_241180 = v_s_241179;
                  break;
                }
                default: heff_nomatch(v_body_241169);
                }
                V v_t_241181 = ({ V rv_1 = heff_get_n(v_t_241180, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241182 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241168, v_t_241177}), v_t_241181});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241167; V a_2 = v_t_241182; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241167); r_; });
              }
            }
          }
        }
        case TAG_ELam: {
          V v_ru_24x3121_24762_24ELam = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241185 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24ELam, heff_dup(v_p_24760)));
          HeffT2 v_t_241187 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam13, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241185));
          {
            V v_field_241189 = v_t_241187.f[1];
            int64_t v_tag_241188 = ((int64_t)v_t_241187.f[0]);
            if ((v_tag_241188 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241190 = v_field_241189;
              V v_t_241191 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str150), heff_strAppend(heff_dup(v_x_241190), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str151)));
              V v_t_241192 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str152), heff_strAppend(v_x_241190, v_t_241191));
              V v_t_241195;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241194 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241195 = v_s_241194;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241192}), v_t_241195});
            } else {
              heff_drop(v_field_241189);
              V v_t_241196 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241197 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241196}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241198 = v_t_241197.f[0];
                V v_field_241199 = v_t_241197.f[1];
                V v_x_241200 = v_field_241198;
                V v_y_241201 = v_field_241199;
                V v_body_241202 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241205;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241204 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241205 = v_s_241204;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241208;
                switch (heff_tag_of(v_body_241202)) {
                case TAG_At: {
                  V v_s_241207 = heff_dup(heff_field(v_body_241202, 1));
                  v_t_241208 = v_s_241207;
                  break;
                }
                default: heff_nomatch(v_body_241202);
                }
                V v_t_241209 = ({ V rv_1 = heff_get_n(v_t_241208, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241205, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241210 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241202)}), v_t_241209});
                V v_t_241213;
                switch (heff_tag_of(v_body_241202)) {
                case TAG_At: {
                  V v_s_241212 = heff_field(v_body_241202, 1);
                  heff_take_n(v_body_241202, 2ULL, 2);
                  v_t_241213 = v_s_241212;
                  break;
                }
                default: heff_nomatch(v_body_241202);
                }
                V v_t_241214 = ({ V rv_1 = heff_get_n(v_t_241213, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241215 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241201, v_t_241210}), v_t_241214});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241200; V a_2 = v_t_241215; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241200); r_; });
              }
            }
          }
        }
        case TAG_EAnn: {
          V v_ru_24x3121_24762_24EAnn = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241218 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EAnn, heff_dup(v_p_24760)));
          HeffT2 v_t_241220 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam14, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241218));
          {
            V v_field_241222 = v_t_241220.f[1];
            int64_t v_tag_241221 = ((int64_t)v_t_241220.f[0]);
            if ((v_tag_241221 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241223 = v_field_241222;
              V v_t_241224 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str153), heff_strAppend(heff_dup(v_x_241223), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str154)));
              V v_t_241225 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str155), heff_strAppend(v_x_241223, v_t_241224));
              V v_t_241228;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241227 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241228 = v_s_241227;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241225}), v_t_241228});
            } else {
              heff_drop(v_field_241222);
              V v_t_241229 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241230 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241229}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241231 = v_t_241230.f[0];
                V v_field_241232 = v_t_241230.f[1];
                V v_x_241233 = v_field_241231;
                V v_y_241234 = v_field_241232;
                V v_body_241235 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241238;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241237 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241238 = v_s_241237;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241241;
                switch (heff_tag_of(v_body_241235)) {
                case TAG_At: {
                  V v_s_241240 = heff_dup(heff_field(v_body_241235, 1));
                  v_t_241241 = v_s_241240;
                  break;
                }
                default: heff_nomatch(v_body_241235);
                }
                V v_t_241242 = ({ V rv_1 = heff_get_n(v_t_241241, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241238, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241243 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241235)}), v_t_241242});
                V v_t_241246;
                switch (heff_tag_of(v_body_241235)) {
                case TAG_At: {
                  V v_s_241245 = heff_field(v_body_241235, 1);
                  heff_take_n(v_body_241235, 2ULL, 2);
                  v_t_241246 = v_s_241245;
                  break;
                }
                default: heff_nomatch(v_body_241235);
                }
                V v_t_241247 = ({ V rv_1 = heff_get_n(v_t_241246, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241248 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241234, v_t_241243}), v_t_241247});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241233; V a_2 = v_t_241248; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241233); r_; });
              }
            }
          }
        }
        case TAG_ESpec: {
          heff_take_n(v_x3121_24762, 0ULL, 4);
          V v_xs_241253 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241255 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam15, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241253));
          {
            V v_field_241257 = v_t_241255.f[1];
            int64_t v_tag_241256 = ((int64_t)v_t_241255.f[0]);
            if ((v_tag_241256 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241258 = v_field_241257;
              V v_t_241259 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str156), heff_strAppend(heff_dup(v_x_241258), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str157)));
              V v_t_241260 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str158), heff_strAppend(v_x_241258, v_t_241259));
              V v_t_241263;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241262 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241263 = v_s_241262;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241260}), v_t_241263});
            } else {
              heff_drop(v_field_241257);
              V v_t_241264 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241265 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241264}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241266 = v_t_241265.f[0];
                V v_field_241267 = v_t_241265.f[1];
                V v_x_241268 = v_field_241266;
                V v_y_241269 = v_field_241267;
                V v_body_241270 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241273;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241272 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241273 = v_s_241272;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241276;
                switch (heff_tag_of(v_body_241270)) {
                case TAG_At: {
                  V v_s_241275 = heff_dup(heff_field(v_body_241270, 1));
                  v_t_241276 = v_s_241275;
                  break;
                }
                default: heff_nomatch(v_body_241270);
                }
                V v_t_241277 = ({ V rv_1 = heff_get_n(v_t_241276, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241273, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241278 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241270)}), v_t_241277});
                V v_t_241281;
                switch (heff_tag_of(v_body_241270)) {
                case TAG_At: {
                  V v_s_241280 = heff_field(v_body_241270, 1);
                  heff_take_n(v_body_241270, 2ULL, 2);
                  v_t_241281 = v_s_241280;
                  break;
                }
                default: heff_nomatch(v_body_241270);
                }
                V v_t_241282 = ({ V rv_1 = heff_get_n(v_t_241281, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241283 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241269, v_t_241278}), v_t_241282});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241268; V a_2 = v_t_241283; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241268); r_; });
              }
            }
          }
        }
        case TAG_ESig: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241285 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241287 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam16, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241285));
          {
            V v_field_241289 = v_t_241287.f[1];
            int64_t v_tag_241288 = ((int64_t)v_t_241287.f[0]);
            if ((v_tag_241288 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241290 = v_field_241289;
              V v_t_241291 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str159), heff_strAppend(heff_dup(v_x_241290), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str160)));
              V v_t_241292 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str161), heff_strAppend(v_x_241290, v_t_241291));
              V v_t_241295;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241294 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241295 = v_s_241294;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241292}), v_t_241295});
            } else {
              heff_drop(v_field_241289);
              V v_t_241296 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241297 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241296}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241298 = v_t_241297.f[0];
                V v_field_241299 = v_t_241297.f[1];
                V v_x_241300 = v_field_241298;
                V v_y_241301 = v_field_241299;
                V v_body_241302 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241305;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241304 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241305 = v_s_241304;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241308;
                switch (heff_tag_of(v_body_241302)) {
                case TAG_At: {
                  V v_s_241307 = heff_dup(heff_field(v_body_241302, 1));
                  v_t_241308 = v_s_241307;
                  break;
                }
                default: heff_nomatch(v_body_241302);
                }
                V v_t_241309 = ({ V rv_1 = heff_get_n(v_t_241308, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241305, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241310 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241302)}), v_t_241309});
                V v_t_241313;
                switch (heff_tag_of(v_body_241302)) {
                case TAG_At: {
                  V v_s_241312 = heff_field(v_body_241302, 1);
                  heff_take_n(v_body_241302, 2ULL, 2);
                  v_t_241313 = v_s_241312;
                  break;
                }
                default: heff_nomatch(v_body_241302);
                }
                V v_t_241314 = ({ V rv_1 = heff_get_n(v_t_241313, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241315 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241301, v_t_241310}), v_t_241314});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241300; V a_2 = v_t_241315; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241300); r_; });
              }
            }
          }
        }
        case TAG_ESum: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241317 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241319 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam17, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241317));
          {
            V v_field_241321 = v_t_241319.f[1];
            int64_t v_tag_241320 = ((int64_t)v_t_241319.f[0]);
            if ((v_tag_241320 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241322 = v_field_241321;
              V v_t_241323 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str162), heff_strAppend(heff_dup(v_x_241322), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str163)));
              V v_t_241324 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str164), heff_strAppend(v_x_241322, v_t_241323));
              V v_t_241327;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241326 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241327 = v_s_241326;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241324}), v_t_241327});
            } else {
              heff_drop(v_field_241321);
              V v_t_241328 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241329 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241328}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241330 = v_t_241329.f[0];
                V v_field_241331 = v_t_241329.f[1];
                V v_x_241332 = v_field_241330;
                V v_y_241333 = v_field_241331;
                V v_body_241334 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241337;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241336 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241337 = v_s_241336;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241340;
                switch (heff_tag_of(v_body_241334)) {
                case TAG_At: {
                  V v_s_241339 = heff_dup(heff_field(v_body_241334, 1));
                  v_t_241340 = v_s_241339;
                  break;
                }
                default: heff_nomatch(v_body_241334);
                }
                V v_t_241341 = ({ V rv_1 = heff_get_n(v_t_241340, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241337, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241342 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241334)}), v_t_241341});
                V v_t_241345;
                switch (heff_tag_of(v_body_241334)) {
                case TAG_At: {
                  V v_s_241344 = heff_field(v_body_241334, 1);
                  heff_take_n(v_body_241334, 2ULL, 2);
                  v_t_241345 = v_s_241344;
                  break;
                }
                default: heff_nomatch(v_body_241334);
                }
                V v_t_241346 = ({ V rv_1 = heff_get_n(v_t_241345, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241347 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241333, v_t_241342}), v_t_241346});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241332; V a_2 = v_t_241347; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241332); r_; });
              }
            }
          }
        }
        case TAG_EStruct: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241349 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241351 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam18, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241349));
          {
            V v_field_241353 = v_t_241351.f[1];
            int64_t v_tag_241352 = ((int64_t)v_t_241351.f[0]);
            if ((v_tag_241352 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241354 = v_field_241353;
              V v_t_241355 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str165), heff_strAppend(heff_dup(v_x_241354), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str166)));
              V v_t_241356 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str167), heff_strAppend(v_x_241354, v_t_241355));
              V v_t_241359;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241358 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241359 = v_s_241358;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241356}), v_t_241359});
            } else {
              heff_drop(v_field_241353);
              V v_t_241360 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241361 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241360}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241362 = v_t_241361.f[0];
                V v_field_241363 = v_t_241361.f[1];
                V v_x_241364 = v_field_241362;
                V v_y_241365 = v_field_241363;
                V v_body_241366 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241369;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241368 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241369 = v_s_241368;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241372;
                switch (heff_tag_of(v_body_241366)) {
                case TAG_At: {
                  V v_s_241371 = heff_dup(heff_field(v_body_241366, 1));
                  v_t_241372 = v_s_241371;
                  break;
                }
                default: heff_nomatch(v_body_241366);
                }
                V v_t_241373 = ({ V rv_1 = heff_get_n(v_t_241372, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241369, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241374 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241366)}), v_t_241373});
                V v_t_241377;
                switch (heff_tag_of(v_body_241366)) {
                case TAG_At: {
                  V v_s_241376 = heff_field(v_body_241366, 1);
                  heff_take_n(v_body_241366, 2ULL, 2);
                  v_t_241377 = v_s_241376;
                  break;
                }
                default: heff_nomatch(v_body_241366);
                }
                V v_t_241378 = ({ V rv_1 = heff_get_n(v_t_241377, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241379 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241365, v_t_241374}), v_t_241378});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241364; V a_2 = v_t_241379; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241364); r_; });
              }
            }
          }
        }
        case TAG_EUpdate: {
          V v_ru_24x3121_24762_24EUpdate = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241382 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EUpdate, heff_dup(v_p_24760)));
          HeffT2 v_t_241384 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam19, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241382));
          {
            V v_field_241386 = v_t_241384.f[1];
            int64_t v_tag_241385 = ((int64_t)v_t_241384.f[0]);
            if ((v_tag_241385 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241387 = v_field_241386;
              V v_t_241388 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str168), heff_strAppend(heff_dup(v_x_241387), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str169)));
              V v_t_241389 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str170), heff_strAppend(v_x_241387, v_t_241388));
              V v_t_241392;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241391 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241392 = v_s_241391;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241389}), v_t_241392});
            } else {
              heff_drop(v_field_241386);
              V v_t_241393 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241394 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241393}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241395 = v_t_241394.f[0];
                V v_field_241396 = v_t_241394.f[1];
                V v_x_241397 = v_field_241395;
                V v_y_241398 = v_field_241396;
                V v_body_241399 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241402;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241401 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241402 = v_s_241401;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241405;
                switch (heff_tag_of(v_body_241399)) {
                case TAG_At: {
                  V v_s_241404 = heff_dup(heff_field(v_body_241399, 1));
                  v_t_241405 = v_s_241404;
                  break;
                }
                default: heff_nomatch(v_body_241399);
                }
                V v_t_241406 = ({ V rv_1 = heff_get_n(v_t_241405, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241402, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241407 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241399)}), v_t_241406});
                V v_t_241410;
                switch (heff_tag_of(v_body_241399)) {
                case TAG_At: {
                  V v_s_241409 = heff_field(v_body_241399, 1);
                  heff_take_n(v_body_241399, 2ULL, 2);
                  v_t_241410 = v_s_241409;
                  break;
                }
                default: heff_nomatch(v_body_241399);
                }
                V v_t_241411 = ({ V rv_1 = heff_get_n(v_t_241410, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241412 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241398, v_t_241407}), v_t_241411});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241397; V a_2 = v_t_241412; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241397); r_; });
              }
            }
          }
        }
        case TAG_EMatch: {
          V v_ru_24x3121_24762_24EMatch = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241415 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EMatch, heff_dup(v_p_24760)));
          HeffT2 v_t_241417 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam20, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241415));
          {
            V v_field_241419 = v_t_241417.f[1];
            int64_t v_tag_241418 = ((int64_t)v_t_241417.f[0]);
            if ((v_tag_241418 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241420 = v_field_241419;
              V v_t_241421 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str171), heff_strAppend(heff_dup(v_x_241420), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str172)));
              V v_t_241422 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str173), heff_strAppend(v_x_241420, v_t_241421));
              V v_t_241425;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241424 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241425 = v_s_241424;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241422}), v_t_241425});
            } else {
              heff_drop(v_field_241419);
              V v_t_241426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241426}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241428 = v_t_241427.f[0];
                V v_field_241429 = v_t_241427.f[1];
                V v_x_241430 = v_field_241428;
                V v_y_241431 = v_field_241429;
                V v_body_241432 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241435;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241434 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241435 = v_s_241434;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241438;
                switch (heff_tag_of(v_body_241432)) {
                case TAG_At: {
                  V v_s_241437 = heff_dup(heff_field(v_body_241432, 1));
                  v_t_241438 = v_s_241437;
                  break;
                }
                default: heff_nomatch(v_body_241432);
                }
                V v_t_241439 = ({ V rv_1 = heff_get_n(v_t_241438, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241435, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241440 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241432)}), v_t_241439});
                V v_t_241443;
                switch (heff_tag_of(v_body_241432)) {
                case TAG_At: {
                  V v_s_241442 = heff_field(v_body_241432, 1);
                  heff_take_n(v_body_241432, 2ULL, 2);
                  v_t_241443 = v_s_241442;
                  break;
                }
                default: heff_nomatch(v_body_241432);
                }
                V v_t_241444 = ({ V rv_1 = heff_get_n(v_t_241443, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241445 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241431, v_t_241440}), v_t_241444});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241430; V a_2 = v_t_241445; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241430); r_; });
              }
            }
          }
        }
        case TAG_ELetIn: {
          V v_ru_24x3121_24762_24ELetIn = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241448 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24ELetIn, heff_dup(v_p_24760)));
          HeffT2 v_t_241450 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam21, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241448));
          {
            V v_field_241452 = v_t_241450.f[1];
            int64_t v_tag_241451 = ((int64_t)v_t_241450.f[0]);
            if ((v_tag_241451 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241453 = v_field_241452;
              V v_t_241454 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str174), heff_strAppend(heff_dup(v_x_241453), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str175)));
              V v_t_241455 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str176), heff_strAppend(v_x_241453, v_t_241454));
              V v_t_241458;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241457 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241458 = v_s_241457;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241455}), v_t_241458});
            } else {
              heff_drop(v_field_241452);
              V v_t_241459 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241460 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241459}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241461 = v_t_241460.f[0];
                V v_field_241462 = v_t_241460.f[1];
                V v_x_241463 = v_field_241461;
                V v_y_241464 = v_field_241462;
                V v_body_241465 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241468;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241467 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241468 = v_s_241467;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241471;
                switch (heff_tag_of(v_body_241465)) {
                case TAG_At: {
                  V v_s_241470 = heff_dup(heff_field(v_body_241465, 1));
                  v_t_241471 = v_s_241470;
                  break;
                }
                default: heff_nomatch(v_body_241465);
                }
                V v_t_241472 = ({ V rv_1 = heff_get_n(v_t_241471, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241468, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241473 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241465)}), v_t_241472});
                V v_t_241476;
                switch (heff_tag_of(v_body_241465)) {
                case TAG_At: {
                  V v_s_241475 = heff_field(v_body_241465, 1);
                  heff_take_n(v_body_241465, 2ULL, 2);
                  v_t_241476 = v_s_241475;
                  break;
                }
                default: heff_nomatch(v_body_241465);
                }
                V v_t_241477 = ({ V rv_1 = heff_get_n(v_t_241476, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241478 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241464, v_t_241473}), v_t_241477});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241463; V a_2 = v_t_241478; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241463); r_; });
              }
            }
          }
        }
        case TAG_EDo: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241480 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241482 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam22, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241480));
          {
            V v_field_241484 = v_t_241482.f[1];
            int64_t v_tag_241483 = ((int64_t)v_t_241482.f[0]);
            if ((v_tag_241483 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241485 = v_field_241484;
              V v_t_241486 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str177), heff_strAppend(heff_dup(v_x_241485), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str178)));
              V v_t_241487 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str179), heff_strAppend(v_x_241485, v_t_241486));
              V v_t_241490;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241489 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241490 = v_s_241489;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241487}), v_t_241490});
            } else {
              heff_drop(v_field_241484);
              V v_t_241491 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241492 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241491}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241493 = v_t_241492.f[0];
                V v_field_241494 = v_t_241492.f[1];
                V v_x_241495 = v_field_241493;
                V v_y_241496 = v_field_241494;
                V v_body_241497 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241500;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241499 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241500 = v_s_241499;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241503;
                switch (heff_tag_of(v_body_241497)) {
                case TAG_At: {
                  V v_s_241502 = heff_dup(heff_field(v_body_241497, 1));
                  v_t_241503 = v_s_241502;
                  break;
                }
                default: heff_nomatch(v_body_241497);
                }
                V v_t_241504 = ({ V rv_1 = heff_get_n(v_t_241503, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241500, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241505 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241497)}), v_t_241504});
                V v_t_241508;
                switch (heff_tag_of(v_body_241497)) {
                case TAG_At: {
                  V v_s_241507 = heff_field(v_body_241497, 1);
                  heff_take_n(v_body_241497, 2ULL, 2);
                  v_t_241508 = v_s_241507;
                  break;
                }
                default: heff_nomatch(v_body_241497);
                }
                V v_t_241509 = ({ V rv_1 = heff_get_n(v_t_241508, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241510 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241496, v_t_241505}), v_t_241509});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241495; V a_2 = v_t_241510; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241495); r_; });
              }
            }
          }
        }
        case TAG_ELocal: {
          V v_ru_24x3121_24762_24ELocal = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241513 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24ELocal, heff_dup(v_p_24760)));
          HeffT2 v_t_241515 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam23, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241513));
          {
            V v_field_241517 = v_t_241515.f[1];
            int64_t v_tag_241516 = ((int64_t)v_t_241515.f[0]);
            if ((v_tag_241516 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241518 = v_field_241517;
              V v_t_241519 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str180), heff_strAppend(heff_dup(v_x_241518), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str181)));
              V v_t_241520 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str182), heff_strAppend(v_x_241518, v_t_241519));
              V v_t_241523;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241522 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241523 = v_s_241522;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241520}), v_t_241523});
            } else {
              heff_drop(v_field_241517);
              V v_t_241524 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241525 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241524}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241526 = v_t_241525.f[0];
                V v_field_241527 = v_t_241525.f[1];
                V v_x_241528 = v_field_241526;
                V v_y_241529 = v_field_241527;
                V v_body_241530 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241533;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241532 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241533 = v_s_241532;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241536;
                switch (heff_tag_of(v_body_241530)) {
                case TAG_At: {
                  V v_s_241535 = heff_dup(heff_field(v_body_241530, 1));
                  v_t_241536 = v_s_241535;
                  break;
                }
                default: heff_nomatch(v_body_241530);
                }
                V v_t_241537 = ({ V rv_1 = heff_get_n(v_t_241536, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241533, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241538 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241530)}), v_t_241537});
                V v_t_241541;
                switch (heff_tag_of(v_body_241530)) {
                case TAG_At: {
                  V v_s_241540 = heff_field(v_body_241530, 1);
                  heff_take_n(v_body_241530, 2ULL, 2);
                  v_t_241541 = v_s_241540;
                  break;
                }
                default: heff_nomatch(v_body_241530);
                }
                V v_t_241542 = ({ V rv_1 = heff_get_n(v_t_241541, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241543 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241529, v_t_241538}), v_t_241542});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241528; V a_2 = v_t_241543; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241528); r_; });
              }
            }
          }
        }
        case TAG_EInvalid: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241545 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241547 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam24, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241545));
          {
            V v_field_241549 = v_t_241547.f[1];
            int64_t v_tag_241548 = ((int64_t)v_t_241547.f[0]);
            if ((v_tag_241548 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241550 = v_field_241549;
              V v_t_241551 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str183), heff_strAppend(heff_dup(v_x_241550), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str184)));
              V v_t_241552 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str185), heff_strAppend(v_x_241550, v_t_241551));
              V v_t_241555;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241554 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241555 = v_s_241554;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241552}), v_t_241555});
            } else {
              heff_drop(v_field_241549);
              V v_t_241556 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241557 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241556}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241558 = v_t_241557.f[0];
                V v_field_241559 = v_t_241557.f[1];
                V v_x_241560 = v_field_241558;
                V v_y_241561 = v_field_241559;
                V v_body_241562 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241565;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241564 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241565 = v_s_241564;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241568;
                switch (heff_tag_of(v_body_241562)) {
                case TAG_At: {
                  V v_s_241567 = heff_dup(heff_field(v_body_241562, 1));
                  v_t_241568 = v_s_241567;
                  break;
                }
                default: heff_nomatch(v_body_241562);
                }
                V v_t_241569 = ({ V rv_1 = heff_get_n(v_t_241568, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241565, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241570 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241562)}), v_t_241569});
                V v_t_241573;
                switch (heff_tag_of(v_body_241562)) {
                case TAG_At: {
                  V v_s_241572 = heff_field(v_body_241562, 1);
                  heff_take_n(v_body_241562, 2ULL, 2);
                  v_t_241573 = v_s_241572;
                  break;
                }
                default: heff_nomatch(v_body_241562);
                }
                V v_t_241574 = ({ V rv_1 = heff_get_n(v_t_241573, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241575 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241561, v_t_241570}), v_t_241574});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241560; V a_2 = v_t_241575; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241560); r_; });
              }
            }
          }
        }
        case TAG_EAssign: {
          heff_take_n(v_x3121_24762, 0ULL, 3);
          V v_xs_241579 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241581 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam25, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241579));
          {
            V v_field_241583 = v_t_241581.f[1];
            int64_t v_tag_241582 = ((int64_t)v_t_241581.f[0]);
            if ((v_tag_241582 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241584 = v_field_241583;
              V v_t_241585 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str186), heff_strAppend(heff_dup(v_x_241584), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str187)));
              V v_t_241586 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str188), heff_strAppend(v_x_241584, v_t_241585));
              V v_t_241589;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241588 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241589 = v_s_241588;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241586}), v_t_241589});
            } else {
              heff_drop(v_field_241583);
              V v_t_241590 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241591 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241590}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241592 = v_t_241591.f[0];
                V v_field_241593 = v_t_241591.f[1];
                V v_x_241594 = v_field_241592;
                V v_y_241595 = v_field_241593;
                V v_body_241596 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241599;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241598 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241599 = v_s_241598;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241602;
                switch (heff_tag_of(v_body_241596)) {
                case TAG_At: {
                  V v_s_241601 = heff_dup(heff_field(v_body_241596, 1));
                  v_t_241602 = v_s_241601;
                  break;
                }
                default: heff_nomatch(v_body_241596);
                }
                V v_t_241603 = ({ V rv_1 = heff_get_n(v_t_241602, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241599, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241604 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241596)}), v_t_241603});
                V v_t_241607;
                switch (heff_tag_of(v_body_241596)) {
                case TAG_At: {
                  V v_s_241606 = heff_field(v_body_241596, 1);
                  heff_take_n(v_body_241596, 2ULL, 2);
                  v_t_241607 = v_s_241606;
                  break;
                }
                default: heff_nomatch(v_body_241596);
                }
                V v_t_241608 = ({ V rv_1 = heff_get_n(v_t_241607, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241609 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241595, v_t_241604}), v_t_241608});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241594; V a_2 = v_t_241609; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241594); r_; });
              }
            }
          }
        }
        case TAG_EWhile: {
          V v_ru_24x3121_24762_24EWhile = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241612 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EWhile, heff_dup(v_p_24760)));
          HeffT2 v_t_241614 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam26, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241612));
          {
            V v_field_241616 = v_t_241614.f[1];
            int64_t v_tag_241615 = ((int64_t)v_t_241614.f[0]);
            if ((v_tag_241615 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241617 = v_field_241616;
              V v_t_241618 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str189), heff_strAppend(heff_dup(v_x_241617), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str190)));
              V v_t_241619 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str191), heff_strAppend(v_x_241617, v_t_241618));
              V v_t_241622;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241621 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241622 = v_s_241621;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241619}), v_t_241622});
            } else {
              heff_drop(v_field_241616);
              V v_t_241623 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241624 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241623}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241625 = v_t_241624.f[0];
                V v_field_241626 = v_t_241624.f[1];
                V v_x_241627 = v_field_241625;
                V v_y_241628 = v_field_241626;
                V v_body_241629 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241632;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241631 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241632 = v_s_241631;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241635;
                switch (heff_tag_of(v_body_241629)) {
                case TAG_At: {
                  V v_s_241634 = heff_dup(heff_field(v_body_241629, 1));
                  v_t_241635 = v_s_241634;
                  break;
                }
                default: heff_nomatch(v_body_241629);
                }
                V v_t_241636 = ({ V rv_1 = heff_get_n(v_t_241635, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241632, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241637 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241629)}), v_t_241636});
                V v_t_241640;
                switch (heff_tag_of(v_body_241629)) {
                case TAG_At: {
                  V v_s_241639 = heff_field(v_body_241629, 1);
                  heff_take_n(v_body_241629, 2ULL, 2);
                  v_t_241640 = v_s_241639;
                  break;
                }
                default: heff_nomatch(v_body_241629);
                }
                V v_t_241641 = ({ V rv_1 = heff_get_n(v_t_241640, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241642 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241628, v_t_241637}), v_t_241641});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241627; V a_2 = v_t_241642; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241627); r_; });
              }
            }
          }
        }
        case TAG_EFor: {
          heff_take_n(v_x3121_24762, 0ULL, 3);
          V v_xs_241646 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241648 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam27, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241646));
          {
            V v_field_241650 = v_t_241648.f[1];
            int64_t v_tag_241649 = ((int64_t)v_t_241648.f[0]);
            if ((v_tag_241649 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241651 = v_field_241650;
              V v_t_241652 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str192), heff_strAppend(heff_dup(v_x_241651), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str193)));
              V v_t_241653 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str194), heff_strAppend(v_x_241651, v_t_241652));
              V v_t_241656;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241655 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241656 = v_s_241655;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241653}), v_t_241656});
            } else {
              heff_drop(v_field_241650);
              V v_t_241657 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241658 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241657}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241659 = v_t_241658.f[0];
                V v_field_241660 = v_t_241658.f[1];
                V v_x_241661 = v_field_241659;
                V v_y_241662 = v_field_241660;
                V v_body_241663 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241666;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241665 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241666 = v_s_241665;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241669;
                switch (heff_tag_of(v_body_241663)) {
                case TAG_At: {
                  V v_s_241668 = heff_dup(heff_field(v_body_241663, 1));
                  v_t_241669 = v_s_241668;
                  break;
                }
                default: heff_nomatch(v_body_241663);
                }
                V v_t_241670 = ({ V rv_1 = heff_get_n(v_t_241669, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241666, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241671 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241663)}), v_t_241670});
                V v_t_241674;
                switch (heff_tag_of(v_body_241663)) {
                case TAG_At: {
                  V v_s_241673 = heff_field(v_body_241663, 1);
                  heff_take_n(v_body_241663, 2ULL, 2);
                  v_t_241674 = v_s_241673;
                  break;
                }
                default: heff_nomatch(v_body_241663);
                }
                V v_t_241675 = ({ V rv_1 = heff_get_n(v_t_241674, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241676 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241662, v_t_241671}), v_t_241675});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241661; V a_2 = v_t_241676; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241661); r_; });
              }
            }
          }
        }
        case TAG_EIfThen: {
          V v_ru_24x3121_24762_24EIfThen = heff_take_reuse_n(v_x3121_24762, 0ULL, 2);
          V v_xs_241679 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x3121_24762_24EIfThen, heff_dup(v_p_24760)));
          HeffT2 v_t_241681 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam28, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241679));
          {
            V v_field_241683 = v_t_241681.f[1];
            int64_t v_tag_241682 = ((int64_t)v_t_241681.f[0]);
            if ((v_tag_241682 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241684 = v_field_241683;
              V v_t_241685 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str195), heff_strAppend(heff_dup(v_x_241684), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str196)));
              V v_t_241686 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str197), heff_strAppend(v_x_241684, v_t_241685));
              V v_t_241689;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241688 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241689 = v_s_241688;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241686}), v_t_241689});
            } else {
              heff_drop(v_field_241683);
              V v_t_241690 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241691 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241690}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241692 = v_t_241691.f[0];
                V v_field_241693 = v_t_241691.f[1];
                V v_x_241694 = v_field_241692;
                V v_y_241695 = v_field_241693;
                V v_body_241696 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241699;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241698 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241699 = v_s_241698;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241702;
                switch (heff_tag_of(v_body_241696)) {
                case TAG_At: {
                  V v_s_241701 = heff_dup(heff_field(v_body_241696, 1));
                  v_t_241702 = v_s_241701;
                  break;
                }
                default: heff_nomatch(v_body_241696);
                }
                V v_t_241703 = ({ V rv_1 = heff_get_n(v_t_241702, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241699, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241704 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241696)}), v_t_241703});
                V v_t_241707;
                switch (heff_tag_of(v_body_241696)) {
                case TAG_At: {
                  V v_s_241706 = heff_field(v_body_241696, 1);
                  heff_take_n(v_body_241696, 2ULL, 2);
                  v_t_241707 = v_s_241706;
                  break;
                }
                default: heff_nomatch(v_body_241696);
                }
                V v_t_241708 = ({ V rv_1 = heff_get_n(v_t_241707, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241709 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241695, v_t_241704}), v_t_241708});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241694; V a_2 = v_t_241709; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241694); r_; });
              }
            }
          }
        }
        case TAG_EBreak: {
          V v_xs_241710 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241712 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam29, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241710));
          {
            V v_field_241714 = v_t_241712.f[1];
            int64_t v_tag_241713 = ((int64_t)v_t_241712.f[0]);
            if ((v_tag_241713 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241715 = v_field_241714;
              V v_t_241716 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str198), heff_strAppend(heff_dup(v_x_241715), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str199)));
              V v_t_241717 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str200), heff_strAppend(v_x_241715, v_t_241716));
              V v_t_241720;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241719 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241720 = v_s_241719;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241717}), v_t_241720});
            } else {
              heff_drop(v_field_241714);
              V v_t_241721 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241722 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241721}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241723 = v_t_241722.f[0];
                V v_field_241724 = v_t_241722.f[1];
                V v_x_241725 = v_field_241723;
                V v_y_241726 = v_field_241724;
                V v_body_241727 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241730;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241729 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241730 = v_s_241729;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241733;
                switch (heff_tag_of(v_body_241727)) {
                case TAG_At: {
                  V v_s_241732 = heff_dup(heff_field(v_body_241727, 1));
                  v_t_241733 = v_s_241732;
                  break;
                }
                default: heff_nomatch(v_body_241727);
                }
                V v_t_241734 = ({ V rv_1 = heff_get_n(v_t_241733, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241730, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241735 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241727)}), v_t_241734});
                V v_t_241738;
                switch (heff_tag_of(v_body_241727)) {
                case TAG_At: {
                  V v_s_241737 = heff_field(v_body_241727, 1);
                  heff_take_n(v_body_241727, 2ULL, 2);
                  v_t_241738 = v_s_241737;
                  break;
                }
                default: heff_nomatch(v_body_241727);
                }
                V v_t_241739 = ({ V rv_1 = heff_get_n(v_t_241738, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241740 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241726, v_t_241735}), v_t_241739});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241725; V a_2 = v_t_241740; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241725); r_; });
              }
            }
          }
        }
        case TAG_EContinue: {
          V v_xs_241741 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241743 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam30, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241741));
          {
            V v_field_241745 = v_t_241743.f[1];
            int64_t v_tag_241744 = ((int64_t)v_t_241743.f[0]);
            if ((v_tag_241744 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241746 = v_field_241745;
              V v_t_241747 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str201), heff_strAppend(heff_dup(v_x_241746), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str202)));
              V v_t_241748 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str203), heff_strAppend(v_x_241746, v_t_241747));
              V v_t_241751;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241750 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241751 = v_s_241750;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241748}), v_t_241751});
            } else {
              heff_drop(v_field_241745);
              V v_t_241752 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241753 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241752}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241754 = v_t_241753.f[0];
                V v_field_241755 = v_t_241753.f[1];
                V v_x_241756 = v_field_241754;
                V v_y_241757 = v_field_241755;
                V v_body_241758 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241761;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241760 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241761 = v_s_241760;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241764;
                switch (heff_tag_of(v_body_241758)) {
                case TAG_At: {
                  V v_s_241763 = heff_dup(heff_field(v_body_241758, 1));
                  v_t_241764 = v_s_241763;
                  break;
                }
                default: heff_nomatch(v_body_241758);
                }
                V v_t_241765 = ({ V rv_1 = heff_get_n(v_t_241764, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241761, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241766 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241758)}), v_t_241765});
                V v_t_241769;
                switch (heff_tag_of(v_body_241758)) {
                case TAG_At: {
                  V v_s_241768 = heff_field(v_body_241758, 1);
                  heff_take_n(v_body_241758, 2ULL, 2);
                  v_t_241769 = v_s_241768;
                  break;
                }
                default: heff_nomatch(v_body_241758);
                }
                V v_t_241770 = ({ V rv_1 = heff_get_n(v_t_241769, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241771 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241757, v_t_241766}), v_t_241770});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241756; V a_2 = v_t_241771; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241756); r_; });
              }
            }
          }
        }
        case TAG_EReturn: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_241773 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_241775 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam31, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241773));
          {
            V v_field_241777 = v_t_241775.f[1];
            int64_t v_tag_241776 = ((int64_t)v_t_241775.f[0]);
            if ((v_tag_241776 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241778 = v_field_241777;
              V v_t_241779 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str204), heff_strAppend(heff_dup(v_x_241778), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str205)));
              V v_t_241780 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str206), heff_strAppend(v_x_241778, v_t_241779));
              V v_t_241783;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_241782 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_241783 = v_s_241782;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241780}), v_t_241783});
            } else {
              heff_drop(v_field_241777);
              V v_t_241784 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241785 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241784}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_241786 = v_t_241785.f[0];
                V v_field_241787 = v_t_241785.f[1];
                V v_x_241788 = v_field_241786;
                V v_y_241789 = v_field_241787;
                V v_body_241790 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241793;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_241792 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_241793 = v_s_241792;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_241796;
                switch (heff_tag_of(v_body_241790)) {
                case TAG_At: {
                  V v_s_241795 = heff_dup(heff_field(v_body_241790, 1));
                  v_t_241796 = v_s_241795;
                  break;
                }
                default: heff_nomatch(v_body_241790);
                }
                V v_t_241797 = ({ V rv_1 = heff_get_n(v_t_241796, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241793, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241798 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241790)}), v_t_241797});
                V v_t_241801;
                switch (heff_tag_of(v_body_241790)) {
                case TAG_At: {
                  V v_s_241800 = heff_field(v_body_241790, 1);
                  heff_take_n(v_body_241790, 2ULL, 2);
                  v_t_241801 = v_s_241800;
                  break;
                }
                default: heff_nomatch(v_body_241790);
                }
                V v_t_241802 = ({ V rv_1 = heff_get_n(v_t_241801, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241803 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241789, v_t_241798}), v_t_241802});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241788; V a_2 = v_t_241803; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241788); r_; });
              }
            }
          }
        }
        case TAG_ENest: {
          V v_x31211_241804 = heff_field(v_x3121_24762, 0);
          heff_take_n(v_x3121_24762, 1ULL, 1);
          switch (heff_tag_of(v_x31211_241804)) {
          case TAG_At: {
            V v_x312111_241805 = heff_field(v_x31211_241804, 0);
            V v_fsp_241806 = heff_field(v_x31211_241804, 1);
            V v_ru_24x31211_241804_24At = heff_take_reuse_n(v_x31211_241804, 3ULL, 2);
            switch (heff_tag_of(v_x312111_241805)) {
            case TAG_EVar: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241808 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241810 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam32, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241808));
              {
                V v_field_241812 = v_t_241810.f[1];
                int64_t v_tag_241811 = ((int64_t)v_t_241810.f[0]);
                if ((v_tag_241811 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241813 = v_field_241812;
                  V v_t_241814 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str207), heff_strAppend(heff_dup(v_x_241813), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str208)));
                  V v_t_241815 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str209), heff_strAppend(v_x_241813, v_t_241814));
                  V v_t_241818;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241817 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241818 = v_s_241817;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241815}), v_t_241818});
                } else {
                  heff_drop(v_field_241812);
                  V v_t_241819 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241820 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241819}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241821 = v_t_241820.f[0];
                    V v_field_241822 = v_t_241820.f[1];
                    V v_x_241823 = v_field_241821;
                    V v_y_241824 = v_field_241822;
                    V v_body_241825 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241828;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241827 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241828 = v_s_241827;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241831;
                    switch (heff_tag_of(v_body_241825)) {
                    case TAG_At: {
                      V v_s_241830 = heff_dup(heff_field(v_body_241825, 1));
                      v_t_241831 = v_s_241830;
                      break;
                    }
                    default: heff_nomatch(v_body_241825);
                    }
                    V v_t_241832 = ({ V rv_1 = heff_get_n(v_t_241831, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241828, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241833 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241825)}), v_t_241832});
                    V v_t_241836;
                    switch (heff_tag_of(v_body_241825)) {
                    case TAG_At: {
                      V v_s_241835 = heff_field(v_body_241825, 1);
                      heff_take_n(v_body_241825, 2ULL, 2);
                      v_t_241836 = v_s_241835;
                      break;
                    }
                    default: heff_nomatch(v_body_241825);
                    }
                    V v_t_241837 = ({ V rv_1 = heff_get_n(v_t_241836, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241838 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241824, v_t_241833}), v_t_241837});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241823; V a_2 = v_t_241838; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241823); r_; });
                  }
                }
              }
            }
            case TAG_EImplicitVar: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241840 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241842 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam33, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241840));
              {
                V v_field_241844 = v_t_241842.f[1];
                int64_t v_tag_241843 = ((int64_t)v_t_241842.f[0]);
                if ((v_tag_241843 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241845 = v_field_241844;
                  V v_t_241846 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str210), heff_strAppend(heff_dup(v_x_241845), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str211)));
                  V v_t_241847 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str212), heff_strAppend(v_x_241845, v_t_241846));
                  V v_t_241850;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241849 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241850 = v_s_241849;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241847}), v_t_241850});
                } else {
                  heff_drop(v_field_241844);
                  V v_t_241851 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241852 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241851}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241853 = v_t_241852.f[0];
                    V v_field_241854 = v_t_241852.f[1];
                    V v_x_241855 = v_field_241853;
                    V v_y_241856 = v_field_241854;
                    V v_body_241857 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241860;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241859 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241860 = v_s_241859;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241863;
                    switch (heff_tag_of(v_body_241857)) {
                    case TAG_At: {
                      V v_s_241862 = heff_dup(heff_field(v_body_241857, 1));
                      v_t_241863 = v_s_241862;
                      break;
                    }
                    default: heff_nomatch(v_body_241857);
                    }
                    V v_t_241864 = ({ V rv_1 = heff_get_n(v_t_241863, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241860, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241865 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241857)}), v_t_241864});
                    V v_t_241868;
                    switch (heff_tag_of(v_body_241857)) {
                    case TAG_At: {
                      V v_s_241867 = heff_field(v_body_241857, 1);
                      heff_take_n(v_body_241857, 2ULL, 2);
                      v_t_241868 = v_s_241867;
                      break;
                    }
                    default: heff_nomatch(v_body_241857);
                    }
                    V v_t_241869 = ({ V rv_1 = heff_get_n(v_t_241868, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241870 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241856, v_t_241865}), v_t_241869});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241855; V a_2 = v_t_241870; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241855); r_; });
                  }
                }
              }
            }
            case TAG_ETag: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241872 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241874 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam34, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241872));
              {
                V v_field_241876 = v_t_241874.f[1];
                int64_t v_tag_241875 = ((int64_t)v_t_241874.f[0]);
                if ((v_tag_241875 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241877 = v_field_241876;
                  V v_t_241878 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str213), heff_strAppend(heff_dup(v_x_241877), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str214)));
                  V v_t_241879 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str215), heff_strAppend(v_x_241877, v_t_241878));
                  V v_t_241882;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241881 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241882 = v_s_241881;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241879}), v_t_241882});
                } else {
                  heff_drop(v_field_241876);
                  V v_t_241883 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241884 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241883}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241885 = v_t_241884.f[0];
                    V v_field_241886 = v_t_241884.f[1];
                    V v_x_241887 = v_field_241885;
                    V v_y_241888 = v_field_241886;
                    V v_body_241889 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241892;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241891 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241892 = v_s_241891;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241895;
                    switch (heff_tag_of(v_body_241889)) {
                    case TAG_At: {
                      V v_s_241894 = heff_dup(heff_field(v_body_241889, 1));
                      v_t_241895 = v_s_241894;
                      break;
                    }
                    default: heff_nomatch(v_body_241889);
                    }
                    V v_t_241896 = ({ V rv_1 = heff_get_n(v_t_241895, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241892, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241897 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241889)}), v_t_241896});
                    V v_t_241900;
                    switch (heff_tag_of(v_body_241889)) {
                    case TAG_At: {
                      V v_s_241899 = heff_field(v_body_241889, 1);
                      heff_take_n(v_body_241889, 2ULL, 2);
                      v_t_241900 = v_s_241899;
                      break;
                    }
                    default: heff_nomatch(v_body_241889);
                    }
                    V v_t_241901 = ({ V rv_1 = heff_get_n(v_t_241900, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241902 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241888, v_t_241897}), v_t_241901});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241887; V a_2 = v_t_241902; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241887); r_; });
                  }
                }
              }
            }
            case TAG_EInt: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241904 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241906 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam35, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241904));
              {
                V v_field_241908 = v_t_241906.f[1];
                int64_t v_tag_241907 = ((int64_t)v_t_241906.f[0]);
                if ((v_tag_241907 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241909 = v_field_241908;
                  V v_t_241910 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str216), heff_strAppend(heff_dup(v_x_241909), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str217)));
                  V v_t_241911 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str218), heff_strAppend(v_x_241909, v_t_241910));
                  V v_t_241914;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241913 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241914 = v_s_241913;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241911}), v_t_241914});
                } else {
                  heff_drop(v_field_241908);
                  V v_t_241915 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241916 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241915}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241917 = v_t_241916.f[0];
                    V v_field_241918 = v_t_241916.f[1];
                    V v_x_241919 = v_field_241917;
                    V v_y_241920 = v_field_241918;
                    V v_body_241921 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241924;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241923 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241924 = v_s_241923;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241927;
                    switch (heff_tag_of(v_body_241921)) {
                    case TAG_At: {
                      V v_s_241926 = heff_dup(heff_field(v_body_241921, 1));
                      v_t_241927 = v_s_241926;
                      break;
                    }
                    default: heff_nomatch(v_body_241921);
                    }
                    V v_t_241928 = ({ V rv_1 = heff_get_n(v_t_241927, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241924, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241929 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241921)}), v_t_241928});
                    V v_t_241932;
                    switch (heff_tag_of(v_body_241921)) {
                    case TAG_At: {
                      V v_s_241931 = heff_field(v_body_241921, 1);
                      heff_take_n(v_body_241921, 2ULL, 2);
                      v_t_241932 = v_s_241931;
                      break;
                    }
                    default: heff_nomatch(v_body_241921);
                    }
                    V v_t_241933 = ({ V rv_1 = heff_get_n(v_t_241932, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241934 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241920, v_t_241929}), v_t_241933});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241919; V a_2 = v_t_241934; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241919); r_; });
                  }
                }
              }
            }
            case TAG_EFloat: {
              heff_take_na(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241936 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241938 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam36, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241936));
              {
                V v_field_241940 = v_t_241938.f[1];
                int64_t v_tag_241939 = ((int64_t)v_t_241938.f[0]);
                if ((v_tag_241939 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241941 = v_field_241940;
                  V v_t_241942 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str219), heff_strAppend(heff_dup(v_x_241941), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str220)));
                  V v_t_241943 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str221), heff_strAppend(v_x_241941, v_t_241942));
                  V v_t_241946;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241945 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241946 = v_s_241945;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241943}), v_t_241946});
                } else {
                  heff_drop(v_field_241940);
                  V v_t_241947 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241948 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241947}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241949 = v_t_241948.f[0];
                    V v_field_241950 = v_t_241948.f[1];
                    V v_x_241951 = v_field_241949;
                    V v_y_241952 = v_field_241950;
                    V v_body_241953 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241956;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241955 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241956 = v_s_241955;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241959;
                    switch (heff_tag_of(v_body_241953)) {
                    case TAG_At: {
                      V v_s_241958 = heff_dup(heff_field(v_body_241953, 1));
                      v_t_241959 = v_s_241958;
                      break;
                    }
                    default: heff_nomatch(v_body_241953);
                    }
                    V v_t_241960 = ({ V rv_1 = heff_get_n(v_t_241959, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241956, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241961 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241953)}), v_t_241960});
                    V v_t_241964;
                    switch (heff_tag_of(v_body_241953)) {
                    case TAG_At: {
                      V v_s_241963 = heff_field(v_body_241953, 1);
                      heff_take_n(v_body_241953, 2ULL, 2);
                      v_t_241964 = v_s_241963;
                      break;
                    }
                    default: heff_nomatch(v_body_241953);
                    }
                    V v_t_241965 = ({ V rv_1 = heff_get_n(v_t_241964, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241966 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241952, v_t_241961}), v_t_241965});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241951; V a_2 = v_t_241966; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241951); r_; });
                  }
                }
              }
            }
            case TAG_EString: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_241968 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_241970 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam37, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241968));
              {
                V v_field_241972 = v_t_241970.f[1];
                int64_t v_tag_241971 = ((int64_t)v_t_241970.f[0]);
                if ((v_tag_241971 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241973 = v_field_241972;
                  V v_t_241974 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str222), heff_strAppend(heff_dup(v_x_241973), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str223)));
                  V v_t_241975 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str224), heff_strAppend(v_x_241973, v_t_241974));
                  V v_t_241978;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_241977 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_241978 = v_s_241977;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241975}), v_t_241978});
                } else {
                  heff_drop(v_field_241972);
                  V v_t_241979 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241980 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241979}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_241981 = v_t_241980.f[0];
                    V v_field_241982 = v_t_241980.f[1];
                    V v_x_241983 = v_field_241981;
                    V v_y_241984 = v_field_241982;
                    V v_body_241985 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241988;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_241987 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_241988 = v_s_241987;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_241991;
                    switch (heff_tag_of(v_body_241985)) {
                    case TAG_At: {
                      V v_s_241990 = heff_dup(heff_field(v_body_241985, 1));
                      v_t_241991 = v_s_241990;
                      break;
                    }
                    default: heff_nomatch(v_body_241985);
                    }
                    V v_t_241992 = ({ V rv_1 = heff_get_n(v_t_241991, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241988, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241993 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_241985)}), v_t_241992});
                    V v_t_241996;
                    switch (heff_tag_of(v_body_241985)) {
                    case TAG_At: {
                      V v_s_241995 = heff_field(v_body_241985, 1);
                      heff_take_n(v_body_241985, 2ULL, 2);
                      v_t_241996 = v_s_241995;
                      break;
                    }
                    default: heff_nomatch(v_body_241985);
                    }
                    V v_t_241997 = ({ V rv_1 = heff_get_n(v_t_241996, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241998 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241984, v_t_241993}), v_t_241997});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241983; V a_2 = v_t_241998; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241983); r_; });
                  }
                }
              }
            }
            case TAG_EBinary: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242000 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242002 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam38, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242000));
              {
                V v_field_242004 = v_t_242002.f[1];
                int64_t v_tag_242003 = ((int64_t)v_t_242002.f[0]);
                if ((v_tag_242003 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242005 = v_field_242004;
                  V v_t_242006 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str225), heff_strAppend(heff_dup(v_x_242005), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str226)));
                  V v_t_242007 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str227), heff_strAppend(v_x_242005, v_t_242006));
                  V v_t_242010;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242009 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242010 = v_s_242009;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242007}), v_t_242010});
                } else {
                  heff_drop(v_field_242004);
                  V v_t_242011 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242012 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242011}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242013 = v_t_242012.f[0];
                    V v_field_242014 = v_t_242012.f[1];
                    V v_x_242015 = v_field_242013;
                    V v_y_242016 = v_field_242014;
                    V v_body_242017 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242020;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242019 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242020 = v_s_242019;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242023;
                    switch (heff_tag_of(v_body_242017)) {
                    case TAG_At: {
                      V v_s_242022 = heff_dup(heff_field(v_body_242017, 1));
                      v_t_242023 = v_s_242022;
                      break;
                    }
                    default: heff_nomatch(v_body_242017);
                    }
                    V v_t_242024 = ({ V rv_1 = heff_get_n(v_t_242023, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242020, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242025 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242017)}), v_t_242024});
                    V v_t_242028;
                    switch (heff_tag_of(v_body_242017)) {
                    case TAG_At: {
                      V v_s_242027 = heff_field(v_body_242017, 1);
                      heff_take_n(v_body_242017, 2ULL, 2);
                      v_t_242028 = v_s_242027;
                      break;
                    }
                    default: heff_nomatch(v_body_242017);
                    }
                    V v_t_242029 = ({ V rv_1 = heff_get_n(v_t_242028, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242030 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242016, v_t_242025}), v_t_242029});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242015; V a_2 = v_t_242030; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242015); r_; });
                  }
                }
              }
            }
            case TAG_ERune: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242032 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242034 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam39, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242032));
              {
                V v_field_242036 = v_t_242034.f[1];
                int64_t v_tag_242035 = ((int64_t)v_t_242034.f[0]);
                if ((v_tag_242035 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242037 = v_field_242036;
                  V v_t_242038 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str228), heff_strAppend(heff_dup(v_x_242037), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str229)));
                  V v_t_242039 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str230), heff_strAppend(v_x_242037, v_t_242038));
                  V v_t_242042;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242041 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242042 = v_s_242041;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242039}), v_t_242042});
                } else {
                  heff_drop(v_field_242036);
                  V v_t_242043 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242044 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242043}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242045 = v_t_242044.f[0];
                    V v_field_242046 = v_t_242044.f[1];
                    V v_x_242047 = v_field_242045;
                    V v_y_242048 = v_field_242046;
                    V v_body_242049 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242052;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242051 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242052 = v_s_242051;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242055;
                    switch (heff_tag_of(v_body_242049)) {
                    case TAG_At: {
                      V v_s_242054 = heff_dup(heff_field(v_body_242049, 1));
                      v_t_242055 = v_s_242054;
                      break;
                    }
                    default: heff_nomatch(v_body_242049);
                    }
                    V v_t_242056 = ({ V rv_1 = heff_get_n(v_t_242055, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242052, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242057 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242049)}), v_t_242056});
                    V v_t_242060;
                    switch (heff_tag_of(v_body_242049)) {
                    case TAG_At: {
                      V v_s_242059 = heff_field(v_body_242049, 1);
                      heff_take_n(v_body_242049, 2ULL, 2);
                      v_t_242060 = v_s_242059;
                      break;
                    }
                    default: heff_nomatch(v_body_242049);
                    }
                    V v_t_242061 = ({ V rv_1 = heff_get_n(v_t_242060, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242062 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242048, v_t_242057}), v_t_242061});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242047; V a_2 = v_t_242062; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242047); r_; });
                  }
                }
              }
            }
            case TAG_EWord: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242064 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242066 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam40, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242064));
              {
                V v_field_242068 = v_t_242066.f[1];
                int64_t v_tag_242067 = ((int64_t)v_t_242066.f[0]);
                if ((v_tag_242067 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242069 = v_field_242068;
                  V v_t_242070 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str231), heff_strAppend(heff_dup(v_x_242069), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str232)));
                  V v_t_242071 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str233), heff_strAppend(v_x_242069, v_t_242070));
                  V v_t_242074;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242073 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242074 = v_s_242073;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242071}), v_t_242074});
                } else {
                  heff_drop(v_field_242068);
                  V v_t_242075 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242076 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242075}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242077 = v_t_242076.f[0];
                    V v_field_242078 = v_t_242076.f[1];
                    V v_x_242079 = v_field_242077;
                    V v_y_242080 = v_field_242078;
                    V v_body_242081 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242084;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242083 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242084 = v_s_242083;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242087;
                    switch (heff_tag_of(v_body_242081)) {
                    case TAG_At: {
                      V v_s_242086 = heff_dup(heff_field(v_body_242081, 1));
                      v_t_242087 = v_s_242086;
                      break;
                    }
                    default: heff_nomatch(v_body_242081);
                    }
                    V v_t_242088 = ({ V rv_1 = heff_get_n(v_t_242087, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242084, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242089 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242081)}), v_t_242088});
                    V v_t_242092;
                    switch (heff_tag_of(v_body_242081)) {
                    case TAG_At: {
                      V v_s_242091 = heff_field(v_body_242081, 1);
                      heff_take_n(v_body_242081, 2ULL, 2);
                      v_t_242092 = v_s_242091;
                      break;
                    }
                    default: heff_nomatch(v_body_242081);
                    }
                    V v_t_242093 = ({ V rv_1 = heff_get_n(v_t_242092, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242094 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242080, v_t_242089}), v_t_242093});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242079; V a_2 = v_t_242094; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242079); r_; });
                  }
                }
              }
            }
            case TAG_EApp: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242097 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242099 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam41, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242097));
              {
                V v_field_242101 = v_t_242099.f[1];
                int64_t v_tag_242100 = ((int64_t)v_t_242099.f[0]);
                if ((v_tag_242100 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242102 = v_field_242101;
                  V v_t_242103 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str234), heff_strAppend(heff_dup(v_x_242102), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str235)));
                  V v_t_242104 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str236), heff_strAppend(v_x_242102, v_t_242103));
                  V v_t_242107;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242106 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242107 = v_s_242106;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242104}), v_t_242107});
                } else {
                  heff_drop(v_field_242101);
                  V v_t_242108 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242109 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242108}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242110 = v_t_242109.f[0];
                    V v_field_242111 = v_t_242109.f[1];
                    V v_x_242112 = v_field_242110;
                    V v_y_242113 = v_field_242111;
                    V v_body_242114 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242117;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242116 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242117 = v_s_242116;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242120;
                    switch (heff_tag_of(v_body_242114)) {
                    case TAG_At: {
                      V v_s_242119 = heff_dup(heff_field(v_body_242114, 1));
                      v_t_242120 = v_s_242119;
                      break;
                    }
                    default: heff_nomatch(v_body_242114);
                    }
                    V v_t_242121 = ({ V rv_1 = heff_get_n(v_t_242120, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242117, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242122 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242114)}), v_t_242121});
                    V v_t_242125;
                    switch (heff_tag_of(v_body_242114)) {
                    case TAG_At: {
                      V v_s_242124 = heff_field(v_body_242114, 1);
                      heff_take_n(v_body_242114, 2ULL, 2);
                      v_t_242125 = v_s_242124;
                      break;
                    }
                    default: heff_nomatch(v_body_242114);
                    }
                    V v_t_242126 = ({ V rv_1 = heff_get_n(v_t_242125, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242127 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242113, v_t_242122}), v_t_242126});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242112; V a_2 = v_t_242127; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242112); r_; });
                  }
                }
              }
            }
            case TAG_EProject: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242129 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242131 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam42, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242129));
              {
                V v_field_242133 = v_t_242131.f[1];
                int64_t v_tag_242132 = ((int64_t)v_t_242131.f[0]);
                if ((v_tag_242132 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242134 = v_field_242133;
                  V v_t_242135 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str237), heff_strAppend(heff_dup(v_x_242134), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str238)));
                  V v_t_242136 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str239), heff_strAppend(v_x_242134, v_t_242135));
                  V v_t_242139;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242138 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242139 = v_s_242138;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242136}), v_t_242139});
                } else {
                  heff_drop(v_field_242133);
                  V v_t_242140 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242141 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242140}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242142 = v_t_242141.f[0];
                    V v_field_242143 = v_t_242141.f[1];
                    V v_x_242144 = v_field_242142;
                    V v_y_242145 = v_field_242143;
                    V v_body_242146 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242149;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242148 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242149 = v_s_242148;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242152;
                    switch (heff_tag_of(v_body_242146)) {
                    case TAG_At: {
                      V v_s_242151 = heff_dup(heff_field(v_body_242146, 1));
                      v_t_242152 = v_s_242151;
                      break;
                    }
                    default: heff_nomatch(v_body_242146);
                    }
                    V v_t_242153 = ({ V rv_1 = heff_get_n(v_t_242152, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242149, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242154 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242146)}), v_t_242153});
                    V v_t_242157;
                    switch (heff_tag_of(v_body_242146)) {
                    case TAG_At: {
                      V v_s_242156 = heff_field(v_body_242146, 1);
                      heff_take_n(v_body_242146, 2ULL, 2);
                      v_t_242157 = v_s_242156;
                      break;
                    }
                    default: heff_nomatch(v_body_242146);
                    }
                    V v_t_242158 = ({ V rv_1 = heff_get_n(v_t_242157, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242159 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242145, v_t_242154}), v_t_242158});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242144; V a_2 = v_t_242159; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242144); r_; });
                  }
                }
              }
            }
            case TAG_ENamed: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242162 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242164 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam43, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242162));
              {
                V v_field_242166 = v_t_242164.f[1];
                int64_t v_tag_242165 = ((int64_t)v_t_242164.f[0]);
                if ((v_tag_242165 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242167 = v_field_242166;
                  V v_t_242168 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str240), heff_strAppend(heff_dup(v_x_242167), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str241)));
                  V v_t_242169 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str242), heff_strAppend(v_x_242167, v_t_242168));
                  V v_t_242172;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242171 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242172 = v_s_242171;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242169}), v_t_242172});
                } else {
                  heff_drop(v_field_242166);
                  V v_t_242173 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242174 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242173}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242175 = v_t_242174.f[0];
                    V v_field_242176 = v_t_242174.f[1];
                    V v_x_242177 = v_field_242175;
                    V v_y_242178 = v_field_242176;
                    V v_body_242179 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242182;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242181 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242182 = v_s_242181;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242185;
                    switch (heff_tag_of(v_body_242179)) {
                    case TAG_At: {
                      V v_s_242184 = heff_dup(heff_field(v_body_242179, 1));
                      v_t_242185 = v_s_242184;
                      break;
                    }
                    default: heff_nomatch(v_body_242179);
                    }
                    V v_t_242186 = ({ V rv_1 = heff_get_n(v_t_242185, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242182, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242187 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242179)}), v_t_242186});
                    V v_t_242190;
                    switch (heff_tag_of(v_body_242179)) {
                    case TAG_At: {
                      V v_s_242189 = heff_field(v_body_242179, 1);
                      heff_take_n(v_body_242179, 2ULL, 2);
                      v_t_242190 = v_s_242189;
                      break;
                    }
                    default: heff_nomatch(v_body_242179);
                    }
                    V v_t_242191 = ({ V rv_1 = heff_get_n(v_t_242190, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242192 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242178, v_t_242187}), v_t_242191});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242177; V a_2 = v_t_242192; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242177); r_; });
                  }
                }
              }
            }
            case TAG_EPi: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242195 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242197 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam44, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242195));
              {
                V v_field_242199 = v_t_242197.f[1];
                int64_t v_tag_242198 = ((int64_t)v_t_242197.f[0]);
                if ((v_tag_242198 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242200 = v_field_242199;
                  V v_t_242201 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str243), heff_strAppend(heff_dup(v_x_242200), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str244)));
                  V v_t_242202 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str245), heff_strAppend(v_x_242200, v_t_242201));
                  V v_t_242205;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242204 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242205 = v_s_242204;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242202}), v_t_242205});
                } else {
                  heff_drop(v_field_242199);
                  V v_t_242206 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242207 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242206}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242208 = v_t_242207.f[0];
                    V v_field_242209 = v_t_242207.f[1];
                    V v_x_242210 = v_field_242208;
                    V v_y_242211 = v_field_242209;
                    V v_body_242212 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242215;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242214 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242215 = v_s_242214;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242218;
                    switch (heff_tag_of(v_body_242212)) {
                    case TAG_At: {
                      V v_s_242217 = heff_dup(heff_field(v_body_242212, 1));
                      v_t_242218 = v_s_242217;
                      break;
                    }
                    default: heff_nomatch(v_body_242212);
                    }
                    V v_t_242219 = ({ V rv_1 = heff_get_n(v_t_242218, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242215, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242220 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242212)}), v_t_242219});
                    V v_t_242223;
                    switch (heff_tag_of(v_body_242212)) {
                    case TAG_At: {
                      V v_s_242222 = heff_field(v_body_242212, 1);
                      heff_take_n(v_body_242212, 2ULL, 2);
                      v_t_242223 = v_s_242222;
                      break;
                    }
                    default: heff_nomatch(v_body_242212);
                    }
                    V v_t_242224 = ({ V rv_1 = heff_get_n(v_t_242223, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242225 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242211, v_t_242220}), v_t_242224});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242210; V a_2 = v_t_242225; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242210); r_; });
                  }
                }
              }
            }
            case TAG_ELam: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242228 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242230 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam45, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242228));
              {
                V v_field_242232 = v_t_242230.f[1];
                int64_t v_tag_242231 = ((int64_t)v_t_242230.f[0]);
                if ((v_tag_242231 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242233 = v_field_242232;
                  V v_t_242234 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str246), heff_strAppend(heff_dup(v_x_242233), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str247)));
                  V v_t_242235 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str248), heff_strAppend(v_x_242233, v_t_242234));
                  V v_t_242238;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242237 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242238 = v_s_242237;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242235}), v_t_242238});
                } else {
                  heff_drop(v_field_242232);
                  V v_t_242239 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242240 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242239}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242241 = v_t_242240.f[0];
                    V v_field_242242 = v_t_242240.f[1];
                    V v_x_242243 = v_field_242241;
                    V v_y_242244 = v_field_242242;
                    V v_body_242245 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242248;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242247 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242248 = v_s_242247;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242251;
                    switch (heff_tag_of(v_body_242245)) {
                    case TAG_At: {
                      V v_s_242250 = heff_dup(heff_field(v_body_242245, 1));
                      v_t_242251 = v_s_242250;
                      break;
                    }
                    default: heff_nomatch(v_body_242245);
                    }
                    V v_t_242252 = ({ V rv_1 = heff_get_n(v_t_242251, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242253 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242245)}), v_t_242252});
                    V v_t_242256;
                    switch (heff_tag_of(v_body_242245)) {
                    case TAG_At: {
                      V v_s_242255 = heff_field(v_body_242245, 1);
                      heff_take_n(v_body_242245, 2ULL, 2);
                      v_t_242256 = v_s_242255;
                      break;
                    }
                    default: heff_nomatch(v_body_242245);
                    }
                    V v_t_242257 = ({ V rv_1 = heff_get_n(v_t_242256, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242258 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242244, v_t_242253}), v_t_242257});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242243; V a_2 = v_t_242258; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242243); r_; });
                  }
                }
              }
            }
            case TAG_EAnn: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242261 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242263 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam46, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242261));
              {
                V v_field_242265 = v_t_242263.f[1];
                int64_t v_tag_242264 = ((int64_t)v_t_242263.f[0]);
                if ((v_tag_242264 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242266 = v_field_242265;
                  V v_t_242267 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str249), heff_strAppend(heff_dup(v_x_242266), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str250)));
                  V v_t_242268 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str251), heff_strAppend(v_x_242266, v_t_242267));
                  V v_t_242271;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242270 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242271 = v_s_242270;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242268}), v_t_242271});
                } else {
                  heff_drop(v_field_242265);
                  V v_t_242272 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242273 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242272}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242274 = v_t_242273.f[0];
                    V v_field_242275 = v_t_242273.f[1];
                    V v_x_242276 = v_field_242274;
                    V v_y_242277 = v_field_242275;
                    V v_body_242278 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242281;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242280 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242281 = v_s_242280;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242284;
                    switch (heff_tag_of(v_body_242278)) {
                    case TAG_At: {
                      V v_s_242283 = heff_dup(heff_field(v_body_242278, 1));
                      v_t_242284 = v_s_242283;
                      break;
                    }
                    default: heff_nomatch(v_body_242278);
                    }
                    V v_t_242285 = ({ V rv_1 = heff_get_n(v_t_242284, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242281, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242286 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242278)}), v_t_242285});
                    V v_t_242289;
                    switch (heff_tag_of(v_body_242278)) {
                    case TAG_At: {
                      V v_s_242288 = heff_field(v_body_242278, 1);
                      heff_take_n(v_body_242278, 2ULL, 2);
                      v_t_242289 = v_s_242288;
                      break;
                    }
                    default: heff_nomatch(v_body_242278);
                    }
                    V v_t_242290 = ({ V rv_1 = heff_get_n(v_t_242289, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242291 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242277, v_t_242286}), v_t_242290});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242276; V a_2 = v_t_242291; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242276); r_; });
                  }
                }
              }
            }
            case TAG_ESpec: {
              heff_take_n(v_x312111_241805, 0ULL, 4);
              heff_drop(v_fsp_241806);
              V v_xs_242296 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242298 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam47, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242296));
              {
                V v_field_242300 = v_t_242298.f[1];
                int64_t v_tag_242299 = ((int64_t)v_t_242298.f[0]);
                if ((v_tag_242299 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242301 = v_field_242300;
                  V v_t_242302 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str252), heff_strAppend(heff_dup(v_x_242301), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str253)));
                  V v_t_242303 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str254), heff_strAppend(v_x_242301, v_t_242302));
                  V v_t_242306;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242305 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242306 = v_s_242305;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242303}), v_t_242306});
                } else {
                  heff_drop(v_field_242300);
                  V v_t_242307 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242308 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242307}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242309 = v_t_242308.f[0];
                    V v_field_242310 = v_t_242308.f[1];
                    V v_x_242311 = v_field_242309;
                    V v_y_242312 = v_field_242310;
                    V v_body_242313 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242316;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242315 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242316 = v_s_242315;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242319;
                    switch (heff_tag_of(v_body_242313)) {
                    case TAG_At: {
                      V v_s_242318 = heff_dup(heff_field(v_body_242313, 1));
                      v_t_242319 = v_s_242318;
                      break;
                    }
                    default: heff_nomatch(v_body_242313);
                    }
                    V v_t_242320 = ({ V rv_1 = heff_get_n(v_t_242319, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242316, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242321 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242313)}), v_t_242320});
                    V v_t_242324;
                    switch (heff_tag_of(v_body_242313)) {
                    case TAG_At: {
                      V v_s_242323 = heff_field(v_body_242313, 1);
                      heff_take_n(v_body_242313, 2ULL, 2);
                      v_t_242324 = v_s_242323;
                      break;
                    }
                    default: heff_nomatch(v_body_242313);
                    }
                    V v_t_242325 = ({ V rv_1 = heff_get_n(v_t_242324, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242326 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242312, v_t_242321}), v_t_242325});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242311; V a_2 = v_t_242326; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242311); r_; });
                  }
                }
              }
            }
            case TAG_ESig: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242328 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242330 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam48, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242328));
              {
                V v_field_242332 = v_t_242330.f[1];
                int64_t v_tag_242331 = ((int64_t)v_t_242330.f[0]);
                if ((v_tag_242331 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242333 = v_field_242332;
                  V v_t_242334 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str255), heff_strAppend(heff_dup(v_x_242333), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str256)));
                  V v_t_242335 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str257), heff_strAppend(v_x_242333, v_t_242334));
                  V v_t_242338;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242337 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242338 = v_s_242337;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242335}), v_t_242338});
                } else {
                  heff_drop(v_field_242332);
                  V v_t_242339 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242340 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242339}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242341 = v_t_242340.f[0];
                    V v_field_242342 = v_t_242340.f[1];
                    V v_x_242343 = v_field_242341;
                    V v_y_242344 = v_field_242342;
                    V v_body_242345 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242348;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242347 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242348 = v_s_242347;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242351;
                    switch (heff_tag_of(v_body_242345)) {
                    case TAG_At: {
                      V v_s_242350 = heff_dup(heff_field(v_body_242345, 1));
                      v_t_242351 = v_s_242350;
                      break;
                    }
                    default: heff_nomatch(v_body_242345);
                    }
                    V v_t_242352 = ({ V rv_1 = heff_get_n(v_t_242351, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242348, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242353 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242345)}), v_t_242352});
                    V v_t_242356;
                    switch (heff_tag_of(v_body_242345)) {
                    case TAG_At: {
                      V v_s_242355 = heff_field(v_body_242345, 1);
                      heff_take_n(v_body_242345, 2ULL, 2);
                      v_t_242356 = v_s_242355;
                      break;
                    }
                    default: heff_nomatch(v_body_242345);
                    }
                    V v_t_242357 = ({ V rv_1 = heff_get_n(v_t_242356, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242358 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242344, v_t_242353}), v_t_242357});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242343; V a_2 = v_t_242358; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242343); r_; });
                  }
                }
              }
            }
            case TAG_ESum: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242360 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242362 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam49, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242360));
              {
                V v_field_242364 = v_t_242362.f[1];
                int64_t v_tag_242363 = ((int64_t)v_t_242362.f[0]);
                if ((v_tag_242363 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242365 = v_field_242364;
                  V v_t_242366 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str258), heff_strAppend(heff_dup(v_x_242365), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str259)));
                  V v_t_242367 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str260), heff_strAppend(v_x_242365, v_t_242366));
                  V v_t_242370;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242369 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242370 = v_s_242369;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242367}), v_t_242370});
                } else {
                  heff_drop(v_field_242364);
                  V v_t_242371 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242372 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242371}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242373 = v_t_242372.f[0];
                    V v_field_242374 = v_t_242372.f[1];
                    V v_x_242375 = v_field_242373;
                    V v_y_242376 = v_field_242374;
                    V v_body_242377 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242380;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242379 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242380 = v_s_242379;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242383;
                    switch (heff_tag_of(v_body_242377)) {
                    case TAG_At: {
                      V v_s_242382 = heff_dup(heff_field(v_body_242377, 1));
                      v_t_242383 = v_s_242382;
                      break;
                    }
                    default: heff_nomatch(v_body_242377);
                    }
                    V v_t_242384 = ({ V rv_1 = heff_get_n(v_t_242383, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242380, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242385 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242377)}), v_t_242384});
                    V v_t_242388;
                    switch (heff_tag_of(v_body_242377)) {
                    case TAG_At: {
                      V v_s_242387 = heff_field(v_body_242377, 1);
                      heff_take_n(v_body_242377, 2ULL, 2);
                      v_t_242388 = v_s_242387;
                      break;
                    }
                    default: heff_nomatch(v_body_242377);
                    }
                    V v_t_242389 = ({ V rv_1 = heff_get_n(v_t_242388, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242390 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242376, v_t_242385}), v_t_242389});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242375; V a_2 = v_t_242390; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242375); r_; });
                  }
                }
              }
            }
            case TAG_EStruct: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242392 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242394 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam50, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242392));
              {
                V v_field_242396 = v_t_242394.f[1];
                int64_t v_tag_242395 = ((int64_t)v_t_242394.f[0]);
                if ((v_tag_242395 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242397 = v_field_242396;
                  V v_t_242398 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str261), heff_strAppend(heff_dup(v_x_242397), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str262)));
                  V v_t_242399 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str263), heff_strAppend(v_x_242397, v_t_242398));
                  V v_t_242402;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242401 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242402 = v_s_242401;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242399}), v_t_242402});
                } else {
                  heff_drop(v_field_242396);
                  V v_t_242403 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242404 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242403}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242405 = v_t_242404.f[0];
                    V v_field_242406 = v_t_242404.f[1];
                    V v_x_242407 = v_field_242405;
                    V v_y_242408 = v_field_242406;
                    V v_body_242409 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242412;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242411 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242412 = v_s_242411;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242415;
                    switch (heff_tag_of(v_body_242409)) {
                    case TAG_At: {
                      V v_s_242414 = heff_dup(heff_field(v_body_242409, 1));
                      v_t_242415 = v_s_242414;
                      break;
                    }
                    default: heff_nomatch(v_body_242409);
                    }
                    V v_t_242416 = ({ V rv_1 = heff_get_n(v_t_242415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242417 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242409)}), v_t_242416});
                    V v_t_242420;
                    switch (heff_tag_of(v_body_242409)) {
                    case TAG_At: {
                      V v_s_242419 = heff_field(v_body_242409, 1);
                      heff_take_n(v_body_242409, 2ULL, 2);
                      v_t_242420 = v_s_242419;
                      break;
                    }
                    default: heff_nomatch(v_body_242409);
                    }
                    V v_t_242421 = ({ V rv_1 = heff_get_n(v_t_242420, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242422 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242408, v_t_242417}), v_t_242421});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242407; V a_2 = v_t_242422; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242407); r_; });
                  }
                }
              }
            }
            case TAG_EUpdate: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242425 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242427 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam51, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242425));
              {
                V v_field_242429 = v_t_242427.f[1];
                int64_t v_tag_242428 = ((int64_t)v_t_242427.f[0]);
                if ((v_tag_242428 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242430 = v_field_242429;
                  V v_t_242431 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str264), heff_strAppend(heff_dup(v_x_242430), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str265)));
                  V v_t_242432 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str266), heff_strAppend(v_x_242430, v_t_242431));
                  V v_t_242435;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242434 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242435 = v_s_242434;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242432}), v_t_242435});
                } else {
                  heff_drop(v_field_242429);
                  V v_t_242436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242436}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242438 = v_t_242437.f[0];
                    V v_field_242439 = v_t_242437.f[1];
                    V v_x_242440 = v_field_242438;
                    V v_y_242441 = v_field_242439;
                    V v_body_242442 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242445;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242444 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242445 = v_s_242444;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242448;
                    switch (heff_tag_of(v_body_242442)) {
                    case TAG_At: {
                      V v_s_242447 = heff_dup(heff_field(v_body_242442, 1));
                      v_t_242448 = v_s_242447;
                      break;
                    }
                    default: heff_nomatch(v_body_242442);
                    }
                    V v_t_242449 = ({ V rv_1 = heff_get_n(v_t_242448, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242445, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242450 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242442)}), v_t_242449});
                    V v_t_242453;
                    switch (heff_tag_of(v_body_242442)) {
                    case TAG_At: {
                      V v_s_242452 = heff_field(v_body_242442, 1);
                      heff_take_n(v_body_242442, 2ULL, 2);
                      v_t_242453 = v_s_242452;
                      break;
                    }
                    default: heff_nomatch(v_body_242442);
                    }
                    V v_t_242454 = ({ V rv_1 = heff_get_n(v_t_242453, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242455 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242441, v_t_242450}), v_t_242454});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242440; V a_2 = v_t_242455; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242440); r_; });
                  }
                }
              }
            }
            case TAG_EMatch: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242458 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242460 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam52, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242458));
              {
                V v_field_242462 = v_t_242460.f[1];
                int64_t v_tag_242461 = ((int64_t)v_t_242460.f[0]);
                if ((v_tag_242461 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242463 = v_field_242462;
                  V v_t_242464 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str267), heff_strAppend(heff_dup(v_x_242463), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str268)));
                  V v_t_242465 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str269), heff_strAppend(v_x_242463, v_t_242464));
                  V v_t_242468;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242467 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242468 = v_s_242467;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242465}), v_t_242468});
                } else {
                  heff_drop(v_field_242462);
                  V v_t_242469 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242470 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242469}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242471 = v_t_242470.f[0];
                    V v_field_242472 = v_t_242470.f[1];
                    V v_x_242473 = v_field_242471;
                    V v_y_242474 = v_field_242472;
                    V v_body_242475 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242478;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242477 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242478 = v_s_242477;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242481;
                    switch (heff_tag_of(v_body_242475)) {
                    case TAG_At: {
                      V v_s_242480 = heff_dup(heff_field(v_body_242475, 1));
                      v_t_242481 = v_s_242480;
                      break;
                    }
                    default: heff_nomatch(v_body_242475);
                    }
                    V v_t_242482 = ({ V rv_1 = heff_get_n(v_t_242481, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242478, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242483 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242475)}), v_t_242482});
                    V v_t_242486;
                    switch (heff_tag_of(v_body_242475)) {
                    case TAG_At: {
                      V v_s_242485 = heff_field(v_body_242475, 1);
                      heff_take_n(v_body_242475, 2ULL, 2);
                      v_t_242486 = v_s_242485;
                      break;
                    }
                    default: heff_nomatch(v_body_242475);
                    }
                    V v_t_242487 = ({ V rv_1 = heff_get_n(v_t_242486, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242488 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242474, v_t_242483}), v_t_242487});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242473; V a_2 = v_t_242488; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242473); r_; });
                  }
                }
              }
            }
            case TAG_ELetIn: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242491 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242493 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam53, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242491));
              {
                V v_field_242495 = v_t_242493.f[1];
                int64_t v_tag_242494 = ((int64_t)v_t_242493.f[0]);
                if ((v_tag_242494 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242496 = v_field_242495;
                  V v_t_242497 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str270), heff_strAppend(heff_dup(v_x_242496), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str271)));
                  V v_t_242498 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str272), heff_strAppend(v_x_242496, v_t_242497));
                  V v_t_242501;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242500 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242501 = v_s_242500;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242498}), v_t_242501});
                } else {
                  heff_drop(v_field_242495);
                  V v_t_242502 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242503 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242502}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242504 = v_t_242503.f[0];
                    V v_field_242505 = v_t_242503.f[1];
                    V v_x_242506 = v_field_242504;
                    V v_y_242507 = v_field_242505;
                    V v_body_242508 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242511;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242510 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242511 = v_s_242510;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242514;
                    switch (heff_tag_of(v_body_242508)) {
                    case TAG_At: {
                      V v_s_242513 = heff_dup(heff_field(v_body_242508, 1));
                      v_t_242514 = v_s_242513;
                      break;
                    }
                    default: heff_nomatch(v_body_242508);
                    }
                    V v_t_242515 = ({ V rv_1 = heff_get_n(v_t_242514, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242511, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242516 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242508)}), v_t_242515});
                    V v_t_242519;
                    switch (heff_tag_of(v_body_242508)) {
                    case TAG_At: {
                      V v_s_242518 = heff_field(v_body_242508, 1);
                      heff_take_n(v_body_242508, 2ULL, 2);
                      v_t_242519 = v_s_242518;
                      break;
                    }
                    default: heff_nomatch(v_body_242508);
                    }
                    V v_t_242520 = ({ V rv_1 = heff_get_n(v_t_242519, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242521 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242507, v_t_242516}), v_t_242520});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242506; V a_2 = v_t_242521; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242506); r_; });
                  }
                }
              }
            }
            case TAG_EDo: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242523 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242525 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam54, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242523));
              {
                V v_field_242527 = v_t_242525.f[1];
                int64_t v_tag_242526 = ((int64_t)v_t_242525.f[0]);
                if ((v_tag_242526 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242528 = v_field_242527;
                  V v_t_242529 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str273), heff_strAppend(heff_dup(v_x_242528), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str274)));
                  V v_t_242530 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str275), heff_strAppend(v_x_242528, v_t_242529));
                  V v_t_242533;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242532 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242533 = v_s_242532;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242530}), v_t_242533});
                } else {
                  heff_drop(v_field_242527);
                  V v_t_242534 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242535 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242534}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242536 = v_t_242535.f[0];
                    V v_field_242537 = v_t_242535.f[1];
                    V v_x_242538 = v_field_242536;
                    V v_y_242539 = v_field_242537;
                    V v_body_242540 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242543;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242542 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242543 = v_s_242542;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242546;
                    switch (heff_tag_of(v_body_242540)) {
                    case TAG_At: {
                      V v_s_242545 = heff_dup(heff_field(v_body_242540, 1));
                      v_t_242546 = v_s_242545;
                      break;
                    }
                    default: heff_nomatch(v_body_242540);
                    }
                    V v_t_242547 = ({ V rv_1 = heff_get_n(v_t_242546, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242543, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242548 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242540)}), v_t_242547});
                    V v_t_242551;
                    switch (heff_tag_of(v_body_242540)) {
                    case TAG_At: {
                      V v_s_242550 = heff_field(v_body_242540, 1);
                      heff_take_n(v_body_242540, 2ULL, 2);
                      v_t_242551 = v_s_242550;
                      break;
                    }
                    default: heff_nomatch(v_body_242540);
                    }
                    V v_t_242552 = ({ V rv_1 = heff_get_n(v_t_242551, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242553 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242539, v_t_242548}), v_t_242552});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242538; V a_2 = v_t_242553; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242538); r_; });
                  }
                }
              }
            }
            case TAG_ELocal: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242556 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242558 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam55, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242556));
              {
                V v_field_242560 = v_t_242558.f[1];
                int64_t v_tag_242559 = ((int64_t)v_t_242558.f[0]);
                if ((v_tag_242559 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242561 = v_field_242560;
                  V v_t_242562 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str276), heff_strAppend(heff_dup(v_x_242561), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str277)));
                  V v_t_242563 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str278), heff_strAppend(v_x_242561, v_t_242562));
                  V v_t_242566;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242565 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242566 = v_s_242565;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242563}), v_t_242566});
                } else {
                  heff_drop(v_field_242560);
                  V v_t_242567 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242568 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242567}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242569 = v_t_242568.f[0];
                    V v_field_242570 = v_t_242568.f[1];
                    V v_x_242571 = v_field_242569;
                    V v_y_242572 = v_field_242570;
                    V v_body_242573 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242576;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242575 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242576 = v_s_242575;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242579;
                    switch (heff_tag_of(v_body_242573)) {
                    case TAG_At: {
                      V v_s_242578 = heff_dup(heff_field(v_body_242573, 1));
                      v_t_242579 = v_s_242578;
                      break;
                    }
                    default: heff_nomatch(v_body_242573);
                    }
                    V v_t_242580 = ({ V rv_1 = heff_get_n(v_t_242579, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242576, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242581 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242573)}), v_t_242580});
                    V v_t_242584;
                    switch (heff_tag_of(v_body_242573)) {
                    case TAG_At: {
                      V v_s_242583 = heff_field(v_body_242573, 1);
                      heff_take_n(v_body_242573, 2ULL, 2);
                      v_t_242584 = v_s_242583;
                      break;
                    }
                    default: heff_nomatch(v_body_242573);
                    }
                    V v_t_242585 = ({ V rv_1 = heff_get_n(v_t_242584, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242586 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242572, v_t_242581}), v_t_242585});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242571; V a_2 = v_t_242586; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242571); r_; });
                  }
                }
              }
            }
            case TAG_EInvalid: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242588 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242590 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam56, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242588));
              {
                V v_field_242592 = v_t_242590.f[1];
                int64_t v_tag_242591 = ((int64_t)v_t_242590.f[0]);
                if ((v_tag_242591 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242593 = v_field_242592;
                  V v_t_242594 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str279), heff_strAppend(heff_dup(v_x_242593), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str280)));
                  V v_t_242595 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str281), heff_strAppend(v_x_242593, v_t_242594));
                  V v_t_242598;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242597 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242598 = v_s_242597;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242595}), v_t_242598});
                } else {
                  heff_drop(v_field_242592);
                  V v_t_242599 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242600 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242599}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242601 = v_t_242600.f[0];
                    V v_field_242602 = v_t_242600.f[1];
                    V v_x_242603 = v_field_242601;
                    V v_y_242604 = v_field_242602;
                    V v_body_242605 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242608;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242607 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242608 = v_s_242607;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242611;
                    switch (heff_tag_of(v_body_242605)) {
                    case TAG_At: {
                      V v_s_242610 = heff_dup(heff_field(v_body_242605, 1));
                      v_t_242611 = v_s_242610;
                      break;
                    }
                    default: heff_nomatch(v_body_242605);
                    }
                    V v_t_242612 = ({ V rv_1 = heff_get_n(v_t_242611, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242608, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242613 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242605)}), v_t_242612});
                    V v_t_242616;
                    switch (heff_tag_of(v_body_242605)) {
                    case TAG_At: {
                      V v_s_242615 = heff_field(v_body_242605, 1);
                      heff_take_n(v_body_242605, 2ULL, 2);
                      v_t_242616 = v_s_242615;
                      break;
                    }
                    default: heff_nomatch(v_body_242605);
                    }
                    V v_t_242617 = ({ V rv_1 = heff_get_n(v_t_242616, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242618 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242604, v_t_242613}), v_t_242617});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242603; V a_2 = v_t_242618; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242603); r_; });
                  }
                }
              }
            }
            case TAG_EAssign: {
              heff_take_n(v_x312111_241805, 0ULL, 3);
              heff_drop(v_fsp_241806);
              V v_xs_242622 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242624 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam57, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242622));
              {
                V v_field_242626 = v_t_242624.f[1];
                int64_t v_tag_242625 = ((int64_t)v_t_242624.f[0]);
                if ((v_tag_242625 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242627 = v_field_242626;
                  V v_t_242628 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str282), heff_strAppend(heff_dup(v_x_242627), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str283)));
                  V v_t_242629 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str284), heff_strAppend(v_x_242627, v_t_242628));
                  V v_t_242632;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242631 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242632 = v_s_242631;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242629}), v_t_242632});
                } else {
                  heff_drop(v_field_242626);
                  V v_t_242633 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242634 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242633}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242635 = v_t_242634.f[0];
                    V v_field_242636 = v_t_242634.f[1];
                    V v_x_242637 = v_field_242635;
                    V v_y_242638 = v_field_242636;
                    V v_body_242639 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242642;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242641 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242642 = v_s_242641;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242645;
                    switch (heff_tag_of(v_body_242639)) {
                    case TAG_At: {
                      V v_s_242644 = heff_dup(heff_field(v_body_242639, 1));
                      v_t_242645 = v_s_242644;
                      break;
                    }
                    default: heff_nomatch(v_body_242639);
                    }
                    V v_t_242646 = ({ V rv_1 = heff_get_n(v_t_242645, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242642, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242647 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242639)}), v_t_242646});
                    V v_t_242650;
                    switch (heff_tag_of(v_body_242639)) {
                    case TAG_At: {
                      V v_s_242649 = heff_field(v_body_242639, 1);
                      heff_take_n(v_body_242639, 2ULL, 2);
                      v_t_242650 = v_s_242649;
                      break;
                    }
                    default: heff_nomatch(v_body_242639);
                    }
                    V v_t_242651 = ({ V rv_1 = heff_get_n(v_t_242650, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242652 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242638, v_t_242647}), v_t_242651});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242637; V a_2 = v_t_242652; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242637); r_; });
                  }
                }
              }
            }
            case TAG_EWhile: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242655 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242657 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam58, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242655));
              {
                V v_field_242659 = v_t_242657.f[1];
                int64_t v_tag_242658 = ((int64_t)v_t_242657.f[0]);
                if ((v_tag_242658 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242660 = v_field_242659;
                  V v_t_242661 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str285), heff_strAppend(heff_dup(v_x_242660), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str286)));
                  V v_t_242662 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str287), heff_strAppend(v_x_242660, v_t_242661));
                  V v_t_242665;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242664 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242665 = v_s_242664;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242662}), v_t_242665});
                } else {
                  heff_drop(v_field_242659);
                  V v_t_242666 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242667 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242666}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242668 = v_t_242667.f[0];
                    V v_field_242669 = v_t_242667.f[1];
                    V v_x_242670 = v_field_242668;
                    V v_y_242671 = v_field_242669;
                    V v_body_242672 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242675;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242674 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242675 = v_s_242674;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242678;
                    switch (heff_tag_of(v_body_242672)) {
                    case TAG_At: {
                      V v_s_242677 = heff_dup(heff_field(v_body_242672, 1));
                      v_t_242678 = v_s_242677;
                      break;
                    }
                    default: heff_nomatch(v_body_242672);
                    }
                    V v_t_242679 = ({ V rv_1 = heff_get_n(v_t_242678, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242675, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242680 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242672)}), v_t_242679});
                    V v_t_242683;
                    switch (heff_tag_of(v_body_242672)) {
                    case TAG_At: {
                      V v_s_242682 = heff_field(v_body_242672, 1);
                      heff_take_n(v_body_242672, 2ULL, 2);
                      v_t_242683 = v_s_242682;
                      break;
                    }
                    default: heff_nomatch(v_body_242672);
                    }
                    V v_t_242684 = ({ V rv_1 = heff_get_n(v_t_242683, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242685 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242671, v_t_242680}), v_t_242684});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242670; V a_2 = v_t_242685; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242670); r_; });
                  }
                }
              }
            }
            case TAG_EFor: {
              V v_q_242686 = heff_field(v_x312111_241805, 0);
              V v_c_242687 = heff_field(v_x312111_241805, 1);
              V v_body_242688 = heff_field(v_x312111_241805, 2);
              heff_take_n(v_x312111_241805, 7ULL, 3);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31211_241804_24At, 2);
              V v_xs_242689 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31_245_24StmtLet, heff_dup(v_p_24760)));
              HeffT2 v_t_242691 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam59, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242689));
              {
                V v_field_242693 = v_t_242691.f[1];
                int64_t v_tag_242692 = ((int64_t)v_t_242691.f[0]);
                if ((v_tag_242692 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop(v_fsp_241806);
                  heff_drop(v_q_242686);
                  heff_drop(v_c_242687);
                  heff_drop(v_body_242688);
                  V v_x_242694 = v_field_242693;
                  V v_t_242695 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str288), heff_strAppend(heff_dup(v_x_242694), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str289)));
                  V v_t_242696 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str290), heff_strAppend(v_x_242694, v_t_242695));
                  V v_t_242699;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242698 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242699 = v_s_242698;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242696}), v_t_242699});
                } else {
                  heff_drop(v_field_242693);
                  V v_t_242700 = (g_heff_2esyntax_2epresyntax_2egathered(v_p_24760, v_fsp_241806, v_q_242686, v_c_242687, v_body_242688));
                  V v_t_242701 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24At, v_t_242700, v_rest_243));
                  return heff_tail(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_t_242701, v_end_244});
                }
              }
            }
            case TAG_EIfThen: {
              heff_take_n(v_x312111_241805, 0ULL, 2);
              heff_drop(v_fsp_241806);
              V v_xs_242704 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242706 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam60, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242704));
              {
                V v_field_242708 = v_t_242706.f[1];
                int64_t v_tag_242707 = ((int64_t)v_t_242706.f[0]);
                if ((v_tag_242707 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242709 = v_field_242708;
                  V v_t_242710 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str291), heff_strAppend(heff_dup(v_x_242709), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str292)));
                  V v_t_242711 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str293), heff_strAppend(v_x_242709, v_t_242710));
                  V v_t_242714;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242713 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242714 = v_s_242713;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242711}), v_t_242714});
                } else {
                  heff_drop(v_field_242708);
                  V v_t_242715 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242716 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242715}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242717 = v_t_242716.f[0];
                    V v_field_242718 = v_t_242716.f[1];
                    V v_x_242719 = v_field_242717;
                    V v_y_242720 = v_field_242718;
                    V v_body_242721 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242724;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242723 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242724 = v_s_242723;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242727;
                    switch (heff_tag_of(v_body_242721)) {
                    case TAG_At: {
                      V v_s_242726 = heff_dup(heff_field(v_body_242721, 1));
                      v_t_242727 = v_s_242726;
                      break;
                    }
                    default: heff_nomatch(v_body_242721);
                    }
                    V v_t_242728 = ({ V rv_1 = heff_get_n(v_t_242727, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242724, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242729 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242721)}), v_t_242728});
                    V v_t_242732;
                    switch (heff_tag_of(v_body_242721)) {
                    case TAG_At: {
                      V v_s_242731 = heff_field(v_body_242721, 1);
                      heff_take_n(v_body_242721, 2ULL, 2);
                      v_t_242732 = v_s_242731;
                      break;
                    }
                    default: heff_nomatch(v_body_242721);
                    }
                    V v_t_242733 = ({ V rv_1 = heff_get_n(v_t_242732, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242734 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242720, v_t_242729}), v_t_242733});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242719; V a_2 = v_t_242734; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242719); r_; });
                  }
                }
              }
            }
            case TAG_EBreak: {
              heff_drop(v_fsp_241806);
              V v_xs_242735 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242737 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam61, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242735));
              {
                V v_field_242739 = v_t_242737.f[1];
                int64_t v_tag_242738 = ((int64_t)v_t_242737.f[0]);
                if ((v_tag_242738 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242740 = v_field_242739;
                  V v_t_242741 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str294), heff_strAppend(heff_dup(v_x_242740), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str295)));
                  V v_t_242742 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str296), heff_strAppend(v_x_242740, v_t_242741));
                  V v_t_242745;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242744 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242745 = v_s_242744;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242742}), v_t_242745});
                } else {
                  heff_drop(v_field_242739);
                  V v_t_242746 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242747 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242746}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242748 = v_t_242747.f[0];
                    V v_field_242749 = v_t_242747.f[1];
                    V v_x_242750 = v_field_242748;
                    V v_y_242751 = v_field_242749;
                    V v_body_242752 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242755;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242754 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242755 = v_s_242754;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242758;
                    switch (heff_tag_of(v_body_242752)) {
                    case TAG_At: {
                      V v_s_242757 = heff_dup(heff_field(v_body_242752, 1));
                      v_t_242758 = v_s_242757;
                      break;
                    }
                    default: heff_nomatch(v_body_242752);
                    }
                    V v_t_242759 = ({ V rv_1 = heff_get_n(v_t_242758, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242755, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242760 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242752)}), v_t_242759});
                    V v_t_242763;
                    switch (heff_tag_of(v_body_242752)) {
                    case TAG_At: {
                      V v_s_242762 = heff_field(v_body_242752, 1);
                      heff_take_n(v_body_242752, 2ULL, 2);
                      v_t_242763 = v_s_242762;
                      break;
                    }
                    default: heff_nomatch(v_body_242752);
                    }
                    V v_t_242764 = ({ V rv_1 = heff_get_n(v_t_242763, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242765 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242751, v_t_242760}), v_t_242764});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242750; V a_2 = v_t_242765; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242750); r_; });
                  }
                }
              }
            }
            case TAG_EContinue: {
              heff_drop(v_fsp_241806);
              V v_xs_242766 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242768 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam62, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242766));
              {
                V v_field_242770 = v_t_242768.f[1];
                int64_t v_tag_242769 = ((int64_t)v_t_242768.f[0]);
                if ((v_tag_242769 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242771 = v_field_242770;
                  V v_t_242772 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str297), heff_strAppend(heff_dup(v_x_242771), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str298)));
                  V v_t_242773 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str299), heff_strAppend(v_x_242771, v_t_242772));
                  V v_t_242776;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242775 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242776 = v_s_242775;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242773}), v_t_242776});
                } else {
                  heff_drop(v_field_242770);
                  V v_t_242777 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242778 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242777}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242779 = v_t_242778.f[0];
                    V v_field_242780 = v_t_242778.f[1];
                    V v_x_242781 = v_field_242779;
                    V v_y_242782 = v_field_242780;
                    V v_body_242783 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242786;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242785 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242786 = v_s_242785;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242789;
                    switch (heff_tag_of(v_body_242783)) {
                    case TAG_At: {
                      V v_s_242788 = heff_dup(heff_field(v_body_242783, 1));
                      v_t_242789 = v_s_242788;
                      break;
                    }
                    default: heff_nomatch(v_body_242783);
                    }
                    V v_t_242790 = ({ V rv_1 = heff_get_n(v_t_242789, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242786, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242791 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242783)}), v_t_242790});
                    V v_t_242794;
                    switch (heff_tag_of(v_body_242783)) {
                    case TAG_At: {
                      V v_s_242793 = heff_field(v_body_242783, 1);
                      heff_take_n(v_body_242783, 2ULL, 2);
                      v_t_242794 = v_s_242793;
                      break;
                    }
                    default: heff_nomatch(v_body_242783);
                    }
                    V v_t_242795 = ({ V rv_1 = heff_get_n(v_t_242794, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242796 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242782, v_t_242791}), v_t_242795});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242781; V a_2 = v_t_242796; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242781); r_; });
                  }
                }
              }
            }
            case TAG_EReturn: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242798 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242800 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam63, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242798));
              {
                V v_field_242802 = v_t_242800.f[1];
                int64_t v_tag_242801 = ((int64_t)v_t_242800.f[0]);
                if ((v_tag_242801 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242803 = v_field_242802;
                  V v_t_242804 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str300), heff_strAppend(heff_dup(v_x_242803), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str301)));
                  V v_t_242805 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str302), heff_strAppend(v_x_242803, v_t_242804));
                  V v_t_242808;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242807 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242808 = v_s_242807;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242805}), v_t_242808});
                } else {
                  heff_drop(v_field_242802);
                  V v_t_242809 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242810 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242809}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242811 = v_t_242810.f[0];
                    V v_field_242812 = v_t_242810.f[1];
                    V v_x_242813 = v_field_242811;
                    V v_y_242814 = v_field_242812;
                    V v_body_242815 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242818;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242817 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242818 = v_s_242817;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242821;
                    switch (heff_tag_of(v_body_242815)) {
                    case TAG_At: {
                      V v_s_242820 = heff_dup(heff_field(v_body_242815, 1));
                      v_t_242821 = v_s_242820;
                      break;
                    }
                    default: heff_nomatch(v_body_242815);
                    }
                    V v_t_242822 = ({ V rv_1 = heff_get_n(v_t_242821, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242818, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242823 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242815)}), v_t_242822});
                    V v_t_242826;
                    switch (heff_tag_of(v_body_242815)) {
                    case TAG_At: {
                      V v_s_242825 = heff_field(v_body_242815, 1);
                      heff_take_n(v_body_242815, 2ULL, 2);
                      v_t_242826 = v_s_242825;
                      break;
                    }
                    default: heff_nomatch(v_body_242815);
                    }
                    V v_t_242827 = ({ V rv_1 = heff_get_n(v_t_242826, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242828 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242814, v_t_242823}), v_t_242827});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242813; V a_2 = v_t_242828; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242813); r_; });
                  }
                }
              }
            }
            case TAG_ENest: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242830 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242832 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam64, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242830));
              {
                V v_field_242834 = v_t_242832.f[1];
                int64_t v_tag_242833 = ((int64_t)v_t_242832.f[0]);
                if ((v_tag_242833 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242835 = v_field_242834;
                  V v_t_242836 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str303), heff_strAppend(heff_dup(v_x_242835), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str304)));
                  V v_t_242837 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str305), heff_strAppend(v_x_242835, v_t_242836));
                  V v_t_242840;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242839 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242840 = v_s_242839;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242837}), v_t_242840});
                } else {
                  heff_drop(v_field_242834);
                  V v_t_242841 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242842 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242841}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242843 = v_t_242842.f[0];
                    V v_field_242844 = v_t_242842.f[1];
                    V v_x_242845 = v_field_242843;
                    V v_y_242846 = v_field_242844;
                    V v_body_242847 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242850;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242849 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242850 = v_s_242849;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242853;
                    switch (heff_tag_of(v_body_242847)) {
                    case TAG_At: {
                      V v_s_242852 = heff_dup(heff_field(v_body_242847, 1));
                      v_t_242853 = v_s_242852;
                      break;
                    }
                    default: heff_nomatch(v_body_242847);
                    }
                    V v_t_242854 = ({ V rv_1 = heff_get_n(v_t_242853, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242850, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242855 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242847)}), v_t_242854});
                    V v_t_242858;
                    switch (heff_tag_of(v_body_242847)) {
                    case TAG_At: {
                      V v_s_242857 = heff_field(v_body_242847, 1);
                      heff_take_n(v_body_242847, 2ULL, 2);
                      v_t_242858 = v_s_242857;
                      break;
                    }
                    default: heff_nomatch(v_body_242847);
                    }
                    V v_t_242859 = ({ V rv_1 = heff_get_n(v_t_242858, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242860 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242846, v_t_242855}), v_t_242859});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242845; V a_2 = v_t_242860; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242845); r_; });
                  }
                }
              }
            }
            case TAG_ELazy: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242862 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242864 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam65, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242862));
              {
                V v_field_242866 = v_t_242864.f[1];
                int64_t v_tag_242865 = ((int64_t)v_t_242864.f[0]);
                if ((v_tag_242865 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242867 = v_field_242866;
                  V v_t_242868 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str306), heff_strAppend(heff_dup(v_x_242867), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str307)));
                  V v_t_242869 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str308), heff_strAppend(v_x_242867, v_t_242868));
                  V v_t_242872;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242871 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242872 = v_s_242871;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242869}), v_t_242872});
                } else {
                  heff_drop(v_field_242866);
                  V v_t_242873 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242874 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242873}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242875 = v_t_242874.f[0];
                    V v_field_242876 = v_t_242874.f[1];
                    V v_x_242877 = v_field_242875;
                    V v_y_242878 = v_field_242876;
                    V v_body_242879 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242882;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242881 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242882 = v_s_242881;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242885;
                    switch (heff_tag_of(v_body_242879)) {
                    case TAG_At: {
                      V v_s_242884 = heff_dup(heff_field(v_body_242879, 1));
                      v_t_242885 = v_s_242884;
                      break;
                    }
                    default: heff_nomatch(v_body_242879);
                    }
                    V v_t_242886 = ({ V rv_1 = heff_get_n(v_t_242885, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242882, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242887 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242879)}), v_t_242886});
                    V v_t_242890;
                    switch (heff_tag_of(v_body_242879)) {
                    case TAG_At: {
                      V v_s_242889 = heff_field(v_body_242879, 1);
                      heff_take_n(v_body_242879, 2ULL, 2);
                      v_t_242890 = v_s_242889;
                      break;
                    }
                    default: heff_nomatch(v_body_242879);
                    }
                    V v_t_242891 = ({ V rv_1 = heff_get_n(v_t_242890, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242892 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242878, v_t_242887}), v_t_242891});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242877; V a_2 = v_t_242892; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242877); r_; });
                  }
                }
              }
            }
            case TAG_ETuple: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242894 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242896 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam66, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242894));
              {
                V v_field_242898 = v_t_242896.f[1];
                int64_t v_tag_242897 = ((int64_t)v_t_242896.f[0]);
                if ((v_tag_242897 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242899 = v_field_242898;
                  V v_t_242900 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str309), heff_strAppend(heff_dup(v_x_242899), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str310)));
                  V v_t_242901 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str311), heff_strAppend(v_x_242899, v_t_242900));
                  V v_t_242904;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242903 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242904 = v_s_242903;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242901}), v_t_242904});
                } else {
                  heff_drop(v_field_242898);
                  V v_t_242905 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242906 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242905}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242907 = v_t_242906.f[0];
                    V v_field_242908 = v_t_242906.f[1];
                    V v_x_242909 = v_field_242907;
                    V v_y_242910 = v_field_242908;
                    V v_body_242911 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242914;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242913 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242914 = v_s_242913;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242917;
                    switch (heff_tag_of(v_body_242911)) {
                    case TAG_At: {
                      V v_s_242916 = heff_dup(heff_field(v_body_242911, 1));
                      v_t_242917 = v_s_242916;
                      break;
                    }
                    default: heff_nomatch(v_body_242911);
                    }
                    V v_t_242918 = ({ V rv_1 = heff_get_n(v_t_242917, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242914, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242919 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242911)}), v_t_242918});
                    V v_t_242922;
                    switch (heff_tag_of(v_body_242911)) {
                    case TAG_At: {
                      V v_s_242921 = heff_field(v_body_242911, 1);
                      heff_take_n(v_body_242911, 2ULL, 2);
                      v_t_242922 = v_s_242921;
                      break;
                    }
                    default: heff_nomatch(v_body_242911);
                    }
                    V v_t_242923 = ({ V rv_1 = heff_get_n(v_t_242922, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242924 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242910, v_t_242919}), v_t_242923});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242909; V a_2 = v_t_242924; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242909); r_; });
                  }
                }
              }
            }
            case TAG_ETry: {
              heff_take_n(v_x312111_241805, 0ULL, 1);
              heff_drop(v_fsp_241806);
              V v_xs_242926 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242928 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam67, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242926));
              {
                V v_field_242930 = v_t_242928.f[1];
                int64_t v_tag_242929 = ((int64_t)v_t_242928.f[0]);
                if ((v_tag_242929 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242931 = v_field_242930;
                  V v_t_242932 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str312), heff_strAppend(heff_dup(v_x_242931), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str313)));
                  V v_t_242933 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str314), heff_strAppend(v_x_242931, v_t_242932));
                  V v_t_242936;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242935 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242936 = v_s_242935;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242933}), v_t_242936});
                } else {
                  heff_drop(v_field_242930);
                  V v_t_242937 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242938 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242937}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242939 = v_t_242938.f[0];
                    V v_field_242940 = v_t_242938.f[1];
                    V v_x_242941 = v_field_242939;
                    V v_y_242942 = v_field_242940;
                    V v_body_242943 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242946;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242945 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242946 = v_s_242945;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242949;
                    switch (heff_tag_of(v_body_242943)) {
                    case TAG_At: {
                      V v_s_242948 = heff_dup(heff_field(v_body_242943, 1));
                      v_t_242949 = v_s_242948;
                      break;
                    }
                    default: heff_nomatch(v_body_242943);
                    }
                    V v_t_242950 = ({ V rv_1 = heff_get_n(v_t_242949, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242946, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242951 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242943)}), v_t_242950});
                    V v_t_242954;
                    switch (heff_tag_of(v_body_242943)) {
                    case TAG_At: {
                      V v_s_242953 = heff_field(v_body_242943, 1);
                      heff_take_n(v_body_242943, 2ULL, 2);
                      v_t_242954 = v_s_242953;
                      break;
                    }
                    default: heff_nomatch(v_body_242943);
                    }
                    V v_t_242955 = ({ V rv_1 = heff_get_n(v_t_242954, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242956 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242942, v_t_242951}), v_t_242955});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242941; V a_2 = v_t_242956; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242941); r_; });
                  }
                }
              }
            }
            case TAG_EWith: {
              heff_take_n(v_x312111_241805, 0ULL, 4);
              heff_drop(v_fsp_241806);
              V v_xs_242961 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31211_241804_24At, heff_dup(v_p_24760)));
              HeffT2 v_t_242963 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam68, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242961));
              {
                V v_field_242965 = v_t_242963.f[1];
                int64_t v_tag_242964 = ((int64_t)v_t_242963.f[0]);
                if ((v_tag_242964 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 6);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24761, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242966 = v_field_242965;
                  V v_t_242967 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str315), heff_strAppend(heff_dup(v_x_242966), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str316)));
                  V v_t_242968 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str317), heff_strAppend(v_x_242966, v_t_242967));
                  V v_t_242971;
                  switch (heff_tag_of(v_p_24760)) {
                  case TAG_At: {
                    V v_s_242970 = heff_field(v_p_24760, 1);
                    heff_take_n(v_p_24760, 2ULL, 2);
                    v_t_242971 = v_s_242970;
                    break;
                  }
                  default: heff_nomatch(v_p_24760);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242968}), v_t_242971});
                } else {
                  heff_drop(v_field_242965);
                  V v_t_242972 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242973 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242972}), NTAG(TAG_Nil), v_x312_24761));
                  {
                    V v_field_242974 = v_t_242973.f[0];
                    V v_field_242975 = v_t_242973.f[1];
                    V v_x_242976 = v_field_242974;
                    V v_y_242977 = v_field_242975;
                    V v_body_242978 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242981;
                    switch (heff_tag_of(v_p_24760)) {
                    case TAG_At: {
                      V v_s_242980 = heff_dup(heff_field(v_p_24760, 1));
                      v_t_242981 = v_s_242980;
                      break;
                    }
                    default: heff_nomatch(v_p_24760);
                    }
                    V v_t_242984;
                    switch (heff_tag_of(v_body_242978)) {
                    case TAG_At: {
                      V v_s_242983 = heff_dup(heff_field(v_body_242978, 1));
                      v_t_242984 = v_s_242983;
                      break;
                    }
                    default: heff_nomatch(v_body_242978);
                    }
                    V v_t_242985 = ({ V rv_1 = heff_get_n(v_t_242984, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242981, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242986 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_242978)}), v_t_242985});
                    V v_t_242989;
                    switch (heff_tag_of(v_body_242978)) {
                    case TAG_At: {
                      V v_s_242988 = heff_field(v_body_242978, 1);
                      heff_take_n(v_body_242978, 2ULL, 2);
                      v_t_242989 = v_s_242988;
                      break;
                    }
                    default: heff_nomatch(v_body_242978);
                    }
                    V v_t_242990 = ({ V rv_1 = heff_get_n(v_t_242989, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242991 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242977, v_t_242986}), v_t_242990});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242976; V a_2 = v_t_242991; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242976); r_; });
                  }
                }
              }
            }
            default: return heff_nomatch(v_x312111_241805);
            }
          }
          default: return heff_nomatch(v_x31211_241804);
          }
        }
        case TAG_ELazy: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_242993 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_242995 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam69, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242993));
          {
            V v_field_242997 = v_t_242995.f[1];
            int64_t v_tag_242996 = ((int64_t)v_t_242995.f[0]);
            if ((v_tag_242996 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_242998 = v_field_242997;
              V v_t_242999 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str318), heff_strAppend(heff_dup(v_x_242998), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str319)));
              V v_t_243000 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str320), heff_strAppend(v_x_242998, v_t_242999));
              V v_t_243003;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_243002 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_243003 = v_s_243002;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243000}), v_t_243003});
            } else {
              heff_drop(v_field_242997);
              V v_t_243004 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243005 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243004}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_243006 = v_t_243005.f[0];
                V v_field_243007 = v_t_243005.f[1];
                V v_x_243008 = v_field_243006;
                V v_y_243009 = v_field_243007;
                V v_body_243010 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243013;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_243012 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_243013 = v_s_243012;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_243016;
                switch (heff_tag_of(v_body_243010)) {
                case TAG_At: {
                  V v_s_243015 = heff_dup(heff_field(v_body_243010, 1));
                  v_t_243016 = v_s_243015;
                  break;
                }
                default: heff_nomatch(v_body_243010);
                }
                V v_t_243017 = ({ V rv_1 = heff_get_n(v_t_243016, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243013, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243018 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_243010)}), v_t_243017});
                V v_t_243021;
                switch (heff_tag_of(v_body_243010)) {
                case TAG_At: {
                  V v_s_243020 = heff_field(v_body_243010, 1);
                  heff_take_n(v_body_243010, 2ULL, 2);
                  v_t_243021 = v_s_243020;
                  break;
                }
                default: heff_nomatch(v_body_243010);
                }
                V v_t_243022 = ({ V rv_1 = heff_get_n(v_t_243021, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243023 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243009, v_t_243018}), v_t_243022});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243008; V a_2 = v_t_243023; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243008); r_; });
              }
            }
          }
        }
        case TAG_ETuple: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_243025 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_243027 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam70, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243025));
          {
            V v_field_243029 = v_t_243027.f[1];
            int64_t v_tag_243028 = ((int64_t)v_t_243027.f[0]);
            if ((v_tag_243028 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243030 = v_field_243029;
              V v_t_243031 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str321), heff_strAppend(heff_dup(v_x_243030), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str322)));
              V v_t_243032 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str323), heff_strAppend(v_x_243030, v_t_243031));
              V v_t_243035;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_243034 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_243035 = v_s_243034;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243032}), v_t_243035});
            } else {
              heff_drop(v_field_243029);
              V v_t_243036 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243037 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243036}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_243038 = v_t_243037.f[0];
                V v_field_243039 = v_t_243037.f[1];
                V v_x_243040 = v_field_243038;
                V v_y_243041 = v_field_243039;
                V v_body_243042 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243045;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_243044 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_243045 = v_s_243044;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_243048;
                switch (heff_tag_of(v_body_243042)) {
                case TAG_At: {
                  V v_s_243047 = heff_dup(heff_field(v_body_243042, 1));
                  v_t_243048 = v_s_243047;
                  break;
                }
                default: heff_nomatch(v_body_243042);
                }
                V v_t_243049 = ({ V rv_1 = heff_get_n(v_t_243048, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243045, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243050 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_243042)}), v_t_243049});
                V v_t_243053;
                switch (heff_tag_of(v_body_243042)) {
                case TAG_At: {
                  V v_s_243052 = heff_field(v_body_243042, 1);
                  heff_take_n(v_body_243042, 2ULL, 2);
                  v_t_243053 = v_s_243052;
                  break;
                }
                default: heff_nomatch(v_body_243042);
                }
                V v_t_243054 = ({ V rv_1 = heff_get_n(v_t_243053, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243055 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243041, v_t_243050}), v_t_243054});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243040; V a_2 = v_t_243055; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243040); r_; });
              }
            }
          }
        }
        case TAG_ETry: {
          heff_take_n(v_x3121_24762, 0ULL, 1);
          V v_xs_243057 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_243059 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam71, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243057));
          {
            V v_field_243061 = v_t_243059.f[1];
            int64_t v_tag_243060 = ((int64_t)v_t_243059.f[0]);
            if ((v_tag_243060 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243062 = v_field_243061;
              V v_t_243063 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str324), heff_strAppend(heff_dup(v_x_243062), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str325)));
              V v_t_243064 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str326), heff_strAppend(v_x_243062, v_t_243063));
              V v_t_243067;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_243066 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_243067 = v_s_243066;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243064}), v_t_243067});
            } else {
              heff_drop(v_field_243061);
              V v_t_243068 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243069 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243068}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_243070 = v_t_243069.f[0];
                V v_field_243071 = v_t_243069.f[1];
                V v_x_243072 = v_field_243070;
                V v_y_243073 = v_field_243071;
                V v_body_243074 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243077;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_243076 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_243077 = v_s_243076;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_243080;
                switch (heff_tag_of(v_body_243074)) {
                case TAG_At: {
                  V v_s_243079 = heff_dup(heff_field(v_body_243074, 1));
                  v_t_243080 = v_s_243079;
                  break;
                }
                default: heff_nomatch(v_body_243074);
                }
                V v_t_243081 = ({ V rv_1 = heff_get_n(v_t_243080, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243077, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243082 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_243074)}), v_t_243081});
                V v_t_243085;
                switch (heff_tag_of(v_body_243074)) {
                case TAG_At: {
                  V v_s_243084 = heff_field(v_body_243074, 1);
                  heff_take_n(v_body_243074, 2ULL, 2);
                  v_t_243085 = v_s_243084;
                  break;
                }
                default: heff_nomatch(v_body_243074);
                }
                V v_t_243086 = ({ V rv_1 = heff_get_n(v_t_243085, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243087 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243073, v_t_243082}), v_t_243086});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243072; V a_2 = v_t_243087; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243072); r_; });
              }
            }
          }
        }
        case TAG_EWith: {
          heff_take_n(v_x3121_24762, 0ULL, 4);
          V v_xs_243092 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24760)));
          HeffT2 v_t_243094 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam72, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243092));
          {
            V v_field_243096 = v_t_243094.f[1];
            int64_t v_tag_243095 = ((int64_t)v_t_243094.f[0]);
            if ((v_tag_243095 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 6);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24761, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243097 = v_field_243096;
              V v_t_243098 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str327), heff_strAppend(heff_dup(v_x_243097), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str328)));
              V v_t_243099 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str329), heff_strAppend(v_x_243097, v_t_243098));
              V v_t_243102;
              switch (heff_tag_of(v_p_24760)) {
              case TAG_At: {
                V v_s_243101 = heff_field(v_p_24760, 1);
                heff_take_n(v_p_24760, 2ULL, 2);
                v_t_243102 = v_s_243101;
                break;
              }
              default: heff_nomatch(v_p_24760);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243099}), v_t_243102});
            } else {
              heff_drop(v_field_243096);
              V v_t_243103 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243104 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243103}), NTAG(TAG_Nil), v_x312_24761));
              {
                V v_field_243105 = v_t_243104.f[0];
                V v_field_243106 = v_t_243104.f[1];
                V v_x_243107 = v_field_243105;
                V v_y_243108 = v_field_243106;
                V v_body_243109 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243112;
                switch (heff_tag_of(v_p_24760)) {
                case TAG_At: {
                  V v_s_243111 = heff_dup(heff_field(v_p_24760, 1));
                  v_t_243112 = v_s_243111;
                  break;
                }
                default: heff_nomatch(v_p_24760);
                }
                V v_t_243115;
                switch (heff_tag_of(v_body_243109)) {
                case TAG_At: {
                  V v_s_243114 = heff_dup(heff_field(v_body_243109, 1));
                  v_t_243115 = v_s_243114;
                  break;
                }
                default: heff_nomatch(v_body_243109);
                }
                V v_t_243116 = ({ V rv_1 = heff_get_n(v_t_243115, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243112, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243117 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24760, heff_dup(v_body_243109)}), v_t_243116});
                V v_t_243120;
                switch (heff_tag_of(v_body_243109)) {
                case TAG_At: {
                  V v_s_243119 = heff_field(v_body_243109, 1);
                  heff_take_n(v_body_243109, 2ULL, 2);
                  v_t_243120 = v_s_243119;
                  break;
                }
                default: heff_nomatch(v_body_243109);
                }
                V v_t_243121 = ({ V rv_1 = heff_get_n(v_t_243120, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243122 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243108, v_t_243117}), v_t_243121});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243107; V a_2 = v_t_243122; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243107); r_; });
              }
            }
          }
        }
        default: return heff_nomatch(v_x3121_24762);
        }
      }
      default: return heff_nomatch(v_x312_24761);
      }
    }
    case TAG_StmtExpr: {
      V v_e_243123 = heff_field(v_x31_245, 0);
      heff_take_n(v_x31_245, 1ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_243124 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_243123));
      if ((heff_dup(v_t_243124) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop(v_t_243124);
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2econtrolT(v_t_240, v_cx_241, v_e_243123, v_rest_243, v_end_244);
      } else {
        heff_drop(v_t_243124);
        V v_t_243125 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_243126 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243125}), NTAG(TAG_Nil), v_e_243123));
        {
          V v_field_243127 = v_t_243126.f[0];
          V v_field_243128 = v_t_243126.f[1];
          V v_x_243129 = v_field_243127;
          V v_y_243130 = v_field_243128;
          V v_xsp_243131 = heff_dup(heff_rfield(v_cx_241, 3));
          V v_rest_243132 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
          V v_t_243133 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
          V v_t_243134 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243133}), heff_dup(heff_rfield(v_cx_241, 3))});
          V v_t_243135 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str330), heff_dup(v_xsp_243131)}), heff_dup(v_rest_243132)});
          V v_t_243138;
          switch (heff_tag_of(v_rest_243132)) {
          case TAG_At: {
            V v_s_243137 = heff_field(v_rest_243132, 1);
            heff_take_n(v_rest_243132, 2ULL, 2);
            v_t_243138 = v_s_243137;
            break;
          }
          default: heff_nomatch(v_rest_243132);
          }
          V v_t_243139 = ({ V rv_1 = heff_get_n(v_t_243138, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_243131, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_243140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243135, v_t_243139}), NTAG(TAG_Nil)});
          V v_t_243141 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_243134, heff_tag_n(TAG_Cons, 2, (V[]){v_y_243130, v_t_243140})));
          return ({ V a_0 = v_cx_241; V a_1 = v_x_243129; V a_2 = v_t_243141; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243129); r_; });
        }
      }
    }
    case TAG_StmtLetMut: {
      V v_x_243142 = heff_field(v_x31_245, 0);
      V v_xsp_243143 = heff_field(v_x31_245, 1);
      V v_e_243144 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      heff_drop_rec(v_sp_246, 2);
      V v_t_243145 = (g_list_2eany_24s2077819594x1842428557(v_x_243142, heff_rfield(v_cx_241, 1)));
      if ((heff_dup(v_t_243145) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 1);
        heff_drop_rec(v_cx_241, 6);
        heff_drop(v_rest_243);
        heff_drop(v_end_244);
        heff_drop(v_e_243144);
        heff_drop(v_t_243145);
        V v_t_243146 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str331), heff_strAppend(heff_dup(v_x_243142), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str332)));
        V v_t_243147 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str333), heff_strAppend(v_x_243142, v_t_243146));
        return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243147}), v_xsp_243143});
      } else {
        heff_drop(v_t_243145);
        V v_t_243148 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_243149 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243148}), NTAG(TAG_Nil), v_e_243144));
        {
          V v_field_243150 = v_t_243149.f[0];
          V v_field_243151 = v_t_243149.f[1];
          V v_x_243152 = v_field_243150;
          V v_y_243153 = v_field_243151;
          V v_sp_243156;
          switch (heff_tag_of(v_y_243153)) {
          case TAG_At: {
            V v_s_243155 = heff_dup(heff_field(v_y_243153, 1));
            v_sp_243156 = v_s_243155;
            break;
          }
          default: heff_nomatch(v_y_243153);
          }
          V v_t_243157 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str334)}), heff_dup(v_sp_243156)});
          V v_t_243158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str335)}), v_sp_243156});
          V v_t_243159 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243158, NTAG(TAG_Nil)});
          V v_t_243160 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_243157, v_t_243159));
          V v_t_243163;
          switch (heff_tag_of(v_y_243153)) {
          case TAG_At: {
            V v_s_243162 = heff_dup(heff_field(v_y_243153, 1));
            v_t_243163 = v_s_243162;
            break;
          }
          default: heff_nomatch(v_y_243153);
          }
          V v_v_243164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_243153, v_t_243160}), v_t_243163});
          V v_t_243165 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243142), NTAG(TAG_Nil)});
          V v_t_243166 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_cx_241, 1)), v_t_243165));
          V v_t_243167 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), v_t_243166, heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), heff_dup(heff_rfield(v_cx_241, 4)), heff_dup(heff_rfield(v_cx_241, 5))});
          V v_body_243168 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_243167, v_rest_243, v_end_244}));
          V v_t_243169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_243142}), heff_dup(v_xsp_243143)});
          V v_t_243172;
          switch (heff_tag_of(v_body_243168)) {
          case TAG_At: {
            V v_s_243171 = heff_dup(heff_field(v_body_243168, 1));
            v_t_243172 = v_s_243171;
            break;
          }
          default: heff_nomatch(v_body_243168);
          }
          V v_t_243173 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_243143, 0)); V rr_ = heff_rec_reuse_nf(v_t_243172, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_243174 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_243169, heff_dup(v_body_243168)}), v_t_243173});
          V v_t_243177;
          switch (heff_tag_of(v_body_243168)) {
          case TAG_At: {
            V v_s_243176 = heff_field(v_body_243168, 1);
            heff_take_n(v_body_243168, 2ULL, 2);
            v_t_243177 = v_s_243176;
            break;
          }
          default: heff_nomatch(v_body_243168);
          }
          V v_t_243178 = ({ V rv_1 = heff_get_n(v_t_243177, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_243143, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_243179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_243164, v_t_243174}), v_t_243178});
          return ({ V a_0 = v_cx_241; V a_1 = v_x_243152; V a_2 = v_t_243179; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243152); r_; });
        }
      }
    }
    case TAG_StmtLetElse: {
      V v_p_243180 = heff_field(v_x31_245, 0);
      V v_e_243181 = heff_field(v_x31_245, 1);
      V v_els_243182 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      V v_xs_243183 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_243180)));
      HeffT2 v_t_243185 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam73, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243183));
      {
        V v_field_243187 = v_t_243185.f[1];
        int64_t v_tag_243186 = ((int64_t)v_t_243185.f[0]);
        if ((v_tag_243186 == ((int64_t)0ULL))) {
          heff_drop_rec(v_t_240, 1);
          heff_drop_rec(v_cx_241, 6);
          heff_drop(v_rest_243);
          heff_drop(v_end_244);
          heff_drop_rec(v_sp_246, 2);
          heff_drop(v_e_243181);
          heff_drop(v_els_243182);
          V v_x_243188 = v_field_243187;
          V v_t_243189 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str336), heff_strAppend(heff_dup(v_x_243188), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str337)));
          V v_t_243190 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str338), heff_strAppend(v_x_243188, v_t_243189));
          V v_t_243193;
          switch (heff_tag_of(v_p_243180)) {
          case TAG_At: {
            V v_s_243192 = heff_field(v_p_243180, 1);
            heff_take_n(v_p_243180, 2ULL, 2);
            v_t_243193 = v_s_243192;
            break;
          }
          default: heff_nomatch(v_p_243180);
          }
          return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243190}), v_t_243193});
        } else {
          heff_drop(v_field_243187);
          V v_t_243194 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str339)}), heff_dup(v_sp_246)});
          V v_t_243195 = (g_heff_2esyntax_2epresyntax_2eelseLeaving(heff_dup(v_sp_246), v_els_243182));
          V v_t_243196 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243194, v_t_243195}), NTAG(TAG_Nil)});
          V v_t_243197 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_p_243180, v_rest_243}), v_t_243196});
          return (g_heff_2esyntax_2epresyntax_2econdT(v_t_240, v_cx_241, v_sp_246, v_e_243181, v_t_243197, NTAG(TAG_Nil), v_end_244));
        }
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtT(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam0(V self, V *args) {
  V v_x_24766 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24766; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24766); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam1(V self, V *args) {
  V v_x_24798 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24798; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24798); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam2(V self, V *args) {
  V v_x_24830 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24830; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24830); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam3(V self, V *args) {
  V v_x_24862 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24862; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24862); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam4(V self, V *args) {
  V v_x_24894 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24894; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24894); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam5(V self, V *args) {
  V v_x_24926 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24926; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24926); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam6(V self, V *args) {
  V v_x_24958 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24958; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24958); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam7(V self, V *args) {
  V v_x_24990 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24990; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24990); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam8(V self, V *args) {
  V v_x_241022 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241022; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241022); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam9(V self, V *args) {
  V v_x_241055 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241055; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241055); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam10(V self, V *args) {
  V v_x_241087 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241087; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241087); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam11(V self, V *args) {
  V v_x_241120 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241120; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241120); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam12(V self, V *args) {
  V v_x_241153 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241153; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241153); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam13(V self, V *args) {
  V v_x_241186 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241186; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241186); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam14(V self, V *args) {
  V v_x_241219 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241219; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241219); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam15(V self, V *args) {
  V v_x_241254 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241254; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241254); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam16(V self, V *args) {
  V v_x_241286 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241286; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241286); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam17(V self, V *args) {
  V v_x_241318 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241318; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241318); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam18(V self, V *args) {
  V v_x_241350 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241350; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241350); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam19(V self, V *args) {
  V v_x_241383 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241383; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241383); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam20(V self, V *args) {
  V v_x_241416 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241416; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241416); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam21(V self, V *args) {
  V v_x_241449 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241449; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241449); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam22(V self, V *args) {
  V v_x_241481 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241481; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241481); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam23(V self, V *args) {
  V v_x_241514 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241514; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241514); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam24(V self, V *args) {
  V v_x_241546 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241546; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241546); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam25(V self, V *args) {
  V v_x_241580 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241580; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241580); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam26(V self, V *args) {
  V v_x_241613 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241613; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241613); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam27(V self, V *args) {
  V v_x_241647 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241647; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241647); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam28(V self, V *args) {
  V v_x_241680 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241680; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241680); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam29(V self, V *args) {
  V v_x_241711 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241711; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241711); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam30(V self, V *args) {
  V v_x_241742 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241742; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241742); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam31(V self, V *args) {
  V v_x_241774 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241774; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241774); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam32(V self, V *args) {
  V v_x_241809 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241809; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241809); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam33(V self, V *args) {
  V v_x_241841 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241841; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241841); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam34(V self, V *args) {
  V v_x_241873 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241873; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241873); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam35(V self, V *args) {
  V v_x_241905 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241905; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241905); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam36(V self, V *args) {
  V v_x_241937 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241937; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241937); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam37(V self, V *args) {
  V v_x_241969 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241969; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_241969); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam38(V self, V *args) {
  V v_x_242001 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242001; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242001); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam39(V self, V *args) {
  V v_x_242033 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242033; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242033); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam40(V self, V *args) {
  V v_x_242065 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242065; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242065); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam41(V self, V *args) {
  V v_x_242098 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242098; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242098); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam42(V self, V *args) {
  V v_x_242130 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242130; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242130); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam43(V self, V *args) {
  V v_x_242163 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242163; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242163); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam44(V self, V *args) {
  V v_x_242196 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242196; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242196); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam45(V self, V *args) {
  V v_x_242229 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242229; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242229); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam46(V self, V *args) {
  V v_x_242262 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242262; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242262); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam47(V self, V *args) {
  V v_x_242297 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242297; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242297); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam48(V self, V *args) {
  V v_x_242329 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242329; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242329); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam49(V self, V *args) {
  V v_x_242361 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242361; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242361); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam50(V self, V *args) {
  V v_x_242393 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242393; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242393); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam51(V self, V *args) {
  V v_x_242426 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242426; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242426); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam52(V self, V *args) {
  V v_x_242459 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242459; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242459); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam53(V self, V *args) {
  V v_x_242492 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242492; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242492); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam54(V self, V *args) {
  V v_x_242524 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242524; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242524); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam55(V self, V *args) {
  V v_x_242557 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242557; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242557); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam56(V self, V *args) {
  V v_x_242589 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242589; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242589); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam57(V self, V *args) {
  V v_x_242623 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242623; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242623); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam58(V self, V *args) {
  V v_x_242656 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242656; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242656); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam59(V self, V *args) {
  V v_x_242690 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242690; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242690); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam60(V self, V *args) {
  V v_x_242705 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242705; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242705); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam61(V self, V *args) {
  V v_x_242736 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242736; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242736); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam62(V self, V *args) {
  V v_x_242767 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242767; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242767); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam63(V self, V *args) {
  V v_x_242799 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242799; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242799); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam64(V self, V *args) {
  V v_x_242831 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242831; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242831); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam65(V self, V *args) {
  V v_x_242863 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242863; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242863); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam66(V self, V *args) {
  V v_x_242895 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242895; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242895); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam67(V self, V *args) {
  V v_x_242927 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242927; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242927); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam68(V self, V *args) {
  V v_x_242962 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242962; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242962); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam69(V self, V *args) {
  V v_x_242994 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242994; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_242994); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam70(V self, V *args) {
  V v_x_243026 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243026; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_243026); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam71(V self, V *args) {
  V v_x_243058 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243058; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_243058); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam72(V self, V *args) {
  V v_x_243093 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243093; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_243093); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam73(V self, V *args) {
  V v_x_243184 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243184; V b_1 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_243184); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2419;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_c_2410 = v_field_249;
          V v_t_2413;
          switch (heff_tag_of(v_c_2410)) {
          case TAG_At: {
            V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
            v_t_2413 = v_s_2412;
            break;
          }
          default: heff_nomatch(v_c_2410);
          }
          v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
        } else {
          if ((v_tag_248 == ((int64_t)1ULL))) {
            V v_i_2414 = v_field_249;
            V v_t_2417;
            switch (heff_tag_of(v_i_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_i_2414);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2414}), v_t_2417});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2418 = v_field_249;
            v_t_2419 = v_t_2418;
          }
        }
      }
      V v_t_2434;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2420 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2420));
        V v_t_2433;
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_c_2424 = v_field_2423;
            v_t_2433 = v_c_2424;
          } else {
            if ((v_tag_2422 == ((int64_t)1ULL))) {
              V v_i_2425 = v_field_2423;
              V v_t_2428;
              switch (heff_tag_of(v_i_2425)) {
              case TAG_At: {
                V v_s_2427 = heff_dup(heff_field(v_i_2425, 1));
                v_t_2428 = v_s_2427;
                break;
              }
              default: heff_nomatch(v_i_2425);
              }
              v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2425}), v_t_2428});
            } else {
              V v_t_2429 = v_field_2423;
              V v_t_2432;
              switch (heff_tag_of(v_t_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_t_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_t_2429);
              }
              v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2429}), v_t_2432});
            }
          }
        }
        v_t_2434 = heff_tag_at_n(v_ru_24d_246_24Just, TAG_Just, 1, (V[]){v_t_2433});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2419, v_t_2434}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2435 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_2436 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2435));
      V v_t_2448;
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_c_2439 = v_field_2438;
          V v_t_2442;
          switch (heff_tag_of(v_c_2439)) {
          case TAG_At: {
            V v_s_2441 = heff_dup(heff_field(v_c_2439, 1));
            v_t_2442 = v_s_2441;
            break;
          }
          default: heff_nomatch(v_c_2439);
          }
          v_t_2448 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2439}), v_t_2442});
        } else {
          if ((v_tag_2437 == ((int64_t)1ULL))) {
            V v_i_2443 = v_field_2438;
            V v_t_2446;
            switch (heff_tag_of(v_i_2443)) {
            case TAG_At: {
              V v_s_2445 = heff_dup(heff_field(v_i_2443, 1));
              v_t_2446 = v_s_2445;
              break;
            }
            default: heff_nomatch(v_i_2443);
            }
            v_t_2448 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2443}), v_t_2446});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2447 = v_field_2438;
            v_t_2448 = v_t_2447;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2448}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_depth_244 = heff_take_field(v_j_243, 3);
  V v_head_245 = heff_take_field(v_j_243, 0);
  V v_vars_246 = heff_take_field(v_j_243, 1);
  V v_unit_247 = heff_get_n(v_j_243, 2, 4);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_244);
  V v_vars_249 = v_vars_246;
  V v_t_2413;
  if ((heff_dup(v_unit_247) == NTAG(TAG_True))) {
    heff_drop(v_unit_247);
    switch (heff_tag_of(v_vars_249)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 2);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
      break;
    }
    default: heff_nomatch(v_vars_249);
    }
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_unit_247);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_245, v_t_2413));
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eleaving(v_cx_241, v_sp_242, v_t_248, v_t_2414);
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str2, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str4, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str6, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str7, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V v_tok_240, V v_cx_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str0)}), v_sp_244});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str1)}), v_sp_244});
    }
    case TAG_StmtExpr: {
      V v_e_2410 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2410));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop_rec(v_sp_244, 2);
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
        heff_drop(v_t_2411);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()), v_cx_241, v_e_2410, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_2411);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_241, 4)))) {
          V v_t_2412 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2412}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_x_2416 = v_field_2414;
            V v_y_2417 = v_field_2415;
            V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
            V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2418}), heff_dup(v_sp_244)});
            V v_t_2420 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str3), v_t_2420));
            V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2421}), heff_dup(v_sp_244)});
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
            V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2419, v_t_2423));
            V v_rest_2425 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), heff_dup(v_sp_244), heff_dup(heff_rfield(v_cx_241, 4)), v_t_2424));
            V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
            V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2426}), heff_dup(heff_rfield(v_cx_241, 3))});
            V v_t_2428 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2429 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str5), v_t_2428));
            V v_t_2430 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2429, heff_dup(v_sp_244)}), heff_dup(v_rest_2425)});
            V v_t_2433;
            switch (heff_tag_of(v_rest_2425)) {
            case TAG_At: {
              V v_s_2432 = heff_field(v_rest_2425, 1);
              heff_take_n(v_rest_2425, 2ULL, 2);
              v_t_2433 = v_s_2432;
              break;
            }
            default: heff_nomatch(v_rest_2425);
            }
            V v_t_2434 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_t_2434}), NTAG(TAG_Nil)});
            V v_t_2436 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2417, v_t_2435})));
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2416; V a_2 = v_t_2436; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
          }
        } else {
          heff_drop_cell(v_tok_240, 2);
          heff_drop_rec(v_sp_244, 2);
          heff_drop_cell(v_ru_24x3_242_24At, 2);
          heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
          V v_t_2437 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2437}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2439 = v_t_2438.f[0];
            V v_field_2440 = v_t_2438.f[1];
            V v_x_2441 = v_field_2439;
            V v_y_2442 = v_field_2440;
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2441; V a_2 = v_y_2442; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2441); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str6)}), v_sp_244});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str7)}), v_sp_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(a[0], a[1], a[2]);
}