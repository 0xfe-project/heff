// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatVar 49363
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2earmT(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econdT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2eelseLeaving(V, V);
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_str2, 1, "`");
V g_heff_2esyntax_2epresyntax_2earmT_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2earmT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmT_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2earmT(V v_t_240, V v_cx_241, V v_end_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_xs_246 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_244)));
    HeffT2 v_t_248 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2earmT_lam0, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_246));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_240, 1);
        heff_drop_rec(v_cx_241, 5);
        heff_drop(v_end_242);
        heff_drop(v_ss_245);
        V v_x_2412 = v_field_2410;
        V v_t_2415;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_p_244, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_str0), heff_strAppend(heff_dup(v_x_2412), ((V)&g_heff_2esyntax_2epresyntax_2earmT_str1)));
        V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_str2), heff_strAppend(v_x_2412, v_t_2416));
        V v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2417}), heff_dup(v_t_2415)});
        V v_t_2421;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2420 = heff_dup(heff_field(v_p_244, 1));
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2421, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_2418}), v_t_2422});
      } else {
        heff_drop(v_field_2410);
        V v_e_2423 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_ss_245, v_end_242}));
        V v_t_2426;
        switch (heff_tag_of(v_p_244)) {
        case TAG_At: {
          V v_s_2425 = heff_dup(heff_field(v_p_244, 1));
          v_t_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        V v_t_2429;
        switch (heff_tag_of(v_e_2423)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_e_2423, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_e_2423);
        }
        V v_t_2430 = ({ V rv_1 = heff_get_n(v_t_2429, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2426, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_e_2423}), v_t_2430});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmT(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2earmT_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_247; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_247); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str0, 7, "recover");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str1, 3, "err");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_str2, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2etryScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryScope_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2etryScope(V v_t_240, V v_cx_241, V v_sp_242, V v_x4_243, V v_end_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkTry: {
    V v_err_245 = heff_field(v_x4_243, 0);
    V v_body_246 = heff_field(v_x4_243, 1);
    V v_h_247 = heff_field(v_x4_243, 2);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_248}), heff_dup(heff_rfield(v_cx_241, 3))});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str0)}), heff_dup(v_sp_242)});
    V v_t_2416;
    switch (heff_tag_of(v_err_245)) {
    case TAG_Nothing: {
      v_t_2416 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_ty_2411 = heff_field(v_err_245, 0);
      V v_t_2414;
      switch (heff_tag_of(v_ty_2411)) {
      case TAG_At: {
        V v_s_2413 = heff_field(v_ty_2411, 1);
        v_t_2414 = heff_dup(v_s_2413);
        break;
      }
      default: heff_nomatch(v_ty_2411);
      }
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENamed, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str1), heff_dup(v_ty_2411)}), v_t_2414});
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_err_245);
    }
    V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_cx_241, 4)), MK_INT(1LL));
    V v_t_2418 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), v_t_2417});
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_t_240, 0)), 3, (V[]){v_t_2418, heff_dup(v_body_246), heff_dup(v_end_244)}));
    V v_t_2425;
    switch (heff_tag_of(v_h_247)) {
    case TAG_MkCatchArm: {
      V v_b_2420 = heff_field(v_h_247, 0);
      V v_ss_2421 = heff_field(v_h_247, 1);
      V v_t_2422 = heff_intAdd(heff_take_field(v_cx_241, 4), MK_INT(1LL));
      V v_t_2423 = ({ V rv_4 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_cx_241, 15ULL, 5, shape_names__muts__loop__sp__depth, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2423, heff_dup(v_ss_2421), v_end_244}));
      v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_b_2420), v_t_2424}), heff_dup(v_sp_242)});
      break;
    }
    default: heff_nomatch(v_h_247);
    }
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2426})));
    V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2427));
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_str2)}), v_sp_242});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2430})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2etryScope(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str3, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str4, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str6, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str7, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str9, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str10, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str12, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str13, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str15, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str16, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str17, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str18, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str19, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str21, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str22, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str24, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str25, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str27, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str28, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str30, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str31, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str33, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str34, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str36, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str37, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str39, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str40, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str42, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str43, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str45, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str46, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str47, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str48, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str49, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str51, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str52, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str53, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str54, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str55, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str57, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str58, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str59, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str60, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str61, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str63, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str64, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str65, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str66, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str67, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str69, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str70, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str71, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str72, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str73, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str75, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str76, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str77, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str78, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str79, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str81, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str82, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str83, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str84, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str85, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str87, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str88, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str89, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str90, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str91, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str92, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str93, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str94, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str95, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str96, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str97, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str98, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str99, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str100, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str101, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str102, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str103, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str104, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str105, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str106, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str107, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str108, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str109, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str110, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str111, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str112, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str113, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str114, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str115, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str116, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str117, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str118, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str119, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str120, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str121, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str122, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str123, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str124, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str125, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str126, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str127, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str128, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str129, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str130, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str131, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str132, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str133, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str134, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str135, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str136, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str137, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str138, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str139, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str140, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str141, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str142, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str143, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str144, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str145, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str146, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str147, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str148, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str149, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str150, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str151, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str152, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str153, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str154, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str155, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str156, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str157, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str158, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str159, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str160, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str161, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str162, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str163, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str164, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str165, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str166, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str167, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str168, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str169, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str170, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str171, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str172, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str173, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str174, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str175, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str176, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str177, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str178, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str179, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str180, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str181, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str182, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str183, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str184, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str185, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str186, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str187, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str188, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str189, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str190, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str191, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str192, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str193, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str194, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str195, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str196, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str197, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str198, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str199, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str200, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str201, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str202, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str203, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str204, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str205, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str206, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str207, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str208, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str209, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str210, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str211, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str212, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str213, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str214, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str215, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str216, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str217, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str218, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str219, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str220, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str221, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str222, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str223, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str224, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str225, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str226, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str227, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str228, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str229, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str230, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str231, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str232, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str233, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str234, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str235, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str236, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str237, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str238, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str239, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str240, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str241, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str242, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str243, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str244, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str245, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str246, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str247, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str248, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str249, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str250, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str251, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str252, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str253, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str254, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str255, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str256, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str257, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str258, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str259, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str260, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str261, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str262, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str263, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str264, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str265, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str266, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str267, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str268, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str269, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str270, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str271, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str272, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str273, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str274, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str275, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str276, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str277, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str278, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str279, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str280, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str281, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str282, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str283, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str284, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str285, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str286, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str287, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str288, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str289, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str290, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str291, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str292, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str293, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str294, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str295, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str296, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str297, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str298, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str299, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str300, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str301, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str302, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str303, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str304, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str305, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str306, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str307, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str308, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str309, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str310, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str311, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str312, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str313, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str314, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str315, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str316, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str317, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str318, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str319, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str320, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str321, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str322, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str323, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str324, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str325, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str326, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str327, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str328, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str329, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str330, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str331, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str332, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str333, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str334, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str335, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str336, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str337, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str338, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_str339, 1, "_");
V g_heff_2esyntax_2epresyntax_2estmtT_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam3(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam4(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam5(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam6(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam7(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam8(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam9(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam10(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam11(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam12(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam13(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam14(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam15(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam16(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam17(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam18(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam19(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam20(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam21(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam22(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam23(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam24(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam25(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam26(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam27(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam28(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam29(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam30(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam31(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam32(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam33(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam34(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam35(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam36(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam37(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam38(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam39(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam40(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam41(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam42(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam43(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam44(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam45(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam46(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam47(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam48(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam49(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam50(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam51(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam52(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam53(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam54(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam55(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam56(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam57(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam58(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam59(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam60(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam61(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam62(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam63(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam64(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam65(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam66(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam67(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam68(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam69(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam70(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam71(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam72(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_lam73(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2estmtT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtT_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2estmtT(V v_t_240, V v_cx_241, V v_x3_242, V v_rest_243, V v_end_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_sp_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_StmtBind: {
      V v_x_247 = heff_field(v_x31_245, 0);
      V v_xsp_248 = heff_field(v_x31_245, 1);
      V v_x313_249 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      heff_drop_rec(v_sp_246, 2);
      switch (heff_tag_of(v_x313_249)) {
      case TAG_At: {
        V v_x3131_2410 = heff_dup(heff_field(v_x313_249, 0));
        V v_fsp_2411 = heff_dup(heff_field(v_x313_249, 1));
        switch (heff_tag_of(v_x3131_2410)) {
        case TAG_EVar: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_2413 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2413);
            V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str0), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str1)));
            V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str2), heff_strAppend(v_x_247, v_t_2414));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2415}), v_xsp_248});
          } else {
            heff_drop(v_t_2413);
            V v_t_2416 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2416}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2418 = v_t_2417.f[0];
              V v_field_2419 = v_t_2417.f[1];
              V v_x_2420 = v_field_2418;
              V v_y_2421 = v_field_2419;
              V v_rest_2422 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_2424 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2423}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2425 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2422)});
              V v_t_2428;
              switch (heff_tag_of(v_rest_2422)) {
              case TAG_At: {
                V v_s_2427 = heff_field(v_rest_2422, 1);
                heff_take_n(v_rest_2422, 2ULL, 2);
                v_t_2428 = v_s_2427;
                break;
              }
              default: heff_nomatch(v_rest_2422);
              }
              V v_t_2429 = ({ V rv_1 = heff_get_n(v_t_2428, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2429}), NTAG(TAG_Nil)});
              V v_t_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2421, v_t_2430})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2420; V a_2 = v_t_2431; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2420); r_; });
            }
          }
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_2433 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2433);
            V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str3), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str4)));
            V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str5), heff_strAppend(v_x_247, v_t_2434));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2435}), v_xsp_248});
          } else {
            heff_drop(v_t_2433);
            V v_t_2436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2436}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2438 = v_t_2437.f[0];
              V v_field_2439 = v_t_2437.f[1];
              V v_x_2440 = v_field_2438;
              V v_y_2441 = v_field_2439;
              V v_rest_2442 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_2444 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2443}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2445 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2442)});
              V v_t_2448;
              switch (heff_tag_of(v_rest_2442)) {
              case TAG_At: {
                V v_s_2447 = heff_field(v_rest_2442, 1);
                heff_take_n(v_rest_2442, 2ULL, 2);
                v_t_2448 = v_s_2447;
                break;
              }
              default: heff_nomatch(v_rest_2442);
              }
              V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2449}), NTAG(TAG_Nil)});
              V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2441, v_t_2450})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2440; V a_2 = v_t_2451; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
            }
          }
        }
        case TAG_ETag: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_2453 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2453);
            V v_t_2454 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str6), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str7)));
            V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str8), heff_strAppend(v_x_247, v_t_2454));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2455}), v_xsp_248});
          } else {
            heff_drop(v_t_2453);
            V v_t_2456 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2456}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2458 = v_t_2457.f[0];
              V v_field_2459 = v_t_2457.f[1];
              V v_x_2460 = v_field_2458;
              V v_y_2461 = v_field_2459;
              V v_rest_2462 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_2464 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2463}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2465 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2462)});
              V v_t_2468;
              switch (heff_tag_of(v_rest_2462)) {
              case TAG_At: {
                V v_s_2467 = heff_field(v_rest_2462, 1);
                heff_take_n(v_rest_2462, 2ULL, 2);
                v_t_2468 = v_s_2467;
                break;
              }
              default: heff_nomatch(v_rest_2462);
              }
              V v_t_2469 = ({ V rv_1 = heff_get_n(v_t_2468, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_t_2469}), NTAG(TAG_Nil)});
              V v_t_2471 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2464, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2461, v_t_2470})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2460; V a_2 = v_t_2471; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2460); r_; });
            }
          }
        }
        case TAG_EInt: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_2473 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2473);
            V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str9), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str10)));
            V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str11), heff_strAppend(v_x_247, v_t_2474));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2475}), v_xsp_248});
          } else {
            heff_drop(v_t_2473);
            V v_t_2476 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2477 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2476}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2478 = v_t_2477.f[0];
              V v_field_2479 = v_t_2477.f[1];
              V v_x_2480 = v_field_2478;
              V v_y_2481 = v_field_2479;
              V v_rest_2482 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_2483 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_2484 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2483}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_2485 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_2482)});
              V v_t_2488;
              switch (heff_tag_of(v_rest_2482)) {
              case TAG_At: {
                V v_s_2487 = heff_field(v_rest_2482, 1);
                heff_take_n(v_rest_2482, 2ULL, 2);
                v_t_2488 = v_s_2487;
                break;
              }
              default: heff_nomatch(v_rest_2482);
              }
              V v_t_2489 = ({ V rv_1 = heff_get_n(v_t_2488, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2485, v_t_2489}), NTAG(TAG_Nil)});
              V v_t_2491 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2484, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2481, v_t_2490})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_2480; V a_2 = v_t_2491; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2480); r_; });
            }
          }
        }
        case TAG_EFloat: {
          heff_take_na(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_2493 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_2493);
            V v_t_2494 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str12), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str13)));
            V v_t_2495 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str14), heff_strAppend(v_x_247, v_t_2494));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2495}), v_xsp_248});
          } else {
            heff_drop(v_t_2493);
            V v_t_2496 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2496}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_2498 = v_t_2497.f[0];
              V v_field_2499 = v_t_2497.f[1];
              V v_x_24100 = v_field_2498;
              V v_y_24101 = v_field_2499;
              V v_rest_24102 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24103 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24104 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24103}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24105 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24102)});
              V v_t_24108;
              switch (heff_tag_of(v_rest_24102)) {
              case TAG_At: {
                V v_s_24107 = heff_field(v_rest_24102, 1);
                heff_take_n(v_rest_24102, 2ULL, 2);
                v_t_24108 = v_s_24107;
                break;
              }
              default: heff_nomatch(v_rest_24102);
              }
              V v_t_24109 = ({ V rv_1 = heff_get_n(v_t_24108, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24105, v_t_24109}), NTAG(TAG_Nil)});
              V v_t_24111 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24104, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24101, v_t_24110})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24100; V a_2 = v_t_24111; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24100); r_; });
            }
          }
        }
        case TAG_EString: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24113 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24113);
            V v_t_24114 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str15), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str16)));
            V v_t_24115 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str17), heff_strAppend(v_x_247, v_t_24114));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24115}), v_xsp_248});
          } else {
            heff_drop(v_t_24113);
            V v_t_24116 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24116}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24118 = v_t_24117.f[0];
              V v_field_24119 = v_t_24117.f[1];
              V v_x_24120 = v_field_24118;
              V v_y_24121 = v_field_24119;
              V v_rest_24122 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24123 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24124 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24123}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24125 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24122)});
              V v_t_24128;
              switch (heff_tag_of(v_rest_24122)) {
              case TAG_At: {
                V v_s_24127 = heff_field(v_rest_24122, 1);
                heff_take_n(v_rest_24122, 2ULL, 2);
                v_t_24128 = v_s_24127;
                break;
              }
              default: heff_nomatch(v_rest_24122);
              }
              V v_t_24129 = ({ V rv_1 = heff_get_n(v_t_24128, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24125, v_t_24129}), NTAG(TAG_Nil)});
              V v_t_24131 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24124, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24121, v_t_24130})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24120; V a_2 = v_t_24131; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24120); r_; });
            }
          }
        }
        case TAG_EBinary: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24133 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24133);
            V v_t_24134 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str18), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str19)));
            V v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str20), heff_strAppend(v_x_247, v_t_24134));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24135}), v_xsp_248});
          } else {
            heff_drop(v_t_24133);
            V v_t_24136 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24137 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24136}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24138 = v_t_24137.f[0];
              V v_field_24139 = v_t_24137.f[1];
              V v_x_24140 = v_field_24138;
              V v_y_24141 = v_field_24139;
              V v_rest_24142 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24143 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24144 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24143}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24145 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24142)});
              V v_t_24148;
              switch (heff_tag_of(v_rest_24142)) {
              case TAG_At: {
                V v_s_24147 = heff_field(v_rest_24142, 1);
                heff_take_n(v_rest_24142, 2ULL, 2);
                v_t_24148 = v_s_24147;
                break;
              }
              default: heff_nomatch(v_rest_24142);
              }
              V v_t_24149 = ({ V rv_1 = heff_get_n(v_t_24148, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24145, v_t_24149}), NTAG(TAG_Nil)});
              V v_t_24151 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24144, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24141, v_t_24150})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24140; V a_2 = v_t_24151; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24140); r_; });
            }
          }
        }
        case TAG_ERune: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24153 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24153) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24153);
            V v_t_24154 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str21), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str22)));
            V v_t_24155 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str23), heff_strAppend(v_x_247, v_t_24154));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24155}), v_xsp_248});
          } else {
            heff_drop(v_t_24153);
            V v_t_24156 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24157 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24156}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24158 = v_t_24157.f[0];
              V v_field_24159 = v_t_24157.f[1];
              V v_x_24160 = v_field_24158;
              V v_y_24161 = v_field_24159;
              V v_rest_24162 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24163 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24164 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24163}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24165 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24162)});
              V v_t_24168;
              switch (heff_tag_of(v_rest_24162)) {
              case TAG_At: {
                V v_s_24167 = heff_field(v_rest_24162, 1);
                heff_take_n(v_rest_24162, 2ULL, 2);
                v_t_24168 = v_s_24167;
                break;
              }
              default: heff_nomatch(v_rest_24162);
              }
              V v_t_24169 = ({ V rv_1 = heff_get_n(v_t_24168, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24170 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24165, v_t_24169}), NTAG(TAG_Nil)});
              V v_t_24171 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24164, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24161, v_t_24170})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24160; V a_2 = v_t_24171; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24160); r_; });
            }
          }
        }
        case TAG_EWord: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24173 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24173) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24173);
            V v_t_24174 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str24), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str25)));
            V v_t_24175 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str26), heff_strAppend(v_x_247, v_t_24174));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24175}), v_xsp_248});
          } else {
            heff_drop(v_t_24173);
            V v_t_24176 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24177 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24176}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24178 = v_t_24177.f[0];
              V v_field_24179 = v_t_24177.f[1];
              V v_x_24180 = v_field_24178;
              V v_y_24181 = v_field_24179;
              V v_rest_24182 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24183 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24184 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24183}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24185 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24182)});
              V v_t_24188;
              switch (heff_tag_of(v_rest_24182)) {
              case TAG_At: {
                V v_s_24187 = heff_field(v_rest_24182, 1);
                heff_take_n(v_rest_24182, 2ULL, 2);
                v_t_24188 = v_s_24187;
                break;
              }
              default: heff_nomatch(v_rest_24182);
              }
              V v_t_24189 = ({ V rv_1 = heff_get_n(v_t_24188, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24190 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24185, v_t_24189}), NTAG(TAG_Nil)});
              V v_t_24191 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24184, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24181, v_t_24190})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24180; V a_2 = v_t_24191; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24180); r_; });
            }
          }
        }
        case TAG_EApp: {
          V v_ru_24x3131_2410_24EApp = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24194 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24194) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EApp, 2);
            heff_drop(v_t_24194);
            V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str27), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str28)));
            V v_t_24196 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str29), heff_strAppend(v_x_247, v_t_24195));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24196}), v_xsp_248});
          } else {
            heff_drop(v_t_24194);
            V v_t_24197 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24198 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24197}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24199 = v_t_24198.f[0];
              V v_field_24200 = v_t_24198.f[1];
              V v_x_24201 = v_field_24199;
              V v_y_24202 = v_field_24200;
              V v_rest_24203 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24204 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24205 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24204}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24206 = heff_tag_at_n(v_ru_24x3131_2410_24EApp, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24203)});
              V v_t_24209;
              switch (heff_tag_of(v_rest_24203)) {
              case TAG_At: {
                V v_s_24208 = heff_field(v_rest_24203, 1);
                heff_take_n(v_rest_24203, 2ULL, 2);
                v_t_24209 = v_s_24208;
                break;
              }
              default: heff_nomatch(v_rest_24203);
              }
              V v_t_24210 = ({ V rv_1 = heff_get_n(v_t_24209, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24211 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24206, v_t_24210}), NTAG(TAG_Nil)});
              V v_t_24212 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24205, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24202, v_t_24211})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24201; V a_2 = v_t_24212; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24201); r_; });
            }
          }
        }
        case TAG_EProject: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24214 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24214) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24214);
            V v_t_24215 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str30), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str31)));
            V v_t_24216 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str32), heff_strAppend(v_x_247, v_t_24215));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24216}), v_xsp_248});
          } else {
            heff_drop(v_t_24214);
            V v_t_24217 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24218 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24217}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24219 = v_t_24218.f[0];
              V v_field_24220 = v_t_24218.f[1];
              V v_x_24221 = v_field_24219;
              V v_y_24222 = v_field_24220;
              V v_rest_24223 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24224 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24225 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24224}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24226 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24223)});
              V v_t_24229;
              switch (heff_tag_of(v_rest_24223)) {
              case TAG_At: {
                V v_s_24228 = heff_field(v_rest_24223, 1);
                heff_take_n(v_rest_24223, 2ULL, 2);
                v_t_24229 = v_s_24228;
                break;
              }
              default: heff_nomatch(v_rest_24223);
              }
              V v_t_24230 = ({ V rv_1 = heff_get_n(v_t_24229, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24226, v_t_24230}), NTAG(TAG_Nil)});
              V v_t_24232 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24225, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24222, v_t_24231})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24221; V a_2 = v_t_24232; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24221); r_; });
            }
          }
        }
        case TAG_ENamed: {
          V v_ru_24x3131_2410_24ENamed = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24235 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24235) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ENamed, 2);
            heff_drop(v_t_24235);
            V v_t_24236 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str33), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str34)));
            V v_t_24237 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str35), heff_strAppend(v_x_247, v_t_24236));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24237}), v_xsp_248});
          } else {
            heff_drop(v_t_24235);
            V v_t_24238 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24239 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24238}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24240 = v_t_24239.f[0];
              V v_field_24241 = v_t_24239.f[1];
              V v_x_24242 = v_field_24240;
              V v_y_24243 = v_field_24241;
              V v_rest_24244 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24245 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24246 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24245}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24247 = heff_tag_at_n(v_ru_24x3131_2410_24ENamed, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24244)});
              V v_t_24250;
              switch (heff_tag_of(v_rest_24244)) {
              case TAG_At: {
                V v_s_24249 = heff_field(v_rest_24244, 1);
                heff_take_n(v_rest_24244, 2ULL, 2);
                v_t_24250 = v_s_24249;
                break;
              }
              default: heff_nomatch(v_rest_24244);
              }
              V v_t_24251 = ({ V rv_1 = heff_get_n(v_t_24250, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24252 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24247, v_t_24251}), NTAG(TAG_Nil)});
              V v_t_24253 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24246, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24243, v_t_24252})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24242; V a_2 = v_t_24253; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24242); r_; });
            }
          }
        }
        case TAG_EPi: {
          V v_ru_24x3131_2410_24EPi = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24256 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24256) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EPi, 2);
            heff_drop(v_t_24256);
            V v_t_24257 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str36), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str37)));
            V v_t_24258 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str38), heff_strAppend(v_x_247, v_t_24257));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24258}), v_xsp_248});
          } else {
            heff_drop(v_t_24256);
            V v_t_24259 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24260 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24259}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24261 = v_t_24260.f[0];
              V v_field_24262 = v_t_24260.f[1];
              V v_x_24263 = v_field_24261;
              V v_y_24264 = v_field_24262;
              V v_rest_24265 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24266 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24267 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24266}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24268 = heff_tag_at_n(v_ru_24x3131_2410_24EPi, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24265)});
              V v_t_24271;
              switch (heff_tag_of(v_rest_24265)) {
              case TAG_At: {
                V v_s_24270 = heff_field(v_rest_24265, 1);
                heff_take_n(v_rest_24265, 2ULL, 2);
                v_t_24271 = v_s_24270;
                break;
              }
              default: heff_nomatch(v_rest_24265);
              }
              V v_t_24272 = ({ V rv_1 = heff_get_n(v_t_24271, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24273 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24268, v_t_24272}), NTAG(TAG_Nil)});
              V v_t_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24267, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24264, v_t_24273})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24263; V a_2 = v_t_24274; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24263); r_; });
            }
          }
        }
        case TAG_ELam: {
          V v_ru_24x3131_2410_24ELam = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24277 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24277) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELam, 2);
            heff_drop(v_t_24277);
            V v_t_24278 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str39), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str40)));
            V v_t_24279 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str41), heff_strAppend(v_x_247, v_t_24278));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24279}), v_xsp_248});
          } else {
            heff_drop(v_t_24277);
            V v_t_24280 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24281 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24280}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24282 = v_t_24281.f[0];
              V v_field_24283 = v_t_24281.f[1];
              V v_x_24284 = v_field_24282;
              V v_y_24285 = v_field_24283;
              V v_rest_24286 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24287 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24288 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24287}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24289 = heff_tag_at_n(v_ru_24x3131_2410_24ELam, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24286)});
              V v_t_24292;
              switch (heff_tag_of(v_rest_24286)) {
              case TAG_At: {
                V v_s_24291 = heff_field(v_rest_24286, 1);
                heff_take_n(v_rest_24286, 2ULL, 2);
                v_t_24292 = v_s_24291;
                break;
              }
              default: heff_nomatch(v_rest_24286);
              }
              V v_t_24293 = ({ V rv_1 = heff_get_n(v_t_24292, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24294 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24289, v_t_24293}), NTAG(TAG_Nil)});
              V v_t_24295 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24288, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24285, v_t_24294})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24284; V a_2 = v_t_24295; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24284); r_; });
            }
          }
        }
        case TAG_EAnn: {
          V v_ru_24x3131_2410_24EAnn = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24298 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24298) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EAnn, 2);
            heff_drop(v_t_24298);
            V v_t_24299 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str42), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str43)));
            V v_t_24300 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str44), heff_strAppend(v_x_247, v_t_24299));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24300}), v_xsp_248});
          } else {
            heff_drop(v_t_24298);
            V v_t_24301 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24302 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24301}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24303 = v_t_24302.f[0];
              V v_field_24304 = v_t_24302.f[1];
              V v_x_24305 = v_field_24303;
              V v_y_24306 = v_field_24304;
              V v_rest_24307 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24308 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24309 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24308}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24310 = heff_tag_at_n(v_ru_24x3131_2410_24EAnn, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24307)});
              V v_t_24313;
              switch (heff_tag_of(v_rest_24307)) {
              case TAG_At: {
                V v_s_24312 = heff_field(v_rest_24307, 1);
                heff_take_n(v_rest_24307, 2ULL, 2);
                v_t_24313 = v_s_24312;
                break;
              }
              default: heff_nomatch(v_rest_24307);
              }
              V v_t_24314 = ({ V rv_1 = heff_get_n(v_t_24313, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24315 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24310, v_t_24314}), NTAG(TAG_Nil)});
              V v_t_24316 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24309, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24306, v_t_24315})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24305; V a_2 = v_t_24316; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24305); r_; });
            }
          }
        }
        case TAG_ESpec: {
          heff_take_n(v_x3131_2410, 0ULL, 4);
          heff_drop(v_fsp_2411);
          V v_t_24321 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24321) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24321);
            V v_t_24322 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str45), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str46)));
            V v_t_24323 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str47), heff_strAppend(v_x_247, v_t_24322));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24323}), v_xsp_248});
          } else {
            heff_drop(v_t_24321);
            V v_t_24324 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24325 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24324}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24326 = v_t_24325.f[0];
              V v_field_24327 = v_t_24325.f[1];
              V v_x_24328 = v_field_24326;
              V v_y_24329 = v_field_24327;
              V v_rest_24330 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24331 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24332 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24331}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24333 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24330)});
              V v_t_24336;
              switch (heff_tag_of(v_rest_24330)) {
              case TAG_At: {
                V v_s_24335 = heff_field(v_rest_24330, 1);
                heff_take_n(v_rest_24330, 2ULL, 2);
                v_t_24336 = v_s_24335;
                break;
              }
              default: heff_nomatch(v_rest_24330);
              }
              V v_t_24337 = ({ V rv_1 = heff_get_n(v_t_24336, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24338 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24333, v_t_24337}), NTAG(TAG_Nil)});
              V v_t_24339 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24332, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24329, v_t_24338})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24328; V a_2 = v_t_24339; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24328); r_; });
            }
          }
        }
        case TAG_ESig: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24341 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24341) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24341);
            V v_t_24342 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str48), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str49)));
            V v_t_24343 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str50), heff_strAppend(v_x_247, v_t_24342));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24343}), v_xsp_248});
          } else {
            heff_drop(v_t_24341);
            V v_t_24344 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24345 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24344}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24346 = v_t_24345.f[0];
              V v_field_24347 = v_t_24345.f[1];
              V v_x_24348 = v_field_24346;
              V v_y_24349 = v_field_24347;
              V v_rest_24350 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24351 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24352 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24351}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24353 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24350)});
              V v_t_24356;
              switch (heff_tag_of(v_rest_24350)) {
              case TAG_At: {
                V v_s_24355 = heff_field(v_rest_24350, 1);
                heff_take_n(v_rest_24350, 2ULL, 2);
                v_t_24356 = v_s_24355;
                break;
              }
              default: heff_nomatch(v_rest_24350);
              }
              V v_t_24357 = ({ V rv_1 = heff_get_n(v_t_24356, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24358 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24353, v_t_24357}), NTAG(TAG_Nil)});
              V v_t_24359 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24352, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24349, v_t_24358})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24348; V a_2 = v_t_24359; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24348); r_; });
            }
          }
        }
        case TAG_ESum: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24361 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24361) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24361);
            V v_t_24362 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str51), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str52)));
            V v_t_24363 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str53), heff_strAppend(v_x_247, v_t_24362));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24363}), v_xsp_248});
          } else {
            heff_drop(v_t_24361);
            V v_t_24364 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24365 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24364}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24366 = v_t_24365.f[0];
              V v_field_24367 = v_t_24365.f[1];
              V v_x_24368 = v_field_24366;
              V v_y_24369 = v_field_24367;
              V v_rest_24370 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24371 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24372 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24371}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24373 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24370)});
              V v_t_24376;
              switch (heff_tag_of(v_rest_24370)) {
              case TAG_At: {
                V v_s_24375 = heff_field(v_rest_24370, 1);
                heff_take_n(v_rest_24370, 2ULL, 2);
                v_t_24376 = v_s_24375;
                break;
              }
              default: heff_nomatch(v_rest_24370);
              }
              V v_t_24377 = ({ V rv_1 = heff_get_n(v_t_24376, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24378 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24373, v_t_24377}), NTAG(TAG_Nil)});
              V v_t_24379 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24372, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24369, v_t_24378})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24368; V a_2 = v_t_24379; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24368); r_; });
            }
          }
        }
        case TAG_EStruct: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24381 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24381) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24381);
            V v_t_24382 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str54), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str55)));
            V v_t_24383 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str56), heff_strAppend(v_x_247, v_t_24382));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24383}), v_xsp_248});
          } else {
            heff_drop(v_t_24381);
            V v_t_24384 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24385 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24384}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24386 = v_t_24385.f[0];
              V v_field_24387 = v_t_24385.f[1];
              V v_x_24388 = v_field_24386;
              V v_y_24389 = v_field_24387;
              V v_rest_24390 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24391 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24392 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24391}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24393 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24390)});
              V v_t_24396;
              switch (heff_tag_of(v_rest_24390)) {
              case TAG_At: {
                V v_s_24395 = heff_field(v_rest_24390, 1);
                heff_take_n(v_rest_24390, 2ULL, 2);
                v_t_24396 = v_s_24395;
                break;
              }
              default: heff_nomatch(v_rest_24390);
              }
              V v_t_24397 = ({ V rv_1 = heff_get_n(v_t_24396, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24398 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24393, v_t_24397}), NTAG(TAG_Nil)});
              V v_t_24399 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24392, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24389, v_t_24398})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24388; V a_2 = v_t_24399; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24388); r_; });
            }
          }
        }
        case TAG_EUpdate: {
          V v_ru_24x3131_2410_24EUpdate = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24402 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24402) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EUpdate, 2);
            heff_drop(v_t_24402);
            V v_t_24403 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str57), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str58)));
            V v_t_24404 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str59), heff_strAppend(v_x_247, v_t_24403));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24404}), v_xsp_248});
          } else {
            heff_drop(v_t_24402);
            V v_t_24405 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24406 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24405}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24407 = v_t_24406.f[0];
              V v_field_24408 = v_t_24406.f[1];
              V v_x_24409 = v_field_24407;
              V v_y_24410 = v_field_24408;
              V v_rest_24411 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24412 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24413 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24412}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24414 = heff_tag_at_n(v_ru_24x3131_2410_24EUpdate, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24411)});
              V v_t_24417;
              switch (heff_tag_of(v_rest_24411)) {
              case TAG_At: {
                V v_s_24416 = heff_field(v_rest_24411, 1);
                heff_take_n(v_rest_24411, 2ULL, 2);
                v_t_24417 = v_s_24416;
                break;
              }
              default: heff_nomatch(v_rest_24411);
              }
              V v_t_24418 = ({ V rv_1 = heff_get_n(v_t_24417, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24414, v_t_24418}), NTAG(TAG_Nil)});
              V v_t_24420 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24413, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24410, v_t_24419})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24409; V a_2 = v_t_24420; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24409); r_; });
            }
          }
        }
        case TAG_EMatch: {
          V v_ru_24x3131_2410_24EMatch = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24423 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24423) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EMatch, 2);
            heff_drop(v_t_24423);
            V v_t_24424 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str60), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str61)));
            V v_t_24425 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str62), heff_strAppend(v_x_247, v_t_24424));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24425}), v_xsp_248});
          } else {
            heff_drop(v_t_24423);
            V v_t_24426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24426}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24428 = v_t_24427.f[0];
              V v_field_24429 = v_t_24427.f[1];
              V v_x_24430 = v_field_24428;
              V v_y_24431 = v_field_24429;
              V v_rest_24432 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24433 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24434 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24433}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24435 = heff_tag_at_n(v_ru_24x3131_2410_24EMatch, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24432)});
              V v_t_24438;
              switch (heff_tag_of(v_rest_24432)) {
              case TAG_At: {
                V v_s_24437 = heff_field(v_rest_24432, 1);
                heff_take_n(v_rest_24432, 2ULL, 2);
                v_t_24438 = v_s_24437;
                break;
              }
              default: heff_nomatch(v_rest_24432);
              }
              V v_t_24439 = ({ V rv_1 = heff_get_n(v_t_24438, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24435, v_t_24439}), NTAG(TAG_Nil)});
              V v_t_24441 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24434, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24431, v_t_24440})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24430; V a_2 = v_t_24441; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24430); r_; });
            }
          }
        }
        case TAG_ELetIn: {
          V v_ru_24x3131_2410_24ELetIn = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24444 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24444) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELetIn, 2);
            heff_drop(v_t_24444);
            V v_t_24445 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str63), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str64)));
            V v_t_24446 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str65), heff_strAppend(v_x_247, v_t_24445));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24446}), v_xsp_248});
          } else {
            heff_drop(v_t_24444);
            V v_t_24447 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24448 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24447}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24449 = v_t_24448.f[0];
              V v_field_24450 = v_t_24448.f[1];
              V v_x_24451 = v_field_24449;
              V v_y_24452 = v_field_24450;
              V v_rest_24453 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24454 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24455 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24454}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24456 = heff_tag_at_n(v_ru_24x3131_2410_24ELetIn, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24453)});
              V v_t_24459;
              switch (heff_tag_of(v_rest_24453)) {
              case TAG_At: {
                V v_s_24458 = heff_field(v_rest_24453, 1);
                heff_take_n(v_rest_24453, 2ULL, 2);
                v_t_24459 = v_s_24458;
                break;
              }
              default: heff_nomatch(v_rest_24453);
              }
              V v_t_24460 = ({ V rv_1 = heff_get_n(v_t_24459, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24456, v_t_24460}), NTAG(TAG_Nil)});
              V v_t_24462 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24455, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24452, v_t_24461})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24451; V a_2 = v_t_24462; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24451); r_; });
            }
          }
        }
        case TAG_EDo: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24464 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24464) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24464);
            V v_t_24465 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str66), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str67)));
            V v_t_24466 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str68), heff_strAppend(v_x_247, v_t_24465));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24466}), v_xsp_248});
          } else {
            heff_drop(v_t_24464);
            V v_t_24467 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24468 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24467}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24469 = v_t_24468.f[0];
              V v_field_24470 = v_t_24468.f[1];
              V v_x_24471 = v_field_24469;
              V v_y_24472 = v_field_24470;
              V v_rest_24473 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24474 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24475 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24474}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24476 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24473)});
              V v_t_24479;
              switch (heff_tag_of(v_rest_24473)) {
              case TAG_At: {
                V v_s_24478 = heff_field(v_rest_24473, 1);
                heff_take_n(v_rest_24473, 2ULL, 2);
                v_t_24479 = v_s_24478;
                break;
              }
              default: heff_nomatch(v_rest_24473);
              }
              V v_t_24480 = ({ V rv_1 = heff_get_n(v_t_24479, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24476, v_t_24480}), NTAG(TAG_Nil)});
              V v_t_24482 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24475, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24472, v_t_24481})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24471; V a_2 = v_t_24482; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24471); r_; });
            }
          }
        }
        case TAG_ELocal: {
          V v_ru_24x3131_2410_24ELocal = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24485 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24485) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24ELocal, 2);
            heff_drop(v_t_24485);
            V v_t_24486 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str69), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str70)));
            V v_t_24487 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str71), heff_strAppend(v_x_247, v_t_24486));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24487}), v_xsp_248});
          } else {
            heff_drop(v_t_24485);
            V v_t_24488 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24489 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24488}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24490 = v_t_24489.f[0];
              V v_field_24491 = v_t_24489.f[1];
              V v_x_24492 = v_field_24490;
              V v_y_24493 = v_field_24491;
              V v_rest_24494 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24495 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24496 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24495}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24497 = heff_tag_at_n(v_ru_24x3131_2410_24ELocal, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24494)});
              V v_t_24500;
              switch (heff_tag_of(v_rest_24494)) {
              case TAG_At: {
                V v_s_24499 = heff_field(v_rest_24494, 1);
                heff_take_n(v_rest_24494, 2ULL, 2);
                v_t_24500 = v_s_24499;
                break;
              }
              default: heff_nomatch(v_rest_24494);
              }
              V v_t_24501 = ({ V rv_1 = heff_get_n(v_t_24500, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24502 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24497, v_t_24501}), NTAG(TAG_Nil)});
              V v_t_24503 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24496, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24493, v_t_24502})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24492; V a_2 = v_t_24503; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24492); r_; });
            }
          }
        }
        case TAG_EInvalid: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24505 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24505) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24505);
            V v_t_24506 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str72), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str73)));
            V v_t_24507 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str74), heff_strAppend(v_x_247, v_t_24506));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24507}), v_xsp_248});
          } else {
            heff_drop(v_t_24505);
            V v_t_24508 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24509 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24508}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24510 = v_t_24509.f[0];
              V v_field_24511 = v_t_24509.f[1];
              V v_x_24512 = v_field_24510;
              V v_y_24513 = v_field_24511;
              V v_rest_24514 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24515 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24516 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24515}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24517 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24514)});
              V v_t_24520;
              switch (heff_tag_of(v_rest_24514)) {
              case TAG_At: {
                V v_s_24519 = heff_field(v_rest_24514, 1);
                heff_take_n(v_rest_24514, 2ULL, 2);
                v_t_24520 = v_s_24519;
                break;
              }
              default: heff_nomatch(v_rest_24514);
              }
              V v_t_24521 = ({ V rv_1 = heff_get_n(v_t_24520, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24522 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24517, v_t_24521}), NTAG(TAG_Nil)});
              V v_t_24523 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24516, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24513, v_t_24522})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24512; V a_2 = v_t_24523; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24512); r_; });
            }
          }
        }
        case TAG_EAssign: {
          heff_take_n(v_x3131_2410, 0ULL, 3);
          heff_drop(v_fsp_2411);
          V v_t_24527 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24527) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24527);
            V v_t_24528 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str75), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str76)));
            V v_t_24529 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str77), heff_strAppend(v_x_247, v_t_24528));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24529}), v_xsp_248});
          } else {
            heff_drop(v_t_24527);
            V v_t_24530 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24531 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24530}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24532 = v_t_24531.f[0];
              V v_field_24533 = v_t_24531.f[1];
              V v_x_24534 = v_field_24532;
              V v_y_24535 = v_field_24533;
              V v_rest_24536 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24537 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24538 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24537}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24539 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24536)});
              V v_t_24542;
              switch (heff_tag_of(v_rest_24536)) {
              case TAG_At: {
                V v_s_24541 = heff_field(v_rest_24536, 1);
                heff_take_n(v_rest_24536, 2ULL, 2);
                v_t_24542 = v_s_24541;
                break;
              }
              default: heff_nomatch(v_rest_24536);
              }
              V v_t_24543 = ({ V rv_1 = heff_get_n(v_t_24542, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24544 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24539, v_t_24543}), NTAG(TAG_Nil)});
              V v_t_24545 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24538, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24535, v_t_24544})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24534; V a_2 = v_t_24545; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24534); r_; });
            }
          }
        }
        case TAG_EWhile: {
          V v_ru_24x3131_2410_24EWhile = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24548 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24548) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EWhile, 2);
            heff_drop(v_t_24548);
            V v_t_24549 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str78), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str79)));
            V v_t_24550 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str80), heff_strAppend(v_x_247, v_t_24549));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24550}), v_xsp_248});
          } else {
            heff_drop(v_t_24548);
            V v_t_24551 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24552 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24551}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24553 = v_t_24552.f[0];
              V v_field_24554 = v_t_24552.f[1];
              V v_x_24555 = v_field_24553;
              V v_y_24556 = v_field_24554;
              V v_rest_24557 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24558 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24559 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24558}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24560 = heff_tag_at_n(v_ru_24x3131_2410_24EWhile, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24557)});
              V v_t_24563;
              switch (heff_tag_of(v_rest_24557)) {
              case TAG_At: {
                V v_s_24562 = heff_field(v_rest_24557, 1);
                heff_take_n(v_rest_24557, 2ULL, 2);
                v_t_24563 = v_s_24562;
                break;
              }
              default: heff_nomatch(v_rest_24557);
              }
              V v_t_24564 = ({ V rv_1 = heff_get_n(v_t_24563, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24565 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24560, v_t_24564}), NTAG(TAG_Nil)});
              V v_t_24566 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24559, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24556, v_t_24565})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24555; V a_2 = v_t_24566; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24555); r_; });
            }
          }
        }
        case TAG_EFor: {
          V v_q_24567 = heff_field(v_x3131_2410, 0);
          V v_c_24568 = heff_field(v_x3131_2410, 1);
          V v_body_24569 = heff_field(v_x3131_2410, 2);
          heff_take_n(v_x3131_2410, 7ULL, 3);
          heff_drop_tag(v_x313_249, 2);
          V v_t_24570 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24570) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop(v_fsp_2411);
            heff_drop(v_q_24567);
            heff_drop(v_c_24568);
            heff_drop(v_body_24569);
            heff_drop(v_t_24570);
            V v_t_24571 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str81), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str82)));
            V v_t_24572 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str83), heff_strAppend(v_x_247, v_t_24571));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24572}), v_xsp_248});
          } else {
            heff_drop(v_t_24570);
            V v_t_24573 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_247}), v_xsp_248});
            V v_t_24574 = (g_heff_2esyntax_2epresyntax_2egathered(v_t_24573, v_fsp_2411, v_q_24567, v_c_24568, v_body_24569));
            V v_t_24575 = (g_prelude_2e_2b_2b(v_t_24574, v_rest_243));
            return heff_tail(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_t_24575, v_end_244});
          }
        }
        case TAG_EIfThen: {
          V v_ru_24x3131_2410_24EIfThen = heff_take_reuse_n(v_x3131_2410, 0ULL, 2);
          heff_drop(v_fsp_2411);
          V v_t_24578 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24578) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop_cell(v_ru_24x3131_2410_24EIfThen, 2);
            heff_drop(v_t_24578);
            V v_t_24579 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str84), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str85)));
            V v_t_24580 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str86), heff_strAppend(v_x_247, v_t_24579));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24580}), v_xsp_248});
          } else {
            heff_drop(v_t_24578);
            V v_t_24581 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24582 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24581}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24583 = v_t_24582.f[0];
              V v_field_24584 = v_t_24582.f[1];
              V v_x_24585 = v_field_24583;
              V v_y_24586 = v_field_24584;
              V v_rest_24587 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24588 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24589 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24588}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24590 = heff_tag_at_n(v_ru_24x3131_2410_24EIfThen, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24587)});
              V v_t_24593;
              switch (heff_tag_of(v_rest_24587)) {
              case TAG_At: {
                V v_s_24592 = heff_field(v_rest_24587, 1);
                heff_take_n(v_rest_24587, 2ULL, 2);
                v_t_24593 = v_s_24592;
                break;
              }
              default: heff_nomatch(v_rest_24587);
              }
              V v_t_24594 = ({ V rv_1 = heff_get_n(v_t_24593, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24595 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24590, v_t_24594}), NTAG(TAG_Nil)});
              V v_t_24596 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24589, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24586, v_t_24595})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24585; V a_2 = v_t_24596; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24585); r_; });
            }
          }
        }
        case TAG_EBreak: {
          heff_drop(v_fsp_2411);
          V v_t_24597 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24597) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24597);
            V v_t_24598 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str87), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str88)));
            V v_t_24599 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str89), heff_strAppend(v_x_247, v_t_24598));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24599}), v_xsp_248});
          } else {
            heff_drop(v_t_24597);
            V v_t_24600 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24601 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24600}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24602 = v_t_24601.f[0];
              V v_field_24603 = v_t_24601.f[1];
              V v_x_24604 = v_field_24602;
              V v_y_24605 = v_field_24603;
              V v_rest_24606 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24607 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24608 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24607}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24609 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24606)});
              V v_t_24612;
              switch (heff_tag_of(v_rest_24606)) {
              case TAG_At: {
                V v_s_24611 = heff_field(v_rest_24606, 1);
                heff_take_n(v_rest_24606, 2ULL, 2);
                v_t_24612 = v_s_24611;
                break;
              }
              default: heff_nomatch(v_rest_24606);
              }
              V v_t_24613 = ({ V rv_1 = heff_get_n(v_t_24612, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24614 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24609, v_t_24613}), NTAG(TAG_Nil)});
              V v_t_24615 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24608, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24605, v_t_24614})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24604; V a_2 = v_t_24615; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24604); r_; });
            }
          }
        }
        case TAG_EContinue: {
          heff_drop(v_fsp_2411);
          V v_t_24616 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24616) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24616);
            V v_t_24617 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str90), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str91)));
            V v_t_24618 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str92), heff_strAppend(v_x_247, v_t_24617));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24618}), v_xsp_248});
          } else {
            heff_drop(v_t_24616);
            V v_t_24619 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24620 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24619}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24621 = v_t_24620.f[0];
              V v_field_24622 = v_t_24620.f[1];
              V v_x_24623 = v_field_24621;
              V v_y_24624 = v_field_24622;
              V v_rest_24625 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24626 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24627 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24626}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24628 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24625)});
              V v_t_24631;
              switch (heff_tag_of(v_rest_24625)) {
              case TAG_At: {
                V v_s_24630 = heff_field(v_rest_24625, 1);
                heff_take_n(v_rest_24625, 2ULL, 2);
                v_t_24631 = v_s_24630;
                break;
              }
              default: heff_nomatch(v_rest_24625);
              }
              V v_t_24632 = ({ V rv_1 = heff_get_n(v_t_24631, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24633 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24628, v_t_24632}), NTAG(TAG_Nil)});
              V v_t_24634 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24627, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24624, v_t_24633})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24623; V a_2 = v_t_24634; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24623); r_; });
            }
          }
        }
        case TAG_EReturn: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24636 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24636) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24636);
            V v_t_24637 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str93), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str94)));
            V v_t_24638 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str95), heff_strAppend(v_x_247, v_t_24637));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24638}), v_xsp_248});
          } else {
            heff_drop(v_t_24636);
            V v_t_24639 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24640 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24639}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24641 = v_t_24640.f[0];
              V v_field_24642 = v_t_24640.f[1];
              V v_x_24643 = v_field_24641;
              V v_y_24644 = v_field_24642;
              V v_rest_24645 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24646 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24647 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24646}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24648 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24645)});
              V v_t_24651;
              switch (heff_tag_of(v_rest_24645)) {
              case TAG_At: {
                V v_s_24650 = heff_field(v_rest_24645, 1);
                heff_take_n(v_rest_24645, 2ULL, 2);
                v_t_24651 = v_s_24650;
                break;
              }
              default: heff_nomatch(v_rest_24645);
              }
              V v_t_24652 = ({ V rv_1 = heff_get_n(v_t_24651, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24653 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24648, v_t_24652}), NTAG(TAG_Nil)});
              V v_t_24654 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24647, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24644, v_t_24653})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24643; V a_2 = v_t_24654; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24643); r_; });
            }
          }
        }
        case TAG_ENest: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24656 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24656) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24656);
            V v_t_24657 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str96), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str97)));
            V v_t_24658 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str98), heff_strAppend(v_x_247, v_t_24657));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24658}), v_xsp_248});
          } else {
            heff_drop(v_t_24656);
            V v_t_24659 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24660 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24659}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24661 = v_t_24660.f[0];
              V v_field_24662 = v_t_24660.f[1];
              V v_x_24663 = v_field_24661;
              V v_y_24664 = v_field_24662;
              V v_rest_24665 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24666 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24667 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24666}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24668 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24665)});
              V v_t_24671;
              switch (heff_tag_of(v_rest_24665)) {
              case TAG_At: {
                V v_s_24670 = heff_field(v_rest_24665, 1);
                heff_take_n(v_rest_24665, 2ULL, 2);
                v_t_24671 = v_s_24670;
                break;
              }
              default: heff_nomatch(v_rest_24665);
              }
              V v_t_24672 = ({ V rv_1 = heff_get_n(v_t_24671, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24673 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24668, v_t_24672}), NTAG(TAG_Nil)});
              V v_t_24674 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24667, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24664, v_t_24673})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24663; V a_2 = v_t_24674; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24663); r_; });
            }
          }
        }
        case TAG_ELazy: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24676 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24676) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24676);
            V v_t_24677 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str99), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str100)));
            V v_t_24678 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str101), heff_strAppend(v_x_247, v_t_24677));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24678}), v_xsp_248});
          } else {
            heff_drop(v_t_24676);
            V v_t_24679 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24680 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24679}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24681 = v_t_24680.f[0];
              V v_field_24682 = v_t_24680.f[1];
              V v_x_24683 = v_field_24681;
              V v_y_24684 = v_field_24682;
              V v_rest_24685 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24686 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24687 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24686}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24688 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24685)});
              V v_t_24691;
              switch (heff_tag_of(v_rest_24685)) {
              case TAG_At: {
                V v_s_24690 = heff_field(v_rest_24685, 1);
                heff_take_n(v_rest_24685, 2ULL, 2);
                v_t_24691 = v_s_24690;
                break;
              }
              default: heff_nomatch(v_rest_24685);
              }
              V v_t_24692 = ({ V rv_1 = heff_get_n(v_t_24691, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24693 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24688, v_t_24692}), NTAG(TAG_Nil)});
              V v_t_24694 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24687, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24684, v_t_24693})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24683; V a_2 = v_t_24694; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24683); r_; });
            }
          }
        }
        case TAG_ETuple: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24696 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24696) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24696);
            V v_t_24697 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str102), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str103)));
            V v_t_24698 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str104), heff_strAppend(v_x_247, v_t_24697));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24698}), v_xsp_248});
          } else {
            heff_drop(v_t_24696);
            V v_t_24699 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24700 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24699}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24701 = v_t_24700.f[0];
              V v_field_24702 = v_t_24700.f[1];
              V v_x_24703 = v_field_24701;
              V v_y_24704 = v_field_24702;
              V v_rest_24705 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24706 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24707 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24706}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24708 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24705)});
              V v_t_24711;
              switch (heff_tag_of(v_rest_24705)) {
              case TAG_At: {
                V v_s_24710 = heff_field(v_rest_24705, 1);
                heff_take_n(v_rest_24705, 2ULL, 2);
                v_t_24711 = v_s_24710;
                break;
              }
              default: heff_nomatch(v_rest_24705);
              }
              V v_t_24712 = ({ V rv_1 = heff_get_n(v_t_24711, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24713 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24708, v_t_24712}), NTAG(TAG_Nil)});
              V v_t_24714 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24707, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24704, v_t_24713})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24703; V a_2 = v_t_24714; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24703); r_; });
            }
          }
        }
        case TAG_ETry: {
          heff_take_n(v_x3131_2410, 0ULL, 1);
          heff_drop(v_fsp_2411);
          V v_t_24716 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24716) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24716);
            V v_t_24717 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str105), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str106)));
            V v_t_24718 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str107), heff_strAppend(v_x_247, v_t_24717));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24718}), v_xsp_248});
          } else {
            heff_drop(v_t_24716);
            V v_t_24719 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24720 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24719}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24721 = v_t_24720.f[0];
              V v_field_24722 = v_t_24720.f[1];
              V v_x_24723 = v_field_24721;
              V v_y_24724 = v_field_24722;
              V v_rest_24725 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24726 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24727 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24726}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24728 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24725)});
              V v_t_24731;
              switch (heff_tag_of(v_rest_24725)) {
              case TAG_At: {
                V v_s_24730 = heff_field(v_rest_24725, 1);
                heff_take_n(v_rest_24725, 2ULL, 2);
                v_t_24731 = v_s_24730;
                break;
              }
              default: heff_nomatch(v_rest_24725);
              }
              V v_t_24732 = ({ V rv_1 = heff_get_n(v_t_24731, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24733 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24728, v_t_24732}), NTAG(TAG_Nil)});
              V v_t_24734 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24727, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24724, v_t_24733})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24723; V a_2 = v_t_24734; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24723); r_; });
            }
          }
        }
        case TAG_EWith: {
          heff_take_n(v_x3131_2410, 0ULL, 4);
          heff_drop(v_fsp_2411);
          V v_t_24739 = (g_list_2eany_24s930586707x1164893977(v_x_247, heff_rfield(v_cx_241, 1)));
          if ((heff_dup(v_t_24739) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_tag(v_x313_249, 2);
            heff_drop(v_t_24739);
            V v_t_24740 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str108), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str109)));
            V v_t_24741 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str110), heff_strAppend(v_x_247, v_t_24740));
            return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24741}), v_xsp_248});
          } else {
            heff_drop(v_t_24739);
            V v_t_24742 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
            HeffT2 v_t_24743 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24742}), NTAG(TAG_Nil), v_x313_249));
            {
              V v_field_24744 = v_t_24743.f[0];
              V v_field_24745 = v_t_24743.f[1];
              V v_x_24746 = v_field_24744;
              V v_y_24747 = v_field_24745;
              V v_rest_24748 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
              V v_t_24749 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
              V v_t_24750 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24749}), heff_dup(heff_rfield(v_cx_241, 3))});
              V v_t_24751 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_247, heff_dup(v_xsp_248)}), heff_dup(v_rest_24748)});
              V v_t_24754;
              switch (heff_tag_of(v_rest_24748)) {
              case TAG_At: {
                V v_s_24753 = heff_field(v_rest_24748, 1);
                heff_take_n(v_rest_24748, 2ULL, 2);
                v_t_24754 = v_s_24753;
                break;
              }
              default: heff_nomatch(v_rest_24748);
              }
              V v_t_24755 = ({ V rv_1 = heff_get_n(v_t_24754, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24756 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24751, v_t_24755}), NTAG(TAG_Nil)});
              V v_t_24757 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24750, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24747, v_t_24756})));
              return ({ V a_0 = v_cx_241; V a_1 = v_x_24746; V a_2 = v_t_24757; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24746); r_; });
            }
          }
        }
        default: return heff_nomatch(v_x3131_2410);
        }
      }
      default: return heff_nomatch(v_x313_249);
      }
    }
    case TAG_StmtLet: {
      V v_p_24758 = heff_field(v_x31_245, 0);
      V v_x312_24759 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24StmtLet = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      switch (heff_tag_of(v_x312_24759)) {
      case TAG_At: {
        V v_x3121_24760 = heff_dup(heff_field(v_x312_24759, 0));
        switch (heff_tag_of(v_x3121_24760)) {
        case TAG_EVar: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24763 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24765 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam0, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24763));
          {
            V v_field_24767 = v_t_24765.f[1];
            int64_t v_tag_24766 = ((int64_t)v_t_24765.f[0]);
            if ((v_tag_24766 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24769 = v_field_24767;
              V v_t_24770 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str111), heff_strAppend(heff_dup(v_x_24769), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str112)));
              V v_t_24771 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str113), heff_strAppend(v_x_24769, v_t_24770));
              V v_t_24774;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24773 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24774 = v_s_24773;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24771}), v_t_24774});
            } else {
              heff_drop(v_field_24767);
              V v_t_24775 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24776 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24775}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24777 = v_t_24776.f[0];
                V v_field_24778 = v_t_24776.f[1];
                V v_x_24779 = v_field_24777;
                V v_y_24780 = v_field_24778;
                V v_body_24781 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24784;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24783 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24784 = v_s_24783;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24787;
                switch (heff_tag_of(v_body_24781)) {
                case TAG_At: {
                  V v_s_24786 = heff_dup(heff_field(v_body_24781, 1));
                  v_t_24787 = v_s_24786;
                  break;
                }
                default: heff_nomatch(v_body_24781);
                }
                V v_t_24788 = ({ V rv_1 = heff_get_n(v_t_24787, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24784, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24789 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24781)}), v_t_24788});
                V v_t_24792;
                switch (heff_tag_of(v_body_24781)) {
                case TAG_At: {
                  V v_s_24791 = heff_field(v_body_24781, 1);
                  heff_take_n(v_body_24781, 2ULL, 2);
                  v_t_24792 = v_s_24791;
                  break;
                }
                default: heff_nomatch(v_body_24781);
                }
                V v_t_24793 = ({ V rv_1 = heff_get_n(v_t_24792, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24794 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24780, v_t_24789}), v_t_24793});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24779; V a_2 = v_t_24794; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24779); r_; });
              }
            }
          }
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24796 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24798 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam1, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24796));
          {
            V v_field_24800 = v_t_24798.f[1];
            int64_t v_tag_24799 = ((int64_t)v_t_24798.f[0]);
            if ((v_tag_24799 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24802 = v_field_24800;
              V v_t_24803 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str114), heff_strAppend(heff_dup(v_x_24802), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str115)));
              V v_t_24804 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str116), heff_strAppend(v_x_24802, v_t_24803));
              V v_t_24807;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24806 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24807 = v_s_24806;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24804}), v_t_24807});
            } else {
              heff_drop(v_field_24800);
              V v_t_24808 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24809 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24808}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24810 = v_t_24809.f[0];
                V v_field_24811 = v_t_24809.f[1];
                V v_x_24812 = v_field_24810;
                V v_y_24813 = v_field_24811;
                V v_body_24814 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24817;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24816 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24817 = v_s_24816;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24820;
                switch (heff_tag_of(v_body_24814)) {
                case TAG_At: {
                  V v_s_24819 = heff_dup(heff_field(v_body_24814, 1));
                  v_t_24820 = v_s_24819;
                  break;
                }
                default: heff_nomatch(v_body_24814);
                }
                V v_t_24821 = ({ V rv_1 = heff_get_n(v_t_24820, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24817, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24822 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24814)}), v_t_24821});
                V v_t_24825;
                switch (heff_tag_of(v_body_24814)) {
                case TAG_At: {
                  V v_s_24824 = heff_field(v_body_24814, 1);
                  heff_take_n(v_body_24814, 2ULL, 2);
                  v_t_24825 = v_s_24824;
                  break;
                }
                default: heff_nomatch(v_body_24814);
                }
                V v_t_24826 = ({ V rv_1 = heff_get_n(v_t_24825, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24827 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24813, v_t_24822}), v_t_24826});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24812; V a_2 = v_t_24827; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24812); r_; });
              }
            }
          }
        }
        case TAG_ETag: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24829 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24831 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam2, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24829));
          {
            V v_field_24833 = v_t_24831.f[1];
            int64_t v_tag_24832 = ((int64_t)v_t_24831.f[0]);
            if ((v_tag_24832 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24835 = v_field_24833;
              V v_t_24836 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str117), heff_strAppend(heff_dup(v_x_24835), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str118)));
              V v_t_24837 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str119), heff_strAppend(v_x_24835, v_t_24836));
              V v_t_24840;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24839 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24840 = v_s_24839;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24837}), v_t_24840});
            } else {
              heff_drop(v_field_24833);
              V v_t_24841 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24842 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24841}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24843 = v_t_24842.f[0];
                V v_field_24844 = v_t_24842.f[1];
                V v_x_24845 = v_field_24843;
                V v_y_24846 = v_field_24844;
                V v_body_24847 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24850;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24849 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24850 = v_s_24849;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24853;
                switch (heff_tag_of(v_body_24847)) {
                case TAG_At: {
                  V v_s_24852 = heff_dup(heff_field(v_body_24847, 1));
                  v_t_24853 = v_s_24852;
                  break;
                }
                default: heff_nomatch(v_body_24847);
                }
                V v_t_24854 = ({ V rv_1 = heff_get_n(v_t_24853, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24850, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24855 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24847)}), v_t_24854});
                V v_t_24858;
                switch (heff_tag_of(v_body_24847)) {
                case TAG_At: {
                  V v_s_24857 = heff_field(v_body_24847, 1);
                  heff_take_n(v_body_24847, 2ULL, 2);
                  v_t_24858 = v_s_24857;
                  break;
                }
                default: heff_nomatch(v_body_24847);
                }
                V v_t_24859 = ({ V rv_1 = heff_get_n(v_t_24858, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24860 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24846, v_t_24855}), v_t_24859});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24845; V a_2 = v_t_24860; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24845); r_; });
              }
            }
          }
        }
        case TAG_EInt: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24862 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24864 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam3, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24862));
          {
            V v_field_24866 = v_t_24864.f[1];
            int64_t v_tag_24865 = ((int64_t)v_t_24864.f[0]);
            if ((v_tag_24865 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24868 = v_field_24866;
              V v_t_24869 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str120), heff_strAppend(heff_dup(v_x_24868), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str121)));
              V v_t_24870 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str122), heff_strAppend(v_x_24868, v_t_24869));
              V v_t_24873;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24872 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24873 = v_s_24872;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24870}), v_t_24873});
            } else {
              heff_drop(v_field_24866);
              V v_t_24874 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24875 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24874}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24876 = v_t_24875.f[0];
                V v_field_24877 = v_t_24875.f[1];
                V v_x_24878 = v_field_24876;
                V v_y_24879 = v_field_24877;
                V v_body_24880 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24883;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24882 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24883 = v_s_24882;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24886;
                switch (heff_tag_of(v_body_24880)) {
                case TAG_At: {
                  V v_s_24885 = heff_dup(heff_field(v_body_24880, 1));
                  v_t_24886 = v_s_24885;
                  break;
                }
                default: heff_nomatch(v_body_24880);
                }
                V v_t_24887 = ({ V rv_1 = heff_get_n(v_t_24886, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24883, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24888 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24880)}), v_t_24887});
                V v_t_24891;
                switch (heff_tag_of(v_body_24880)) {
                case TAG_At: {
                  V v_s_24890 = heff_field(v_body_24880, 1);
                  heff_take_n(v_body_24880, 2ULL, 2);
                  v_t_24891 = v_s_24890;
                  break;
                }
                default: heff_nomatch(v_body_24880);
                }
                V v_t_24892 = ({ V rv_1 = heff_get_n(v_t_24891, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24893 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24879, v_t_24888}), v_t_24892});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24878; V a_2 = v_t_24893; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24878); r_; });
              }
            }
          }
        }
        case TAG_EFloat: {
          heff_take_na(v_x3121_24760, 0ULL, 1);
          V v_xs_24895 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24897 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam4, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24895));
          {
            V v_field_24899 = v_t_24897.f[1];
            int64_t v_tag_24898 = ((int64_t)v_t_24897.f[0]);
            if ((v_tag_24898 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24901 = v_field_24899;
              V v_t_24902 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str123), heff_strAppend(heff_dup(v_x_24901), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str124)));
              V v_t_24903 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str125), heff_strAppend(v_x_24901, v_t_24902));
              V v_t_24906;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24905 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24906 = v_s_24905;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24903}), v_t_24906});
            } else {
              heff_drop(v_field_24899);
              V v_t_24907 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24908 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24907}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24909 = v_t_24908.f[0];
                V v_field_24910 = v_t_24908.f[1];
                V v_x_24911 = v_field_24909;
                V v_y_24912 = v_field_24910;
                V v_body_24913 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24916;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24915 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24916 = v_s_24915;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24919;
                switch (heff_tag_of(v_body_24913)) {
                case TAG_At: {
                  V v_s_24918 = heff_dup(heff_field(v_body_24913, 1));
                  v_t_24919 = v_s_24918;
                  break;
                }
                default: heff_nomatch(v_body_24913);
                }
                V v_t_24920 = ({ V rv_1 = heff_get_n(v_t_24919, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24916, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24921 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24913)}), v_t_24920});
                V v_t_24924;
                switch (heff_tag_of(v_body_24913)) {
                case TAG_At: {
                  V v_s_24923 = heff_field(v_body_24913, 1);
                  heff_take_n(v_body_24913, 2ULL, 2);
                  v_t_24924 = v_s_24923;
                  break;
                }
                default: heff_nomatch(v_body_24913);
                }
                V v_t_24925 = ({ V rv_1 = heff_get_n(v_t_24924, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24926 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24912, v_t_24921}), v_t_24925});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24911; V a_2 = v_t_24926; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24911); r_; });
              }
            }
          }
        }
        case TAG_EString: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24928 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24930 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam5, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24928));
          {
            V v_field_24932 = v_t_24930.f[1];
            int64_t v_tag_24931 = ((int64_t)v_t_24930.f[0]);
            if ((v_tag_24931 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24934 = v_field_24932;
              V v_t_24935 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str126), heff_strAppend(heff_dup(v_x_24934), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str127)));
              V v_t_24936 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str128), heff_strAppend(v_x_24934, v_t_24935));
              V v_t_24939;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24938 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24939 = v_s_24938;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24936}), v_t_24939});
            } else {
              heff_drop(v_field_24932);
              V v_t_24940 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24941 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24940}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24942 = v_t_24941.f[0];
                V v_field_24943 = v_t_24941.f[1];
                V v_x_24944 = v_field_24942;
                V v_y_24945 = v_field_24943;
                V v_body_24946 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24949;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24948 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24949 = v_s_24948;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24952;
                switch (heff_tag_of(v_body_24946)) {
                case TAG_At: {
                  V v_s_24951 = heff_dup(heff_field(v_body_24946, 1));
                  v_t_24952 = v_s_24951;
                  break;
                }
                default: heff_nomatch(v_body_24946);
                }
                V v_t_24953 = ({ V rv_1 = heff_get_n(v_t_24952, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24949, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24954 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24946)}), v_t_24953});
                V v_t_24957;
                switch (heff_tag_of(v_body_24946)) {
                case TAG_At: {
                  V v_s_24956 = heff_field(v_body_24946, 1);
                  heff_take_n(v_body_24946, 2ULL, 2);
                  v_t_24957 = v_s_24956;
                  break;
                }
                default: heff_nomatch(v_body_24946);
                }
                V v_t_24958 = ({ V rv_1 = heff_get_n(v_t_24957, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24959 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24945, v_t_24954}), v_t_24958});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24944; V a_2 = v_t_24959; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24944); r_; });
              }
            }
          }
        }
        case TAG_EBinary: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24961 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24963 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam6, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24961));
          {
            V v_field_24965 = v_t_24963.f[1];
            int64_t v_tag_24964 = ((int64_t)v_t_24963.f[0]);
            if ((v_tag_24964 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_24967 = v_field_24965;
              V v_t_24968 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str129), heff_strAppend(heff_dup(v_x_24967), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str130)));
              V v_t_24969 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str131), heff_strAppend(v_x_24967, v_t_24968));
              V v_t_24972;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_24971 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_24972 = v_s_24971;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24969}), v_t_24972});
            } else {
              heff_drop(v_field_24965);
              V v_t_24973 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24974 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24973}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_24975 = v_t_24974.f[0];
                V v_field_24976 = v_t_24974.f[1];
                V v_x_24977 = v_field_24975;
                V v_y_24978 = v_field_24976;
                V v_body_24979 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_24982;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_24981 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_24982 = v_s_24981;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_24985;
                switch (heff_tag_of(v_body_24979)) {
                case TAG_At: {
                  V v_s_24984 = heff_dup(heff_field(v_body_24979, 1));
                  v_t_24985 = v_s_24984;
                  break;
                }
                default: heff_nomatch(v_body_24979);
                }
                V v_t_24986 = ({ V rv_1 = heff_get_n(v_t_24985, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24982, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24987 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_24979)}), v_t_24986});
                V v_t_24990;
                switch (heff_tag_of(v_body_24979)) {
                case TAG_At: {
                  V v_s_24989 = heff_field(v_body_24979, 1);
                  heff_take_n(v_body_24979, 2ULL, 2);
                  v_t_24990 = v_s_24989;
                  break;
                }
                default: heff_nomatch(v_body_24979);
                }
                V v_t_24991 = ({ V rv_1 = heff_get_n(v_t_24990, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24992 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24978, v_t_24987}), v_t_24991});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_24977; V a_2 = v_t_24992; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24977); r_; });
              }
            }
          }
        }
        case TAG_ERune: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_24994 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_24996 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam7, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_24994));
          {
            V v_field_24998 = v_t_24996.f[1];
            int64_t v_tag_24997 = ((int64_t)v_t_24996.f[0]);
            if ((v_tag_24997 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241000 = v_field_24998;
              V v_t_241001 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str132), heff_strAppend(heff_dup(v_x_241000), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str133)));
              V v_t_241002 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str134), heff_strAppend(v_x_241000, v_t_241001));
              V v_t_241005;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241004 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241005 = v_s_241004;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241002}), v_t_241005});
            } else {
              heff_drop(v_field_24998);
              V v_t_241006 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241007 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241006}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241008 = v_t_241007.f[0];
                V v_field_241009 = v_t_241007.f[1];
                V v_x_241010 = v_field_241008;
                V v_y_241011 = v_field_241009;
                V v_body_241012 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241015;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241014 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241015 = v_s_241014;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241018;
                switch (heff_tag_of(v_body_241012)) {
                case TAG_At: {
                  V v_s_241017 = heff_dup(heff_field(v_body_241012, 1));
                  v_t_241018 = v_s_241017;
                  break;
                }
                default: heff_nomatch(v_body_241012);
                }
                V v_t_241019 = ({ V rv_1 = heff_get_n(v_t_241018, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241015, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241020 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241012)}), v_t_241019});
                V v_t_241023;
                switch (heff_tag_of(v_body_241012)) {
                case TAG_At: {
                  V v_s_241022 = heff_field(v_body_241012, 1);
                  heff_take_n(v_body_241012, 2ULL, 2);
                  v_t_241023 = v_s_241022;
                  break;
                }
                default: heff_nomatch(v_body_241012);
                }
                V v_t_241024 = ({ V rv_1 = heff_get_n(v_t_241023, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241025 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241011, v_t_241020}), v_t_241024});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241010; V a_2 = v_t_241025; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241010); r_; });
              }
            }
          }
        }
        case TAG_EWord: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241027 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241029 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam8, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241027));
          {
            V v_field_241031 = v_t_241029.f[1];
            int64_t v_tag_241030 = ((int64_t)v_t_241029.f[0]);
            if ((v_tag_241030 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241033 = v_field_241031;
              V v_t_241034 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str135), heff_strAppend(heff_dup(v_x_241033), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str136)));
              V v_t_241035 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str137), heff_strAppend(v_x_241033, v_t_241034));
              V v_t_241038;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241037 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241038 = v_s_241037;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241035}), v_t_241038});
            } else {
              heff_drop(v_field_241031);
              V v_t_241039 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241040 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241039}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241041 = v_t_241040.f[0];
                V v_field_241042 = v_t_241040.f[1];
                V v_x_241043 = v_field_241041;
                V v_y_241044 = v_field_241042;
                V v_body_241045 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241048;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241047 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241048 = v_s_241047;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241051;
                switch (heff_tag_of(v_body_241045)) {
                case TAG_At: {
                  V v_s_241050 = heff_dup(heff_field(v_body_241045, 1));
                  v_t_241051 = v_s_241050;
                  break;
                }
                default: heff_nomatch(v_body_241045);
                }
                V v_t_241052 = ({ V rv_1 = heff_get_n(v_t_241051, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241048, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241053 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241045)}), v_t_241052});
                V v_t_241056;
                switch (heff_tag_of(v_body_241045)) {
                case TAG_At: {
                  V v_s_241055 = heff_field(v_body_241045, 1);
                  heff_take_n(v_body_241045, 2ULL, 2);
                  v_t_241056 = v_s_241055;
                  break;
                }
                default: heff_nomatch(v_body_241045);
                }
                V v_t_241057 = ({ V rv_1 = heff_get_n(v_t_241056, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241058 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241044, v_t_241053}), v_t_241057});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241043; V a_2 = v_t_241058; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241043); r_; });
              }
            }
          }
        }
        case TAG_EApp: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241061 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241063 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam9, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241061));
          {
            V v_field_241065 = v_t_241063.f[1];
            int64_t v_tag_241064 = ((int64_t)v_t_241063.f[0]);
            if ((v_tag_241064 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241067 = v_field_241065;
              V v_t_241068 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str138), heff_strAppend(heff_dup(v_x_241067), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str139)));
              V v_t_241069 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str140), heff_strAppend(v_x_241067, v_t_241068));
              V v_t_241072;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241071 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241072 = v_s_241071;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241069}), v_t_241072});
            } else {
              heff_drop(v_field_241065);
              V v_t_241073 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241074 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241073}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241075 = v_t_241074.f[0];
                V v_field_241076 = v_t_241074.f[1];
                V v_x_241077 = v_field_241075;
                V v_y_241078 = v_field_241076;
                V v_body_241079 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241082;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241081 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241082 = v_s_241081;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241085;
                switch (heff_tag_of(v_body_241079)) {
                case TAG_At: {
                  V v_s_241084 = heff_dup(heff_field(v_body_241079, 1));
                  v_t_241085 = v_s_241084;
                  break;
                }
                default: heff_nomatch(v_body_241079);
                }
                V v_t_241086 = ({ V rv_1 = heff_get_n(v_t_241085, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241082, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241087 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241079)}), v_t_241086});
                V v_t_241090;
                switch (heff_tag_of(v_body_241079)) {
                case TAG_At: {
                  V v_s_241089 = heff_field(v_body_241079, 1);
                  heff_take_n(v_body_241079, 2ULL, 2);
                  v_t_241090 = v_s_241089;
                  break;
                }
                default: heff_nomatch(v_body_241079);
                }
                V v_t_241091 = ({ V rv_1 = heff_get_n(v_t_241090, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241092 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241078, v_t_241087}), v_t_241091});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241077; V a_2 = v_t_241092; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241077); r_; });
              }
            }
          }
        }
        case TAG_EProject: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241094 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241096 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam10, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241094));
          {
            V v_field_241098 = v_t_241096.f[1];
            int64_t v_tag_241097 = ((int64_t)v_t_241096.f[0]);
            if ((v_tag_241097 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241100 = v_field_241098;
              V v_t_241101 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str141), heff_strAppend(heff_dup(v_x_241100), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str142)));
              V v_t_241102 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str143), heff_strAppend(v_x_241100, v_t_241101));
              V v_t_241105;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241104 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241105 = v_s_241104;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241102}), v_t_241105});
            } else {
              heff_drop(v_field_241098);
              V v_t_241106 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241107 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241106}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241108 = v_t_241107.f[0];
                V v_field_241109 = v_t_241107.f[1];
                V v_x_241110 = v_field_241108;
                V v_y_241111 = v_field_241109;
                V v_body_241112 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241115;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241114 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241115 = v_s_241114;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241118;
                switch (heff_tag_of(v_body_241112)) {
                case TAG_At: {
                  V v_s_241117 = heff_dup(heff_field(v_body_241112, 1));
                  v_t_241118 = v_s_241117;
                  break;
                }
                default: heff_nomatch(v_body_241112);
                }
                V v_t_241119 = ({ V rv_1 = heff_get_n(v_t_241118, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241115, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241120 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241112)}), v_t_241119});
                V v_t_241123;
                switch (heff_tag_of(v_body_241112)) {
                case TAG_At: {
                  V v_s_241122 = heff_field(v_body_241112, 1);
                  heff_take_n(v_body_241112, 2ULL, 2);
                  v_t_241123 = v_s_241122;
                  break;
                }
                default: heff_nomatch(v_body_241112);
                }
                V v_t_241124 = ({ V rv_1 = heff_get_n(v_t_241123, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241125 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241111, v_t_241120}), v_t_241124});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241110; V a_2 = v_t_241125; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241110); r_; });
              }
            }
          }
        }
        case TAG_ENamed: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241128 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241130 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam11, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241128));
          {
            V v_field_241132 = v_t_241130.f[1];
            int64_t v_tag_241131 = ((int64_t)v_t_241130.f[0]);
            if ((v_tag_241131 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241134 = v_field_241132;
              V v_t_241135 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str144), heff_strAppend(heff_dup(v_x_241134), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str145)));
              V v_t_241136 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str146), heff_strAppend(v_x_241134, v_t_241135));
              V v_t_241139;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241138 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241139 = v_s_241138;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241136}), v_t_241139});
            } else {
              heff_drop(v_field_241132);
              V v_t_241140 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241141 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241140}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241142 = v_t_241141.f[0];
                V v_field_241143 = v_t_241141.f[1];
                V v_x_241144 = v_field_241142;
                V v_y_241145 = v_field_241143;
                V v_body_241146 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241149;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241148 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241149 = v_s_241148;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241152;
                switch (heff_tag_of(v_body_241146)) {
                case TAG_At: {
                  V v_s_241151 = heff_dup(heff_field(v_body_241146, 1));
                  v_t_241152 = v_s_241151;
                  break;
                }
                default: heff_nomatch(v_body_241146);
                }
                V v_t_241153 = ({ V rv_1 = heff_get_n(v_t_241152, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241149, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241154 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241146)}), v_t_241153});
                V v_t_241157;
                switch (heff_tag_of(v_body_241146)) {
                case TAG_At: {
                  V v_s_241156 = heff_field(v_body_241146, 1);
                  heff_take_n(v_body_241146, 2ULL, 2);
                  v_t_241157 = v_s_241156;
                  break;
                }
                default: heff_nomatch(v_body_241146);
                }
                V v_t_241158 = ({ V rv_1 = heff_get_n(v_t_241157, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241159 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241145, v_t_241154}), v_t_241158});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241144; V a_2 = v_t_241159; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241144); r_; });
              }
            }
          }
        }
        case TAG_EPi: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241162 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241164 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam12, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241162));
          {
            V v_field_241166 = v_t_241164.f[1];
            int64_t v_tag_241165 = ((int64_t)v_t_241164.f[0]);
            if ((v_tag_241165 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241168 = v_field_241166;
              V v_t_241169 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str147), heff_strAppend(heff_dup(v_x_241168), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str148)));
              V v_t_241170 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str149), heff_strAppend(v_x_241168, v_t_241169));
              V v_t_241173;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241172 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241173 = v_s_241172;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241170}), v_t_241173});
            } else {
              heff_drop(v_field_241166);
              V v_t_241174 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241175 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241174}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241176 = v_t_241175.f[0];
                V v_field_241177 = v_t_241175.f[1];
                V v_x_241178 = v_field_241176;
                V v_y_241179 = v_field_241177;
                V v_body_241180 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241183;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241182 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241183 = v_s_241182;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241186;
                switch (heff_tag_of(v_body_241180)) {
                case TAG_At: {
                  V v_s_241185 = heff_dup(heff_field(v_body_241180, 1));
                  v_t_241186 = v_s_241185;
                  break;
                }
                default: heff_nomatch(v_body_241180);
                }
                V v_t_241187 = ({ V rv_1 = heff_get_n(v_t_241186, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241183, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241188 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241180)}), v_t_241187});
                V v_t_241191;
                switch (heff_tag_of(v_body_241180)) {
                case TAG_At: {
                  V v_s_241190 = heff_field(v_body_241180, 1);
                  heff_take_n(v_body_241180, 2ULL, 2);
                  v_t_241191 = v_s_241190;
                  break;
                }
                default: heff_nomatch(v_body_241180);
                }
                V v_t_241192 = ({ V rv_1 = heff_get_n(v_t_241191, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241193 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241179, v_t_241188}), v_t_241192});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241178; V a_2 = v_t_241193; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241178); r_; });
              }
            }
          }
        }
        case TAG_ELam: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241196 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241198 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam13, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241196));
          {
            V v_field_241200 = v_t_241198.f[1];
            int64_t v_tag_241199 = ((int64_t)v_t_241198.f[0]);
            if ((v_tag_241199 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241202 = v_field_241200;
              V v_t_241203 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str150), heff_strAppend(heff_dup(v_x_241202), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str151)));
              V v_t_241204 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str152), heff_strAppend(v_x_241202, v_t_241203));
              V v_t_241207;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241206 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241207 = v_s_241206;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241204}), v_t_241207});
            } else {
              heff_drop(v_field_241200);
              V v_t_241208 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241209 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241208}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241210 = v_t_241209.f[0];
                V v_field_241211 = v_t_241209.f[1];
                V v_x_241212 = v_field_241210;
                V v_y_241213 = v_field_241211;
                V v_body_241214 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241217;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241216 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241217 = v_s_241216;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241220;
                switch (heff_tag_of(v_body_241214)) {
                case TAG_At: {
                  V v_s_241219 = heff_dup(heff_field(v_body_241214, 1));
                  v_t_241220 = v_s_241219;
                  break;
                }
                default: heff_nomatch(v_body_241214);
                }
                V v_t_241221 = ({ V rv_1 = heff_get_n(v_t_241220, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241217, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241222 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241214)}), v_t_241221});
                V v_t_241225;
                switch (heff_tag_of(v_body_241214)) {
                case TAG_At: {
                  V v_s_241224 = heff_field(v_body_241214, 1);
                  heff_take_n(v_body_241214, 2ULL, 2);
                  v_t_241225 = v_s_241224;
                  break;
                }
                default: heff_nomatch(v_body_241214);
                }
                V v_t_241226 = ({ V rv_1 = heff_get_n(v_t_241225, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241227 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241213, v_t_241222}), v_t_241226});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241212; V a_2 = v_t_241227; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241212); r_; });
              }
            }
          }
        }
        case TAG_EAnn: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241230 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241232 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam14, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241230));
          {
            V v_field_241234 = v_t_241232.f[1];
            int64_t v_tag_241233 = ((int64_t)v_t_241232.f[0]);
            if ((v_tag_241233 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241236 = v_field_241234;
              V v_t_241237 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str153), heff_strAppend(heff_dup(v_x_241236), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str154)));
              V v_t_241238 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str155), heff_strAppend(v_x_241236, v_t_241237));
              V v_t_241241;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241240 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241241 = v_s_241240;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241238}), v_t_241241});
            } else {
              heff_drop(v_field_241234);
              V v_t_241242 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241243 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241242}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241244 = v_t_241243.f[0];
                V v_field_241245 = v_t_241243.f[1];
                V v_x_241246 = v_field_241244;
                V v_y_241247 = v_field_241245;
                V v_body_241248 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241251;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241250 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241251 = v_s_241250;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241254;
                switch (heff_tag_of(v_body_241248)) {
                case TAG_At: {
                  V v_s_241253 = heff_dup(heff_field(v_body_241248, 1));
                  v_t_241254 = v_s_241253;
                  break;
                }
                default: heff_nomatch(v_body_241248);
                }
                V v_t_241255 = ({ V rv_1 = heff_get_n(v_t_241254, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241251, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241256 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241248)}), v_t_241255});
                V v_t_241259;
                switch (heff_tag_of(v_body_241248)) {
                case TAG_At: {
                  V v_s_241258 = heff_field(v_body_241248, 1);
                  heff_take_n(v_body_241248, 2ULL, 2);
                  v_t_241259 = v_s_241258;
                  break;
                }
                default: heff_nomatch(v_body_241248);
                }
                V v_t_241260 = ({ V rv_1 = heff_get_n(v_t_241259, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241261 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241247, v_t_241256}), v_t_241260});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241246; V a_2 = v_t_241261; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241246); r_; });
              }
            }
          }
        }
        case TAG_ESpec: {
          heff_take_n(v_x3121_24760, 0ULL, 4);
          V v_xs_241266 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241268 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam15, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241266));
          {
            V v_field_241270 = v_t_241268.f[1];
            int64_t v_tag_241269 = ((int64_t)v_t_241268.f[0]);
            if ((v_tag_241269 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241272 = v_field_241270;
              V v_t_241273 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str156), heff_strAppend(heff_dup(v_x_241272), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str157)));
              V v_t_241274 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str158), heff_strAppend(v_x_241272, v_t_241273));
              V v_t_241277;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241276 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241277 = v_s_241276;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241274}), v_t_241277});
            } else {
              heff_drop(v_field_241270);
              V v_t_241278 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241279 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241278}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241280 = v_t_241279.f[0];
                V v_field_241281 = v_t_241279.f[1];
                V v_x_241282 = v_field_241280;
                V v_y_241283 = v_field_241281;
                V v_body_241284 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241287;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241286 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241287 = v_s_241286;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241290;
                switch (heff_tag_of(v_body_241284)) {
                case TAG_At: {
                  V v_s_241289 = heff_dup(heff_field(v_body_241284, 1));
                  v_t_241290 = v_s_241289;
                  break;
                }
                default: heff_nomatch(v_body_241284);
                }
                V v_t_241291 = ({ V rv_1 = heff_get_n(v_t_241290, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241287, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241292 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241284)}), v_t_241291});
                V v_t_241295;
                switch (heff_tag_of(v_body_241284)) {
                case TAG_At: {
                  V v_s_241294 = heff_field(v_body_241284, 1);
                  heff_take_n(v_body_241284, 2ULL, 2);
                  v_t_241295 = v_s_241294;
                  break;
                }
                default: heff_nomatch(v_body_241284);
                }
                V v_t_241296 = ({ V rv_1 = heff_get_n(v_t_241295, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241297 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241283, v_t_241292}), v_t_241296});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241282; V a_2 = v_t_241297; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241282); r_; });
              }
            }
          }
        }
        case TAG_ESig: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241299 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241301 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam16, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241299));
          {
            V v_field_241303 = v_t_241301.f[1];
            int64_t v_tag_241302 = ((int64_t)v_t_241301.f[0]);
            if ((v_tag_241302 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241305 = v_field_241303;
              V v_t_241306 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str159), heff_strAppend(heff_dup(v_x_241305), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str160)));
              V v_t_241307 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str161), heff_strAppend(v_x_241305, v_t_241306));
              V v_t_241310;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241309 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241310 = v_s_241309;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241307}), v_t_241310});
            } else {
              heff_drop(v_field_241303);
              V v_t_241311 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241312 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241311}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241313 = v_t_241312.f[0];
                V v_field_241314 = v_t_241312.f[1];
                V v_x_241315 = v_field_241313;
                V v_y_241316 = v_field_241314;
                V v_body_241317 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241320;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241319 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241320 = v_s_241319;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241323;
                switch (heff_tag_of(v_body_241317)) {
                case TAG_At: {
                  V v_s_241322 = heff_dup(heff_field(v_body_241317, 1));
                  v_t_241323 = v_s_241322;
                  break;
                }
                default: heff_nomatch(v_body_241317);
                }
                V v_t_241324 = ({ V rv_1 = heff_get_n(v_t_241323, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241320, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241325 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241317)}), v_t_241324});
                V v_t_241328;
                switch (heff_tag_of(v_body_241317)) {
                case TAG_At: {
                  V v_s_241327 = heff_field(v_body_241317, 1);
                  heff_take_n(v_body_241317, 2ULL, 2);
                  v_t_241328 = v_s_241327;
                  break;
                }
                default: heff_nomatch(v_body_241317);
                }
                V v_t_241329 = ({ V rv_1 = heff_get_n(v_t_241328, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241330 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241316, v_t_241325}), v_t_241329});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241315; V a_2 = v_t_241330; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241315); r_; });
              }
            }
          }
        }
        case TAG_ESum: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241332 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241334 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam17, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241332));
          {
            V v_field_241336 = v_t_241334.f[1];
            int64_t v_tag_241335 = ((int64_t)v_t_241334.f[0]);
            if ((v_tag_241335 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241338 = v_field_241336;
              V v_t_241339 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str162), heff_strAppend(heff_dup(v_x_241338), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str163)));
              V v_t_241340 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str164), heff_strAppend(v_x_241338, v_t_241339));
              V v_t_241343;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241342 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241343 = v_s_241342;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241340}), v_t_241343});
            } else {
              heff_drop(v_field_241336);
              V v_t_241344 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241345 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241344}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241346 = v_t_241345.f[0];
                V v_field_241347 = v_t_241345.f[1];
                V v_x_241348 = v_field_241346;
                V v_y_241349 = v_field_241347;
                V v_body_241350 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241353;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241352 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241353 = v_s_241352;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241356;
                switch (heff_tag_of(v_body_241350)) {
                case TAG_At: {
                  V v_s_241355 = heff_dup(heff_field(v_body_241350, 1));
                  v_t_241356 = v_s_241355;
                  break;
                }
                default: heff_nomatch(v_body_241350);
                }
                V v_t_241357 = ({ V rv_1 = heff_get_n(v_t_241356, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241353, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241358 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241350)}), v_t_241357});
                V v_t_241361;
                switch (heff_tag_of(v_body_241350)) {
                case TAG_At: {
                  V v_s_241360 = heff_field(v_body_241350, 1);
                  heff_take_n(v_body_241350, 2ULL, 2);
                  v_t_241361 = v_s_241360;
                  break;
                }
                default: heff_nomatch(v_body_241350);
                }
                V v_t_241362 = ({ V rv_1 = heff_get_n(v_t_241361, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241363 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241349, v_t_241358}), v_t_241362});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241348; V a_2 = v_t_241363; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241348); r_; });
              }
            }
          }
        }
        case TAG_EStruct: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241365 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241367 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam18, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241365));
          {
            V v_field_241369 = v_t_241367.f[1];
            int64_t v_tag_241368 = ((int64_t)v_t_241367.f[0]);
            if ((v_tag_241368 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241371 = v_field_241369;
              V v_t_241372 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str165), heff_strAppend(heff_dup(v_x_241371), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str166)));
              V v_t_241373 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str167), heff_strAppend(v_x_241371, v_t_241372));
              V v_t_241376;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241375 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241376 = v_s_241375;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241373}), v_t_241376});
            } else {
              heff_drop(v_field_241369);
              V v_t_241377 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241378 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241377}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241379 = v_t_241378.f[0];
                V v_field_241380 = v_t_241378.f[1];
                V v_x_241381 = v_field_241379;
                V v_y_241382 = v_field_241380;
                V v_body_241383 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241386;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241385 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241386 = v_s_241385;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241389;
                switch (heff_tag_of(v_body_241383)) {
                case TAG_At: {
                  V v_s_241388 = heff_dup(heff_field(v_body_241383, 1));
                  v_t_241389 = v_s_241388;
                  break;
                }
                default: heff_nomatch(v_body_241383);
                }
                V v_t_241390 = ({ V rv_1 = heff_get_n(v_t_241389, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241386, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241391 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241383)}), v_t_241390});
                V v_t_241394;
                switch (heff_tag_of(v_body_241383)) {
                case TAG_At: {
                  V v_s_241393 = heff_field(v_body_241383, 1);
                  heff_take_n(v_body_241383, 2ULL, 2);
                  v_t_241394 = v_s_241393;
                  break;
                }
                default: heff_nomatch(v_body_241383);
                }
                V v_t_241395 = ({ V rv_1 = heff_get_n(v_t_241394, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241396 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241382, v_t_241391}), v_t_241395});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241381; V a_2 = v_t_241396; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241381); r_; });
              }
            }
          }
        }
        case TAG_EUpdate: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241399 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241401 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam19, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241399));
          {
            V v_field_241403 = v_t_241401.f[1];
            int64_t v_tag_241402 = ((int64_t)v_t_241401.f[0]);
            if ((v_tag_241402 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241405 = v_field_241403;
              V v_t_241406 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str168), heff_strAppend(heff_dup(v_x_241405), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str169)));
              V v_t_241407 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str170), heff_strAppend(v_x_241405, v_t_241406));
              V v_t_241410;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241409 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241410 = v_s_241409;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241407}), v_t_241410});
            } else {
              heff_drop(v_field_241403);
              V v_t_241411 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241412 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241411}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241413 = v_t_241412.f[0];
                V v_field_241414 = v_t_241412.f[1];
                V v_x_241415 = v_field_241413;
                V v_y_241416 = v_field_241414;
                V v_body_241417 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241420;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241419 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241420 = v_s_241419;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241423;
                switch (heff_tag_of(v_body_241417)) {
                case TAG_At: {
                  V v_s_241422 = heff_dup(heff_field(v_body_241417, 1));
                  v_t_241423 = v_s_241422;
                  break;
                }
                default: heff_nomatch(v_body_241417);
                }
                V v_t_241424 = ({ V rv_1 = heff_get_n(v_t_241423, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241420, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241425 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241417)}), v_t_241424});
                V v_t_241428;
                switch (heff_tag_of(v_body_241417)) {
                case TAG_At: {
                  V v_s_241427 = heff_field(v_body_241417, 1);
                  heff_take_n(v_body_241417, 2ULL, 2);
                  v_t_241428 = v_s_241427;
                  break;
                }
                default: heff_nomatch(v_body_241417);
                }
                V v_t_241429 = ({ V rv_1 = heff_get_n(v_t_241428, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241430 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241416, v_t_241425}), v_t_241429});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241415; V a_2 = v_t_241430; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241415); r_; });
              }
            }
          }
        }
        case TAG_EMatch: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241433 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241435 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam20, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241433));
          {
            V v_field_241437 = v_t_241435.f[1];
            int64_t v_tag_241436 = ((int64_t)v_t_241435.f[0]);
            if ((v_tag_241436 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241439 = v_field_241437;
              V v_t_241440 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str171), heff_strAppend(heff_dup(v_x_241439), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str172)));
              V v_t_241441 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str173), heff_strAppend(v_x_241439, v_t_241440));
              V v_t_241444;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241443 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241444 = v_s_241443;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241441}), v_t_241444});
            } else {
              heff_drop(v_field_241437);
              V v_t_241445 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241446 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241445}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241447 = v_t_241446.f[0];
                V v_field_241448 = v_t_241446.f[1];
                V v_x_241449 = v_field_241447;
                V v_y_241450 = v_field_241448;
                V v_body_241451 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241454;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241453 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241454 = v_s_241453;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241457;
                switch (heff_tag_of(v_body_241451)) {
                case TAG_At: {
                  V v_s_241456 = heff_dup(heff_field(v_body_241451, 1));
                  v_t_241457 = v_s_241456;
                  break;
                }
                default: heff_nomatch(v_body_241451);
                }
                V v_t_241458 = ({ V rv_1 = heff_get_n(v_t_241457, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241459 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241451)}), v_t_241458});
                V v_t_241462;
                switch (heff_tag_of(v_body_241451)) {
                case TAG_At: {
                  V v_s_241461 = heff_field(v_body_241451, 1);
                  heff_take_n(v_body_241451, 2ULL, 2);
                  v_t_241462 = v_s_241461;
                  break;
                }
                default: heff_nomatch(v_body_241451);
                }
                V v_t_241463 = ({ V rv_1 = heff_get_n(v_t_241462, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241464 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241450, v_t_241459}), v_t_241463});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241449; V a_2 = v_t_241464; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241449); r_; });
              }
            }
          }
        }
        case TAG_ELetIn: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241467 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241469 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam21, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241467));
          {
            V v_field_241471 = v_t_241469.f[1];
            int64_t v_tag_241470 = ((int64_t)v_t_241469.f[0]);
            if ((v_tag_241470 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241473 = v_field_241471;
              V v_t_241474 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str174), heff_strAppend(heff_dup(v_x_241473), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str175)));
              V v_t_241475 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str176), heff_strAppend(v_x_241473, v_t_241474));
              V v_t_241478;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241477 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241478 = v_s_241477;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241475}), v_t_241478});
            } else {
              heff_drop(v_field_241471);
              V v_t_241479 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241480 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241479}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241481 = v_t_241480.f[0];
                V v_field_241482 = v_t_241480.f[1];
                V v_x_241483 = v_field_241481;
                V v_y_241484 = v_field_241482;
                V v_body_241485 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241488;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241487 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241488 = v_s_241487;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241491;
                switch (heff_tag_of(v_body_241485)) {
                case TAG_At: {
                  V v_s_241490 = heff_dup(heff_field(v_body_241485, 1));
                  v_t_241491 = v_s_241490;
                  break;
                }
                default: heff_nomatch(v_body_241485);
                }
                V v_t_241492 = ({ V rv_1 = heff_get_n(v_t_241491, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241488, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241493 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241485)}), v_t_241492});
                V v_t_241496;
                switch (heff_tag_of(v_body_241485)) {
                case TAG_At: {
                  V v_s_241495 = heff_field(v_body_241485, 1);
                  heff_take_n(v_body_241485, 2ULL, 2);
                  v_t_241496 = v_s_241495;
                  break;
                }
                default: heff_nomatch(v_body_241485);
                }
                V v_t_241497 = ({ V rv_1 = heff_get_n(v_t_241496, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241498 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241484, v_t_241493}), v_t_241497});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241483; V a_2 = v_t_241498; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241483); r_; });
              }
            }
          }
        }
        case TAG_EDo: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241500 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241502 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam22, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241500));
          {
            V v_field_241504 = v_t_241502.f[1];
            int64_t v_tag_241503 = ((int64_t)v_t_241502.f[0]);
            if ((v_tag_241503 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241506 = v_field_241504;
              V v_t_241507 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str177), heff_strAppend(heff_dup(v_x_241506), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str178)));
              V v_t_241508 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str179), heff_strAppend(v_x_241506, v_t_241507));
              V v_t_241511;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241510 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241511 = v_s_241510;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241508}), v_t_241511});
            } else {
              heff_drop(v_field_241504);
              V v_t_241512 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241513 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241512}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241514 = v_t_241513.f[0];
                V v_field_241515 = v_t_241513.f[1];
                V v_x_241516 = v_field_241514;
                V v_y_241517 = v_field_241515;
                V v_body_241518 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241521;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241520 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241521 = v_s_241520;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241524;
                switch (heff_tag_of(v_body_241518)) {
                case TAG_At: {
                  V v_s_241523 = heff_dup(heff_field(v_body_241518, 1));
                  v_t_241524 = v_s_241523;
                  break;
                }
                default: heff_nomatch(v_body_241518);
                }
                V v_t_241525 = ({ V rv_1 = heff_get_n(v_t_241524, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241521, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241526 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241518)}), v_t_241525});
                V v_t_241529;
                switch (heff_tag_of(v_body_241518)) {
                case TAG_At: {
                  V v_s_241528 = heff_field(v_body_241518, 1);
                  heff_take_n(v_body_241518, 2ULL, 2);
                  v_t_241529 = v_s_241528;
                  break;
                }
                default: heff_nomatch(v_body_241518);
                }
                V v_t_241530 = ({ V rv_1 = heff_get_n(v_t_241529, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241531 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241517, v_t_241526}), v_t_241530});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241516; V a_2 = v_t_241531; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241516); r_; });
              }
            }
          }
        }
        case TAG_ELocal: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241534 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241536 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam23, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241534));
          {
            V v_field_241538 = v_t_241536.f[1];
            int64_t v_tag_241537 = ((int64_t)v_t_241536.f[0]);
            if ((v_tag_241537 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241540 = v_field_241538;
              V v_t_241541 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str180), heff_strAppend(heff_dup(v_x_241540), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str181)));
              V v_t_241542 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str182), heff_strAppend(v_x_241540, v_t_241541));
              V v_t_241545;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241544 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241545 = v_s_241544;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241542}), v_t_241545});
            } else {
              heff_drop(v_field_241538);
              V v_t_241546 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241547 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241546}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241548 = v_t_241547.f[0];
                V v_field_241549 = v_t_241547.f[1];
                V v_x_241550 = v_field_241548;
                V v_y_241551 = v_field_241549;
                V v_body_241552 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241555;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241554 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241555 = v_s_241554;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241558;
                switch (heff_tag_of(v_body_241552)) {
                case TAG_At: {
                  V v_s_241557 = heff_dup(heff_field(v_body_241552, 1));
                  v_t_241558 = v_s_241557;
                  break;
                }
                default: heff_nomatch(v_body_241552);
                }
                V v_t_241559 = ({ V rv_1 = heff_get_n(v_t_241558, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241555, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241560 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241552)}), v_t_241559});
                V v_t_241563;
                switch (heff_tag_of(v_body_241552)) {
                case TAG_At: {
                  V v_s_241562 = heff_field(v_body_241552, 1);
                  heff_take_n(v_body_241552, 2ULL, 2);
                  v_t_241563 = v_s_241562;
                  break;
                }
                default: heff_nomatch(v_body_241552);
                }
                V v_t_241564 = ({ V rv_1 = heff_get_n(v_t_241563, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241565 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241551, v_t_241560}), v_t_241564});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241550; V a_2 = v_t_241565; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241550); r_; });
              }
            }
          }
        }
        case TAG_EInvalid: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241567 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241569 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam24, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241567));
          {
            V v_field_241571 = v_t_241569.f[1];
            int64_t v_tag_241570 = ((int64_t)v_t_241569.f[0]);
            if ((v_tag_241570 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241573 = v_field_241571;
              V v_t_241574 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str183), heff_strAppend(heff_dup(v_x_241573), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str184)));
              V v_t_241575 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str185), heff_strAppend(v_x_241573, v_t_241574));
              V v_t_241578;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241577 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241578 = v_s_241577;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241575}), v_t_241578});
            } else {
              heff_drop(v_field_241571);
              V v_t_241579 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241580 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241579}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241581 = v_t_241580.f[0];
                V v_field_241582 = v_t_241580.f[1];
                V v_x_241583 = v_field_241581;
                V v_y_241584 = v_field_241582;
                V v_body_241585 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241588;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241587 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241588 = v_s_241587;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241591;
                switch (heff_tag_of(v_body_241585)) {
                case TAG_At: {
                  V v_s_241590 = heff_dup(heff_field(v_body_241585, 1));
                  v_t_241591 = v_s_241590;
                  break;
                }
                default: heff_nomatch(v_body_241585);
                }
                V v_t_241592 = ({ V rv_1 = heff_get_n(v_t_241591, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241588, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241593 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241585)}), v_t_241592});
                V v_t_241596;
                switch (heff_tag_of(v_body_241585)) {
                case TAG_At: {
                  V v_s_241595 = heff_field(v_body_241585, 1);
                  heff_take_n(v_body_241585, 2ULL, 2);
                  v_t_241596 = v_s_241595;
                  break;
                }
                default: heff_nomatch(v_body_241585);
                }
                V v_t_241597 = ({ V rv_1 = heff_get_n(v_t_241596, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241598 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241584, v_t_241593}), v_t_241597});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241583; V a_2 = v_t_241598; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241583); r_; });
              }
            }
          }
        }
        case TAG_EAssign: {
          heff_take_n(v_x3121_24760, 0ULL, 3);
          V v_xs_241602 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241604 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam25, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241602));
          {
            V v_field_241606 = v_t_241604.f[1];
            int64_t v_tag_241605 = ((int64_t)v_t_241604.f[0]);
            if ((v_tag_241605 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241608 = v_field_241606;
              V v_t_241609 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str186), heff_strAppend(heff_dup(v_x_241608), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str187)));
              V v_t_241610 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str188), heff_strAppend(v_x_241608, v_t_241609));
              V v_t_241613;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241612 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241613 = v_s_241612;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241610}), v_t_241613});
            } else {
              heff_drop(v_field_241606);
              V v_t_241614 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241615 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241614}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241616 = v_t_241615.f[0];
                V v_field_241617 = v_t_241615.f[1];
                V v_x_241618 = v_field_241616;
                V v_y_241619 = v_field_241617;
                V v_body_241620 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241623;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241622 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241623 = v_s_241622;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241626;
                switch (heff_tag_of(v_body_241620)) {
                case TAG_At: {
                  V v_s_241625 = heff_dup(heff_field(v_body_241620, 1));
                  v_t_241626 = v_s_241625;
                  break;
                }
                default: heff_nomatch(v_body_241620);
                }
                V v_t_241627 = ({ V rv_1 = heff_get_n(v_t_241626, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241623, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241628 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241620)}), v_t_241627});
                V v_t_241631;
                switch (heff_tag_of(v_body_241620)) {
                case TAG_At: {
                  V v_s_241630 = heff_field(v_body_241620, 1);
                  heff_take_n(v_body_241620, 2ULL, 2);
                  v_t_241631 = v_s_241630;
                  break;
                }
                default: heff_nomatch(v_body_241620);
                }
                V v_t_241632 = ({ V rv_1 = heff_get_n(v_t_241631, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241633 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241619, v_t_241628}), v_t_241632});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241618; V a_2 = v_t_241633; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241618); r_; });
              }
            }
          }
        }
        case TAG_EWhile: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241636 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241638 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam26, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241636));
          {
            V v_field_241640 = v_t_241638.f[1];
            int64_t v_tag_241639 = ((int64_t)v_t_241638.f[0]);
            if ((v_tag_241639 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241642 = v_field_241640;
              V v_t_241643 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str189), heff_strAppend(heff_dup(v_x_241642), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str190)));
              V v_t_241644 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str191), heff_strAppend(v_x_241642, v_t_241643));
              V v_t_241647;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241646 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241647 = v_s_241646;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241644}), v_t_241647});
            } else {
              heff_drop(v_field_241640);
              V v_t_241648 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241649 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241648}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241650 = v_t_241649.f[0];
                V v_field_241651 = v_t_241649.f[1];
                V v_x_241652 = v_field_241650;
                V v_y_241653 = v_field_241651;
                V v_body_241654 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241657;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241656 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241657 = v_s_241656;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241660;
                switch (heff_tag_of(v_body_241654)) {
                case TAG_At: {
                  V v_s_241659 = heff_dup(heff_field(v_body_241654, 1));
                  v_t_241660 = v_s_241659;
                  break;
                }
                default: heff_nomatch(v_body_241654);
                }
                V v_t_241661 = ({ V rv_1 = heff_get_n(v_t_241660, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241657, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241662 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241654)}), v_t_241661});
                V v_t_241665;
                switch (heff_tag_of(v_body_241654)) {
                case TAG_At: {
                  V v_s_241664 = heff_field(v_body_241654, 1);
                  heff_take_n(v_body_241654, 2ULL, 2);
                  v_t_241665 = v_s_241664;
                  break;
                }
                default: heff_nomatch(v_body_241654);
                }
                V v_t_241666 = ({ V rv_1 = heff_get_n(v_t_241665, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241667 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241653, v_t_241662}), v_t_241666});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241652; V a_2 = v_t_241667; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241652); r_; });
              }
            }
          }
        }
        case TAG_EFor: {
          heff_take_n(v_x3121_24760, 0ULL, 3);
          V v_xs_241671 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241673 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam27, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241671));
          {
            V v_field_241675 = v_t_241673.f[1];
            int64_t v_tag_241674 = ((int64_t)v_t_241673.f[0]);
            if ((v_tag_241674 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241677 = v_field_241675;
              V v_t_241678 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str192), heff_strAppend(heff_dup(v_x_241677), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str193)));
              V v_t_241679 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str194), heff_strAppend(v_x_241677, v_t_241678));
              V v_t_241682;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241681 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241682 = v_s_241681;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241679}), v_t_241682});
            } else {
              heff_drop(v_field_241675);
              V v_t_241683 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241684 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241683}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241685 = v_t_241684.f[0];
                V v_field_241686 = v_t_241684.f[1];
                V v_x_241687 = v_field_241685;
                V v_y_241688 = v_field_241686;
                V v_body_241689 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241692;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241691 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241692 = v_s_241691;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241695;
                switch (heff_tag_of(v_body_241689)) {
                case TAG_At: {
                  V v_s_241694 = heff_dup(heff_field(v_body_241689, 1));
                  v_t_241695 = v_s_241694;
                  break;
                }
                default: heff_nomatch(v_body_241689);
                }
                V v_t_241696 = ({ V rv_1 = heff_get_n(v_t_241695, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241692, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241697 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241689)}), v_t_241696});
                V v_t_241700;
                switch (heff_tag_of(v_body_241689)) {
                case TAG_At: {
                  V v_s_241699 = heff_field(v_body_241689, 1);
                  heff_take_n(v_body_241689, 2ULL, 2);
                  v_t_241700 = v_s_241699;
                  break;
                }
                default: heff_nomatch(v_body_241689);
                }
                V v_t_241701 = ({ V rv_1 = heff_get_n(v_t_241700, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241702 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241688, v_t_241697}), v_t_241701});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241687; V a_2 = v_t_241702; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241687); r_; });
              }
            }
          }
        }
        case TAG_EIfThen: {
          heff_take_n(v_x3121_24760, 0ULL, 2);
          V v_xs_241705 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241707 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam28, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241705));
          {
            V v_field_241709 = v_t_241707.f[1];
            int64_t v_tag_241708 = ((int64_t)v_t_241707.f[0]);
            if ((v_tag_241708 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241711 = v_field_241709;
              V v_t_241712 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str195), heff_strAppend(heff_dup(v_x_241711), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str196)));
              V v_t_241713 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str197), heff_strAppend(v_x_241711, v_t_241712));
              V v_t_241716;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241715 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241716 = v_s_241715;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241713}), v_t_241716});
            } else {
              heff_drop(v_field_241709);
              V v_t_241717 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241718 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241717}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241719 = v_t_241718.f[0];
                V v_field_241720 = v_t_241718.f[1];
                V v_x_241721 = v_field_241719;
                V v_y_241722 = v_field_241720;
                V v_body_241723 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241726;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241725 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241726 = v_s_241725;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241729;
                switch (heff_tag_of(v_body_241723)) {
                case TAG_At: {
                  V v_s_241728 = heff_dup(heff_field(v_body_241723, 1));
                  v_t_241729 = v_s_241728;
                  break;
                }
                default: heff_nomatch(v_body_241723);
                }
                V v_t_241730 = ({ V rv_1 = heff_get_n(v_t_241729, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241726, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241731 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241723)}), v_t_241730});
                V v_t_241734;
                switch (heff_tag_of(v_body_241723)) {
                case TAG_At: {
                  V v_s_241733 = heff_field(v_body_241723, 1);
                  heff_take_n(v_body_241723, 2ULL, 2);
                  v_t_241734 = v_s_241733;
                  break;
                }
                default: heff_nomatch(v_body_241723);
                }
                V v_t_241735 = ({ V rv_1 = heff_get_n(v_t_241734, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241736 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241722, v_t_241731}), v_t_241735});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241721; V a_2 = v_t_241736; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241721); r_; });
              }
            }
          }
        }
        case TAG_EBreak: {
          V v_xs_241737 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241739 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam29, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241737));
          {
            V v_field_241741 = v_t_241739.f[1];
            int64_t v_tag_241740 = ((int64_t)v_t_241739.f[0]);
            if ((v_tag_241740 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241743 = v_field_241741;
              V v_t_241744 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str198), heff_strAppend(heff_dup(v_x_241743), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str199)));
              V v_t_241745 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str200), heff_strAppend(v_x_241743, v_t_241744));
              V v_t_241748;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241747 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241748 = v_s_241747;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241745}), v_t_241748});
            } else {
              heff_drop(v_field_241741);
              V v_t_241749 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241750 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241749}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241751 = v_t_241750.f[0];
                V v_field_241752 = v_t_241750.f[1];
                V v_x_241753 = v_field_241751;
                V v_y_241754 = v_field_241752;
                V v_body_241755 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241758;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241757 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241758 = v_s_241757;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241761;
                switch (heff_tag_of(v_body_241755)) {
                case TAG_At: {
                  V v_s_241760 = heff_dup(heff_field(v_body_241755, 1));
                  v_t_241761 = v_s_241760;
                  break;
                }
                default: heff_nomatch(v_body_241755);
                }
                V v_t_241762 = ({ V rv_1 = heff_get_n(v_t_241761, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241758, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241763 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241755)}), v_t_241762});
                V v_t_241766;
                switch (heff_tag_of(v_body_241755)) {
                case TAG_At: {
                  V v_s_241765 = heff_field(v_body_241755, 1);
                  heff_take_n(v_body_241755, 2ULL, 2);
                  v_t_241766 = v_s_241765;
                  break;
                }
                default: heff_nomatch(v_body_241755);
                }
                V v_t_241767 = ({ V rv_1 = heff_get_n(v_t_241766, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241768 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241754, v_t_241763}), v_t_241767});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241753; V a_2 = v_t_241768; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241753); r_; });
              }
            }
          }
        }
        case TAG_EContinue: {
          V v_xs_241769 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241771 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam30, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241769));
          {
            V v_field_241773 = v_t_241771.f[1];
            int64_t v_tag_241772 = ((int64_t)v_t_241771.f[0]);
            if ((v_tag_241772 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241775 = v_field_241773;
              V v_t_241776 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str201), heff_strAppend(heff_dup(v_x_241775), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str202)));
              V v_t_241777 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str203), heff_strAppend(v_x_241775, v_t_241776));
              V v_t_241780;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241779 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241780 = v_s_241779;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241777}), v_t_241780});
            } else {
              heff_drop(v_field_241773);
              V v_t_241781 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241782 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241781}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241783 = v_t_241782.f[0];
                V v_field_241784 = v_t_241782.f[1];
                V v_x_241785 = v_field_241783;
                V v_y_241786 = v_field_241784;
                V v_body_241787 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241790;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241789 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241790 = v_s_241789;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241793;
                switch (heff_tag_of(v_body_241787)) {
                case TAG_At: {
                  V v_s_241792 = heff_dup(heff_field(v_body_241787, 1));
                  v_t_241793 = v_s_241792;
                  break;
                }
                default: heff_nomatch(v_body_241787);
                }
                V v_t_241794 = ({ V rv_1 = heff_get_n(v_t_241793, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241790, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241795 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241787)}), v_t_241794});
                V v_t_241798;
                switch (heff_tag_of(v_body_241787)) {
                case TAG_At: {
                  V v_s_241797 = heff_field(v_body_241787, 1);
                  heff_take_n(v_body_241787, 2ULL, 2);
                  v_t_241798 = v_s_241797;
                  break;
                }
                default: heff_nomatch(v_body_241787);
                }
                V v_t_241799 = ({ V rv_1 = heff_get_n(v_t_241798, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241800 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241786, v_t_241795}), v_t_241799});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241785; V a_2 = v_t_241800; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241785); r_; });
              }
            }
          }
        }
        case TAG_EReturn: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_241802 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_241804 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam31, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241802));
          {
            V v_field_241806 = v_t_241804.f[1];
            int64_t v_tag_241805 = ((int64_t)v_t_241804.f[0]);
            if ((v_tag_241805 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_241808 = v_field_241806;
              V v_t_241809 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str204), heff_strAppend(heff_dup(v_x_241808), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str205)));
              V v_t_241810 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str206), heff_strAppend(v_x_241808, v_t_241809));
              V v_t_241813;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_241812 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_241813 = v_s_241812;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241810}), v_t_241813});
            } else {
              heff_drop(v_field_241806);
              V v_t_241814 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_241815 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241814}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_241816 = v_t_241815.f[0];
                V v_field_241817 = v_t_241815.f[1];
                V v_x_241818 = v_field_241816;
                V v_y_241819 = v_field_241817;
                V v_body_241820 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_241823;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_241822 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_241823 = v_s_241822;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_241826;
                switch (heff_tag_of(v_body_241820)) {
                case TAG_At: {
                  V v_s_241825 = heff_dup(heff_field(v_body_241820, 1));
                  v_t_241826 = v_s_241825;
                  break;
                }
                default: heff_nomatch(v_body_241820);
                }
                V v_t_241827 = ({ V rv_1 = heff_get_n(v_t_241826, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241823, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241828 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241820)}), v_t_241827});
                V v_t_241831;
                switch (heff_tag_of(v_body_241820)) {
                case TAG_At: {
                  V v_s_241830 = heff_field(v_body_241820, 1);
                  heff_take_n(v_body_241820, 2ULL, 2);
                  v_t_241831 = v_s_241830;
                  break;
                }
                default: heff_nomatch(v_body_241820);
                }
                V v_t_241832 = ({ V rv_1 = heff_get_n(v_t_241831, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_241833 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241819, v_t_241828}), v_t_241832});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_241818; V a_2 = v_t_241833; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241818); r_; });
              }
            }
          }
        }
        case TAG_ENest: {
          V v_x31211_241834 = heff_field(v_x3121_24760, 0);
          heff_take_n(v_x3121_24760, 1ULL, 1);
          switch (heff_tag_of(v_x31211_241834)) {
          case TAG_At: {
            V v_x312111_241835 = heff_field(v_x31211_241834, 0);
            V v_fsp_241836 = heff_field(v_x31211_241834, 1);
            heff_take_n(v_x31211_241834, 3ULL, 2);
            switch (heff_tag_of(v_x312111_241835)) {
            case TAG_EVar: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_241838 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_241840 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam32, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241838));
              {
                V v_field_241842 = v_t_241840.f[1];
                int64_t v_tag_241841 = ((int64_t)v_t_241840.f[0]);
                if ((v_tag_241841 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241844 = v_field_241842;
                  V v_t_241845 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str207), heff_strAppend(heff_dup(v_x_241844), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str208)));
                  V v_t_241846 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str209), heff_strAppend(v_x_241844, v_t_241845));
                  V v_t_241849;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_241848 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_241849 = v_s_241848;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241846}), v_t_241849});
                } else {
                  heff_drop(v_field_241842);
                  V v_t_241850 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241851 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241850}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_241852 = v_t_241851.f[0];
                    V v_field_241853 = v_t_241851.f[1];
                    V v_x_241854 = v_field_241852;
                    V v_y_241855 = v_field_241853;
                    V v_body_241856 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241859;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_241858 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_241859 = v_s_241858;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_241862;
                    switch (heff_tag_of(v_body_241856)) {
                    case TAG_At: {
                      V v_s_241861 = heff_dup(heff_field(v_body_241856, 1));
                      v_t_241862 = v_s_241861;
                      break;
                    }
                    default: heff_nomatch(v_body_241856);
                    }
                    V v_t_241863 = ({ V rv_1 = heff_get_n(v_t_241862, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241859, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241864 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241856)}), v_t_241863});
                    V v_t_241867;
                    switch (heff_tag_of(v_body_241856)) {
                    case TAG_At: {
                      V v_s_241866 = heff_field(v_body_241856, 1);
                      heff_take_n(v_body_241856, 2ULL, 2);
                      v_t_241867 = v_s_241866;
                      break;
                    }
                    default: heff_nomatch(v_body_241856);
                    }
                    V v_t_241868 = ({ V rv_1 = heff_get_n(v_t_241867, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241869 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241855, v_t_241864}), v_t_241868});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241854; V a_2 = v_t_241869; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241854); r_; });
                  }
                }
              }
            }
            case TAG_EImplicitVar: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_241871 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_241873 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam33, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241871));
              {
                V v_field_241875 = v_t_241873.f[1];
                int64_t v_tag_241874 = ((int64_t)v_t_241873.f[0]);
                if ((v_tag_241874 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241877 = v_field_241875;
                  V v_t_241878 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str210), heff_strAppend(heff_dup(v_x_241877), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str211)));
                  V v_t_241879 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str212), heff_strAppend(v_x_241877, v_t_241878));
                  V v_t_241882;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_241881 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_241882 = v_s_241881;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241879}), v_t_241882});
                } else {
                  heff_drop(v_field_241875);
                  V v_t_241883 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241884 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241883}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_241885 = v_t_241884.f[0];
                    V v_field_241886 = v_t_241884.f[1];
                    V v_x_241887 = v_field_241885;
                    V v_y_241888 = v_field_241886;
                    V v_body_241889 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241892;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_241891 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_241892 = v_s_241891;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_241895;
                    switch (heff_tag_of(v_body_241889)) {
                    case TAG_At: {
                      V v_s_241894 = heff_dup(heff_field(v_body_241889, 1));
                      v_t_241895 = v_s_241894;
                      break;
                    }
                    default: heff_nomatch(v_body_241889);
                    }
                    V v_t_241896 = ({ V rv_1 = heff_get_n(v_t_241895, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241892, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241897 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241889)}), v_t_241896});
                    V v_t_241900;
                    switch (heff_tag_of(v_body_241889)) {
                    case TAG_At: {
                      V v_s_241899 = heff_field(v_body_241889, 1);
                      heff_take_n(v_body_241889, 2ULL, 2);
                      v_t_241900 = v_s_241899;
                      break;
                    }
                    default: heff_nomatch(v_body_241889);
                    }
                    V v_t_241901 = ({ V rv_1 = heff_get_n(v_t_241900, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241902 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241888, v_t_241897}), v_t_241901});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241887; V a_2 = v_t_241902; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241887); r_; });
                  }
                }
              }
            }
            case TAG_ETag: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_241904 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_241906 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam34, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241904));
              {
                V v_field_241908 = v_t_241906.f[1];
                int64_t v_tag_241907 = ((int64_t)v_t_241906.f[0]);
                if ((v_tag_241907 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241910 = v_field_241908;
                  V v_t_241911 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str213), heff_strAppend(heff_dup(v_x_241910), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str214)));
                  V v_t_241912 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str215), heff_strAppend(v_x_241910, v_t_241911));
                  V v_t_241915;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_241914 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_241915 = v_s_241914;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241912}), v_t_241915});
                } else {
                  heff_drop(v_field_241908);
                  V v_t_241916 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241917 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241916}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_241918 = v_t_241917.f[0];
                    V v_field_241919 = v_t_241917.f[1];
                    V v_x_241920 = v_field_241918;
                    V v_y_241921 = v_field_241919;
                    V v_body_241922 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241925;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_241924 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_241925 = v_s_241924;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_241928;
                    switch (heff_tag_of(v_body_241922)) {
                    case TAG_At: {
                      V v_s_241927 = heff_dup(heff_field(v_body_241922, 1));
                      v_t_241928 = v_s_241927;
                      break;
                    }
                    default: heff_nomatch(v_body_241922);
                    }
                    V v_t_241929 = ({ V rv_1 = heff_get_n(v_t_241928, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241925, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241930 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241922)}), v_t_241929});
                    V v_t_241933;
                    switch (heff_tag_of(v_body_241922)) {
                    case TAG_At: {
                      V v_s_241932 = heff_field(v_body_241922, 1);
                      heff_take_n(v_body_241922, 2ULL, 2);
                      v_t_241933 = v_s_241932;
                      break;
                    }
                    default: heff_nomatch(v_body_241922);
                    }
                    V v_t_241934 = ({ V rv_1 = heff_get_n(v_t_241933, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241935 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241921, v_t_241930}), v_t_241934});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241920; V a_2 = v_t_241935; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241920); r_; });
                  }
                }
              }
            }
            case TAG_EInt: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_241937 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_241939 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam35, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241937));
              {
                V v_field_241941 = v_t_241939.f[1];
                int64_t v_tag_241940 = ((int64_t)v_t_241939.f[0]);
                if ((v_tag_241940 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241943 = v_field_241941;
                  V v_t_241944 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str216), heff_strAppend(heff_dup(v_x_241943), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str217)));
                  V v_t_241945 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str218), heff_strAppend(v_x_241943, v_t_241944));
                  V v_t_241948;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_241947 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_241948 = v_s_241947;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241945}), v_t_241948});
                } else {
                  heff_drop(v_field_241941);
                  V v_t_241949 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241950 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241949}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_241951 = v_t_241950.f[0];
                    V v_field_241952 = v_t_241950.f[1];
                    V v_x_241953 = v_field_241951;
                    V v_y_241954 = v_field_241952;
                    V v_body_241955 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241958;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_241957 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_241958 = v_s_241957;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_241961;
                    switch (heff_tag_of(v_body_241955)) {
                    case TAG_At: {
                      V v_s_241960 = heff_dup(heff_field(v_body_241955, 1));
                      v_t_241961 = v_s_241960;
                      break;
                    }
                    default: heff_nomatch(v_body_241955);
                    }
                    V v_t_241962 = ({ V rv_1 = heff_get_n(v_t_241961, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241958, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241963 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241955)}), v_t_241962});
                    V v_t_241966;
                    switch (heff_tag_of(v_body_241955)) {
                    case TAG_At: {
                      V v_s_241965 = heff_field(v_body_241955, 1);
                      heff_take_n(v_body_241955, 2ULL, 2);
                      v_t_241966 = v_s_241965;
                      break;
                    }
                    default: heff_nomatch(v_body_241955);
                    }
                    V v_t_241967 = ({ V rv_1 = heff_get_n(v_t_241966, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241968 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241954, v_t_241963}), v_t_241967});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241953; V a_2 = v_t_241968; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241953); r_; });
                  }
                }
              }
            }
            case TAG_EFloat: {
              heff_take_na(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_241970 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_241972 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam36, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_241970));
              {
                V v_field_241974 = v_t_241972.f[1];
                int64_t v_tag_241973 = ((int64_t)v_t_241972.f[0]);
                if ((v_tag_241973 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_241976 = v_field_241974;
                  V v_t_241977 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str219), heff_strAppend(heff_dup(v_x_241976), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str220)));
                  V v_t_241978 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str221), heff_strAppend(v_x_241976, v_t_241977));
                  V v_t_241981;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_241980 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_241981 = v_s_241980;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_241978}), v_t_241981});
                } else {
                  heff_drop(v_field_241974);
                  V v_t_241982 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_241983 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_241982}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_241984 = v_t_241983.f[0];
                    V v_field_241985 = v_t_241983.f[1];
                    V v_x_241986 = v_field_241984;
                    V v_y_241987 = v_field_241985;
                    V v_body_241988 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_241991;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_241990 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_241991 = v_s_241990;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_241994;
                    switch (heff_tag_of(v_body_241988)) {
                    case TAG_At: {
                      V v_s_241993 = heff_dup(heff_field(v_body_241988, 1));
                      v_t_241994 = v_s_241993;
                      break;
                    }
                    default: heff_nomatch(v_body_241988);
                    }
                    V v_t_241995 = ({ V rv_1 = heff_get_n(v_t_241994, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_241991, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_241996 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_241988)}), v_t_241995});
                    V v_t_241999;
                    switch (heff_tag_of(v_body_241988)) {
                    case TAG_At: {
                      V v_s_241998 = heff_field(v_body_241988, 1);
                      heff_take_n(v_body_241988, 2ULL, 2);
                      v_t_241999 = v_s_241998;
                      break;
                    }
                    default: heff_nomatch(v_body_241988);
                    }
                    V v_t_242000 = ({ V rv_1 = heff_get_n(v_t_241999, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242001 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_241987, v_t_241996}), v_t_242000});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_241986; V a_2 = v_t_242001; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_241986); r_; });
                  }
                }
              }
            }
            case TAG_EString: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242003 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242005 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam37, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242003));
              {
                V v_field_242007 = v_t_242005.f[1];
                int64_t v_tag_242006 = ((int64_t)v_t_242005.f[0]);
                if ((v_tag_242006 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242009 = v_field_242007;
                  V v_t_242010 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str222), heff_strAppend(heff_dup(v_x_242009), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str223)));
                  V v_t_242011 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str224), heff_strAppend(v_x_242009, v_t_242010));
                  V v_t_242014;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242013 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242014 = v_s_242013;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242011}), v_t_242014});
                } else {
                  heff_drop(v_field_242007);
                  V v_t_242015 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242016 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242015}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242017 = v_t_242016.f[0];
                    V v_field_242018 = v_t_242016.f[1];
                    V v_x_242019 = v_field_242017;
                    V v_y_242020 = v_field_242018;
                    V v_body_242021 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242024;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242023 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242024 = v_s_242023;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242027;
                    switch (heff_tag_of(v_body_242021)) {
                    case TAG_At: {
                      V v_s_242026 = heff_dup(heff_field(v_body_242021, 1));
                      v_t_242027 = v_s_242026;
                      break;
                    }
                    default: heff_nomatch(v_body_242021);
                    }
                    V v_t_242028 = ({ V rv_1 = heff_get_n(v_t_242027, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242024, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242029 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242021)}), v_t_242028});
                    V v_t_242032;
                    switch (heff_tag_of(v_body_242021)) {
                    case TAG_At: {
                      V v_s_242031 = heff_field(v_body_242021, 1);
                      heff_take_n(v_body_242021, 2ULL, 2);
                      v_t_242032 = v_s_242031;
                      break;
                    }
                    default: heff_nomatch(v_body_242021);
                    }
                    V v_t_242033 = ({ V rv_1 = heff_get_n(v_t_242032, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242034 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242020, v_t_242029}), v_t_242033});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242019; V a_2 = v_t_242034; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242019); r_; });
                  }
                }
              }
            }
            case TAG_EBinary: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242036 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242038 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam38, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242036));
              {
                V v_field_242040 = v_t_242038.f[1];
                int64_t v_tag_242039 = ((int64_t)v_t_242038.f[0]);
                if ((v_tag_242039 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242042 = v_field_242040;
                  V v_t_242043 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str225), heff_strAppend(heff_dup(v_x_242042), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str226)));
                  V v_t_242044 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str227), heff_strAppend(v_x_242042, v_t_242043));
                  V v_t_242047;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242046 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242047 = v_s_242046;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242044}), v_t_242047});
                } else {
                  heff_drop(v_field_242040);
                  V v_t_242048 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242049 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242048}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242050 = v_t_242049.f[0];
                    V v_field_242051 = v_t_242049.f[1];
                    V v_x_242052 = v_field_242050;
                    V v_y_242053 = v_field_242051;
                    V v_body_242054 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242057;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242056 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242057 = v_s_242056;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242060;
                    switch (heff_tag_of(v_body_242054)) {
                    case TAG_At: {
                      V v_s_242059 = heff_dup(heff_field(v_body_242054, 1));
                      v_t_242060 = v_s_242059;
                      break;
                    }
                    default: heff_nomatch(v_body_242054);
                    }
                    V v_t_242061 = ({ V rv_1 = heff_get_n(v_t_242060, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242057, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242062 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242054)}), v_t_242061});
                    V v_t_242065;
                    switch (heff_tag_of(v_body_242054)) {
                    case TAG_At: {
                      V v_s_242064 = heff_field(v_body_242054, 1);
                      heff_take_n(v_body_242054, 2ULL, 2);
                      v_t_242065 = v_s_242064;
                      break;
                    }
                    default: heff_nomatch(v_body_242054);
                    }
                    V v_t_242066 = ({ V rv_1 = heff_get_n(v_t_242065, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242067 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242053, v_t_242062}), v_t_242066});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242052; V a_2 = v_t_242067; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242052); r_; });
                  }
                }
              }
            }
            case TAG_ERune: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242069 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242071 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam39, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242069));
              {
                V v_field_242073 = v_t_242071.f[1];
                int64_t v_tag_242072 = ((int64_t)v_t_242071.f[0]);
                if ((v_tag_242072 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242075 = v_field_242073;
                  V v_t_242076 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str228), heff_strAppend(heff_dup(v_x_242075), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str229)));
                  V v_t_242077 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str230), heff_strAppend(v_x_242075, v_t_242076));
                  V v_t_242080;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242079 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242080 = v_s_242079;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242077}), v_t_242080});
                } else {
                  heff_drop(v_field_242073);
                  V v_t_242081 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242082 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242081}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242083 = v_t_242082.f[0];
                    V v_field_242084 = v_t_242082.f[1];
                    V v_x_242085 = v_field_242083;
                    V v_y_242086 = v_field_242084;
                    V v_body_242087 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242090;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242089 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242090 = v_s_242089;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242093;
                    switch (heff_tag_of(v_body_242087)) {
                    case TAG_At: {
                      V v_s_242092 = heff_dup(heff_field(v_body_242087, 1));
                      v_t_242093 = v_s_242092;
                      break;
                    }
                    default: heff_nomatch(v_body_242087);
                    }
                    V v_t_242094 = ({ V rv_1 = heff_get_n(v_t_242093, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242090, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242095 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242087)}), v_t_242094});
                    V v_t_242098;
                    switch (heff_tag_of(v_body_242087)) {
                    case TAG_At: {
                      V v_s_242097 = heff_field(v_body_242087, 1);
                      heff_take_n(v_body_242087, 2ULL, 2);
                      v_t_242098 = v_s_242097;
                      break;
                    }
                    default: heff_nomatch(v_body_242087);
                    }
                    V v_t_242099 = ({ V rv_1 = heff_get_n(v_t_242098, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242100 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242086, v_t_242095}), v_t_242099});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242085; V a_2 = v_t_242100; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242085); r_; });
                  }
                }
              }
            }
            case TAG_EWord: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242102 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242104 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam40, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242102));
              {
                V v_field_242106 = v_t_242104.f[1];
                int64_t v_tag_242105 = ((int64_t)v_t_242104.f[0]);
                if ((v_tag_242105 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242108 = v_field_242106;
                  V v_t_242109 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str231), heff_strAppend(heff_dup(v_x_242108), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str232)));
                  V v_t_242110 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str233), heff_strAppend(v_x_242108, v_t_242109));
                  V v_t_242113;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242112 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242113 = v_s_242112;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242110}), v_t_242113});
                } else {
                  heff_drop(v_field_242106);
                  V v_t_242114 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242115 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242114}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242116 = v_t_242115.f[0];
                    V v_field_242117 = v_t_242115.f[1];
                    V v_x_242118 = v_field_242116;
                    V v_y_242119 = v_field_242117;
                    V v_body_242120 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242123;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242122 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242123 = v_s_242122;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242126;
                    switch (heff_tag_of(v_body_242120)) {
                    case TAG_At: {
                      V v_s_242125 = heff_dup(heff_field(v_body_242120, 1));
                      v_t_242126 = v_s_242125;
                      break;
                    }
                    default: heff_nomatch(v_body_242120);
                    }
                    V v_t_242127 = ({ V rv_1 = heff_get_n(v_t_242126, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242123, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242128 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242120)}), v_t_242127});
                    V v_t_242131;
                    switch (heff_tag_of(v_body_242120)) {
                    case TAG_At: {
                      V v_s_242130 = heff_field(v_body_242120, 1);
                      heff_take_n(v_body_242120, 2ULL, 2);
                      v_t_242131 = v_s_242130;
                      break;
                    }
                    default: heff_nomatch(v_body_242120);
                    }
                    V v_t_242132 = ({ V rv_1 = heff_get_n(v_t_242131, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242133 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242119, v_t_242128}), v_t_242132});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242118; V a_2 = v_t_242133; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242118); r_; });
                  }
                }
              }
            }
            case TAG_EApp: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242136 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242138 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam41, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242136));
              {
                V v_field_242140 = v_t_242138.f[1];
                int64_t v_tag_242139 = ((int64_t)v_t_242138.f[0]);
                if ((v_tag_242139 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242142 = v_field_242140;
                  V v_t_242143 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str234), heff_strAppend(heff_dup(v_x_242142), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str235)));
                  V v_t_242144 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str236), heff_strAppend(v_x_242142, v_t_242143));
                  V v_t_242147;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242146 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242147 = v_s_242146;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242144}), v_t_242147});
                } else {
                  heff_drop(v_field_242140);
                  V v_t_242148 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242149 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242148}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242150 = v_t_242149.f[0];
                    V v_field_242151 = v_t_242149.f[1];
                    V v_x_242152 = v_field_242150;
                    V v_y_242153 = v_field_242151;
                    V v_body_242154 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242157;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242156 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242157 = v_s_242156;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242160;
                    switch (heff_tag_of(v_body_242154)) {
                    case TAG_At: {
                      V v_s_242159 = heff_dup(heff_field(v_body_242154, 1));
                      v_t_242160 = v_s_242159;
                      break;
                    }
                    default: heff_nomatch(v_body_242154);
                    }
                    V v_t_242161 = ({ V rv_1 = heff_get_n(v_t_242160, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242157, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242162 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242154)}), v_t_242161});
                    V v_t_242165;
                    switch (heff_tag_of(v_body_242154)) {
                    case TAG_At: {
                      V v_s_242164 = heff_field(v_body_242154, 1);
                      heff_take_n(v_body_242154, 2ULL, 2);
                      v_t_242165 = v_s_242164;
                      break;
                    }
                    default: heff_nomatch(v_body_242154);
                    }
                    V v_t_242166 = ({ V rv_1 = heff_get_n(v_t_242165, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242167 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242153, v_t_242162}), v_t_242166});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242152; V a_2 = v_t_242167; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242152); r_; });
                  }
                }
              }
            }
            case TAG_EProject: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242169 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242171 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam42, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242169));
              {
                V v_field_242173 = v_t_242171.f[1];
                int64_t v_tag_242172 = ((int64_t)v_t_242171.f[0]);
                if ((v_tag_242172 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242175 = v_field_242173;
                  V v_t_242176 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str237), heff_strAppend(heff_dup(v_x_242175), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str238)));
                  V v_t_242177 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str239), heff_strAppend(v_x_242175, v_t_242176));
                  V v_t_242180;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242179 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242180 = v_s_242179;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242177}), v_t_242180});
                } else {
                  heff_drop(v_field_242173);
                  V v_t_242181 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242182 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242181}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242183 = v_t_242182.f[0];
                    V v_field_242184 = v_t_242182.f[1];
                    V v_x_242185 = v_field_242183;
                    V v_y_242186 = v_field_242184;
                    V v_body_242187 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242190;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242189 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242190 = v_s_242189;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242193;
                    switch (heff_tag_of(v_body_242187)) {
                    case TAG_At: {
                      V v_s_242192 = heff_dup(heff_field(v_body_242187, 1));
                      v_t_242193 = v_s_242192;
                      break;
                    }
                    default: heff_nomatch(v_body_242187);
                    }
                    V v_t_242194 = ({ V rv_1 = heff_get_n(v_t_242193, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242190, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242195 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242187)}), v_t_242194});
                    V v_t_242198;
                    switch (heff_tag_of(v_body_242187)) {
                    case TAG_At: {
                      V v_s_242197 = heff_field(v_body_242187, 1);
                      heff_take_n(v_body_242187, 2ULL, 2);
                      v_t_242198 = v_s_242197;
                      break;
                    }
                    default: heff_nomatch(v_body_242187);
                    }
                    V v_t_242199 = ({ V rv_1 = heff_get_n(v_t_242198, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242200 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242186, v_t_242195}), v_t_242199});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242185; V a_2 = v_t_242200; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242185); r_; });
                  }
                }
              }
            }
            case TAG_ENamed: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242203 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242205 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam43, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242203));
              {
                V v_field_242207 = v_t_242205.f[1];
                int64_t v_tag_242206 = ((int64_t)v_t_242205.f[0]);
                if ((v_tag_242206 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242209 = v_field_242207;
                  V v_t_242210 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str240), heff_strAppend(heff_dup(v_x_242209), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str241)));
                  V v_t_242211 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str242), heff_strAppend(v_x_242209, v_t_242210));
                  V v_t_242214;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242213 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242214 = v_s_242213;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242211}), v_t_242214});
                } else {
                  heff_drop(v_field_242207);
                  V v_t_242215 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242216 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242215}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242217 = v_t_242216.f[0];
                    V v_field_242218 = v_t_242216.f[1];
                    V v_x_242219 = v_field_242217;
                    V v_y_242220 = v_field_242218;
                    V v_body_242221 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242224;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242223 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242224 = v_s_242223;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242227;
                    switch (heff_tag_of(v_body_242221)) {
                    case TAG_At: {
                      V v_s_242226 = heff_dup(heff_field(v_body_242221, 1));
                      v_t_242227 = v_s_242226;
                      break;
                    }
                    default: heff_nomatch(v_body_242221);
                    }
                    V v_t_242228 = ({ V rv_1 = heff_get_n(v_t_242227, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242224, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242229 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242221)}), v_t_242228});
                    V v_t_242232;
                    switch (heff_tag_of(v_body_242221)) {
                    case TAG_At: {
                      V v_s_242231 = heff_field(v_body_242221, 1);
                      heff_take_n(v_body_242221, 2ULL, 2);
                      v_t_242232 = v_s_242231;
                      break;
                    }
                    default: heff_nomatch(v_body_242221);
                    }
                    V v_t_242233 = ({ V rv_1 = heff_get_n(v_t_242232, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242234 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242220, v_t_242229}), v_t_242233});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242219; V a_2 = v_t_242234; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242219); r_; });
                  }
                }
              }
            }
            case TAG_EPi: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242237 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242239 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam44, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242237));
              {
                V v_field_242241 = v_t_242239.f[1];
                int64_t v_tag_242240 = ((int64_t)v_t_242239.f[0]);
                if ((v_tag_242240 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242243 = v_field_242241;
                  V v_t_242244 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str243), heff_strAppend(heff_dup(v_x_242243), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str244)));
                  V v_t_242245 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str245), heff_strAppend(v_x_242243, v_t_242244));
                  V v_t_242248;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242247 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242248 = v_s_242247;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242245}), v_t_242248});
                } else {
                  heff_drop(v_field_242241);
                  V v_t_242249 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242250 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242249}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242251 = v_t_242250.f[0];
                    V v_field_242252 = v_t_242250.f[1];
                    V v_x_242253 = v_field_242251;
                    V v_y_242254 = v_field_242252;
                    V v_body_242255 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242258;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242257 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242258 = v_s_242257;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242261;
                    switch (heff_tag_of(v_body_242255)) {
                    case TAG_At: {
                      V v_s_242260 = heff_dup(heff_field(v_body_242255, 1));
                      v_t_242261 = v_s_242260;
                      break;
                    }
                    default: heff_nomatch(v_body_242255);
                    }
                    V v_t_242262 = ({ V rv_1 = heff_get_n(v_t_242261, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242258, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242263 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242255)}), v_t_242262});
                    V v_t_242266;
                    switch (heff_tag_of(v_body_242255)) {
                    case TAG_At: {
                      V v_s_242265 = heff_field(v_body_242255, 1);
                      heff_take_n(v_body_242255, 2ULL, 2);
                      v_t_242266 = v_s_242265;
                      break;
                    }
                    default: heff_nomatch(v_body_242255);
                    }
                    V v_t_242267 = ({ V rv_1 = heff_get_n(v_t_242266, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242268 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242254, v_t_242263}), v_t_242267});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242253; V a_2 = v_t_242268; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242253); r_; });
                  }
                }
              }
            }
            case TAG_ELam: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242271 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242273 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam45, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242271));
              {
                V v_field_242275 = v_t_242273.f[1];
                int64_t v_tag_242274 = ((int64_t)v_t_242273.f[0]);
                if ((v_tag_242274 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242277 = v_field_242275;
                  V v_t_242278 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str246), heff_strAppend(heff_dup(v_x_242277), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str247)));
                  V v_t_242279 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str248), heff_strAppend(v_x_242277, v_t_242278));
                  V v_t_242282;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242281 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242282 = v_s_242281;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242279}), v_t_242282});
                } else {
                  heff_drop(v_field_242275);
                  V v_t_242283 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242284 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242283}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242285 = v_t_242284.f[0];
                    V v_field_242286 = v_t_242284.f[1];
                    V v_x_242287 = v_field_242285;
                    V v_y_242288 = v_field_242286;
                    V v_body_242289 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242292;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242291 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242292 = v_s_242291;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242295;
                    switch (heff_tag_of(v_body_242289)) {
                    case TAG_At: {
                      V v_s_242294 = heff_dup(heff_field(v_body_242289, 1));
                      v_t_242295 = v_s_242294;
                      break;
                    }
                    default: heff_nomatch(v_body_242289);
                    }
                    V v_t_242296 = ({ V rv_1 = heff_get_n(v_t_242295, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242292, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242297 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242289)}), v_t_242296});
                    V v_t_242300;
                    switch (heff_tag_of(v_body_242289)) {
                    case TAG_At: {
                      V v_s_242299 = heff_field(v_body_242289, 1);
                      heff_take_n(v_body_242289, 2ULL, 2);
                      v_t_242300 = v_s_242299;
                      break;
                    }
                    default: heff_nomatch(v_body_242289);
                    }
                    V v_t_242301 = ({ V rv_1 = heff_get_n(v_t_242300, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242302 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242288, v_t_242297}), v_t_242301});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242287; V a_2 = v_t_242302; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242287); r_; });
                  }
                }
              }
            }
            case TAG_EAnn: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242305 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242307 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam46, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242305));
              {
                V v_field_242309 = v_t_242307.f[1];
                int64_t v_tag_242308 = ((int64_t)v_t_242307.f[0]);
                if ((v_tag_242308 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242311 = v_field_242309;
                  V v_t_242312 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str249), heff_strAppend(heff_dup(v_x_242311), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str250)));
                  V v_t_242313 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str251), heff_strAppend(v_x_242311, v_t_242312));
                  V v_t_242316;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242315 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242316 = v_s_242315;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242313}), v_t_242316});
                } else {
                  heff_drop(v_field_242309);
                  V v_t_242317 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242318 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242317}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242319 = v_t_242318.f[0];
                    V v_field_242320 = v_t_242318.f[1];
                    V v_x_242321 = v_field_242319;
                    V v_y_242322 = v_field_242320;
                    V v_body_242323 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242326;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242325 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242326 = v_s_242325;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242329;
                    switch (heff_tag_of(v_body_242323)) {
                    case TAG_At: {
                      V v_s_242328 = heff_dup(heff_field(v_body_242323, 1));
                      v_t_242329 = v_s_242328;
                      break;
                    }
                    default: heff_nomatch(v_body_242323);
                    }
                    V v_t_242330 = ({ V rv_1 = heff_get_n(v_t_242329, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242326, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242331 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242323)}), v_t_242330});
                    V v_t_242334;
                    switch (heff_tag_of(v_body_242323)) {
                    case TAG_At: {
                      V v_s_242333 = heff_field(v_body_242323, 1);
                      heff_take_n(v_body_242323, 2ULL, 2);
                      v_t_242334 = v_s_242333;
                      break;
                    }
                    default: heff_nomatch(v_body_242323);
                    }
                    V v_t_242335 = ({ V rv_1 = heff_get_n(v_t_242334, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242336 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242322, v_t_242331}), v_t_242335});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242321; V a_2 = v_t_242336; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242321); r_; });
                  }
                }
              }
            }
            case TAG_ESpec: {
              heff_take_n(v_x312111_241835, 0ULL, 4);
              heff_drop(v_fsp_241836);
              V v_xs_242341 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242343 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam47, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242341));
              {
                V v_field_242345 = v_t_242343.f[1];
                int64_t v_tag_242344 = ((int64_t)v_t_242343.f[0]);
                if ((v_tag_242344 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242347 = v_field_242345;
                  V v_t_242348 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str252), heff_strAppend(heff_dup(v_x_242347), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str253)));
                  V v_t_242349 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str254), heff_strAppend(v_x_242347, v_t_242348));
                  V v_t_242352;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242351 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242352 = v_s_242351;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242349}), v_t_242352});
                } else {
                  heff_drop(v_field_242345);
                  V v_t_242353 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242354 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242353}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242355 = v_t_242354.f[0];
                    V v_field_242356 = v_t_242354.f[1];
                    V v_x_242357 = v_field_242355;
                    V v_y_242358 = v_field_242356;
                    V v_body_242359 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242362;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242361 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242362 = v_s_242361;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242365;
                    switch (heff_tag_of(v_body_242359)) {
                    case TAG_At: {
                      V v_s_242364 = heff_dup(heff_field(v_body_242359, 1));
                      v_t_242365 = v_s_242364;
                      break;
                    }
                    default: heff_nomatch(v_body_242359);
                    }
                    V v_t_242366 = ({ V rv_1 = heff_get_n(v_t_242365, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242362, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242367 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242359)}), v_t_242366});
                    V v_t_242370;
                    switch (heff_tag_of(v_body_242359)) {
                    case TAG_At: {
                      V v_s_242369 = heff_field(v_body_242359, 1);
                      heff_take_n(v_body_242359, 2ULL, 2);
                      v_t_242370 = v_s_242369;
                      break;
                    }
                    default: heff_nomatch(v_body_242359);
                    }
                    V v_t_242371 = ({ V rv_1 = heff_get_n(v_t_242370, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242372 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242358, v_t_242367}), v_t_242371});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242357; V a_2 = v_t_242372; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242357); r_; });
                  }
                }
              }
            }
            case TAG_ESig: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242374 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242376 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam48, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242374));
              {
                V v_field_242378 = v_t_242376.f[1];
                int64_t v_tag_242377 = ((int64_t)v_t_242376.f[0]);
                if ((v_tag_242377 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242380 = v_field_242378;
                  V v_t_242381 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str255), heff_strAppend(heff_dup(v_x_242380), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str256)));
                  V v_t_242382 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str257), heff_strAppend(v_x_242380, v_t_242381));
                  V v_t_242385;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242384 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242385 = v_s_242384;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242382}), v_t_242385});
                } else {
                  heff_drop(v_field_242378);
                  V v_t_242386 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242387 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242386}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242388 = v_t_242387.f[0];
                    V v_field_242389 = v_t_242387.f[1];
                    V v_x_242390 = v_field_242388;
                    V v_y_242391 = v_field_242389;
                    V v_body_242392 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242395;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242394 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242395 = v_s_242394;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242398;
                    switch (heff_tag_of(v_body_242392)) {
                    case TAG_At: {
                      V v_s_242397 = heff_dup(heff_field(v_body_242392, 1));
                      v_t_242398 = v_s_242397;
                      break;
                    }
                    default: heff_nomatch(v_body_242392);
                    }
                    V v_t_242399 = ({ V rv_1 = heff_get_n(v_t_242398, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242395, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242400 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242392)}), v_t_242399});
                    V v_t_242403;
                    switch (heff_tag_of(v_body_242392)) {
                    case TAG_At: {
                      V v_s_242402 = heff_field(v_body_242392, 1);
                      heff_take_n(v_body_242392, 2ULL, 2);
                      v_t_242403 = v_s_242402;
                      break;
                    }
                    default: heff_nomatch(v_body_242392);
                    }
                    V v_t_242404 = ({ V rv_1 = heff_get_n(v_t_242403, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242405 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242391, v_t_242400}), v_t_242404});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242390; V a_2 = v_t_242405; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242390); r_; });
                  }
                }
              }
            }
            case TAG_ESum: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242407 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242409 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam49, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242407));
              {
                V v_field_242411 = v_t_242409.f[1];
                int64_t v_tag_242410 = ((int64_t)v_t_242409.f[0]);
                if ((v_tag_242410 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242413 = v_field_242411;
                  V v_t_242414 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str258), heff_strAppend(heff_dup(v_x_242413), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str259)));
                  V v_t_242415 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str260), heff_strAppend(v_x_242413, v_t_242414));
                  V v_t_242418;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242417 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242418 = v_s_242417;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242415}), v_t_242418});
                } else {
                  heff_drop(v_field_242411);
                  V v_t_242419 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242420 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242419}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242421 = v_t_242420.f[0];
                    V v_field_242422 = v_t_242420.f[1];
                    V v_x_242423 = v_field_242421;
                    V v_y_242424 = v_field_242422;
                    V v_body_242425 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242428;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242427 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242428 = v_s_242427;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242431;
                    switch (heff_tag_of(v_body_242425)) {
                    case TAG_At: {
                      V v_s_242430 = heff_dup(heff_field(v_body_242425, 1));
                      v_t_242431 = v_s_242430;
                      break;
                    }
                    default: heff_nomatch(v_body_242425);
                    }
                    V v_t_242432 = ({ V rv_1 = heff_get_n(v_t_242431, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242428, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242433 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242425)}), v_t_242432});
                    V v_t_242436;
                    switch (heff_tag_of(v_body_242425)) {
                    case TAG_At: {
                      V v_s_242435 = heff_field(v_body_242425, 1);
                      heff_take_n(v_body_242425, 2ULL, 2);
                      v_t_242436 = v_s_242435;
                      break;
                    }
                    default: heff_nomatch(v_body_242425);
                    }
                    V v_t_242437 = ({ V rv_1 = heff_get_n(v_t_242436, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242438 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242424, v_t_242433}), v_t_242437});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242423; V a_2 = v_t_242438; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242423); r_; });
                  }
                }
              }
            }
            case TAG_EStruct: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242440 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242442 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam50, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242440));
              {
                V v_field_242444 = v_t_242442.f[1];
                int64_t v_tag_242443 = ((int64_t)v_t_242442.f[0]);
                if ((v_tag_242443 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242446 = v_field_242444;
                  V v_t_242447 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str261), heff_strAppend(heff_dup(v_x_242446), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str262)));
                  V v_t_242448 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str263), heff_strAppend(v_x_242446, v_t_242447));
                  V v_t_242451;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242450 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242451 = v_s_242450;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242448}), v_t_242451});
                } else {
                  heff_drop(v_field_242444);
                  V v_t_242452 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242453 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242452}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242454 = v_t_242453.f[0];
                    V v_field_242455 = v_t_242453.f[1];
                    V v_x_242456 = v_field_242454;
                    V v_y_242457 = v_field_242455;
                    V v_body_242458 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242461;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242460 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242461 = v_s_242460;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242464;
                    switch (heff_tag_of(v_body_242458)) {
                    case TAG_At: {
                      V v_s_242463 = heff_dup(heff_field(v_body_242458, 1));
                      v_t_242464 = v_s_242463;
                      break;
                    }
                    default: heff_nomatch(v_body_242458);
                    }
                    V v_t_242465 = ({ V rv_1 = heff_get_n(v_t_242464, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242461, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242466 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242458)}), v_t_242465});
                    V v_t_242469;
                    switch (heff_tag_of(v_body_242458)) {
                    case TAG_At: {
                      V v_s_242468 = heff_field(v_body_242458, 1);
                      heff_take_n(v_body_242458, 2ULL, 2);
                      v_t_242469 = v_s_242468;
                      break;
                    }
                    default: heff_nomatch(v_body_242458);
                    }
                    V v_t_242470 = ({ V rv_1 = heff_get_n(v_t_242469, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242471 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242457, v_t_242466}), v_t_242470});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242456; V a_2 = v_t_242471; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242456); r_; });
                  }
                }
              }
            }
            case TAG_EUpdate: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242474 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242476 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam51, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242474));
              {
                V v_field_242478 = v_t_242476.f[1];
                int64_t v_tag_242477 = ((int64_t)v_t_242476.f[0]);
                if ((v_tag_242477 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242480 = v_field_242478;
                  V v_t_242481 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str264), heff_strAppend(heff_dup(v_x_242480), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str265)));
                  V v_t_242482 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str266), heff_strAppend(v_x_242480, v_t_242481));
                  V v_t_242485;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242484 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242485 = v_s_242484;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242482}), v_t_242485});
                } else {
                  heff_drop(v_field_242478);
                  V v_t_242486 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242487 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242486}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242488 = v_t_242487.f[0];
                    V v_field_242489 = v_t_242487.f[1];
                    V v_x_242490 = v_field_242488;
                    V v_y_242491 = v_field_242489;
                    V v_body_242492 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242495;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242494 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242495 = v_s_242494;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242498;
                    switch (heff_tag_of(v_body_242492)) {
                    case TAG_At: {
                      V v_s_242497 = heff_dup(heff_field(v_body_242492, 1));
                      v_t_242498 = v_s_242497;
                      break;
                    }
                    default: heff_nomatch(v_body_242492);
                    }
                    V v_t_242499 = ({ V rv_1 = heff_get_n(v_t_242498, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242495, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242500 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242492)}), v_t_242499});
                    V v_t_242503;
                    switch (heff_tag_of(v_body_242492)) {
                    case TAG_At: {
                      V v_s_242502 = heff_field(v_body_242492, 1);
                      heff_take_n(v_body_242492, 2ULL, 2);
                      v_t_242503 = v_s_242502;
                      break;
                    }
                    default: heff_nomatch(v_body_242492);
                    }
                    V v_t_242504 = ({ V rv_1 = heff_get_n(v_t_242503, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242505 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242491, v_t_242500}), v_t_242504});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242490; V a_2 = v_t_242505; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242490); r_; });
                  }
                }
              }
            }
            case TAG_EMatch: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242508 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242510 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam52, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242508));
              {
                V v_field_242512 = v_t_242510.f[1];
                int64_t v_tag_242511 = ((int64_t)v_t_242510.f[0]);
                if ((v_tag_242511 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242514 = v_field_242512;
                  V v_t_242515 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str267), heff_strAppend(heff_dup(v_x_242514), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str268)));
                  V v_t_242516 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str269), heff_strAppend(v_x_242514, v_t_242515));
                  V v_t_242519;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242518 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242519 = v_s_242518;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242516}), v_t_242519});
                } else {
                  heff_drop(v_field_242512);
                  V v_t_242520 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242521 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242520}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242522 = v_t_242521.f[0];
                    V v_field_242523 = v_t_242521.f[1];
                    V v_x_242524 = v_field_242522;
                    V v_y_242525 = v_field_242523;
                    V v_body_242526 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242529;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242528 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242529 = v_s_242528;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242532;
                    switch (heff_tag_of(v_body_242526)) {
                    case TAG_At: {
                      V v_s_242531 = heff_dup(heff_field(v_body_242526, 1));
                      v_t_242532 = v_s_242531;
                      break;
                    }
                    default: heff_nomatch(v_body_242526);
                    }
                    V v_t_242533 = ({ V rv_1 = heff_get_n(v_t_242532, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242529, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242534 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242526)}), v_t_242533});
                    V v_t_242537;
                    switch (heff_tag_of(v_body_242526)) {
                    case TAG_At: {
                      V v_s_242536 = heff_field(v_body_242526, 1);
                      heff_take_n(v_body_242526, 2ULL, 2);
                      v_t_242537 = v_s_242536;
                      break;
                    }
                    default: heff_nomatch(v_body_242526);
                    }
                    V v_t_242538 = ({ V rv_1 = heff_get_n(v_t_242537, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242539 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242525, v_t_242534}), v_t_242538});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242524; V a_2 = v_t_242539; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242524); r_; });
                  }
                }
              }
            }
            case TAG_ELetIn: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242542 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242544 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam53, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242542));
              {
                V v_field_242546 = v_t_242544.f[1];
                int64_t v_tag_242545 = ((int64_t)v_t_242544.f[0]);
                if ((v_tag_242545 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242548 = v_field_242546;
                  V v_t_242549 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str270), heff_strAppend(heff_dup(v_x_242548), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str271)));
                  V v_t_242550 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str272), heff_strAppend(v_x_242548, v_t_242549));
                  V v_t_242553;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242552 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242553 = v_s_242552;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242550}), v_t_242553});
                } else {
                  heff_drop(v_field_242546);
                  V v_t_242554 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242555 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242554}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242556 = v_t_242555.f[0];
                    V v_field_242557 = v_t_242555.f[1];
                    V v_x_242558 = v_field_242556;
                    V v_y_242559 = v_field_242557;
                    V v_body_242560 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242563;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242562 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242563 = v_s_242562;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242566;
                    switch (heff_tag_of(v_body_242560)) {
                    case TAG_At: {
                      V v_s_242565 = heff_dup(heff_field(v_body_242560, 1));
                      v_t_242566 = v_s_242565;
                      break;
                    }
                    default: heff_nomatch(v_body_242560);
                    }
                    V v_t_242567 = ({ V rv_1 = heff_get_n(v_t_242566, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242563, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242568 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242560)}), v_t_242567});
                    V v_t_242571;
                    switch (heff_tag_of(v_body_242560)) {
                    case TAG_At: {
                      V v_s_242570 = heff_field(v_body_242560, 1);
                      heff_take_n(v_body_242560, 2ULL, 2);
                      v_t_242571 = v_s_242570;
                      break;
                    }
                    default: heff_nomatch(v_body_242560);
                    }
                    V v_t_242572 = ({ V rv_1 = heff_get_n(v_t_242571, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242573 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242559, v_t_242568}), v_t_242572});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242558; V a_2 = v_t_242573; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242558); r_; });
                  }
                }
              }
            }
            case TAG_EDo: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242575 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242577 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam54, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242575));
              {
                V v_field_242579 = v_t_242577.f[1];
                int64_t v_tag_242578 = ((int64_t)v_t_242577.f[0]);
                if ((v_tag_242578 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242581 = v_field_242579;
                  V v_t_242582 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str273), heff_strAppend(heff_dup(v_x_242581), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str274)));
                  V v_t_242583 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str275), heff_strAppend(v_x_242581, v_t_242582));
                  V v_t_242586;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242585 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242586 = v_s_242585;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242583}), v_t_242586});
                } else {
                  heff_drop(v_field_242579);
                  V v_t_242587 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242588 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242587}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242589 = v_t_242588.f[0];
                    V v_field_242590 = v_t_242588.f[1];
                    V v_x_242591 = v_field_242589;
                    V v_y_242592 = v_field_242590;
                    V v_body_242593 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242596;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242595 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242596 = v_s_242595;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242599;
                    switch (heff_tag_of(v_body_242593)) {
                    case TAG_At: {
                      V v_s_242598 = heff_dup(heff_field(v_body_242593, 1));
                      v_t_242599 = v_s_242598;
                      break;
                    }
                    default: heff_nomatch(v_body_242593);
                    }
                    V v_t_242600 = ({ V rv_1 = heff_get_n(v_t_242599, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242596, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242601 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242593)}), v_t_242600});
                    V v_t_242604;
                    switch (heff_tag_of(v_body_242593)) {
                    case TAG_At: {
                      V v_s_242603 = heff_field(v_body_242593, 1);
                      heff_take_n(v_body_242593, 2ULL, 2);
                      v_t_242604 = v_s_242603;
                      break;
                    }
                    default: heff_nomatch(v_body_242593);
                    }
                    V v_t_242605 = ({ V rv_1 = heff_get_n(v_t_242604, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242606 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242592, v_t_242601}), v_t_242605});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242591; V a_2 = v_t_242606; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242591); r_; });
                  }
                }
              }
            }
            case TAG_ELocal: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242609 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242611 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam55, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242609));
              {
                V v_field_242613 = v_t_242611.f[1];
                int64_t v_tag_242612 = ((int64_t)v_t_242611.f[0]);
                if ((v_tag_242612 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242615 = v_field_242613;
                  V v_t_242616 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str276), heff_strAppend(heff_dup(v_x_242615), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str277)));
                  V v_t_242617 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str278), heff_strAppend(v_x_242615, v_t_242616));
                  V v_t_242620;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242619 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242620 = v_s_242619;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242617}), v_t_242620});
                } else {
                  heff_drop(v_field_242613);
                  V v_t_242621 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242622 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242621}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242623 = v_t_242622.f[0];
                    V v_field_242624 = v_t_242622.f[1];
                    V v_x_242625 = v_field_242623;
                    V v_y_242626 = v_field_242624;
                    V v_body_242627 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242630;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242629 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242630 = v_s_242629;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242633;
                    switch (heff_tag_of(v_body_242627)) {
                    case TAG_At: {
                      V v_s_242632 = heff_dup(heff_field(v_body_242627, 1));
                      v_t_242633 = v_s_242632;
                      break;
                    }
                    default: heff_nomatch(v_body_242627);
                    }
                    V v_t_242634 = ({ V rv_1 = heff_get_n(v_t_242633, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242630, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242635 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242627)}), v_t_242634});
                    V v_t_242638;
                    switch (heff_tag_of(v_body_242627)) {
                    case TAG_At: {
                      V v_s_242637 = heff_field(v_body_242627, 1);
                      heff_take_n(v_body_242627, 2ULL, 2);
                      v_t_242638 = v_s_242637;
                      break;
                    }
                    default: heff_nomatch(v_body_242627);
                    }
                    V v_t_242639 = ({ V rv_1 = heff_get_n(v_t_242638, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242640 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242626, v_t_242635}), v_t_242639});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242625; V a_2 = v_t_242640; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242625); r_; });
                  }
                }
              }
            }
            case TAG_EInvalid: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242642 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242644 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam56, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242642));
              {
                V v_field_242646 = v_t_242644.f[1];
                int64_t v_tag_242645 = ((int64_t)v_t_242644.f[0]);
                if ((v_tag_242645 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242648 = v_field_242646;
                  V v_t_242649 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str279), heff_strAppend(heff_dup(v_x_242648), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str280)));
                  V v_t_242650 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str281), heff_strAppend(v_x_242648, v_t_242649));
                  V v_t_242653;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242652 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242653 = v_s_242652;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242650}), v_t_242653});
                } else {
                  heff_drop(v_field_242646);
                  V v_t_242654 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242655 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242654}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242656 = v_t_242655.f[0];
                    V v_field_242657 = v_t_242655.f[1];
                    V v_x_242658 = v_field_242656;
                    V v_y_242659 = v_field_242657;
                    V v_body_242660 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242663;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242662 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242663 = v_s_242662;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242666;
                    switch (heff_tag_of(v_body_242660)) {
                    case TAG_At: {
                      V v_s_242665 = heff_dup(heff_field(v_body_242660, 1));
                      v_t_242666 = v_s_242665;
                      break;
                    }
                    default: heff_nomatch(v_body_242660);
                    }
                    V v_t_242667 = ({ V rv_1 = heff_get_n(v_t_242666, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242663, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242668 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242660)}), v_t_242667});
                    V v_t_242671;
                    switch (heff_tag_of(v_body_242660)) {
                    case TAG_At: {
                      V v_s_242670 = heff_field(v_body_242660, 1);
                      heff_take_n(v_body_242660, 2ULL, 2);
                      v_t_242671 = v_s_242670;
                      break;
                    }
                    default: heff_nomatch(v_body_242660);
                    }
                    V v_t_242672 = ({ V rv_1 = heff_get_n(v_t_242671, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242673 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242659, v_t_242668}), v_t_242672});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242658; V a_2 = v_t_242673; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242658); r_; });
                  }
                }
              }
            }
            case TAG_EAssign: {
              heff_take_n(v_x312111_241835, 0ULL, 3);
              heff_drop(v_fsp_241836);
              V v_xs_242677 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242679 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam57, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242677));
              {
                V v_field_242681 = v_t_242679.f[1];
                int64_t v_tag_242680 = ((int64_t)v_t_242679.f[0]);
                if ((v_tag_242680 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242683 = v_field_242681;
                  V v_t_242684 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str282), heff_strAppend(heff_dup(v_x_242683), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str283)));
                  V v_t_242685 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str284), heff_strAppend(v_x_242683, v_t_242684));
                  V v_t_242688;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242687 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242688 = v_s_242687;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242685}), v_t_242688});
                } else {
                  heff_drop(v_field_242681);
                  V v_t_242689 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242690 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242689}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242691 = v_t_242690.f[0];
                    V v_field_242692 = v_t_242690.f[1];
                    V v_x_242693 = v_field_242691;
                    V v_y_242694 = v_field_242692;
                    V v_body_242695 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242698;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242697 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242698 = v_s_242697;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242701;
                    switch (heff_tag_of(v_body_242695)) {
                    case TAG_At: {
                      V v_s_242700 = heff_dup(heff_field(v_body_242695, 1));
                      v_t_242701 = v_s_242700;
                      break;
                    }
                    default: heff_nomatch(v_body_242695);
                    }
                    V v_t_242702 = ({ V rv_1 = heff_get_n(v_t_242701, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242698, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242703 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242695)}), v_t_242702});
                    V v_t_242706;
                    switch (heff_tag_of(v_body_242695)) {
                    case TAG_At: {
                      V v_s_242705 = heff_field(v_body_242695, 1);
                      heff_take_n(v_body_242695, 2ULL, 2);
                      v_t_242706 = v_s_242705;
                      break;
                    }
                    default: heff_nomatch(v_body_242695);
                    }
                    V v_t_242707 = ({ V rv_1 = heff_get_n(v_t_242706, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242708 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242694, v_t_242703}), v_t_242707});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242693; V a_2 = v_t_242708; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242693); r_; });
                  }
                }
              }
            }
            case TAG_EWhile: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242711 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242713 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam58, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242711));
              {
                V v_field_242715 = v_t_242713.f[1];
                int64_t v_tag_242714 = ((int64_t)v_t_242713.f[0]);
                if ((v_tag_242714 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242717 = v_field_242715;
                  V v_t_242718 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str285), heff_strAppend(heff_dup(v_x_242717), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str286)));
                  V v_t_242719 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str287), heff_strAppend(v_x_242717, v_t_242718));
                  V v_t_242722;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242721 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242722 = v_s_242721;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242719}), v_t_242722});
                } else {
                  heff_drop(v_field_242715);
                  V v_t_242723 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242724 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242723}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242725 = v_t_242724.f[0];
                    V v_field_242726 = v_t_242724.f[1];
                    V v_x_242727 = v_field_242725;
                    V v_y_242728 = v_field_242726;
                    V v_body_242729 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242732;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242731 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242732 = v_s_242731;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242735;
                    switch (heff_tag_of(v_body_242729)) {
                    case TAG_At: {
                      V v_s_242734 = heff_dup(heff_field(v_body_242729, 1));
                      v_t_242735 = v_s_242734;
                      break;
                    }
                    default: heff_nomatch(v_body_242729);
                    }
                    V v_t_242736 = ({ V rv_1 = heff_get_n(v_t_242735, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242732, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242737 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242729)}), v_t_242736});
                    V v_t_242740;
                    switch (heff_tag_of(v_body_242729)) {
                    case TAG_At: {
                      V v_s_242739 = heff_field(v_body_242729, 1);
                      heff_take_n(v_body_242729, 2ULL, 2);
                      v_t_242740 = v_s_242739;
                      break;
                    }
                    default: heff_nomatch(v_body_242729);
                    }
                    V v_t_242741 = ({ V rv_1 = heff_get_n(v_t_242740, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242742 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242728, v_t_242737}), v_t_242741});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242727; V a_2 = v_t_242742; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242727); r_; });
                  }
                }
              }
            }
            case TAG_EFor: {
              V v_q_242743 = heff_field(v_x312111_241835, 0);
              V v_c_242744 = heff_field(v_x312111_241835, 1);
              V v_body_242745 = heff_field(v_x312111_241835, 2);
              heff_take_n(v_x312111_241835, 7ULL, 3);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_xs_242746 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242748 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam59, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242746));
              {
                V v_field_242750 = v_t_242748.f[1];
                int64_t v_tag_242749 = ((int64_t)v_t_242748.f[0]);
                if ((v_tag_242749 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop(v_fsp_241836);
                  heff_drop(v_q_242743);
                  heff_drop(v_c_242744);
                  heff_drop(v_body_242745);
                  V v_x_242752 = v_field_242750;
                  V v_t_242753 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str288), heff_strAppend(heff_dup(v_x_242752), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str289)));
                  V v_t_242754 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str290), heff_strAppend(v_x_242752, v_t_242753));
                  V v_t_242757;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242756 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242757 = v_s_242756;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242754}), v_t_242757});
                } else {
                  heff_drop_cell(v_ru_24x3_242_24At, 2);
                  heff_drop(v_field_242750);
                  V v_t_242758 = (g_heff_2esyntax_2epresyntax_2egathered(v_p_24758, v_fsp_241836, v_q_242743, v_c_242744, v_body_242745));
                  V v_t_242759 = (g_prelude_2e_2b_2b(v_t_242758, v_rest_243));
                  return heff_tail(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_t_242759, v_end_244});
                }
              }
            }
            case TAG_EIfThen: {
              heff_take_n(v_x312111_241835, 0ULL, 2);
              heff_drop(v_fsp_241836);
              V v_xs_242762 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242764 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam60, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242762));
              {
                V v_field_242766 = v_t_242764.f[1];
                int64_t v_tag_242765 = ((int64_t)v_t_242764.f[0]);
                if ((v_tag_242765 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242768 = v_field_242766;
                  V v_t_242769 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str291), heff_strAppend(heff_dup(v_x_242768), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str292)));
                  V v_t_242770 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str293), heff_strAppend(v_x_242768, v_t_242769));
                  V v_t_242773;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242772 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242773 = v_s_242772;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242770}), v_t_242773});
                } else {
                  heff_drop(v_field_242766);
                  V v_t_242774 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242775 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242774}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242776 = v_t_242775.f[0];
                    V v_field_242777 = v_t_242775.f[1];
                    V v_x_242778 = v_field_242776;
                    V v_y_242779 = v_field_242777;
                    V v_body_242780 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242783;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242782 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242783 = v_s_242782;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242786;
                    switch (heff_tag_of(v_body_242780)) {
                    case TAG_At: {
                      V v_s_242785 = heff_dup(heff_field(v_body_242780, 1));
                      v_t_242786 = v_s_242785;
                      break;
                    }
                    default: heff_nomatch(v_body_242780);
                    }
                    V v_t_242787 = ({ V rv_1 = heff_get_n(v_t_242786, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242783, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242788 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242780)}), v_t_242787});
                    V v_t_242791;
                    switch (heff_tag_of(v_body_242780)) {
                    case TAG_At: {
                      V v_s_242790 = heff_field(v_body_242780, 1);
                      heff_take_n(v_body_242780, 2ULL, 2);
                      v_t_242791 = v_s_242790;
                      break;
                    }
                    default: heff_nomatch(v_body_242780);
                    }
                    V v_t_242792 = ({ V rv_1 = heff_get_n(v_t_242791, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242793 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242779, v_t_242788}), v_t_242792});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242778; V a_2 = v_t_242793; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242778); r_; });
                  }
                }
              }
            }
            case TAG_EBreak: {
              heff_drop(v_fsp_241836);
              V v_xs_242794 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242796 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam61, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242794));
              {
                V v_field_242798 = v_t_242796.f[1];
                int64_t v_tag_242797 = ((int64_t)v_t_242796.f[0]);
                if ((v_tag_242797 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242800 = v_field_242798;
                  V v_t_242801 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str294), heff_strAppend(heff_dup(v_x_242800), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str295)));
                  V v_t_242802 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str296), heff_strAppend(v_x_242800, v_t_242801));
                  V v_t_242805;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242804 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242805 = v_s_242804;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242802}), v_t_242805});
                } else {
                  heff_drop(v_field_242798);
                  V v_t_242806 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242807 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242806}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242808 = v_t_242807.f[0];
                    V v_field_242809 = v_t_242807.f[1];
                    V v_x_242810 = v_field_242808;
                    V v_y_242811 = v_field_242809;
                    V v_body_242812 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242815;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242814 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242815 = v_s_242814;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242818;
                    switch (heff_tag_of(v_body_242812)) {
                    case TAG_At: {
                      V v_s_242817 = heff_dup(heff_field(v_body_242812, 1));
                      v_t_242818 = v_s_242817;
                      break;
                    }
                    default: heff_nomatch(v_body_242812);
                    }
                    V v_t_242819 = ({ V rv_1 = heff_get_n(v_t_242818, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242815, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242820 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242812)}), v_t_242819});
                    V v_t_242823;
                    switch (heff_tag_of(v_body_242812)) {
                    case TAG_At: {
                      V v_s_242822 = heff_field(v_body_242812, 1);
                      heff_take_n(v_body_242812, 2ULL, 2);
                      v_t_242823 = v_s_242822;
                      break;
                    }
                    default: heff_nomatch(v_body_242812);
                    }
                    V v_t_242824 = ({ V rv_1 = heff_get_n(v_t_242823, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242825 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242811, v_t_242820}), v_t_242824});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242810; V a_2 = v_t_242825; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242810); r_; });
                  }
                }
              }
            }
            case TAG_EContinue: {
              heff_drop(v_fsp_241836);
              V v_xs_242826 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242828 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam62, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242826));
              {
                V v_field_242830 = v_t_242828.f[1];
                int64_t v_tag_242829 = ((int64_t)v_t_242828.f[0]);
                if ((v_tag_242829 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242832 = v_field_242830;
                  V v_t_242833 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str297), heff_strAppend(heff_dup(v_x_242832), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str298)));
                  V v_t_242834 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str299), heff_strAppend(v_x_242832, v_t_242833));
                  V v_t_242837;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242836 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242837 = v_s_242836;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242834}), v_t_242837});
                } else {
                  heff_drop(v_field_242830);
                  V v_t_242838 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242839 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242838}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242840 = v_t_242839.f[0];
                    V v_field_242841 = v_t_242839.f[1];
                    V v_x_242842 = v_field_242840;
                    V v_y_242843 = v_field_242841;
                    V v_body_242844 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242847;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242846 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242847 = v_s_242846;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242850;
                    switch (heff_tag_of(v_body_242844)) {
                    case TAG_At: {
                      V v_s_242849 = heff_dup(heff_field(v_body_242844, 1));
                      v_t_242850 = v_s_242849;
                      break;
                    }
                    default: heff_nomatch(v_body_242844);
                    }
                    V v_t_242851 = ({ V rv_1 = heff_get_n(v_t_242850, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242847, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242852 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242844)}), v_t_242851});
                    V v_t_242855;
                    switch (heff_tag_of(v_body_242844)) {
                    case TAG_At: {
                      V v_s_242854 = heff_field(v_body_242844, 1);
                      heff_take_n(v_body_242844, 2ULL, 2);
                      v_t_242855 = v_s_242854;
                      break;
                    }
                    default: heff_nomatch(v_body_242844);
                    }
                    V v_t_242856 = ({ V rv_1 = heff_get_n(v_t_242855, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242857 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242843, v_t_242852}), v_t_242856});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242842; V a_2 = v_t_242857; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242842); r_; });
                  }
                }
              }
            }
            case TAG_EReturn: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242859 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242861 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam63, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242859));
              {
                V v_field_242863 = v_t_242861.f[1];
                int64_t v_tag_242862 = ((int64_t)v_t_242861.f[0]);
                if ((v_tag_242862 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242865 = v_field_242863;
                  V v_t_242866 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str300), heff_strAppend(heff_dup(v_x_242865), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str301)));
                  V v_t_242867 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str302), heff_strAppend(v_x_242865, v_t_242866));
                  V v_t_242870;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242869 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242870 = v_s_242869;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242867}), v_t_242870});
                } else {
                  heff_drop(v_field_242863);
                  V v_t_242871 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242872 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242871}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242873 = v_t_242872.f[0];
                    V v_field_242874 = v_t_242872.f[1];
                    V v_x_242875 = v_field_242873;
                    V v_y_242876 = v_field_242874;
                    V v_body_242877 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242880;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242879 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242880 = v_s_242879;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242883;
                    switch (heff_tag_of(v_body_242877)) {
                    case TAG_At: {
                      V v_s_242882 = heff_dup(heff_field(v_body_242877, 1));
                      v_t_242883 = v_s_242882;
                      break;
                    }
                    default: heff_nomatch(v_body_242877);
                    }
                    V v_t_242884 = ({ V rv_1 = heff_get_n(v_t_242883, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242880, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242885 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242877)}), v_t_242884});
                    V v_t_242888;
                    switch (heff_tag_of(v_body_242877)) {
                    case TAG_At: {
                      V v_s_242887 = heff_field(v_body_242877, 1);
                      heff_take_n(v_body_242877, 2ULL, 2);
                      v_t_242888 = v_s_242887;
                      break;
                    }
                    default: heff_nomatch(v_body_242877);
                    }
                    V v_t_242889 = ({ V rv_1 = heff_get_n(v_t_242888, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242890 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242876, v_t_242885}), v_t_242889});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242875; V a_2 = v_t_242890; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242875); r_; });
                  }
                }
              }
            }
            case TAG_ENest: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242892 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242894 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam64, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242892));
              {
                V v_field_242896 = v_t_242894.f[1];
                int64_t v_tag_242895 = ((int64_t)v_t_242894.f[0]);
                if ((v_tag_242895 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242898 = v_field_242896;
                  V v_t_242899 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str303), heff_strAppend(heff_dup(v_x_242898), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str304)));
                  V v_t_242900 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str305), heff_strAppend(v_x_242898, v_t_242899));
                  V v_t_242903;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242902 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242903 = v_s_242902;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242900}), v_t_242903});
                } else {
                  heff_drop(v_field_242896);
                  V v_t_242904 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242905 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242904}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242906 = v_t_242905.f[0];
                    V v_field_242907 = v_t_242905.f[1];
                    V v_x_242908 = v_field_242906;
                    V v_y_242909 = v_field_242907;
                    V v_body_242910 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242913;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242912 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242913 = v_s_242912;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242916;
                    switch (heff_tag_of(v_body_242910)) {
                    case TAG_At: {
                      V v_s_242915 = heff_dup(heff_field(v_body_242910, 1));
                      v_t_242916 = v_s_242915;
                      break;
                    }
                    default: heff_nomatch(v_body_242910);
                    }
                    V v_t_242917 = ({ V rv_1 = heff_get_n(v_t_242916, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242913, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242918 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242910)}), v_t_242917});
                    V v_t_242921;
                    switch (heff_tag_of(v_body_242910)) {
                    case TAG_At: {
                      V v_s_242920 = heff_field(v_body_242910, 1);
                      heff_take_n(v_body_242910, 2ULL, 2);
                      v_t_242921 = v_s_242920;
                      break;
                    }
                    default: heff_nomatch(v_body_242910);
                    }
                    V v_t_242922 = ({ V rv_1 = heff_get_n(v_t_242921, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242923 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242909, v_t_242918}), v_t_242922});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242908; V a_2 = v_t_242923; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242908); r_; });
                  }
                }
              }
            }
            case TAG_ELazy: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242925 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242927 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam65, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242925));
              {
                V v_field_242929 = v_t_242927.f[1];
                int64_t v_tag_242928 = ((int64_t)v_t_242927.f[0]);
                if ((v_tag_242928 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242931 = v_field_242929;
                  V v_t_242932 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str306), heff_strAppend(heff_dup(v_x_242931), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str307)));
                  V v_t_242933 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str308), heff_strAppend(v_x_242931, v_t_242932));
                  V v_t_242936;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242935 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242936 = v_s_242935;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242933}), v_t_242936});
                } else {
                  heff_drop(v_field_242929);
                  V v_t_242937 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242938 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242937}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242939 = v_t_242938.f[0];
                    V v_field_242940 = v_t_242938.f[1];
                    V v_x_242941 = v_field_242939;
                    V v_y_242942 = v_field_242940;
                    V v_body_242943 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242946;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242945 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242946 = v_s_242945;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242949;
                    switch (heff_tag_of(v_body_242943)) {
                    case TAG_At: {
                      V v_s_242948 = heff_dup(heff_field(v_body_242943, 1));
                      v_t_242949 = v_s_242948;
                      break;
                    }
                    default: heff_nomatch(v_body_242943);
                    }
                    V v_t_242950 = ({ V rv_1 = heff_get_n(v_t_242949, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242946, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242951 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242943)}), v_t_242950});
                    V v_t_242954;
                    switch (heff_tag_of(v_body_242943)) {
                    case TAG_At: {
                      V v_s_242953 = heff_field(v_body_242943, 1);
                      heff_take_n(v_body_242943, 2ULL, 2);
                      v_t_242954 = v_s_242953;
                      break;
                    }
                    default: heff_nomatch(v_body_242943);
                    }
                    V v_t_242955 = ({ V rv_1 = heff_get_n(v_t_242954, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242956 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242942, v_t_242951}), v_t_242955});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242941; V a_2 = v_t_242956; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242941); r_; });
                  }
                }
              }
            }
            case TAG_ETuple: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242958 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242960 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam66, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242958));
              {
                V v_field_242962 = v_t_242960.f[1];
                int64_t v_tag_242961 = ((int64_t)v_t_242960.f[0]);
                if ((v_tag_242961 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242964 = v_field_242962;
                  V v_t_242965 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str309), heff_strAppend(heff_dup(v_x_242964), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str310)));
                  V v_t_242966 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str311), heff_strAppend(v_x_242964, v_t_242965));
                  V v_t_242969;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_242968 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_242969 = v_s_242968;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242966}), v_t_242969});
                } else {
                  heff_drop(v_field_242962);
                  V v_t_242970 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_242971 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_242970}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_242972 = v_t_242971.f[0];
                    V v_field_242973 = v_t_242971.f[1];
                    V v_x_242974 = v_field_242972;
                    V v_y_242975 = v_field_242973;
                    V v_body_242976 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_242979;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_242978 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_242979 = v_s_242978;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_242982;
                    switch (heff_tag_of(v_body_242976)) {
                    case TAG_At: {
                      V v_s_242981 = heff_dup(heff_field(v_body_242976, 1));
                      v_t_242982 = v_s_242981;
                      break;
                    }
                    default: heff_nomatch(v_body_242976);
                    }
                    V v_t_242983 = ({ V rv_1 = heff_get_n(v_t_242982, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_242979, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242984 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_242976)}), v_t_242983});
                    V v_t_242987;
                    switch (heff_tag_of(v_body_242976)) {
                    case TAG_At: {
                      V v_s_242986 = heff_field(v_body_242976, 1);
                      heff_take_n(v_body_242976, 2ULL, 2);
                      v_t_242987 = v_s_242986;
                      break;
                    }
                    default: heff_nomatch(v_body_242976);
                    }
                    V v_t_242988 = ({ V rv_1 = heff_get_n(v_t_242987, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_242989 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_242975, v_t_242984}), v_t_242988});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_242974; V a_2 = v_t_242989; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_242974); r_; });
                  }
                }
              }
            }
            case TAG_ETry: {
              heff_take_n(v_x312111_241835, 0ULL, 1);
              heff_drop(v_fsp_241836);
              V v_xs_242991 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_242993 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam67, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_242991));
              {
                V v_field_242995 = v_t_242993.f[1];
                int64_t v_tag_242994 = ((int64_t)v_t_242993.f[0]);
                if ((v_tag_242994 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_242997 = v_field_242995;
                  V v_t_242998 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str312), heff_strAppend(heff_dup(v_x_242997), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str313)));
                  V v_t_242999 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str314), heff_strAppend(v_x_242997, v_t_242998));
                  V v_t_243002;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_243001 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_243002 = v_s_243001;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_242999}), v_t_243002});
                } else {
                  heff_drop(v_field_242995);
                  V v_t_243003 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_243004 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243003}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_243005 = v_t_243004.f[0];
                    V v_field_243006 = v_t_243004.f[1];
                    V v_x_243007 = v_field_243005;
                    V v_y_243008 = v_field_243006;
                    V v_body_243009 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_243012;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_243011 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_243012 = v_s_243011;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_243015;
                    switch (heff_tag_of(v_body_243009)) {
                    case TAG_At: {
                      V v_s_243014 = heff_dup(heff_field(v_body_243009, 1));
                      v_t_243015 = v_s_243014;
                      break;
                    }
                    default: heff_nomatch(v_body_243009);
                    }
                    V v_t_243016 = ({ V rv_1 = heff_get_n(v_t_243015, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243012, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_243017 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243009)}), v_t_243016});
                    V v_t_243020;
                    switch (heff_tag_of(v_body_243009)) {
                    case TAG_At: {
                      V v_s_243019 = heff_field(v_body_243009, 1);
                      heff_take_n(v_body_243009, 2ULL, 2);
                      v_t_243020 = v_s_243019;
                      break;
                    }
                    default: heff_nomatch(v_body_243009);
                    }
                    V v_t_243021 = ({ V rv_1 = heff_get_n(v_t_243020, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_243022 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243008, v_t_243017}), v_t_243021});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_243007; V a_2 = v_t_243022; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243007); r_; });
                  }
                }
              }
            }
            case TAG_EWith: {
              heff_take_n(v_x312111_241835, 0ULL, 4);
              heff_drop(v_fsp_241836);
              V v_xs_243027 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
              HeffT2 v_t_243029 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam68, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243027));
              {
                V v_field_243031 = v_t_243029.f[1];
                int64_t v_tag_243030 = ((int64_t)v_t_243029.f[0]);
                if ((v_tag_243030 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_240, 1);
                  heff_drop_rec(v_cx_241, 5);
                  heff_drop(v_rest_243);
                  heff_drop(v_end_244);
                  heff_drop_rec(v_sp_246, 2);
                  heff_drop_tag(v_x312_24759, 2);
                  heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
                  V v_x_243033 = v_field_243031;
                  V v_t_243034 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str315), heff_strAppend(heff_dup(v_x_243033), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str316)));
                  V v_t_243035 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str317), heff_strAppend(v_x_243033, v_t_243034));
                  V v_t_243038;
                  switch (heff_tag_of(v_p_24758)) {
                  case TAG_At: {
                    V v_s_243037 = heff_field(v_p_24758, 1);
                    heff_take_n(v_p_24758, 2ULL, 2);
                    v_t_243038 = v_s_243037;
                    break;
                  }
                  default: heff_nomatch(v_p_24758);
                  }
                  return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243035}), v_t_243038});
                } else {
                  heff_drop(v_field_243031);
                  V v_t_243039 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_243040 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243039}), NTAG(TAG_Nil), v_x312_24759));
                  {
                    V v_field_243041 = v_t_243040.f[0];
                    V v_field_243042 = v_t_243040.f[1];
                    V v_x_243043 = v_field_243041;
                    V v_y_243044 = v_field_243042;
                    V v_body_243045 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                    V v_t_243048;
                    switch (heff_tag_of(v_p_24758)) {
                    case TAG_At: {
                      V v_s_243047 = heff_dup(heff_field(v_p_24758, 1));
                      v_t_243048 = v_s_243047;
                      break;
                    }
                    default: heff_nomatch(v_p_24758);
                    }
                    V v_t_243051;
                    switch (heff_tag_of(v_body_243045)) {
                    case TAG_At: {
                      V v_s_243050 = heff_dup(heff_field(v_body_243045, 1));
                      v_t_243051 = v_s_243050;
                      break;
                    }
                    default: heff_nomatch(v_body_243045);
                    }
                    V v_t_243052 = ({ V rv_1 = heff_get_n(v_t_243051, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243048, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_243053 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243045)}), v_t_243052});
                    V v_t_243056;
                    switch (heff_tag_of(v_body_243045)) {
                    case TAG_At: {
                      V v_s_243055 = heff_field(v_body_243045, 1);
                      heff_take_n(v_body_243045, 2ULL, 2);
                      v_t_243056 = v_s_243055;
                      break;
                    }
                    default: heff_nomatch(v_body_243045);
                    }
                    V v_t_243057 = ({ V rv_1 = heff_get_n(v_t_243056, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_243058 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243044, v_t_243053}), v_t_243057});
                    return ({ V a_0 = v_cx_241; V a_1 = v_x_243043; V a_2 = v_t_243058; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243043); r_; });
                  }
                }
              }
            }
            default: return heff_nomatch(v_x312111_241835);
            }
          }
          default: return heff_nomatch(v_x31211_241834);
          }
        }
        case TAG_ELazy: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_243060 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_243062 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam69, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243060));
          {
            V v_field_243064 = v_t_243062.f[1];
            int64_t v_tag_243063 = ((int64_t)v_t_243062.f[0]);
            if ((v_tag_243063 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243066 = v_field_243064;
              V v_t_243067 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str318), heff_strAppend(heff_dup(v_x_243066), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str319)));
              V v_t_243068 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str320), heff_strAppend(v_x_243066, v_t_243067));
              V v_t_243071;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_243070 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_243071 = v_s_243070;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243068}), v_t_243071});
            } else {
              heff_drop(v_field_243064);
              V v_t_243072 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243073 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243072}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_243074 = v_t_243073.f[0];
                V v_field_243075 = v_t_243073.f[1];
                V v_x_243076 = v_field_243074;
                V v_y_243077 = v_field_243075;
                V v_body_243078 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243081;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_243080 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_243081 = v_s_243080;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_243084;
                switch (heff_tag_of(v_body_243078)) {
                case TAG_At: {
                  V v_s_243083 = heff_dup(heff_field(v_body_243078, 1));
                  v_t_243084 = v_s_243083;
                  break;
                }
                default: heff_nomatch(v_body_243078);
                }
                V v_t_243085 = ({ V rv_1 = heff_get_n(v_t_243084, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243081, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243086 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243078)}), v_t_243085});
                V v_t_243089;
                switch (heff_tag_of(v_body_243078)) {
                case TAG_At: {
                  V v_s_243088 = heff_field(v_body_243078, 1);
                  heff_take_n(v_body_243078, 2ULL, 2);
                  v_t_243089 = v_s_243088;
                  break;
                }
                default: heff_nomatch(v_body_243078);
                }
                V v_t_243090 = ({ V rv_1 = heff_get_n(v_t_243089, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243091 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243077, v_t_243086}), v_t_243090});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243076; V a_2 = v_t_243091; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243076); r_; });
              }
            }
          }
        }
        case TAG_ETuple: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_243093 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_243095 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam70, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243093));
          {
            V v_field_243097 = v_t_243095.f[1];
            int64_t v_tag_243096 = ((int64_t)v_t_243095.f[0]);
            if ((v_tag_243096 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243099 = v_field_243097;
              V v_t_243100 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str321), heff_strAppend(heff_dup(v_x_243099), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str322)));
              V v_t_243101 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str323), heff_strAppend(v_x_243099, v_t_243100));
              V v_t_243104;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_243103 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_243104 = v_s_243103;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243101}), v_t_243104});
            } else {
              heff_drop(v_field_243097);
              V v_t_243105 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243106 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243105}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_243107 = v_t_243106.f[0];
                V v_field_243108 = v_t_243106.f[1];
                V v_x_243109 = v_field_243107;
                V v_y_243110 = v_field_243108;
                V v_body_243111 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243114;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_243113 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_243114 = v_s_243113;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_243117;
                switch (heff_tag_of(v_body_243111)) {
                case TAG_At: {
                  V v_s_243116 = heff_dup(heff_field(v_body_243111, 1));
                  v_t_243117 = v_s_243116;
                  break;
                }
                default: heff_nomatch(v_body_243111);
                }
                V v_t_243118 = ({ V rv_1 = heff_get_n(v_t_243117, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243114, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243119 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243111)}), v_t_243118});
                V v_t_243122;
                switch (heff_tag_of(v_body_243111)) {
                case TAG_At: {
                  V v_s_243121 = heff_field(v_body_243111, 1);
                  heff_take_n(v_body_243111, 2ULL, 2);
                  v_t_243122 = v_s_243121;
                  break;
                }
                default: heff_nomatch(v_body_243111);
                }
                V v_t_243123 = ({ V rv_1 = heff_get_n(v_t_243122, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243124 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243110, v_t_243119}), v_t_243123});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243109; V a_2 = v_t_243124; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243109); r_; });
              }
            }
          }
        }
        case TAG_ETry: {
          heff_take_n(v_x3121_24760, 0ULL, 1);
          V v_xs_243126 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_243128 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam71, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243126));
          {
            V v_field_243130 = v_t_243128.f[1];
            int64_t v_tag_243129 = ((int64_t)v_t_243128.f[0]);
            if ((v_tag_243129 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243132 = v_field_243130;
              V v_t_243133 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str324), heff_strAppend(heff_dup(v_x_243132), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str325)));
              V v_t_243134 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str326), heff_strAppend(v_x_243132, v_t_243133));
              V v_t_243137;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_243136 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_243137 = v_s_243136;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243134}), v_t_243137});
            } else {
              heff_drop(v_field_243130);
              V v_t_243138 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243139 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243138}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_243140 = v_t_243139.f[0];
                V v_field_243141 = v_t_243139.f[1];
                V v_x_243142 = v_field_243140;
                V v_y_243143 = v_field_243141;
                V v_body_243144 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243147;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_243146 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_243147 = v_s_243146;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_243150;
                switch (heff_tag_of(v_body_243144)) {
                case TAG_At: {
                  V v_s_243149 = heff_dup(heff_field(v_body_243144, 1));
                  v_t_243150 = v_s_243149;
                  break;
                }
                default: heff_nomatch(v_body_243144);
                }
                V v_t_243151 = ({ V rv_1 = heff_get_n(v_t_243150, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243147, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243152 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243144)}), v_t_243151});
                V v_t_243155;
                switch (heff_tag_of(v_body_243144)) {
                case TAG_At: {
                  V v_s_243154 = heff_field(v_body_243144, 1);
                  heff_take_n(v_body_243144, 2ULL, 2);
                  v_t_243155 = v_s_243154;
                  break;
                }
                default: heff_nomatch(v_body_243144);
                }
                V v_t_243156 = ({ V rv_1 = heff_get_n(v_t_243155, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243157 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243143, v_t_243152}), v_t_243156});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243142; V a_2 = v_t_243157; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243142); r_; });
              }
            }
          }
        }
        case TAG_EWith: {
          heff_take_n(v_x3121_24760, 0ULL, 4);
          V v_xs_243162 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24758)));
          HeffT2 v_t_243164 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam72, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243162));
          {
            V v_field_243166 = v_t_243164.f[1];
            int64_t v_tag_243165 = ((int64_t)v_t_243164.f[0]);
            if ((v_tag_243165 == ((int64_t)0ULL))) {
              heff_drop_rec(v_t_240, 1);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_rest_243);
              heff_drop(v_end_244);
              heff_drop_rec(v_sp_246, 2);
              heff_drop_tag(v_x312_24759, 2);
              heff_drop_cell(v_ru_24x31_245_24StmtLet, 2);
              V v_x_243168 = v_field_243166;
              V v_t_243169 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str327), heff_strAppend(heff_dup(v_x_243168), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str328)));
              V v_t_243170 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str329), heff_strAppend(v_x_243168, v_t_243169));
              V v_t_243173;
              switch (heff_tag_of(v_p_24758)) {
              case TAG_At: {
                V v_s_243172 = heff_field(v_p_24758, 1);
                heff_take_n(v_p_24758, 2ULL, 2);
                v_t_243173 = v_s_243172;
                break;
              }
              default: heff_nomatch(v_p_24758);
              }
              return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243170}), v_t_243173});
            } else {
              heff_drop(v_field_243166);
              V v_t_243174 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
              HeffT2 v_t_243175 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243174}), NTAG(TAG_Nil), v_x312_24759));
              {
                V v_field_243176 = v_t_243175.f[0];
                V v_field_243177 = v_t_243175.f[1];
                V v_x_243178 = v_field_243176;
                V v_y_243179 = v_field_243177;
                V v_body_243180 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
                V v_t_243183;
                switch (heff_tag_of(v_p_24758)) {
                case TAG_At: {
                  V v_s_243182 = heff_dup(heff_field(v_p_24758, 1));
                  v_t_243183 = v_s_243182;
                  break;
                }
                default: heff_nomatch(v_p_24758);
                }
                V v_t_243186;
                switch (heff_tag_of(v_body_243180)) {
                case TAG_At: {
                  V v_s_243185 = heff_dup(heff_field(v_body_243180, 1));
                  v_t_243186 = v_s_243185;
                  break;
                }
                default: heff_nomatch(v_body_243180);
                }
                V v_t_243187 = ({ V rv_1 = heff_get_n(v_t_243186, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_243183, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243188 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24758, heff_dup(v_body_243180)}), v_t_243187});
                V v_t_243191;
                switch (heff_tag_of(v_body_243180)) {
                case TAG_At: {
                  V v_s_243190 = heff_field(v_body_243180, 1);
                  heff_take_n(v_body_243180, 2ULL, 2);
                  v_t_243191 = v_s_243190;
                  break;
                }
                default: heff_nomatch(v_body_243180);
                }
                V v_t_243192 = ({ V rv_1 = heff_get_n(v_t_243191, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_243193 = heff_tag_at_n(v_ru_24x31_245_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_243179, v_t_243188}), v_t_243192});
                return ({ V a_0 = v_cx_241; V a_1 = v_x_243178; V a_2 = v_t_243193; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243178); r_; });
              }
            }
          }
        }
        default: return heff_nomatch(v_x3121_24760);
        }
      }
      default: return heff_nomatch(v_x312_24759);
      }
    }
    case TAG_StmtExpr: {
      V v_e_243194 = heff_field(v_x31_245, 0);
      heff_take_n(v_x31_245, 1ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_243195 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_243194));
      if ((heff_dup(v_t_243195) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop(v_t_243195);
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2econtrolT(v_t_240, v_cx_241, v_e_243194, v_rest_243, v_end_244);
      } else {
        heff_drop(v_t_243195);
        V v_t_243196 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_243197 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243196}), NTAG(TAG_Nil), v_e_243194));
        {
          V v_field_243198 = v_t_243197.f[0];
          V v_field_243199 = v_t_243197.f[1];
          V v_x_243200 = v_field_243198;
          V v_y_243201 = v_field_243199;
          V v_xsp_243202 = heff_dup(heff_rfield(v_cx_241, 3));
          V v_rest_243203 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
          V v_t_243204 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
          V v_t_243205 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243204}), heff_dup(heff_rfield(v_cx_241, 3))});
          V v_t_243206 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str330), heff_dup(v_xsp_243202)}), heff_dup(v_rest_243203)});
          V v_t_243209;
          switch (heff_tag_of(v_rest_243203)) {
          case TAG_At: {
            V v_s_243208 = heff_field(v_rest_243203, 1);
            heff_take_n(v_rest_243203, 2ULL, 2);
            v_t_243209 = v_s_243208;
            break;
          }
          default: heff_nomatch(v_rest_243203);
          }
          V v_t_243210 = ({ V rv_1 = heff_get_n(v_t_243209, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_243202, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_243211 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243206, v_t_243210}), NTAG(TAG_Nil)});
          V v_t_243212 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_243205, heff_tag_n(TAG_Cons, 2, (V[]){v_y_243201, v_t_243211})));
          return ({ V a_0 = v_cx_241; V a_1 = v_x_243200; V a_2 = v_t_243212; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243200); r_; });
        }
      }
    }
    case TAG_StmtLetMut: {
      V v_x_243213 = heff_field(v_x31_245, 0);
      V v_xsp_243214 = heff_field(v_x31_245, 1);
      V v_e_243215 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      heff_drop_rec(v_sp_246, 2);
      V v_t_243216 = (g_list_2eany_24s930586707x1164893977(v_x_243213, heff_rfield(v_cx_241, 1)));
      if ((heff_dup(v_t_243216) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 1);
        heff_drop_rec(v_cx_241, 5);
        heff_drop(v_rest_243);
        heff_drop(v_end_244);
        heff_drop(v_e_243215);
        heff_drop(v_t_243216);
        V v_t_243217 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str331), heff_strAppend(heff_dup(v_x_243213), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str332)));
        V v_t_243218 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str333), heff_strAppend(v_x_243213, v_t_243217));
        return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243218}), v_xsp_243214});
      } else {
        heff_drop(v_t_243216);
        V v_t_243219 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_243220 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_243219}), NTAG(TAG_Nil), v_e_243215));
        {
          V v_field_243221 = v_t_243220.f[0];
          V v_field_243222 = v_t_243220.f[1];
          V v_x_243223 = v_field_243221;
          V v_y_243224 = v_field_243222;
          V v_sp_243227;
          switch (heff_tag_of(v_y_243224)) {
          case TAG_At: {
            V v_s_243226 = heff_dup(heff_field(v_y_243224, 1));
            v_sp_243227 = v_s_243226;
            break;
          }
          default: heff_nomatch(v_y_243224);
          }
          V v_t_243228 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str334)}), heff_dup(v_sp_243227)});
          V v_t_243229 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str335)}), v_sp_243227});
          V v_t_243230 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243229, NTAG(TAG_Nil)});
          V v_t_243231 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_243228, v_t_243230));
          V v_t_243234;
          switch (heff_tag_of(v_y_243224)) {
          case TAG_At: {
            V v_s_243233 = heff_dup(heff_field(v_y_243224, 1));
            v_t_243234 = v_s_243233;
            break;
          }
          default: heff_nomatch(v_y_243224);
          }
          V v_v_243235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_243224, v_t_243231}), v_t_243234});
          V v_t_243236 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243213), NTAG(TAG_Nil)});
          V v_t_243237 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_cx_241, 1)), v_t_243236));
          V v_t_243238 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), v_t_243237, heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), heff_dup(heff_rfield(v_cx_241, 4))});
          V v_body_243239 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_243238, v_rest_243, v_end_244}));
          V v_t_243240 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_243213}), heff_dup(v_xsp_243214)});
          V v_t_243243;
          switch (heff_tag_of(v_body_243239)) {
          case TAG_At: {
            V v_s_243242 = heff_dup(heff_field(v_body_243239, 1));
            v_t_243243 = v_s_243242;
            break;
          }
          default: heff_nomatch(v_body_243239);
          }
          V v_t_243244 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_243214, 0)); V rr_ = heff_rec_reuse_nf(v_t_243243, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_243245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_243240, heff_dup(v_body_243239)}), v_t_243244});
          V v_t_243248;
          switch (heff_tag_of(v_body_243239)) {
          case TAG_At: {
            V v_s_243247 = heff_field(v_body_243239, 1);
            heff_take_n(v_body_243239, 2ULL, 2);
            v_t_243248 = v_s_243247;
            break;
          }
          default: heff_nomatch(v_body_243239);
          }
          V v_t_243249 = ({ V rv_1 = heff_get_n(v_t_243248, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_243214, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_243250 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_243235, v_t_243245}), v_t_243249});
          return ({ V a_0 = v_cx_241; V a_1 = v_x_243223; V a_2 = v_t_243250; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_243223); r_; });
        }
      }
    }
    case TAG_StmtLetElse: {
      V v_p_243251 = heff_field(v_x31_245, 0);
      V v_e_243252 = heff_field(v_x31_245, 1);
      V v_els_243253 = heff_field(v_x31_245, 2);
      heff_take_n(v_x31_245, 7ULL, 3);
      V v_xs_243254 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_243251)));
      HeffT2 v_t_243256 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_lam73, 1, 1, (V[]){heff_dup(v_cx_241)}), v_xs_243254));
      {
        V v_field_243258 = v_t_243256.f[1];
        int64_t v_tag_243257 = ((int64_t)v_t_243256.f[0]);
        if ((v_tag_243257 == ((int64_t)0ULL))) {
          heff_drop_rec(v_t_240, 1);
          heff_drop_rec(v_cx_241, 5);
          heff_drop(v_rest_243);
          heff_drop(v_end_244);
          heff_drop_rec(v_sp_246, 2);
          heff_drop(v_e_243252);
          heff_drop(v_els_243253);
          V v_x_243260 = v_field_243258;
          V v_t_243261 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str336), heff_strAppend(heff_dup(v_x_243260), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_str337)));
          V v_t_243262 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_str338), heff_strAppend(v_x_243260, v_t_243261));
          V v_t_243265;
          switch (heff_tag_of(v_p_243251)) {
          case TAG_At: {
            V v_s_243264 = heff_field(v_p_243251, 1);
            heff_take_n(v_p_243251, 2ULL, 2);
            v_t_243265 = v_s_243264;
            break;
          }
          default: heff_nomatch(v_p_243251);
          }
          return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_243262}), v_t_243265});
        } else {
          heff_drop(v_field_243258);
          V v_t_243266 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_str339)}), heff_dup(v_sp_246)});
          V v_t_243267 = (g_heff_2esyntax_2epresyntax_2eelseLeaving(heff_dup(v_sp_246), v_els_243253));
          V v_t_243268 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243266, v_t_243267}), NTAG(TAG_Nil)});
          V v_t_243269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_p_243251, v_rest_243}), v_t_243268});
          return (g_heff_2esyntax_2epresyntax_2econdT(v_t_240, v_cx_241, v_sp_246, v_e_243252, v_t_243269, NTAG(TAG_Nil), v_end_244));
        }
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtT(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam0(V self, V *args) {
  V v_x_24764 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24764; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24764); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam1(V self, V *args) {
  V v_x_24797 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24797; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24797); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam2(V self, V *args) {
  V v_x_24830 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24830; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24830); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam3(V self, V *args) {
  V v_x_24863 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24863; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24863); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam4(V self, V *args) {
  V v_x_24896 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24896; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24896); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam5(V self, V *args) {
  V v_x_24929 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24929; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24929); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam6(V self, V *args) {
  V v_x_24962 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24962; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24962); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam7(V self, V *args) {
  V v_x_24995 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24995; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24995); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam8(V self, V *args) {
  V v_x_241028 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241028; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241028); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam9(V self, V *args) {
  V v_x_241062 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241062; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241062); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam10(V self, V *args) {
  V v_x_241095 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241095; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241095); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam11(V self, V *args) {
  V v_x_241129 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241129; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241129); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam12(V self, V *args) {
  V v_x_241163 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241163; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241163); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam13(V self, V *args) {
  V v_x_241197 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241197; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241197); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam14(V self, V *args) {
  V v_x_241231 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241231; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241231); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam15(V self, V *args) {
  V v_x_241267 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241267; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241267); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam16(V self, V *args) {
  V v_x_241300 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241300; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241300); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam17(V self, V *args) {
  V v_x_241333 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241333; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241333); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam18(V self, V *args) {
  V v_x_241366 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241366; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241366); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam19(V self, V *args) {
  V v_x_241400 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241400; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241400); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam20(V self, V *args) {
  V v_x_241434 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241434; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241434); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam21(V self, V *args) {
  V v_x_241468 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241468; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241468); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam22(V self, V *args) {
  V v_x_241501 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241501; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241501); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam23(V self, V *args) {
  V v_x_241535 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241535; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241535); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam24(V self, V *args) {
  V v_x_241568 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241568; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241568); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam25(V self, V *args) {
  V v_x_241603 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241603; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241603); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam26(V self, V *args) {
  V v_x_241637 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241637; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241637); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam27(V self, V *args) {
  V v_x_241672 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241672; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241672); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam28(V self, V *args) {
  V v_x_241706 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241706; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241706); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam29(V self, V *args) {
  V v_x_241738 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241738; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241738); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam30(V self, V *args) {
  V v_x_241770 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241770; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241770); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam31(V self, V *args) {
  V v_x_241803 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241803; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241803); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam32(V self, V *args) {
  V v_x_241839 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241839; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241839); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam33(V self, V *args) {
  V v_x_241872 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241872; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241872); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam34(V self, V *args) {
  V v_x_241905 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241905; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241905); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam35(V self, V *args) {
  V v_x_241938 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241938; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241938); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam36(V self, V *args) {
  V v_x_241971 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_241971; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_241971); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam37(V self, V *args) {
  V v_x_242004 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242004; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242004); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam38(V self, V *args) {
  V v_x_242037 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242037; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242037); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam39(V self, V *args) {
  V v_x_242070 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242070; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242070); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam40(V self, V *args) {
  V v_x_242103 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242103; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242103); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam41(V self, V *args) {
  V v_x_242137 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242137; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242137); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam42(V self, V *args) {
  V v_x_242170 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242170; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242170); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam43(V self, V *args) {
  V v_x_242204 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242204; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242204); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam44(V self, V *args) {
  V v_x_242238 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242238; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242238); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam45(V self, V *args) {
  V v_x_242272 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242272; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242272); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam46(V self, V *args) {
  V v_x_242306 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242306; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242306); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam47(V self, V *args) {
  V v_x_242342 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242342; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242342); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam48(V self, V *args) {
  V v_x_242375 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242375; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242375); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam49(V self, V *args) {
  V v_x_242408 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242408; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242408); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam50(V self, V *args) {
  V v_x_242441 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242441; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242441); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam51(V self, V *args) {
  V v_x_242475 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242475; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242475); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam52(V self, V *args) {
  V v_x_242509 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242509; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242509); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam53(V self, V *args) {
  V v_x_242543 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242543; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242543); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam54(V self, V *args) {
  V v_x_242576 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242576; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242576); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam55(V self, V *args) {
  V v_x_242610 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242610; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242610); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam56(V self, V *args) {
  V v_x_242643 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242643; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242643); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam57(V self, V *args) {
  V v_x_242678 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242678; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242678); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam58(V self, V *args) {
  V v_x_242712 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242712; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242712); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam59(V self, V *args) {
  V v_x_242747 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242747; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242747); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam60(V self, V *args) {
  V v_x_242763 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242763; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242763); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam61(V self, V *args) {
  V v_x_242795 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242795; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242795); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam62(V self, V *args) {
  V v_x_242827 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242827; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242827); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam63(V self, V *args) {
  V v_x_242860 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242860; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242860); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam64(V self, V *args) {
  V v_x_242893 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242893; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242893); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam65(V self, V *args) {
  V v_x_242926 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242926; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242926); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam66(V self, V *args) {
  V v_x_242959 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242959; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242959); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam67(V self, V *args) {
  V v_x_242992 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_242992; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_242992); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam68(V self, V *args) {
  V v_x_243028 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243028; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243028); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam69(V self, V *args) {
  V v_x_243061 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243061; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243061); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam70(V self, V *args) {
  V v_x_243094 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243094; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243094); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam71(V self, V *args) {
  V v_x_243127 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243127; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243127); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam72(V self, V *args) {
  V v_x_243163 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243163; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243163); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_lam73(V self, V *args) {
  V v_x_243255 = args[0];
  V v_cx_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_243255; V b_1 = heff_get_n(v_cx_241, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_243255); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2421;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_c_2411 = v_field_249;
          V v_t_2414;
          switch (heff_tag_of(v_c_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_c_2411);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        } else {
          if ((v_tag_248 == ((int64_t)1ULL))) {
            V v_i_2416 = v_field_249;
            V v_t_2419;
            switch (heff_tag_of(v_i_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_i_2416);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2416}), v_t_2419});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2420 = v_field_249;
            v_t_2421 = v_t_2420;
          }
        }
      }
      V v_t_2438;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2422 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2422));
        V v_t_2437;
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_c_2427 = v_field_2425;
            v_t_2437 = v_c_2427;
          } else {
            if ((v_tag_2424 == ((int64_t)1ULL))) {
              V v_i_2429 = v_field_2425;
              V v_t_2432;
              switch (heff_tag_of(v_i_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_i_2429);
              }
              v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2429}), v_t_2432});
            } else {
              V v_t_2433 = v_field_2425;
              V v_t_2436;
              switch (heff_tag_of(v_t_2433)) {
              case TAG_At: {
                V v_s_2435 = heff_dup(heff_field(v_t_2433, 1));
                v_t_2436 = v_s_2435;
                break;
              }
              default: heff_nomatch(v_t_2433);
              }
              v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2433}), v_t_2436});
            }
          }
        }
        v_t_2438 = heff_tag_at_n(v_ru_24d_246_24Just, TAG_Just, 1, (V[]){v_t_2437});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2421, v_t_2438}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2439 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2439));
      V v_t_2454;
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_c_2444 = v_field_2442;
          V v_t_2447;
          switch (heff_tag_of(v_c_2444)) {
          case TAG_At: {
            V v_s_2446 = heff_dup(heff_field(v_c_2444, 1));
            v_t_2447 = v_s_2446;
            break;
          }
          default: heff_nomatch(v_c_2444);
          }
          v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2444}), v_t_2447});
        } else {
          if ((v_tag_2441 == ((int64_t)1ULL))) {
            V v_i_2449 = v_field_2442;
            V v_t_2452;
            switch (heff_tag_of(v_i_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_i_2449);
            }
            v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2453 = v_field_2442;
            v_t_2454 = v_t_2453;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2454}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(a[0]);
}