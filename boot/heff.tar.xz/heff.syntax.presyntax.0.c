// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentInteger 22664
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_head 9693863
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835(V);
V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeInteger(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewholeInteger_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeInteger_clo;
V g_heff_2esyntax_2epresyntax_2ewholeSegment(V);
V g_heff_2esyntax_2epresyntax_2ewholeSegment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeSegment_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s2081626528x1476576812(V);
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s539093115x379698116(V);
V g_list_2emap_24s539093115x379698116_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_clo;
Clo g_heff_2esyntax_2epresyntax_2espineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2espineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2espineOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_e1_241, 0);
      V v_xs_2413 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2412, v_xs_2413});
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2espineOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_na(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IBytes: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IPrim: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_i1_241, 0);
      V v_xs_2411 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      heff_drop_tag(v_i_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IUpdate: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 5, "a tag");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 8, "a record");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 8, "a `case`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 29, "a `let` whose body is checked");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 19, "a term with `where`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 9, "`abandon`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 64, " does not infer its type: it must be put where its type is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str14, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str15, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str16, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str17, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str18, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str19, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str20, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str21, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str22, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str23, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str24, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str25, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_i_241;
  }
  case TAG_IsCheckable: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsCheckable = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_c_243 = heff_field(v_x11_242, 0);
      V v_sp_244 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInf: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0);
        break;
      }
      case TAG_CType: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1);
        break;
      }
      case TAG_CLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2);
        break;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3);
        break;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c_243, 0ULL, 4);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4);
        break;
      }
      case TAG_CTag: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5);
        break;
      }
      case TAG_CStruct: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6);
        break;
      }
      case TAG_CMatch: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7);
        break;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8);
        break;
      }
      case TAG_CLocal: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9);
        break;
      }
      case TAG_CAbandon: {
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10);
        break;
      }
      case TAG_CNominal: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11);
        break;
      }
      default: heff_nomatch(v_c_243);
      }
      V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)), heff_tag_at_n(v_ru_24x1_240_24IsCheckable, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
      return heff_tag_at_n(v_ru_24x11_242_24At, TAG_At, 2, (V[]){v_t_2429, v_sp_244});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IsType: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsType = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_At: {
      V v_x111_2431 = heff_dup(heff_field(v_x11_2430, 0));
      V v_sp_2432 = heff_dup(heff_field(v_x11_2430, 1));
      switch (heff_tag_of(v_x111_2431)) {
      case TAG_TPi: {
        V v_ru_24x111_2431_24TPi = heff_take_reuse_n(v_x111_2431, 0ULL, 2);
        heff_drop(v_sp_2432);
        V v_t_2435 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2438;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_at_n(v_ru_24x111_2431_24TPi, TAG_At, 2, (V[]){v_t_2435, v_t_2438});
      }
      case TAG_TSig: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2440 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str14), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_2432});
      }
      case TAG_TSum: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2442 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str15), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_2432});
      }
      case TAG_TType: {
        heff_drop(v_sp_2432);
        V v_t_2443 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str16), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2446;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2445 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2446});
      }
      case TAG_TInt: {
        heff_drop(v_sp_2432);
        V v_t_2447 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str17), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2450;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2449 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2450 = v_s_2449;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2447, v_t_2450});
      }
      case TAG_TFloat: {
        heff_drop(v_sp_2432);
        V v_t_2451 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str18), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2454;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2454});
      }
      case TAG_TString: {
        heff_drop(v_sp_2432);
        V v_t_2455 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str19), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2458;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_t_2458});
      }
      case TAG_TRune: {
        heff_drop(v_sp_2432);
        V v_t_2459 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str20), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2462;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2461 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2459, v_t_2462});
      }
      case TAG_TArray: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2464 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str21), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2467;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_t_2467});
      }
      case TAG_TFixed: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2469 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str22), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2472;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2472});
      }
      case TAG_TInf: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2474 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str23), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2477;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2476 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2477 = v_s_2476;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2477});
      }
      case TAG_TChk: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2479 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str24), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2482;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2481 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_t_2482});
      }
      case TAG_TNominal: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2484 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str25), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2487;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2486 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2487 = v_s_2486;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2484, v_t_2487});
      }
      default: return heff_nomatch(v_x111_2431);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etoInferable(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_str0, 22, "`Array` takes one type");
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_242});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_243});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_244});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_245});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_246});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_249});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    V v_tsp_245 = heff_dup(heff_field(v_h_241, 1));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_EVar: {
      V v_ru_24h1_244_24EVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_247));
      V v_t_249 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2410 = (g_list_2emap(v_t_249, v_args_242));
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EVar, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_244_24EImplicitVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2413));
      V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2416 = (g_list_2emap(v_t_2415, v_args_242));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2414, v_t_2416}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_2417});
    }
    case TAG_ETag: {
      V v_t_2418 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop_tag(v_h_241, 2);
      V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242));
      V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2418, v_tsp_245, v_t_2430}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2431});
    }
    case TAG_EInt: {
      V v_ru_24h1_244_24EInt = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2433));
      V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2436 = (g_list_2emap(v_t_2435, v_args_242));
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2434, v_t_2436}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInt, TAG_IsInferable, 1, (V[]){v_t_2437});
    }
    case TAG_EFloat: {
      V v_ru_24h1_244_24EFloat = heff_take_reuse_na(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2439));
      V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2442 = (g_list_2emap(v_t_2441, v_args_242));
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2440, v_t_2442}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2443});
    }
    case TAG_EString: {
      V v_ru_24h1_244_24EString = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2446 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2445));
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2448 = (g_list_2emap(v_t_2447, v_args_242));
      V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2446, v_t_2448}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EString, TAG_IsInferable, 1, (V[]){v_t_2449});
    }
    case TAG_EBinary: {
      V v_ru_24h1_244_24EBinary = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2451));
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2454 = (g_list_2emap(v_t_2453, v_args_242));
      V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2452, v_t_2454}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EBinary, TAG_IsInferable, 1, (V[]){v_t_2455});
    }
    case TAG_ERune: {
      V v_ru_24h1_244_24ERune = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2458 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2457));
      V v_t_2459 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2460 = (g_list_2emap(v_t_2459, v_args_242));
      V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2458, v_t_2460}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ERune, TAG_IsInferable, 1, (V[]){v_t_2461});
    }
    case TAG_EWord: {
      V v_h11_2462 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop(v_tsp_245);
      switch (heff_tag_of(v_h11_2462)) {
      case TAG_TypeWord: {
        V v_t_2463 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2464 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2463));
        V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2466 = (g_list_2emap(v_t_2465, v_args_242));
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2464, v_t_2466}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2467});
      }
      case TAG_IntWord: {
        V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2469 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2468));
        V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2471 = (g_list_2emap(v_t_2470, v_args_242));
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2469, v_t_2471}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2472});
      }
      case TAG_FloatWord: {
        V v_t_2473 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2474 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2473));
        V v_t_2475 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2476 = (g_list_2emap(v_t_2475, v_args_242));
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2474, v_t_2476}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2477});
      }
      case TAG_StringWord: {
        V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2479 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2478));
        V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2481 = (g_list_2emap(v_t_2480, v_args_242));
        V v_t_2482 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2479, v_t_2481}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2482});
      }
      case TAG_RuneWord: {
        V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2484 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2483));
        V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2486 = (g_list_2emap(v_t_2485, v_args_242));
        V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2486}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2487});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2488 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0), NTAG(TAG_Nothing)});
          V v_t_2489 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2488, heff_dup(v_sp_243)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2489, v_sp_243})});
        }
        case TAG_Cons: {
          V v_a_2490 = heff_field(v_args_242, 0);
          V v_args2_2491 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2491)) {
          case TAG_Nil: {
            V v_x1_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2490}));
            V v_t_24102;
            switch (heff_tag_of(v_x1_2492)) {
            case TAG_IsInferable: {
              V v_i_2493 = heff_field(v_x1_2492, 0);
              heff_take_n(v_x1_2492, 1ULL, 1);
              V v_t_2496;
              switch (heff_tag_of(v_i_2493)) {
              case TAG_At: {
                V v_s_2495 = heff_dup(heff_field(v_i_2493, 1));
                v_t_2496 = v_s_2495;
                break;
              }
              default: heff_nomatch(v_i_2493);
              }
              v_t_24102 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2493}), v_t_2496});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2497 = heff_field(v_x1_2492, 0);
              heff_take_n(v_x1_2492, 1ULL, 1);
              V v_t_24100;
              switch (heff_tag_of(v_c_2497)) {
              case TAG_At: {
                V v_s_2499 = heff_dup(heff_field(v_c_2497, 1));
                v_t_24100 = v_s_2499;
                break;
              }
              default: heff_nomatch(v_c_2497);
              }
              v_t_24102 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2497}), v_t_24100});
              break;
            }
            case TAG_IsType: {
              V v_t_24101 = heff_field(v_x1_2492, 0);
              heff_take_n(v_x1_2492, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_24102 = v_t_24101;
              break;
            }
            default: heff_nomatch(v_x1_2492);
            }
            V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_24102}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_24103});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2491, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2490);
            V v_t_24106 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1), NTAG(TAG_Nothing)});
            V v_t_24107 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24106, heff_dup(v_sp_243)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){v_t_24107, v_sp_243})});
          }
          default: return heff_nomatch(v_args2_2491);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      case TAG_AbandonWord: {
        V v_t_24108 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_24109 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24108));
        V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_24111 = (g_list_2emap(v_t_24110, v_args_242));
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24109, v_t_24111}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_24112});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2462, 0ULL, 1);
        V v_t_24114 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_24115 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24114));
        V v_t_24116 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_24117 = (g_list_2emap(v_t_24116, v_args_242));
        V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24115, v_t_24117}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_24118});
      }
      default: return heff_nomatch(v_h11_2462);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_244_24EApp = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24121 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24122 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24121));
      V v_t_24123 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24124 = (g_list_2emap(v_t_24123, v_args_242));
      V v_t_24125 = heff_tag_at_n(v_ru_24h1_244_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24122, v_t_24124}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24125});
    }
    case TAG_EProject: {
      V v_ru_24h1_244_24EProject = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24127 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24128 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24127));
      V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24130 = (g_list_2emap(v_t_24129, v_args_242));
      V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24128, v_t_24130}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EProject, TAG_IsInferable, 1, (V[]){v_t_24131});
    }
    case TAG_ENamed: {
      V v_ru_24h1_244_24ENamed = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24134 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24135 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24134));
      V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24137 = (g_list_2emap(v_t_24136, v_args_242));
      V v_t_24138 = heff_tag_at_n(v_ru_24h1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24135, v_t_24137}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24138});
    }
    case TAG_EPi: {
      V v_ru_24h1_244_24EPi = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24141 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24141));
      V v_t_24143 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24144 = (g_list_2emap(v_t_24143, v_args_242));
      V v_t_24145 = heff_tag_at_n(v_ru_24h1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24142, v_t_24144}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24145});
    }
    case TAG_ELam: {
      V v_ru_24h1_244_24ELam = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24148 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24149 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24148));
      V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24151 = (g_list_2emap(v_t_24150, v_args_242));
      V v_t_24152 = heff_tag_at_n(v_ru_24h1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24149, v_t_24151}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24152});
    }
    case TAG_EAnn: {
      V v_ru_24h1_244_24EAnn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24156 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24155));
      V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24158 = (g_list_2emap(v_t_24157, v_args_242));
      V v_t_24159 = heff_tag_at_n(v_ru_24h1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24156, v_t_24158}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24159});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_244, 0ULL, 4);
      heff_drop(v_tsp_245);
      V v_t_24164 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24165 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24164));
      V v_t_24166 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24167 = (g_list_2emap(v_t_24166, v_args_242));
      V v_t_24168 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24165, v_t_24167}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24168});
    }
    case TAG_ESig: {
      V v_ru_24h1_244_24ESig = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24171 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24170));
      V v_t_24172 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24173 = (g_list_2emap(v_t_24172, v_args_242));
      V v_t_24174 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24171, v_t_24173}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESig, TAG_IsInferable, 1, (V[]){v_t_24174});
    }
    case TAG_ESum: {
      V v_ru_24h1_244_24ESum = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24176 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24177 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24176));
      V v_t_24178 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24179 = (g_list_2emap(v_t_24178, v_args_242));
      V v_t_24180 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24177, v_t_24179}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESum, TAG_IsInferable, 1, (V[]){v_t_24180});
    }
    case TAG_EStruct: {
      V v_ru_24h1_244_24EStruct = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24183 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24182));
      V v_t_24184 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24185 = (g_list_2emap(v_t_24184, v_args_242));
      V v_t_24186 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24183, v_t_24185}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EStruct, TAG_IsInferable, 1, (V[]){v_t_24186});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_244_24EUpdate = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24189 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24190 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24189));
      V v_t_24191 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24192 = (g_list_2emap(v_t_24191, v_args_242));
      V v_t_24193 = heff_tag_at_n(v_ru_24h1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24190, v_t_24192}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24193});
    }
    case TAG_EMatch: {
      V v_ru_24h1_244_24EMatch = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24196 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24197 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24196));
      V v_t_24198 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24199 = (g_list_2emap(v_t_24198, v_args_242));
      V v_t_24200 = heff_tag_at_n(v_ru_24h1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24197, v_t_24199}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24200});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_244_24ELetIn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24203 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24204 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24203));
      V v_t_24205 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24206 = (g_list_2emap(v_t_24205, v_args_242));
      V v_t_24207 = heff_tag_at_n(v_ru_24h1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24204, v_t_24206}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24207});
    }
    case TAG_EDo: {
      V v_ru_24h1_244_24EDo = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24209 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24210 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24209));
      V v_t_24211 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24212 = (g_list_2emap(v_t_24211, v_args_242));
      V v_t_24213 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24210, v_t_24212}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EDo, TAG_IsInferable, 1, (V[]){v_t_24213});
    }
    case TAG_ELocal: {
      V v_ru_24h1_244_24ELocal = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24216 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24217 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24216));
      V v_t_24218 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24219 = (g_list_2emap(v_t_24218, v_args_242));
      V v_t_24220 = heff_tag_at_n(v_ru_24h1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24217, v_t_24219}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24220});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_244_24EInvalid = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24222 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24223 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24222));
      V v_t_24224 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24225 = (g_list_2emap(v_t_24224, v_args_242));
      V v_t_24226 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24223, v_t_24225}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24226});
    }
    default: return heff_nomatch(v_h1_244);
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_2419 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_IsInferable: {
    V v_i_2421 = heff_field(v_x1_2420, 0);
    V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_i_2421)) {
    case TAG_At: {
      V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
      v_t_2424 = v_s_2423;
      break;
    }
    default: heff_nomatch(v_i_2421);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
  }
  case TAG_IsCheckable: {
    V v_c_2425 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    return v_c_2425;
  }
  case TAG_IsType: {
    V v_t_2426 = heff_field(v_x1_2420, 0);
    V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
      v_t_2429 = v_s_2428;
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ewholeSegment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeSegment_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewholeSegment(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EImplicitVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        V v_v_2411 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return (g_heff_2esyntax_2epresyntax_2ewholeInteger(heff_dup(v_size_243), v_little_244, heff_dup(v_v_2411)));
        }
        case TAG_SegmentBinary: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_EFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EString: {
        V v_s_2413 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_Nothing);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_s_2413)});
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SizeName: {
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_size_243);
          }
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_EBinary: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ERune: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EWord: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EProject: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ENamed: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPi: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAnn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ESpec: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ESig: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ESum: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EStruct: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EUpdate: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELetIn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EDo: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELocal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EInvalid: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x111_246);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeSegment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ewholeSegment(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str2, 18, "prelude.bytesSized");
Clo g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_2414;
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          V v_t_248 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_242)});
          v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_242)});
          break;
        }
        case TAG_SizeNumber: {
          V v_n_249 = heff_field(v_size_245, 0);
          V v_ru_24size_245_24SizeNumber = heff_take_reuse_n(v_size_245, 1ULL, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_249}), heff_dup(v_sp_242)});
          v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2410}), heff_dup(v_sp_242)});
          break;
        }
        case TAG_SizeName: {
          V v_x_2411 = heff_field(v_size_245, 0);
          V v_xsp_2412 = heff_field(v_size_245, 1);
          V v_ru_24size_245_24SizeName = heff_take_reuse_n(v_size_245, 3ULL, 2);
          V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2411}), heff_dup(v_xsp_2412)});
          v_t_2414 = heff_tag_at_n(v_ru_24size_245_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), v_xsp_2412});
          break;
        }
        default: heff_nomatch(v_size_245);
        }
        V v_t_2415;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_2415 = MK_INT(1LL);
        } else {
          heff_drop(v_little_246);
          v_t_2415 = MK_INT(0LL);
        }
        V v_t_2416;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2416 = MK_INT(2LL);
        } else {
          heff_drop(v_signed_247);
          v_t_2416 = MK_INT(0LL);
        }
        V v_t_2417 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intAdd(v_t_2415, v_t_2416)});
        V v_i_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_242)});
        V v_t_2421;
        switch (heff_tag_of(v_i_2418)) {
        case TAG_At: {
          V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_i_2418);
        }
        V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
        V v_x1_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_243));
        V v_t_2433;
        switch (heff_tag_of(v_x1_2423)) {
        case TAG_IsInferable: {
          V v_i_2424 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsInferable = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2427;
          switch (heff_tag_of(v_i_2424)) {
          case TAG_At: {
            V v_s_2426 = heff_dup(heff_field(v_i_2424, 1));
            v_t_2427 = v_s_2426;
            break;
          }
          default: heff_nomatch(v_i_2424);
          }
          v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsInferable, TAG_CInf, 1, (V[]){v_i_2424}), v_t_2427});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2428 = heff_field(v_x1_2423, 0);
          heff_take_n(v_x1_2423, 1ULL, 1);
          v_t_2433 = v_c_2428;
          break;
        }
        case TAG_IsType: {
          V v_t_2429 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsType = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2432;
          switch (heff_tag_of(v_t_2429)) {
          case TAG_At: {
            V v_s_2431 = heff_dup(heff_field(v_t_2429, 1));
            v_t_2432 = v_s_2431;
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
          v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsType, TAG_CType, 1, (V[]){v_t_2429}), v_t_2432});
          break;
        }
        default: heff_nomatch(v_x1_2423);
        }
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
        V v_args_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str0)}), heff_dup(v_sp_242)});
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2435));
        V v_i_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_t_2437}), v_sp_242});
        V v_t_2441;
        switch (heff_tag_of(v_i_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_i_2438);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2438}), v_t_2441});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          V v_x1_2442 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_243));
          switch (heff_tag_of(v_x1_2442)) {
          case TAG_IsInferable: {
            V v_i_2443 = heff_field(v_x1_2442, 0);
            heff_take_n(v_x1_2442, 1ULL, 1);
            V v_t_2446;
            switch (heff_tag_of(v_i_2443)) {
            case TAG_At: {
              V v_s_2445 = heff_dup(heff_field(v_i_2443, 1));
              v_t_2446 = v_s_2445;
              break;
            }
            default: heff_nomatch(v_i_2443);
            }
            return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2443}), v_t_2446});
          }
          case TAG_IsCheckable: {
            V v_c_2447 = heff_field(v_x1_2442, 0);
            heff_take_n(v_x1_2442, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            return v_c_2447;
          }
          case TAG_IsType: {
            V v_t_2448 = heff_field(v_x1_2442, 0);
            heff_take_n(v_x1_2442, 1ULL, 1);
            V v_t_2451;
            switch (heff_tag_of(v_t_2448)) {
            case TAG_At: {
              V v_s_2450 = heff_dup(heff_field(v_t_2448, 1));
              v_t_2451 = v_s_2450;
              break;
            }
            default: heff_nomatch(v_t_2448);
            }
            return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2448}), v_t_2451});
          }
          default: return heff_nomatch(v_x1_2442);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2459;
          switch (heff_tag_of(v_size_245)) {
          case TAG_SizeDefault: {
            V v_t_2453 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_242)});
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2453}), heff_dup(v_sp_242)});
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2454 = heff_field(v_size_245, 0);
            V v_ru_24size_245_24SizeNumber = heff_take_reuse_n(v_size_245, 1ULL, 1);
            V v_t_2455 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2454}), heff_dup(v_sp_242)});
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2455}), heff_dup(v_sp_242)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2456 = heff_field(v_size_245, 0);
            V v_xsp_2457 = heff_field(v_size_245, 1);
            V v_ru_24size_245_24SizeName = heff_take_reuse_n(v_size_245, 3ULL, 2);
            V v_t_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2456}), heff_dup(v_xsp_2457)});
            v_t_2459 = heff_tag_at_n(v_ru_24size_245_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2458}), v_xsp_2457});
            break;
          }
          default: heff_nomatch(v_size_245);
          }
          V v_x1_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_243));
          V v_t_2470;
          switch (heff_tag_of(v_x1_2460)) {
          case TAG_IsInferable: {
            V v_i_2461 = heff_field(v_x1_2460, 0);
            V v_ru_24x1_2460_24IsInferable = heff_take_reuse_n(v_x1_2460, 1ULL, 1);
            V v_t_2464;
            switch (heff_tag_of(v_i_2461)) {
            case TAG_At: {
              V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
              v_t_2464 = v_s_2463;
              break;
            }
            default: heff_nomatch(v_i_2461);
            }
            v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2460_24IsInferable, TAG_CInf, 1, (V[]){v_i_2461}), v_t_2464});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2465 = heff_field(v_x1_2460, 0);
            heff_take_n(v_x1_2460, 1ULL, 1);
            v_t_2470 = v_c_2465;
            break;
          }
          case TAG_IsType: {
            V v_t_2466 = heff_field(v_x1_2460, 0);
            V v_ru_24x1_2460_24IsType = heff_take_reuse_n(v_x1_2460, 1ULL, 1);
            V v_t_2469;
            switch (heff_tag_of(v_t_2466)) {
            case TAG_At: {
              V v_s_2468 = heff_dup(heff_field(v_t_2466, 1));
              v_t_2469 = v_s_2468;
              break;
            }
            default: heff_nomatch(v_t_2466);
            }
            v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2460_24IsType, TAG_CType, 1, (V[]){v_t_2466}), v_t_2469});
            break;
          }
          default: heff_nomatch(v_x1_2460);
          }
          V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
          V v_args_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2471});
          V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str1)}), heff_dup(v_sp_242)});
          V v_t_2474 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2472));
          V v_i_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2473, v_t_2474}), v_sp_242});
          V v_t_2478;
          switch (heff_tag_of(v_i_2475)) {
          case TAG_At: {
            V v_s_2477 = heff_dup(heff_field(v_i_2475, 1));
            v_t_2478 = v_s_2477;
            break;
          }
          default: heff_nomatch(v_i_2475);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2475}), v_t_2478});
        }
        case TAG_SizeName: {
          V v_t_2487;
          switch (heff_tag_of(v_size_245)) {
          case TAG_SizeDefault: {
            V v_t_2481 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_242)});
            v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2481}), heff_dup(v_sp_242)});
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2482 = heff_field(v_size_245, 0);
            V v_ru_24size_245_24SizeNumber = heff_take_reuse_n(v_size_245, 1ULL, 1);
            V v_t_2483 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2482}), heff_dup(v_sp_242)});
            v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2483}), heff_dup(v_sp_242)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2484 = heff_field(v_size_245, 0);
            V v_xsp_2485 = heff_field(v_size_245, 1);
            V v_ru_24size_245_24SizeName = heff_take_reuse_n(v_size_245, 3ULL, 2);
            V v_t_2486 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2484}), heff_dup(v_xsp_2485)});
            v_t_2487 = heff_tag_at_n(v_ru_24size_245_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2486}), v_xsp_2485});
            break;
          }
          default: heff_nomatch(v_size_245);
          }
          V v_x1_2488 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_243));
          V v_t_2498;
          switch (heff_tag_of(v_x1_2488)) {
          case TAG_IsInferable: {
            V v_i_2489 = heff_field(v_x1_2488, 0);
            V v_ru_24x1_2488_24IsInferable = heff_take_reuse_n(v_x1_2488, 1ULL, 1);
            V v_t_2492;
            switch (heff_tag_of(v_i_2489)) {
            case TAG_At: {
              V v_s_2491 = heff_dup(heff_field(v_i_2489, 1));
              v_t_2492 = v_s_2491;
              break;
            }
            default: heff_nomatch(v_i_2489);
            }
            v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2488_24IsInferable, TAG_CInf, 1, (V[]){v_i_2489}), v_t_2492});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2493 = heff_field(v_x1_2488, 0);
            heff_take_n(v_x1_2488, 1ULL, 1);
            v_t_2498 = v_c_2493;
            break;
          }
          case TAG_IsType: {
            V v_t_2494 = heff_field(v_x1_2488, 0);
            V v_ru_24x1_2488_24IsType = heff_take_reuse_n(v_x1_2488, 1ULL, 1);
            V v_t_2497;
            switch (heff_tag_of(v_t_2494)) {
            case TAG_At: {
              V v_s_2496 = heff_dup(heff_field(v_t_2494, 1));
              v_t_2497 = v_s_2496;
              break;
            }
            default: heff_nomatch(v_t_2494);
            }
            v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2488_24IsType, TAG_CType, 1, (V[]){v_t_2494}), v_t_2497});
            break;
          }
          default: heff_nomatch(v_x1_2488);
          }
          V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, NTAG(TAG_Nil)});
          V v_args_24100 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, v_t_2499});
          V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_str2)}), heff_dup(v_sp_242)});
          V v_t_24102 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24100));
          V v_i_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24102}), v_sp_242});
          V v_t_24106;
          switch (heff_tag_of(v_i_24103)) {
          case TAG_At: {
            V v_s_24105 = heff_dup(heff_field(v_i_24103, 1));
            v_t_24106 = v_s_24105;
            break;
          }
          default: heff_nomatch(v_i_24103);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24103}), v_t_24106});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      V v_ru_24e1_241_24EVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2414;
      switch (heff_tag_of(v_x1_244)) {
      case TAG_IsInferable: {
        V v_i_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_248;
        switch (heff_tag_of(v_i_245)) {
        case TAG_At: {
          V v_s_247 = heff_dup(heff_field(v_i_245, 1));
          v_t_248 = v_s_247;
          break;
        }
        default: heff_nomatch(v_i_245);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EVar, TAG_CInf, 1, (V[]){v_i_245}), v_t_248});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_249 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EVar, 1);
        v_t_2414 = v_c_249;
        break;
      }
      case TAG_IsType: {
        V v_t_2410 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_t_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EVar, TAG_CType, 1, (V[]){v_t_2410}), v_t_2413});
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
      V v_t_2417;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2414}), v_t_2417});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_241_24EImplicitVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EImplicitVar, 1);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V v_t_2432;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2429}), v_t_2432});
    }
    case TAG_ETag: {
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2444;
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_IsInferable: {
        V v_i_2435 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2438;
        switch (heff_tag_of(v_i_2435)) {
        case TAG_At: {
          V v_s_2437 = heff_dup(heff_field(v_i_2435, 1));
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_i_2435);
        }
        v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_CInf, 1, (V[]){v_i_2435}), v_t_2438});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2439 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ETag, 1);
        v_t_2444 = v_c_2439;
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_t_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_CType, 1, (V[]){v_t_2440}), v_t_2443});
        break;
      }
      default: heff_nomatch(v_x1_2434);
      }
      V v_t_2447;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2444}), v_t_2447});
    }
    case TAG_EInt: {
      V v_ru_24e1_241_24EInt = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2449 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2459;
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_IsInferable: {
        V v_i_2450 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2453;
        switch (heff_tag_of(v_i_2450)) {
        case TAG_At: {
          V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
          v_t_2453 = v_s_2452;
          break;
        }
        default: heff_nomatch(v_i_2450);
        }
        v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInt, TAG_CInf, 1, (V[]){v_i_2450}), v_t_2453});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2454 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInt, 1);
        v_t_2459 = v_c_2454;
        break;
      }
      case TAG_IsType: {
        V v_t_2455 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_t_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_t_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_t_2455);
        }
        v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInt, TAG_CType, 1, (V[]){v_t_2455}), v_t_2458});
        break;
      }
      default: heff_nomatch(v_x1_2449);
      }
      V v_t_2462;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2459}), v_t_2462});
    }
    case TAG_EFloat: {
      V v_ru_24e1_241_24EFloat = heff_take_reuse_na(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2464 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2474;
      switch (heff_tag_of(v_x1_2464)) {
      case TAG_IsInferable: {
        V v_i_2465 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2468;
        switch (heff_tag_of(v_i_2465)) {
        case TAG_At: {
          V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
          v_t_2468 = v_s_2467;
          break;
        }
        default: heff_nomatch(v_i_2465);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EFloat, TAG_CInf, 1, (V[]){v_i_2465}), v_t_2468});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2469 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EFloat, 1);
        v_t_2474 = v_c_2469;
        break;
      }
      case TAG_IsType: {
        V v_t_2470 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2473;
        switch (heff_tag_of(v_t_2470)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_t_2470, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_t_2470);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EFloat, TAG_CType, 1, (V[]){v_t_2470}), v_t_2473});
        break;
      }
      default: heff_nomatch(v_x1_2464);
      }
      V v_t_2477;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2477 = v_s_2476;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2474}), v_t_2477});
    }
    case TAG_EString: {
      V v_ru_24e1_241_24EString = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2489;
      switch (heff_tag_of(v_x1_2479)) {
      case TAG_IsInferable: {
        V v_i_2480 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2483;
        switch (heff_tag_of(v_i_2480)) {
        case TAG_At: {
          V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
          v_t_2483 = v_s_2482;
          break;
        }
        default: heff_nomatch(v_i_2480);
        }
        v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EString, TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2484 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EString, 1);
        v_t_2489 = v_c_2484;
        break;
      }
      case TAG_IsType: {
        V v_t_2485 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2488;
        switch (heff_tag_of(v_t_2485)) {
        case TAG_At: {
          V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
          v_t_2488 = v_s_2487;
          break;
        }
        default: heff_nomatch(v_t_2485);
        }
        v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EString, TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
        break;
      }
      default: heff_nomatch(v_x1_2479);
      }
      V v_t_2492;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2489}), v_t_2492});
    }
    case TAG_EBinary: {
      V v_ru_24e1_241_24EBinary = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24104;
      switch (heff_tag_of(v_x1_2494)) {
      case TAG_IsInferable: {
        V v_i_2495 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_i_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_i_2495);
        }
        v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EBinary, TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2499 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EBinary, 1);
        v_t_24104 = v_c_2499;
        break;
      }
      case TAG_IsType: {
        V v_t_24100 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_t_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EBinary, TAG_CType, 1, (V[]){v_t_24100}), v_t_24103});
        break;
      }
      default: heff_nomatch(v_x1_2494);
      }
      V v_t_24107;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24106 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24107 = v_s_24106;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24104}), v_t_24107});
    }
    case TAG_ERune: {
      V v_ru_24e1_241_24ERune = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24109 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24119;
      switch (heff_tag_of(v_x1_24109)) {
      case TAG_IsInferable: {
        V v_i_24110 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        V v_t_24113;
        switch (heff_tag_of(v_i_24110)) {
        case TAG_At: {
          V v_s_24112 = heff_dup(heff_field(v_i_24110, 1));
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_i_24110);
        }
        v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ERune, TAG_CInf, 1, (V[]){v_i_24110}), v_t_24113});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24114 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ERune, 1);
        v_t_24119 = v_c_24114;
        break;
      }
      case TAG_IsType: {
        V v_t_24115 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        V v_t_24118;
        switch (heff_tag_of(v_t_24115)) {
        case TAG_At: {
          V v_s_24117 = heff_dup(heff_field(v_t_24115, 1));
          v_t_24118 = v_s_24117;
          break;
        }
        default: heff_nomatch(v_t_24115);
        }
        v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ERune, TAG_CType, 1, (V[]){v_t_24115}), v_t_24118});
        break;
      }
      default: heff_nomatch(v_x1_24109);
      }
      V v_t_24122;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24121 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24122 = v_s_24121;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24119}), v_t_24122});
    }
    case TAG_EWord: {
      V v_ru_24e1_241_24EWord = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24124 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24134;
      switch (heff_tag_of(v_x1_24124)) {
      case TAG_IsInferable: {
        V v_i_24125 = heff_field(v_x1_24124, 0);
        heff_take_n(v_x1_24124, 1ULL, 1);
        V v_t_24128;
        switch (heff_tag_of(v_i_24125)) {
        case TAG_At: {
          V v_s_24127 = heff_dup(heff_field(v_i_24125, 1));
          v_t_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_i_24125);
        }
        v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EWord, TAG_CInf, 1, (V[]){v_i_24125}), v_t_24128});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24129 = heff_field(v_x1_24124, 0);
        heff_take_n(v_x1_24124, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EWord, 1);
        v_t_24134 = v_c_24129;
        break;
      }
      case TAG_IsType: {
        V v_t_24130 = heff_field(v_x1_24124, 0);
        heff_take_n(v_x1_24124, 1ULL, 1);
        V v_t_24133;
        switch (heff_tag_of(v_t_24130)) {
        case TAG_At: {
          V v_s_24132 = heff_dup(heff_field(v_t_24130, 1));
          v_t_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_t_24130);
        }
        v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EWord, TAG_CType, 1, (V[]){v_t_24130}), v_t_24133});
        break;
      }
      default: heff_nomatch(v_x1_24124);
      }
      V v_t_24137;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24136 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24137 = v_s_24136;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24134}), v_t_24137});
    }
    case TAG_EApp: {
      V v_ru_24e1_241_24EApp = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24140 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24150;
      switch (heff_tag_of(v_x1_24140)) {
      case TAG_IsInferable: {
        V v_i_24141 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        V v_t_24144;
        switch (heff_tag_of(v_i_24141)) {
        case TAG_At: {
          V v_s_24143 = heff_dup(heff_field(v_i_24141, 1));
          v_t_24144 = v_s_24143;
          break;
        }
        default: heff_nomatch(v_i_24141);
        }
        v_t_24150 = heff_tag_at_n(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24141}), v_t_24144});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24145 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EApp, 2);
        v_t_24150 = v_c_24145;
        break;
      }
      case TAG_IsType: {
        V v_t_24146 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        V v_t_24149;
        switch (heff_tag_of(v_t_24146)) {
        case TAG_At: {
          V v_s_24148 = heff_dup(heff_field(v_t_24146, 1));
          v_t_24149 = v_s_24148;
          break;
        }
        default: heff_nomatch(v_t_24146);
        }
        v_t_24150 = heff_tag_at_n(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24146}), v_t_24149});
        break;
      }
      default: heff_nomatch(v_x1_24140);
      }
      V v_t_24153;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24152 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24153 = v_s_24152;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24150}), v_t_24153});
    }
    case TAG_EProject: {
      V v_x_24154 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24EProject = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_24154}), v_sp_242});
    }
    case TAG_ENamed: {
      V v_x_24155 = heff_field(v_e1_241, 0);
      V v_e12_24156 = heff_field(v_e1_241, 1);
      V v_ru_24e1_241_24ENamed = heff_take_reuse_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      V v_x1_24157 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e12_24156));
      V v_t_24167;
      switch (heff_tag_of(v_x1_24157)) {
      case TAG_IsInferable: {
        V v_i_24158 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        V v_t_24161;
        switch (heff_tag_of(v_i_24158)) {
        case TAG_At: {
          V v_s_24160 = heff_dup(heff_field(v_i_24158, 1));
          v_t_24161 = v_s_24160;
          break;
        }
        default: heff_nomatch(v_i_24158);
        }
        v_t_24167 = heff_tag_at_n(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24158}), v_t_24161});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24162 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ENamed, 2);
        v_t_24167 = v_c_24162;
        break;
      }
      case TAG_IsType: {
        V v_t_24163 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        V v_t_24166;
        switch (heff_tag_of(v_t_24163)) {
        case TAG_At: {
          V v_s_24165 = heff_dup(heff_field(v_t_24163, 1));
          v_t_24166 = v_s_24165;
          break;
        }
        default: heff_nomatch(v_t_24163);
        }
        v_t_24167 = heff_tag_at_n(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24163}), v_t_24166});
        break;
      }
      default: heff_nomatch(v_x1_24157);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24155, v_t_24167}), v_sp_242});
    }
    case TAG_EPi: {
      V v_ru_24e1_241_24EPi = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24170 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24180;
      switch (heff_tag_of(v_x1_24170)) {
      case TAG_IsInferable: {
        V v_i_24171 = heff_field(v_x1_24170, 0);
        heff_take_n(v_x1_24170, 1ULL, 1);
        V v_t_24174;
        switch (heff_tag_of(v_i_24171)) {
        case TAG_At: {
          V v_s_24173 = heff_dup(heff_field(v_i_24171, 1));
          v_t_24174 = v_s_24173;
          break;
        }
        default: heff_nomatch(v_i_24171);
        }
        v_t_24180 = heff_tag_at_n(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24171}), v_t_24174});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24175 = heff_field(v_x1_24170, 0);
        heff_take_n(v_x1_24170, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EPi, 2);
        v_t_24180 = v_c_24175;
        break;
      }
      case TAG_IsType: {
        V v_t_24176 = heff_field(v_x1_24170, 0);
        heff_take_n(v_x1_24170, 1ULL, 1);
        V v_t_24179;
        switch (heff_tag_of(v_t_24176)) {
        case TAG_At: {
          V v_s_24178 = heff_dup(heff_field(v_t_24176, 1));
          v_t_24179 = v_s_24178;
          break;
        }
        default: heff_nomatch(v_t_24176);
        }
        v_t_24180 = heff_tag_at_n(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24176}), v_t_24179});
        break;
      }
      default: heff_nomatch(v_x1_24170);
      }
      V v_t_24183;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24182 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24183 = v_s_24182;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24180}), v_t_24183});
    }
    case TAG_ELam: {
      V v_ru_24e1_241_24ELam = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24186 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24196;
      switch (heff_tag_of(v_x1_24186)) {
      case TAG_IsInferable: {
        V v_i_24187 = heff_field(v_x1_24186, 0);
        heff_take_n(v_x1_24186, 1ULL, 1);
        V v_t_24190;
        switch (heff_tag_of(v_i_24187)) {
        case TAG_At: {
          V v_s_24189 = heff_dup(heff_field(v_i_24187, 1));
          v_t_24190 = v_s_24189;
          break;
        }
        default: heff_nomatch(v_i_24187);
        }
        v_t_24196 = heff_tag_at_n(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24187}), v_t_24190});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24191 = heff_field(v_x1_24186, 0);
        heff_take_n(v_x1_24186, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELam, 2);
        v_t_24196 = v_c_24191;
        break;
      }
      case TAG_IsType: {
        V v_t_24192 = heff_field(v_x1_24186, 0);
        heff_take_n(v_x1_24186, 1ULL, 1);
        V v_t_24195;
        switch (heff_tag_of(v_t_24192)) {
        case TAG_At: {
          V v_s_24194 = heff_dup(heff_field(v_t_24192, 1));
          v_t_24195 = v_s_24194;
          break;
        }
        default: heff_nomatch(v_t_24192);
        }
        v_t_24196 = heff_tag_at_n(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24192}), v_t_24195});
        break;
      }
      default: heff_nomatch(v_x1_24186);
      }
      V v_t_24199;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24198 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24199 = v_s_24198;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24196}), v_t_24199});
    }
    case TAG_EAnn: {
      V v_ru_24e1_241_24EAnn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24202 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24212;
      switch (heff_tag_of(v_x1_24202)) {
      case TAG_IsInferable: {
        V v_i_24203 = heff_field(v_x1_24202, 0);
        heff_take_n(v_x1_24202, 1ULL, 1);
        V v_t_24206;
        switch (heff_tag_of(v_i_24203)) {
        case TAG_At: {
          V v_s_24205 = heff_dup(heff_field(v_i_24203, 1));
          v_t_24206 = v_s_24205;
          break;
        }
        default: heff_nomatch(v_i_24203);
        }
        v_t_24212 = heff_tag_at_n(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24203}), v_t_24206});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24207 = heff_field(v_x1_24202, 0);
        heff_take_n(v_x1_24202, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EAnn, 2);
        v_t_24212 = v_c_24207;
        break;
      }
      case TAG_IsType: {
        V v_t_24208 = heff_field(v_x1_24202, 0);
        heff_take_n(v_x1_24202, 1ULL, 1);
        V v_t_24211;
        switch (heff_tag_of(v_t_24208)) {
        case TAG_At: {
          V v_s_24210 = heff_dup(heff_field(v_t_24208, 1));
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_t_24208);
        }
        v_t_24212 = heff_tag_at_n(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24208}), v_t_24211});
        break;
      }
      default: heff_nomatch(v_x1_24202);
      }
      V v_t_24215;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24214 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24215 = v_s_24214;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24212}), v_t_24215});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      V v_x1_24220 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24230;
      switch (heff_tag_of(v_x1_24220)) {
      case TAG_IsInferable: {
        V v_i_24221 = heff_field(v_x1_24220, 0);
        V v_ru_24x1_24220_24IsInferable = heff_take_reuse_n(v_x1_24220, 1ULL, 1);
        V v_t_24224;
        switch (heff_tag_of(v_i_24221)) {
        case TAG_At: {
          V v_s_24223 = heff_dup(heff_field(v_i_24221, 1));
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_i_24221);
        }
        v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24220_24IsInferable, TAG_CInf, 1, (V[]){v_i_24221}), v_t_24224});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24225 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        v_t_24230 = v_c_24225;
        break;
      }
      case TAG_IsType: {
        V v_t_24226 = heff_field(v_x1_24220, 0);
        V v_ru_24x1_24220_24IsType = heff_take_reuse_n(v_x1_24220, 1ULL, 1);
        V v_t_24229;
        switch (heff_tag_of(v_t_24226)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_t_24226, 1));
          v_t_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_t_24226);
        }
        v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24220_24IsType, TAG_CType, 1, (V[]){v_t_24226}), v_t_24229});
        break;
      }
      default: heff_nomatch(v_x1_24220);
      }
      V v_t_24233;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24232 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24233 = v_s_24232;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24230}), v_t_24233});
    }
    case TAG_ESig: {
      V v_ru_24e1_241_24ESig = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24235 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24245;
      switch (heff_tag_of(v_x1_24235)) {
      case TAG_IsInferable: {
        V v_i_24236 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24239;
        switch (heff_tag_of(v_i_24236)) {
        case TAG_At: {
          V v_s_24238 = heff_dup(heff_field(v_i_24236, 1));
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_i_24236);
        }
        v_t_24245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESig, TAG_CInf, 1, (V[]){v_i_24236}), v_t_24239});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24240 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESig, 1);
        v_t_24245 = v_c_24240;
        break;
      }
      case TAG_IsType: {
        V v_t_24241 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24244;
        switch (heff_tag_of(v_t_24241)) {
        case TAG_At: {
          V v_s_24243 = heff_dup(heff_field(v_t_24241, 1));
          v_t_24244 = v_s_24243;
          break;
        }
        default: heff_nomatch(v_t_24241);
        }
        v_t_24245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESig, TAG_CType, 1, (V[]){v_t_24241}), v_t_24244});
        break;
      }
      default: heff_nomatch(v_x1_24235);
      }
      V v_t_24248;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24247 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24248 = v_s_24247;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24245}), v_t_24248});
    }
    case TAG_ESum: {
      V v_ru_24e1_241_24ESum = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24250 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24260;
      switch (heff_tag_of(v_x1_24250)) {
      case TAG_IsInferable: {
        V v_i_24251 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        V v_t_24254;
        switch (heff_tag_of(v_i_24251)) {
        case TAG_At: {
          V v_s_24253 = heff_dup(heff_field(v_i_24251, 1));
          v_t_24254 = v_s_24253;
          break;
        }
        default: heff_nomatch(v_i_24251);
        }
        v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESum, TAG_CInf, 1, (V[]){v_i_24251}), v_t_24254});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24255 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESum, 1);
        v_t_24260 = v_c_24255;
        break;
      }
      case TAG_IsType: {
        V v_t_24256 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        V v_t_24259;
        switch (heff_tag_of(v_t_24256)) {
        case TAG_At: {
          V v_s_24258 = heff_dup(heff_field(v_t_24256, 1));
          v_t_24259 = v_s_24258;
          break;
        }
        default: heff_nomatch(v_t_24256);
        }
        v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESum, TAG_CType, 1, (V[]){v_t_24256}), v_t_24259});
        break;
      }
      default: heff_nomatch(v_x1_24250);
      }
      V v_t_24263;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24262 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24263 = v_s_24262;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24260}), v_t_24263});
    }
    case TAG_EStruct: {
      V v_ru_24e1_241_24EStruct = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24265 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24275;
      switch (heff_tag_of(v_x1_24265)) {
      case TAG_IsInferable: {
        V v_i_24266 = heff_field(v_x1_24265, 0);
        heff_take_n(v_x1_24265, 1ULL, 1);
        V v_t_24269;
        switch (heff_tag_of(v_i_24266)) {
        case TAG_At: {
          V v_s_24268 = heff_dup(heff_field(v_i_24266, 1));
          v_t_24269 = v_s_24268;
          break;
        }
        default: heff_nomatch(v_i_24266);
        }
        v_t_24275 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EStruct, TAG_CInf, 1, (V[]){v_i_24266}), v_t_24269});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24270 = heff_field(v_x1_24265, 0);
        heff_take_n(v_x1_24265, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EStruct, 1);
        v_t_24275 = v_c_24270;
        break;
      }
      case TAG_IsType: {
        V v_t_24271 = heff_field(v_x1_24265, 0);
        heff_take_n(v_x1_24265, 1ULL, 1);
        V v_t_24274;
        switch (heff_tag_of(v_t_24271)) {
        case TAG_At: {
          V v_s_24273 = heff_dup(heff_field(v_t_24271, 1));
          v_t_24274 = v_s_24273;
          break;
        }
        default: heff_nomatch(v_t_24271);
        }
        v_t_24275 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EStruct, TAG_CType, 1, (V[]){v_t_24271}), v_t_24274});
        break;
      }
      default: heff_nomatch(v_x1_24265);
      }
      V v_t_24278;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24277 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24278 = v_s_24277;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24275}), v_t_24278});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_241_24EUpdate = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24281 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24291;
      switch (heff_tag_of(v_x1_24281)) {
      case TAG_IsInferable: {
        V v_i_24282 = heff_field(v_x1_24281, 0);
        heff_take_n(v_x1_24281, 1ULL, 1);
        V v_t_24285;
        switch (heff_tag_of(v_i_24282)) {
        case TAG_At: {
          V v_s_24284 = heff_dup(heff_field(v_i_24282, 1));
          v_t_24285 = v_s_24284;
          break;
        }
        default: heff_nomatch(v_i_24282);
        }
        v_t_24291 = heff_tag_at_n(v_ru_24e1_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24282}), v_t_24285});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24286 = heff_field(v_x1_24281, 0);
        heff_take_n(v_x1_24281, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EUpdate, 2);
        v_t_24291 = v_c_24286;
        break;
      }
      case TAG_IsType: {
        V v_t_24287 = heff_field(v_x1_24281, 0);
        heff_take_n(v_x1_24281, 1ULL, 1);
        V v_t_24290;
        switch (heff_tag_of(v_t_24287)) {
        case TAG_At: {
          V v_s_24289 = heff_dup(heff_field(v_t_24287, 1));
          v_t_24290 = v_s_24289;
          break;
        }
        default: heff_nomatch(v_t_24287);
        }
        v_t_24291 = heff_tag_at_n(v_ru_24e1_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24287}), v_t_24290});
        break;
      }
      default: heff_nomatch(v_x1_24281);
      }
      V v_t_24294;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24293 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24294 = v_s_24293;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24291}), v_t_24294});
    }
    case TAG_EMatch: {
      V v_ru_24e1_241_24EMatch = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24297 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24307;
      switch (heff_tag_of(v_x1_24297)) {
      case TAG_IsInferable: {
        V v_i_24298 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        V v_t_24301;
        switch (heff_tag_of(v_i_24298)) {
        case TAG_At: {
          V v_s_24300 = heff_dup(heff_field(v_i_24298, 1));
          v_t_24301 = v_s_24300;
          break;
        }
        default: heff_nomatch(v_i_24298);
        }
        v_t_24307 = heff_tag_at_n(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24298}), v_t_24301});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24302 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EMatch, 2);
        v_t_24307 = v_c_24302;
        break;
      }
      case TAG_IsType: {
        V v_t_24303 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        V v_t_24306;
        switch (heff_tag_of(v_t_24303)) {
        case TAG_At: {
          V v_s_24305 = heff_dup(heff_field(v_t_24303, 1));
          v_t_24306 = v_s_24305;
          break;
        }
        default: heff_nomatch(v_t_24303);
        }
        v_t_24307 = heff_tag_at_n(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24303}), v_t_24306});
        break;
      }
      default: heff_nomatch(v_x1_24297);
      }
      V v_t_24310;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24309 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24310 = v_s_24309;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24307}), v_t_24310});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_241_24ELetIn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24313 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24323;
      switch (heff_tag_of(v_x1_24313)) {
      case TAG_IsInferable: {
        V v_i_24314 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24317;
        switch (heff_tag_of(v_i_24314)) {
        case TAG_At: {
          V v_s_24316 = heff_dup(heff_field(v_i_24314, 1));
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_i_24314);
        }
        v_t_24323 = heff_tag_at_n(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24314}), v_t_24317});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24318 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELetIn, 2);
        v_t_24323 = v_c_24318;
        break;
      }
      case TAG_IsType: {
        V v_t_24319 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24322;
        switch (heff_tag_of(v_t_24319)) {
        case TAG_At: {
          V v_s_24321 = heff_dup(heff_field(v_t_24319, 1));
          v_t_24322 = v_s_24321;
          break;
        }
        default: heff_nomatch(v_t_24319);
        }
        v_t_24323 = heff_tag_at_n(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24319}), v_t_24322});
        break;
      }
      default: heff_nomatch(v_x1_24313);
      }
      V v_t_24326;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24325 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24326 = v_s_24325;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24323}), v_t_24326});
    }
    case TAG_EDo: {
      V v_ru_24e1_241_24EDo = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24328 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24338;
      switch (heff_tag_of(v_x1_24328)) {
      case TAG_IsInferable: {
        V v_i_24329 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        V v_t_24332;
        switch (heff_tag_of(v_i_24329)) {
        case TAG_At: {
          V v_s_24331 = heff_dup(heff_field(v_i_24329, 1));
          v_t_24332 = v_s_24331;
          break;
        }
        default: heff_nomatch(v_i_24329);
        }
        v_t_24338 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EDo, TAG_CInf, 1, (V[]){v_i_24329}), v_t_24332});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24333 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EDo, 1);
        v_t_24338 = v_c_24333;
        break;
      }
      case TAG_IsType: {
        V v_t_24334 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        V v_t_24337;
        switch (heff_tag_of(v_t_24334)) {
        case TAG_At: {
          V v_s_24336 = heff_dup(heff_field(v_t_24334, 1));
          v_t_24337 = v_s_24336;
          break;
        }
        default: heff_nomatch(v_t_24334);
        }
        v_t_24338 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EDo, TAG_CType, 1, (V[]){v_t_24334}), v_t_24337});
        break;
      }
      default: heff_nomatch(v_x1_24328);
      }
      V v_t_24341;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24340 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24341 = v_s_24340;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24338}), v_t_24341});
    }
    case TAG_ELocal: {
      V v_ru_24e1_241_24ELocal = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24344 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24354;
      switch (heff_tag_of(v_x1_24344)) {
      case TAG_IsInferable: {
        V v_i_24345 = heff_field(v_x1_24344, 0);
        heff_take_n(v_x1_24344, 1ULL, 1);
        V v_t_24348;
        switch (heff_tag_of(v_i_24345)) {
        case TAG_At: {
          V v_s_24347 = heff_dup(heff_field(v_i_24345, 1));
          v_t_24348 = v_s_24347;
          break;
        }
        default: heff_nomatch(v_i_24345);
        }
        v_t_24354 = heff_tag_at_n(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24345}), v_t_24348});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24349 = heff_field(v_x1_24344, 0);
        heff_take_n(v_x1_24344, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELocal, 2);
        v_t_24354 = v_c_24349;
        break;
      }
      case TAG_IsType: {
        V v_t_24350 = heff_field(v_x1_24344, 0);
        heff_take_n(v_x1_24344, 1ULL, 1);
        V v_t_24353;
        switch (heff_tag_of(v_t_24350)) {
        case TAG_At: {
          V v_s_24352 = heff_dup(heff_field(v_t_24350, 1));
          v_t_24353 = v_s_24352;
          break;
        }
        default: heff_nomatch(v_t_24350);
        }
        v_t_24354 = heff_tag_at_n(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24350}), v_t_24353});
        break;
      }
      default: heff_nomatch(v_x1_24344);
      }
      V v_t_24357;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24356 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24357 = v_s_24356;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24354}), v_t_24357});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_241_24EInvalid = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24359 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24369;
      switch (heff_tag_of(v_x1_24359)) {
      case TAG_IsInferable: {
        V v_i_24360 = heff_field(v_x1_24359, 0);
        heff_take_n(v_x1_24359, 1ULL, 1);
        V v_t_24363;
        switch (heff_tag_of(v_i_24360)) {
        case TAG_At: {
          V v_s_24362 = heff_dup(heff_field(v_i_24360, 1));
          v_t_24363 = v_s_24362;
          break;
        }
        default: heff_nomatch(v_i_24360);
        }
        v_t_24369 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInvalid, TAG_CInf, 1, (V[]){v_i_24360}), v_t_24363});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24364 = heff_field(v_x1_24359, 0);
        heff_take_n(v_x1_24359, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInvalid, 1);
        v_t_24369 = v_c_24364;
        break;
      }
      case TAG_IsType: {
        V v_t_24365 = heff_field(v_x1_24359, 0);
        heff_take_n(v_x1_24359, 1ULL, 1);
        V v_t_24368;
        switch (heff_tag_of(v_t_24365)) {
        case TAG_At: {
          V v_s_24367 = heff_dup(heff_field(v_t_24365, 1));
          v_t_24368 = v_s_24367;
          break;
        }
        default: heff_nomatch(v_t_24365);
        }
        v_t_24369 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInvalid, TAG_CType, 1, (V[]){v_t_24365}), v_t_24368});
        break;
      }
      default: heff_nomatch(v_x1_24359);
      }
      V v_t_24372;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24371 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24372 = v_s_24371;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24369}), v_t_24372});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_245));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      V v_t_2430;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2430 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_2418));
        V v_t_2429;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_IsInferable: {
          V v_i_2420 = heff_field(v_x1_2419, 0);
          V v_ru_24x1_2419_24IsInferable = heff_take_reuse_n(v_x1_2419, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_i_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_i_2420);
          }
          v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2419_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2424 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          v_t_2429 = v_c_2424;
          break;
        }
        case TAG_IsType: {
          V v_t_2425 = heff_field(v_x1_2419, 0);
          V v_ru_24x1_2419_24IsType = heff_take_reuse_n(v_x1_2419, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_t_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_t_2425);
          }
          v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2419_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24d_246_24Just, TAG_Just, 1, (V[]){v_t_2429});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2417, v_t_2430}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2431 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_c_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_c_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_c_2437);
        }
        v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2437}), v_t_2440});
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2442 = v_t_2441;
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2442}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      V v_t_246 = (g_list_2emap_24s1887874170x1747433177(v_args_245));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, v_t_246}), v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_247));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2418}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetPath: {
      V v_path_243 = heff_field(v_x21_241, 0);
      V v_e_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24SetPath = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_244));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetPath, TAG_SetPath, 2, (V[]){v_path_243, v_t_2415}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_declared_245 = heff_field(v_x21_241, 2);
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_x1_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_ty_246));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2419 = (g_list_2emap_24s2081626528x1476576812(v_eqs_247));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_243, v_fsp_244, v_declared_245, v_t_2418, v_t_2419}), v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2420 = heff_field(v_x21_241, 0);
      V v_xsp_2421 = heff_field(v_x21_241, 1);
      V v_ps_2422 = heff_field(v_x21_241, 2);
      V v_u_2423 = heff_field(v_x21_241, 3);
      V v_body_2424 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2425 = (g_list_2emap_24s539093115x379698116(v_ps_2422));
      V v_x1_2426 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_u_2423));
      V v_t_2436;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_IsInferable: {
        V v_i_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        V v_t_2430;
        switch (heff_tag_of(v_i_2427)) {
        case TAG_At: {
          V v_s_2429 = heff_dup(heff_field(v_i_2427, 1));
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_i_2427);
        }
        v_t_2436 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2427}), v_t_2430});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2431 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        V v_t_2434;
        switch (heff_tag_of(v_c_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_c_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_c_2431);
        }
        v_t_2436 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2431}), v_t_2434});
        break;
      }
      case TAG_IsType: {
        V v_t_2435 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2436 = v_t_2435;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_x1_2437 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2424));
      V v_t_2447;
      switch (heff_tag_of(v_x1_2437)) {
      case TAG_IsInferable: {
        V v_i_2438 = heff_field(v_x1_2437, 0);
        V v_ru_24x1_2437_24IsInferable = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_i_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_i_2438);
        }
        v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2437_24IsInferable, TAG_CInf, 1, (V[]){v_i_2438}), v_t_2441});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2442 = heff_field(v_x1_2437, 0);
        heff_take_n(v_x1_2437, 1ULL, 1);
        v_t_2447 = v_c_2442;
        break;
      }
      case TAG_IsType: {
        V v_t_2443 = heff_field(v_x1_2437, 0);
        V v_ru_24x1_2437_24IsType = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
        V v_t_2446;
        switch (heff_tag_of(v_t_2443)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_t_2443, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2437_24IsType, TAG_CType, 1, (V[]){v_t_2443}), v_t_2446});
        break;
      }
      default: heff_nomatch(v_x1_2437);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2420, v_xsp_2421, v_t_2425, v_t_2436, v_t_2447}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2448 = heff_field(v_x21_241, 0);
      V v_xsp_2449 = heff_field(v_x21_241, 1);
      V v_ps_2450 = heff_field(v_x21_241, 2);
      V v_body_2451 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2452 = (g_list_2emap_24s539093115x379698116(v_ps_2450));
      V v_x1_2453 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2451));
      V v_t_2463;
      switch (heff_tag_of(v_x1_2453)) {
      case TAG_IsInferable: {
        V v_i_2454 = heff_field(v_x1_2453, 0);
        heff_take_n(v_x1_2453, 1ULL, 1);
        V v_t_2457;
        switch (heff_tag_of(v_i_2454)) {
        case TAG_At: {
          V v_s_2456 = heff_dup(heff_field(v_i_2454, 1));
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_i_2454);
        }
        v_t_2463 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2454}), v_t_2457});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2458 = heff_field(v_x1_2453, 0);
        heff_take_n(v_x1_2453, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2463 = v_c_2458;
        break;
      }
      case TAG_IsType: {
        V v_t_2459 = heff_field(v_x1_2453, 0);
        heff_take_n(v_x1_2453, 1ULL, 1);
        V v_t_2462;
        switch (heff_tag_of(v_t_2459)) {
        case TAG_At: {
          V v_s_2461 = heff_dup(heff_field(v_t_2459, 1));
          v_t_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_t_2459);
        }
        v_t_2463 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2459}), v_t_2462});
        break;
      }
      default: heff_nomatch(v_x1_2453);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2448, v_xsp_2449, v_t_2452, v_t_2463}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2464 = heff_field(v_x21_241, 0);
      V v_xsp_2465 = heff_field(v_x21_241, 1);
      V v_t_2466 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_2467 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2466));
      V v_t_2477;
      switch (heff_tag_of(v_x1_2467)) {
      case TAG_IsInferable: {
        V v_i_2468 = heff_field(v_x1_2467, 0);
        heff_take_n(v_x1_2467, 1ULL, 1);
        V v_t_2471;
        switch (heff_tag_of(v_i_2468)) {
        case TAG_At: {
          V v_s_2470 = heff_dup(heff_field(v_i_2468, 1));
          v_t_2471 = v_s_2470;
          break;
        }
        default: heff_nomatch(v_i_2468);
        }
        v_t_2477 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2468}), v_t_2471});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2472 = heff_field(v_x1_2467, 0);
        heff_take_n(v_x1_2467, 1ULL, 1);
        V v_t_2475;
        switch (heff_tag_of(v_c_2472)) {
        case TAG_At: {
          V v_s_2474 = heff_dup(heff_field(v_c_2472, 1));
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_c_2472);
        }
        v_t_2477 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2472}), v_t_2475});
        break;
      }
      case TAG_IsType: {
        V v_t_2476 = heff_field(v_x1_2467, 0);
        heff_take_n(v_x1_2467, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2477 = v_t_2476;
        break;
      }
      default: heff_nomatch(v_x1_2467);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2464, v_xsp_2465, v_t_2477}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2478 = heff_field(v_x21_241, 0);
      V v_xsp_2479 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2478, v_xsp_2479}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2480 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2481 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2480));
      V v_t_2482 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2481));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2482}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      heff_take_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2427 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2432 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = (g_list_2emap_24s249042484x1701682908(v_fs_2433));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){v_t_2434}), v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2438 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2442 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2446 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2448 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(a[0], a[1]);
}