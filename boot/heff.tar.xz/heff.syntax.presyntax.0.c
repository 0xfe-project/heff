// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_head 9693863
#define LBL_part 9928890
#define LBL_run 322821
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1276400643x126214923(V);
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
Clo g_heff_2esyntax_2epresyntax_2espineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2espineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2espineOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_e1_241, 0);
      V v_xs_2413 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2412, v_xs_2413});
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2espineOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_na(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IBytes: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IPrim: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_i1_241, 0);
      V v_xs_2411 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      heff_drop_tag(v_i_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IUpdate: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 5, "a tag");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 8, "a record");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 8, "a `case`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 29, "a `let` whose body is checked");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 19, "a term with `where`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 9, "`abandon`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 64, " does not infer its type: it must be put where its type is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str14, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str15, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str16, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str17, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str18, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str19, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str20, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str21, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str22, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str23, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str24, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str25, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_i_241;
  }
  case TAG_IsCheckable: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsCheckable = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_c_243 = heff_field(v_x11_242, 0);
      V v_sp_244 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInf: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0);
        break;
      }
      case TAG_CType: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1);
        break;
      }
      case TAG_CLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2);
        break;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3);
        break;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c_243, 0ULL, 4);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4);
        break;
      }
      case TAG_CTag: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5);
        break;
      }
      case TAG_CStruct: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6);
        break;
      }
      case TAG_CMatch: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7);
        break;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8);
        break;
      }
      case TAG_CLocal: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9);
        break;
      }
      case TAG_CAbandon: {
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10);
        break;
      }
      case TAG_CNominal: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11);
        break;
      }
      default: heff_nomatch(v_c_243);
      }
      V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)), heff_tag_at_n(v_ru_24x1_240_24IsCheckable, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
      return heff_tag_at_n(v_ru_24x11_242_24At, TAG_At, 2, (V[]){v_t_2429, v_sp_244});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IsType: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsType = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_At: {
      V v_x111_2431 = heff_dup(heff_field(v_x11_2430, 0));
      V v_sp_2432 = heff_dup(heff_field(v_x11_2430, 1));
      switch (heff_tag_of(v_x111_2431)) {
      case TAG_TPi: {
        V v_ru_24x111_2431_24TPi = heff_take_reuse_n(v_x111_2431, 0ULL, 2);
        heff_drop(v_sp_2432);
        V v_t_2435 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2438;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_at_n(v_ru_24x111_2431_24TPi, TAG_At, 2, (V[]){v_t_2435, v_t_2438});
      }
      case TAG_TSig: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2440 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str14), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_2432});
      }
      case TAG_TSum: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2442 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str15), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_2432});
      }
      case TAG_TType: {
        heff_drop(v_sp_2432);
        V v_t_2443 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str16), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2446;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2445 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2446});
      }
      case TAG_TInt: {
        heff_drop(v_sp_2432);
        V v_t_2447 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str17), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2450;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2449 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2450 = v_s_2449;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2447, v_t_2450});
      }
      case TAG_TFloat: {
        heff_drop(v_sp_2432);
        V v_t_2451 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str18), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2454;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2454});
      }
      case TAG_TString: {
        heff_drop(v_sp_2432);
        V v_t_2455 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str19), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2458;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_t_2458});
      }
      case TAG_TRune: {
        heff_drop(v_sp_2432);
        V v_t_2459 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str20), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2462;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2461 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2459, v_t_2462});
      }
      case TAG_TArray: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2464 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str21), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2467;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_t_2467});
      }
      case TAG_TFixed: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2469 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str22), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2472;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2472});
      }
      case TAG_TInf: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2474 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str23), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2477;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2476 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2477 = v_s_2476;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2477});
      }
      case TAG_TChk: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2479 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str24), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2482;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2481 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_t_2482});
      }
      case TAG_TNominal: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2484 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str25), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2487;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2486 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2487 = v_s_2486;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2484, v_t_2487});
      }
      default: return heff_nomatch(v_x111_2431);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etoInferable(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_240, v_sp_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_244});
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_244});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_244});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    V v_tsp_245 = heff_dup(heff_field(v_h_241, 1));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_EVar: {
      V v_ru_24h1_244_24EVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_247));
      V v_t_249 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_249}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EVar, TAG_IsInferable, 1, (V[]){v_t_2410});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_244_24EImplicitVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2412));
      V v_t_2414 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_ETag: {
      V v_t_2416 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop_tag(v_h_241, 2);
      V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242));
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2416, v_tsp_245, v_t_2428}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2429});
    }
    case TAG_EInt: {
      V v_ru_24h1_244_24EInt = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2432 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2431));
      V v_t_2433 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2433}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInt, TAG_IsInferable, 1, (V[]){v_t_2434});
    }
    case TAG_EFloat: {
      V v_ru_24h1_244_24EFloat = heff_take_reuse_na(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2437 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2436));
      V v_t_2438 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2437, v_t_2438}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2439});
    }
    case TAG_EString: {
      V v_ru_24h1_244_24EString = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2442 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2441));
      V v_t_2443 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2442, v_t_2443}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EString, TAG_IsInferable, 1, (V[]){v_t_2444});
    }
    case TAG_EBinary: {
      V v_ru_24h1_244_24EBinary = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2447 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2446));
      V v_t_2448 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2447, v_t_2448}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EBinary, TAG_IsInferable, 1, (V[]){v_t_2449});
    }
    case TAG_ERune: {
      V v_ru_24h1_244_24ERune = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2451));
      V v_t_2453 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2452, v_t_2453}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ERune, TAG_IsInferable, 1, (V[]){v_t_2454});
    }
    case TAG_EWord: {
      V v_h11_2455 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop(v_tsp_245);
      switch (heff_tag_of(v_h11_2455)) {
      case TAG_TypeWord: {
        V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2457 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2456));
        V v_t_2458 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2458}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2459});
      }
      case TAG_IntWord: {
        V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2461 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2460));
        V v_t_2462 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2461, v_t_2462}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2463});
      }
      case TAG_FloatWord: {
        V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2465 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2464));
        V v_t_2466 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2465, v_t_2466}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2467});
      }
      case TAG_StringWord: {
        V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2469 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2468));
        V v_t_2470 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2469, v_t_2470}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2471});
      }
      case TAG_RuneWord: {
        V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2473 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2472));
        V v_t_2474 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2473, v_t_2474}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2475});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2476 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0), NTAG(TAG_Nothing)});
          V v_t_2477 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2476, heff_dup(v_sp_243)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2477, v_sp_243})});
        }
        case TAG_Cons: {
          V v_a_2478 = heff_field(v_args_242, 0);
          V v_args2_2479 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2479)) {
          case TAG_Nil: {
            V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2478}));
            V v_t_2490;
            switch (heff_tag_of(v_x1_2480)) {
            case TAG_IsInferable: {
              V v_i_2481 = heff_field(v_x1_2480, 0);
              heff_take_n(v_x1_2480, 1ULL, 1);
              V v_t_2484;
              switch (heff_tag_of(v_i_2481)) {
              case TAG_At: {
                V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
                v_t_2484 = v_s_2483;
                break;
              }
              default: heff_nomatch(v_i_2481);
              }
              v_t_2490 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2481}), v_t_2484});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2485 = heff_field(v_x1_2480, 0);
              heff_take_n(v_x1_2480, 1ULL, 1);
              V v_t_2488;
              switch (heff_tag_of(v_c_2485)) {
              case TAG_At: {
                V v_s_2487 = heff_dup(heff_field(v_c_2485, 1));
                v_t_2488 = v_s_2487;
                break;
              }
              default: heff_nomatch(v_c_2485);
              }
              v_t_2490 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2485}), v_t_2488});
              break;
            }
            case TAG_IsType: {
              V v_t_2489 = heff_field(v_x1_2480, 0);
              heff_take_n(v_x1_2480, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2490 = v_t_2489;
              break;
            }
            default: heff_nomatch(v_x1_2480);
            }
            V v_t_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2490}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2491});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2479, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2478);
            V v_t_2494 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1), NTAG(TAG_Nothing)});
            V v_t_2495 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2494, heff_dup(v_sp_243)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){v_t_2495, v_sp_243})});
          }
          default: return heff_nomatch(v_args2_2479);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2496 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2497 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2496));
        V v_t_2498 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2499 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2497, v_t_2498}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2499});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2455, 0ULL, 1);
        V v_t_24101 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_24102 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24101));
        V v_t_24103 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24102, v_t_24103}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_24104});
      }
      default: return heff_nomatch(v_h11_2455);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_244_24EApp = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24108 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24107));
      V v_t_24109 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24110 = heff_tag_at_n(v_ru_24h1_244_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24108, v_t_24109}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24110});
    }
    case TAG_EProject: {
      V v_ru_24h1_244_24EProject = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24113 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24112));
      V v_t_24114 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24113, v_t_24114}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EProject, TAG_IsInferable, 1, (V[]){v_t_24115});
    }
    case TAG_ENamed: {
      V v_ru_24h1_244_24ENamed = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24119 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24118));
      V v_t_24120 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24121 = heff_tag_at_n(v_ru_24h1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24119, v_t_24120}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24121});
    }
    case TAG_EPi: {
      V v_ru_24h1_244_24EPi = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24124 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24125 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24124));
      V v_t_24126 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24127 = heff_tag_at_n(v_ru_24h1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24125, v_t_24126}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24127});
    }
    case TAG_ELam: {
      V v_ru_24h1_244_24ELam = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24130 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24131 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24130));
      V v_t_24132 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24133 = heff_tag_at_n(v_ru_24h1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24131, v_t_24132}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24133});
    }
    case TAG_EAnn: {
      V v_ru_24h1_244_24EAnn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24136 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24137 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24136));
      V v_t_24138 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24139 = heff_tag_at_n(v_ru_24h1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24138}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24139});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_244, 0ULL, 4);
      heff_drop(v_tsp_245);
      V v_t_24144 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24145 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24144));
      V v_t_24146 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24145, v_t_24146}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24147});
    }
    case TAG_ESig: {
      V v_ru_24h1_244_24ESig = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24149 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24150 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24149));
      V v_t_24151 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24152 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24151}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESig, TAG_IsInferable, 1, (V[]){v_t_24152});
    }
    case TAG_ESum: {
      V v_ru_24h1_244_24ESum = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24154 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24155 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24154));
      V v_t_24156 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24157 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24155, v_t_24156}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESum, TAG_IsInferable, 1, (V[]){v_t_24157});
    }
    case TAG_EStruct: {
      V v_ru_24h1_244_24EStruct = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24160 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24159));
      V v_t_24161 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24161}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EStruct, TAG_IsInferable, 1, (V[]){v_t_24162});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_244_24EUpdate = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24166 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24165));
      V v_t_24167 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24168 = heff_tag_at_n(v_ru_24h1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24166, v_t_24167}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24168});
    }
    case TAG_EMatch: {
      V v_ru_24h1_244_24EMatch = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24171 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24172 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24171));
      V v_t_24173 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24174 = heff_tag_at_n(v_ru_24h1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24172, v_t_24173}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24174});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_244_24ELetIn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24177 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24178 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24177));
      V v_t_24179 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24180 = heff_tag_at_n(v_ru_24h1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24178, v_t_24179}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24180});
    }
    case TAG_EDo: {
      V v_ru_24h1_244_24EDo = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24183 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24182));
      V v_t_24184 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24185 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24183, v_t_24184}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EDo, TAG_IsInferable, 1, (V[]){v_t_24185});
    }
    case TAG_ELocal: {
      V v_ru_24h1_244_24ELocal = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24188 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24189 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24188));
      V v_t_24190 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24191 = heff_tag_at_n(v_ru_24h1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24189, v_t_24190}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24191});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_244_24EInvalid = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24193 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24194 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24193));
      V v_t_24195 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24196 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24194, v_t_24195}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24196});
    }
    default: return heff_nomatch(v_h1_244);
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_IsInferable: {
    V v_i_2419 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsInferable = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_i_2419)) {
    case TAG_At: {
      V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_i_2419);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2418_24IsInferable, TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
  }
  case TAG_IsCheckable: {
    V v_c_2423 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_c_2423;
  }
  case TAG_IsType: {
    V v_t_2424 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsType = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
      v_t_2427 = v_s_2426;
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2418_24IsType, TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkSegment: {
      V v_v_244 = heff_field(v_x21_242, 0);
      V v_x212_245 = heff_field(v_x21_242, 1);
      V v_size_246 = heff_field(v_x21_242, 2);
      V v_little_247 = heff_field(v_x21_242, 3);
      V v_signed_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 31ULL, 5);
      switch (heff_tag_of(v_x212_245)) {
      case TAG_SegmentInteger: {
        V v_t_249 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(8LL), heff_dup(v_sp_243)));
        int64_t v_t_2410;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        int64_t v_t_2411;
        if ((heff_dup(v_signed_248) == NTAG(TAG_True))) {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        V v_t_2412 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2410 + v_t_2411))});
        V v_t_2413 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_243)})});
        V v_x1_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2424;
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_IsInferable: {
          V v_i_2415 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsInferable = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_i_2415)) {
          case TAG_At: {
            V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
            v_t_2418 = v_s_2417;
            break;
          }
          default: heff_nomatch(v_i_2415);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsInferable, TAG_CInf, 1, (V[]){v_i_2415}), v_t_2418});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2419 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 1);
          v_t_2424 = v_c_2419;
          break;
        }
        case TAG_IsType: {
          V v_t_2420 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsType = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsType, TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_243)}), v_t_2425});
        V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2426});
        V v_t_2428 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2427));
        V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str0)}), heff_dup(v_sp_243)});
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2428}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), v_sp_243});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        switch (heff_tag_of(v_size_246)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_243);
          V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          switch (heff_tag_of(v_x1_2431)) {
          case TAG_IsInferable: {
            V v_i_2432 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            V v_t_2435;
            switch (heff_tag_of(v_i_2432)) {
            case TAG_At: {
              V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
              v_t_2435 = v_s_2434;
              break;
            }
            default: heff_nomatch(v_i_2432);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2432}), v_t_2435});
          }
          case TAG_IsCheckable: {
            V v_c_2436 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            return v_c_2436;
          }
          case TAG_IsType: {
            V v_t_2437 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            V v_t_2440;
            switch (heff_tag_of(v_t_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_t_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_t_2437);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2437}), v_t_2440});
          }
          default: return heff_nomatch(v_x1_2431);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2453;
          switch (heff_tag_of(v_x1_2443)) {
          case TAG_IsInferable: {
            V v_i_2444 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2447;
            switch (heff_tag_of(v_i_2444)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_i_2444);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2448 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2453 = v_c_2448;
            break;
          }
          case TAG_IsType: {
            V v_t_2449 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2452;
            switch (heff_tag_of(v_t_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_t_2449);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
            break;
          }
          default: heff_nomatch(v_x1_2443);
          }
          V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
          V v_args_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2454});
          V v_t_2456 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2455));
          V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str1)}), heff_dup(v_sp_243)});
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2456}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2458}), v_sp_243});
        }
        case TAG_SizeName: {
          V v_t_2462 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2473;
          switch (heff_tag_of(v_x1_2463)) {
          case TAG_IsInferable: {
            V v_i_2464 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            V v_t_2467;
            switch (heff_tag_of(v_i_2464)) {
            case TAG_At: {
              V v_s_2466 = heff_dup(heff_field(v_i_2464, 1));
              v_t_2467 = v_s_2466;
              break;
            }
            default: heff_nomatch(v_i_2464);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2464}), v_t_2467});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2468 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2473 = v_c_2468;
            break;
          }
          case TAG_IsType: {
            V v_t_2469 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            V v_t_2472;
            switch (heff_tag_of(v_t_2469)) {
            case TAG_At: {
              V v_s_2471 = heff_dup(heff_field(v_t_2469, 1));
              v_t_2472 = v_s_2471;
              break;
            }
            default: heff_nomatch(v_t_2469);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2469}), v_t_2472});
            break;
          }
          default: heff_nomatch(v_x1_2463);
          }
          V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, NTAG(TAG_Nil)});
          V v_args_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_t_2474});
          V v_t_2476 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2475));
          V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str2)}), heff_dup(v_sp_243)});
          V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2477, v_t_2476}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2478}), v_sp_243});
        }
        default: return heff_nomatch(v_size_246);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_246);
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        V v_x1_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2489;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_IsInferable: {
          V v_i_2480 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          V v_t_2483;
          switch (heff_tag_of(v_i_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_i_2480);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2484 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2489 = v_c_2484;
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          V v_t_2488;
          switch (heff_tag_of(v_t_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_t_2485);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
        V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2490));
        V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str3)}), heff_dup(v_sp_243)});
        V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_243});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_248);
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_246), MK_INT(64LL), heff_dup(v_sp_243)));
        int64_t v_t_2495;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)0ULL);
        }
        V v_t_2496 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2495 + ((int64_t)0ULL)))});
        V v_t_2497 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2496, heff_dup(v_sp_243)})});
        V v_t_2498 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(64LL), heff_dup(v_sp_243)));
        V v_x1_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_24109;
        switch (heff_tag_of(v_x1_2499)) {
        case TAG_IsInferable: {
          V v_i_24100 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsInferable = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24103;
          switch (heff_tag_of(v_i_24100)) {
          case TAG_At: {
            V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
            v_t_24103 = v_s_24102;
            break;
          }
          default: heff_nomatch(v_i_24100);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsInferable, TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_24104 = heff_field(v_x1_2499, 0);
          heff_take_n(v_x1_2499, 1ULL, 1);
          v_t_24109 = v_c_24104;
          break;
        }
        case TAG_IsType: {
          V v_t_24105 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsType = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24108;
          switch (heff_tag_of(v_t_24105)) {
          case TAG_At: {
            V v_s_24107 = heff_dup(heff_field(v_t_24105, 1));
            v_t_24108 = v_s_24107;
            break;
          }
          default: heff_nomatch(v_t_24105);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsType, TAG_CType, 1, (V[]){v_t_24105}), v_t_24108});
          break;
        }
        default: heff_nomatch(v_x1_2499);
        }
        V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
        V v_args_24111 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, v_t_24110});
        V v_t_24112 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24111));
        V v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str4)}), heff_dup(v_sp_243)});
        V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24113, v_t_24112}), heff_dup(v_sp_243)});
        V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24114}), heff_dup(v_sp_243)});
        V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
        V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2497, heff_dup(v_sp_243)}), v_t_24116});
        V v_args_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_t_24117});
        V v_t_24119 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24118));
        V v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str5)}), heff_dup(v_sp_243)});
        V v_t_24121 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24120, v_t_24119}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24121}), v_sp_243});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24122 = heff_field(v_x212_245, 0);
        V v_ru_24x212_245_24SegmentUtf = heff_take_reuse_n(v_x212_245, 1ULL, 1);
        heff_drop(v_size_246);
        heff_drop(v_signed_248);
        if (heff_intEq_c(heff_dup(v_x2121_24122), MK_INT(8LL))) {
          heff_drop(v_little_247);
          heff_drop(v_x2121_24122);
          V v_t_24124 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
          V v_args_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          V v_t_24126 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24125));
          V v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str6)}), heff_dup(v_sp_243)});
          V v_t_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24127, v_t_24126}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24128}), v_sp_243});
        } else {
          if (heff_intEq_c(v_x2121_24122, MK_INT(16LL))) {
            int64_t v_t_24130;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24130 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24130 = ((int64_t)0ULL);
            }
            V v_t_24131 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24130 + ((int64_t)0ULL)))});
            V v_t_24132 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24131, heff_dup(v_sp_243)})});
            V v_t_24133 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
            V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24132, heff_dup(v_sp_243)}), v_t_24134});
            V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24135));
            V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str7)}), heff_dup(v_sp_243)});
            V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), v_sp_243});
          } else {
            int64_t v_t_24139;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24139 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24139 = ((int64_t)0ULL);
            }
            V v_t_24140 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24139 + ((int64_t)0ULL)))});
            V v_t_24141 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24140, heff_dup(v_sp_243)})});
            V v_t_24142 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
            V v_args_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, heff_dup(v_sp_243)}), v_t_24143});
            V v_t_24145 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24144));
            V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str8)}), heff_dup(v_sp_243)});
            V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24146, v_t_24145}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24147}), v_sp_243});
          }
        }
      }
      default: return heff_nomatch(v_x212_245);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EImplicitVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinary: {
    V v_segs_247 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_segs_247}});
  }
  case TAG_ERune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWord: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProject: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENamed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPi: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAnn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESpec: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESig: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStruct: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUpdate: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetIn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EDo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELocal: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInvalid: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4, 10, "bitsConcat");
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0, 2, 0};
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V v_lit_240, V v_r_241, V v_segs_242, V v_sp_243, V v_x5_244) {
top: ;
  if ((heff_dup(v_x5_244) == NTAG(TAG_True))) {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2414 = heff_rec_n(2, shape_part__run, (V[]){v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo)});
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2414, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_243)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2418));
    V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1)}), heff_dup(v_sp_243)});
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2419}), heff_dup(v_sp_243)});
    V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), heff_dup(v_sp_243)});
    V v_args_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2)}), heff_dup(v_sp_243)});
    V v_t_2425 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2423));
    V v_f_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2424, v_t_2425}), v_sp_243});
    return ((HeffT1){{v_f_2426}});
  } else {
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2436 = heff_rec_n(2, shape_part__run, (V[]){v_t_2427, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo)});
    V v_xs_2437 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2436, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2438, heff_dup(v_sp_243)));
    V v_args_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4)}), heff_dup(v_sp_243)});
    V v_t_2442 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2440));
    V v_f_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, v_t_2442}), v_sp_243});
    return ((HeffT1){{v_f_2443}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_sp_247 = args[1];
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_246}), heff_dup(v_sp_247)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_247)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_247), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0)}), heff_dup(v_sp_247)});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2411}), heff_dup(v_sp_247)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), v_sp_247});
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args) {
  V v_s_2428 = args[0];
  V v_sp_2429 = args[1];
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2428}), heff_dup(v_sp_2429)});
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), heff_dup(v_sp_2429)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_t_2433 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2429), v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3)}), heff_dup(v_sp_2429)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2434, v_t_2433}), heff_dup(v_sp_2429)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2435}), v_sp_2429});
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V v_v_240, V v_sp_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_240));
  V v_t_2416;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_c_246 = v_field_244;
      v_t_2416 = v_c_246;
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        V v_i_248 = v_field_244;
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      } else {
        V v_t_2412 = v_field_244;
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
      }
    }
  }
  V v_args_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2417));
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0)}), heff_dup(v_sp_241)});
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2418}), heff_dup(v_sp_241)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2420}), v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2421;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_c_2411 = v_field_249;
          V v_t_2414;
          switch (heff_tag_of(v_c_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_c_2411);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        } else {
          if ((v_tag_248 == ((int64_t)1ULL))) {
            V v_i_2416 = v_field_249;
            V v_t_2419;
            switch (heff_tag_of(v_i_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_i_2416);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2416}), v_t_2419});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2420 = v_field_249;
            v_t_2421 = v_t_2420;
          }
        }
      }
      V v_t_2438;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2422 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2422));
        V v_t_2437;
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_c_2427 = v_field_2425;
            v_t_2437 = v_c_2427;
          } else {
            if ((v_tag_2424 == ((int64_t)1ULL))) {
              V v_i_2429 = v_field_2425;
              V v_t_2432;
              switch (heff_tag_of(v_i_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_i_2429);
              }
              v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2429}), v_t_2432});
            } else {
              V v_t_2433 = v_field_2425;
              V v_t_2436;
              switch (heff_tag_of(v_t_2433)) {
              case TAG_At: {
                V v_s_2435 = heff_dup(heff_field(v_t_2433, 1));
                v_t_2436 = v_s_2435;
                break;
              }
              default: heff_nomatch(v_t_2433);
              }
              v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2433}), v_t_2436});
            }
          }
        }
        v_t_2438 = heff_tag_at_n(v_ru_24d_246_24Just, TAG_Just, 1, (V[]){v_t_2437});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2421, v_t_2438}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2439 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2439));
      V v_t_2454;
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_c_2444 = v_field_2442;
          V v_t_2447;
          switch (heff_tag_of(v_c_2444)) {
          case TAG_At: {
            V v_s_2446 = heff_dup(heff_field(v_c_2444, 1));
            v_t_2447 = v_s_2446;
            break;
          }
          default: heff_nomatch(v_c_2444);
          }
          v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2444}), v_t_2447});
        } else {
          if ((v_tag_2441 == ((int64_t)1ULL))) {
            V v_i_2449 = v_field_2442;
            V v_t_2452;
            switch (heff_tag_of(v_i_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_i_2449);
            }
            v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2453 = v_field_2442;
            v_t_2454 = v_t_2453;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2454}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetPath: {
      V v_path_243 = heff_field(v_x21_241, 0);
      V v_e_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24SetPath = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_244));
      V v_t_2419;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_249 = v_field_247;
          v_t_2419 = v_c_249;
        } else {
          if ((v_tag_246 == ((int64_t)1ULL))) {
            V v_i_2411 = v_field_247;
            V v_t_2414;
            switch (heff_tag_of(v_i_2411)) {
            case TAG_At: {
              V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
              v_t_2414 = v_s_2413;
              break;
            }
            default: heff_nomatch(v_i_2411);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2411}), v_t_2414});
          } else {
            V v_t_2415 = v_field_247;
            V v_t_2418;
            switch (heff_tag_of(v_t_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_t_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_t_2415);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2415}), v_t_2418});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetPath, TAG_SetPath, 2, (V[]){v_path_243, v_t_2419}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_declared_245 = heff_field(v_x21_241, 2);
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_ty_246));
      V v_t_2422;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = v_field_2410;
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2417 = v_field_2410;
            V v_t_2420;
            switch (heff_tag_of(v_i_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_i_2417);
            }
            v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2417}), v_t_2420});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2421 = v_field_2410;
            v_t_2422 = v_t_2421;
          }
        }
      }
      V v_t_2423 = (g_list_2emap_24s1276400643x126214923(v_eqs_247));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_243, v_fsp_244, v_declared_245, v_t_2422, v_t_2423}), v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2424 = heff_field(v_x21_241, 0);
      V v_xsp_2425 = heff_field(v_x21_241, 1);
      V v_ps_2426 = heff_field(v_x21_241, 2);
      V v_u_2427 = heff_field(v_x21_241, 3);
      V v_body_2428 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2429 = (g_list_2emap_24s2051429168x672290949(v_ps_2426));
      HeffT2 v_t_2430 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_u_2427));
      V v_t_2444;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_c_2434 = v_field_2432;
          V v_t_2437;
          switch (heff_tag_of(v_c_2434)) {
          case TAG_At: {
            V v_s_2436 = heff_dup(heff_field(v_c_2434, 1));
            v_t_2437 = v_s_2436;
            break;
          }
          default: heff_nomatch(v_c_2434);
          }
          v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2434}), v_t_2437});
        } else {
          if ((v_tag_2431 == ((int64_t)1ULL))) {
            V v_i_2439 = v_field_2432;
            V v_t_2442;
            switch (heff_tag_of(v_i_2439)) {
            case TAG_At: {
              V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
              v_t_2442 = v_s_2441;
              break;
            }
            default: heff_nomatch(v_i_2439);
            }
            v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2439}), v_t_2442});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2443 = v_field_2432;
            v_t_2444 = v_t_2443;
          }
        }
      }
      HeffT2 v_t_2445 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2428));
      V v_t_2459;
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_c_2449 = v_field_2447;
          v_t_2459 = v_c_2449;
        } else {
          if ((v_tag_2446 == ((int64_t)1ULL))) {
            V v_i_2451 = v_field_2447;
            V v_t_2454;
            switch (heff_tag_of(v_i_2451)) {
            case TAG_At: {
              V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
              v_t_2454 = v_s_2453;
              break;
            }
            default: heff_nomatch(v_i_2451);
            }
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
          } else {
            V v_t_2455 = v_field_2447;
            V v_t_2458;
            switch (heff_tag_of(v_t_2455)) {
            case TAG_At: {
              V v_s_2457 = heff_dup(heff_field(v_t_2455, 1));
              v_t_2458 = v_s_2457;
              break;
            }
            default: heff_nomatch(v_t_2455);
            }
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2455}), v_t_2458});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2424, v_xsp_2425, v_t_2429, v_t_2444, v_t_2459}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2460 = heff_field(v_x21_241, 0);
      V v_xsp_2461 = heff_field(v_x21_241, 1);
      V v_ps_2462 = heff_field(v_x21_241, 2);
      V v_body_2463 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2464 = (g_list_2emap_24s2051429168x672290949(v_ps_2462));
      HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2463));
      V v_t_2479;
      {
        V v_field_2467 = v_t_2465.f[1];
        int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
        if ((v_tag_2466 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2469 = v_field_2467;
          v_t_2479 = v_c_2469;
        } else {
          if ((v_tag_2466 == ((int64_t)1ULL))) {
            V v_i_2471 = v_field_2467;
            V v_t_2474;
            switch (heff_tag_of(v_i_2471)) {
            case TAG_At: {
              V v_s_2473 = heff_dup(heff_field(v_i_2471, 1));
              v_t_2474 = v_s_2473;
              break;
            }
            default: heff_nomatch(v_i_2471);
            }
            v_t_2479 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2471}), v_t_2474});
          } else {
            V v_t_2475 = v_field_2467;
            V v_t_2478;
            switch (heff_tag_of(v_t_2475)) {
            case TAG_At: {
              V v_s_2477 = heff_dup(heff_field(v_t_2475, 1));
              v_t_2478 = v_s_2477;
              break;
            }
            default: heff_nomatch(v_t_2475);
            }
            v_t_2479 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2475}), v_t_2478});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2460, v_xsp_2461, v_t_2464, v_t_2479}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2480 = heff_field(v_x21_241, 0);
      V v_xsp_2481 = heff_field(v_x21_241, 1);
      V v_t_2482 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_2483 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2482));
      V v_t_2497;
      {
        V v_field_2485 = v_t_2483.f[1];
        int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
        if ((v_tag_2484 == ((int64_t)0ULL))) {
          V v_c_2487 = v_field_2485;
          V v_t_2490;
          switch (heff_tag_of(v_c_2487)) {
          case TAG_At: {
            V v_s_2489 = heff_dup(heff_field(v_c_2487, 1));
            v_t_2490 = v_s_2489;
            break;
          }
          default: heff_nomatch(v_c_2487);
          }
          v_t_2497 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2487}), v_t_2490});
        } else {
          if ((v_tag_2484 == ((int64_t)1ULL))) {
            V v_i_2492 = v_field_2485;
            V v_t_2495;
            switch (heff_tag_of(v_i_2492)) {
            case TAG_At: {
              V v_s_2494 = heff_dup(heff_field(v_i_2492, 1));
              v_t_2495 = v_s_2494;
              break;
            }
            default: heff_nomatch(v_i_2492);
            }
            v_t_2497 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2492}), v_t_2495});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2496 = v_field_2485;
            v_t_2497 = v_t_2496;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2480, v_xsp_2481, v_t_2497}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2498 = heff_field(v_x21_241, 0);
      V v_xsp_2499 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2498, v_xsp_2499}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_24100 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24101 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_24100));
      V v_t_24102 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_24101));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_24102}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      heff_take_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2427 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2432 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = (g_list_2emap_24s249042484x1701682908(v_fs_2433));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){v_t_2434}), v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2438 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2442 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2446 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2448 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(a[0], a[1]);
}