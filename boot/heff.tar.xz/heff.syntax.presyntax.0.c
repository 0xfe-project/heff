// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_EReturn 59059
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_bind__pure__giveBack[] = {LBL_bind, LBL_pure, LBL_giveBack};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecoNames_str0, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecoNames_str1, 4, "pure");

static V g_heff_2esyntax_2epresyntax_2ecoNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2ecoNames_st;
static V g_heff_2esyntax_2epresyntax_2ecoNames_init(void) {
  return heff_rec_n(3, shape_bind__pure__giveBack, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecoNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2ecoNames_str1), NTAG(TAG_False)});
}
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2ecoNames_st)) return g_heff_2esyntax_2epresyntax_2ecoNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2ecoNames_val, &g_heff_2esyntax_2epresyntax_2ecoNames_st, g_heff_2esyntax_2epresyntax_2ecoNames_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str1, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2epackE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackE(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), v_sp_240});
    }
    case TAG_Cons: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str1)}), heff_dup(v_sp_240)});
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2epackE(v_sp_240, v_x22_243));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epackE(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str0, 12, "builtin.Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str1, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str3, 14, "prelude.typeOf");
Clo g_heff_2esyntax_2epresyntax_2epackTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackTy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackTy(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str1)}), heff_dup(v_sp_240)});
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), v_sp_240});
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246);
    }
    case TAG_Cons: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str2)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str3)}), heff_dup(v_sp_240)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2412));
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_x22_243));
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epackTy(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_244 = v_st_240;
    V v_x3_245 = v_x_242;
    V v_x1_2444;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_At: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_sp_247 = heff_field(v_x3_245, 1);
      V v_ru_24x3_245_24At = heff_take_reuse_n(v_x3_245, 3ULL, 2);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x31_246, 0);
        V v_xsp_249 = heff_field(v_x31_246, 1);
        V v_e_2410 = heff_field(v_x31_246, 2);
        V v_ru_24x31_246_24SetField = heff_take_reuse_n(v_x31_246, 7ULL, 3);
        V v_x_2425;
        if ((heff_dup(v_st_244) == NTAG(TAG_True))) {
          heff_drop(v_st_244);
          v_x_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_244);
          switch (heff_tag_of(v_e_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_e_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2425 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2425 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2410)));
              {
                V v_field_2421 = v_t_2420.f[0];
                V v_field_2422 = v_t_2420.f[1];
                V v_a_2423 = v_field_2421;
                V v_a_2424 = v_field_2422;
                heff_drop(v_a_2424);
                v_x_2425 = v_a_2423;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2410);
          }
        }
        V v_t_2426 = heff_tag_at_n(v_ru_24x3_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_246_24SetField, TAG_SetField, 3, (V[]){v_x_248, v_xsp_249, v_e_2410}), v_sp_247});
        v_x1_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_t_2426});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2427 = heff_field(v_x31_246, 0);
        V v_ru_24x31_246_24BadFieldSet = heff_take_reuse_n(v_x31_246, 1ULL, 1);
        V v_x_2442;
        if ((heff_dup(v_st_244) == NTAG(TAG_True))) {
          heff_drop(v_st_244);
          v_x_2442 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_244);
          switch (heff_tag_of(v_e_2427)) {
          case TAG_At: {
            V v_a_2428 = heff_dup(heff_field(v_e_2427, 0));
            switch (heff_tag_of(v_a_2428)) {
            case TAG_ELam: {
              heff_take_n(v_a_2428, 0ULL, 2);
              switch (heff_tag_of(v_e_2427)) {
              case TAG_At: {
                v_x_2442 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2427);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2428, 0ULL, 1);
              switch (heff_tag_of(v_e_2427)) {
              case TAG_At: {
                v_x_2442 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2427);
              }
              break;
            }
            default: {
              heff_drop(v_a_2428);
              HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2427)));
              {
                V v_field_2438 = v_t_2437.f[0];
                V v_field_2439 = v_t_2437.f[1];
                V v_a_2440 = v_field_2438;
                V v_a_2441 = v_field_2439;
                heff_drop(v_a_2441);
                v_x_2442 = v_a_2440;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2427);
          }
        }
        V v_t_2443 = heff_tag_at_n(v_ru_24x3_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_246_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_e_2427}), v_sp_247});
        v_x1_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2442, v_t_2443});
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x1_2444)) {
    case TAG_MkPair: {
      V v_st_2445 = heff_field(v_x1_2444, 0);
      V v_y_2446 = heff_field(v_x1_2444, 1);
      heff_take_n(v_x1_2444, 3ULL, 2);
      HeffT2 v_t_2447 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(v_st_2445, v_xs_243));
      {
        V v_field_2448 = v_t_2447.f[0];
        V v_field_2449 = v_t_2447.f[1];
        V v_x_2450 = v_field_2448;
        V v_y_2451 = v_field_2449;
        return ((HeffT2){{v_x_2450, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2446, v_y_2451})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2444)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_244;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_st_244 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_x_242)));
    }
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_st_244, v_xs_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_y_249 = v_field_247;
      return ((HeffT2){{v_x_248, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_249})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_st_240; V a_1 = v_x_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_st_247 = v_field_245;
      V v_y_248 = v_field_246;
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_247, v_xs_243));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_y_2413 = v_field_2411;
        return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_y_2413})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkSegment: {
      V v_v_244 = heff_field(v_x21_242, 0);
      V v_x212_245 = heff_field(v_x21_242, 1);
      V v_size_246 = heff_field(v_x21_242, 2);
      V v_little_247 = heff_field(v_x21_242, 3);
      V v_signed_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 31ULL, 5);
      switch (heff_tag_of(v_x212_245)) {
      case TAG_SegmentInteger: {
        V v_t_249 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(8LL), heff_dup(v_sp_243)));
        int64_t v_t_2410;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        int64_t v_t_2411;
        if ((heff_dup(v_signed_248) == NTAG(TAG_True))) {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        V v_t_2412 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2410 + v_t_2411))});
        V v_t_2413 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_243)})});
        V v_x1_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2424;
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_IsInferable: {
          V v_i_2415 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsInferable = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_i_2415)) {
          case TAG_At: {
            V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
            v_t_2418 = v_s_2417;
            break;
          }
          default: heff_nomatch(v_i_2415);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsInferable, TAG_CInf, 1, (V[]){v_i_2415}), v_t_2418});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2419 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 1);
          v_t_2424 = v_c_2419;
          break;
        }
        case TAG_IsType: {
          V v_t_2420 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsType = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsType, TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_243)}), v_t_2425});
        V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2426});
        V v_t_2428 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2427));
        V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str0)}), heff_dup(v_sp_243)});
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2428}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), v_sp_243});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        switch (heff_tag_of(v_size_246)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_243);
          V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          switch (heff_tag_of(v_x1_2431)) {
          case TAG_IsInferable: {
            V v_i_2432 = heff_field(v_x1_2431, 0);
            V v_ru_24x1_2431_24IsInferable = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
            V v_t_2435;
            switch (heff_tag_of(v_i_2432)) {
            case TAG_At: {
              V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
              v_t_2435 = v_s_2434;
              break;
            }
            default: heff_nomatch(v_i_2432);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2431_24IsInferable, TAG_CInf, 1, (V[]){v_i_2432}), v_t_2435});
          }
          case TAG_IsCheckable: {
            V v_c_2436 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            return v_c_2436;
          }
          case TAG_IsType: {
            V v_t_2437 = heff_field(v_x1_2431, 0);
            V v_ru_24x1_2431_24IsType = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
            V v_t_2440;
            switch (heff_tag_of(v_t_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_t_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_t_2437);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2431_24IsType, TAG_CType, 1, (V[]){v_t_2437}), v_t_2440});
          }
          default: return heff_nomatch(v_x1_2431);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2453;
          switch (heff_tag_of(v_x1_2443)) {
          case TAG_IsInferable: {
            V v_i_2444 = heff_field(v_x1_2443, 0);
            V v_ru_24x1_2443_24IsInferable = heff_take_reuse_n(v_x1_2443, 1ULL, 1);
            V v_t_2447;
            switch (heff_tag_of(v_i_2444)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_i_2444);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2443_24IsInferable, TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2448 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2453 = v_c_2448;
            break;
          }
          case TAG_IsType: {
            V v_t_2449 = heff_field(v_x1_2443, 0);
            V v_ru_24x1_2443_24IsType = heff_take_reuse_n(v_x1_2443, 1ULL, 1);
            V v_t_2452;
            switch (heff_tag_of(v_t_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_t_2449);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2443_24IsType, TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
            break;
          }
          default: heff_nomatch(v_x1_2443);
          }
          V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
          V v_args_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2454});
          V v_t_2456 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2455));
          V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str1)}), heff_dup(v_sp_243)});
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2456}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2458}), v_sp_243});
        }
        case TAG_SizeName: {
          V v_t_2462 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2473;
          switch (heff_tag_of(v_x1_2463)) {
          case TAG_IsInferable: {
            V v_i_2464 = heff_field(v_x1_2463, 0);
            V v_ru_24x1_2463_24IsInferable = heff_take_reuse_n(v_x1_2463, 1ULL, 1);
            V v_t_2467;
            switch (heff_tag_of(v_i_2464)) {
            case TAG_At: {
              V v_s_2466 = heff_dup(heff_field(v_i_2464, 1));
              v_t_2467 = v_s_2466;
              break;
            }
            default: heff_nomatch(v_i_2464);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2463_24IsInferable, TAG_CInf, 1, (V[]){v_i_2464}), v_t_2467});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2468 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2473 = v_c_2468;
            break;
          }
          case TAG_IsType: {
            V v_t_2469 = heff_field(v_x1_2463, 0);
            V v_ru_24x1_2463_24IsType = heff_take_reuse_n(v_x1_2463, 1ULL, 1);
            V v_t_2472;
            switch (heff_tag_of(v_t_2469)) {
            case TAG_At: {
              V v_s_2471 = heff_dup(heff_field(v_t_2469, 1));
              v_t_2472 = v_s_2471;
              break;
            }
            default: heff_nomatch(v_t_2469);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2463_24IsType, TAG_CType, 1, (V[]){v_t_2469}), v_t_2472});
            break;
          }
          default: heff_nomatch(v_x1_2463);
          }
          V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, NTAG(TAG_Nil)});
          V v_args_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_t_2474});
          V v_t_2476 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2475));
          V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str2)}), heff_dup(v_sp_243)});
          V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2477, v_t_2476}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2478}), v_sp_243});
        }
        default: return heff_nomatch(v_size_246);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_246);
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        V v_x1_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2489;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_IsInferable: {
          V v_i_2480 = heff_field(v_x1_2479, 0);
          V v_ru_24x1_2479_24IsInferable = heff_take_reuse_n(v_x1_2479, 1ULL, 1);
          V v_t_2483;
          switch (heff_tag_of(v_i_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_i_2480);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2479_24IsInferable, TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2484 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2489 = v_c_2484;
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2479, 0);
          V v_ru_24x1_2479_24IsType = heff_take_reuse_n(v_x1_2479, 1ULL, 1);
          V v_t_2488;
          switch (heff_tag_of(v_t_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_t_2485);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2479_24IsType, TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
        V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2490));
        V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str3)}), heff_dup(v_sp_243)});
        V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_243});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_248);
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_246), MK_INT(64LL), heff_dup(v_sp_243)));
        int64_t v_t_2495;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)0ULL);
        }
        V v_t_2496 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2495 + ((int64_t)0ULL)))});
        V v_t_2497 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2496, heff_dup(v_sp_243)})});
        V v_t_2498 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(64LL), heff_dup(v_sp_243)));
        V v_x1_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_24109;
        switch (heff_tag_of(v_x1_2499)) {
        case TAG_IsInferable: {
          V v_i_24100 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsInferable = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24103;
          switch (heff_tag_of(v_i_24100)) {
          case TAG_At: {
            V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
            v_t_24103 = v_s_24102;
            break;
          }
          default: heff_nomatch(v_i_24100);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsInferable, TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_24104 = heff_field(v_x1_2499, 0);
          heff_take_n(v_x1_2499, 1ULL, 1);
          v_t_24109 = v_c_24104;
          break;
        }
        case TAG_IsType: {
          V v_t_24105 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsType = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24108;
          switch (heff_tag_of(v_t_24105)) {
          case TAG_At: {
            V v_s_24107 = heff_dup(heff_field(v_t_24105, 1));
            v_t_24108 = v_s_24107;
            break;
          }
          default: heff_nomatch(v_t_24105);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsType, TAG_CType, 1, (V[]){v_t_24105}), v_t_24108});
          break;
        }
        default: heff_nomatch(v_x1_2499);
        }
        V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
        V v_args_24111 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, v_t_24110});
        V v_t_24112 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24111));
        V v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str4)}), heff_dup(v_sp_243)});
        V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24113, v_t_24112}), heff_dup(v_sp_243)});
        V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24114}), heff_dup(v_sp_243)});
        V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
        V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2497, heff_dup(v_sp_243)}), v_t_24116});
        V v_args_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_t_24117});
        V v_t_24119 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24118));
        V v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str5)}), heff_dup(v_sp_243)});
        V v_t_24121 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24120, v_t_24119}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24121}), v_sp_243});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24122 = heff_field(v_x212_245, 0);
        V v_ru_24x212_245_24SegmentUtf = heff_take_reuse_n(v_x212_245, 1ULL, 1);
        heff_drop(v_size_246);
        heff_drop(v_signed_248);
        if (heff_intEq_c_lent(v_x2121_24122, MK_INT(8LL), 2)) {
          heff_drop(v_little_247);
          heff_drop(v_x2121_24122);
          V v_t_24123 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
          V v_args_24124 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
          V v_t_24125 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24124));
          V v_t_24126 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str6)}), heff_dup(v_sp_243)});
          V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24126, v_t_24125}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24127}), v_sp_243});
        } else {
          if (heff_intEq_c(v_x2121_24122, MK_INT(16LL))) {
            int64_t v_t_24128;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24128 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24128 = ((int64_t)0ULL);
            }
            V v_t_24129 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24128 + ((int64_t)0ULL)))});
            V v_t_24130 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24129, heff_dup(v_sp_243)})});
            V v_t_24131 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
            V v_args_24133 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24130, heff_dup(v_sp_243)}), v_t_24132});
            V v_t_24134 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24133));
            V v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str7)}), heff_dup(v_sp_243)});
            V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24135, v_t_24134}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24136}), v_sp_243});
          } else {
            int64_t v_t_24137;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24137 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24137 = ((int64_t)0ULL);
            }
            V v_t_24138 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24137 + ((int64_t)0ULL)))});
            V v_t_24139 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24138, heff_dup(v_sp_243)})});
            V v_t_24140 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
            V v_args_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24139, heff_dup(v_sp_243)}), v_t_24141});
            V v_t_24143 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24142));
            V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str8)}), heff_dup(v_sp_243)});
            V v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24144, v_t_24143}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24145}), v_sp_243});
          }
        }
      }
      default: return heff_nomatch(v_x212_245);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      V v_ru_24i_242_24At = heff_take_reuse_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_242_24At, v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(v_ru_24t_246_24At, v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2427 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2432 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = (g_list_2emap_24s249042484x1701682908(v_fs_2433));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){v_t_2434}), v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2438 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2442 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2446 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2448 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_depth_244 = heff_take_field(v_j_243, 3);
  V v_head_245 = heff_take_field(v_j_243, 0);
  V v_vars_246 = heff_take_field(v_j_243, 1);
  V v_unit_247 = heff_get_n(v_j_243, 2, 4);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_244);
  V v_vars_249 = v_vars_246;
  V v_t_2413;
  if ((heff_dup(v_unit_247) == NTAG(TAG_True))) {
    heff_drop(v_unit_247);
    switch (heff_tag_of(v_vars_249)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 2);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
      break;
    }
    default: heff_nomatch(v_vars_249);
    }
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_unit_247);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_245, v_t_2413));
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eleaving(v_cx_241, v_sp_242, v_t_248, v_t_2414);
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str2, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str3, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str5, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V v_tok_240, V v_cx_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str0)}), v_sp_244});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str1)}), v_sp_244});
    }
    case TAG_StmtExpr: {
      V v_e_2410 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2410));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop_rec(v_sp_244, 2);
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
        heff_drop(v_t_2411);
        return (g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(v_cx_241, v_e_2410, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_2411);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_241, 4)))) {
          V v_t_2412 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2412}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_x_2416 = v_field_2414;
            V v_y_2417 = v_field_2415;
            V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
            V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2418}), heff_dup(v_sp_244)});
            V v_t_2420 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2421 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str2), v_t_2420)});
            V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_244)}), NTAG(TAG_Nil)});
            V v_t_2423 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2419, v_t_2422));
            V v_rest_2424 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), heff_dup(v_sp_244), heff_dup(heff_rfield(v_cx_241, 4)), v_t_2423));
            V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
            V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2425}), heff_dup(heff_rfield(v_cx_241, 3))});
            V v_t_2427 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2428 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str3), v_t_2427), heff_dup(v_sp_244)});
            V v_t_2431;
            switch (heff_tag_of(v_rest_2424)) {
            case TAG_At: {
              V v_s_2430 = heff_dup(heff_field(v_rest_2424, 1));
              v_t_2431 = v_s_2430;
              break;
            }
            default: heff_nomatch(v_rest_2424);
            }
            V v_t_2432 = ({ V rv_1 = heff_get_n(v_t_2431, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2428, v_rest_2424}), v_t_2432});
            V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
            V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2417, v_t_2434})));
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2416; V a_2 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
          }
        } else {
          heff_drop_cell(v_tok_240, 2);
          heff_drop_rec(v_sp_244, 2);
          heff_drop_cell(v_ru_24x3_242_24At, 2);
          heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
          V v_t_2436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2436}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2438 = v_t_2437.f[0];
            V v_field_2439 = v_t_2437.f[1];
            V v_x_2440 = v_field_2438;
            V v_y_2441 = v_field_2439;
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2440; V a_2 = v_y_2441; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str4)}), v_sp_244});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop_rec(v_cx_241, 6);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_str5)}), v_sp_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24tok2_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V v_tok_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24tok2_str0), 2)) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_x_244);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2418));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2419); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2421 = heff_field(v_x11_242, 0);
      V v_q_2423 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2424 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_2421, heff_hole()});
      V v_u_2425 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2423, heff_dup(v_cell_2424)));
      heff_drop(v_u_2425);
      return v_cell_2424;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames_24tok2(a[0], a[1]);
}