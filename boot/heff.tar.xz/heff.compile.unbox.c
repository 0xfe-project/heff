// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_GivenTag 49870
#define TAG_ManyTags 51265
#define TAG_MkArm 55352
#define TAG_NoTag 1821
#define TAG_OneTag 13947
#define TAG_Tip 31527
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_last 9809757
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_slots 310891087
#define LBL_tag 324116
#define LBL_tys 324872
#define LBL_vars 10107635
static uint32_t shape_at__param__tag__tys__vars[] = {LBL_at, LBL_param, LBL_tag, LBL_tys, LBL_vars};
static uint32_t shape_key__body__last__args[] = {LBL_key, LBL_body, LBL_last, LBL_args};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__slots[] = {LBL_key, LBL_slots};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2escalars_2eselfLast(V, V, V);
V g_heff_2ecompile_2escalars_2eselfLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eselfLast_clo;
V g_heff_2ecompile_2eunbox_2eaddGiven(V, V);
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo;
V g_heff_2ecompile_2eunbox_2eargsRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2eargsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eargsRw_clo;
V g_heff_2ecompile_2eunbox_2ecallerCall(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallerCall_clo;
V g_heff_2ecompile_2eunbox_2ecallersIn(V, V);
V g_heff_2ecompile_2eunbox_2ecallersIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersIn_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw(V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_24dps_clo;
V g_heff_2ecompile_2eunbox_2ecallsLoopW(V, V);
V g_heff_2ecompile_2eunbox_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsLoopW_clo;
V g_heff_2ecompile_2eunbox_2ecallsW(V, V, V);
V g_heff_2ecompile_2eunbox_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsW_clo;
V g_heff_2ecompile_2eunbox_2edefWith(V, V);
V g_heff_2ecompile_2eunbox_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2edefWith_clo;
V g_heff_2ecompile_2eunbox_2eexitsWhole(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2eexitsWhole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eexitsWhole_clo;
V g_heff_2ecompile_2eunbox_2efirstApart(V, V, V, V);
V g_heff_2ecompile_2eunbox_2efirstApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2efirstApart_clo;
V g_heff_2ecompile_2eunbox_2egivenOf(V, V);
V g_heff_2ecompile_2eunbox_2egivenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2egivenOf_clo;
V g_heff_2ecompile_2eunbox_2eisBuilt(V, V);
V g_heff_2ecompile_2eunbox_2eisBuilt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eisBuilt_clo;
V g_heff_2ecompile_2eunbox_2ejustsOf(V);
V g_heff_2ecompile_2eunbox_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ejustsOf_clo;
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2eunbox_2elamWholeW(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2elamWholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2elamWholeW_clo;
V g_heff_2ecompile_2eunbox_2eloopDefs(V, V, V, V);
V g_heff_2ecompile_2eunbox_2eloopDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eloopDefs_clo;
V g_heff_2ecompile_2eunbox_2ematchRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ematchRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ematchRw_clo;
V g_heff_2ecompile_2eunbox_2eparamsRw(V, V, V);
V g_heff_2ecompile_2eunbox_2eparamsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eparamsRw_clo;
V g_heff_2ecompile_2eunbox_2erw(V, V);
V g_heff_2ecompile_2eunbox_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_clo;
V g_heff_2ecompile_2eunbox_2erw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2erw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_24dps_clo;
V g_heff_2ecompile_2eunbox_2eslotFor(V, V, V);
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotFor_clo;
V g_heff_2ecompile_2eunbox_2eslotWith(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotWith_clo;
V g_heff_2ecompile_2eunbox_2eslotsIn(V, V);
V g_heff_2ecompile_2eunbox_2eslotsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsIn_clo;
V g_heff_2ecompile_2eunbox_2eslotsOf(V);
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo;
V g_heff_2ecompile_2eunbox_2esomeApart(V, V);
V g_heff_2ecompile_2eunbox_2esomeApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2esomeApart_clo;
V g_heff_2ecompile_2eunbox_2espread(V, V, V);
V g_heff_2ecompile_2eunbox_2espread_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2espread_clo;
V g_heff_2ecompile_2eunbox_2etakesApart(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2etakesApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2etakesApart_clo;
V g_heff_2ecompile_2eunbox_2ewholeW(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ewholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewholeW_clo;
V g_heff_2ecompile_2eunbox_2ewithVars(V);
V g_heff_2ecompile_2eunbox_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewithVars_clo;
V g_heff_2ecompile_2eunbox_2ewrapArgs(V, V, V);
V g_heff_2ecompile_2eunbox_2ewrapArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewrapArgs_clo;
V g_heff_2ecompile_2eunbox_2ewrapBody(V, V, V);
V g_heff_2ecompile_2eunbox_2ewrapBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewrapBody_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1351953222x1439135591_24cpr(V, V);
V g_list_2efind_24s945009177x1839852169(V, V);
V g_list_2efind_24s945009177x1839852169_entry(V self, V *a);
extern Clo g_list_2efind_24s945009177x1839852169_clo;
HeffT2 g_list_2efind_24s945009177x1839852169_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f237374790x641547121(V, V, V);
V g_list_2efoldl_24f237374790x641547121_entry(V self, V *a);
extern Clo g_list_2efoldl_24f237374790x641547121_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s825077203x853965193(V, V);
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s825077203x853965193_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1023948938x380005785(V, V, V);
V g_list_2ezipWith_24s1023948938x380005785_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1023948938x380005785_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_prelude_2etraverse_24s1435890225x1582751312(V, V, V, V);
V g_prelude_2etraverse_24s1435890225x1582751312_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1435890225x1582751312_clo;
HeffT2 g_prelude_2etraverse_24s1512790070x1159539918_24cpr(V, V);
V g_prelude_2etraverse_24s350379375x322835164(V);
V g_prelude_2etraverse_24s350379375x322835164_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s350379375x322835164_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2eunbox_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallsW_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ecallsW(V v_f_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_g_249 = heff_field(v_x31_243, 0);
      V v_argv_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2410, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_g_249, v_t_2411});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2415;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2416, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2418;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2424, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2426;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2427, v_t_2429});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2432 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2432, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2433;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2434 = heff_field(v_x31_243, 0);
      V v_argv_2435 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2437;
      if (heff_strEq_c_lent(v_g_2434, v_f_240, 1)) {
        v_t_2437 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_argv_2435), v_acc_241});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2437 = v_acc_241;
      }
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2435, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_t_2437;
      V t_2 = v_t_2438;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ecallsW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eunbox_2etakesApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2etakesApart_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2etakesApart(V v_p_240, V v_t_241, V v_k_242, V v_s_243, V v_arms_244) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_EVar: {
    V v_y_245 = heff_field(v_s_243, 0);
    if (heff_strEq_c_lent(v_p_240, v_y_245, 0)) {
      switch (heff_tag_of(v_arms_244)) {
      case TAG_Nil: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_arms1_247 = heff_field(v_arms_244, 0);
        V v_arms2_248 = heff_field(v_arms_244, 1);
        switch (heff_tag_of(v_arms1_247)) {
        case TAG_MkArm: {
          V v_t2_249 = heff_field(v_arms1_247, 0);
          V v_vs_2410 = heff_field(v_arms1_247, 1);
          switch (heff_tag_of(v_arms2_248)) {
          case TAG_Nil: {
            V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_241, v_t2_249, 0) && ({ V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2410)); int c_ = heff_intEq_c_lent(v_t_2413, v_k_242, 0); heff_drop(v_t_2413); c_; })));
            heff_drop(v_k_242);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            heff_drop(v_k_242);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_arms2_248);
          }
        }
        default: return heff_nomatch(v_arms1_247);
        }
      }
      default: return heff_nomatch(v_arms_244);
      }
    } else {
      heff_drop(v_k_242);
      return NTAG(TAG_False);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2eunbox_2etakesApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eunbox_2etakesApart(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2eunbox_2ewholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewholeW_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2ewholeW(V v_p_240, V v_t_241, V v_k_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      V v_y_247 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_249;
      if (heff_strEq_c_lent(v_y_247, v_p_240, 1)) {
        v_t_249 = heff_intAdd(v_n_243, MK_INT(1LL));
      } else {
        v_t_249 = v_n_243;
      }
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_t_249;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2412 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_b_2412, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2413 = heff_field(v_x51_245, 0);
      V v_argv_2414 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2414, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_2413, v_t_2415});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2417 = heff_field(v_x51_245, 1);
      V v_b_2418 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2419 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2418, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2419;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2420 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2422 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2420, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2422;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2423 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 4);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_e_2423, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2428 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2428, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2430;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2431 = heff_field(v_x51_245, 0);
      V v_arms_2432 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2433 = (g_heff_2ecompile_2eunbox_2etakesApart(v_p_240, v_t_241, heff_dup(v_k_242), v_s_2431, v_arms_2432));
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_s_2431);
        heff_drop(v_t_2433);
        V v_t_2434 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2432, v_rest_246));
        V t_0 = v_p_240;
        V t_1 = v_t_241;
        V t_2 = v_k_242;
        V t_3 = v_n_243;
        V t_4 = v_t_2434;
        v_p_240 = t_0;
        v_t_241 = t_1;
        v_k_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2433);
        V v_t_2435 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2432, v_rest_246));
        V t_0 = v_p_240;
        V t_1 = v_t_241;
        V t_2 = v_k_242;
        V t_3 = v_n_243;
        V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_s_2431, v_t_2435});
        v_p_240 = t_0;
        v_t_241 = t_1;
        v_k_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2438 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2438, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2439;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2441 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2442 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2441, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2442;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eunbox_2ewholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2ewholeW(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eunbox_2elamWholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2elamWholeW_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2elamWholeW(V v_p_240, V v_t_241, V v_k_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_b_2410, NTAG(TAG_Nil)});
      V v_t_2412 = (g_heff_2ecompile_2eunbox_2ewholeW(v_p_240, v_t_241, heff_dup(v_k_242), v_n_243, v_t_2411));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_t_2412;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2413 = heff_field(v_x51_245, 0);
      V v_argv_2414 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2414, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_2413, v_t_2415});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2417 = heff_field(v_x51_245, 1);
      V v_b_2418 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2419 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2418, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2419;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2420 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2422 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2420, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2422;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2423 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 4);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_e_2423, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2428 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2428, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2430;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2431 = heff_field(v_x51_245, 0);
      V v_arms_2432 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2432, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_s_2431, v_t_2433});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2436 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2436, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2437;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2439 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2440 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2439, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2440;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eunbox_2elamWholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2elamWholeW(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eexitsWhole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eexitsWhole_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2eexitsWhole(V v_f_240, V v_p_241, V v_t_242, V v_k_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_246);
  }
  case TAG_EGlobal: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_248);
  }
  case TAG_ELam: {
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2411);
  }
  case TAG_EApp: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2414);
  }
  case TAG_ELet: {
    V v_b_2417 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 4ULL, 3);
    V t_0 = v_f_240;
    V t_1 = v_p_241;
    V t_2 = v_t_242;
    V t_3 = v_k_243;
    V t_4 = v_b_2417;
    v_f_240 = t_0;
    v_p_241 = t_1;
    v_t_242 = t_2;
    v_k_243 = t_3;
    v_e_244 = t_4;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2420);
  }
  case TAG_EProj: {
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2425);
  }
  case TAG_ETag: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2429);
  }
  case TAG_EMatch: {
    V v_arms_2431 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eunbox_2eexitsWhole_lam0, 2, 4, (V[]){heff_dup(v_f_240), heff_dup(v_p_241), heff_dup(v_t_242), v_k_243}); V a_1 = MK_INT(0LL); V a_2 = v_arms_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2431); r_; });
  }
  case TAG_EPrim: {
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2440);
  }
  case TAG_EPrimCall: {
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2443);
  }
  case TAG_ECall: {
    V v_g_2444 = heff_field(v_e_244, 0);
    V v_argv_2445 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2444, v_f_240, 0)) {
      heff_drop(v_k_243);
      heff_drop(v_g_2444);
      heff_drop(v_argv_2445);
      heff_drop_cell(v_ru_24e_244_24ECall, 2);
      return MK_INT(0LL);
    } else {
      V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){v_g_2444, v_argv_2445}), NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2447);
    }
  }
  case TAG_EInt: {
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2449);
  }
  case TAG_EFloat: {
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2451);
  }
  case TAG_EStr: {
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2453);
  }
  case TAG_EBytes: {
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2455);
  }
  case TAG_EFixed: {
    V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2458);
  }
  case TAG_EFloat32: {
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2460);
  }
  case TAG_EAbandon: {
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2461);
  }
  case TAG_EFix: {
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2464);
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eunbox_2eexitsWhole(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_lam0(V self, V *args) {
  V v_n_2432 = args[0];
  V v_arm_2433 = args[1];
  V v_f_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2437;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_b_2436 = heff_field(v_arm_2433, 2);
    heff_take_n(v_arm_2433, 4ULL, 3);
    v_t_2437 = v_b_2436;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2438 = ({ V a_0 = v_f_240; V a_1 = v_p_241; V a_2 = v_t_242; V a_3 = v_k_243; V a_4 = v_t_2437; V r_ = (g_heff_2ecompile_2eunbox_2eexitsWhole(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_240); heff_drop(v_p_241); heff_drop(v_t_242); r_; });
  return heff_intAdd(v_n_2432, v_t_2438);
}
V g_heff_2ecompile_2eunbox_2efirstApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2efirstApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2efirstApart_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2efirstApart(V v_p_240, V v_t_241, V v_k_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_e_243, 1);
    V v_b_2412 = heff_field(v_e_243, 2);
    V v_t_2413 = (g_heff_2ecompile_2eir_2eisValue(v_a_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_b_2412;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_e_243 = t_3;
      goto top;
    } else {
      heff_drop(v_k_242);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_e_243, 0);
    V v_arms_2424 = heff_field(v_e_243, 1);
    V v_t_2425 = (g_heff_2ecompile_2eunbox_2etakesApart(v_p_240, v_t_241, heff_dup(v_k_242), v_s_2423, v_arms_2424));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_k_242);
      heff_drop(v_t_2425);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2425);
      switch (heff_tag_of(v_s_2423)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2424)) {
        case TAG_Nil: {
          heff_drop(v_k_242);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          return (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2efirstApart_lam0, 1, 3, (V[]){heff_dup(v_p_240), heff_dup(v_t_241), v_k_242}), v_arms_2424));
        }
        default: return heff_nomatch(v_arms_2424);
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2423);
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eunbox_2efirstApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2efirstApart(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2efirstApart_lam0(V self, V *args) {
  V v_a_2429 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_b_2432 = heff_field(v_a_2429, 2);
    heff_take_n(v_a_2429, 4ULL, 3);
    v_t_2433 = v_b_2432;
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_t_241; V a_2 = v_k_242; V a_3 = v_t_2433; V r_ = (g_heff_2ecompile_2eunbox_2efirstApart(a_0, a_1, a_2, a_3)); heff_drop(v_p_240); heff_drop(v_t_241); heff_drop(v_t_2433); r_; });
}
V g_heff_2ecompile_2eunbox_2esomeApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2esomeApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2esomeApart_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2esomeApart(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eisValue(v_a_249));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V t_0 = v_p_240;
      V t_1 = v_b_2410;
      v_p_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_2411);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_e_241, 0);
    V v_arms_2422 = heff_field(v_e_241, 1);
    V v_t_2462;
    switch (heff_tag_of(v_s_2421)) {
    case TAG_EVar: {
      V v_y_2423 = heff_field(v_s_2421, 0);
      if (heff_strEq_c_lent(v_p_240, v_y_2423, 0)) {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          v_t_2462 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          V v_arms2_2426 = heff_field(v_arms_2422, 1);
          switch (heff_tag_of(v_arms2_2426)) {
          case TAG_Nil: {
            v_t_2462 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            v_t_2462 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_2426);
          }
          break;
        }
        default: heff_nomatch(v_arms_2422);
        }
      } else {
        v_t_2462 = NTAG(TAG_False);
      }
      break;
    }
    case TAG_EGlobal: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2421);
    }
    if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
      heff_drop(v_t_2462);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2462);
      switch (heff_tag_of(v_s_2421)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          HEFF_LAST return g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2esomeApart_lam0, 1, 1, (V[]){heff_dup(v_p_240)}), v_arms_2422);
        }
        default: return heff_nomatch(v_arms_2422);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2421);
      }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2esomeApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2esomeApart(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2esomeApart_lam0(V self, V *args) {
  V v_a_2466 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_t_2470; V r_ = (g_heff_2ecompile_2eunbox_2esomeApart(a_0, a_1)); heff_drop(v_p_240); heff_drop(v_t_2470); r_; });
}
V g_heff_2ecompile_2eunbox_2egivenOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2egivenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2egivenOf_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2egivenOf(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_e_241, 0);
    if (heff_strEq_c_lent(v_y_242, v_p_240, 0)) {
      return NTAG(TAG_GivenSame);
    } else {
      return NTAG(TAG_GivenOther);
    }
  }
  case TAG_EGlobal: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELam: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EApp: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELet: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ERecord: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EProj: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ETag: {
    V v_t_2418 = heff_field(v_e_241, 0);
    V v_argv_2419 = heff_field(v_e_241, 1);
    V v_ts_2420 = heff_field(v_e_241, 2);
    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2419));
    V v_t_2422 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2421, MK_INT(1LL))));
    V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2egivenOf_lam0, 1, 1, (V[]){heff_dup(v_ts_2420)}), v_t_2422));
    return heff_tag_n(TAG_GivenTag, 2, (V[]){heff_dup(v_t_2418), v_t_2424});
  }
  case TAG_EMatch: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrim: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ECall: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EInt: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EStr: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EBytes: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFixed: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFix: {
    return NTAG(TAG_GivenOther);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2egivenOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2egivenOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2egivenOf_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_ts_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2423; V a_1 = v_ts_2420; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2420); r_; });
}
Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eaddGiven_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eaddGiven(V v_s_240, V v_g_241) {
top: ;
  switch (heff_tag_of(v_g_241)) {
  case TAG_GivenTag: {
    V v_g1_242 = heff_field(v_g_241, 0);
    V v_g2_243 = heff_field(v_g_241, 1);
    V v_ru_24g_241_24GivenTag = heff_take_reuse_n(v_g_241, 3ULL, 2);
    switch (heff_tag_of(v_s_240)) {
    case TAG_NoTag: {
      return heff_tag_at_n(v_ru_24g_241_24GivenTag, TAG_OneTag, 2, (V[]){v_g1_242, v_g2_243});
    }
    case TAG_OneTag: {
      V v_t_244 = heff_field(v_s_240, 0);
      V v_ts_245 = heff_field(v_s_240, 1);
      heff_take_n(v_s_240, 3ULL, 2);
      if (heff_strEq_c_lent(v_t_244, v_g1_242, 2)) {
        V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_245));
        V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_g2_243));
        if (heff_intEq_c(v_t_247, v_t_248)) {
          V v_t_2410 = (g_list_2ezipWith_24s1893966264x617194987(v_ts_245, v_g2_243));
          return heff_tag_at_n(v_ru_24g_241_24GivenTag, TAG_OneTag, 2, (V[]){v_t_244, v_t_2410});
        } else {
          heff_drop(v_g2_243);
          heff_drop_cell(v_ru_24g_241_24GivenTag, 2);
          heff_drop(v_t_244);
          heff_drop(v_ts_245);
          return NTAG(TAG_ManyTags);
        }
      } else {
        heff_drop(v_g2_243);
        heff_drop_cell(v_ru_24g_241_24GivenTag, 2);
        heff_drop(v_t_244);
        heff_drop(v_ts_245);
        return NTAG(TAG_ManyTags);
      }
    }
    case TAG_ManyTags: {
      heff_drop(v_g1_242);
      heff_drop(v_g2_243);
      heff_drop_cell(v_ru_24g_241_24GivenTag, 2);
      return NTAG(TAG_ManyTags);
    }
    default: return heff_nomatch(v_s_240);
    }
  }
  case TAG_GivenSame: {
    return v_s_240;
  }
  case TAG_GivenOther: {
    heff_drop(v_s_240);
    return NTAG(TAG_ManyTags);
  }
  default: return heff_nomatch(v_g_241);
  }
}
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eaddGiven(a[0], a[1]);
}
Clo g_heff_2ecompile_2eunbox_2eslotWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotWith_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2eslotWith(V v_c_240, V v_i_241, V v_p_242, V v_sames_243, V v_g_244) {
top: ;
  switch (heff_tag_of(v_g_244)) {
  case TAG_NoTag: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    heff_drop(v_sames_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OneTag: {
    V v_t_245 = heff_field(v_g_244, 0);
    V v_ts_246 = heff_field(v_g_244, 1);
    V v_ru_24g_244_24OneTag = heff_take_reuse_n(v_g_244, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_246));
    if (heff_intLe_c(v_t_247, MK_INT(8LL))) {
      switch (heff_tag_of(v_ts_246)) {
      case TAG_Nil: {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_i_241);
        heff_drop(v_p_242);
        heff_drop(v_sames_243);
        heff_drop(v_t_245);
        heff_drop_cell(v_ru_24g_244_24OneTag, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_246));
        V v_t_2412 = (g_heff_2ecompile_2eunbox_2efirstApart(v_p_242, v_t_245, v_t_2411, heff_rfield(v_c_240, 1)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_246));
          V v_t_2414 = heff_tag_at_n(v_ru_24g_244_24OneTag, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2ecompile_2eunbox_2elamWholeW(v_p_242, v_t_245, v_t_2413, MK_INT(0LL), v_t_2414));
          if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
            V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_246));
            V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_Nil)});
            V v_t_2419 = (g_heff_2ecompile_2eunbox_2ewholeW(v_p_242, v_t_245, v_t_2417, MK_INT(0LL), v_t_2418));
            V v_k_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_246));
            V v_t_2421 = heff_take_field(v_c_240, 2);
            V v_t_2422;
            if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
              heff_drop(v_t_2421);
              v_t_2422 = ({ V b_0 = heff_dup(heff_rfield(v_c_240, 0)); V a_1 = v_p_242; V a_2 = v_t_245; V a_3 = v_k_2420; V a_4 = heff_get_n(v_c_240, 1, 4); V r_ = (g_heff_2ecompile_2eunbox_2eexitsWhole(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            } else {
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_k_2420);
              heff_drop(v_t_2421);
              v_t_2422 = MK_INT(0LL);
            }
            if (heff_intEq_c(v_t_2419, heff_intAdd(v_sames_243, v_t_2422))) {
              V v_t_2424 = heff_rec_n(5, shape_at__param__tag__tys__vars, (V[]){v_i_241, v_p_242, v_t_245, v_ts_246, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
            } else {
              heff_drop(v_i_241);
              heff_drop(v_p_242);
              heff_drop(v_t_245);
              heff_drop_tag(v_ts_246, 2);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop_rec(v_c_240, 4);
            heff_drop(v_i_241);
            heff_drop(v_p_242);
            heff_drop(v_sames_243);
            heff_drop(v_t_245);
            heff_drop_tag(v_ts_246, 2);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_i_241);
          heff_drop(v_p_242);
          heff_drop(v_sames_243);
          heff_drop(v_t_245);
          heff_drop_tag(v_ts_246, 2);
          heff_drop_cell(v_ru_24g_244_24OneTag, 2);
          heff_drop(v_t_2412);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_ts_246);
      }
    } else {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_i_241);
      heff_drop(v_p_242);
      heff_drop(v_sames_243);
      heff_drop(v_t_245);
      heff_drop(v_ts_246);
      heff_drop_cell(v_ru_24g_244_24OneTag, 2);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_ManyTags: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    heff_drop(v_sames_243);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_g_244);
  }
}
V g_heff_2ecompile_2eunbox_2eslotWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotWith(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eunbox_2eslotFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotFor_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2eslotFor(V v_c_240, V v_p_241, V v_i_242) {
top: ;
  V v_gs_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotFor_lam0, 1, 2, (V[]){heff_dup(v_i_242), heff_dup(v_p_241)}), heff_dup(heff_rfield(v_c_240, 3))));
  V v_t_2413 = (g_list_2efoldl_24f237374790x641547121(MK_INT(1LL), MK_INT(0LL), v_gs_2412));
  V v_t_2414 = ({ V a_0 = NTAG(TAG_NoTag); V a_1 = v_gs_2412; V r_ = (g_list_2efoldl_24s825077203x853965193(a_0, a_1)); heff_drop(v_gs_2412); r_; });
  return (g_heff_2ecompile_2eunbox_2eslotWith(v_c_240, v_i_242, v_p_241, v_t_2413, v_t_2414));
}
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotFor(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eunbox_2eslotFor_lam0(V self, V *args) {
  V v_argv_243 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT3 v_t_244 = ({ V a_0 = v_i_242; V a_1 = v_argv_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_243); r_; });
  V v_t_2411;
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_246;
      V v_x12_2410 = v_field_247;
      heff_drop(v_x12_2410);
      v_t_2411 = v_x_249;
    } else {
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      v_t_2411 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_p_241; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eunbox_2egivenOf(a_0, a_1)); heff_drop(v_p_241); heff_drop(v_t_2411); r_; });
}
Clo g_heff_2ecompile_2eunbox_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ms_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eunbox_2ejustsOf_24dps(v_ms_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eunbox_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ejustsOf(a[0]);
}
Clo g_heff_2ecompile_2eunbox_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_ms_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ejustsOf_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2eslotsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotsIn_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eslotsIn(V v_xs_240, V v_c_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_c_241, 3));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_xs_240);
    heff_drop_rec(v_c_241, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    heff_take_n(v_t_242, 0ULL, 2);
    V v_t_249 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotsIn_lam0, 1, 1, (V[]){heff_dup(v_xs_240)}), heff_rfield(v_c_241, 3)));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_xs_240);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_t_249);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_249);
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
      V v_t_2412 = (g_list_2ezipWith_24s1023948938x380005785(v_c_241, v_xs_240, v_t_2411));
      return (g_heff_2ecompile_2eunbox_2ejustsOf(v_t_2412));
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eunbox_2eslotsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotsIn(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2eslotsIn_lam0(V self, V *args) {
  V v_argv_245 = args[0];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_245); r_; });
  V v_y_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_240); r_; });
  V v_ret_24bool = heff_bool(!heff_intEq_c_lent(v_x_246, v_y_247, 0));
  heff_drop(v_x_246);
  heff_drop(v_y_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eunbox_2eslotsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotsOf_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2eslotsOf(V v_d_240) {
top: ;
  V v_t_241 = heff_take_field(v_d_240, 2);
  switch (heff_tag_of(v_t_241)) {
  case TAG_EVar: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_t_241, 0);
    V v_b_245 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24ELam = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_t_247 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotsOf_lam0, 1, 1, (V[]){heff_dup(v_b_245)}), v_xs_244));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_f_248 = heff_dup(heff_rfield(v_d_240, 0));
      V v_t_249 = heff_tag_at_n(v_ru_24t_241_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_245), NTAG(TAG_Nil)});
      V v_args_2410 = ({ V b_0 = heff_get_n(v_d_240, 0, 3); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2eunbox_2ecallsW(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_xs_2411 = (g_heff_2ecompile_2escalars_2eselfLast(v_f_248, NTAG(TAG_Nil), heff_dup(v_b_245)));
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2410));
      V v_t_2414 = heff_rec_n(4, shape_key__body__last__args, (V[]){v_f_248, v_b_245, heff_intEq(v_t_2412, v_t_2413), v_args_2410});
      return (g_heff_2ecompile_2eunbox_2eslotsIn(v_xs_244, v_t_2414));
    } else {
      heff_drop_rec(v_d_240, 3);
      heff_drop(v_xs_244);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24t_241_24ELam, 2);
      heff_drop(v_t_247);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_t_241, 0ULL, 4);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotsOf(a[0]);
}
V g_heff_2ecompile_2eunbox_2eslotsOf_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_246; V a_1 = v_b_245; V r_ = (g_heff_2ecompile_2eunbox_2esomeApart(a_0, a_1)); heff_drop(v_x_246); heff_drop(v_b_245); r_; });
}
Clo g_heff_2ecompile_2eunbox_2espread_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2espread_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2espread(V v_go_240, V v_s_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EGlobal: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELam: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EApp: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELet: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ERecord: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EProj: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ETag: {
    V v_argv_2419 = heff_field(v_e_242, 1);
    heff_drop_rec(v_s_241, 5);
    return (g_list_2emap(v_go_240, heff_dup(v_argv_2419)));
  }
  case TAG_EMatch: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrim: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrimCall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ECall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EInt: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EStr: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EBytes: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFixed: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat32: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EAbandon: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFix: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eunbox_2espread_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eunbox_2espread(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eunbox_2eargsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eargsRw_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2eargsRw(V v_go_240, V v_ss_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_ss_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_argv_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_246 = (g_list_2efind_24s1351953222x1439135591_24cpr(heff_dup(v_i_242), heff_dup(v_ss_241)));
    V v_t_2412;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_s_2410 = v_field_248;
        v_t_2412 = ({ V a_0 = heff_dup(v_go_240); V a_1 = v_s_2410; V a_2 = v_a_244; V r_ = (g_heff_2ecompile_2eunbox_2espread(a_0, a_1, a_2)); heff_drop(v_a_244); r_; });
      } else {
        heff_drop(v_field_248);
        V v_t_2411 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_244}));
        v_t_2412 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      }
    }
    V v_t_2413 = (g_heff_2ecompile_2eunbox_2eargsRw(v_go_240, v_ss_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_argv_245));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eunbox_2eargsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eargsRw(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam1(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam2(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam3(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ematchRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ematchRw_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ematchRw(V v_go_240, V v_s_241, V v_arms_242, V v_m_243) {
top: ;
  switch (heff_tag_of(v_arms_242)) {
  case TAG_Nil: {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
    V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam0, 1, 1, (V[]){v_go_240}), v_arms_242));
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_244, v_t_2419});
  }
  case TAG_Cons: {
    V v_arms1_2420 = heff_dup(heff_field(v_arms_242, 0));
    V v_arms2_2421 = heff_dup(heff_field(v_arms_242, 1));
    switch (heff_tag_of(v_arms1_2420)) {
    case TAG_MkArm: {
      V v_t_2422 = heff_field(v_arms1_2420, 0);
      V v_vs_2423 = heff_field(v_arms1_2420, 1);
      V v_b_2424 = heff_field(v_arms1_2420, 2);
      V v_ru_24arms1_2420_24MkArm = heff_take_reuse_n(v_arms1_2420, 7ULL, 3);
      switch (heff_tag_of(v_arms2_2421)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_m_243)) {
        case TAG_Nothing: {
          heff_drop(v_t_2422);
          heff_drop(v_vs_2423);
          heff_drop(v_b_2424);
          heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
          V v_t_2425 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
          V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam1, 1, 1, (V[]){v_go_240}), v_arms_242));
          return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2425, v_t_2440});
        }
        case TAG_Just: {
          V v_sl_2441 = heff_field(v_m_243, 0);
          heff_drop_tag(v_arms_242, 2);
          if (heff_strEq_c(heff_dup(v_t_2422), heff_dup(heff_rfield(v_sl_2441, 2)))) {
            heff_drop(v_s_241);
            heff_drop(v_t_2422);
            heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
            V v_ps_2443 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_2423, heff_dup(heff_rfield(v_sl_2441, 4))));
            V v_m_2444 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2443; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2443); r_; });
            V v_t_2445 = (g_std_2emap_2esize(v_m_2444));
            V v_t_2447;
            if (heff_intEq_c(v_t_2445, MK_INT(0LL))) {
              heff_drop(v_m_2444);
              v_t_2447 = v_b_2424;
            } else {
              v_t_2447 = ({ V a_0 = v_m_2444; V a_1 = v_b_2424; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2444); r_; });
            }
            return heff_tail(v_go_240, 1, (V[]){v_t_2447});
          } else {
            V v_t_2448 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
            V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_2420_24MkArm, TAG_MkArm, 3, (V[]){v_t_2422, v_vs_2423, v_b_2424}), NTAG(TAG_Nil)});
            V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam2, 1, 1, (V[]){v_go_240}), v_t_2449));
            return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2448, v_t_2464});
          }
        }
        default: return heff_nomatch(v_m_243);
        }
      }
      case TAG_Cons: {
        V v_ru_24arms2_2421_24Cons = heff_take_reuse_n(v_arms2_2421, 0ULL, 2);
        heff_drop(v_t_2422);
        heff_drop(v_vs_2423);
        heff_drop(v_b_2424);
        heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
        V v_t_2467 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
        V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam3, 1, 1, (V[]){v_go_240}), v_arms_242));
        return heff_tag_at_n(v_ru_24arms2_2421_24Cons, TAG_EMatch, 2, (V[]){v_t_2467, v_t_2482});
      }
      default: return heff_nomatch(v_arms2_2421);
      }
    }
    default: return heff_nomatch(v_arms1_2420);
    }
  }
  default: return heff_nomatch(v_arms_242);
  }
}
V g_heff_2ecompile_2eunbox_2ematchRw_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2ematchRw(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_t_246 = heff_dup(heff_field(v_a_245, 0));
    v_t_249 = v_t_246;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2413;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_vs_2411 = heff_dup(heff_field(v_a_245, 1));
    v_t_2413 = v_vs_2411;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2417;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_b_2416 = heff_field(v_a_245, 2);
    heff_take_n(v_a_245, 4ULL, 3);
    v_t_2417 = v_b_2416;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2418 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2417}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_t_2418});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam1(V self, V *args) {
  V v_a_2426 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_t_2427 = heff_dup(heff_field(v_a_2426, 0));
    v_t_2430 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2434;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_vs_2432 = heff_dup(heff_field(v_a_2426, 1));
    v_t_2434 = v_vs_2432;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2438;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_b_2437 = heff_field(v_a_2426, 2);
    heff_take_n(v_a_2426, 4ULL, 3);
    v_t_2438 = v_b_2437;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2439 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2438}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2430, v_t_2434, v_t_2439});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam2(V self, V *args) {
  V v_a_2450 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_t_2451 = heff_dup(heff_field(v_a_2450, 0));
    v_t_2454 = v_t_2451;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2458;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_vs_2456 = heff_dup(heff_field(v_a_2450, 1));
    v_t_2458 = v_vs_2456;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2462;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_b_2461 = heff_field(v_a_2450, 2);
    heff_take_n(v_a_2450, 4ULL, 3);
    v_t_2462 = v_b_2461;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2463 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2462}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2454, v_t_2458, v_t_2463});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam3(V self, V *args) {
  V v_a_2468 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_t_2469 = heff_dup(heff_field(v_a_2468, 0));
    v_t_2472 = v_t_2469;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2476;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_vs_2474 = heff_dup(heff_field(v_a_2468, 1));
    v_t_2476 = v_vs_2474;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2480;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_b_2479 = heff_field(v_a_2468, 2);
    heff_take_n(v_a_2468, 4ULL, 3);
    v_t_2480 = v_b_2479;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2481 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2480}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2472, v_t_2476, v_t_2481});
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2erw_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2erw_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2erw_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2erw(V v_lp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_list_2efind_24s945009177x1839852169_24cpr(v_x_242, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24EVar, 1);
        V v_s_247 = v_field_245;
        V v_t_248 = (g_list_2emap_24s1809017761x1063871171(heff_take_field(v_s_247, 4)));
        return heff_tag_n(TAG_ETag, 3, (V[]){heff_dup(heff_rfield(v_s_247, 2)), v_t_248, heff_get_n(v_s_247, 3, 5)});
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_x2_241, 0);
    V v_b_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2eunbox_2erw_24dps(v_lp_240, v_b_2411, heff_dup(v_cell_2412), MK_INT(1LL)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_241, 0);
    V v_argv_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2416 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_f_2414));
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2418 = (g_list_2emap(v_t_2417, v_argv_2415));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2416, v_t_2418});
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2422 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_2420));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_t_2422, heff_hole()});
    V v_u_2424 = (g_heff_2ecompile_2eunbox_2erw_24dps(v_lp_240, v_b_2421, heff_dup(v_cell_2423), MK_INT(2LL)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_x2_241, 0);
    V v_ts_2426 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2erw_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2425));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2435, v_ts_2426});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_241, 0);
    V v_l_2437 = heff_field(v_x2_241, 1);
    V v_sh_2438 = heff_field(v_x2_241, 2);
    V v_t_2439 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2440 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_e_2436));
    return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2440, v_l_2437, v_sh_2438, v_t_2439});
  }
  case TAG_ETag: {
    V v_t_2441 = heff_field(v_x2_241, 0);
    V v_argv_2442 = heff_field(v_x2_241, 1);
    V v_ts_2443 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2445 = (g_list_2emap(v_t_2444, v_argv_2442));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2441, v_t_2445, v_ts_2443});
  }
  case TAG_EMatch: {
    V v_s_2446 = heff_field(v_x2_241, 0);
    V v_arms_2447 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_t_2483;
    switch (heff_tag_of(v_s_2446)) {
    case TAG_EVar: {
      V v_x_2449 = heff_dup(heff_field(v_s_2446, 0));
      v_t_2483 = ({ V a_0 = v_x_2449; V a_1 = heff_get_n(v_lp_240, 1, 2); V r_ = (g_list_2efind_24s945009177x1839852169(a_0, a_1)); heff_drop(v_x_2449); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_2446);
    }
    return ({ V a_0 = v_t_2448; V a_1 = v_s_2446; V a_2 = v_arms_2447; V a_3 = v_t_2483; V r_ = (g_heff_2ecompile_2eunbox_2ematchRw(a_0, a_1, a_2, a_3)); heff_drop(v_t_2483); r_; });
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_x2_241, 0);
    V v_argv_2486 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2488 = (g_list_2emap(v_t_2487, v_argv_2486));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2485, v_t_2488});
  }
  case TAG_ECall: {
    V v_g_2489 = heff_field(v_x2_241, 0);
    V v_argv_2490 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2489), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_2492 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_2493 = (g_heff_2ecompile_2eunbox_2eargsRw(v_t_2492, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_argv_2490));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2489, ((V)&g_heff_2ecompile_2eunbox_2erw_str0)), v_t_2493});
    } else {
      V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_2495 = (g_list_2emap(v_t_2494, v_argv_2490));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_2489, v_t_2495});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2erw_lam0(V self, V *args) {
  V v_p_2427 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_p_2427, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_t_2433;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_p_2427, 1);
    heff_take_n(v_p_2427, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_t_2434 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_t_2433));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_t_2434});
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2erw_24dps_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2erw_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2erw_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2erw_24dps_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2erw_24dps(V v_lp_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_list_2efind_24s945009177x1839852169_24cpr(v_x_244, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_s_249 = v_field_247;
        V v_t_2410 = (g_list_2emap_24s1809017761x1063871171(heff_take_field(v_s_249, 4)));
        V v_t_2411 = heff_tag_n(TAG_ETag, 3, (V[]){heff_take_field(v_s_249, 2), v_t_2410, heff_get_n(v_s_249, 3, 5)});
        return heff_setField(v_d_242, v_i_243, v_t_2411);
      } else {
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2413, heff_hole()});
    V v_u_2416 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lp_240;
    V t_1 = v_b_2414;
    V t_2 = v_cell_2415;
    V t_3 = MK_INT(1LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2417 = heff_field(v_x2_241, 0);
    V v_argv_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2419 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_f_2417));
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2421 = (g_list_2emap(v_t_2420, v_argv_2418));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2419, v_t_2421}));
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2425 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_2423));
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2422, v_t_2425, heff_hole()});
    V v_u_2427 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_lp_240;
    V t_1 = v_b_2424;
    V t_2 = v_cell_2426;
    V t_3 = MK_INT(2LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2erw_24dps_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2428));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2438, v_ts_2429}));
  }
  case TAG_EProj: {
    V v_e_2439 = heff_field(v_x2_241, 0);
    V v_l_2440 = heff_field(v_x2_241, 1);
    V v_sh_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2443 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_e_2439));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2443, v_l_2440, v_sh_2441, v_t_2442}));
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_argv_2445 = heff_field(v_x2_241, 1);
    V v_ts_2446 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2448 = (g_list_2emap(v_t_2447, v_argv_2445));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2444, v_t_2448, v_ts_2446}));
  }
  case TAG_EMatch: {
    V v_s_2449 = heff_field(v_x2_241, 0);
    V v_arms_2450 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_t_2486;
    switch (heff_tag_of(v_s_2449)) {
    case TAG_EVar: {
      V v_x_2452 = heff_dup(heff_field(v_s_2449, 0));
      v_t_2486 = ({ V a_0 = v_x_2452; V a_1 = heff_get_n(v_lp_240, 1, 2); V r_ = (g_list_2efind_24s945009177x1839852169(a_0, a_1)); heff_drop(v_x_2452); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_2449);
    }
    V v_t_2487 = ({ V a_0 = v_t_2451; V a_1 = v_s_2449; V a_2 = v_arms_2450; V a_3 = v_t_2486; V r_ = heff_tr(g_heff_2ecompile_2eunbox_2ematchRw(a_0, a_1, a_2, a_3)); heff_drop(v_t_2486); r_; });
    return heff_setField(v_d_242, v_i_243, v_t_2487);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2489 = heff_field(v_x2_241, 0);
    V v_argv_2490 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2491 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2492 = (g_list_2emap(v_t_2491, v_argv_2490));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2489, v_t_2492}));
  }
  case TAG_ECall: {
    V v_g_2493 = heff_field(v_x2_241, 0);
    V v_argv_2494 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2493), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_2497 = (g_heff_2ecompile_2eunbox_2eargsRw(v_t_2496, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_argv_2494));
      V v_t_2498 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2493, ((V)&g_heff_2ecompile_2eunbox_2erw_24dps_str0)), v_t_2497});
      return heff_setField(v_d_242, v_i_243, v_t_2498);
    } else {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_24100 = (g_list_2emap(v_t_2499, v_argv_2494));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2493, v_t_24100}));
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2erw_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2erw_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2erw_24dps_lam0(V self, V *args) {
  V v_p_2430 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_dup(heff_field(v_p_2430, 0));
    v_t_2433 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2436;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2430, 1);
    heff_take_n(v_p_2430, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2437 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_t_2436));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_t_2437});
}
Clo g_heff_2ecompile_2eunbox_2eparamsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eparamsRw_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2eparamsRw(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1351953222x1439135591_24cpr(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_249 = v_field_247;
        v_t_2410 = heff_get_n(v_s_249, 4, 5);
      } else {
        heff_drop(v_field_247);
        v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    V v_t_2411 = (g_heff_2ecompile_2eunbox_2eparamsRw(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2eparamsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eparamsRw(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eunbox_2ewrapArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewrapArgs_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ewrapArgs(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1351953222x1439135591_24cpr(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_y_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_249 = v_field_247;
        v_t_2410 = (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_249, 4, 5)));
      } else {
        heff_drop(v_field_247);
        v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), NTAG(TAG_Nil)});
      }
    }
    V v_t_2411 = (g_heff_2ecompile_2eunbox_2ewrapArgs(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ys_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2ewrapArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ewrapArgs(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2ewrapBody_str0, 0, "");
V g_heff_2ecompile_2eunbox_2ewrapBody_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ewrapBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewrapBody_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ewrapBody(V v_ys_240, V v_ss_241, V v_call_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eunbox_2ewrapBody_lam0, 2, 1, (V[]){heff_dup(v_ys_240)}); V a_1 = v_call_242; V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2eunbox_2ewrapBody_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ewrapBody(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eunbox_2ewrapBody_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_ys_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_246 = ({ V a_0 = heff_take_field(v_x_245, 0); V a_1 = v_ys_240; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ys_240); r_; });
  V v_t_2413;
  {
    V v_field_248 = v_t_246.f[1];
    V v_field_249 = v_t_246.f[2];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_248;
      V v_x12_2412 = v_field_249;
      heff_drop(v_x12_2412);
      v_t_2413 = v_x_2411;
    } else {
      heff_drop(v_field_248);
      heff_drop(v_field_249);
      v_t_2413 = ((V)&g_heff_2ecompile_2eunbox_2ewrapBody_str0);
    }
  }
  V v_t_2414 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_take_field(v_x_245, 2), heff_get_n(v_x_245, 4, 5), v_acc_244});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), v_t_2415});
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ewithVars_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ewithVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewithVars_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2ewithVars(V v_s_240) {
top: ;
  V v_t_242 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ewithVars_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), heff_dup(heff_rfield(v_s_240, 3))));
  return heff_clo_n(g_heff_2ecompile_2eunbox_2ewithVars_lam1, 1, 2, (V[]){v_t_242, v_s_240});
}
V g_heff_2ecompile_2eunbox_2ewithVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ewithVars(a[0]);
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam0(V self, V *args) {
  V v_x_241 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_241);
  return (g_heff_2ecompile_2eir_2ebaseGo(heff_get_n(v_s_240, 1, 5), MK_INT(0LL)));
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam1(V self, V *args) {
  V v_n_243 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_s_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_244 = (g_prelude_2etraverse_24s1512790070x1159539918_24cpr(v_t_242, v_n_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    V v_n_248 = v_field_246;
    V v_t_249 = ({ V rv_4 = v_x_247; V rr_ = heff_rec_reuse_nf(v_s_240, 15ULL, 5, shape_at__param__tag__tys__vars, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_n_248});
  }
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str1, 6, "$unbox");
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str2, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2eloopDefs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eloopDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eloopDefs_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2eloopDefs(V v_d_240, V v_xs_241, V v_b_242, V v_ss0_243) {
top: ;
  V v_m_244 = (g_prelude_2etraverse_24s350379375x322835164(heff_dup(v_ss0_243)));
  return heff_clo_n(g_heff_2ecompile_2eunbox_2eloopDefs_lam0, 1, 5, (V[]){v_m_244, v_ss0_243, v_xs_241, v_d_240, v_b_242});
}
V g_heff_2ecompile_2eunbox_2eloopDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eloopDefs(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2eloopDefs_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_ss0_243 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_d_240 = heff_env(self)[3];
  V v_b_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s350379375x322835164(v_ss0_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_m_2413 = (g_prelude_2etraverse_24s1435890225x1582751312(MK_INT(0LL), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str0), MK_INT(1LL), heff_dup(v_xs_241)));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        V v_t_2417 = (g_heff_2ecompile_2eunbox_2eparamsRw(heff_dup(v_x_247), MK_INT(0LL), v_xs_241));
        V v_t_2418 = heff_rec_n(2, shape_key__slots, (V[]){heff_dup(heff_rfield(v_d_240, 0)), v_x_247});
        V v_t_2419 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_t_2418, v_b_242));
        V v_body_2420 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_ELam, 2, (V[]){v_t_2417, v_t_2419});
        V v_t_2421 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str1));
        V v_t_2422 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2421, heff_dup(heff_rfield(v_d_240, 1)), v_body_2420});
        V v_t_2423 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str2));
        V v_t_2424 = (g_heff_2ecompile_2eunbox_2ewrapArgs(heff_dup(v_x_2411), MK_INT(0LL), heff_dup(v_x_2415)));
        V v_t_2425 = (g_heff_2ecompile_2eunbox_2ewrapBody(v_x_2415, v_x_2411, heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_ECall, 2, (V[]){v_t_2423, v_t_2424})));
        V v_body_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2415, v_t_2425});
        V v_t_2427 = ({ V rv_2 = v_body_2426; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428});
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_n_2416});
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eunbox_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam6(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam7(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam8(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam9(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam10(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam11(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam12(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam13(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam14(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam15(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam16(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam17(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam18(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam19(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2edefWith_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2edefWith(V v_d_240, V v_ss_241) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam0, 1, 1, (V[]){v_d_240});
  }
  case TAG_Cons: {
    V v_t_246 = heff_dup(heff_rfield(v_d_240, 2));
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam1, 1, 1, (V[]){v_d_240});
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam2, 1, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      V v_xs_2413 = heff_field(v_t_246, 0);
      V v_b_2414 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      return (g_heff_2ecompile_2eunbox_2eloopDefs(v_d_240, v_xs_2413, v_b_2414, v_ss_241));
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam3, 1, 1, (V[]){v_d_240});
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam4, 1, 1, (V[]){v_d_240});
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam5, 1, 1, (V[]){v_d_240});
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam6, 1, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam7, 1, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam8, 1, 1, (V[]){v_d_240});
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam9, 1, 1, (V[]){v_d_240});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam10, 1, 1, (V[]){v_d_240});
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam11, 1, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam12, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam13, 1, 1, (V[]){v_d_240});
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam14, 1, 1, (V[]){v_d_240});
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam15, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam16, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam17, 1, 1, (V[]){v_d_240});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam18, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam19, 1, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_ss_241);
  }
}
V g_heff_2ecompile_2eunbox_2edefWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2edefWith(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2edefWith_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_n_248});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_n_2411});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_n_2417});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam4(V self, V *args) {
  V v_n_2422 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_n_2422});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_n_2426});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam6(V self, V *args) {
  V v_n_2432 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_n_2432});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam7(V self, V *args) {
  V v_n_2437 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_n_2437});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam8(V self, V *args) {
  V v_n_2441 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_n_2441});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam9(V self, V *args) {
  V v_n_2444 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam10(V self, V *args) {
  V v_n_2448 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_n_2448});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam11(V self, V *args) {
  V v_n_2452 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_n_2452});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam12(V self, V *args) {
  V v_n_2455 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam13(V self, V *args) {
  V v_n_2458 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_n_2458});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam14(V self, V *args) {
  V v_n_2461 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_n_2461});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam15(V self, V *args) {
  V v_n_2464 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_n_2464});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam16(V self, V *args) {
  V v_n_2468 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_n_2468});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam17(V self, V *args) {
  V v_n_2471 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2472, v_n_2471});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam18(V self, V *args) {
  V v_n_2473 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2474, v_n_2473});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam19(V self, V *args) {
  V v_n_2477 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_n_2477});
}
Clo g_heff_2ecompile_2eunbox_2eisBuilt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eisBuilt_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eisBuilt(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_241, 0);
    V v_fs_2418 = heff_field(v_e_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(v_t_2417), heff_dup(heff_rfield(v_s_240, 2))) && ({ V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2418)); int c_ = ({ V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_240, 3))); int c_ = heff_intEq_c_lent(v_t_2421, v_t_2422, 0); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2421); c_; })));
    heff_drop_rec(v_s_240, 5);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2eisBuilt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2eisBuilt(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2ecallerCall_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2ecallerCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallerCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallerCall_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ecallerCall(V v_go_240, V v_g_241, V v_argv_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2emap(v_go_240, v_argv_242));
    return heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_t_244});
  }
  case TAG_Just: {
    V v_ss_245 = heff_field(v_x4_243, 0);
    V v_t_2415 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallerCall_lam0, 1, 1, (V[]){heff_dup(v_argv_242)}), v_ss_245));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V v_t_2416 = (g_heff_2ecompile_2eunbox_2eargsRw(v_go_240, heff_dup(v_ss_245), MK_INT(0LL), v_argv_242));
      return heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2eunbox_2ecallerCall_str0)), v_t_2416});
    } else {
      heff_drop(v_t_2415);
      V v_t_2417 = (g_list_2emap(v_go_240, v_argv_242));
      return heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_t_2417});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eunbox_2ecallerCall_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2ecallerCall(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2ecallerCall_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_247 = ({ V a_0 = heff_dup(heff_rfield(v_s_246, 0)); V a_1 = v_argv_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_242); r_; });
  V v_t_2414;
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_249;
      V v_x12_2413 = v_field_2410;
      heff_drop(v_x12_2413);
      v_t_2414 = v_x_2412;
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      v_t_2414 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_s_246; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2eunbox_2eisBuilt(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ecallersRw_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersRw_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallersRw(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eunbox_2ecallersRw_24dps(v_m_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x2_241, 0);
    V v_argv_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_f_248));
    V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2412 = (g_list_2emap(v_t_2411, v_argv_249));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, v_t_2412});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_x2_241, 0);
    V v_a_2414 = heff_field(v_x2_241, 1);
    V v_b_2415 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2414));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eunbox_2ecallersRw_24dps(v_m_240, v_b_2415, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_ERecord: {
    V v_fs_2419 = heff_field(v_x2_241, 0);
    V v_ts_2420 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_lam0, 1, 1, (V[]){v_m_240}), v_fs_2419));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2429, v_ts_2420});
  }
  case TAG_EProj: {
    V v_e_2430 = heff_field(v_x2_241, 0);
    V v_l_2431 = heff_field(v_x2_241, 1);
    V v_sh_2432 = heff_field(v_x2_241, 2);
    V v_t_2433 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2434 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_e_2430));
    return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2434, v_l_2431, v_sh_2432, v_t_2433});
  }
  case TAG_ETag: {
    V v_t_2435 = heff_field(v_x2_241, 0);
    V v_argv_2436 = heff_field(v_x2_241, 1);
    V v_ts_2437 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2439 = (g_list_2emap(v_t_2438, v_argv_2436));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2435, v_t_2439, v_ts_2437});
  }
  case TAG_EMatch: {
    V v_s_2440 = heff_field(v_x2_241, 0);
    V v_arms_2441 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2442 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_s_2440));
    V v_go_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_lam1, 1, 1, (V[]){v_go_2443}), v_arms_2441));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2442, v_t_2458});
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_x2_241, 0);
    V v_argv_2461 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2463 = (g_list_2emap(v_t_2462, v_argv_2461));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2460, v_t_2463});
  }
  case TAG_ECall: {
    V v_g_2464 = heff_field(v_x2_241, 0);
    V v_argv_2465 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){heff_dup(v_m_240)}));
    V v_t_2467 = ({ V a_0 = v_m_240; V a_1 = v_g_2464; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_m_240); r_; });
    return ({ V a_0 = v_t_2466; V a_1 = v_g_2464; V a_2 = v_argv_2465; V a_3 = v_t_2467; V r_ = (g_heff_2ecompile_2eunbox_2ecallerCall(a_0, a_1, a_2, a_3)); heff_drop(v_t_2467); r_; });
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersRw(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam0(V self, V *args) {
  V v_p_2421 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_p_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_p_2421, 1);
    heff_take_n(v_p_2421, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2428 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_t_2427));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2428});
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam1(V self, V *args) {
  V v_a_2444 = args[0];
  V v_go_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_dup(heff_field(v_a_2444, 0));
    v_t_2448 = v_t_2445;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2452;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_vs_2450 = heff_dup(heff_field(v_a_2444, 1));
    v_t_2452 = v_vs_2450;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2456;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_b_2455 = heff_field(v_a_2444, 2);
    heff_take_n(v_a_2444, 4ULL, 3);
    v_t_2456 = v_b_2455;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2457 = heff_tr(heff_call(v_go_2443, 1, (V[]){v_t_2456}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2448, v_t_2452, v_t_2457});
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersRw_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ecallersRw_24dps(V v_m_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_m_240;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_m_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_x2_241, 0);
    V v_argv_2411 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_f_2410));
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2414 = (g_list_2emap(v_t_2413, v_argv_2411));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2412, v_t_2414}));
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_x2_241, 0);
    V v_a_2416 = heff_field(v_x2_241, 1);
    V v_b_2417 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_m_240;
    V t_1 = v_b_2417;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_x2_241, 0);
    V v_ts_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0, 1, 1, (V[]){v_m_240}), v_fs_2421));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2422}));
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x2_241, 0);
    V v_l_2433 = heff_field(v_x2_241, 1);
    V v_sh_2434 = heff_field(v_x2_241, 2);
    V v_t_2435 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_e_2432));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435}));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x2_241, 0);
    V v_argv_2438 = heff_field(v_x2_241, 1);
    V v_ts_2439 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2441 = (g_list_2emap(v_t_2440, v_argv_2438));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439}));
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x2_241, 0);
    V v_arms_2443 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_s_2442));
    V v_go_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2460 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1, 1, 1, (V[]){v_go_2445}), v_arms_2443));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2444, v_t_2460}));
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_x2_241, 0);
    V v_argv_2463 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2465 = (g_list_2emap(v_t_2464, v_argv_2463));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2462, v_t_2465}));
  }
  case TAG_ECall: {
    V v_g_2466 = heff_field(v_x2_241, 0);
    V v_argv_2467 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){heff_dup(v_m_240)}));
    V v_t_2469 = ({ V a_0 = v_m_240; V a_1 = v_g_2466; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_2470 = ({ V a_0 = v_t_2468; V a_1 = v_g_2466; V a_2 = v_argv_2467; V a_3 = v_t_2469; V r_ = (g_heff_2ecompile_2eunbox_2ecallerCall(a_0, a_1, a_2, a_3)); heff_drop(v_t_2469); r_; });
    return heff_setField(v_d_242, v_i_243, v_t_2470);
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersRw_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2430 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_t_2429));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2430});
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1(V self, V *args) {
  V v_a_2446 = args[0];
  V v_go_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_dup(heff_field(v_a_2446, 0));
    v_t_2450 = v_t_2447;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2454;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_vs_2452 = heff_dup(heff_field(v_a_2446, 1));
    v_t_2454 = v_vs_2452;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2458;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_a_2446, 2);
    heff_take_n(v_a_2446, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2459 = heff_tr(heff_call(v_go_2445, 1, (V[]){v_t_2458}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2450, v_t_2454, v_t_2459});
}
Clo g_heff_2ecompile_2eunbox_2ecallsLoopW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallsLoopW_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallsLoopW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_argv_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2423, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2425;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2426, v_t_2428});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2431, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2432;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2433 = heff_field(v_x21_242, 0);
      V v_argv_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      HeffT2 v_t_2435 = ({ V a_0 = v_m_240; V a_1 = v_g_2433; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_g_2433); r_; });
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          heff_drop(v_rest_243);
          heff_drop(v_argv_2434);
          V v_x_2439 = v_field_2437;
          heff_drop(v_x_2439);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_field_2437);
          V v_t_2440 = (g_heff_2ecompile_2eir_2eappendI(v_argv_2434, v_rest_243));
          V t_0 = v_m_240;
          V t_1 = v_t_2440;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallsLoopW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ecallsLoopW(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eunbox_2ecallersIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersIn_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallersIn(V v_m_240, V v_ds_241) {
top: ;
  V v_t_242 = (g_std_2emap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, MK_INT(0LL))) {
    heff_drop(v_m_240);
    return v_ds_241;
  } else {
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersIn_lam0, 1, 1, (V[]){v_m_240}), v_ds_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersIn(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2ecallersIn_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_244, 2)), NTAG(TAG_Nil)});
  V v_t_246 = (g_heff_2ecompile_2eunbox_2ecallsLoopW(v_m_240, v_t_245));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_body_247 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, heff_take_field(v_d_244, 2)));
    return ({ V rv_2 = v_body_247; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    heff_drop(v_m_240);
    heff_drop(v_t_246);
    return v_d_244;
  }
}