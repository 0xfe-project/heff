// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_HE 9070
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_ems 310085
#define LBL_facts 298546081
#define LBL_fixed 298804110
#define LBL_flat 9641024
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_result 1012715336
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_tuples 1084651734
#define LBL_workers 1757018875
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2easLent(V, V);
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2easLent_clo;
V g_heff_2ecompile_2eemitc_2ecByte(V, V, V);
V g_heff_2ecompile_2eemitc_2ecByte_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecByte_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2edefOwn(V, V);
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefOwn_clo;
V g_heff_2ecompile_2eemitc_2edefsKept(V, V, V);
V g_heff_2ecompile_2eemitc_2edefsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefsKept_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemitVer(V, V, V);
V g_heff_2ecompile_2eemitc_2eemitVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitVer_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2efixedConst(V, V);
V g_heff_2ecompile_2eemitc_2efixedConst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedConst_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efixedU(V, V);
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedU_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
V g_heff_2ecompile_2eemitc_2efunDecl(V, V, V);
V g_heff_2ecompile_2eemitc_2efunDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDecl_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2egivenMask(V, V, V);
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivenMask_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2elentOperand(V, V);
V g_heff_2ecompile_2eemitc_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentOperand_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartCount(V, V);
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartCount_clo;
V g_heff_2ecompile_2eemitc_2eprojShapesW(V, V);
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo;
V g_heff_2ecompile_2eemitc_2erelSymbol(V, V);
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo;
V g_heff_2ecompile_2eemitc_2erelU(V, V);
V g_heff_2ecompile_2eemitc_2erelU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelU_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2etagH(V, V, V);
V g_heff_2ecompile_2eemitc_2etagH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagH_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etupleDecl(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo;
V g_heff_2ecompile_2eemitc_2ewordSymbols_get(void);
V g_heff_2ecompile_2eemitc_2ewordU(V, V);
V g_heff_2ecompile_2eemitc_2ewordU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewordU_clo;
V g_heff_2ecompile_2eemitc_2eworkerDecl(V, V);
V g_heff_2ecompile_2eemitc_2eworkerDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eworkerDecl_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2ecDef(V, V, V);
V g_heff_2ecompile_2elower_2ecDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecDef_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldr(V, V, V);
V g_list_2efoldr_entry(V self, V *a);
extern Clo g_list_2efoldr_clo;
HeffT2 g_list_2elookupBy_24cpr(V, V, V);
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
HeffT2 g_map_2elookup_24s659669741x1036301430_24cpr(V, V);
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strEq_get(void);
Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashBelow_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ehashBelow(V v_t_240, V v_box_24m_241, V v_box_24i_242, V v_box_24a_243) {
  int64_t v_m_241 = heff_unbox_word(v_box_24m_241);
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  int64_t v_a_243 = heff_unbox_word(v_box_24a_243);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_t_240, 0)) <= v_i_242)) {
    heff_drop(v_t_240);
    return heff_box_word(v_a_243);
  } else {
    int64_t v_t_245 = ((v_a_243 * ((int64_t)31ULL)) + heff_unbox_word(heff_strByteAt_lent(v_t_240, heff_box_word(v_i_242), 2)));
    int64_t v_t_246 = ((v_t_245 + ((int64_t)1ULL)) % v_m_241);
    V t_0 = v_t_240;
    int64_t t_1 = v_m_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    int64_t t_3 = v_t_246;
    v_t_240 = t_0;
    v_m_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ehashBelow(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecByte_str0, 2, "\\\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecByte_str1, 2, "\\\\");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecByte_str2, 2, "\\\?");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecByte_str3, 1, "\\");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecByte_str4, 1, "\\");
Clo g_heff_2ecompile_2eemitc_2ecByte_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecByte_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecByte(V v_s_240, V v_i_241, V v_box_24b_242) {
  int64_t v_b_242 = heff_unbox_word(v_box_24b_242);
top: ;
  if ((v_b_242 == ((int64_t)34ULL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2ecompile_2eemitc_2ecByte_str0);
  } else {
    if ((v_b_242 == ((int64_t)92ULL))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2ecompile_2eemitc_2ecByte_str1);
    } else {
      if ((v_b_242 == ((int64_t)63ULL))) {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2ecompile_2eemitc_2ecByte_str2);
      } else {
        if ((((int64_t)32ULL) <= v_b_242)) {
          if ((v_b_242 < ((int64_t)127ULL))) {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
          } else {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            V v_t_248 = heff_intShow(heff_box_word((v_b_242 / ((int64_t)64ULL))));
            int64_t v_t_249 = ((v_b_242 / ((int64_t)8ULL)) % ((int64_t)8ULL));
            V v_t_2410 = heff_intShow(heff_box_word((v_b_242 % ((int64_t)8ULL))));
            V v_t_2411 = heff_strAppend(heff_intShow(heff_box_word(v_t_249)), v_t_2410);
            return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecByte_str3), heff_strAppend(v_t_248, v_t_2411));
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          V v_t_2412 = heff_intShow(heff_box_word(heff_word_div(v_b_242, ((int64_t)64ULL))));
          int64_t v_t_2413 = heff_word_mod(heff_word_div(v_b_242, ((int64_t)8ULL)), ((int64_t)8ULL));
          V v_t_2414 = heff_intShow(heff_box_word(heff_word_mod(v_b_242, ((int64_t)8ULL))));
          V v_t_2415 = heff_strAppend(heff_intShow(heff_box_word(v_t_2413)), v_t_2414);
          return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecByte_str4), heff_strAppend(v_t_2412, v_t_2415));
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2ecByte_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecByte(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str0, 3, "f32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str1, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str2, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str3, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str4, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str5, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str6, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str7, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str8, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str9, 1, "i");
Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedSuffix_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedSuffix(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    return heff_strAppend(v_t_242, heff_intShow(v_t_243));
  }
}
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedSuffix(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str0, 2, ")-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str1, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str2, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str3, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedConst_str5, 2, "((");
Clo g_heff_2ecompile_2eemitc_2efixedConst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedConst_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efixedConst(V v_w_240, V v_n_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_241), MK_INT(0LL))) {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_n_241));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedConst_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2efixedConst_str1)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedConst_str2), heff_strAppend(v_t_243, v_t_245));
  } else {
    V v_t_246 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_247 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedConst_str3));
    V v_t_248 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedConst_str4), v_t_247));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedConst_str5), v_t_248);
  }
}
V g_heff_2ecompile_2eemitc_2efixedConst_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedConst(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str21, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str22, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str24, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str26, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str27, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efixedU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedU_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efixedU(V v_fp_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_fp_240, 1));
  V v_t_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_OpAdd: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpSub: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpMul: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpDiv: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpRem: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpEq: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpLt: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpLe: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpAnd: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpOr: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpXor: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShl: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShr: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShow: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFromInt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpToInt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpSqrt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpToFloat: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFloor: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_246;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_vs_241, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_247 = heff_get_n(v_fp_240, 1, 2);
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_OpAdd: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str1);
      break;
    }
    case TAG_OpSub: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str2);
      break;
    }
    case TAG_OpMul: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str3);
      break;
    }
    case TAG_OpDiv: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str4);
      break;
    }
    case TAG_OpRem: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str5);
      break;
    }
    case TAG_OpEq: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str6);
      break;
    }
    case TAG_OpLt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str7);
      break;
    }
    case TAG_OpLe: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str8);
      break;
    }
    case TAG_OpAnd: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str9);
      break;
    }
    case TAG_OpOr: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str10);
      break;
    }
    case TAG_OpXor: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str11);
      break;
    }
    case TAG_OpShl: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str12);
      break;
    }
    case TAG_OpShr: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str13);
      break;
    }
    case TAG_OpShow: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str14);
      break;
    }
    case TAG_OpFromInt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str15);
      break;
    }
    case TAG_OpToInt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str16);
      break;
    }
    case TAG_OpSqrt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str17);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str18);
      break;
    }
    case TAG_OpToFloat: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str19);
      break;
    }
    case TAG_OpFloor: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str20);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    HeffT3 v_t_249 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2416;
    {
      V v_field_2411 = v_t_249.f[1];
      V v_field_2412 = v_t_249.f[2];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2411;
        V v_x12_2415 = v_field_2412;
        heff_drop(v_x12_2415);
        v_t_2416 = v_x_2414;
      } else {
        heff_drop(v_field_2411);
        heff_drop(v_field_2412);
        v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str21);
      }
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str22), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2efixedU_str23)));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str24), heff_strAppend(v_t_248, v_t_2417));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str25), heff_strAppend(v_t_246, v_t_2418));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str26), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2efixedU_str27)));
  } else {
    heff_drop(v_t_243);
    V v_t_2420 = heff_dup(heff_rfield(v_fp_240, 0));
    V v_t_2421;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_I8: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_I16: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_I32: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_I64: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U8: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      return ({ V b_0 = heff_get_n(v_fp_240, 1, 2); V a_1 = v_vs_241; V r_ = (g_heff_2ecompile_2eemitc_2efloat32U(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_t_2421);
      return ({ V b_0 = heff_dup(heff_rfield(v_fp_240, 0)); V b_1 = heff_get_n(v_fp_240, 1, 2); V a_2 = v_vs_241; V r_ = (g_heff_2ecompile_2eemitc_2eintU(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
    }
  }
}
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2efixedU(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str0, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str5, 13, "heff_word_div");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str6, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str11, 13, "heff_word_mod");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str12, 11, "wordToFloat");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str13, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str14, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str16, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str17, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str18, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str19, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str21, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str22, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str24, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str26, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str28, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str30, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str31, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str32, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str33, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordU_str34, 1, "(");
Clo g_heff_2ecompile_2eemitc_2ewordU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewordU_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ewordU(V v_p_240, V v_vs_241) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str0), 2)) {
    heff_drop(v_p_240);
    V v_t_245;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_vs_241, 0);
      V v_xs_244 = heff_field(v_vs_241, 1);
      v_t_245 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2ewordU_str2), heff_dup(v_x_243), v_xs_244));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str3), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str4)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str5), v_t_246);
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str6), 2)) {
      heff_drop(v_p_240);
      V v_t_2410;
      switch (heff_tag_of(v_vs_241)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_vs_241, 0);
        V v_xs_249 = heff_field(v_vs_241, 1);
        v_t_2410 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2ewordU_str8), heff_dup(v_x_248), v_xs_249));
        break;
      }
      default: heff_nomatch(v_vs_241);
      }
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str9), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str10)));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str11), v_t_2411);
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str12), 2)) {
        heff_drop(v_p_240);
        V v_t_2415;
        switch (heff_tag_of(v_vs_241)) {
        case TAG_Nil: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str13);
          break;
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_vs_241, 0);
          v_t_2415 = heff_dup(v_x_2413);
          break;
        }
        default: heff_nomatch(v_vs_241);
        }
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str14), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str15)));
      } else {
        V v_t_2418 = heff_bool((heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str16), 2) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str17), 2) || heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str18), 2))));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_t_2418);
          HeffT2 v_t_2419 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), v_p_240, heff_dup(g_heff_2ecompile_2eemitc_2ewordSymbols_get())));
          V v_t_2438;
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            V v_t_2424;
            switch (heff_tag_of(v_vs_241)) {
            case TAG_Nil: {
              v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str19);
              break;
            }
            case TAG_Cons: {
              V v_x_2422 = heff_field(v_vs_241, 0);
              v_t_2424 = heff_dup(v_x_2422);
              break;
            }
            default: heff_nomatch(v_vs_241);
            }
            V v_t_2427;
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2421;
              v_t_2427 = v_x_2426;
            } else {
              heff_drop(v_field_2421);
              v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str20);
            }
            HeffT3 v_t_2428 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
            V v_t_2435;
            {
              V v_field_2430 = v_t_2428.f[1];
              V v_field_2431 = v_t_2428.f[2];
              int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
              if ((v_tag_2429 == ((int64_t)0ULL))) {
                V v_x_2433 = v_field_2430;
                V v_x12_2434 = v_field_2431;
                heff_drop(v_x12_2434);
                v_t_2435 = v_x_2433;
              } else {
                heff_drop(v_field_2430);
                heff_drop(v_field_2431);
                v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str21);
              }
            }
            V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str22), heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str23)));
            V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str24), heff_strAppend(v_t_2427, v_t_2436));
            v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str25), heff_strAppend(v_t_2424, v_t_2437));
          }
          return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str26), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str27)));
        } else {
          heff_drop(v_t_2418);
          HeffT2 v_t_2439 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), v_p_240, heff_dup(g_heff_2ecompile_2eemitc_2ewordSymbols_get())));
          {
            V v_field_2441 = v_t_2439.f[1];
            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
            V v_t_2444;
            switch (heff_tag_of(v_vs_241)) {
            case TAG_Nil: {
              v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str28);
              break;
            }
            case TAG_Cons: {
              V v_x_2442 = heff_field(v_vs_241, 0);
              v_t_2444 = heff_dup(v_x_2442);
              break;
            }
            default: heff_nomatch(v_vs_241);
            }
            V v_t_2447;
            if ((v_tag_2440 == ((int64_t)0ULL))) {
              V v_x_2446 = v_field_2441;
              v_t_2447 = v_x_2446;
            } else {
              heff_drop(v_field_2441);
              v_t_2447 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str29);
            }
            HeffT3 v_t_2448 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
            V v_t_2455;
            {
              V v_field_2450 = v_t_2448.f[1];
              V v_field_2451 = v_t_2448.f[2];
              int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
              if ((v_tag_2449 == ((int64_t)0ULL))) {
                V v_x_2453 = v_field_2450;
                V v_x12_2454 = v_field_2451;
                heff_drop(v_x12_2454);
                v_t_2455 = v_x_2453;
              } else {
                heff_drop(v_field_2450);
                heff_drop(v_field_2451);
                v_t_2455 = ((V)&g_heff_2ecompile_2eemitc_2ewordU_str30);
              }
            }
            V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str31), heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eemitc_2ewordU_str32)));
            V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str33), heff_strAppend(v_t_2447, v_t_2456));
            return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordU_str34), heff_strAppend(v_t_2444, v_t_2457));
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2ewordU_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2ewordU(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str1, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str3, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str5, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str10, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str11, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str14, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelU_str15, 1, "(");
Clo g_heff_2ecompile_2eemitc_2erelU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erelU_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erelU(V v_p_240, V v_vs_241) {
top: ;
  V v_t_244 = heff_bool((heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2erelU_str0), 2) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2erelU_str1), 2) || heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2erelU_str2), 2))));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    HeffT2 v_t_245 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), v_p_240, heff_dup(g_heff_2ecompile_2eemitc_2ewordSymbols_get())));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2410;
      switch (heff_tag_of(v_vs_241)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2erelU_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_vs_241, 0);
        v_t_2410 = heff_dup(v_x_248);
        break;
      }
      default: heff_nomatch(v_vs_241);
      }
      V v_t_2413;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_247;
        v_t_2413 = v_x_2412;
      } else {
        heff_drop(v_field_247);
        v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2erelU_str4);
      }
      HeffT3 v_t_2414 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
      V v_t_2421;
      {
        V v_field_2416 = v_t_2414.f[1];
        V v_field_2417 = v_t_2414.f[2];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x_2419 = v_field_2416;
          V v_x12_2420 = v_field_2417;
          heff_drop(v_x12_2420);
          v_t_2421 = v_x_2419;
        } else {
          heff_drop(v_field_2416);
          heff_drop(v_field_2417);
          v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2erelU_str5);
        }
      }
      V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str6), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2erelU_str7)));
      V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str8), heff_strAppend(v_t_2413, v_t_2422));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str9), heff_strAppend(v_t_2410, v_t_2423));
    }
  } else {
    heff_drop(v_t_244);
    V v_t_2424 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_240)));
    V v_op_2425 = ({ V a_0 = v_p_240; V a_1 = v_t_2424; V r_ = (g_heff_2ecompile_2eemitc_2erelSymbol(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2428;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2erelU_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_vs_241, 0);
      v_t_2428 = heff_dup(v_x_2426);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    HeffT3 v_t_2429 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2436;
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2431;
        V v_x12_2435 = v_field_2432;
        heff_drop(v_x12_2435);
        v_t_2436 = v_x_2434;
      } else {
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2erelU_str11);
      }
    }
    V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str12), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2erelU_str13)));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str14), heff_strAppend(v_op_2425, v_t_2437));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erelU_str15), heff_strAppend(v_t_2428, v_t_2438));
  }
}
V g_heff_2ecompile_2eemitc_2erelU_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erelU(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str1, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str4, 14, "heff_drop_tag(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str7, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str9, 15, "heff_drop_cell(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str11, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str12, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str14, 14, "heff_drop_rec(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str16, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str17, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str19, 14, "heff_drop_clo(");
Clo g_heff_2ecompile_2eemitc_2edropAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edropAs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edropAs(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_KnownTag: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str0)));
    V v_t_244 = heff_strAppend(heff_intShow(heff_dup(v_n_242)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str1));
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str2), v_t_243), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str3), v_t_244));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str4), v_t_245);
  }
  case TAG_KnownCell: {
    V v_n_246 = heff_field(v_x2_241, 0);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str5)));
    V v_t_248 = heff_strAppend(heff_intShow(heff_dup(v_n_246)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str6));
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str7), v_t_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str8), v_t_248));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str9), v_t_249);
  }
  case TAG_KnownRec: {
    V v_n_2410 = heff_field(v_x2_241, 0);
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str10)));
    V v_t_2412 = heff_strAppend(heff_intShow(heff_dup(v_n_2410)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str11));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str12), v_t_2411), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str13), v_t_2412));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str14), v_t_2413);
  }
  case TAG_KnownClo: {
    V v_n_2414 = heff_field(v_x2_241, 0);
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str15)));
    V v_t_2416 = heff_strAppend(heff_intShow(heff_dup(v_n_2414)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str16));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str17), v_t_2415), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str18), v_t_2416));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str19), v_t_2417);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2edropAs(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2egivenMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2egivenMask_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2egivenMask(V v_es_240, V v_x2_241, V v_bit_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bit_242);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2elentOperand(v_es_240, v_e_243));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    } else {
      heff_drop(v_t_245);
      v_t_246 = heff_dup(v_bit_242);
    }
    V v_t_247 = (g_heff_2ecompile_2eemitc_2egivenMask(v_es_240, v_rest_244, heff_intMul(v_bit_242, MK_INT(2LL))));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2egivenMask(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2easLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2easLent_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2easLent(V v_es_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    return v_e_241;
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24RDup = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_244 = ({ V a_0 = v_es_240; V b_1 = heff_tag_at_n(v_ru_24e_241_24RDup, TAG_RDup, 1, (V[]){heff_dup(v_x_243)}); V r_ = (g_heff_2ecompile_2eemitc_2elentOperand(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_RLocal, 1, (V[]){v_x_243});
    } else {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_RDup, 1, (V[]){v_x_243});
    }
  }
  case TAG_RClo: {
    return v_e_241;
  }
  case TAG_RGet: {
    return v_e_241;
  }
  case TAG_RGetRaw: {
    return v_e_241;
  }
  case TAG_RInt: {
    return v_e_241;
  }
  case TAG_RFloat: {
    return v_e_241;
  }
  case TAG_RStr: {
    return v_e_241;
  }
  case TAG_RBytes: {
    return v_e_241;
  }
  case TAG_RFixed: {
    return v_e_241;
  }
  case TAG_RF32: {
    return v_e_241;
  }
  case TAG_RNTag: {
    return v_e_241;
  }
  case TAG_RTag: {
    return v_e_241;
  }
  case TAG_RTagIn: {
    return v_e_241;
  }
  case TAG_RRec: {
    return v_e_241;
  }
  case TAG_RRecIn: {
    return v_e_241;
  }
  case TAG_RField: {
    return v_e_241;
  }
  case TAG_RDupE: {
    return v_e_241;
  }
  case TAG_RFieldV: {
    return v_e_241;
  }
  case TAG_RGetN: {
    return v_e_241;
  }
  case TAG_RFieldU: {
    return v_e_241;
  }
  case TAG_RGetNU: {
    return v_e_241;
  }
  case TAG_RWord: {
    return v_e_241;
  }
  case TAG_RTakeField: {
    return v_e_241;
  }
  case TAG_RGetLabel: {
    return v_e_241;
  }
  case TAG_RPrimFn: {
    return v_e_241;
  }
  case TAG_RPrim: {
    return v_e_241;
  }
  case TAG_RLam: {
    return v_e_241;
  }
  case TAG_RCall: {
    return v_e_241;
  }
  case TAG_RApply: {
    return v_e_241;
  }
  case TAG_RBool: {
    return v_e_241;
  }
  case TAG_RAbandon: {
    return v_e_241;
  }
  case TAG_RBox: {
    return v_e_241;
  }
  case TAG_RUnbox: {
    return v_e_241;
  }
  case TAG_RPeek: {
    return v_e_241;
  }
  case TAG_RPrimU: {
    return v_e_241;
  }
  case TAG_RPrimAt: {
    return v_e_241;
  }
  case TAG_RFixU: {
    return v_e_241;
  }
  case TAG_RF32U: {
    return v_e_241;
  }
  case TAG_RF64U: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2easLent(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str2, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str8, 7, "static ");
Clo g_heff_2ecompile_2eemitc_2efunHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunHead_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2efunHead(V v_key_240, V v_xs_241, V v_rs_242, V v_ret_243, V v_w_244) {
top: ;
  V v_t_247;
  if ((heff_dup(v_w_244) == NTAG(TAG_True))) {
    V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str0)));
    v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str1), v_t_245), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str2));
  } else {
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str3)));
    v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str4), v_t_246);
  }
  V v_t_248 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_242, heff_dup(g_map_2eempty_get()), MK_INT(0LL)));
  V v_t_249 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_248, v_xs_241));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2efunHead_str6)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str7), heff_strAppend(v_t_247, v_t_2410));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str8), heff_strAppend(v_ret_243, v_t_2411));
}
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2efunHead(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2edefOwn_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edefOwn_str1, 2, "g_");
V g_heff_2ecompile_2eemitc_2edefOwn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2edefOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefOwn_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edefOwn(V v_ce_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edefOwn_str0)));
  V v_o_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edefOwn_str1), v_t_242);
  return heff_clo_n(g_heff_2ecompile_2eemitc_2edefOwn_lam0, 1, 3, (V[]){v_ce_240, v_d_241, v_o_243});
}
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edefOwn(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2edefOwn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_o_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 10);
  V v_t_246 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_d_241, 2))));
  V v_t_247 = ({ V a_0 = heff_get_n(v_ce_240, 2, 3); V a_1 = v_d_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2elower_2ecDef(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = ({ V rv_0 = v_o_243; V rv_1 = MK_INT(0LL); V rv_4 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_244, 236ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 64752u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; rr_; });
  return ({ V a_0 = v_t_245; V a_1 = v_t_247; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eemitc_2edefC(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str5, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str6, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str10, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eworkerDecl_str11, 1, " ");
Clo g_heff_2ecompile_2eemitc_2eworkerDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eworkerDecl_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eworkerDecl(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_sg_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_dup(heff_rfield(v_sg_242, 1));
    V v_t_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_245 = ({ V a_0 = v_w_244; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_244); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str1);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str2);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str3)));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str4), v_t_246), ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str5));
    V v_t_248 = heff_dup(heff_rfield(v_sg_242, 0));
    V v_t_2414;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str6);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_248, 0ULL, 2);
      V v_x2_2411 = (g_list_2emap_24s1386329375x1773300759(heff_dup(heff_rfield(v_sg_242, 0))));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_xs_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str8); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str9), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str10)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eworkerDecl_str11), heff_strAppend(v_t_247, v_t_2415));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, v_t_2416), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eworkerDecl_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eworkerDecl(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str2, 11, "_get(void);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str3, 2, "V ");
Clo g_heff_2ecompile_2eemitc_2edeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edeclOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edeclOf(V v_ce_240, V v_k_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 10);
  HeffT2 v_t_243 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_242; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_n_247 = v_field_245;
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 10);
      HeffT2 v_t_249 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_248; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_t_2414;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          v_t_2414 = v_x_2413;
        } else {
          heff_drop(v_field_2411);
          v_t_2414 = MK_INT(0LL);
        }
        if (heff_intLt_c(MK_INT(0LL), v_t_2414)) {
          V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 4, 10);
          V v_t_2417 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2416; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2416); r_; });
          V v_t_2418 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 8, 10);
          HeffT2 v_t_2419 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2418; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
          V v_t_2424;
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_x_2423 = v_field_2421;
              v_t_2424 = v_x_2423;
            } else {
              heff_drop(v_field_2421);
              v_t_2424 = MK_INT(0LL);
            }
          }
          return ({ V a_0 = v_k_241; V a_1 = v_n_247; V a_2 = v_t_2417; V a_3 = v_t_2424; V r_ = (g_heff_2ecompile_2eemitc_2etupleDecl(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
        } else {
          return (g_heff_2ecompile_2eemitc_2efunDecl(v_ce_240, v_k_241, v_n_247));
        }
      }
    } else {
      heff_drop_rec(v_ce_240, 3);
      heff_drop(v_field_245);
      V v_t_2425 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str0)));
      V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str1), v_t_2425), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str2));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str3), v_t_2426), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edeclOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2epartCount_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartCount_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2epartCount(V v_bytes_240, V v_box_24b_241) {
  int64_t v_b_241 = heff_unbox_word(v_box_24b_241);
top: ;
  if ((((int64_t)64ULL) <= v_b_241)) {
    heff_drop(v_bytes_240);
    return heff_box_word(v_b_241);
  } else {
    if (heff_intLe_c(heff_dup(v_bytes_240), heff_box_word((v_b_241 * ((int64_t)160000ULL))))) {
      heff_drop(v_bytes_240);
      return heff_box_word(v_b_241);
    } else {
      V t_0 = v_bytes_240;
      int64_t t_1 = (v_b_241 * ((int64_t)2ULL));
      v_bytes_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartCount(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str0, 1, "-");
V g_heff_2ecompile_2eemitc_2eemitVer_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eemitVer_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eemitVer_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eemitVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitVer_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eemitVer(V v_ce_240, V v_key_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eshapeH_clo), 1, (V[]){heff_dup(v_ce_240)}));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2ecompile_2eemitc_2eprojShapesW(NTAG(TAG_Nil), v_t_244));
  V v_m_246 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_245); r_; });
  V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_z_249 = (g_list_2efoldr(v_t_243, NTAG(TAG_Nil), v_t_248));
  V v_x1_2410 = (g_heff_2ecompile_2eemitc_2etagsLbls(heff_dup(v_b_242)));
  V v_t_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_m_2414 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2414); r_; });
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
  V v_t_2424 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_2416));
  V v_z_2427 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam1, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = v_z_249; V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  V v_t_2428 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
  V v_t_2429 = (g_heff_2ecompile_2eir_2enubI(v_t_2428));
  V v_xs_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_key_241), v_t_2429});
  V v_m_2431 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2430; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop_tag(v_xs_2430, 2); r_; });
  V v_t_2432 = ({ V a_0 = v_m_2431; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2431); r_; });
  V v_t_2433 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2432));
  V v_t_2436 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam2, 2, 1, (V[]){v_ce_240}); V a_1 = v_z_2427; V a_2 = v_t_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_242}), v_t_2436});
  V v_items_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_key_241}), v_t_2437});
  HeffT2 v_t_2439 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2438));
  {
    V v_field_2440 = v_t_2439.f[0];
    V v_field_2441 = v_t_2439.f[1];
    V v_a_2442 = v_field_2440;
    V v_b_2443 = v_field_2441;
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitVer_str0), heff_intShow(v_b_2443));
    return heff_strAppend(heff_intShow(v_a_2442), v_t_2444);
  }
}
V g_heff_2ecompile_2eemitc_2eemitVer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eemitVer(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam0(V self, V *args) {
  V v_t_2417 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 5, 10);
  HeffT2 v_t_2419 = ({ V a_0 = v_t_2417; V a_1 = v_t_2418; HeffT2 r_ = (g_map_2elookup_24s659669741x1036301430_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2420 == ((int64_t)0ULL)) && ({ V v_x_2423 = heff_dup(v_field_2421); int c_ = 1; heff_drop(v_x_2423); c_; })));
    heff_drop(v_field_2421);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam1(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemitc_2etagH(v_ce_240, v_x_2426, v_acc_2425));
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam2(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_x_2435 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemitc_2eglobalH(v_ce_240, v_x_2435, v_acc_2434));
}
V g_heff_2ecompile_2eemitc_2edefsKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2edefsKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefsKept_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2edefsKept(V v_ce_240, V v_kept_241, V v_defs_242) {
top: ;
  V v_t_243 = heff_rec_n(3, shape_ems__s__fresh, (V[]){NTAG(TAG_Nil), heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get()), NTAG(TAG_Nil)});
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemitc_2edefsKept_lam0, 2, 2, (V[]){v_ce_240, heff_dup(v_kept_241)}), v_t_243, v_defs_242);
}
V g_heff_2ecompile_2eemitc_2edefsKept_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2edefsKept(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2edefsKept_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_d_245 = args[1];
  V v_ce_240 = heff_env(self)[0];
  V v_kept_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_own_246 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_d_245, 2))));
  V v_t_249;
  switch (heff_tag_of(v_own_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_dup(heff_field(v_own_246, 0));
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_own_246);
  }
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2eemitVer(heff_dup(v_ce_240), heff_dup(heff_rfield(v_d_245, 0)), v_t_249));
  return ({ V a_0 = v_ce_240; V a_1 = v_kept_241; V a_2 = v_acc_244; V a_3 = v_d_245; V a_4 = v_own_246; V a_5 = v_t_2410; V r_ = (g_heff_2ecompile_2eemitc_2eemitAt(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_241); heff_drop(v_own_246); r_; });
}