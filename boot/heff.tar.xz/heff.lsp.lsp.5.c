// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Send 26077
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_sources 357464573
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_clo;
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_clo;
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981(V, V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(V, V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(V, V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f1037112923x126964824(V, V, V, V, V);
V g_list_2efoldl_24f1037112923x126964824_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1037112923x126964824_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2ewordEnd_str0, 12, " \011\015(){}[]:,=");
Clo g_heff_2elsp_2elsp_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewordEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewordEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_l_240, 0), heff_dup(v_i_241)) || ({ V v_t_242 = heff_strSlice(heff_dup(v_l_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ({ V v_t_243 = heff_strFind_lent(v_t_242, ((V)&g_heff_2elsp_2elsp_2ewordEnd_str0), MK_INT(0LL), 6); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_243, 1); heff_drop(v_t_243); c_; }); heff_drop(v_t_242); c_; }))) {
    return v_i_241;
  } else {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str7, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str9, 1, " ");
Clo g_heff_2elsp_2elsp_2ekeyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeyOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeyOf(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_242 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_get_n(v_t_241, 0, 2), heff_get_n(v_t_242, 1, 2));
  V v_t_244 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_245 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_244, 6);
  V v_t_247;
  if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str0), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str1), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str2), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str3), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str4), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str5), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str6), v_w_245, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str7), v_w_245, 1))))))))) {
    heff_drop(v_w_245);
    V v_t_246 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    v_t_247 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_246, 6);
  } else {
    heff_drop(v_w_245);
    v_t_247 = ((V)&g_heff_2elsp_2elsp_2ekeyOf_str8);
  }
  return heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2elsp_2elsp_2ekeyOf_str9)), v_t_247);
}
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ekeyOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s1441124185x871809048(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_local_243 = heff_take_field(v_target_242, 2);
  V v_member_244 = heff_get_n(v_target_242, 1, 3);
  switch (heff_tag_of(v_local_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_member_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength(v_t_246)) - heff_unbox_word(v_t_247));
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), heff_box_word(v_t_248)), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_member_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_member_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_local_243, 0);
    V v_ru_24local_243_24Just = heff_take_reuse_n(v_local_243, 1ULL, 1);
    heff_drop(v_member_244);
    V v_path_2413 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
    V v_t_2414 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2414));
    V v_t_2416 = (g_list_2efoldl_24f1037112923x126964824(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2417 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(heff_box_word(v_t_2415), v_t_2416));
    V v_t_2418 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2418));
    V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_t_240); V a_3 = heff_dup(v_b_2412); V b_4 = heff_get_n(v_t_240, 3, 4); V r_ = (g_list_2efoldl_24f1037112923x126964824(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    V v_t_2421 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(heff_box_word(v_t_2419), v_t_2420));
    V v_e_2422 = heff_intAdd(v_t_2421, heff_strLength(v_new_241));
    V v_t_2423 = heff_tag_at_n(v_ru_24local_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2417, v_e_2422})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_path_2413, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_local_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1836353438x580818415(heff_dup(v_c_243), v_changed_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
      V v_u_248 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_247, v_rest_244, heff_dup(v_cell_246)));
      heff_drop(v_u_248);
      return v_cell_246;
    } else {
      heff_drop(v_t_245);
      V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
        V v_u_2413 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2412, v_rest_244, heff_dup(v_cell_2411)));
        heff_drop(v_u_2413);
        return v_cell_2411;
      } else {
        heff_drop_rec(v_c_243, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2410);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_249; V a_1 = v_mods_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_d_249); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(V v_e_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(heff_dup(v_e_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_lam0, 1, 4, (V[]){v_e_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_e_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_str0, 0, "");
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam2, 3, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_entry, 4, 0};

V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(V v_e_240, V v_st_241, V v_names_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_st_241, 7);
    return ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_p_246));
    V v_c_2428;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2411 = v_field_2410;
        v_c_2428 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam1, 2, 1, (V[]){v_d_2411});
      } else {
        heff_drop(v_field_2410);
        V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_246)));
        V v_c_2416 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2415; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2415); r_; });
        V v_t_2417 = (g_exception_2eattempted(heff_dup(v_e_240)));
        V v_c_2421 = heff_tr(heff_call(v_c_2416, 2, (V[]){v_t_2417, ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam2_clo)}));
        v_c_2428 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam3, 2, 1, (V[]){v_c_2421});
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam5, 2, 6, (V[]){v_c_2428, v_e_240, v_st_241, heff_dup(v_names_242), v_rest_247, v_p_246});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2411, 1, 2)});
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2427 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2426 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    v_t_2427 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_Just, 1, (V[]){v_y_2426});
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V f_ = v_k_2423;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam4, 1, 1, (V[]){v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_names_242 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_k_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nothing: {
    v_t_2435 = ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    v_t_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V v_t_2436 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2435; V b_2 = MK_INT(0LL); V a_3 = v_names_242; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, a_1, b_2, a_3)); heff_drop(v_t_2435); heff_drop(b_2); heff_drop(v_names_242); r_; });
  V v_x_2437;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_x_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_246, v_x_2433});
  } else {
    heff_drop(v_p_246);
    heff_drop(v_t_2436);
    v_x_2437 = v_x_2433;
  }
  V f_ = v_k_2430;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_names_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2429 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_k_2430 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2432 = (g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(v_e_240, v_st_241, v_names_242, v_rest_247));
  V f_ = v_c_2432;
  heff_room[0] = v_hd_2429;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam7, 1, 4, (V[]){v_x_2431, v_names_242, v_p_246, v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_names_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_lam6, 1, 7, (V[]){v_e_240, v_st_241, v_names_242, v_rest_247, v_hd_2429, v_p_246, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_entry, 4, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(V v_e_240, V v_read_241, V v_lib_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_read_241);
    heff_drop(v_lib_242);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_dup(v_read_241), heff_dup(v_lib_242), heff_dup(v_f_246)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam1, 2, 5, (V[]){v_c_248, v_e_240, v_read_241, v_lib_242, heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2411, 0, 5), v_x_2413));
  V f_ = v_k_2410;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_read_241 = heff_env(self)[1];
  V v_lib_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2412 = ({ V a_0 = v_e_240; V a_1 = v_read_241; V a_2 = v_lib_242; V a_3 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam3, 1, 2, (V[]){v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_read_241 = heff_env(self)[2];
  V v_lib_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_lam2, 1, 6, (V[]){v_e_240, v_read_241, v_lib_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str21, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str24, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str39, 1, "}");
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam5, 3, 0};
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_entry, 4, 0};

V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913(V v_e_240, V v_st_241, V v_id_242, V v_p_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), v_p_243));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_id_242), v_e_240, v_st_241});
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_d_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2436, 1, 2)});
  V f_ = v_k_2438;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    heff_take_n(v_x_2449, 0ULL, 1);
    v_t_2452 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2451 = heff_field(v_x_2449, 0);
    V v_ru_24x_2449_24Right = heff_take_reuse_n(v_x_2449, 1ULL, 1);
    v_t_2452 = heff_tag_at_n(v_ru_24x_2449_24Right, TAG_Just, 1, (V[]){v_y_2451});
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V f_ = v_k_2448;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam7, 1, 1, (V[]){v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam3(V self, V *args) {
  V v_q_2432 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2433 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_q_2432; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      heff_drop(v_q_2432);
      heff_drop(v_e_240);
      V v_d_2436 = v_field_2435;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam4, 2, 1, (V[]){v_d_2436});
    } else {
      heff_drop(v_field_2435);
      V v_path_2440 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_2432));
      V v_c_2441 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2440; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2440); r_; });
      V v_t_2442 = (g_exception_2eattempted(v_e_240));
      V v_c_2446 = heff_tr(heff_call(v_c_2441, 2, (V[]){v_t_2442, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam5_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam6, 2, 1, (V[]){v_c_2446});
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_d_2431 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2455 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2454, 0, 5)));
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_id_242; V a_3 = v_d_2431; V a_4 = v_t_2455; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_id_242); r_; });
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2474);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str0), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str1), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str2)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str3));
    V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str4), heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str5)), MK_INT(0LL)));
    V v_acc_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str7)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str8));
    V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str9), v_t_2412, MK_INT(0LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str10)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str11));
    V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_id_242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_242); r_; });
    V v_t_2416 = heff_strAppend(heff_strAppend(v_acc_2415, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str12)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str13));
    V v_t_2417 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str14), v_t_2416, MK_INT(0LL)));
    V v_acc_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str15)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str16));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str17)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str18));
    V v_a_2420 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str19)), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2425, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam2, 1, 2, (V[]){v_k_246, v_st_241})));
  }
  case TAG_Just: {
    V v_f_2427 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    HeffT2 v_t_2428 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_f_2427));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_d_2431 = v_field_2430;
        V v_c_2453 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam3, 1, 2, (V[]){heff_dup(v_st_241), heff_dup(v_e_240)}), heff_dup(heff_rfield(v_st_241, 6)), v_f_2427));
        V f_ = v_c_2453;
        heff_room[0] = heff_dup(v_hd_245);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam8, 1, 6, (V[]){v_e_240, v_st_241, v_id_242, v_d_2431, v_hd_245, v_k_246});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2427);
        heff_drop(v_field_2430);
        V v_t_2456 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str20), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str21), MK_INT(0LL)));
        V v_acc_2457 = heff_strAppend(heff_strAppend(v_t_2456, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str22)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str23));
        V v_t_2458 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str24), heff_strAppend(v_acc_2457, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str25)), MK_INT(0LL)));
        V v_acc_2459 = heff_strAppend(v_t_2458, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str26));
        V v_t_2460 = heff_strAppend(heff_strAppend(v_acc_2459, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str27)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str28));
        V v_t_2461 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str29), v_t_2460, MK_INT(0LL)));
        V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2461, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str30)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str31));
        V v_acc_2463 = ({ V a_0 = v_t_2462; V a_1 = v_id_242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_242); r_; });
        V v_t_2464 = heff_strAppend(heff_strAppend(v_acc_2463, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str32)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str33));
        V v_t_2465 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str34), v_t_2464, MK_INT(0LL)));
        V v_acc_2466 = heff_strAppend(heff_strAppend(v_t_2465, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str35)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str36));
        V v_t_2467 = heff_strAppend(heff_strAppend(v_acc_2466, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str37)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str38));
        V v_a_2468 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_str39)), NTAG(TAG_MkUnit)});
        V v_t_2469 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2468})});
        V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2473, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam9, 1, 2, (V[]){v_k_246, v_st_241})));
      }
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_lam1, 1, 5, (V[]){v_id_242, v_e_240, v_hd_245, v_k_246, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str4, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str5, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_entry, 5, 0};

V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301(V v_e_240, V v_st_241, V v_msg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_msg_242)) {
  case TAG_JNull: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2410 = heff_dup(heff_field(v_msg_242, 0));
    HeffT2 v_t_2411 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str0); V a_1 = v_fs_2410; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2410); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_p_2414 = v_field_2413;
        V v_t_2417;
        switch (heff_tag_of(v_p_2414)) {
        case TAG_MkPair: {
          V v_y_2416 = heff_field(v_p_2414, 1);
          heff_take_n(v_p_2414, 2ULL, 2);
          v_t_2417 = v_y_2416;
          break;
        }
        default: heff_nomatch(v_p_2414);
        }
        switch (heff_tag_of(v_t_2417)) {
        case TAG_JNull: {
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2417, 0ULL, 1);
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2417, 0ULL, 1);
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2417, 0ULL, 1);
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2421 = heff_field(v_t_2417, 0);
          V v_ru_24t_2417_24JString = heff_take_reuse_n(v_t_2417, 1ULL, 1);
          v_t_2424 = heff_tag_at_n(v_ru_24t_2417_24JString, TAG_Just, 1, (V[]){v_s_2421});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2417, 0ULL, 1);
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2417, 0ULL, 1);
          v_t_2424 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2417);
        }
      } else {
        heff_drop(v_field_2413);
        v_t_2424 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_msg_242);
  }
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_msg_242);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Just: {
    V v_m_2425 = heff_field(v_t_2424, 0);
    V v_ru_24t_2424_24Just = heff_take_reuse_n(v_t_2424, 1ULL, 1);
    V v_t_2439;
    switch (heff_tag_of(v_msg_242)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2424_24Just, 1);
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2431 = heff_dup(heff_field(v_msg_242, 0));
      HeffT2 v_t_2432 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str1); V a_1 = v_fs_2431; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2431); r_; });
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          V v_p_2435 = v_field_2434;
          V v_t_2438;
          switch (heff_tag_of(v_p_2435)) {
          case TAG_MkPair: {
            V v_y_2437 = heff_field(v_p_2435, 1);
            heff_take_n(v_p_2435, 2ULL, 2);
            v_t_2438 = v_y_2437;
            break;
          }
          default: heff_nomatch(v_p_2435);
          }
          v_t_2439 = heff_tag_at_n(v_ru_24t_2424_24Just, TAG_Just, 1, (V[]){v_t_2438});
        } else {
          heff_drop_cell(v_ru_24t_2424_24Just, 1);
          heff_drop(v_field_2434);
          v_t_2439 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_242);
    }
    switch (heff_tag_of(v_t_2439)) {
    case TAG_Nothing: {
      V v_p_2452;
      switch (heff_tag_of(v_msg_242)) {
      case TAG_JNull: {
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_242, 0ULL, 1);
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_242, 0ULL, 1);
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_msg_242, 0ULL, 1);
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_242, 0ULL, 1);
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_242, 0ULL, 1);
        v_p_2452 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JObject: {
        V v_fs_2445 = heff_field(v_msg_242, 0);
        heff_take_n(v_msg_242, 1ULL, 1);
        HeffT2 v_t_2446 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str2); V a_1 = v_fs_2445; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2445); r_; });
        {
          V v_field_2448 = v_t_2446.f[1];
          int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
          if ((v_tag_2447 == ((int64_t)0ULL))) {
            V v_p_2449 = v_field_2448;
            switch (heff_tag_of(v_p_2449)) {
            case TAG_MkPair: {
              V v_y_2451 = heff_field(v_p_2449, 1);
              heff_take_n(v_p_2449, 2ULL, 2);
              v_p_2452 = v_y_2451;
              break;
            }
            default: heff_nomatch(v_p_2449);
            }
          } else {
            heff_drop(v_field_2448);
            v_p_2452 = NTAG(TAG_JNull);
          }
        }
        break;
      }
      default: heff_nomatch(v_msg_242);
      }
      V v_c_2453 = (g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981(heff_dup(v_e_240), heff_dup(v_st_241), v_m_2425, heff_dup(v_p_2452)));
      return heff_tail(v_c_2453, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam0, 1, 6, (V[]){v_st_241, v_e_240, v_m_2425, v_p_2452, v_z_243, v_z_244})});
    }
    case TAG_Just: {
      V v_id_2466 = heff_field(v_t_2439, 0);
      V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 1ULL, 1);
      if (((heff_dup(heff_rfield(v_st_241, 5)) == NTAG(TAG_True)) && !heff_strEq_c_lent(v_m_2425, ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str3), 2))) {
        heff_drop(v_msg_242);
        heff_drop(v_m_2425);
        V v_c_2467 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24t_2439_24Just, v_e_240, v_id_2466, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str4)));
        return heff_tail(v_c_2467, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam1, 1, 2, (V[]){v_z_244, v_st_241})});
      } else {
        heff_drop_cell(v_ru_24t_2439_24Just, 1);
        V v_t_2481;
        switch (heff_tag_of(v_msg_242)) {
        case TAG_JNull: {
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_242, 0ULL, 1);
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_242, 0ULL, 1);
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_msg_242, 0ULL, 1);
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_242, 0ULL, 1);
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_242, 0ULL, 1);
          v_t_2481 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JObject: {
          V v_fs_2474 = heff_field(v_msg_242, 0);
          heff_take_n(v_msg_242, 1ULL, 1);
          HeffT2 v_t_2475 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_str5); V a_1 = v_fs_2474; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2474); r_; });
          {
            V v_field_2477 = v_t_2475.f[1];
            int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
            if ((v_tag_2476 == ((int64_t)0ULL))) {
              V v_p_2478 = v_field_2477;
              switch (heff_tag_of(v_p_2478)) {
              case TAG_MkPair: {
                V v_y_2480 = heff_field(v_p_2478, 1);
                heff_take_n(v_p_2478, 2ULL, 2);
                v_t_2481 = v_y_2480;
                break;
              }
              default: heff_nomatch(v_p_2478);
              }
            } else {
              heff_drop(v_field_2477);
              v_t_2481 = NTAG(TAG_JNull);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_242);
        }
        return (g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282(v_e_240, v_st_241, v_m_2425, v_id_2466, v_t_2481, v_z_243, v_z_244));
      }
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam0(V self, V *args) {
  V v_x_2454 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_2425 = heff_env(self)[2];
  V v_p_2452 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2465;
  if ((heff_dup(v_x_2454) == NTAG(TAG_True))) {
    heff_drop(v_x_2454);
    v_t_2465 = v_st_241;
  } else {
    heff_drop(v_x_2454);
    V v_s_2455 = v_st_241;
    V v_t_2456 = heff_dup(heff_rfield(v_s_2455, 3));
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Nothing: {
      v_t_2465 = v_s_2455;
      break;
    }
    case TAG_Just: {
      V v_pr_2457 = heff_field(v_t_2456, 0);
      heff_take_n(v_t_2456, 1ULL, 1);
      V v_due_2458 = heff_take_field(v_s_2455, 2);
      V v_watch_2459 = heff_take_field(v_s_2455, 4);
      V v_shutdown_2460 = heff_take_field(v_s_2455, 5);
      V v_lib_2461 = heff_take_field(v_s_2455, 6);
      V v_program_2462 = heff_take_field(v_pr_2457, 2);
      V v_kept_2463 = heff_take_field(v_pr_2457, 4);
      V v_t_2464 = ({ V rv_2 = v_program_2462; V rv_3 = NTAG(TAG_False); V rv_4 = v_kept_2463; V rr_ = heff_rec_reuse_nf(v_pr_2457, 3ULL, 5, shape_root__names__program__current__kept, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      v_t_2465 = ({ V rv_2 = v_due_2458; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2464}); V rv_4 = v_watch_2459; V rv_5 = v_shutdown_2460; V rv_6 = v_lib_2461; V rr_ = heff_rec_reuse_nf(v_s_2455, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
      break;
    }
    default: heff_nomatch(v_t_2456);
    }
  }
  return ({ V a_0 = v_e_240; V a_1 = v_t_2465; V a_2 = v_m_2425; V a_3 = v_p_2452; V a_4 = v_z_243; V a_5 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2enotified_24s738584401x754960967(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_m_2425); r_; });
}
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_lam1(V self, V *args) {
  V v_x_2468 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2468);
  V f_ = v_z_244;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_entry, 8, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1(V v_tok_240, V v_e_241, V v_a_242, V v_f_243, V v_off_244, V v_t_245, V v_z_246, V v_z_247) {
top: ;
  V v_target_248 = heff_take_field(v_t_245, 0);
  V v_name_249 = heff_get_n(v_t_245, 1, 2);
  V v_st_2410 = heff_take_field(v_a_242, 0);
  V v_program_2411 = heff_get_n(v_a_242, 2, 3);
  V v_t_2412 = heff_dup(heff_rfield(v_target_248, 2));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_249), NTAG(TAG_Nil)});
    V v_c_2414 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(v_e_241, v_st_2410, heff_dup(v_f_243), heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_2413})));
    return heff_tail(v_c_2414, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_lam0, 1, 6, (V[]){v_name_249, v_program_2411, v_target_248, v_f_243, v_z_247, v_off_244})});
  }
  case TAG_Just: {
    heff_take_n(v_t_2412, 0ULL, 1);
    heff_drop(v_e_241);
    heff_drop(v_z_246);
    V v_name_2425 = heff_dup(v_name_249);
    V v_occurrences_2426 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2411, heff_dup(v_target_248), v_name_249));
    V v_target_2427 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_243, v_target_248, v_name_2425, v_occurrences_2426})});
    return heff_tail(v_z_247, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_2410, v_off_244, v_target_2427})});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_name_249 = heff_env(self)[0];
  V v_program_2411 = heff_env(self)[1];
  V v_target_248 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_off_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2416 = heff_take_field(v_x_2415, 1);
  V v_st_2417 = heff_get_n(v_x_2415, 0, 2);
  V v_name_2418 = heff_dup(v_name_249);
  V v_t_2421;
  switch (heff_tag_of(v_program_2416)) {
  case TAG_Nil: {
    v_t_2421 = v_program_2411;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_2411);
    v_t_2421 = v_program_2416;
    break;
  }
  default: heff_nomatch(v_program_2416);
  }
  V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2421, heff_dup(v_target_248), v_name_249));
  V v_target_2423 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_243, v_target_248, v_name_2418, v_occurrences_2422})});
  V f_ = v_z_247;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2417, v_off_244, v_target_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}