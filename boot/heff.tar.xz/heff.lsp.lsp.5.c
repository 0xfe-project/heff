// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Attempt 14217
#define TAG_ByFields 9073
#define TAG_ByTags 55317
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Throw 56084
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_ret 322331
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_uses 10094739
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__span__start__equals__end[] = {LBL_name, LBL_span, LBL_start, LBL_equals, LBL_end};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_title__start__end__text[] = {LBL_title, LBL_start, LBL_end, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_clo;
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907(V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2esplit_2ealiasedTag(V, V);
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ealiasedTag_clo;
V g_heff_2elsp_2esplit_2earrowOutside(V, V, V);
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2earrowOutside_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS(V);
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo;
V g_heff_2elsp_2esplit_2edeclsOf(V);
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2edeclsOf_clo;
V g_heff_2elsp_2esplit_2eextentEnd(V, V, V);
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eextentEnd_clo;
V g_heff_2elsp_2esplit_2efirstJust(V);
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efirstJust_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
V g_heff_2elsp_2esplit_2efreshNames(V, V);
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_clo;
V g_heff_2elsp_2esplit_2ehintOf(V, V);
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehintOf_clo;
V g_heff_2elsp_2esplit_2eisOperator(V);
V g_heff_2elsp_2esplit_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eisOperator_clo;
V g_heff_2elsp_2esplit_2elineStart(V, V);
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elineStart_clo;
V g_heff_2elsp_2esplit_2enameEnd(V, V);
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enameEnd_clo;
V g_heff_2elsp_2esplit_2evarIn(V, V);
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2evarIn_clo;
V g_heff_2elsp_2esplit_2ewordsIn(V, V, V, V);
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ewordsIn_clo;
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1338461068x888657721_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efind_24s633938771x532201311(V, V);
V g_list_2efind_24s633938771x532201311_entry(V self, V *a);
extern Clo g_list_2efind_24s633938771x532201311_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1037112923x126964824(V, V, V, V, V);
V g_list_2efoldl_24f1037112923x126964824_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1037112923x126964824_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s661788424x2062432904(V, V);
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a);
extern Clo g_list_2efoldl_24s661788424x2062432904_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1628253759x601849359(V, V, V);
V g_list_2emap_24s1628253759x601849359_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s2130584539x811126895(V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_strEq_get(void);
HEFF_LIT(g_heff_2elsp_2elsp_2ewordEnd_str0, 12, " \011\015(){}[]:,=");
Clo g_heff_2elsp_2elsp_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewordEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewordEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_l_240, 0), heff_dup(v_i_241)) || ({ V v_t_242 = heff_strSlice(heff_dup(v_l_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ({ V v_t_243 = heff_strFind_lent(v_t_242, ((V)&g_heff_2elsp_2elsp_2ewordEnd_str0), MK_INT(0LL), 6); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_243, 1); heff_drop(v_t_243); c_; }); heff_drop(v_t_242); c_; }))) {
    return v_i_241;
  } else {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str7, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str9, 1, " ");
Clo g_heff_2elsp_2elsp_2ekeyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeyOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeyOf(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_242 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_get_n(v_t_241, 0, 2), heff_get_n(v_t_242, 1, 2));
  V v_t_244 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_245 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_244, 6);
  V v_t_247;
  if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str0), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str1), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str2), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str3), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str4), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str5), v_w_245, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str6), v_w_245, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str7), v_w_245, 1))))))))) {
    heff_drop(v_w_245);
    V v_t_246 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    v_t_247 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_246, 6);
  } else {
    heff_drop(v_w_245);
    v_t_247 = ((V)&g_heff_2elsp_2elsp_2ekeyOf_str8);
  }
  return heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2elsp_2elsp_2ekeyOf_str9)), v_t_247);
}
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ekeyOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s1441124185x871809048(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_local_243 = heff_take_field(v_target_242, 2);
  V v_member_244 = heff_get_n(v_target_242, 1, 3);
  switch (heff_tag_of(v_local_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_member_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength(v_t_246)) - heff_unbox_word(v_t_247));
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), heff_box_word(v_t_248)), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_member_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_member_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_local_243, 0);
    V v_ru_24local_243_24Just = heff_take_reuse_n(v_local_243, 1ULL, 1);
    heff_drop(v_member_244);
    V v_path_2413 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
    V v_t_2414 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2414));
    V v_t_2416 = (g_list_2efoldl_24f1037112923x126964824(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2417 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(heff_box_word(v_t_2415), v_t_2416));
    V v_t_2418 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2418));
    V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_t_240); V a_3 = heff_dup(v_b_2412); V b_4 = heff_get_n(v_t_240, 3, 4); V r_ = (g_list_2efoldl_24f1037112923x126964824(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    V v_t_2421 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(heff_box_word(v_t_2419), v_t_2420));
    V v_e_2422 = heff_intAdd(v_t_2421, heff_strLength(v_new_241));
    V v_t_2423 = heff_tag_at_n(v_ru_24local_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2417, v_e_2422})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_path_2413, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_local_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_245 = heff_take_field(v_c_243, 1);
    V v_module_246 = heff_take_field(v_c_243, 0);
    V v_deps_247 = heff_get_n(v_c_243, 8, 14);
    V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_245)}));
    V v_t_249 = (g_list_2eany(v_t_248, v_changed_240));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_deps_247);
      heff_drop(v_t_249);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_245, heff_hole()});
      V v_u_2411 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, heff_tag_n(TAG_Cons, 2, (V[]){v_module_246, v_mods_241}), v_rest_244, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop(v_t_249);
      V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V a_1 = v_deps_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_deps_247); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_cell_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_245, heff_hole()});
        V v_u_2416 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, heff_tag_n(TAG_Cons, 2, (V[]){v_module_246, v_mods_241}), v_rest_244, heff_dup(v_cell_2415)));
        heff_drop(v_u_2416);
        return v_cell_2415;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_path_245);
        heff_drop(v_module_246);
        heff_drop(v_t_2414);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2412}));
  return ({ V a_0 = v_t_2413; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry, 3, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_str6); V a_1 = v_t_2410; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2417});
}
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_entry, 8, 0};

V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(V v_read_240, V v_lib_241, V v_full_242, V v_kept_243, V v_f_244, V v_files_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = (g_heff_2elsp_2elsp_2enubPaths(v_files_245));
  V v_c_249 = ({ V a_0 = v_read_240; V a_1 = heff_dup(v_lib_241); V a_2 = v_t_248; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam0, 1, 6, (V[]){v_lib_241, v_f_244, v_z_246, v_full_242, v_kept_243, v_z_247})});
}
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_full_242 = heff_env(self)[1];
  V v_kept_243 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2elsp_2elsp_2enubSources(v_x_2410));
  return (g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073(v_full_242, v_kept_243, v_x_2412, v_t_2413, v_z_246, v_z_247));
}
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lib_241 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_full_242 = heff_env(self)[3];
  V v_kept_243 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_lib_241, v_f_244));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_lam1, 1, 5, (V[]){v_x_2410, v_full_242, v_kept_243, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam11(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam11, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348(V v_st_240, V v_f_241, V v_program_242, V v_c_243, V v_s_244) {
top: ;
  V v_docs_245 = heff_take_field(v_st_240, 0);
  V v_lib_246 = heff_get_n(v_st_240, 6, 7);
  V v_c_2445 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam0, 1, 4, (V[]){heff_dup(v_f_241), v_c_243, heff_dup(v_s_244), v_docs_245}), v_lib_246, v_f_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam8, 2, 3, (V[]){v_c_2445, v_program_242, v_s_244});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_src_2410 = heff_get_n(v_c_243, 3, 14);
  V v_t_2411 = heff_strSlice(heff_dup(v_src_2410), MK_INT(0LL), heff_take_field(v_s_244, 3));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_str0)), heff_take_field(v_s_244, 0));
  V v_t_2413 = heff_strSlice(heff_dup(v_src_2410), heff_get_n(v_s_244, 4, 5), heff_strLength(v_src_2410));
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2412, v_t_2413)});
  V f_ = v_k_249;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam3(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_err_2433 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2432_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2433})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2434));
  }
  case TAG_Right: {
    V v_x_2435 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam5, 2, 1, (V[]){v_x_2435});
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    heff_take_n(v_x_2441, 0ULL, 1);
    v_t_2444 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2443 = heff_field(v_x_2441, 0);
    V v_ru_24x_2441_24Right = heff_take_reuse_n(v_x_2441, 1ULL, 1);
    v_t_2444 = heff_tag_at_n(v_ru_24x_2441_24Right, TAG_Just, 1, (V[]){v_y_2443});
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_k_2440;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam6(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam7, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam0(V self, V *args) {
  V v_q_247 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  V v_docs_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_247, v_f_241, 2)) {
    heff_drop(v_q_247);
    heff_drop(v_docs_245);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam1, 2, 2, (V[]){v_c_243, v_s_244});
  } else {
    heff_drop_rec(v_c_243, 14);
    heff_drop_rec(v_s_244, 5);
    HeffT2 v_t_2415 = ({ V a_0 = v_docs_245; V a_1 = v_q_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_245); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_q_247);
        V v_d_2418 = v_field_2417;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam2, 2, 1, (V[]){v_d_2418});
      } else {
        heff_drop(v_field_2417);
        V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_247));
        V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
        V v_a_2425 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2423, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam3_clo)});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
        V v_c_2438 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam4_clo)));
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam6, 2, 1, (V[]){v_c_2438});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam11(V self, V *args) {
  V v_r_2474 = args[0];
  return v_r_2474;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam10(V self, V *args) {
  V v_use_2449 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_hd_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_program_2450 = v_program_242;
  V v_s_2451 = v_s_244;
  V v_equals_2452 = heff_take_field(v_s_2451, 3);
  V v_name_2453 = heff_get_n(v_s_2451, 0, 5);
  V v_x1_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2448, 0, 5)));
  V v_x3_2457;
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nil: {
    v_x3_2457 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 2);
    v_x3_2457 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2455});
    break;
  }
  default: heff_nomatch(v_x1_2454);
  }
  V v_x_2472;
  switch (heff_tag_of(v_x3_2457)) {
  case TAG_Nothing: {
    heff_drop(v_program_2450);
    heff_drop(v_equals_2452);
    heff_drop(v_name_2453);
    v_x_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_source_2458 = heff_field(v_x3_2457, 0);
    V v_ru_24x3_2457_24Just = heff_take_reuse_n(v_x3_2457, 1ULL, 1);
    V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_2450));
    V v_xs_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2459; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2459); r_; });
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2460));
    V v_c_2462 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2461, v_source_2458, NTAG(TAG_Nothing)));
    HeffT2 v_t_2463 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2462, heff_intAdd(v_equals_2452, MK_INT(1LL))));
    {
      V v_field_2465 = v_t_2463.f[1];
      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
      if ((v_tag_2464 == ((int64_t)0ULL))) {
        V v_i_2466 = v_field_2465;
        V v_name_2467 = heff_take_field(v_i_2466, 1);
        V v_key_2468 = heff_take_field(v_i_2466, 2);
        V v_ty_2469 = heff_get_n(v_i_2466, 4, 5);
        if (heff_strEq_c(v_name_2467, v_name_2453)) {
          switch (heff_tag_of(v_key_2468)) {
          case TAG_Nothing: {
            V v_t_2470 = heff_tr(heff_call(v_ty_2469, 1, (V[]){NTAG(TAG_MkUnit)}));
            v_x_2472 = heff_tag_at_n(v_ru_24x3_2457_24Just, TAG_Just, 1, (V[]){v_t_2470});
            break;
          }
          case TAG_Just: {
            heff_take_n(v_key_2468, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_2457_24Just, 1);
            heff_drop(v_ty_2469);
            v_x_2472 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_key_2468);
          }
        } else {
          heff_drop_cell(v_ru_24x3_2457_24Just, 1);
          heff_drop(v_key_2468);
          heff_drop(v_ty_2469);
          v_x_2472 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_name_2453);
        heff_drop_cell(v_ru_24x3_2457_24Just, 1);
        heff_drop(v_field_2465);
        v_x_2472 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x3_2457);
  }
  V v_t_2473 = heff_tr(heff_call(heff_get_n(v_hd_2446, 0, 3), 1, (V[]){v_x_2472}));
  V f_ = v_use_2449;
  heff_room[0] = v_t_2473;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam11_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam12(V self, V *args) {
  V v_x_2481 = args[0];
  V v_k_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484;
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Left: {
    heff_take_n(v_x_2481, 0ULL, 1);
    v_t_2484 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_t_2483 = heff_field(v_x_2481, 0);
    heff_take_n(v_x_2481, 1ULL, 1);
    v_t_2484 = v_t_2483;
    break;
  }
  default: heff_nomatch(v_x_2481);
  }
  V f_ = v_k_2447;
  args[0] = v_t_2484;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_hd_2446 = heff_env(self)[2];
  V v_k_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam10, 1, 4, (V[]){v_program_242, v_s_244, v_x_2448, heff_dup(v_hd_2446)})})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_2446, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
  V f_ = heff_get_n(v_hd_2446, 1, 3);
  heff_room[0] = v_t_2480;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam12, 1, 1, (V[]){v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam8(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2445;
  args[0] = heff_dup(v_hd_2446);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348_lam9, 1, 4, (V[]){v_program_242, v_s_244, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str0, 1, "=");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str3, 7, "Split `");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str4, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str6, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str7, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str12, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str13, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str14, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str15, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str17, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str18, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str19, 1, "(");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str20, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str21, 3, " = ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str22, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str23, 2, ", ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str24, 2, "{ ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str25, 2, " }");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str26, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str27, 12, "` into cases");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str28, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str29, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str30, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str31, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str32, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str33, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str34, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str35, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str36, 4, "edit");
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_entry, 8, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326(V v_st_240, V v_f_241, V v_uri_242, V v_program_243, V v_c_244, V v_off_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam0, 1, 2, (V[]){heff_dup(v_c_244), v_off_245}), heff_dup(heff_rfield(v_c_244, 4))));
  HeffT2 v_t_2465 = ({ V a_0 = v_t_2464; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2464); r_; });
  {
    V v_field_2467 = v_t_2465.f[1];
    int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
    if ((v_tag_2466 == ((int64_t)0ULL))) {
      V v_s_2468 = v_field_2467;
      V v_c_2469 = heff_dup(v_c_244);
      V v_s_2470 = heff_dup(v_s_2468);
      V v_t_2471 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2469, 4)));
      V v_t_2472 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2471));
      HeffT2 v_t_2473 = ({ V a_0 = heff_dup(v_s_2470); V b_1 = heff_get_n(v_t_2472, 0, 2); HeffT2 r_ = (g_list_2efind_24s1338461068x888657721_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2489;
      {
        V v_field_2475 = v_t_2473.f[1];
        int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
        if ((v_tag_2474 == ((int64_t)0ULL))) {
          V v_l_2476 = v_field_2475;
          V v_t_2477 = heff_get_n(v_l_2476, 2, 3);
          switch (heff_tag_of(v_t_2477)) {
          case TAG_Nil: {
            heff_drop_rec(v_c_2469, 14);
            heff_drop_rec(v_s_2470, 5);
            v_t_2489 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_x_2478 = heff_field(v_t_2477, 0);
            heff_take_n(v_t_2477, 1ULL, 2);
            HeffT2 v_t_2480 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2469, heff_get_n(v_x_2478, 0, 2)));
            {
              V v_field_2482 = v_t_2480.f[1];
              int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
              if ((v_tag_2481 == ((int64_t)0ULL))) {
                V v_i_2483 = v_field_2482;
                V v_name_2484 = heff_take_field(v_i_2483, 1);
                V v_key_2485 = heff_take_field(v_i_2483, 2);
                V v_ty_2486 = heff_get_n(v_i_2483, 4, 5);
                if (heff_strEq_c(v_name_2484, heff_get_n(v_s_2470, 0, 5))) {
                  switch (heff_tag_of(v_key_2485)) {
                  case TAG_Nothing: {
                    V v_t_2487 = heff_tr(heff_call(v_ty_2486, 1, (V[]){NTAG(TAG_MkUnit)}));
                    v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2487});
                    break;
                  }
                  case TAG_Just: {
                    heff_take_n(v_key_2485, 0ULL, 1);
                    heff_drop(v_ty_2486);
                    v_t_2489 = NTAG(TAG_Nothing);
                    break;
                  }
                  default: heff_nomatch(v_key_2485);
                  }
                } else {
                  heff_drop(v_key_2485);
                  heff_drop(v_ty_2486);
                  v_t_2489 = NTAG(TAG_Nothing);
                }
              } else {
                heff_drop_rec(v_s_2470, 5);
                heff_drop(v_field_2482);
                v_t_2489 = NTAG(TAG_Nothing);
              }
            }
            break;
          }
          default: heff_nomatch(v_t_2477);
          }
        } else {
          heff_drop_rec(v_c_2469, 14);
          heff_drop_rec(v_s_2470, 5);
          heff_drop(v_field_2475);
          v_t_2489 = NTAG(TAG_Nothing);
        }
      }
      V v_c_2493;
      switch (heff_tag_of(v_t_2489)) {
      case TAG_Nothing: {
        v_c_2493 = (g_heff_2elsp_2elsp_2eprobedType_24s1784439983x791549348(v_st_240, v_f_241, heff_dup(v_program_243), heff_dup(v_c_244), heff_dup(v_s_2468)));
        break;
      }
      case TAG_Just: {
        V v_t_2490 = heff_field(v_t_2489, 0);
        heff_take_n(v_t_2489, 1ULL, 1);
        heff_drop(v_st_240);
        heff_drop(v_f_241);
        v_c_2493 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam3, 2, 1, (V[]){v_t_2490});
        break;
      }
      default: heff_nomatch(v_t_2489);
      }
      return heff_tail(v_c_2493, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam4, 1, 5, (V[]){v_program_243, v_c_244, v_s_2468, v_uri_242, v_z_247})});
    } else {
      heff_drop(v_st_240);
      heff_drop(v_f_241);
      heff_drop(v_uri_242);
      heff_drop(v_program_243);
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_z_246);
      heff_drop(v_field_2467);
      return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam2(V self, V *args) {
  V v_p_2426 = args[0];
  V v_off_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_2410; V a_1 = v_p_2426; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2426); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam1(V self, V *args) {
  V v_e_2419 = args[0];
  V v_off_2410 = heff_env(self)[0];
  V v_src_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_e_2419)) {
  case TAG_At: {
    V v_x31_2420 = heff_field(v_e_2419, 0);
    V v_sp_2421 = heff_field(v_e_2419, 1);
    V v_ru_24e_2419_24At = heff_take_reuse_n(v_e_2419, 3ULL, 2);
    switch (heff_tag_of(v_x31_2420)) {
    case TAG_MkEquation: {
      V v_ps_2424 = heff_field(v_x31_2420, 2);
      heff_take_n(v_x31_2420, 4ULL, 4);
      V v_t_2427 = (g_list_2emap_24tok2(v_ru_24e_2419_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam2, 1, 1, (V[]){v_off_2410}), heff_dup(v_ps_2424)));
      HeffT2 v_t_2428 = ({ V a_0 = v_t_2427; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2427); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_v_2431 = v_field_2430;
          V v_src_2432 = v_src_249;
          V v_v_2433 = v_v_2431;
          V v_name_2434 = heff_take_field(v_v_2433, 0);
          V v_span_2435 = heff_get_n(v_v_2433, 1, 2);
          V v_sp_2436 = v_sp_2421;
          V v_start_2437 = heff_take_field(v_sp_2436, 0);
          V v_end_2438 = heff_get_n(v_sp_2436, 1, 2);
          V v_ps_2439 = v_ps_2424;
          V v_i_2440 = ({ V a_0 = heff_dup(v_start_2437); V a_1 = v_ps_2439; V r_ = (g_list_2efoldl_24s661788424x2062432904(a_0, a_1)); heff_drop(v_ps_2439); r_; });
          V v_j_2441 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str0), v_src_2432, v_i_2440, 5);
          if (heff_intLt_c_lent(v_j_2441, MK_INT(0LL), 2)) {
            heff_drop(v_src_2432);
            heff_drop(v_name_2434);
            heff_drop(v_span_2435);
            heff_drop(v_start_2437);
            heff_drop(v_end_2438);
            heff_drop(v_j_2441);
            return NTAG(TAG_Nothing);
          } else {
            V v_t_2442 = (g_heff_2elsp_2esplit_2elineStart(v_src_2432, heff_dup(v_start_2437)));
            V v_d_2443 = heff_strLength_lent(v_src_2432, 0);
            V v_j_2444 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str1), v_src_2432, v_end_2438, 5);
            V v_t_2445;
            if (heff_intLt_c_lent(v_j_2444, MK_INT(0LL), 2)) {
              heff_drop(v_j_2444);
              v_t_2445 = v_d_2443;
            } else {
              heff_drop(v_d_2443);
              v_t_2445 = v_j_2444;
            }
            V v_t_2446 = ({ V a_0 = v_src_2432; V a_1 = heff_intSub(heff_dup(v_start_2437), v_t_2442); V a_2 = v_t_2445; V r_ = (g_heff_2elsp_2esplit_2eextentEnd(a_0, a_1, a_2)); heff_drop(v_src_2432); r_; });
            V v_t_2447 = heff_rec_n(5, shape_name__span__start__equals__end, (V[]){v_name_2434, v_span_2435, v_start_2437, heff_intAdd(v_j_2441, MK_INT(1LL)), v_t_2446});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2447});
          }
        } else {
          heff_drop(v_src_249);
          heff_drop(v_sp_2421);
          heff_drop(v_ps_2424);
          heff_drop(v_field_2430);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x31_2420);
    }
  }
  default: return heff_nomatch(v_e_2419);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_off_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_249 = heff_get_n(v_c_244, 3, 14);
  V v_off_2410 = v_off_245;
  V v_x3_2411 = v_d_248;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_At: {
    V v_x31_2412 = heff_field(v_x3_2411, 0);
    V v_ru_24x3_2411_24At = heff_take_reuse_n(v_x3_2411, 1ULL, 2);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_DeclEquations: {
      V v_eqs_2418 = heff_field(v_x31_2412, 4);
      heff_take_n(v_x31_2412, 16ULL, 5);
      V v_t_2448 = (g_list_2emap_24tok2(v_ru_24x3_2411_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam1, 1, 2, (V[]){v_off_2410, v_src_249}), v_eqs_2418));
      return ({ V a_0 = v_t_2448; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2448); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_2412, 0ULL, 5);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_2412, 0ULL, 4);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_2412, 0ULL, 3);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_2412, 0ULL, 2);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_2412, 0ULL, 1);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam3(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_t_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2491);
  V f_ = v_k_2492;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2490});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam5(V self, V *args) {
  V v_c2_24119 = args[0];
  V v_k_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24120 = ({ V a_0 = v_k_24117; V a_1 = heff_rfield(v_c2_24119, 7); HeffT2 r_ = (g_list_2efind_24s1953031388x2120050076_24cpr(a_0, a_1)); heff_drop(v_k_24117); r_; });
  {
    V v_field_24122 = v_t_24120.f[1];
    int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
    if ((v_tag_24121 == ((int64_t)0ULL))) {
      V v_o_24123 = v_field_24122;
      V v_t_24124 = (g_heff_2elsp_2esplit_2edeclsOf(v_c2_24119));
      return ({ V a_0 = v_o_24123; V a_1 = v_t_24124; V r_ = (g_list_2efind_24s633938771x532201311(a_0, a_1)); heff_drop(v_t_24124); r_; });
    } else {
      heff_drop_rec(v_c2_24119, 14);
      heff_drop(v_field_24122);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam7(V self, V *args) {
  V v_o_24241 = args[0];
  V v_c_24240 = heff_env(self)[0];
  V v_g_24239 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24242 = (g_heff_2elsp_2esplit_2eisOperator(heff_rfield(v_o_24241, 0)));
  if ((heff_dup(v_t_24242) == NTAG(TAG_True))) {
    heff_drop(v_t_24242);
    V v_x_24243 = heff_get_n(v_o_24241, 0, 2);
    HeffT2 v_t_24244 = ({ V a_0 = v_x_24243; V b_1 = heff_get_n(v_c_24240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_24246 = v_t_24244.f[1];
      int64_t v_tag_24245 = ((int64_t)v_t_24244.f[0]);
      if ((v_tag_24245 == ((int64_t)0ULL))) {
        V v_o_24247 = v_field_24246;
        HeffT3 v_t_24248 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24239, v_x_24243));
        {
          V v_field_24250 = v_t_24248.f[1];
          V v_field_24251 = v_t_24248.f[2];
          int64_t v_tag_24249 = ((int64_t)v_t_24248.f[0]);
          if ((v_tag_24249 == ((int64_t)0ULL))) {
            heff_drop_rec(v_o_24247, 2);
            heff_drop(v_field_24251);
            V v_x_24252 = v_field_24250;
            heff_drop(v_x_24252);
            return NTAG(TAG_False);
          } else {
            if ((v_tag_24249 == ((int64_t)1ULL))) {
              heff_drop_rec(v_o_24247, 2);
              heff_drop(v_field_24250);
              heff_drop(v_field_24251);
              return NTAG(TAG_False);
            } else {
              if ((v_tag_24249 == ((int64_t)2ULL))) {
                V v_k2_24253 = v_field_24250;
                V v_x_24254 = v_field_24251;
                heff_drop(v_x_24254);
                V v_ret_24bool = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_o_24247, 1)), heff_dup(v_k2_24253)));
                heff_drop_rec(v_o_24247, 2);
                heff_drop(v_k2_24253);
                return v_ret_24bool;
              } else {
                heff_drop_rec(v_o_24247, 2);
                heff_drop(v_field_24250);
                heff_drop(v_field_24251);
                return NTAG(TAG_False);
              }
            }
          }
        }
      } else {
        heff_drop(v_g_24239);
        heff_drop(v_x_24243);
        heff_drop(v_field_24246);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop_rec(v_o_24241, 2);
    heff_drop_rec(v_c_24240, 14);
    heff_drop(v_g_24239);
    heff_drop(v_t_24242);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam8(V self, V *args) {
  V v_d_24257 = args[0];
  V v_g_24238 = heff_env(self)[0];
  V v_x_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_g_24258 = v_g_24238;
  V v_c_24259 = v_x_24237;
  V v_x3_24260 = v_d_24257;
  switch (heff_tag_of(v_x3_24260)) {
  case TAG_At: {
    V v_x31_24261 = heff_field(v_x3_24260, 0);
    V v_ru_24x3_24260_24At = heff_take_reuse_n(v_x3_24260, 1ULL, 2);
    switch (heff_tag_of(v_x31_24261)) {
    case TAG_DeclEquations: {
      V v_op_24263 = heff_field(v_x31_24261, 0);
      V v_x315_24267 = heff_field(v_x31_24261, 4);
      heff_take_n(v_x31_24261, 17ULL, 5);
      switch (heff_tag_of(v_x315_24267)) {
      case TAG_Nil: {
        heff_drop(v_g_24258);
        heff_drop_rec(v_c_24259, 14);
        heff_drop_cell(v_ru_24x3_24260_24At, 2);
        heff_drop(v_op_24263);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_e_24268 = heff_field(v_x315_24267, 0);
        V v_x3152_24269 = heff_field(v_x315_24267, 1);
        heff_take_n(v_x315_24267, 3ULL, 2);
        switch (heff_tag_of(v_x3152_24269)) {
        case TAG_Nil: {
          V v_t_24270 = (g_heff_2elsp_2esplit_2eisOperator(v_op_24263));
          if ((heff_dup(v_t_24270) == NTAG(TAG_True))) {
            heff_drop(v_t_24270);
            HeffT2 v_t_24271 = ({ V a_0 = v_op_24263; V b_1 = heff_get_n(v_c_24259, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24273 = v_t_24271.f[1];
              int64_t v_tag_24272 = ((int64_t)v_t_24271.f[0]);
              if ((v_tag_24272 == ((int64_t)0ULL))) {
                V v_o_24274 = v_field_24273;
                HeffT3 v_t_24275 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24258, heff_dup(v_op_24263)));
                {
                  V v_field_24277 = v_t_24275.f[1];
                  V v_field_24278 = v_t_24275.f[2];
                  int64_t v_tag_24276 = ((int64_t)v_t_24275.f[0]);
                  if ((v_tag_24276 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24x3_24260_24At, 2);
                    heff_drop(v_op_24263);
                    heff_drop(v_e_24268);
                    heff_drop_rec(v_o_24274, 2);
                    heff_drop(v_field_24278);
                    V v_x_24279 = v_field_24277;
                    heff_drop(v_x_24279);
                    return NTAG(TAG_Nothing);
                  } else {
                    if ((v_tag_24276 == ((int64_t)1ULL))) {
                      heff_drop_cell(v_ru_24x3_24260_24At, 2);
                      heff_drop(v_op_24263);
                      heff_drop(v_e_24268);
                      heff_drop_rec(v_o_24274, 2);
                      heff_drop(v_field_24277);
                      heff_drop(v_field_24278);
                      return NTAG(TAG_Nothing);
                    } else {
                      if ((v_tag_24276 == ((int64_t)2ULL))) {
                        V v_k2_24280 = v_field_24277;
                        V v_x_24281 = v_field_24278;
                        heff_drop(v_x_24281);
                        if (heff_strEq_c(heff_get_n(v_o_24274, 1, 2), v_k2_24280)) {
                          V v_t_24288;
                          switch (heff_tag_of(v_e_24268)) {
                          case TAG_At: {
                            V v_x11_24282 = heff_field(v_e_24268, 0);
                            heff_take_n(v_e_24268, 1ULL, 2);
                            switch (heff_tag_of(v_x11_24282)) {
                            case TAG_MkEquation: {
                              V v_ps_24286 = heff_field(v_x11_24282, 2);
                              V v_body_24287 = heff_field(v_x11_24282, 3);
                              heff_take_n(v_x11_24282, 12ULL, 4);
                              v_t_24288 = ({ V a_0 = v_ps_24286; V a_1 = v_body_24287; V r_ = (g_heff_2elsp_2esplit_2ealiasedTag(a_0, a_1)); heff_drop(v_body_24287); r_; });
                              break;
                            }
                            default: heff_nomatch(v_x11_24282);
                            }
                            break;
                          }
                          default: heff_nomatch(v_e_24268);
                          }
                          switch (heff_tag_of(v_t_24288)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x3_24260_24At, 2);
                            heff_drop(v_op_24263);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_t_24289 = heff_field(v_t_24288, 0);
                            V v_ru_24t_24288_24Just = heff_take_reuse_n(v_t_24288, 1ULL, 1);
                            return heff_tag_at_n(v_ru_24t_24288_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x3_24260_24At, TAG_MkPair, 2, (V[]){v_t_24289, v_op_24263})});
                          }
                          default: return heff_nomatch(v_t_24288);
                          }
                        } else {
                          heff_drop_cell(v_ru_24x3_24260_24At, 2);
                          heff_drop(v_op_24263);
                          heff_drop(v_e_24268);
                          return NTAG(TAG_Nothing);
                        }
                      } else {
                        heff_drop_cell(v_ru_24x3_24260_24At, 2);
                        heff_drop(v_op_24263);
                        heff_drop(v_e_24268);
                        heff_drop_rec(v_o_24274, 2);
                        heff_drop(v_field_24277);
                        heff_drop(v_field_24278);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                }
              } else {
                heff_drop(v_g_24258);
                heff_drop_cell(v_ru_24x3_24260_24At, 2);
                heff_drop(v_op_24263);
                heff_drop(v_e_24268);
                heff_drop(v_field_24273);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_g_24258);
            heff_drop_rec(v_c_24259, 14);
            heff_drop_cell(v_ru_24x3_24260_24At, 2);
            heff_drop(v_op_24263);
            heff_drop(v_e_24268);
            heff_drop(v_t_24270);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x3152_24269, 0ULL, 2);
          heff_drop(v_g_24258);
          heff_drop_rec(v_c_24259, 14);
          heff_drop_cell(v_ru_24x3_24260_24At, 2);
          heff_drop(v_op_24263);
          heff_drop(v_e_24268);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x3152_24269);
        }
      }
      default: return heff_nomatch(v_x315_24267);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_24261, 0ULL, 5);
      heff_drop(v_g_24258);
      heff_drop_rec(v_c_24259, 14);
      heff_drop_cell(v_ru_24x3_24260_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_24261, 0ULL, 4);
      heff_drop(v_g_24258);
      heff_drop_rec(v_c_24259, 14);
      heff_drop_cell(v_ru_24x3_24260_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_24261, 0ULL, 3);
      heff_drop(v_g_24258);
      heff_drop_rec(v_c_24259, 14);
      heff_drop_cell(v_ru_24x3_24260_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_24261, 0ULL, 2);
      heff_drop(v_g_24258);
      heff_drop_rec(v_c_24259, 14);
      heff_drop_cell(v_ru_24x3_24260_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_24261, 0ULL, 1);
      heff_drop(v_g_24258);
      heff_drop_rec(v_c_24259, 14);
      heff_drop_cell(v_ru_24x3_24260_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_24261);
    }
  }
  default: return heff_nomatch(v_x3_24260);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam6(V self, V *args) {
  V v_acc_24236 = args[0];
  V v_x_24237 = args[1];
  V v_c_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_24238 = heff_get_n(heff_get_n(v_c_24234, 5, 14), 0, 10);
  V v_g_24239 = heff_dup(v_g_24238);
  V v_c_24240 = heff_dup(v_x_24237);
  V v_t_24255 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam7, 1, 2, (V[]){heff_dup(v_c_24240), v_g_24239}); V b_1 = heff_get_n(v_c_24240, 7, 14); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24308;
  if ((heff_dup(v_t_24255) == NTAG(TAG_True))) {
    heff_drop(v_t_24255);
    V v_t_24256 = (g_heff_2elsp_2esplit_2edeclsOf(heff_dup(v_x_24237)));
    V v_t_24307 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam8, 1, 2, (V[]){v_g_24238, v_x_24237}), v_t_24256));
    v_t_24308 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24307));
  } else {
    heff_drop(v_x_24237);
    heff_drop(v_g_24238);
    heff_drop(v_t_24255);
    v_t_24308 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_24308, v_acc_24236));
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam10(V self, V *args) {
  V v_a_24320 = args[0];
  V v_ps_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_ps_24313; V a_1 = v_a_24320; V r_ = (g_heff_2elsp_2esplit_2ehintOf(a_0, a_1)); heff_drop(v_ps_24313); heff_drop(v_a_24320); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam9(V self, V *args) {
  V v_t_24315 = args[0];
  V v_ops_24309 = heff_env(self)[0];
  V v_ps_24313 = heff_env(self)[1];
  V v_taken_24312 = heff_env(self)[2];
  V v_s_24311 = heff_env(self)[3];
  V v_src_24310 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_name_24316 = heff_take_field(v_t_24315, 0);
  V v_args_24317 = heff_get_n(v_t_24315, 1, 2);
  V v_op_24318 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = heff_dup(v_name_24316); V a_2 = v_ops_24309; V r_ = (g_list_2elookupBy(a_0, a_1, a_2)); heff_drop(v_ops_24309); r_; });
  V v_t_24319 = v_name_24316;
  V v_t_24321 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam10, 1, 1, (V[]){v_ps_24313}), v_args_24317));
  V v_xs_24322 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24312, v_t_24321));
  switch (heff_tag_of(v_xs_24322)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_24311, 5);
    heff_drop(v_src_24310);
    heff_drop(v_op_24318);
    return v_t_24319;
  }
  case TAG_Cons: {
    V v_x1_24325 = v_op_24318;
    V v_t_24326 = v_t_24319;
    V v_xs_24327 = v_xs_24322;
    V v_p_24348;
    switch (heff_tag_of(v_x1_24325)) {
    case TAG_Nothing: {
      V v_t_24330;
      switch (heff_tag_of(v_xs_24327)) {
      case TAG_Nil: {
        v_t_24330 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_24328 = heff_field(v_xs_24327, 0);
        V v_xs_24329 = heff_field(v_xs_24327, 1);
        heff_take_n(v_xs_24327, 3ULL, 2);
        v_t_24330 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str6); V a_1 = v_x_24328; V a_2 = v_xs_24329; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24329); r_; });
        break;
      }
      default: heff_nomatch(v_xs_24327);
      }
      v_p_24348 = heff_strAppend(heff_strAppend(v_t_24326, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str7)), v_t_24330);
      break;
    }
    case TAG_Just: {
      V v_op_24331 = heff_field(v_x1_24325, 0);
      heff_take_n(v_x1_24325, 1ULL, 1);
      switch (heff_tag_of(v_xs_24327)) {
      case TAG_Nil: {
        heff_drop(v_op_24331);
        V v_t_24334;
        switch (heff_tag_of(v_xs_24327)) {
        case TAG_Nil: {
          v_t_24334 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_24332 = heff_field(v_xs_24327, 0);
          V v_xs_24333 = heff_field(v_xs_24327, 1);
          heff_take_n(v_xs_24327, 3ULL, 2);
          v_t_24334 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str9); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
          break;
        }
        default: heff_nomatch(v_xs_24327);
        }
        v_p_24348 = heff_strAppend(heff_strAppend(v_t_24326, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str10)), v_t_24334);
        break;
      }
      case TAG_Cons: {
        V v_a_24335 = heff_dup(heff_field(v_xs_24327, 0));
        V v_xs2_24336 = heff_dup(heff_field(v_xs_24327, 1));
        switch (heff_tag_of(v_xs2_24336)) {
        case TAG_Nil: {
          heff_drop(v_op_24331);
          heff_drop(v_a_24335);
          V v_t_24339;
          switch (heff_tag_of(v_xs_24327)) {
          case TAG_Nil: {
            v_t_24339 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str11);
            break;
          }
          case TAG_Cons: {
            V v_x_24337 = heff_field(v_xs_24327, 0);
            V v_xs_24338 = heff_field(v_xs_24327, 1);
            heff_take_n(v_xs_24327, 3ULL, 2);
            v_t_24339 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str12); V a_1 = v_x_24337; V a_2 = v_xs_24338; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24338); r_; });
            break;
          }
          default: heff_nomatch(v_xs_24327);
          }
          v_p_24348 = heff_strAppend(heff_strAppend(v_t_24326, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str13)), v_t_24339);
          break;
        }
        case TAG_Cons: {
          V v_b_24340 = heff_field(v_xs2_24336, 0);
          V v_xs22_24341 = heff_field(v_xs2_24336, 1);
          heff_take_n(v_xs2_24336, 3ULL, 2);
          switch (heff_tag_of(v_xs22_24341)) {
          case TAG_Nil: {
            heff_drop(v_t_24326);
            heff_drop_tag(v_xs_24327, 2);
            V v_t_24342 = heff_strAppend(heff_strAppend(v_a_24335, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str14)), v_op_24331);
            v_p_24348 = heff_strAppend(heff_strAppend(v_t_24342, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str15)), v_b_24340);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_xs22_24341, 0ULL, 2);
            heff_drop(v_op_24331);
            heff_drop(v_a_24335);
            heff_drop(v_b_24340);
            V v_t_24347;
            switch (heff_tag_of(v_xs_24327)) {
            case TAG_Nil: {
              v_t_24347 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str16);
              break;
            }
            case TAG_Cons: {
              V v_x_24345 = heff_field(v_xs_24327, 0);
              V v_xs_24346 = heff_field(v_xs_24327, 1);
              heff_take_n(v_xs_24327, 3ULL, 2);
              v_t_24347 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str17); V a_1 = v_x_24345; V a_2 = v_xs_24346; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24346); r_; });
              break;
            }
            default: heff_nomatch(v_xs_24327);
            }
            v_p_24348 = heff_strAppend(heff_strAppend(v_t_24326, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str18)), v_t_24347);
            break;
          }
          default: heff_nomatch(v_xs22_24341);
          }
          break;
        }
        default: heff_nomatch(v_xs2_24336);
        }
        break;
      }
      default: heff_nomatch(v_xs_24327);
      }
      break;
    }
    default: heff_nomatch(v_x1_24325);
    }
    V v_t_24349 = heff_get_n(heff_dup(heff_rfield(v_s_24311, 1)), 0, 2);
    if ((heff_intLt_c_lent(MK_INT(0LL), v_t_24349, 1) && ({ V v_t_24350 = heff_get_n(heff_dup(heff_rfield(v_s_24311, 1)), 0, 2); int c_ = ({ V v_t_24396 = heff_strByteAt(heff_dup(v_src_24310), heff_intSub(heff_dup(v_t_24350), MK_INT(1LL))); int c_ = ((heff_peek_word(v_t_24396) == ((int64_t)40ULL)) && ({ V v_t_24351 = heff_get_n(heff_dup(heff_rfield(v_s_24311, 1)), 1, 2); int c_ = ({ V v_t_24397 = heff_strByteAt_lent(v_src_24310, v_t_24351, 0); int c_ = (heff_peek_word(v_t_24397) == ((int64_t)41ULL)); heff_drop(v_t_24397); c_; }); heff_drop(v_t_24351); c_; })); heff_drop(v_t_24396); c_; }); heff_drop(v_t_24350); c_; }))) {
      heff_drop_rec(v_s_24311, 5);
      heff_drop(v_src_24310);
      heff_drop(v_t_24349);
      return v_p_24348;
    } else {
      heff_drop_rec(v_s_24311, 5);
      heff_drop(v_src_24310);
      heff_drop(v_t_24349);
      return heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str19), v_p_24348), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str20));
    }
  }
  default: return heff_nomatch(v_xs_24322);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam4(V self, V *args) {
  V v_x_2494 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_2468 = heff_env(self)[2];
  V v_uri_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_24395;
  switch (heff_tag_of(v_x_2494)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop_rec(v_c_244, 14);
    heff_drop(v_s_2468);
    heff_drop(v_uri_242);
    v_x_24395 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2495 = heff_field(v_x_2494, 0);
    V v_ru_24x_2494_24Just = heff_take_reuse_n(v_x_2494, 1ULL, 1);
    V v_program_2496 = v_program_243;
    V v_c_2497 = heff_dup(v_c_244);
    V v_s_2498 = v_s_2468;
    V v_ty_2499 = v_t_2495;
    V v_t_24100 = v_ty_2499;
    V v_t_24103;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24100, 0)))) {
      V v_c_24101 = heff_strByteAt_lent(v_t_24100, MK_INT(0LL), 2);
      if (((((int64_t)65ULL) <= heff_peek_word(v_c_24101)) && (heff_peek_word(v_c_24101) <= ((int64_t)90ULL)))) {
        heff_drop(v_c_24101);
        V v_x1_24102 = (g_heff_2elsp_2esplit_2earrowOutside(v_t_24100, MK_INT(0LL), MK_INT(0LL)));
        v_t_24103 = heff_bool(!(heff_dup(v_x1_24102) == NTAG(TAG_True)));
        heff_drop(v_x1_24102);
      } else {
        heff_drop(v_c_24101);
        v_t_24103 = NTAG(TAG_False);
      }
    } else {
      v_t_24103 = NTAG(TAG_False);
    }
    V v_t_24106;
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_t_24103);
      V v_t_24104 = (g_heff_2elsp_2esplit_2enameEnd(v_t_24100, MK_INT(0LL)));
      v_t_24106 = heff_tag_at_n(v_ru_24x_2494_24Just, TAG_Just, 1, (V[]){heff_strSlice(v_t_24100, MK_INT(0LL), v_t_24104)});
    } else {
      heff_drop(v_t_24103);
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24100, 0)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_t_24100, MK_INT(0LL), 2)) == ((int64_t)40ULL))) {
          V v_x1_24105 = ({ V a_0 = v_t_24100; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V r_ = (g_heff_2elsp_2esplit_2earrowOutside(a_0, a_1, a_2)); heff_drop(v_t_24100); r_; });
          if (!(heff_dup(v_x1_24105) == NTAG(TAG_True))) {
            heff_drop(v_x1_24105);
            v_t_24106 = heff_tag_at_n(v_ru_24x_2494_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str2)});
          } else {
            heff_drop_cell(v_ru_24x_2494_24Just, 1);
            heff_drop(v_x1_24105);
            v_t_24106 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24x_2494_24Just, 1);
          heff_drop(v_t_24100);
          v_t_24106 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x_2494_24Just, 1);
        heff_drop(v_t_24100);
        v_t_24106 = NTAG(TAG_Nothing);
      }
    }
    V v_t_24365;
    switch (heff_tag_of(v_t_24106)) {
    case TAG_Nothing: {
      heff_drop(v_program_2496);
      heff_drop_rec(v_c_2497, 14);
      heff_drop_rec(v_s_2498, 5);
      v_t_24365 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_h_24107 = heff_field(v_t_24106, 0);
      V v_ru_24t_24106_24Just = heff_take_reuse_n(v_t_24106, 1ULL, 1);
      V v_program_24108 = heff_dup(v_program_2496);
      V v_c_24109 = heff_dup(v_c_2497);
      V v_x_24110 = v_h_24107;
      V v_t_24111 = heff_get_n(heff_get_n(v_c_24109, 5, 14), 0, 10);
      HeffT3 v_t_24112 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_t_24111, v_x_24110));
      V v_t_24220;
      {
        V v_field_24114 = v_t_24112.f[1];
        V v_field_24115 = v_t_24112.f[2];
        int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
        if ((v_tag_24113 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24t_24106_24Just, 1);
          heff_drop(v_program_24108);
          heff_drop(v_field_24115);
          V v_x_24116 = v_field_24114;
          heff_drop(v_x_24116);
          v_t_24220 = NTAG(TAG_Nothing);
        } else {
          if ((v_tag_24113 == ((int64_t)1ULL))) {
            heff_drop_cell(v_ru_24t_24106_24Just, 1);
            heff_drop(v_program_24108);
            heff_drop(v_field_24114);
            heff_drop(v_field_24115);
            v_t_24220 = NTAG(TAG_Nothing);
          } else {
            if ((v_tag_24113 == ((int64_t)2ULL))) {
              V v_k_24117 = v_field_24114;
              V v_x_24118 = v_field_24115;
              heff_drop(v_x_24118);
              V v_t_24125 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam5, 1, 1, (V[]){v_k_24117}), v_program_24108));
              HeffT2 v_t_24126 = ({ V a_0 = v_t_24125; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_24125); r_; });
              {
                V v_field_24128 = v_t_24126.f[1];
                int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
                if ((v_tag_24127 == ((int64_t)0ULL))) {
                  V v_d_24129 = v_field_24128;
                  switch (heff_tag_of(v_d_24129)) {
                  case TAG_At: {
                    V v_x11_24130 = heff_field(v_d_24129, 0);
                    V v_ru_24d_24129_24At = heff_take_reuse_n(v_d_24129, 1ULL, 2);
                    switch (heff_tag_of(v_x11_24130)) {
                    case TAG_DeclEquations: {
                      heff_take_n(v_x11_24130, 0ULL, 5);
                      heff_drop_cell(v_ru_24t_24106_24Just, 1);
                      heff_drop_cell(v_ru_24d_24129_24At, 2);
                      v_t_24220 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclDefine: {
                      V v_ps_24139 = heff_field(v_x11_24130, 2);
                      V v_body_24141 = heff_field(v_x11_24130, 4);
                      heff_take_n(v_x11_24130, 20ULL, 5);
                      V v_ps_24142 = (g_list_2emap_24s1170504272x1852564147(v_ps_24139));
                      V v_x2_24143 = v_body_24141;
                      switch (heff_tag_of(v_x2_24143)) {
                      case TAG_At: {
                        V v_x21_24144 = heff_field(v_x2_24143, 0);
                        heff_take_n(v_x2_24143, 1ULL, 2);
                        switch (heff_tag_of(v_x21_24144)) {
                        case TAG_EVar: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EImplicitVar: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETag: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInt: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFloat: {
                          heff_take_nf(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EString: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBinary: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ERune: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWord: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EApp: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EProject: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENamed: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EPi: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELam: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAnn: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESpec: {
                          heff_take_n(v_x21_24144, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESig: {
                          V v_fs_24170 = heff_field(v_x21_24144, 0);
                          V v_ru_24x21_24144_24ESig = heff_take_reuse_n(v_x21_24144, 1ULL, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          switch (heff_tag_of(v_fs_24170)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24106_24Just, 1);
                            heff_drop_cell(v_ru_24x21_24144_24ESig, 1);
                            v_t_24220 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24173 = (g_list_2emap_24s1387309293x1990579214(v_fs_24170));
                            V v_t_24174 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24173));
                            v_t_24220 = heff_tag_at_n(v_ru_24t_24106_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_24144_24ESig, TAG_ByFields, 1, (V[]){v_t_24174})});
                            break;
                          }
                          default: heff_nomatch(v_fs_24170);
                          }
                          break;
                        }
                        case TAG_ESum: {
                          V v_vs_24175 = heff_field(v_x21_24144, 0);
                          heff_take_n(v_x21_24144, 1ULL, 1);
                          switch (heff_tag_of(v_vs_24175)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24106_24Just, 1);
                            heff_drop_cell(v_ru_24d_24129_24At, 2);
                            heff_drop(v_ps_24142);
                            v_t_24220 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24178 = (g_list_2emap_24s580776739x648604941(v_vs_24175));
                            V v_t_24179 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24178));
                            v_t_24220 = heff_tag_at_n(v_ru_24t_24106_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24d_24129_24At, TAG_ByTags, 2, (V[]){v_ps_24142, v_t_24179})});
                            break;
                          }
                          default: heff_nomatch(v_vs_24175);
                          }
                          break;
                        }
                        case TAG_EStruct: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EUpdate: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EMatch: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELetIn: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EDo: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELocal: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInvalid: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAssign: {
                          heff_take_n(v_x21_24144, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWhile: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFor: {
                          heff_take_n(v_x21_24144, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EIfThen: {
                          heff_take_n(v_x21_24144, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBreak: {
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EContinue: {
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EReturn: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENest: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELazy: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETuple: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETry: {
                          heff_take_n(v_x21_24144, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWith: {
                          heff_take_n(v_x21_24144, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24106_24Just, 1);
                          heff_drop_cell(v_ru_24d_24129_24At, 2);
                          heff_drop(v_ps_24142);
                          v_t_24220 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_x21_24144);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x2_24143);
                      }
                      break;
                    }
                    case TAG_DeclTheory: {
                      heff_take_n(v_x11_24130, 0ULL, 4);
                      heff_drop_cell(v_ru_24t_24106_24Just, 1);
                      heff_drop_cell(v_ru_24d_24129_24At, 2);
                      v_t_24220 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclPrimitive: {
                      heff_take_n(v_x11_24130, 0ULL, 3);
                      heff_drop_cell(v_ru_24t_24106_24Just, 1);
                      heff_drop_cell(v_ru_24d_24129_24At, 2);
                      v_t_24220 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclTest: {
                      heff_take_n(v_x11_24130, 0ULL, 2);
                      heff_drop_cell(v_ru_24t_24106_24Just, 1);
                      heff_drop_cell(v_ru_24d_24129_24At, 2);
                      v_t_24220 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclWatch: {
                      heff_take_n(v_x11_24130, 0ULL, 1);
                      heff_drop_cell(v_ru_24t_24106_24Just, 1);
                      heff_drop_cell(v_ru_24d_24129_24At, 2);
                      v_t_24220 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_x11_24130);
                    }
                    break;
                  }
                  default: heff_nomatch(v_d_24129);
                  }
                } else {
                  heff_drop_cell(v_ru_24t_24106_24Just, 1);
                  heff_drop(v_field_24128);
                  v_t_24220 = NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop_cell(v_ru_24t_24106_24Just, 1);
              heff_drop(v_program_24108);
              heff_drop(v_field_24114);
              heff_drop(v_field_24115);
              v_t_24220 = NTAG(TAG_Nothing);
            }
          }
        }
      }
      switch (heff_tag_of(v_t_24220)) {
      case TAG_Nothing: {
        heff_drop(v_program_2496);
        heff_drop_rec(v_c_2497, 14);
        heff_drop_rec(v_s_2498, 5);
        v_t_24365 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_m_24221 = heff_field(v_t_24220, 0);
        V v_ru_24t_24220_24Just = heff_take_reuse_n(v_t_24220, 1ULL, 1);
        V v_t_24222 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str3), heff_dup(heff_rfield(v_s_2498, 0)));
        V v_t_24223 = (g_heff_2elsp_2esplit_2elineStart(heff_rfield(v_c_2497, 3), heff_dup(heff_rfield(v_s_2498, 2))));
        V v_t_24224 = heff_strSlice(heff_dup(heff_rfield(v_c_2497, 3)), v_t_24223, heff_dup(heff_rfield(v_s_2498, 2)));
        V v_sep_24225 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str4), v_t_24224);
        V v_program_24226 = v_program_2496;
        V v_c_24227 = heff_dup(v_c_2497);
        V v_s_24228 = heff_dup(v_s_2498);
        V v_taken_24229 = (g_heff_2elsp_2esplit_2ewordsIn(heff_rfield(v_c_2497, 3), heff_dup(heff_rfield(v_s_2498, 2)), heff_dup(heff_rfield(v_s_2498, 4)), NTAG(TAG_Nil)));
        V v_x5_24230 = v_m_24221;
        V v_t_24359;
        switch (heff_tag_of(v_x5_24230)) {
        case TAG_ByTags: {
          V v_ps_24231 = heff_field(v_x5_24230, 0);
          V v_tags_24232 = heff_field(v_x5_24230, 1);
          V v_ru_24x5_24230_24ByTags = heff_take_reuse_n(v_x5_24230, 3ULL, 2);
          V v_program_24233 = v_program_24226;
          V v_c_24234 = heff_dup(v_c_24227);
          V v_t_24235 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24233));
          V v_ops_24309 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam6, 2, 1, (V[]){v_c_24234}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24235; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24235); r_; });
          V v_src_24310 = heff_get_n(v_c_24227, 3, 14);
          V v_s_24311 = v_s_24228;
          V v_taken_24312 = v_taken_24229;
          V v_ps_24313 = v_ps_24231;
          V v_tags_24314 = v_tags_24232;
          v_t_24359 = (g_list_2emap_24tok2(v_ru_24x5_24230_24ByTags, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_lam9, 1, 5, (V[]){v_ops_24309, v_ps_24313, v_taken_24312, v_s_24311, v_src_24310}), v_tags_24314));
          break;
        }
        case TAG_ByFields: {
          V v_fs_24352 = heff_field(v_x5_24230, 0);
          heff_take_n(v_x5_24230, 1ULL, 1);
          heff_drop(v_program_24226);
          heff_drop_rec(v_c_24227, 14);
          heff_drop(v_s_24228);
          V v_xs_24353 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24229, heff_dup(v_fs_24352)));
          V v_x2_24354 = (g_list_2ezipWith_24s2130584539x811126895(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str21), v_fs_24352, v_xs_24353));
          V v_t_24357;
          switch (heff_tag_of(v_x2_24354)) {
          case TAG_Nil: {
            v_t_24357 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str22);
            break;
          }
          case TAG_Cons: {
            V v_x_24355 = heff_field(v_x2_24354, 0);
            V v_xs_24356 = heff_field(v_x2_24354, 1);
            heff_take_n(v_x2_24354, 3ULL, 2);
            v_t_24357 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str23); V a_1 = v_x_24355; V a_2 = v_xs_24356; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24356); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24354);
          }
          V v_t_24358 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str24), v_t_24357), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str25));
          v_t_24359 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24358, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_x5_24230);
        }
        V v_x2_24360 = (g_list_2emap_24s1628253759x601849359(v_c_2497, heff_dup(v_s_2498), v_t_24359));
        V v_t_24363;
        switch (heff_tag_of(v_x2_24360)) {
        case TAG_Nil: {
          heff_drop(v_sep_24225);
          v_t_24363 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str26);
          break;
        }
        case TAG_Cons: {
          V v_x_24361 = heff_field(v_x2_24360, 0);
          V v_xs_24362 = heff_field(v_x2_24360, 1);
          heff_take_n(v_x2_24360, 3ULL, 2);
          v_t_24363 = ({ V a_0 = v_sep_24225; V a_1 = v_x_24361; V a_2 = v_xs_24362; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24362); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24360);
        }
        V v_t_24364 = heff_rec_n(4, shape_title__start__end__text, (V[]){heff_strAppend(v_t_24222, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str27)), heff_take_field(v_s_2498, 2), heff_get_n(v_s_2498, 4, 5), v_t_24363});
        v_t_24365 = heff_tag_at_n(v_ru_24t_24220_24Just, TAG_Just, 1, (V[]){v_t_24364});
        break;
      }
      default: heff_nomatch(v_t_24220);
      }
      break;
    }
    default: heff_nomatch(v_t_24106);
    }
    switch (heff_tag_of(v_t_24365)) {
    case TAG_Nothing: {
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_uri_242);
      v_x_24395 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24366 = heff_field(v_t_24365, 0);
      V v_ru_24t_24365_24Just = heff_take_reuse_n(v_t_24365, 1ULL, 1);
      V v_uri_24367 = v_uri_242;
      V v_src_24368 = heff_get_n(v_c_244, 3, 14);
      V v_x_24369 = v_x_24366;
      V v_title_24370 = heff_take_field(v_x_24369, 0);
      V v_start_24371 = heff_take_field(v_x_24369, 1);
      V v_end_24372 = heff_take_field(v_x_24369, 2);
      V v_text_24373 = heff_get_n(v_x_24369, 3, 4);
      V v_t_24374 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str28), heff_tag_at_n(v_ru_24t_24365_24Just, TAG_JString, 1, (V[]){v_title_24370})});
      V v_t_24375 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str29), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str30)})});
      V v_t_24376 = v_start_24371;
      V v_t_24377 = v_end_24372;
      V v_t_24378 = (g_heff_2elsp_2elsp_2eposition(v_src_24368, heff_dup(v_t_24376)));
      V v_t_24379;
      if (heff_intLe_c_lent(v_t_24376, v_t_24377, 0)) {
        heff_drop(v_t_24376);
        v_t_24379 = v_t_24377;
      } else {
        heff_drop(v_t_24377);
        v_t_24379 = v_t_24376;
      }
      V v_t_24380 = ({ V a_0 = v_src_24368; V a_1 = v_t_24379; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_24368); r_; });
      V v_t_24381 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str31), v_t_24380}), NTAG(TAG_Nil)});
      V v_t_24382 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str32), v_t_24378}), v_t_24381});
      V v_t_24383 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str33), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24382})});
      V v_t_24384 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str34), heff_tag_n(TAG_JString, 1, (V[]){v_text_24373})});
      V v_t_24385 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24384, NTAG(TAG_Nil)});
      V v_t_24386 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24383, v_t_24385})});
      V v_t_24387 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24386, NTAG(TAG_Nil)});
      V v_t_24388 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_24367, heff_tag_n(TAG_JArray, 1, (V[]){v_t_24387})});
      V v_t_24389 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24388, NTAG(TAG_Nil)});
      V v_t_24390 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str35), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24389})});
      V v_t_24391 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24390, NTAG(TAG_Nil)});
      V v_t_24392 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_str36), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24391})});
      V v_t_24393 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24392, NTAG(TAG_Nil)});
      V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24374, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24375, v_t_24393})});
      v_x_24395 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_24394}), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24365);
    }
    break;
  }
  default: heff_nomatch(v_x_2494);
  }
  V f_ = v_z_247;
  args[0] = v_x_24395;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str0, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str1, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str2, 22, "heff failed answering ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str4, 1, ")");
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam1, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_entry, 3, 0};

V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907(V v_st_240, V v_msg_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_why_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Left = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_x1_2417;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_249 = heff_dup(heff_field(v_msg_241, 0));
      HeffT2 v_t_2410 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str0); V a_1 = v_fs_249; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_p_2413 = v_field_2412;
          V v_t_2416;
          switch (heff_tag_of(v_p_2413)) {
          case TAG_MkPair: {
            V v_y_2415 = heff_field(v_p_2413, 1);
            heff_take_n(v_p_2413, 2ULL, 2);
            v_t_2416 = v_y_2415;
            break;
          }
          default: heff_nomatch(v_p_2413);
          }
          v_x1_2417 = heff_tag_at_n(v_ru_24x3_242_24Left, TAG_Just, 1, (V[]){v_t_2416});
        } else {
          heff_drop_cell(v_ru_24x3_242_24Left, 1);
          heff_drop(v_field_2412);
          v_x1_2417 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    V v_x2_2437;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_msg_241, 0ULL, 1);
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2423 = heff_field(v_msg_241, 0);
      V v_ru_24msg_241_24JObject = heff_take_reuse_n(v_msg_241, 1ULL, 1);
      HeffT2 v_t_2424 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str1); V a_1 = v_fs_2423; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2423); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_p_2427 = v_field_2426;
          V v_t_2430;
          switch (heff_tag_of(v_p_2427)) {
          case TAG_MkPair: {
            V v_y_2429 = heff_field(v_p_2427, 1);
            heff_take_n(v_p_2427, 2ULL, 2);
            v_t_2430 = v_y_2429;
            break;
          }
          default: heff_nomatch(v_p_2427);
          }
          switch (heff_tag_of(v_t_2430)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2430, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2430, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2430, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2434 = heff_field(v_t_2430, 0);
            heff_take_n(v_t_2430, 1ULL, 1);
            v_x2_2437 = heff_tag_at_n(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_s_2434});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2430, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2430, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2437 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2430);
          }
        } else {
          heff_drop_cell(v_ru_24msg_241_24JObject, 1);
          heff_drop(v_field_2426);
          v_x2_2437 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    V v_c_2446;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nothing: {
      heff_drop(v_why_243);
      heff_drop(v_x2_2437);
      v_c_2446 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_id_2440 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      switch (heff_tag_of(v_x2_2437)) {
      case TAG_Nothing: {
        heff_drop(v_why_243);
        heff_drop(v_id_2440);
        heff_drop_cell(v_ru_24x1_2417_24Just, 1);
        v_c_2446 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam1_clo);
        break;
      }
      case TAG_Just: {
        V v_m_2443 = heff_field(v_x2_2437, 0);
        heff_take_n(v_x2_2437, 1ULL, 1);
        V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str2), v_m_2443), ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str3));
        V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, v_why_243), ((V)&g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_str4));
        v_c_2446 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24x1_2417_24Just, v_id_2440, MK_INT(-32603LL), v_t_2445));
        break;
      }
      default: heff_nomatch(v_x2_2437);
      }
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam2, 2, 2, (V[]){v_c_2446, v_st_240});
  }
  case TAG_Right: {
    V v_st2_2450 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_st_240);
    heff_drop(v_msg_241);
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam4, 2, 1, (V[]){v_st2_2450});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam0(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam1(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam3(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V f_ = v_k_2448;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam2(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam3, 1, 2, (V[]){v_k_2448, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_lam4(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_st2_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = v_st2_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry, 4, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(V v_tok_240, V v_id_241, V v_code_242, V v_msg_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str0), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str1)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_242})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_243})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str4), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str5), v_id_241}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410})});
  V v_t_2412 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_str6); V a_1 = v_t_2411; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_2411, 1); r_; });
  V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2418});
}
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(a[0], a[1], a[2], a[3]);
}