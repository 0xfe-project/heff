// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_claim 296100950
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_clo;
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(V, V);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205(V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159(V, V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_clo;
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(V, V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1032636598x1013662416(V);
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a);
extern Clo g_list_2eany_24s1032636598x1013662416_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f1037112923x126964824(V, V, V, V, V);
V g_list_2efoldl_24f1037112923x126964824_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1037112923x126964824_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s735270044x1288664053(V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2ewordEnd_str0, 12, " \011\015(){}[]:,=");
Clo g_heff_2elsp_2elsp_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewordEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewordEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(heff_strLength_lent(v_l_240, 0), v_i_241, 1) || ({ V v_t_242 = heff_strSlice_lent(v_l_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 4); int c_ = ({ V v_t_243 = heff_strFind_lent(v_t_242, ((V)&g_heff_2elsp_2elsp_2ewordEnd_str0), MK_INT(0LL), 6); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_243, 1); heff_drop(v_t_243); c_; }); heff_drop(v_t_242); c_; }))) {
    return v_i_241;
  } else {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str7, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str9, 1, " ");
Clo g_heff_2elsp_2elsp_2ekeyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeyOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeyOf(V v_l_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_l_240));
  {
    V v_field_242 = v_t_241.f[0];
    heff_drop(v_t_241.f[1]);
    HeffT2 v_t_244 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_l_240));
    {
      V v_field_246 = v_t_244.f[1];
      heff_drop(v_t_244.f[0]);
      V v_t_247 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_w_248 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_247, 6);
      V v_t_2410;
      if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str0), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str1), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str2), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str3), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str4), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str5), v_w_248, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str6), v_w_248, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2ekeyOf_str7), v_w_248, 1))))))))) {
        heff_drop(v_w_248);
        V v_t_249 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
        v_t_2410 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_249, 6);
      } else {
        heff_drop(v_w_248);
        v_t_2410 = ((V)&g_heff_2elsp_2elsp_2ekeyOf_str8);
      }
      V v_t_2411 = heff_strAppend(heff_strSlice_lent(v_l_240, v_field_242, v_field_246, 6), ((V)&g_heff_2elsp_2elsp_2ekeyOf_str9));
      return heff_strAppend(v_t_2411, v_t_2410);
    }
  }
}
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ekeyOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s1441124185x871809048(heff_dup(v_s_241), v_ss_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_s_241, heff_hole()});
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_local_243 = heff_take_field(v_target_242, 2);
  V v_member_244 = heff_take_field(v_target_242, 1);
  V v_t_245 = v_local_243;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = v_member_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_249 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_2410 = (heff_unbox_word(heff_strLength(v_t_248)) - heff_unbox_word(v_t_249));
      V v_t_2411 = heff_strAppend(heff_strSlice(v_t_247, MK_INT(0LL), heff_box_word(v_t_2410)), v_new_241);
      return ({ V rv_0 = v_t_2411; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_target_242, 0ULL, 3, shape_key__member__local, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      V v_t_2413 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return ({ V rv_0 = v_t_2413; V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_new_241}); V rv_2 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_target_242, 0ULL, 3, shape_key__member__local, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_Just: {
    V v_b_2414 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_member_244);
    V v_path_2415 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
    V v_t_2416 = (g_list_2efoldl_24f1037112923x126964824(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2414), heff_rfield(v_t_240, 3)));
    V v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2417));
    V v_s_2419 = heff_intAdd(heff_dup(heff_rfield(v_b_2414, 0)), heff_intMul(heff_box_word(v_t_2418), v_t_2416));
    V v_t_2420 = (g_list_2efoldl_24f1037112923x126964824(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2414), heff_rfield(v_t_240, 3)));
    V v_t_2421 = heff_strLength(heff_get_n(v_t_240, 2, 4));
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2421));
    V v_t_2423 = heff_intAdd(heff_take_field(v_b_2414, 0), heff_intMul(heff_box_word(v_t_2422), v_t_2420));
    V v_e_2424 = heff_intAdd(v_t_2423, heff_strLength(v_new_241));
    V v_t_2425 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){({ V rv_0 = v_s_2419; V rv_1 = v_e_2424; V rr_ = heff_rec_reuse_nf(v_b_2414, 0ULL, 2, shape_start__end, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
    return ({ V rv_0 = v_path_2415; V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_target_242, 0ULL, 3, shape_key__member__local, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1836353438x580818415(heff_dup(v_c_243), v_changed_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
      V v_u_248 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_247, v_rest_244, v_cell_246));
      heff_drop(v_u_248);
      return v_cell_246;
    } else {
      heff_drop(v_t_245);
      V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
        V v_u_2413 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2412, v_rest_244, v_cell_2411));
        heff_drop(v_u_2413);
        return v_cell_2411;
      } else {
        heff_drop_rec(v_c_243, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2410);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_249; V a_1 = v_mods_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_d_249); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_entry, 5, 0};

V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871(V v_st_240, V v_f_241, V v_d_242, V v_z_243, V v_z_244) {
top: ;
  V v_docs_245 = heff_take_field(v_st_240, 0);
  V v_lib_246 = heff_get_n(v_st_240, 6, 7);
  V v_c_2431 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam0, 1, 1, (V[]){v_docs_245}), v_lib_246, v_f_241));
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam5, 1, 3, (V[]){v_z_243, v_d_242, v_z_244})});
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_d_2411 = heff_env(self)[0];
  heff_drop(v_hd_2412);
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2411, 1, 2)});
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2420 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2420;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      heff_take_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2420;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2420;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2430});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_a_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2418})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2425, v_hd_2419, heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam4, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_docs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_docs_245; V a_1 = v_p_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_245); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_p_247);
      V v_d_2411 = v_field_2410;
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam1, 2, 1, (V[]){v_d_2411});
    } else {
      heff_drop(v_field_2410);
      V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_247));
      V v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
      V v_a_2418 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2416, ((V)&g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam2_clo)});
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam3, 2, 1, (V[]){v_a_2418});
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2439; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_full_2435 = heff_get_n(v_x_2434, 0, 2);
  V v_program_2436 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2435)));
  V v_t_2437 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2435));
  heff_clo_take(self, 3);
  V v_t_2438 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2437, heff_get_n(v_x_2432, 1, 5)));
  V v_diags_2440 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam7, 1, 1, (V[]){v_d_242}), v_t_2438));
  V f_ = v_z_244;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2436, v_diags_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_t_2433 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_x_2432)));
  heff_clo_take(self, 3);
  V f_ = v_t_2433;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_lam6, 1, 3, (V[]){v_d_242, v_x_2432, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_entry, 3, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547(v_st_240, v_c_241, v_rest_246));
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_entry, 5, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(V v_st_240, V v_query_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam0, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s346258249x590818547(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2410));
    return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam1, 1, 5, (V[]){v_st_240, heff_dup(v_query_241), heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam0(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  V v_s_249 = ({ V b_0 = heff_get_n(v_y_248, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_query_241, v_s_249, MK_INT(0LL), 4)));
  heff_drop(self);
  heff_drop(v_s_249);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2414 = (g_prelude_2e_2b_2b(v_x_2412, v_x_2413));
  V f_ = v_z_244;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_lam2, 1, 2, (V[]){v_x_2412, v_z_244}); V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_query_241); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_entry, 4, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159(V v_a_240, V v_p_241, V v_z_242, V v_z_243) {
top: ;
  V v_program_244 = heff_take_field(v_a_240, 2);
  V v_text_245 = heff_take_field(v_a_240, 1);
  V v_st_246 = heff_get_n(v_a_240, 0, 3);
  V v_c_247 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(heff_dup(v_p_241)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_lam0, 1, 6, (V[]){v_z_243, v_program_244, v_p_241, v_text_245, v_st_246, v_z_242})});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_program_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_text_245 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_z_242 = heff_env(self)[5];
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_clo_take(self, 6);
    heff_drop(v_program_244);
    heff_drop(v_p_241);
    heff_drop(v_text_245);
    heff_drop(v_st_246);
    heff_drop(v_z_242);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_244)));
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Nil: {
      heff_clo_take(self, 6);
      heff_drop(v_program_244);
      heff_drop(v_p_241);
      heff_drop(v_text_245);
      heff_drop(v_st_246);
      heff_drop(v_z_242);
      heff_drop(v_f_249);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Cons = heff_take_reuse_n(v_x1_2410, 1ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_2410_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2414 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str1), v_t_2413}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        V v_t_2424;
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_it1_2417 = v_field_2416;
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JArray: {
            V v_xs_2422 = heff_field(v_it1_2417, 0);
            heff_take_n(v_it1_2417, 1ULL, 1);
            v_t_2424 = ({ V a_0 = v_xs_2422; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2422); r_; });
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it1_2417);
          }
        } else {
          heff_drop(v_field_2416);
          v_t_2424 = NTAG(TAG_True);
        }
        if (((heff_dup(v_t_2424) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2411, 3)), heff_dup(v_text_245)))) {
          heff_drop(v_t_2424);
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str2), NTAG(TAG_Nil)});
          HeffT2 v_t_2426 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str3), v_t_2425}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2428 = v_t_2426.f[1];
            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
            V v_t_2436;
            if ((v_tag_2427 == ((int64_t)0ULL))) {
              V v_it1_2429 = v_field_2428;
              switch (heff_tag_of(v_it1_2429)) {
              case TAG_JNull: {
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str4);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str5);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str6);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str7);
                break;
              }
              case TAG_JString: {
                V v_s_2433 = heff_field(v_it1_2429, 0);
                heff_take_n(v_it1_2429, 1ULL, 1);
                v_t_2436 = v_s_2433;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str8);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str9);
                break;
              }
              default: heff_nomatch(v_it1_2429);
              }
            } else {
              heff_drop(v_field_2428);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str10);
            }
            V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str11), NTAG(TAG_Nil)});
            V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str13), v_t_2437})});
            HeffT2 v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2438, 2); r_; });
            {
              V v_field_2441 = v_t_2439.f[1];
              int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
              V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str14), NTAG(TAG_Nil)});
              V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_str16), v_t_2442})});
              heff_clo_take(self, 6);
              HeffT2 v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = v_p_241; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2443, 2); r_; });
              {
                V v_field_2446 = v_t_2444.f[1];
                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                V v_t_2454;
                if ((v_tag_2440 == ((int64_t)0ULL))) {
                  V v_it1_2447 = v_field_2441;
                  switch (heff_tag_of(v_it1_2447)) {
                  case TAG_JNull: {
                    v_t_2454 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2447, 0ULL, 1);
                    v_t_2454 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JInt: {
                    V v_i_2449 = heff_field(v_it1_2447, 0);
                    heff_take_n(v_it1_2447, 1ULL, 1);
                    v_t_2454 = v_i_2449;
                    break;
                  }
                  case TAG_JFloat: {
                    double v_x_2450 = heff_tflat_f64(v_it1_2447, 0);
                    heff_take_na(v_it1_2447, 0ULL, 1);
                    v_t_2454 = heff_floor_f64(v_x_2450);
                    break;
                  }
                  case TAG_JString: {
                    heff_take_n(v_it1_2447, 0ULL, 1);
                    v_t_2454 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2447, 0ULL, 1);
                    v_t_2454 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2447, 0ULL, 1);
                    v_t_2454 = MK_INT(0LL);
                    break;
                  }
                  default: heff_nomatch(v_it1_2447);
                  }
                } else {
                  heff_drop(v_field_2441);
                  v_t_2454 = MK_INT(0LL);
                }
                V v_t_2462;
                if ((v_tag_2445 == ((int64_t)0ULL))) {
                  V v_it1_2455 = v_field_2446;
                  switch (heff_tag_of(v_it1_2455)) {
                  case TAG_JNull: {
                    v_t_2462 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2455, 0ULL, 1);
                    v_t_2462 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JInt: {
                    V v_i_2457 = heff_field(v_it1_2455, 0);
                    heff_take_n(v_it1_2455, 1ULL, 1);
                    v_t_2462 = v_i_2457;
                    break;
                  }
                  case TAG_JFloat: {
                    double v_x_2458 = heff_tflat_f64(v_it1_2455, 0);
                    heff_take_na(v_it1_2455, 0ULL, 1);
                    v_t_2462 = heff_floor_f64(v_x_2458);
                    break;
                  }
                  case TAG_JString: {
                    heff_take_n(v_it1_2455, 0ULL, 1);
                    v_t_2462 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2455, 0ULL, 1);
                    v_t_2462 = MK_INT(0LL);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2455, 0ULL, 1);
                    v_t_2462 = MK_INT(0LL);
                    break;
                  }
                  default: heff_nomatch(v_it1_2455);
                  }
                } else {
                  heff_drop(v_field_2446);
                  v_t_2462 = MK_INT(0LL);
                }
                V v_t_2463 = ({ V a_0 = v_text_245; V a_1 = v_t_2454; V a_2 = v_t_2462; V a_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eoffsetGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_245); r_; });
                return (g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285(v_st_246, v_f_249, v_t_2436, v_program_244, v_x_2411, v_t_2463, v_z_242, v_z_243));
              }
            }
          }
        } else {
          heff_clo_take(self, 6);
          heff_drop(v_program_244);
          heff_drop(v_p_241);
          heff_drop(v_text_245);
          heff_drop(v_st_246);
          heff_drop(v_z_242);
          heff_drop(v_f_249);
          heff_drop_rec(v_x_2411, 14);
          heff_drop(v_t_2424);
          V f_ = v_z_243;
          args[0] = NTAG(TAG_Nil);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str2, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str3, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str4, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str5, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str6, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str7, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str8, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str9, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str10, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str11, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str13, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str14, 2, "\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str15, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str16, 1, " ");
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_entry, 4, 0};

V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205(V v_st_240, V v_p_241, V v_z_242, V v_z_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(heff_dup(v_p_241)));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam0, 1, 4, (V[]){v_z_243, v_st_240, v_p_241, v_z_242})});
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam1(V self, V *args) {
  V v_x_2438 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_d_2439 = v_d_2410;
  V v_text_2440 = heff_take_field(v_d_2439, 1);
  V v_uri_2441 = heff_get_n(v_d_2439, 0, 2);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str7), NTAG(TAG_Nil)});
  HeffT2 v_t_2443 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str8), v_t_2442}); V a_1 = v_p_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    V v_t_2453;
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_it1_2446 = v_field_2445;
      switch (heff_tag_of(v_it1_2446)) {
      case TAG_JNull: {
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2446, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2446, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2446, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2446, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2451 = heff_field(v_it1_2446, 0);
        heff_take_n(v_it1_2446, 1ULL, 1);
        v_t_2453 = v_xs_2451;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2446, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2446);
      }
    } else {
      heff_drop(v_field_2445);
      v_t_2453 = NTAG(TAG_Nil);
    }
    V v_ds_2454 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str9); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str10); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str11); V a_3 = v_t_2453; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_x3_2455 = v_x_2438;
    V v_x_2484;
    switch (heff_tag_of(v_x3_2455)) {
    case TAG_Nothing: {
      heff_drop(v_text_2440);
      heff_drop(v_uri_2441);
      heff_drop(v_ds_2454);
      v_x_2484 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_n_2456 = heff_field(v_x3_2455, 0);
      V v_ru_24x3_2455_24Just = heff_take_reuse_n(v_x3_2455, 1ULL, 1);
      V v_src_2457 = heff_dup(v_text_2440);
      V v_n_2458 = heff_dup(v_n_2456);
      V v_t_2459 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_text_2440), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
      V v_x3_2460 = heff_get_n(v_t_2459, 2, 4);
      V v_t_2481;
      switch (heff_tag_of(v_x3_2460)) {
      case TAG_Nothing: {
        V v_t_2461;
        if (heff_strEq_c(v_src_2457, ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str12))) {
          v_t_2461 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str13);
        } else {
          v_t_2461 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str14);
        }
        V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str15), v_n_2458), v_t_2461);
        v_t_2481 = heff_tag_at_n(v_ru_24x3_2455_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), v_t_2462})});
        break;
      }
      case TAG_Just: {
        V v_h_2463 = heff_field(v_x3_2460, 0);
        heff_take_n(v_x3_2460, 1ULL, 1);
        V v_t_2464 = heff_dup(heff_rfield(v_h_2463, 0));
        switch (heff_tag_of(v_t_2464)) {
        case TAG_Nothing: {
          heff_drop(v_src_2457);
          V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_h_2463, 3)), 0, 2);
          V v_t_2466 = heff_get_n(heff_get_n(v_h_2463, 3, 5), 0, 2);
          V v_t_2467 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_t_2465, MK_INT(6LL)), heff_intAdd(v_t_2466, MK_INT(6LL))});
          V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2467, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str16), v_n_2458)});
          v_t_2481 = heff_tag_at_n(v_ru_24x3_2455_24Just, TAG_Just, 1, (V[]){v_t_2468});
          break;
        }
        case TAG_Just: {
          V v_m_2469 = heff_field(v_t_2464, 0);
          heff_take_n(v_t_2464, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_2469, v_n_2458, 0)) {
            heff_drop_cell(v_ru_24x3_2455_24Just, 1);
            heff_drop(v_src_2457);
            heff_drop(v_n_2458);
            heff_drop_rec(v_h_2463, 5);
            heff_drop(v_m_2469);
            v_t_2481 = NTAG(TAG_Nothing);
          } else {
            V v_src_2470 = v_src_2457;
            V v_h_2471 = v_h_2463;
            V v_m_2472 = v_m_2469;
            V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_h_2471, 3)), 0, 2);
            V v_from_2474 = heff_intAdd(v_t_2473, MK_INT(6LL));
            V v_t_2475 = heff_get_n(heff_get_n(v_h_2471, 3, 5), 1, 2);
            V v_j_2476 = heff_strFind(heff_dup(v_m_2472), heff_strSlice_lent(v_src_2470, v_from_2474, v_t_2475, 5), MK_INT(0LL));
            V v_t_2477;
            if (heff_intLt_c_lent(v_j_2476, MK_INT(0LL), 2)) {
              heff_drop(v_j_2476);
              v_t_2477 = MK_INT(1LL);
            } else {
              v_t_2477 = v_j_2476;
            }
            V v_at_2478 = heff_intAdd(v_from_2474, v_t_2477);
            V v_e_2479 = heff_intAdd(heff_dup(v_at_2478), heff_strLength(v_m_2472));
            V v_t_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_at_2478, v_e_2479}), v_n_2458});
            v_t_2481 = heff_tag_at_n(v_ru_24x3_2455_24Just, TAG_Just, 1, (V[]){v_t_2480});
          }
          break;
        }
        default: heff_nomatch(v_t_2464);
        }
        break;
      }
      default: heff_nomatch(v_x3_2460);
      }
      switch (heff_tag_of(v_t_2481)) {
      case TAG_Nothing: {
        heff_drop(v_text_2440);
        heff_drop(v_uri_2441);
        heff_drop(v_ds_2454);
        heff_drop(v_n_2456);
        v_x_2484 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2482 = heff_field(v_t_2481, 0);
        heff_take_n(v_t_2481, 1ULL, 1);
        V v_t_2483 = ({ V a_0 = v_uri_2441; V a_1 = v_text_2440; V a_2 = v_n_2456; V a_3 = v_ds_2454; V a_4 = v_x_2482; V r_ = (g_heff_2elsp_2elsp_2eclaimAction(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_2440); r_; });
        v_x_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2481);
      }
      break;
    }
    default: heff_nomatch(v_x3_2455);
    }
    V f_ = v_z_243;
    args[0] = v_x_2484;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_clo_take(self, 4);
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_p_241);
    heff_drop(v_z_242);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_d_2410 = v_field_249;
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2412 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str1), v_t_2411}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          V v_t_2422;
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_it1_2415 = v_field_2414;
            switch (heff_tag_of(v_it1_2415)) {
            case TAG_JNull: {
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JArray: {
              V v_xs_2420 = heff_field(v_it1_2415, 0);
              heff_take_n(v_it1_2415, 1ULL, 1);
              v_t_2422 = ({ V a_0 = v_xs_2420; V r_ = (g_list_2eany_24s1032636598x1013662416(a_0)); heff_drop(v_xs_2420); r_; });
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it1_2415);
            }
          } else {
            heff_drop(v_field_2414);
            v_t_2422 = NTAG(TAG_True);
          }
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str2), NTAG(TAG_Nil)});
            HeffT2 v_t_2424 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str3), v_t_2423}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              V v_t_2434;
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                V v_it1_2427 = v_field_2426;
                switch (heff_tag_of(v_it1_2427)) {
                case TAG_JNull: {
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JArray: {
                  V v_xs_2432 = heff_field(v_it1_2427, 0);
                  heff_take_n(v_it1_2427, 1ULL, 1);
                  v_t_2434 = v_xs_2432;
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                default: heff_nomatch(v_it1_2427);
                }
              } else {
                heff_drop(v_field_2426);
                v_t_2434 = NTAG(TAG_Nil);
              }
              V v_x1_2435 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str4); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str5); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_str6); V a_3 = v_t_2434; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
              switch (heff_tag_of(v_x1_2435)) {
              case TAG_Nil: {
                heff_clo_take(self, 4);
                heff_drop_rec(v_st_240, 7);
                heff_drop(v_p_241);
                heff_drop(v_z_242);
                heff_drop(v_f_246);
                heff_drop(v_d_2410);
                V f_ = v_z_243;
                args[0] = NTAG(TAG_Nil);
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Cons: {
                heff_take_n(v_x1_2435, 0ULL, 2);
                heff_clo_take(self, 4);
                return (g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(v_st_240, v_f_246, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_lam1, 1, 3, (V[]){v_d_2410, v_p_241, v_z_243})));
              }
              default: return heff_nomatch(v_x1_2435);
              }
            }
          } else {
            heff_clo_take(self, 4);
            heff_drop_rec(v_st_240, 7);
            heff_drop(v_p_241);
            heff_drop(v_z_242);
            heff_drop(v_f_246);
            heff_drop(v_d_2410);
            heff_drop(v_t_2422);
            V f_ = v_z_243;
            args[0] = NTAG(TAG_Nil);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_clo_take(self, 4);
        heff_drop_rec(v_st_240, 7);
        heff_drop(v_p_241);
        heff_drop(v_z_242);
        heff_drop(v_f_246);
        heff_drop(v_field_249);
        V f_ = v_z_243;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str0, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str1, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str2, 22, "heff failed answering ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str4, 1, ")");
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam1, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_entry, 5, 0};

V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503(V v_st_240, V v_msg_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_why_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Left = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_x1_2419;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24x3_242_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2411 = heff_dup(heff_field(v_msg_241, 0));
      HeffT2 v_t_2412 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str0); V a_1 = v_fs_2411; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2411); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_p_2415 = v_field_2414;
          V v_t_2418;
          switch (heff_tag_of(v_p_2415)) {
          case TAG_MkPair: {
            V v_y_2417 = heff_field(v_p_2415, 1);
            heff_take_n(v_p_2415, 2ULL, 2);
            v_t_2418 = v_y_2417;
            break;
          }
          default: heff_nomatch(v_p_2415);
          }
          v_x1_2419 = heff_tag_at_n(v_ru_24x3_242_24Left, TAG_Just, 1, (V[]){v_t_2418});
        } else {
          heff_drop_cell(v_ru_24x3_242_24Left, 1);
          heff_drop(v_field_2414);
          v_x1_2419 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    V v_x2_2439;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_msg_241, 0ULL, 1);
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_msg_241, 0ULL, 1);
      v_x2_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2425 = heff_field(v_msg_241, 0);
      V v_ru_24msg_241_24JObject = heff_take_reuse_n(v_msg_241, 1ULL, 1);
      HeffT2 v_t_2426 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str1); V a_1 = v_fs_2425; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2425); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_p_2429 = v_field_2428;
          V v_t_2432;
          switch (heff_tag_of(v_p_2429)) {
          case TAG_MkPair: {
            V v_y_2431 = heff_field(v_p_2429, 1);
            heff_take_n(v_p_2429, 2ULL, 2);
            v_t_2432 = v_y_2431;
            break;
          }
          default: heff_nomatch(v_p_2429);
          }
          switch (heff_tag_of(v_t_2432)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2432, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2432, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2432, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2436 = heff_field(v_t_2432, 0);
            heff_take_n(v_t_2432, 1ULL, 1);
            v_x2_2439 = heff_tag_at_n(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_s_2436});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2432, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2432, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_241_24JObject, 1);
            v_x2_2439 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
        } else {
          heff_drop_cell(v_ru_24msg_241_24JObject, 1);
          heff_drop(v_field_2428);
          v_x2_2439 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    V v_c_2448;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nothing: {
      heff_drop(v_why_245);
      heff_drop(v_x2_2439);
      v_c_2448 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_id_2442 = heff_field(v_x1_2419, 0);
      V v_ru_24x1_2419_24Just = heff_take_reuse_n(v_x1_2419, 1ULL, 1);
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nothing: {
        heff_drop(v_why_245);
        heff_drop(v_id_2442);
        heff_drop_cell(v_ru_24x1_2419_24Just, 1);
        v_c_2448 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam1_clo);
        break;
      }
      case TAG_Just: {
        V v_m_2445 = heff_field(v_x2_2439, 0);
        heff_take_n(v_x2_2439, 1ULL, 1);
        V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str2), v_m_2445), ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str3));
        V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, v_why_245), ((V)&g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_str4));
        v_c_2448 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24x1_2419_24Just, v_id_2442, MK_INT(-32603LL), v_t_2447));
        break;
      }
      default: heff_nomatch(v_x2_2439);
      }
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tail(v_c_2448, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam2, 1, 2, (V[]){v_z_244, v_st_240})});
  }
  case TAG_Right: {
    V v_st2_2450 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_st_240);
    heff_drop(v_msg_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st2_2450});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam0(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam1(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_lam2(V self, V *args) {
  V v_x_2449 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2449);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}