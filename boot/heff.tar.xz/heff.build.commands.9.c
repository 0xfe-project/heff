// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_bin 307073
#define LBL_c 317
#define LBL_command 1182252425
#define LBL_copies 592412158
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_segments 1801007612
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_zig 330130
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_clo;
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2ecErased(V, V);
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecErased_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s529567056x880977707(V, V, V);
V g_list_2eany_24s529567056x880977707_entry(V self, V *a);
extern Clo g_list_2eany_24s529567056x880977707_clo;
V g_list_2efilter_24s794048906x2073543501(V, V);
V g_list_2efilter_24s794048906x2073543501_entry(V self, V *a);
extern Clo g_list_2efilter_24s794048906x2073543501_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1022228162x792599878(V, V);
V g_list_2efoldl_24s1022228162x792599878_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1022228162x792599878_clo;
V g_list_2efoldl_24s1032373580x351779613(V, V);
V g_list_2efoldl_24s1032373580x351779613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1032373580x351779613_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s239465670x1559235816(V, V);
V g_list_2efoldl_24s239465670x1559235816_entry(V self, V *a);
extern Clo g_list_2efoldl_24s239465670x1559235816_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s708435384x833942752(V, V, V, V, V, V, V, V);
V g_list_2emap_24s708435384x833942752_entry(V self, V *a);
extern Clo g_list_2emap_24s708435384x833942752_clo;
V g_list_2emap_24s764064723x821001015(V);
V g_list_2emap_24s764064723x821001015_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3);
        V v_s_248 = heff_strAppend(v_s_247, heff_dup(v_b_243));
        V v_s_249 = heff_strAppend(v_s_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_std_2epath_2ejoin(heff_rfield(v_paths_240, 5), heff_take_field(v_paths_240, 0), ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_xs_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = heff_dup(v_p_243); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = heff_get_n(v_p_243, 2, 3); V r_ = (g_list_2efoldl_24s1725521117x1379101383(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_x2_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_p_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_p_248 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_p_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return ({ V b_0 = heff_get_n(v_paths_240, 5, 6); V a_1 = v_d_242; V a_2 = v_p_248; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
  V v_t_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
    V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
    v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_244 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_245 = (g_list_2emap_24s708435384x833942752(((V)&g_heff_2ebuild_2ecommands_2estatistic_str3), heff_dup(v_o_240), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), heff_get_n(v_o_240, 7, 12)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_248));
  return heff_strAppend(v_t_241, v_t_249);
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(v_t_242, heff_dup(v_j_241)));
  V v_t_2414;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_248 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        v_t_2414 = v_b_248;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_245);
      v_t_2414 = NTAG(TAG_False);
    }
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1), NTAG(TAG_Nil)});
  HeffT2 v_t_2416 = (g_json_2eat_24cpr(v_t_2415, heff_dup(v_j_241)));
  V v_t_2427;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_it1_2420 = v_field_2418;
      switch (heff_tag_of(v_it1_2420)) {
      case TAG_JNull: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2424 = heff_field(v_it1_2420, 0);
        V v_ru_24it1_2420_24JString = heff_take_reuse_n(v_it1_2420, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24it1_2420_24JString, TAG_Just, 1, (V[]){v_s_2424});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2420);
      }
    } else {
      heff_drop(v_field_2418);
      v_t_2427 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2429 = (g_json_2eat_24cpr(v_t_2428, heff_dup(v_j_241)));
  V v_t_2440;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_it1_2433 = v_field_2431;
      switch (heff_tag_of(v_it1_2433)) {
      case TAG_JNull: {
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2438 = heff_field(v_it1_2433, 0);
        heff_take_n(v_it1_2433, 1ULL, 1);
        v_t_2440 = v_xs_2438;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2433);
      }
    } else {
      heff_drop(v_field_2431);
      v_t_2440 = NTAG(TAG_Nil);
    }
  }
  V v_t_2441 = (g_list_2emap_24s1618539892x552009225(v_t_2440));
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3), NTAG(TAG_Nil)});
  HeffT2 v_t_2443 = (g_json_2eat_24cpr(v_t_2442, heff_dup(v_j_241)));
  V v_t_2448;
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_f_2447 = v_field_2445;
      v_t_2448 = (g_heff_2ebuild_2ecommands_2ejsonFailure(v_f_2447));
    } else {
      heff_drop(v_field_2445);
      v_t_2448 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2450 = (g_json_2eat_24cpr(v_t_2449, v_j_241));
  V v_t_2461;
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_it1_2454 = v_field_2452;
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_JNull: {
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2459 = heff_field(v_it1_2454, 0);
        heff_take_n(v_it1_2454, 1ULL, 1);
        v_t_2461 = v_xs_2459;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2454);
      }
    } else {
      heff_drop(v_field_2452);
      v_t_2461 = NTAG(TAG_Nil);
    }
  }
  V v_t_2462 = (g_list_2emap_24s809490196x1189312632(v_t_2461));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2414, v_t_2427, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2441, v_t_2448, MK_INT(0LL), v_t_2462});
}
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeOfJson(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_t_246 = (g_regex_2ematches(v_r_242, v_n_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str1)));
  V v_t_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_245), heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s94900133x232571340(v_t_2412, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam1, 1, 4, (V[]){v_text_241, v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam2(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_text_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    V v_t_2414 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str2), heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_str3)));
    V v_t_2417 = heff_tag_n(TAG_Replace, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_2415), v_path_240, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_lam2_clo)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s94900133x232571340(v_t_2422, v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2413);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str2, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(v_t_249, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240}));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam4(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_b_2418 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781(v_ps_240, v_b_2418, v_x_2428));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_b_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Just = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_d_2419 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str1)));
    V v_d_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2419, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_2421 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2420, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_str2)));
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2417_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2421, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam4_clo)})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam5, 1, 4, (V[]){v_ps_240, v_b_2418, v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_lam3, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241})));
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = heff_get_n(heff_get_n(v_c_244, 5, 13), 0, 9);
  V v_t_2413 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2414 = (g_list_2emap_24s1173914895x100384474(v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1022228162x792599878(heff_dup(g_std_2emap_2eempty_get()), v_bs_2414));
  V v_t_2416 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2414; V r_ = (g_list_2efoldl_24s1032373580x351779613(a_0, a_1)); heff_drop(v_bs_2414); r_; });
  V v_t_2417 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s239465670x1559235816(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2420 = ({ V a_0 = heff_take_field(v_rt_242, 0); V a_1 = v_available_245; V a_2 = v_t_2412; V a_3 = heff_take_field(v_r_246, 0); V a_4 = heff_get_n(v_r_246, 1, 2); V a_5 = heff_dup(heff_rfield(v_bi_240, 1)); V a_6 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2415, v_t_2416}); V a_7 = v_t_2419; V r_ = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2419); r_; });
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277(v_bi_240, v_dir_241, heff_get_n(v_rt_242, 1, 2), v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2420, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str12, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str13, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam8(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2412;
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam0, 1, 1, (V[]){heff_dup(v_c_2414)}), heff_dup(heff_rfield(v_c_2414, 7))));
      V v_t_2423 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
      V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2423); r_; });
      V v_t_2425 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2424));
      V v_xs_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str3); V a_6 = v_t_2425; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2427 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2426));
      V v_c_2428 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(v_sources_241, v_t_2427));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam1, 1, 9, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2414, v_z_249, v_file_242, v_failed_245, v_bi_240, v_done_246})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str13), NTAG(TAG_MkUnit)});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam8, 1, 2, (V[]){v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam0(V self, V *args) {
  V v_o_2415 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2414, heff_rfield(v_o_2415, 1)));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_eff_2420 = v_field_2418;
      V v_t_2421 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2415, 0), heff_get_n(v_o_2415, 1, 2), v_eff_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    } else {
      heff_drop_rec(v_o_2415, 2);
      heff_drop(v_field_2418);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam4(V self, V *args) {
  V v_ok_2437 = args[0];
  return v_ok_2437;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_c_2414 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_bool(!(heff_dup(v_x_2444) == NTAG(TAG_True)));
  heff_drop(v_x_2444);
  V v_exports_2446 = (g_list_2emap_24s764064723x821001015(heff_take_field(v_c_2414, 7)));
  V v_roots_2447 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2446)));
  V v_t_2448 = heff_get_n(heff_get_n(v_c_2414, 5, 13), 0, 9);
  V v_t_2449 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2448));
  V v_t_2450 = (g_heff_2ecompile_2elower_2ecErased(v_roots_2447, v_t_2449));
  V v_t_2451 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2430, v_exports_2446, v_t_2450));
  return ({ V a_0 = v_outPath_244; V a_1 = v_t_2445; V a_2 = v_t_2451; V a_3 = v_z_248; V a_4 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2445); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam6(V self, V *args) {
  V v_o_2453 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2454 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2414, heff_rfield(v_o_2453, 1)));
  {
    V v_field_2456 = v_t_2454.f[1];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    if ((v_tag_2455 == ((int64_t)0ULL))) {
      V v_eff_2458 = v_field_2456;
      V v_t_2459 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2453, 0), heff_get_n(v_o_2453, 1, 2), v_eff_2458});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2459});
    } else {
      heff_drop_rec(v_o_2453, 2);
      heff_drop(v_field_2456);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam7(V self, V *args) {
  V v_x_2484 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_why_2475 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_strAppend(v_file_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str11), v_why_2475));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str12), v_t_2485);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_x_2429 = heff_env(self)[6];
  V v_file_242 = heff_env(self)[7];
  V v_failed_245 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2429);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_bi_240);
    heff_drop(v_done_246);
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2433 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2432), heff_strLength_lent(v_outPath_244, 0));
    V v_t_2436;
    if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str6))) {
      int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2436 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2435), 6);
    } else {
      v_t_2436 = heff_dup(v_outPath_244);
    }
    V v_t_2438 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str7)), v_x_2431, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam4_clo)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s94900133x232571340(v_t_2443, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam5, 1, 5, (V[]){v_c_2414, v_x_2430, v_outPath_244, v_z_248, v_z_249})));
  }
  case TAG_Just: {
    V v_t_2460 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam6, 1, 1, (V[]){heff_dup(v_c_2414)}), heff_dup(heff_rfield(v_c_2414, 7))));
    V v_t_2461 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2460));
    V v_t_2462 = ({ V a_0 = v_t_2461; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2461); r_; });
    V v_leaves_2463 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2462));
    V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 0, 9);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2429)}));
    V v_t_2466 = (g_list_2emap_24s164225955x66209884(v_t_2464, v_t_2465, v_leaves_2463));
    HeffT2 v_t_2467 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2466));
    V v_t_2474;
    {
      V v_field_2469 = v_t_2467.f[1];
      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
      if ((v_tag_2468 == ((int64_t)0ULL))) {
        V v_why_2471 = v_field_2469;
        v_t_2474 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2471});
      } else {
        V v_ms_2472 = v_field_2469;
        V v_t_2473 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2472));
        v_t_2474 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2473});
      }
    }
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Left: {
      V v_why_2475 = heff_field(v_t_2474, 0);
      V v_ru_24t_2474_24Left = heff_take_reuse_n(v_t_2474, 1ULL, 1);
      heff_drop(v_x_2431);
      heff_drop_tag(v_name_243, 1);
      heff_drop(v_outPath_244);
      heff_drop_rec(v_c_2414, 13);
      heff_drop(v_x_2430);
      heff_drop(v_x_2429);
      heff_drop(v_bi_240);
      heff_drop(v_done_246);
      V v_t_2476 = heff_strAppend(heff_dup(v_file_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str8), heff_dup(v_why_2475)));
      V v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str9), v_t_2476), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str10));
      V v_t_2478 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2477, NTAG(TAG_MkUnit)});
      V v_t_2479 = heff_tag_at_n(v_ru_24t_2474_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
      V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam7, 1, 5, (V[]){v_file_242, v_why_2475, v_failed_245, v_z_248, v_z_249})));
    }
    case TAG_Right: {
      V v_glues_2486 = heff_field(v_t_2474, 0);
      heff_take_n(v_t_2474, 1ULL, 1);
      V v_t_2487 = (g_list_2emap_24s1435185561x202019164(v_glues_2486));
      V v_t_2488 = (g_prelude_2e_2b_2b(v_x_2429, v_t_2487));
      return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2430, v_x_2431}); V a_5 = v_failed_245; V a_6 = v_done_246; V a_7 = v_c_2414; V a_8 = v_t_2488; V a_9 = v_z_248; V a_10 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop_tag(v_name_243, 1); r_; });
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_x_2429 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam3, 1, 11, (V[]){v_name_243, v_outPath_244, v_z_248, v_c_2414, v_x_2430, v_z_249, v_x_2429, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam2, 1, 10, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2414, v_z_249, v_x_2429, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_lam8(V self, V *args) {
  V v_x_2495 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str21, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(V v_lit_240, V v_prog_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248, V v_hd_249, V v_k_2410) {
top: ;
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_246), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam1, 1, 11, (V[]){heff_dup(v_st_243), v_dir_246, v_prog_241, v_p_245, v_hd_249, v_flags_244, v_out_247, v_next_248, v_k_2410, v_who_242, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam0(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2421; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam3(V self, V *args) {
  V v_n_2426 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2426; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam4(V self, V *args) {
  V v_t_2431 = args[0];
  return v_t_2431;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V v_t_2443 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str14)});
  V f_ = v_k_2442;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam8(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam12(V self, V *args) {
  V v_x_2476 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s903439140x919002362(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2468);
  V v_t_2469 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str20), v_out_247));
  V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str21)), NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam12, 1, 3, (V[]){v_lit_240, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2454 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_take_field(v_x_2454, 0);
  V v_t_2461;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Exited: {
    V v_n_2459 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 1);
    v_t_2461 = heff_intEq(v_n_2459, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2458, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2454, 3);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_lit_240);
    heff_drop(v_t_2461);
    V f_ = v_next_248;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2461);
    V v_t_2462 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2454, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam11, 1, 5, (V[]){v_who_242, v_out_247, v_hd_249, v_lit_240, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2455 = heff_tag_n(TAG_End, 2, (V[]){v_x_2433, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2455}));
  return (g_co_2eop_24s94900133x232571340(v_t_2456, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam10, 1, 7, (V[]){v_x_2454, v_next_248, v_hd_249, v_k_2410, v_who_242, v_out_247, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2433 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2453;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nothing: {
    heff_drop(v_x_2422);
    heff_drop(v_flags_244);
    v_c_2453 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam7_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2444 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str15), NTAG(TAG_Nil)});
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2445})});
    V v_t_2447 = (g_prelude_2e_2b_2b(v_os_2444, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_x_2422, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str17), v_t_2448})));
    V v_as_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str18), v_t_2449});
    V v_t_2452 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2433), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str19), v_as_2450, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam8_clo)})}));
    v_c_2453 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_2452}));
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam9, 1, 8, (V[]){v_x_2433, v_prog_241, v_hd_249, v_next_248, v_k_2410, v_who_242, v_out_247, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2438;
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str4);
  } else {
    heff_drop(v_t_2434);
    V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str6);
    } else {
      heff_drop(v_t_2435);
      V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_t_2436);
        v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str8);
      } else {
        heff_drop(v_t_2436);
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s529567056x880977707(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
          heff_drop(v_t_2437);
          v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str11);
        } else {
          heff_drop(v_t_2437);
          v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str12);
        }
      }
    }
  }
  V v_c_2439 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(heff_dup(v_prog_241), heff_dup(v_x_2433), v_t_2438, v_x_2427, NTAG(TAG_Nil)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam6, 1, 10, (V[]){v_out_247, v_x_2422, v_flags_244, v_prog_241, v_x_2433, v_hd_249, v_next_248, v_k_2410, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_lit_240 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2419;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_dup(heff_field(v_x_2417, 0));
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str0); V a_1 = v_t_2419; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam2, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2420));
  V v_t_2424;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2425 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str1); V a_1 = v_t_2424; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam3, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2425));
  V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2422));
  V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2427));
  V v_total_2430 = heff_intAdd(heff_intAdd(v_t_2428, v_t_2429), MK_INT(1LL));
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_str2), v_total_2430, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2432, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_lam5, 1, 10, (V[]){v_flags_244, v_prog_241, v_x_2427, v_hd_249, v_out_247, v_x_2422, v_next_248, v_k_2410, v_who_242, v_lit_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str4, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str5, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str7, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str9, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str12, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str13, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str14, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str16, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str17, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str19, 9, "that of /");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str20, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str21, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str22, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str23, 20, " (vA.B.C, its major ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str24, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str25, 17, " is a version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str26, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str27, 10, "no tag of ");
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847(V v_prog_240, V v_path_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str0), heff_dup(v_path_241)), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam0_clo)});
  V v_t_244 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_243}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam1, 2, 3, (V[]){v_t_244, v_path_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam3(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam6(V self, V *args) {
  V v_best_2437 = args[0];
  V v_line_2438 = args[1];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2439 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str12); V a_1 = v_line_2438; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str13), v_line_2438, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_line_2438); r_; });
  switch (heff_tag_of(v_it_2439)) {
  case TAG_Nil: {
    heff_drop(v_path_241);
    return v_best_2437;
  }
  case TAG_Cons: {
    V v_it2_2441 = heff_field(v_it_2439, 1);
    heff_take_n(v_it_2439, 2ULL, 2);
    switch (heff_tag_of(v_it2_2441)) {
    case TAG_Nil: {
      heff_drop(v_path_241);
      return v_best_2437;
    }
    case TAG_Cons: {
      V v_v_2442 = heff_field(v_it2_2441, 0);
      V v_it22_2443 = heff_field(v_it2_2441, 1);
      heff_take_n(v_it2_2441, 3ULL, 2);
      switch (heff_tag_of(v_it22_2443)) {
      case TAG_Nil: {
        V v_t_2444 = (g_prelude_2eskipSpaces(v_v_2442, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2445 = (heff_unbox_word(heff_strLength_lent(v_v_2442, 0)) - ((int64_t)1ULL));
        V v_t_2446 = (g_prelude_2eskipSpaces(v_v_2442, heff_box_word(v_t_2445), MK_INT(-1LL)));
        V v_t_2447 = heff_strSlice(heff_dup(v_v_2442), v_t_2444, heff_intAdd(v_t_2446, MK_INT(1LL)));
        HeffT2 v_t_2448 = ({ V a_0 = v_t_2447; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2447); r_; });
        {
          V v_field_2450 = v_t_2448.f[1];
          int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
          if ((v_tag_2449 == ((int64_t)0ULL))) {
            V v_x_2452 = v_field_2450;
            heff_drop(v_x_2452);
            V v_t_2453 = (g_prelude_2eskipSpaces(v_v_2442, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2454 = (heff_unbox_word(heff_strLength_lent(v_v_2442, 0)) - ((int64_t)1ULL));
            V v_t_2455 = (g_prelude_2eskipSpaces(v_v_2442, heff_box_word(v_t_2454), MK_INT(-1LL)));
            V v_t_2456 = heff_strSlice(heff_dup(v_v_2442), v_t_2453, heff_intAdd(v_t_2455, MK_INT(1LL)));
            HeffT2 v_t_2457 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_241, v_t_2456));
            {
              V v_field_2459 = v_t_2457.f[1];
              int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
              if ((v_tag_2458 == ((int64_t)0ULL))) {
                heff_drop(v_v_2442);
                V v_x_2461 = v_field_2459;
                heff_drop(v_x_2461);
                return v_best_2437;
              } else {
                heff_drop(v_field_2459);
                switch (heff_tag_of(v_best_2437)) {
                case TAG_Nothing: {
                  V v_t_2462 = (g_prelude_2eskipSpaces(v_v_2442, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2463 = (heff_unbox_word(heff_strLength_lent(v_v_2442, 0)) - ((int64_t)1ULL));
                  V v_t_2464 = (g_prelude_2eskipSpaces(v_v_2442, heff_box_word(v_t_2463), MK_INT(-1LL)));
                  V v_t_2465 = heff_strSlice(v_v_2442, v_t_2462, heff_intAdd(v_t_2464, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2465});
                }
                case TAG_Just: {
                  V v_b_2466 = heff_dup(heff_field(v_best_2437, 0));
                  V v_t_2467 = (g_prelude_2eskipSpaces(v_v_2442, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2468 = (heff_unbox_word(heff_strLength_lent(v_v_2442, 0)) - ((int64_t)1ULL));
                  V v_t_2469 = (g_prelude_2eskipSpaces(v_v_2442, heff_box_word(v_t_2468), MK_INT(-1LL)));
                  V v_a_2470 = heff_strSlice(heff_dup(v_v_2442), v_t_2467, heff_intAdd(v_t_2469, MK_INT(1LL)));
                  HeffT2 v_t_2471 = ({ V a_0 = v_a_2470; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_a_2470); r_; });
                  V v_t_2476;
                  {
                    V v_field_2473 = v_t_2471.f[1];
                    int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
                    if ((v_tag_2472 == ((int64_t)0ULL))) {
                      V v_x_2475 = v_field_2473;
                      v_t_2476 = v_x_2475;
                    } else {
                      heff_drop(v_field_2473);
                      v_t_2476 = NTAG(TAG_Nil);
                    }
                  }
                  HeffT2 v_t_2477 = ({ V a_0 = v_b_2466; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_b_2466); r_; });
                  V v_t_2482;
                  {
                    V v_field_2479 = v_t_2477.f[1];
                    int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
                    if ((v_tag_2478 == ((int64_t)0ULL))) {
                      V v_x_2481 = v_field_2479;
                      v_t_2482 = v_x_2481;
                    } else {
                      heff_drop(v_field_2479);
                      v_t_2482 = NTAG(TAG_Nil);
                    }
                  }
                  V v_t_2483 = ({ V a_0 = v_t_2476; V a_1 = v_t_2482; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2476); heff_drop(v_t_2482); r_; });
                  if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_2437, 1);
                    heff_drop(v_t_2483);
                    V v_t_2484 = (g_prelude_2eskipSpaces(v_v_2442, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2485 = (heff_unbox_word(heff_strLength_lent(v_v_2442, 0)) - ((int64_t)1ULL));
                    V v_t_2486 = (g_prelude_2eskipSpaces(v_v_2442, heff_box_word(v_t_2485), MK_INT(-1LL)));
                    V v_t_2487 = heff_strSlice(v_v_2442, v_t_2484, heff_intAdd(v_t_2486, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2487});
                  } else {
                    heff_drop(v_v_2442);
                    heff_drop(v_t_2483);
                    return v_best_2437;
                  }
                }
                default: return heff_nomatch(v_best_2437);
                }
              }
            }
          } else {
            heff_drop(v_path_241);
            heff_drop(v_v_2442);
            heff_drop(v_field_2450);
            return v_best_2437;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2443, 0ULL, 2);
        heff_drop(v_path_241);
        heff_drop(v_v_2442);
        return v_best_2437;
      }
      default: return heff_nomatch(v_it22_2443);
      }
    }
    default: return heff_nomatch(v_it2_2441);
    }
  }
  default: return heff_nomatch(v_it_2439);
  }
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_take_field(v_x_2419, 0);
  V v_t_2427;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    v_t_2427 = heff_bool(!heff_intEq_c_lent(v_n_2424, MK_INT(0LL), 2));
    heff_drop(v_n_2424);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2427 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2427 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2427 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_x_24111;
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_t_2427);
    V v_t_2428 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_s_2429 = heff_get_n(v_x_2419, 2, 3);
    V v_t_2430 = (g_prelude_2eskipSpaces(v_s_2429, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_s_2429, 0)) - ((int64_t)1ULL));
    V v_t_2432 = (g_prelude_2eskipSpaces(v_s_2429, heff_box_word(v_t_2431), MK_INT(-1LL)));
    V v_t_2433 = heff_strSlice(v_s_2429, v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str7), v_t_2428), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str8), v_t_2433));
    v_x_24111 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str9), v_t_2434)});
  } else {
    heff_drop(v_t_2427);
    V v_s_2435 = heff_get_n(v_x_2419, 1, 3);
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str10); V a_1 = v_s_2435; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str11), v_s_2435, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2435); r_; });
    V v_t_2490 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam6, 2, 1, (V[]){heff_dup(v_path_241)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2436; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2436); r_; });
    switch (heff_tag_of(v_t_2490)) {
    case TAG_Nothing: {
      V v_t_2491 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
      V v_xs_2492 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str14); V a_1 = v_path_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str15), v_path_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2492));
      V v_x_2496;
      switch (heff_tag_of(v_t_2493)) {
      case TAG_Nil: {
        v_x_2496 = heff_dup(v_path_241);
        break;
      }
      case TAG_Cons: {
        V v_x_2494 = heff_field(v_t_2493, 0);
        heff_take_n(v_t_2493, 1ULL, 2);
        v_x_2496 = v_x_2494;
        break;
      }
      default: heff_nomatch(v_t_2493);
      }
      V v_t_24106;
      if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_2496, 0)))) {
        if (heff_strEq_c(heff_strSlice_lent(v_x_2496, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str16))) {
          V v_t_2499 = heff_strSlice(heff_dup(v_x_2496), MK_INT(1LL), heff_strLength(v_x_2496));
          V v_t_24100 = ({ V a_0 = v_t_2499; V r_ = (g_heff_2ebuild_2eproject_2eisNumber(a_0)); heff_drop(v_t_2499); r_; });
          if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
            heff_drop(v_t_24100);
            V v_xs_24101 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str17); V a_1 = v_path_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str18), v_path_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24101));
            V v_t_24105;
            switch (heff_tag_of(v_t_24102)) {
            case TAG_Nil: {
              v_t_24105 = heff_dup(v_path_241);
              break;
            }
            case TAG_Cons: {
              V v_x_24103 = heff_field(v_t_24102, 0);
              heff_take_n(v_t_24102, 1ULL, 2);
              v_t_24105 = v_x_24103;
              break;
            }
            default: heff_nomatch(v_t_24102);
            }
            v_t_24106 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str19), v_t_24105);
          } else {
            heff_drop(v_t_24100);
            v_t_24106 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str20);
          }
        } else {
          heff_drop(v_x_2496);
          v_t_24106 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str21);
        }
      } else {
        heff_drop(v_x_2496);
        v_t_24106 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str22);
      }
      V v_t_24107 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str23), heff_strAppend(v_t_24106, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str24)));
      V v_t_24108 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str25), heff_strAppend(v_path_241, v_t_24107));
      V v_t_24109 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str26), v_t_2491), v_t_24108);
      v_x_24111 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str27), v_t_24109)});
      break;
    }
    case TAG_Just: {
      V v_v_24110 = heff_field(v_t_2490, 0);
      V v_ru_24t_2490_24Just = heff_take_reuse_n(v_t_2490, 1ULL, 1);
      heff_drop(v_path_241);
      v_x_24111 = heff_tag_at_n(v_ru_24t_2490_24Just, TAG_Right, 1, (V[]){v_v_24110});
      break;
    }
    default: heff_nomatch(v_t_2490);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_24111;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2420}));
  return (g_co_2eop_24s94900133x232571340(v_t_2421, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam5, 1, 3, (V[]){v_x_2419, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str1), v_t_248), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str3), v_t_249})});
  V v_c_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str5), v_t_2410}), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_str6), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_c_2411, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam3_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_245, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_244 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s94900133x232571340(v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_lam2, 1, 4, (V[]){v_path_241, v_hd_245, v_prog_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(V v_prog_240, V v_chk_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_chk_241);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_c_248 = (g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338(heff_dup(v_prog_240), heff_dup(v_chk_241), v_acc_242, heff_dup(v_f_246)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam1, 2, 4, (V[]){v_c_248, v_prog_240, v_chk_241, heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = ({ V a_0 = v_prog_240; V a_1 = v_chk_241; V a_2 = v_x_2411; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_chk_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_lam2, 1, 5, (V[]){v_prog_240, v_chk_241, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245(V v_prog_240, V v_st_241, V v_t_242, V v_next_243, V v_progs_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam0_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam1, 1, 7, (V[]){heff_dup(v_progs_244), v_t_242, v_prog_240, v_hd_245, heff_dup(v_st_241), v_next_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245(a[0], a1, a[2], a[3], a4, a[5], a[6]); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam0(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_next_243;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_t_2421 = heff_env(self)[0];
  V v_next_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam5, 1, 3, (V[]){v_next_243, v_hd_2422, v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_next_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2419), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2420}));
  V v_t_2425 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_x_2419; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam4, 2, 2, (V[]){v_t_2421, v_next_243}); V a_5 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2414);
  V v_total_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_str0), heff_dup(heff_rfield(v_t_242, 1)));
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2416, v_total_2415, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_lam3, 1, 7, (V[]){v_prog_240, v_st_241, v_t_242, v_next_243, v_progs_244, v_hd_245, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819(V v_prog_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_244);
    return v_done_243;
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_245, 0);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_244)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    V v_t_2411 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_str0), heff_dup(v_home_246)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam0_clo)});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2411}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam1, 2, 7, (V[]){v_t_2412, v_prog_240, v_progs_244, heff_dup(v_st_241), v_t_242, heff_dup(v_home_246), v_done_243});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_243 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V f_ = v_done_243;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2417 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_2417, heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam4, 1, 3, (V[]){v_done_243, v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2415), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2416}));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_244));
  V v_xs_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2424 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_246; V a_4 = v_x_2415; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam3, 2, 2, (V[]){v_t_2417, v_done_243}); V a_6 = v_t_2420; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2420); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_246 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_lam2, 1, 8, (V[]){v_prog_240, v_progs_244, v_st_241, v_t_242, v_home_246, v_done_243, v_hd_2413, v_k_2414})));
}