// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_output 941629484
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_segments 1801007612
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s708435384x833942752(V, V, V, V, V, V, V, V);
V g_list_2emap_24s708435384x833942752_entry(V self, V *a);
extern Clo g_list_2emap_24s708435384x833942752_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3);
        V v_s_248 = heff_strAppend(v_s_247, heff_dup(v_b_243));
        V v_s_249 = heff_strAppend(v_s_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_std_2epath_2ejoin(heff_rfield(v_paths_240, 5), heff_take_field(v_paths_240, 0), ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_xs_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = heff_dup(v_p_243); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = heff_get_n(v_p_243, 2, 3); V r_ = (g_list_2efoldl_24s1725521117x1379101383(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_x2_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_p_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_p_248 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_p_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return ({ V b_0 = heff_get_n(v_paths_240, 5, 6); V a_1 = v_d_242; V a_2 = v_p_248; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
  V v_t_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
    V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
    v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_244 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_245 = (g_list_2emap_24s708435384x833942752(((V)&g_heff_2ebuild_2ecommands_2estatistic_str3), heff_dup(v_o_240), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), heff_get_n(v_o_240, 7, 12)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_248));
  return heff_strAppend(v_t_241, v_t_249);
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(v_t_242, heff_dup(v_j_241)));
  V v_t_2414;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_248 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        v_t_2414 = v_b_248;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_245);
      v_t_2414 = NTAG(TAG_False);
    }
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1), NTAG(TAG_Nil)});
  HeffT2 v_t_2416 = (g_json_2eat_24cpr(v_t_2415, heff_dup(v_j_241)));
  V v_t_2427;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_it1_2420 = v_field_2418;
      switch (heff_tag_of(v_it1_2420)) {
      case TAG_JNull: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2424 = heff_field(v_it1_2420, 0);
        V v_ru_24it1_2420_24JString = heff_take_reuse_n(v_it1_2420, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24it1_2420_24JString, TAG_Just, 1, (V[]){v_s_2424});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2420);
      }
    } else {
      heff_drop(v_field_2418);
      v_t_2427 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2429 = (g_json_2eat_24cpr(v_t_2428, heff_dup(v_j_241)));
  V v_t_2440;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_it1_2433 = v_field_2431;
      switch (heff_tag_of(v_it1_2433)) {
      case TAG_JNull: {
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2438 = heff_field(v_it1_2433, 0);
        heff_take_n(v_it1_2433, 1ULL, 1);
        v_t_2440 = v_xs_2438;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2433);
      }
    } else {
      heff_drop(v_field_2431);
      v_t_2440 = NTAG(TAG_Nil);
    }
  }
  V v_t_2441 = (g_list_2emap_24s1618539892x552009225(v_t_2440));
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3), NTAG(TAG_Nil)});
  HeffT2 v_t_2443 = (g_json_2eat_24cpr(v_t_2442, heff_dup(v_j_241)));
  V v_t_2448;
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_f_2447 = v_field_2445;
      v_t_2448 = (g_heff_2ebuild_2ecommands_2ejsonFailure(v_f_2447));
    } else {
      heff_drop(v_field_2445);
      v_t_2448 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2450 = (g_json_2eat_24cpr(v_t_2449, v_j_241));
  V v_t_2461;
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_it1_2454 = v_field_2452;
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_JNull: {
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2459 = heff_field(v_it1_2454, 0);
        heff_take_n(v_it1_2454, 1ULL, 1);
        v_t_2461 = v_xs_2459;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2454);
      }
    } else {
      heff_drop(v_field_2452);
      v_t_2461 = NTAG(TAG_Nil);
    }
  }
  V v_t_2462 = (g_list_2emap_24s809490196x1189312632(v_t_2461));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2414, v_t_2427, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2441, v_t_2448, MK_INT(0LL), v_t_2462});
}
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeOfJson(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_t_246 = (g_regex_2ematches(v_r_242, v_n_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2421, v_x_2430));
  V v_x_2432 = ({ V a_0 = v_st_2421; V a_1 = v_t_2431; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2421); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2421;
  if (heff_strEq_c(v_x_2419, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str1))) {
    v_st_2421 = NTAG(TAG_Windows);
  } else {
    v_st_2421 = NTAG(TAG_Posix);
  }
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s495635622x733177935(v_t_2429, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam5, 1, 2, (V[]){v_st_2421, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2433 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  return v_v_2420;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2444;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2439;
    if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str3))) {
      v_t_2439 = NTAG(TAG_Windows);
    } else {
      v_t_2439 = NTAG(TAG_Posix);
    }
    V v_t_2442;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2428)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2428, 0);
        heff_take_n(v_x_2428, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_x_2428);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    v_x_2444 = ({ V a_0 = v_t_2439; V a_1 = v_t_2442; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2443 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_2437);
    heff_drop(v_x_2419);
    heff_drop(v_x_2428);
    v_x_2444 = v_d_2443;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_241;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(v_t_2436, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7, 1, 4, (V[]){v_x_2410, v_x_2419, v_x_2428, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5, 1, 4, (V[]){v_hd_240, v_x_2410, v_x_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3, 1, 3, (V[]){v_hd_240, v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str1, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str3, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str4, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0, 2, 0};
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2446 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2446, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2439);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2410, 0ULL, 1);
    v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str2), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2418, 0ULL, 1);
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str3), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_it_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
  switch (heff_tag_of(v_it_2423)) {
  case TAG_Nil: {
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str4), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Cons: {
    V v_t_2442 = (g_list_2emap_24s1420651609x666245096(v_it_2423));
    V v_t_2443 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2442, NTAG(TAG_Nil)));
    V f_ = v_t_2443;
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_it_2423);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str1), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4, 1, 3, (V[]){v_x_2410, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str0), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0, 2, 3, (V[]){v_c_242, v_rep_240, v_file_241});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_rep_240; V a_1 = v_file_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3, 1, 5, (V[]){v_rep_240, v_file_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_rep_240, v_file_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1, 1, 4, (V[]){v_hd_243, v_rep_240, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_file_241));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0, 2, 2, (V[]){v_c_242, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_c_2416 = v_field_2414;
      V v_t_2417 = (g_heff_2ebuild_2equery_2eexplain(v_c_2416));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(v_t_2417, v_hd_243, v_k_244));
    } else {
      heff_drop(v_field_2414);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_249)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4, 1, 3, (V[]){v_cs_249, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3, 1, 3, (V[]){v_rep_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_rep_240, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1, 1, 3, (V[]){v_hd_243, v_rep_240, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str1, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str4, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str5, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str9, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str10, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  HEFF_LAST return g_co_2eop_24s495635622x733177935(v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  return v_s_2435;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam9(V self, V *args) {
  V v_x_2473 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2473) == NTAG(TAG_True))) {
    heff_drop(v_x_2473);
    V v_t_2474 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str4), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str5)));
    V v_t_2475 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2474, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str6)), NTAG(TAG_MkUnit)});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_2473);
    heff_drop(v_dir_240);
    V v_t_2482 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam10(V self, V *args) {
  V v_x_24103 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24103);
  V v_t_24104 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24110}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_2449 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2452;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str2), 2)) {
    v_t_2452 = v_x_2411;
  } else {
    heff_drop(v_x_2411);
    v_t_2452 = heff_dup(v_dir_240);
  }
  HeffT2 v_t_2453 = (g_heff_2ebuild_2ecommands_2einitProblem_24cpr(v_t_2452, v_x_2446));
  {
    V v_field_2455 = v_t_2453.f[1];
    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
    if ((v_tag_2454 == ((int64_t)0ULL))) {
      heff_drop(v_x_2450);
      heff_drop(v_dir_240);
      heff_drop(v_x_2449);
      V v_why_2457 = v_field_2455;
      V v_t_2458 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_2457, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str3)), NTAG(TAG_MkUnit)});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam8, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_field_2455);
      switch (heff_tag_of(v_x_2450)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(heff_dup(v_dir_240), v_x_2449, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam9, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2449);
        V v_t_2493;
        switch (heff_tag_of(v_x_2450)) {
        case TAG_Nil: {
          v_t_2493 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2491 = heff_field(v_x_2450, 0);
          V v_xs_2492 = heff_field(v_x_2450, 1);
          heff_take_n(v_x_2450, 3ULL, 2);
          v_t_2493 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str8); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
          break;
        }
        default: heff_nomatch(v_x_2450);
        }
        V v_t_2494 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str9), heff_strAppend(v_t_2493, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str10)));
        V v_str_2495 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str11), heff_strAppend(v_dir_240, v_t_2494));
        V v_t_2496 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2495, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str12)), NTAG(TAG_MkUnit)});
        V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
        V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
        V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
        V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
        V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam10, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2450);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445;
  if (heff_strEq_c(v_x_2443, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str0))) {
    v_t_2445 = NTAG(TAG_Windows);
  } else {
    v_t_2445 = NTAG(TAG_Posix);
  }
  V v_x_2446 = ({ V a_0 = v_t_2445; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_x_2411); V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2445); r_; });
  V v_t_2448;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Nothing: {
    v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2447 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    v_t_2448 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V v_x_2449 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2446), v_t_2448));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(heff_dup(v_dir_240), heff_dup(v_x_2449), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7, 1, 6, (V[]){v_dir_240, v_x_2411, v_x_2446, v_hd_241, v_k_242, v_x_2449})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2434;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    v_x_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Just = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    HeffT2 v_t_2422 = ({ V a_0 = v_src_2421; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_2421); r_; });
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2420_24Just, 1);
        V v_p_2426 = v_field_2424;
        heff_drop(v_p_2426);
        v_x_2434 = NTAG(TAG_Nothing);
      } else {
        V v_x_2427 = v_field_2424;
        HeffT2 v_t_2428 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2427));
        {
          V v_field_2430 = v_t_2428.f[1];
          int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
          if ((v_tag_2429 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2420_24Just, 1);
            V v_x_2432 = v_field_2430;
            heff_drop(v_x_2432);
            v_x_2434 = NTAG(TAG_Nothing);
          } else {
            V v_p_2433 = v_field_2430;
            v_x_2434 = heff_tag_at_n(v_ru_24x_2420_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2433, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5_clo)})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s495635622x733177935(v_t_2442, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6, 1, 5, (V[]){v_dir_240, v_x_2411, v_x_2434, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_2411, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_2411, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(V v_rep_240, V v_prog_241, V v_st_242, V v_cmd_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str0)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_c_249 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_248, NTAG(TAG_Nil)));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0, 1, 7, (V[]){v_prog_241, v_z_245, v_rep_240, v_cmd_243, v_z_246, v_st_242, v_t_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7(V self, V *args) {
  V v_ns_2457 = args[0];
  return v_ns_2457;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9(V self, V *args) {
  V v_t_2468 = args[0];
  return v_t_2468;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13(V self, V *args) {
  V v_x_2493 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2493);
  V v_t_2494 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24100}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12(V self, V *args) {
  V v_x_2478 = args[0];
  V v_x_2475 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2478);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2475, 1)))) {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    V v_n_2480 = heff_get_n(v_x_2475, 1, 2);
    V v_t_2482;
    if (heff_intEq_c_lent(v_n_2480, MK_INT(1LL), 2)) {
      heff_drop(v_n_2480);
      v_t_2482 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str17);
    } else {
      v_t_2482 = heff_strAppend(heff_intShow(v_n_2480), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str18));
    }
    V v_what_2483 = heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str19));
    V v_t_2484 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str20), heff_strAppend(v_what_2483, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str21)));
    V v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str22), heff_strAppend(v_cmd_243, v_t_2484));
    V v_t_2486 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2485, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str23)), NTAG(TAG_MkUnit)});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2492}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    heff_drop(v_cmd_243);
    V v_t_24101 = heff_dup(heff_rfield(v_x_2475, 0));
    switch (heff_tag_of(v_t_24101)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2475, 2);
      heff_drop(v_z_245);
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_244, 6);
      V f_ = v_z_246;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_24101, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(v_rep_240, v_prog_241, v_st_242, v_t_244, heff_get_n(v_x_2475, 0, 2), v_z_245, v_z_246));
    }
    default: return heff_nomatch(v_t_24101);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2476 = heff_tag_n(TAG_End, 2, (V[]){v_x_2470, NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2476}));
  return (g_co_2eop_24s495635622x733177935(v_t_2477, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12, 1, 8, (V[]){v_x_2475, v_cmd_243, v_z_245, v_z_246, v_rep_240, v_prog_241, v_st_242, v_t_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2464 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_cmd_243 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2471 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2473;
  switch (heff_tag_of(v_x_2464)) {
  case TAG_Nothing: {
    v_t_2473 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2472 = heff_field(v_x_2464, 0);
    heff_take_n(v_x_2464, 1ULL, 1);
    v_t_2473 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2464);
  }
  V v_c_2474 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_244), heff_dup(v_x_2470), v_t_2471, v_t_2473));
  V f_ = v_c_2474;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11, 1, 8, (V[]){v_x_2470, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_rep_240, v_st_242, v_t_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2466;
  switch (heff_tag_of(v_x_2464)) {
  case TAG_Nothing: {
    v_t_2466 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2465 = heff_dup(heff_field(v_x_2464, 0));
    v_t_2466 = v_x_2465;
    break;
  }
  default: heff_nomatch(v_x_2464);
  }
  V v_total_2467 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2466; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
  V v_t_2469 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str16), v_total_2467, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2469, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10, 1, 8, (V[]){v_x_2464, v_prog_241, v_st_242, v_t_244, v_z_245, v_cmd_243, v_z_246, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2455);
  V v_path_2456 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str15)));
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_2456, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7_clo)})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8, 1, 7, (V[]){v_prog_241, v_z_245, v_st_242, v_t_244, v_cmd_243, v_z_246, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_242 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2420);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2417, 1)))) {
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    V v_n_2422 = heff_get_n(v_x_2417, 1, 2);
    V v_t_2424;
    if (heff_intEq_c_lent(v_n_2422, MK_INT(1LL), 2)) {
      heff_drop(v_n_2422);
      v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str2);
    } else {
      v_t_2424 = heff_strAppend(heff_intShow(v_n_2422), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str3));
    }
    V v_what_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str4));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str5), heff_strAppend(v_what_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str6)));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str7), heff_strAppend(v_cmd_243, v_t_2426));
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str8)), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    V v_n_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2417, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2445;
    if (heff_intEq_c_lent(v_n_2443, MK_INT(1LL), 2)) {
      heff_drop(v_n_2443);
      v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str9);
    } else {
      v_t_2445 = heff_strAppend(heff_intShow(v_n_2443), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str10));
    }
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str11), heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str12)));
    V v_str_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str13), heff_strAppend(heff_dup(v_cmd_243), v_t_2446));
    V v_t_2448 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2447, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str14)), NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6, 1, 7, (V[]){v_st_242, v_t_244, v_z_245, v_prog_241, v_cmd_243, v_z_246, v_rep_240})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2418}));
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4, 1, 8, (V[]){v_x_2417, v_cmd_243, v_z_245, v_z_246, v_st_242, v_t_244, v_prog_241, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2416 = ({ V a_0 = heff_dup(v_rep_240); V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_x_2414); V a_3 = v_t_2415; V a_4 = v_x_2410; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2410); r_; });
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3, 1, 8, (V[]){v_x_2414, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2410));
  V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str1), v_total_2411, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2, 1, 8, (V[]){v_rep_240, v_prog_241, v_x_2410, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str5, 6, ": git ");
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(V v_what_240, V v_argv_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str0), heff_dup(v_argv_241), ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str1), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1, 1, 3, (V[]){v_argv_241, v_what_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_take_field(v_x_2413, 0);
  V v_t_2417;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Exited: {
    V v_n_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    v_t_2417 = heff_intEq(v_n_2415, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2414, 0ULL, 1);
    v_t_2417 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2417 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2417 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_x_2428;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2413, 3);
    heff_drop(v_argv_241);
    heff_drop(v_what_240);
    heff_drop(v_t_2417);
    v_x_2428 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2417);
    V v_t_2420;
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_argv_241, 0);
      V v_xs_2419 = heff_field(v_argv_241, 1);
      heff_take_n(v_argv_241, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_argv_241);
    }
    V v_s_2421 = heff_get_n(v_x_2413, 2, 3);
    V v_t_2422 = (g_prelude_2eskipSpaces(v_s_2421, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_s_2421, 0)) - ((int64_t)1ULL));
    V v_t_2424 = (g_prelude_2eskipSpaces(v_s_2421, heff_box_word(v_t_2423), MK_INT(-1LL)));
    V v_t_2425 = heff_strSlice(v_s_2421, v_t_2422, heff_intAdd(v_t_2424, MK_INT(1LL)));
    V v_t_2426 = heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str4), v_t_2425));
    V v_t_2427 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str5), v_t_2426));
    v_x_2428 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2427});
  }
  V f_ = v_k_243;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}