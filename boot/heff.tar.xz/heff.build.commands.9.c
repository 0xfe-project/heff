// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_clo;
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s947498525x825328855(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s947498525x825328855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s947498525x825328855_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_clo;
V g_heff_2ebuild_2ecommands_2erevNamed(V);
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevNamed_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s714175201x1920746028(V, V, V, V, V, V, V, V);
V g_list_2eall_24s714175201x1920746028_entry(V self, V *a);
extern Clo g_list_2eall_24s714175201x1920746028_clo;
V g_list_2efoldl_24s1313398329x1387572461(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1313398329x1387572461_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1313398329x1387572461_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s708435384x833942752(V, V, V, V, V, V, V, V);
V g_list_2emap_24s708435384x833942752_entry(V self, V *a);
extern Clo g_list_2emap_24s708435384x833942752_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3);
        V v_s_248 = heff_strAppend(v_s_247, heff_dup(v_b_243));
        V v_s_249 = heff_strAppend(v_s_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_b_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, v_b_245));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildTarget(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_t_243 = (g_std_2epath_2eparse(v_st_242, heff_take_field(v_paths_240, 0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_d_246 = ({ V a_0 = v_st_242; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_245); r_; });
  HeffT3 v_t_247 = (g_std_2epath_2eparse_24cpr(heff_rfield(v_paths_240, 5), v_file_241));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    V v_d_2411 = v_field_248;
    heff_drop(v_d_2411);
    V v_a_2412 = v_field_249;
    V v_xs_2413 = v_field_2410;
    V v_xs_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = v_a_2412; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2413; V r_ = (g_list_2efoldl_24s1313398329x1387572461(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2412); heff_drop(b_3); r_; });
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
    V v_x2_2416 = v_t_2415;
    V v_p_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_p_2419 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_p_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_st_2420 = heff_get_n(v_paths_240, 5, 6);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2420, v_d_246));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2420, v_p_2419));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    return ({ V a_0 = v_st_2420; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2423); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
  V v_t_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
    V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
    v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_244 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_245 = (g_list_2emap_24s708435384x833942752(((V)&g_heff_2ebuild_2ecommands_2estatistic_str3), heff_dup(v_o_240), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), heff_get_n(v_o_240, 7, 12)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_248));
  return heff_strAppend(v_t_241, v_t_249);
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(v_t_242, heff_dup(v_j_241)));
  V v_t_2414;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_248 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        v_t_2414 = v_b_248;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_245);
      v_t_2414 = NTAG(TAG_False);
    }
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1), NTAG(TAG_Nil)});
  HeffT2 v_t_2416 = (g_json_2eat_24cpr(v_t_2415, heff_dup(v_j_241)));
  V v_t_2427;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_it1_2420 = v_field_2418;
      switch (heff_tag_of(v_it1_2420)) {
      case TAG_JNull: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2424 = heff_field(v_it1_2420, 0);
        V v_ru_24it1_2420_24JString = heff_take_reuse_n(v_it1_2420, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24it1_2420_24JString, TAG_Just, 1, (V[]){v_s_2424});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2420, 0ULL, 1);
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2420);
      }
    } else {
      heff_drop(v_field_2418);
      v_t_2427 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2429 = (g_json_2eat_24cpr(v_t_2428, heff_dup(v_j_241)));
  V v_t_2440;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_it1_2433 = v_field_2431;
      switch (heff_tag_of(v_it1_2433)) {
      case TAG_JNull: {
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2438 = heff_field(v_it1_2433, 0);
        heff_take_n(v_it1_2433, 1ULL, 1);
        v_t_2440 = v_xs_2438;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2433, 0ULL, 1);
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2433);
      }
    } else {
      heff_drop(v_field_2431);
      v_t_2440 = NTAG(TAG_Nil);
    }
  }
  V v_t_2441 = (g_list_2emap_24s1618539892x552009225(v_t_2440));
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3), NTAG(TAG_Nil)});
  HeffT2 v_t_2443 = (g_json_2eat_24cpr(v_t_2442, heff_dup(v_j_241)));
  V v_t_2448;
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_f_2447 = v_field_2445;
      v_t_2448 = (g_heff_2ebuild_2ecommands_2ejsonFailure(v_f_2447));
    } else {
      heff_drop(v_field_2445);
      v_t_2448 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2450 = (g_json_2eat_24cpr(v_t_2449, v_j_241));
  V v_t_2461;
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_it1_2454 = v_field_2452;
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_JNull: {
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2459 = heff_field(v_it1_2454, 0);
        heff_take_n(v_it1_2454, 1ULL, 1);
        v_t_2461 = v_xs_2459;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2461 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2454);
      }
    } else {
      heff_drop(v_field_2452);
      v_t_2461 = NTAG(TAG_Nil);
    }
  }
  V v_t_2462 = (g_list_2emap_24s809490196x1189312632(v_t_2461));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2414, v_t_2427, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2441, v_t_2448, MK_INT(0LL), v_t_2462});
}
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeOfJson(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_t_246 = (g_regex_2ematches(v_r_242, v_n_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str1, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str2, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str3, 11, "refs/heads/");
Clo g_heff_2ebuild_2ecommands_2erevNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erevNamed_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2erevNamed(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2ecommands_2erevNamed_str0), 2)) {
    return v_rev_240;
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_244 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_245 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = MK_INT(97LL); V a_6 = MK_INT(102LL); V a_7 = v_t_244; V r_ = (g_list_2eall_24s714175201x1920746028(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_244); r_; });
        if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
          heff_drop(v_t_245);
          return v_rev_240;
        } else {
          heff_drop(v_t_245);
          return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str1), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str2), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str3), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erevNamed(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2423 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2421, v_x_2422));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_2421, v_a_2423));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_2421, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str2)));
  V v_t_2426 = (g_std_2epath_2ejoin(v_t_2424, v_t_2425));
  V v_x_2427 = ({ V a_0 = v_st_2421; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2421); heff_drop(v_t_2426); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2421;
  if (heff_strEq_c(v_x_2419, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_str1))) {
    v_st_2421 = NTAG(TAG_Windows);
  } else {
    v_st_2421 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam4, 1, 2, (V[]){v_st_2421, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam2_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2428 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  return v_v_2420;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2447;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2428)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2428, 0);
        heff_take_n(v_x_2428, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_x_2428);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_t_2443 = (g_std_2epath_2eparse(v_st_2439, v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str5)));
    V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
    v_x_2447 = ({ V a_0 = v_st_2439; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2446 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2428);
    heff_drop(v_st_2439);
    v_x_2447 = v_d_2446;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_241;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam6_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(v_t_2436, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam7, 1, 4, (V[]){v_x_2410, v_x_2419, v_x_2428, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam5, 1, 4, (V[]){v_hd_240, v_x_2410, v_x_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_lam3, 1, 3, (V[]){v_hd_240, v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str1, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str3, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str4, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_241); r_; });
    V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1, 2, 1, (V[]){v_a_244});
  }
  case TAG_Cons: {
    V v_t_2452 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2452, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3(V self, V *args) {
  V v_ns_2416 = args[0];
  return v_ns_2416;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2445);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam6, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2426 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2413, 0ULL, 1);
    v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str2), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    v_t_2428 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str3), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_it_2429 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2428));
  switch (heff_tag_of(v_it_2429)) {
  case TAG_Nil: {
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str4), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Cons: {
    V v_t_2448 = (g_list_2emap_24s1420651609x666245096(v_it_2429));
    V v_t_2449 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2448, NTAG(TAG_Nil)));
    V f_ = v_t_2449;
    heff_room[0] = v_hd_245;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_it_2429);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_str1); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
  V v_a_2417 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam3_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(v_t_2423, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam4, 1, 3, (V[]){v_x_2413, v_hd_245, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_lam2, 1, 2, (V[]){v_hd_245, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0, 2, 3, (V[]){v_c_242, v_rep_240, v_file_241});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_rep_240; V a_1 = v_file_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s899658323x671721059(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam3, 1, 5, (V[]){v_rep_240, v_file_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_rep_240, v_file_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s486333559x791161815_lam1, 1, 4, (V[]){v_hd_243, v_rep_240, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_file_241));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0, 2, 2, (V[]){v_c_242, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_c_2416 = v_field_2414;
      V v_t_2417 = (g_heff_2ebuild_2equery_2eexplain(v_c_2416));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(v_t_2417, v_hd_243, v_k_244));
    } else {
      heff_drop(v_field_2414);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_249)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam4, 1, 3, (V[]){v_cs_249, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam3, 1, 3, (V[]){v_rep_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_rep_240, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s148582297x864946509_lam1, 1, 3, (V[]){v_hd_243, v_rep_240, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str1, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str4, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str5, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str9, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str10, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2444) == NTAG(TAG_True))) {
    heff_drop(v_x_2444);
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str4), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str5)));
    V v_t_2446 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str6)), NTAG(TAG_MkUnit)});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_2444);
    heff_drop(v_dir_240);
    V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7(V self, V *args) {
  V v_x_2474 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2474);
  V v_t_2475 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str2), 2)) {
    v_t_2423 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_t_2423 = heff_dup(v_dir_240);
  }
  HeffT2 v_t_2424 = (g_heff_2ebuild_2ecommands_2einitProblem_24cpr(v_t_2423, v_x_2417));
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      heff_drop(v_x_2421);
      heff_drop(v_dir_240);
      heff_drop(v_x_2420);
      V v_why_2428 = v_field_2426;
      V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_2428, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str3)), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_field_2426);
      switch (heff_tag_of(v_x_2421)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(heff_dup(v_dir_240), v_x_2420, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam6, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2420);
        V v_t_2464;
        switch (heff_tag_of(v_x_2421)) {
        case TAG_Nil: {
          v_t_2464 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2462 = heff_field(v_x_2421, 0);
          V v_xs_2463 = heff_field(v_x_2421, 1);
          heff_take_n(v_x_2421, 3ULL, 2);
          v_t_2464 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str8); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
          break;
        }
        default: heff_nomatch(v_x_2421);
        }
        V v_t_2465 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str9), heff_strAppend(v_t_2464, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str10)));
        V v_str_2466 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str11), heff_strAppend(v_dir_240, v_t_2465));
        V v_t_2467 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2466, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str12)), NTAG(TAG_MkUnit)});
        V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
        V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
        V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam7, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2421);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str0))) {
    v_t_2416 = NTAG(TAG_Windows);
  } else {
    v_t_2416 = NTAG(TAG_Posix);
  }
  V v_x_2417 = ({ V a_0 = v_t_2416; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_x_243); V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_x_2420 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2417), v_t_2419));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(heff_dup(v_dir_240), heff_dup(v_x_2420), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam4, 1, 6, (V[]){v_dir_240, v_x_243, v_x_2417, v_hd_241, v_k_242, v_x_2420})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam2_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam3, 1, 5, (V[]){v_dir_240, v_x_243, v_x_245, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_244 = ((V)&g_heff_2ebuild_2ecommands_2eownVersion_24s947498525x825328855_clo);
  V f_ = v_c_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1991816530x1359816992_lam1, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str1, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str3, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str5, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str12, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str13, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str14, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str15, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str16, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str17, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str18, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str19, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str20, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str21, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str22, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str23, 17, "the commit is of ");
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948(V v_path_240, V v_v_241, V v_time_242, V v_hash_243, V v_dir_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str0), v_t_245), ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str1));
  V v_t_247 = heff_strAppend(heff_dup(v_hash_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str2), v_t_246));
  V v_t_248 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str3), v_t_247));
  V v_t_249 = heff_strAppend(heff_dup(v_path_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str4), v_t_248));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str5), v_t_249);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam0, 2, 5, (V[]){v_path_240, v_dir_244, v_x_2410, v_hash_243, v_time_242});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam1(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam3(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_time_242 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2458 = heff_take_field(v_x_2455, 0);
  V v_t_2462;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Exited: {
    V v_n_2459 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 1);
    v_t_2462 = heff_bool(!heff_intEq_c_lent(v_n_2459, MK_INT(0LL), 2));
    heff_drop(v_n_2459);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2458, 0ULL, 1);
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_x_2474;
  if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
    heff_drop(v_x_2457);
    heff_drop(v_time_242);
    heff_drop(v_t_2462);
    V v_s_2463 = heff_get_n(v_x_2455, 2, 3);
    V v_t_2464 = (g_prelude_2eskipSpaces(v_s_2463, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2465 = (heff_unbox_word(heff_strLength_lent(v_s_2463, 0)) - ((int64_t)1ULL));
    V v_t_2466 = (g_prelude_2eskipSpaces(v_s_2463, heff_box_word(v_t_2465), MK_INT(-1LL)));
    V v_t_2467 = heff_strSlice(v_s_2463, v_t_2464, heff_intAdd(v_t_2466, MK_INT(1LL)));
    v_x_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2467)});
  } else {
    heff_drop_rec(v_x_2455, 3);
    heff_drop(v_t_2462);
    switch (heff_tag_of(v_x_2457)) {
    case TAG_Nothing: {
      heff_drop(v_time_242);
      v_x_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str21))});
      break;
    }
    case TAG_Just: {
      V v_it1_2468 = heff_field(v_x_2457, 0);
      V v_ru_24x_2457_24Just = heff_take_reuse_n(v_x_2457, 1ULL, 1);
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_MkPair: {
        V v_t_2469 = heff_field(v_it1_2468, 0);
        heff_take_n(v_it1_2468, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2469, v_time_242, 0)) {
          heff_drop(v_x_2410);
          heff_drop(v_time_242);
          heff_drop_cell(v_ru_24x_2457_24Just, 1);
          heff_drop(v_t_2469);
          v_x_2474 = NTAG(TAG_Nothing);
        } else {
          V v_t_2472 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str22), v_time_242));
          V v_t_2473 = heff_strAppend(v_x_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str23), v_t_2472));
          v_x_2474 = heff_tag_at_n(v_ru_24x_2457_24Just, TAG_Just, 1, (V[]){v_t_2473});
        }
        break;
      }
      default: heff_nomatch(v_it1_2468);
      }
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
  }
  V f_ = v_k_2412;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam4(V self, V *args) {
  V v_x_2455 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2456 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(v_dir_244, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str20)));
  V f_ = v_c_2456;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam5, 1, 4, (V[]){v_x_2455, v_x_2410, v_time_242, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_time_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = heff_take_field(v_x_2429, 0);
  V v_t_2434;
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Exited: {
    V v_n_2431 = heff_field(v_t_2430, 0);
    heff_take_n(v_t_2430, 1ULL, 1);
    v_t_2434 = heff_bool(!heff_intEq_c_lent(v_n_2431, MK_INT(0LL), 2));
    heff_drop(v_n_2431);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2430, 0ULL, 1);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2430);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_dir_244);
    heff_drop(v_hash_243);
    heff_drop(v_hd_2411);
    heff_drop(v_time_242);
    heff_drop(v_t_2434);
    V v_s_2435 = heff_get_n(v_x_2429, 2, 3);
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2435, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_s_2435, 0)) - ((int64_t)1ULL));
    V v_t_2438 = (g_prelude_2eskipSpaces(v_s_2435, heff_box_word(v_t_2437), MK_INT(-1LL)));
    V v_t_2439 = heff_strSlice(v_s_2435, v_t_2436, heff_intAdd(v_t_2438, MK_INT(1LL)));
    V v_x_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2439)});
    V f_ = v_k_2412;
    args[0] = v_x_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop_rec(v_x_2429, 3);
    heff_drop(v_t_2434);
    V v_t_2441 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_243, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str13)), NTAG(TAG_Nil)});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str15), v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str17), v_t_2443})});
    V v_t_2445 = ({ V a_0 = v_t_2441; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2441); r_; });
    V v_t_2446 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str19), v_t_2444}), v_t_2445, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2448 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam3_clo)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam4, 1, 5, (V[]){v_dir_244, v_hd_2411, v_x_2410, v_time_242, v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_240 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_time_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_244), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str6), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str8), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str10), v_t_2416})});
  V v_t_2418 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str11);
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_str12), v_t_2417, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2422 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam1_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s1425316842x162872948_lam2, 1, 6, (V[]){v_x_2410, v_k_2412, v_dir_244, v_hash_243, v_hd_2411, v_time_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(V v_rep_240, V v_prog_241, V v_st_242, V v_cmd_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_248 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str0)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = v_st_242; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_2411, NTAG(TAG_Nil)));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0, 1, 7, (V[]){v_prog_241, v_z_245, v_rep_240, v_cmd_243, v_z_246, heff_dup(v_st_242), v_t_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7(V self, V *args) {
  V v_ns_2465 = args[0];
  return v_ns_2465;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9(V self, V *args) {
  V v_t_2477 = args[0];
  return v_t_2477;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13(V self, V *args) {
  V v_x_24102 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12(V self, V *args) {
  V v_x_2487 = args[0];
  V v_x_2484 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2487);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2484, 1)))) {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    V v_n_2489 = heff_get_n(v_x_2484, 1, 2);
    V v_t_2491;
    if (heff_intEq_c_lent(v_n_2489, MK_INT(1LL), 2)) {
      heff_drop(v_n_2489);
      v_t_2491 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str17);
    } else {
      v_t_2491 = heff_strAppend(heff_intShow(v_n_2489), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str18));
    }
    V v_what_2492 = heff_strAppend(v_t_2491, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str19));
    V v_t_2493 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str20), heff_strAppend(v_what_2492, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str21)));
    V v_t_2494 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str22), heff_strAppend(v_cmd_243, v_t_2493));
    V v_t_2495 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2494, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str23)), NTAG(TAG_MkUnit)});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam13, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    heff_drop(v_cmd_243);
    V v_t_24110 = heff_dup(heff_rfield(v_x_2484, 0));
    switch (heff_tag_of(v_t_24110)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2484, 2);
      heff_drop(v_z_245);
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_244, 6);
      V f_ = v_z_246;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_24110, 0ULL, 2);
      return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_242; V a_3 = v_t_244; V a_4 = heff_get_n(v_x_2484, 0, 2); V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_242); r_; });
    }
    default: return heff_nomatch(v_t_24110);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11(V self, V *args) {
  V v_x_2484 = args[0];
  V v_x_2479 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2485 = heff_tag_n(TAG_End, 2, (V[]){v_x_2479, NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2485}));
  return (g_co_2eop_24s495635622x733177935(v_t_2486, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam12, 1, 8, (V[]){v_x_2484, v_cmd_243, v_z_245, v_z_246, v_rep_240, v_prog_241, v_st_242, v_t_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2473 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_cmd_243 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2480 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2482;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Nothing: {
    v_t_2482 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2481 = heff_field(v_x_2473, 0);
    heff_take_n(v_x_2473, 1ULL, 1);
    v_t_2482 = v_x_2481;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_c_2483 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_244), heff_dup(v_x_2479), v_t_2480, v_t_2482));
  V f_ = v_c_2483;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam11, 1, 8, (V[]){v_x_2479, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_rep_240, v_st_242, v_t_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2475;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Nothing: {
    v_t_2475 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2474 = heff_dup(heff_field(v_x_2473, 0));
    v_t_2475 = v_x_2474;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_total_2476 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2475; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2475); r_; });
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str16), v_total_2476, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam9_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2478, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam10, 1, 8, (V[]){v_x_2473, v_prog_241, v_st_242, v_t_244, v_z_245, v_cmd_243, v_z_246, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_2460 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str15)));
  V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
  V v_s_2462 = ({ V a_0 = v_st_242; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2461); r_; });
  V v_path_2463 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2462; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2464 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2463; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2463); r_; });
  V v_a_2466 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2464, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam7_clo)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
  return (g_co_2eop_24s495635622x733177935(v_t_2472, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam8, 1, 7, (V[]){v_prog_241, v_z_245, v_st_242, v_t_244, v_cmd_243, v_z_246, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_242 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2420, 1)))) {
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    V v_n_2425 = heff_get_n(v_x_2420, 1, 2);
    V v_t_2427;
    if (heff_intEq_c_lent(v_n_2425, MK_INT(1LL), 2)) {
      heff_drop(v_n_2425);
      v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str2);
    } else {
      v_t_2427 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str3));
    }
    V v_what_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str4));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str5), heff_strAppend(v_what_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str6)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str7), heff_strAppend(v_cmd_243, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str8)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam5, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    V v_n_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2420, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2448;
    if (heff_intEq_c_lent(v_n_2446, MK_INT(1LL), 2)) {
      heff_drop(v_n_2446);
      v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str9);
    } else {
      v_t_2448 = heff_strAppend(heff_intShow(v_n_2446), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str10));
    }
    V v_t_2449 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str11), heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str12)));
    V v_str_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str13), heff_strAppend(heff_dup(v_cmd_243), v_t_2449));
    V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str14)), NTAG(TAG_MkUnit)});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam6, 1, 7, (V[]){v_st_242, v_t_244, v_z_245, v_prog_241, v_cmd_243, v_z_246, v_rep_240})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2421}));
  return (g_co_2eop_24s495635622x733177935(v_t_2422, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam4, 1, 8, (V[]){v_x_2420, v_cmd_243, v_z_245, v_z_246, v_st_242, v_t_244, v_prog_241, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2419 = ({ V a_0 = heff_dup(v_rep_240); V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_x_2417); V a_3 = v_t_2418; V a_4 = v_x_2413; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam3, 1, 8, (V[]){v_x_2417, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_str1), v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam1_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_lam2, 1, 8, (V[]){v_rep_240, v_prog_241, v_x_2413, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str1, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str5, 6, ": git ");
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(V v_what_240, V v_argv_241) {
top: ;
  V v_t_242 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_243;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_243 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str0);
  } else {
    heff_drop(v_t_242);
    v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_244 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str1), heff_dup(v_argv_241), v_t_243, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_246 = heff_tag_n(TAG_Run, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1, 2, 3, (V[]){v_a_246, v_argv_241, v_what_240});
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_take_field(v_x_2415, 0);
  V v_t_2419;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Exited: {
    V v_n_2417 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2419 = heff_intEq(v_n_2417, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_x_2430;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2415, 3);
    heff_drop(v_argv_241);
    heff_drop(v_what_240);
    heff_drop(v_t_2419);
    v_x_2430 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2419);
    V v_t_2422;
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_argv_241, 0);
      V v_xs_2421 = heff_field(v_argv_241, 1);
      heff_take_n(v_argv_241, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str3); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_argv_241);
    }
    V v_s_2423 = heff_get_n(v_x_2415, 2, 3);
    V v_t_2424 = (g_prelude_2eskipSpaces(v_s_2423, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_s_2423, 0)) - ((int64_t)1ULL));
    V v_t_2426 = (g_prelude_2eskipSpaces(v_s_2423, heff_box_word(v_t_2425), MK_INT(-1LL)));
    V v_t_2427 = heff_strSlice(v_s_2423, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
    V v_t_2428 = heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str4), v_t_2427));
    V v_t_2429 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_str5), v_t_2428));
    v_x_2430 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2429});
  }
  V f_ = v_k_248;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_what_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_lam2, 1, 3, (V[]){v_argv_241, v_what_240, v_k_248})));
}