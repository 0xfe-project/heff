// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Holds 53574
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_property 1899481104
#define LBL_replace 1326354680
#define LBL_reports 1326460931
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shipTo 1043811586
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_version 583465758
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s1191249873x1860951653(V, V, V, V, V);
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a);
extern Clo g_co_2eop_24s1191249873x1860951653_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_clo;
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070(V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_clo;
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_clo;
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2erevNamed(V);
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevNamed_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(V, V, V);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1435008228x557204311(V, V);
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a);
extern Clo g_list_2eany_24s1435008228x557204311_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s336998615x1317776977(V, V, V);
V g_list_2eany_24s336998615x1317776977_entry(V self, V *a);
extern Clo g_list_2eany_24s336998615x1317776977_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s1953633397x1251544744(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1953633397x1251544744_entry(V self, V *a);
extern Clo g_list_2emap_24s1953633397x1251544744_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ereplace_24s174842679x636132898(V, V);
V g_std_2efilesystem_2ereplace_24s174842679x636132898_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereplace_24s174842679x636132898_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3);
        V v_s_248 = heff_strAppend(v_s_247, heff_dup(v_b_243));
        V v_s_249 = heff_strAppend(v_s_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_b_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, v_b_245));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildTarget(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(v_style_242, v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(v_st_2422, v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(v_st_2422, v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
  V v_t_243;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
    V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
    v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_243 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_244 = (g_list_2emap_24s1953633397x1251544744(((V)&g_heff_2ebuild_2ecommands_2estatistic_str3), heff_dup(v_o_240), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), heff_get_n(v_o_240, 7, 12)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_243, v_t_247));
  return heff_strAppend(v_t_241, v_t_248);
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(v_t_242, heff_dup(v_j_241)));
  V v_t_2413;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_245;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_247 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 1);
        v_t_2413 = v_b_247;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_245);
      v_t_2413 = NTAG(TAG_False);
    }
  }
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str1), NTAG(TAG_Nil)});
  HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, heff_dup(v_j_241)));
  V v_t_2425;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_it1_2418 = v_field_2417;
      switch (heff_tag_of(v_it1_2418)) {
      case TAG_JNull: {
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2418, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2418, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2418, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2422 = heff_field(v_it1_2418, 0);
        V v_ru_24it1_2418_24JString = heff_take_reuse_n(v_it1_2418, 1ULL, 1);
        v_t_2425 = heff_tag_at_n(v_ru_24it1_2418_24JString, TAG_Just, 1, (V[]){v_s_2422});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2418, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2418, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2418);
      }
    } else {
      heff_drop(v_field_2417);
      v_t_2425 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2427 = (g_json_2eat_24cpr(v_t_2426, heff_dup(v_j_241)));
  V v_t_2437;
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_it1_2430 = v_field_2429;
      switch (heff_tag_of(v_it1_2430)) {
      case TAG_JNull: {
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2430, 0ULL, 1);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2430, 0ULL, 1);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2430, 0ULL, 1);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2430, 0ULL, 1);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2435 = heff_field(v_it1_2430, 0);
        heff_take_n(v_it1_2430, 1ULL, 1);
        v_t_2437 = v_xs_2435;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2430, 0ULL, 1);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2430);
      }
    } else {
      heff_drop(v_field_2429);
      v_t_2437 = NTAG(TAG_Nil);
    }
  }
  V v_t_2438 = (g_list_2emap_24s1618539892x552009225(v_t_2437));
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str3), NTAG(TAG_Nil)});
  HeffT2 v_t_2440 = (g_json_2eat_24cpr(v_t_2439, heff_dup(v_j_241)));
  V v_t_2444;
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      V v_f_2443 = v_field_2442;
      v_t_2444 = (g_heff_2ebuild_2ecommands_2ejsonFailure(v_f_2443));
    } else {
      heff_drop(v_field_2442);
      v_t_2444 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2446 = (g_json_2eat_24cpr(v_t_2445, v_j_241));
  V v_t_2456;
  {
    V v_field_2448 = v_t_2446.f[1];
    int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
    if ((v_tag_2447 == ((int64_t)0ULL))) {
      V v_it1_2449 = v_field_2448;
      switch (heff_tag_of(v_it1_2449)) {
      case TAG_JNull: {
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2449, 0ULL, 1);
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2449, 0ULL, 1);
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2449, 0ULL, 1);
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2449, 0ULL, 1);
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2454 = heff_field(v_it1_2449, 0);
        heff_take_n(v_it1_2449, 1ULL, 1);
        v_t_2456 = v_xs_2454;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2449, 0ULL, 1);
        v_t_2456 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2449);
      }
    } else {
      heff_drop(v_field_2448);
      v_t_2456 = NTAG(TAG_Nil);
    }
  }
  V v_t_2457 = (g_list_2emap_24s809490196x1189312632(v_t_2456));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2413, v_t_2425, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2438, v_t_2444, MK_INT(0LL), v_t_2457});
}
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeOfJson(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_t_246 = (g_regex_2ematches(v_r_242, v_n_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str1, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str2, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevNamed_str3, 11, "refs/heads/");
Clo g_heff_2ebuild_2ecommands_2erevNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erevNamed_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2erevNamed(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2ecommands_2erevNamed_str0), 2)) {
    return v_rev_240;
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_242 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_241; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_241); r_; });
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return v_rev_240;
        } else {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str1), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str2), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevNamed_str3), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erevNamed(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str21, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam9, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(V v_lit_240, V v_prog_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_246); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2410 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_249));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam2, 2, 10, (V[]){v_c_2415, heff_dup(v_st_243), v_dir_246, v_prog_241, v_p_245, v_flags_244, v_out_247, v_next_248, v_who_242, v_lit_240});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2411));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam1, 2, 1, (V[]){v_x_2412});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_243, v_n_2425));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2428); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_243, v_n_2433));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2436); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam6(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam9(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  heff_drop(v_hd_2451);
  V v_t_2453 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str14)});
  V f_ = v_k_2452;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam10(V self, V *args) {
  V v_r_2461 = args[0];
  return v_r_2461;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam14(V self, V *args) {
  V v_x_2491 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2491);
  V v_t_2492 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  return (g_co_2eop_24s847889387x1388281137(heff_tag_n(TAG_InR, 1, (V[]){v_t_2498}), v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam13(V self, V *args) {
  V v_x_2481 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str20), v_out_247));
  V v_t_2483 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str21)), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})}));
  V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
  heff_room[0] = v_t_2490;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam14, 1, 3, (V[]){v_lit_240, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam12(V self, V *args) {
  V v_x_2469 = args[0];
  V v_ended_2465 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_err_2466 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2469);
  V v_t_2472;
  switch (heff_tag_of(v_ended_2465)) {
  case TAG_Exited: {
    V v_n_2470 = heff_field(v_ended_2465, 0);
    heff_take_n(v_ended_2465, 1ULL, 1);
    v_t_2472 = heff_bool(heff_intEq_c_lent(v_n_2470, MK_INT(0LL), 2));
    heff_drop(v_n_2470);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2465, 0ULL, 1);
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2465);
  }
  if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
    heff_drop(v_err_2466);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_lit_240);
    heff_drop(v_t_2472);
    V f_ = v_next_248;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2472);
    V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2466, NTAG(TAG_MkUnit)});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
    V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
    heff_room[0] = v_t_2480;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam13, 1, 5, (V[]){v_who_242, v_out_247, v_hd_2416, v_lit_240, v_k_2417});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ended_2465 = heff_take_field(v_x_2464, 0);
  V v_err_2466 = heff_get_n(v_x_2464, 2, 3);
  V v_t_2467 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2467}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2468, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam12, 1, 8, (V[]){v_ended_2465, v_next_248, v_hd_2416, v_k_2417, v_err_2466, v_who_242, v_out_247, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2417 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2463;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Nothing: {
    heff_drop(v_x_2429);
    heff_drop(v_flags_244);
    v_c_2463 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam9_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2454 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str15), NTAG(TAG_Nil)});
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2455})});
    V v_t_2457 = (g_prelude_2e_2b_2b(v_os_2454, v_t_2456));
    V v_t_2458 = (g_prelude_2e_2b_2b(v_x_2429, v_t_2457));
    V v_t_2459 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str17), v_t_2458})));
    V v_argv_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str18), v_t_2459});
    V v_t_2462 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2443), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str19), v_argv_2460, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam10_clo)})}));
    v_c_2463 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2462}));
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam11, 1, 8, (V[]){v_x_2443, v_prog_241, v_hd_2416, v_next_248, v_k_2417, v_who_242, v_out_247, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2429 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2417 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2448;
  if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
    heff_drop(v_t_2444);
    v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str4);
  } else {
    heff_drop(v_t_2444);
    V v_t_2445 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str6);
    } else {
      heff_drop(v_t_2445);
      V v_t_2446 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str8);
      } else {
        heff_drop(v_t_2446);
        V v_t_2447 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s336998615x1317776977(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
          heff_drop(v_t_2447);
          v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str11);
        } else {
          heff_drop(v_t_2447);
          v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str12);
        }
      }
    }
  }
  V v_c_2449 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(heff_dup(v_prog_241), heff_dup(v_x_2443), v_t_2448, v_x_2437, NTAG(TAG_Nil)));
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam8, 1, 10, (V[]){v_out_247, v_x_2429, v_flags_244, v_prog_241, v_x_2443, v_hd_2416, v_next_248, v_k_2417, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_lit_240 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_x_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    v_x_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_x_2421 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){v_y_2420});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_dup(heff_field(v_x_2421, 0));
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str0); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam4, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2424));
  V v_t_2431;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2431 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2430 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2432 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str1); V a_1 = v_t_2431; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2437 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam5, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2432));
  V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2429));
  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2437));
  V v_total_2440 = heff_intAdd(heff_intAdd(v_t_2438, v_t_2439), MK_INT(1LL));
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_str2), v_total_2440, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam6_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2442, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam7, 1, 10, (V[]){v_flags_244, v_prog_241, v_x_2437, v_hd_2416, v_out_247, v_x_2429, v_next_248, v_k_2417, v_who_242, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_lam3, 1, 11, (V[]){v_st_243, v_dir_246, v_prog_241, v_p_245, v_hd_2416, v_flags_244, v_out_247, v_next_248, v_k_2417, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V v_path_240, V v_text_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str0), heff_strAppend(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str1)));
  V v_path_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_path_240), v_t_243); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_245 = ({ V a_0 = v_path_244; V a_1 = heff_dup(v_text_241); V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_244); r_; });
  V v_c_249 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1, 2, 3, (V[]){v_c_249, v_text_241, v_path_240});
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2427 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V f_ = v_k_2411;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_2410);
    V f_ = v_k_2411;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    V v_t_2415 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str2), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str3)));
    V v_path_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_path_240), v_t_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_to_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2419 = ({ V a_0 = v_path_2417; V a_1 = v_to_2418; V r_ = (g_std_2efilesystem_2ereplace_24s174842679x636132898(a_0, a_1)); heff_drop(v_path_2417); heff_drop(v_to_2418); r_; });
    V v_c_2423 = heff_tr(heff_call(v_c_2419, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3_clo)}));
    V f_ = v_c_2423;
    heff_room[0] = v_hd_2410;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4, 1, 1, (V[]){v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2, 1, 4, (V[]){v_k_2411, v_text_241, v_path_240, v_hd_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str10, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str11, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str17, 1, "\"");
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_247); r_; });
      V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam0_clo)}));
      return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam1, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})});
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2424 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str2), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str3)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2424});
    }
  }
  case TAG_Just: {
    V v_kept_2425 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2425, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2425);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2425);
        V v_path_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_c_2427 = ({ V a_0 = v_path_2426; V a_1 = v_text_243; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2426); r_; });
        V v_c_2431 = heff_tr(heff_call(v_c_2427, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam4_clo)}));
        return heff_tail(v_c_2431, 2, (V[]){v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam5, 1, 2, (V[]){v_path_242, v_z_246})});
      } else {
        heff_drop(v_z_245);
        V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str6); V a_1 = v_kept_2425; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str7), v_kept_2425, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_kept_2425); r_; });
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str8); V a_1 = v_text_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str9), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_243); r_; });
        HeffT2 v_t_2438 = (g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(MK_INT(1LL), v_t_2436, v_t_2437));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_n_2441 = v_field_2439;
          V v_x22_2442 = v_field_2440;
          V v_x_2451;
          switch (heff_tag_of(v_x22_2442)) {
          case TAG_MkPair: {
            V v_kept_2443 = heff_field(v_x22_2442, 0);
            V v_text_2444 = heff_field(v_x22_2442, 1);
            V v_ru_24x22_2442_24MkPair = heff_take_reuse_n(v_x22_2442, 3ULL, 2);
            V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str10), heff_intShow(v_n_2441));
            V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str11), heff_strAppend(v_path_242, v_t_2445));
            V v_t_2447 = ({ V a_0 = v_kept_2443; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2443); r_; });
            V v_t_2448 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str13), heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str14)));
            V v_t_2449 = ({ V a_0 = v_text_2444; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2444); r_; });
            V v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str16), heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str17)));
            v_x_2451 = heff_tag_at_n(v_ru_24x22_2442_24MkPair, TAG_Wrong, 2, (V[]){v_t_2446, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2448, v_t_2450})});
            break;
          }
          default: heff_nomatch(v_x22_2442);
          }
          return heff_tail(v_z_246, 1, (V[]){v_x_2451});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 0ULL, 1);
    V v_t_2422 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str0), v_path_242), heff_tag_at_n(v_ru_24x_2420_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str1)})});
    V f_ = v_z_246;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2420, 0ULL, 1);
    V f_ = v_z_246;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  V v_path_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2415 = ({ V a_0 = v_path_2414; V a_1 = v_text_243; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2414); r_; });
  V v_c_2419 = heff_tr(heff_call(v_c_2415, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam2_clo)}));
  V f_ = v_c_2419;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam3, 1, 2, (V[]){v_path_242, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 0ULL, 1);
    V v_t_2434 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str4), v_path_242), heff_tag_at_n(v_ru_24x_2432_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_str5)})});
    V f_ = v_z_246;
    args[0] = v_t_2434;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2432, 0ULL, 1);
    V f_ = v_z_246;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2432);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s1191249873x1860951653(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str2, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str3, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str4, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str5, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str6, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str7, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str8, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str10, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str11, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str12, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str13, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str14, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str16, 13, "cannot fetch ");
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(V v_path_240, V v_v_241, V v_dir_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_dir_242, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str0), v_t_243), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str1), heff_dup(v_v_241)), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str3), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str5), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str7), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str8), v_t_249});
  V v_t_2411 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2412;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str9);
  } else {
    heff_drop(v_t_2411);
    v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2413 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str10), v_t_2410, v_t_2412, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2415 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam1, 2, 3, (V[]){v_a_2415, v_path_240, v_v_241});
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_ended_2428 = heff_take_field(v_x_2427, 0);
  V v_err_2429 = heff_get_n(v_x_2427, 2, 3);
  V v_t_2432;
  switch (heff_tag_of(v_ended_2428)) {
  case TAG_Exited: {
    V v_n_2430 = heff_field(v_ended_2428, 0);
    heff_take_n(v_ended_2428, 1ULL, 1);
    v_t_2432 = heff_bool(heff_intEq_c_lent(v_n_2430, MK_INT(0LL), 2));
    heff_drop(v_n_2430);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2428, 0ULL, 1);
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2428);
  }
  V v_x_2443;
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop(v_path_240);
    heff_drop(v_v_241);
    heff_drop(v_err_2429);
    heff_drop(v_t_2432);
    v_x_2443 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2432);
    V v_t_2433 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
    V v_s_2434 = v_err_2429;
    V v_t_2435 = (g_prelude_2eskipSpaces(v_s_2434, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_s_2434, 0)) - ((int64_t)1ULL));
    V v_t_2437 = (g_prelude_2eskipSpaces(v_s_2434, heff_box_word(v_t_2436), MK_INT(-1LL)));
    V v_t_2438 = heff_strSlice(v_s_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str11), v_t_2433), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str12), v_t_2438));
    V v_t_2440 = heff_strAppend(heff_dup(v_v_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str13), v_t_2439));
    V v_t_2441 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str14), v_t_2440));
    V v_t_2442 = heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str15), v_t_2441));
    v_x_2443 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_str16), v_t_2442)});
  }
  V f_ = v_k_2417;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_a_2415 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2418 = heff_take_field(v_hd_2416, 1);
  V v_malg_2419 = heff_get_n(v_hd_2416, 2, 3);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2419, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
  V f_ = v_bind_2418;
  args[0] = v_t_2426;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_lam2, 1, 3, (V[]){v_path_240, v_v_241, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str8, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str10, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str11, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str13, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str16, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str17, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str18, 34, "heff get: cannot write package.hf\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str19, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str20, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str21, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam15, 3, 0};
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201(V v_prog_240, V v_ps_241, V v_text_242, V v_pk_243, V v_path_244, V v_v_245) {
top: ;
  V v_require_246 = heff_take_field(v_pk_243, 2);
  V v_module_247 = heff_take_field(v_pk_243, 0);
  V v_heff_248 = heff_take_field(v_pk_243, 1);
  V v_replace_249 = heff_get_n(v_pk_243, 3, 4);
  HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_244), heff_dup(v_v_245)));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_prog_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_text_242);
      heff_drop(v_v_245);
      heff_drop(v_require_246);
      heff_drop(v_module_247);
      heff_drop(v_heff_248);
      heff_drop(v_replace_249);
      V v_why_2413 = v_field_2412;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam0, 2, 2, (V[]){v_path_244, v_why_2413});
    } else {
      heff_drop(v_field_2412);
      V v_c_2438 = (g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam3, 2, 9, (V[]){v_c_2438, v_ps_241, v_path_244, v_v_245, v_require_246, v_text_242, v_module_247, v_heff_248, v_replace_249});
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_malg_2417 = heff_env(self)[0];
  V v_bind_2416 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(v_malg_2417, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
  V f_ = v_bind_2416;
  heff_room[0] = v_t_2436;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam2, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_why_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2416 = heff_take_field(v_hd_2414, 1);
  V v_malg_2417 = heff_get_n(v_hd_2414, 2, 3);
  V v_t_2418 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str0), v_why_2413));
  V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str1), v_t_2418), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str2));
  V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_malg_2417), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_dup(v_bind_2416);
  args[0] = v_t_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam1, 1, 3, (V[]){v_malg_2417, v_bind_2416, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2461);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam5(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  heff_room[0] = v_t_2460;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam6, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam10(V self, V *args) {
  V v_x_2493 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2493);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam9(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  heff_room[0] = v_t_2492;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam10, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam12(V self, V *args) {
  V v_x_24114 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24114);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam11(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24105);
  V v_t_24106 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  heff_room[0] = v_t_24113;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam12, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam14(V self, V *args) {
  V v_x_24138 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24138);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam13(V self, V *args) {
  V v_x_24129 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24129);
  V v_t_24130 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
  V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
  V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
  V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
  V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24136})}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  heff_room[0] = v_t_24137;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam14, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam15(V self, V *args) {
  V v_x_24151 = args[0];
  V v_hd_24152 = args[1];
  V v_k_24153 = args[2];
  heff_drop(v_hd_24152);
  V f_ = v_k_24153;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24151});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam18(V self, V *args) {
  V v_x_24174 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24174);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam17(V self, V *args) {
  V v_x_24165 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24165);
  V v_t_24166 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24166})});
  V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
  V v_t_24169 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24168})});
  V v_t_24170 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
  V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24170})});
  V v_t_24172 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24171})});
  V v_t_24173 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24172})}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  heff_room[0] = v_t_24173;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam18, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam19(V self, V *args) {
  V v_x_24186 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24186);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam16(V self, V *args) {
  V v_x_24155 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24155)) {
  case TAG_Left: {
    V v_ru_24x_24155_24Left = heff_take_reuse_n(v_x_24155, 0ULL, 1);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    V v_t_24157 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str18), NTAG(TAG_MkUnit)});
    V v_t_24158 = heff_tag_at_n(v_ru_24x_24155_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
    V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
    V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})});
    V v_t_24164 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
    V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
    heff_room[0] = v_t_24164;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam17, 1, 2, (V[]){v_hd_2439, v_k_2440});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_24155_24Right = heff_take_reuse_n(v_x_24155, 0ULL, 1);
    V v_t_24176 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str19), v_v_245));
    V v_t_24177 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str20), v_t_24176), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str21));
    V v_t_24178 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24177, NTAG(TAG_MkUnit)});
    V v_t_24179 = heff_tag_at_n(v_ru_24x_24155_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24178})});
    V v_t_24180 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24179})});
    V v_t_24181 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24180})});
    V v_t_24182 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24181})});
    V v_t_24183 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24182})});
    V v_t_24184 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24183})});
    V v_t_24185 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24184})}));
    V f_ = heff_get_n(v_hd_2439, 1, 3);
    heff_room[0] = v_t_24185;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam19, 1, 1, (V[]){v_k_2440});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24155);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_hd_2439 = heff_env(self)[1];
  V v_k_2440 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_require_246 = heff_env(self)[4];
  V v_v_245 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  V v_module_247 = heff_env(self)[7];
  V v_heff_248 = heff_env(self)[8];
  V v_replace_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    V v_why_2474 = heff_field(v_x_2465, 0);
    V v_ru_24x_2465_24Left = heff_take_reuse_n(v_x_2465, 1ULL, 1);
    heff_drop(v_x_2473);
    heff_drop(v_path_244);
    heff_drop(v_require_246);
    heff_drop(v_v_245);
    heff_drop(v_text_242);
    heff_drop(v_module_247);
    heff_drop(v_heff_248);
    heff_drop(v_replace_249);
    V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str6), v_why_2474), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str7));
    V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2475, NTAG(TAG_MkUnit)});
    V v_t_2477 = heff_tag_at_n(v_ru_24x_2465_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})}));
    V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
    heff_room[0] = v_t_2483;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam9, 1, 2, (V[]){v_hd_2439, v_k_2440});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2465_24Right = heff_take_reuse_n(v_x_2465, 0ULL, 1);
    switch (heff_tag_of(v_x_2473)) {
    case TAG_Left: {
      V v_why_2495 = heff_field(v_x_2473, 0);
      V v_ru_24x_2473_24Left = heff_take_reuse_n(v_x_2473, 1ULL, 1);
      heff_drop(v_path_244);
      heff_drop(v_require_246);
      heff_drop(v_v_245);
      heff_drop(v_text_242);
      heff_drop(v_module_247);
      heff_drop(v_heff_248);
      heff_drop(v_replace_249);
      V v_t_2496 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str8), v_why_2495), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str9));
      V v_t_2497 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2496, NTAG(TAG_MkUnit)});
      V v_t_2498 = heff_tag_at_n(v_ru_24x_2465_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tag_at_n(v_ru_24x_2473_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
      V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
      V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
      V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
      V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
      V v_t_24104 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})}));
      V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
      heff_room[0] = v_t_24104;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam11, 1, 2, (V[]){v_hd_2439, v_k_2440});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      V v_name_24115 = heff_field(v_x_2473, 0);
      V v_ru_24x_2473_24Right = heff_take_reuse_n(v_x_2473, 1ULL, 1);
      V v_x1_24116 = (g_list_2eany_24s1435008228x557204311(v_path_244, v_require_246));
      V v_t_24117;
      if (!(heff_dup(v_x1_24116) == NTAG(TAG_True))) {
        heff_drop(v_x1_24116);
        v_t_24117 = (g_list_2eany_24s944501138x775098345(v_name_24115, v_require_246));
      } else {
        heff_drop(v_x1_24116);
        v_t_24117 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
        heff_drop(v_require_246);
        heff_drop(v_v_245);
        heff_drop(v_text_242);
        heff_drop(v_module_247);
        heff_drop(v_heff_248);
        heff_drop(v_replace_249);
        heff_drop(v_t_24117);
        V v_t_24118 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str10), heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str11)));
        V v_t_24119 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str12), heff_strAppend(v_name_24115, v_t_24118));
        V v_t_24120 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str13), v_t_24119), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str14));
        V v_t_24121 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24120, NTAG(TAG_MkUnit)});
        V v_t_24122 = heff_tag_at_n(v_ru_24x_2465_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
        V v_t_24123 = heff_tag_at_n(v_ru_24x_2473_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
        V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
        V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
        V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
        V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})});
        V v_t_24128 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})}));
        V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
        heff_room[0] = v_t_24128;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam13, 1, 2, (V[]){v_hd_2439, v_k_2440});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24x_2465_24Right, 1);
        heff_drop_cell(v_ru_24x_2473_24Right, 1);
        heff_drop(v_t_24117);
        V v_path_24139 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str15); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_24140 = (g_list_2eany_24s1435008228x557204311(v_path_244, v_require_246));
        V v_t_24142;
        if ((heff_dup(v_t_24140) == NTAG(TAG_True))) {
          heff_drop(v_name_24115);
          heff_drop(v_t_24140);
          v_t_24142 = (g_list_2emap_24s1193924222x1531824795(heff_dup(v_path_244), heff_dup(v_v_245), v_require_246));
        } else {
          heff_drop(v_t_24140);
          V v_t_24141 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_24115, heff_dup(v_path_244), heff_dup(v_v_245)}), NTAG(TAG_Nil)});
          v_t_24142 = (g_prelude_2e_2b_2b(v_require_246, v_t_24141));
        }
        V v_text_24143 = (g_heff_2ebuild_2eproject_2ewithPackage(v_text_242, heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_module_247, v_heff_248, v_t_24142, v_replace_249})));
        V v_text_24149;
        if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str16), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str17))) {
          HeffT2 v_t_24144 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_24143)));
          {
            V v_field_24146 = v_t_24144.f[1];
            int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
            if ((v_tag_24145 == ((int64_t)0ULL))) {
              V v_x_24147 = v_field_24146;
              heff_drop(v_x_24147);
              v_text_24149 = v_text_24143;
            } else {
              heff_drop(v_text_24143);
              V v_out_24148 = v_field_24146;
              v_text_24149 = v_out_24148;
            }
          }
        } else {
          v_text_24149 = v_text_24143;
        }
        V v_c_24150 = ({ V a_0 = v_path_24139; V a_1 = v_text_24149; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_24139); r_; });
        V v_c_24154 = heff_tr(heff_call(v_c_24150, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam15_clo)}));
        V f_ = v_c_24154;
        heff_room[0] = heff_dup(v_hd_2439);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam16, 1, 4, (V[]){v_hd_2439, v_k_2440, v_path_244, v_v_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_x_2473);
    }
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam7(V self, V *args) {
  V v_x_2465 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_hd_2439 = heff_env(self)[3];
  V v_k_2440 = heff_env(self)[4];
  V v_require_246 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  V v_module_247 = heff_env(self)[7];
  V v_heff_248 = heff_env(self)[8];
  V v_replace_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_st_2466 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_a_2467 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
  V v_t_2468 = (g_std_2epath_2eparse(v_st_2466, v_a_2467));
  V v_t_2469 = (g_std_2epath_2eparse(v_st_2466, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str5)));
  V v_t_2470 = (g_std_2epath_2ejoin(v_t_2468, v_t_2469));
  V v_t_2471 = ({ V a_0 = v_st_2466; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2466); heff_drop(v_t_2470); r_; });
  V v_c_2472 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(v_ps_241, v_t_2471));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_2439);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam8, 1, 10, (V[]){v_x_2465, v_hd_2439, v_k_2440, v_path_244, v_require_246, v_v_245, v_text_242, v_module_247, v_heff_248, v_replace_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_require_246 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  V v_module_247 = heff_env(self)[7];
  V v_heff_248 = heff_env(self)[8];
  V v_replace_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    V v_why_2442 = heff_field(v_x_2441, 0);
    V v_ru_24x_2441_24Left = heff_take_reuse_n(v_x_2441, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    heff_drop(v_require_246);
    heff_drop(v_text_242);
    heff_drop(v_module_247);
    heff_drop(v_heff_248);
    heff_drop(v_replace_249);
    V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str3), v_why_2442), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_str4));
    V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2443, NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_at_n(v_ru_24x_2441_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})}));
    V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
    heff_room[0] = v_t_2451;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam5, 1, 2, (V[]){v_hd_2439, v_k_2440});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2441, 0ULL, 1);
    V v_t_2463 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_c_2464 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(heff_dup(v_ps_241), v_t_2463, heff_dup(v_path_244)));
    V f_ = v_c_2464;
    heff_room[0] = heff_dup(v_hd_2439);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam7, 1, 10, (V[]){v_ps_241, v_path_244, v_v_245, v_hd_2439, v_k_2440, v_require_246, v_text_242, v_module_247, v_heff_248, v_replace_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam3(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_require_246 = heff_env(self)[4];
  V v_text_242 = heff_env(self)[5];
  V v_module_247 = heff_env(self)[6];
  V v_heff_248 = heff_env(self)[7];
  V v_replace_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2438;
  args[0] = heff_dup(v_hd_2439);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201_lam4, 1, 10, (V[]){v_hd_2439, v_k_2440, v_ps_241, v_path_244, v_v_245, v_require_246, v_text_242, v_module_247, v_heff_248, v_replace_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str3, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str7, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str8, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str9, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str10, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070(V v_prog_240, V v_spec_241) {
top: ;
  V v_path_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = ({ V a_0 = v_path_242; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_242); r_; });
  V v_c_247 = heff_tr(heff_call(v_c_243, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam1, 2, 3, (V[]){v_c_247, v_spec_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_245 = args[1];
  V v_k_246 = args[2];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam5(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V v_t_2463 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam6(V self, V *args) {
  V v_x_2487 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2487);
  V v_t_2488 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam10(V self, V *args) {
  V v_x_24113 = args[0];
  V v_k_24112 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2498 = heff_env(self)[2];
  V v_path_24109 = heff_env(self)[3];
  V v_hd_24111 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_24113)) {
  case TAG_Left: {
    V v_why_24114 = heff_field(v_x_24113, 0);
    heff_take_n(v_x_24113, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_x_2498);
    heff_drop(v_path_24109);
    heff_drop(v_hd_24111);
    V f_ = v_k_24112;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_24114});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_it1_24115 = heff_field(v_x_24113, 0);
    heff_take_n(v_x_24113, 1ULL, 1);
    switch (heff_tag_of(v_it1_24115)) {
    case TAG_Nothing: {
      V v_t_24116 = (g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(v_prog_240, v_x_2498, v_path_24109, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str7)));
      V f_ = v_t_24116;
      heff_room[0] = v_hd_24111;
      heff_room[1] = v_k_24112;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_v_24117 = heff_field(v_it1_24115, 0);
      heff_take_n(v_it1_24115, 1ULL, 1);
      heff_drop(v_prog_240);
      heff_drop(v_x_2498);
      heff_drop(v_path_24109);
      heff_drop(v_hd_24111);
      V f_ = v_k_24112;
      args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_24117});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it1_24115);
    }
  }
  default: return heff_nomatch(v_x_24113);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam9(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_c_24110 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2498 = heff_env(self)[2];
  V v_path_24109 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24110;
  args[0] = heff_dup(v_hd_24111);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam10, 1, 5, (V[]){v_k_24112, v_prog_240, v_x_2498, v_path_24109, v_hd_24111});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam11(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_rev_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24130);
  V f_ = v_k_24131;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_rev_24118});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam13(V self, V *args) {
  V v_x_24146 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24146);
  V v_t_24147 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24147})});
  V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
  V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
  V v_t_24153 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24152})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24153}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam14(V self, V *args) {
  V v_x_24162 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24162) == NTAG(TAG_True))) {
    heff_drop(v_x_24162);
    return (g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(v_prog_240, v_hd_248, v_k_249));
  } else {
    heff_drop(v_x_24162);
    heff_drop(v_prog_240);
    heff_drop_rec(v_hd_248, 3);
    V f_ = v_k_249;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam12(V self, V *args) {
  V v_x_24135 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  V v_s_2471 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2498 = heff_env(self)[4];
  V v_y_2428 = heff_env(self)[5];
  V v_pk_2470 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24135)) {
  case TAG_Left: {
    V v_why_24136 = heff_field(v_x_24135, 0);
    V v_ru_24x_24135_24Left = heff_take_reuse_n(v_x_24135, 1ULL, 1);
    heff_drop(v_s_2471);
    heff_drop(v_prog_240);
    heff_drop(v_x_2498);
    heff_drop(v_y_2428);
    heff_drop(v_pk_2470);
    V v_t_24137 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str10), v_why_24136), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str11));
    V v_t_24138 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24137, NTAG(TAG_MkUnit)});
    V v_t_24139 = heff_tag_at_n(v_ru_24x_24135_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24144})}));
    V f_ = heff_dup(heff_rfield(v_hd_248, 1));
    heff_room[0] = v_t_24145;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam13, 1, 2, (V[]){v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ver_24154 = heff_field(v_x_24135, 0);
    heff_take_n(v_x_24135, 1ULL, 1);
    HeffT2 v_t_24155 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(v_s_2471));
    V v_t_24160;
    {
      V v_field_24156 = v_t_24155.f[0];
      V v_field_24157 = v_t_24155.f[1];
      V v_x_24158 = v_field_24156;
      V v_y_24159 = v_field_24157;
      heff_drop(v_y_24159);
      v_t_24160 = v_x_24158;
    }
    V v_c_24161 = (g_heff_2ebuild_2ecommands_2egetRequire_24s1562164645x446927201(heff_dup(v_prog_240), v_x_2498, v_y_2428, v_pk_2470, v_t_24160, v_ver_24154));
    V f_ = v_c_24161;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam14, 1, 3, (V[]){v_prog_240, v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24135);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam8(V self, V *args) {
  V v_x_2498 = args[0];
  V v_s_2471 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  V v_pk_2470 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2499 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2471)));
  {
    V v_field_24100 = v_t_2499.f[0];
    V v_field_24101 = v_t_2499.f[1];
    V v_x_24102 = v_field_24100;
    heff_drop(v_x_24102);
    V v_y_24103 = v_field_24101;
    V v_c_24134;
    switch (heff_tag_of(v_y_24103)) {
    case TAG_Nothing: {
      HeffT2 v_t_24104 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2471)));
      {
        V v_field_24105 = v_t_24104.f[0];
        V v_field_24106 = v_t_24104.f[1];
        V v_x_24107 = v_field_24105;
        V v_y_24108 = v_field_24106;
        heff_drop(v_y_24108);
        V v_path_24109 = v_x_24107;
        V v_c_24110 = (g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886(heff_dup(v_prog_240), heff_dup(v_path_24109)));
        v_c_24134 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam9, 2, 4, (V[]){v_c_24110, heff_dup(v_prog_240), heff_dup(v_x_2498), v_path_24109});
      }
      break;
    }
    case TAG_Just: {
      V v_rev_24118 = heff_field(v_y_24103, 0);
      heff_take_n(v_y_24103, 1ULL, 1);
      HeffT2 v_t_24119 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2471)));
      {
        V v_field_24120 = v_t_24119.f[0];
        V v_field_24121 = v_t_24119.f[1];
        V v_t_24122 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str8); V a_1 = v_rev_24118; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str9), v_rev_24118, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_24123 = (g_heff_2ebuild_2eproject_2epseudoParts(v_t_24122));
        HeffT2 v_t_24124 = ({ V a_0 = v_rev_24118; V a_1 = v_t_24123; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_24123); r_; });
        V v_t_24129;
        {
          V v_field_24125 = v_t_24124.f[0];
          V v_field_24126 = v_t_24124.f[1];
          V v_x_24127 = v_field_24125;
          V v_y_24128 = v_field_24126;
          heff_drop(v_y_24128);
          v_t_24129 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24127; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24127); r_; });
        }
        if (heff_intEq_c(v_t_24129, MK_INT(3LL))) {
          heff_drop(v_field_24120);
          heff_drop(v_field_24121);
          v_c_24134 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam11, 2, 1, (V[]){v_rev_24118});
        } else {
          V v_x_24132 = v_field_24120;
          V v_y_24133 = v_field_24121;
          heff_drop(v_y_24133);
          v_c_24134 = (g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(heff_dup(v_prog_240), heff_dup(v_x_2498), v_x_24132, v_rev_24118));
        }
      }
      break;
    }
    default: heff_nomatch(v_y_24103);
    }
    V f_ = v_c_24134;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam12, 1, 7, (V[]){v_hd_248, v_k_249, v_s_2471, v_prog_240, v_x_2498, v_y_2428, v_pk_2470});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam7(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_s_2471 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  V v_pk_2470 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2497 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_2496, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str6)));
  V f_ = v_c_2497;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam8, 1, 6, (V[]){v_s_2471, v_prog_240, v_hd_248, v_k_249, v_y_2428, v_pk_2470});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  V v_spec_241 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    heff_drop(v_spec_241);
    heff_drop(v_prog_240);
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str1), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
    V f_ = heff_dup(heff_rfield(v_hd_248, 1));
    heff_room[0] = v_t_2419;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam3, 1, 2, (V[]){v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Right = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    HeffT2 v_t_2429 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2428));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        heff_drop(v_spec_241);
        heff_drop(v_prog_240);
        heff_drop(v_y_2428);
        V v_p_2432 = v_field_2431;
        heff_drop(v_p_2432);
        V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str2), NTAG(TAG_MkUnit)});
        V v_t_2434 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
        V f_ = heff_dup(heff_rfield(v_hd_248, 1));
        heff_room[0] = v_t_2440;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam4, 1, 2, (V[]){v_hd_248, v_k_249});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_x_2449 = v_field_2431;
        HeffT2 v_t_2450 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2449));
        {
          V v_field_2452 = v_t_2450.f[1];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            heff_drop(v_spec_241);
            heff_drop(v_prog_240);
            heff_drop(v_y_2428);
            V v_x_2453 = v_field_2452;
            heff_drop(v_x_2453);
            V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str3), NTAG(TAG_MkUnit)});
            V v_t_2455 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
            V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
            V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
            V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
            V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})}));
            V f_ = heff_dup(heff_rfield(v_hd_248, 1));
            heff_room[0] = v_t_2461;
            heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam5, 1, 2, (V[]){v_hd_248, v_k_249});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            V v_pk_2470 = v_field_2452;
            switch (heff_tag_of(v_spec_241)) {
            case TAG_Nothing: {
              heff_drop(v_y_2428);
              heff_drop_cell(v_ru_24x_2410_24Right, 1);
              heff_drop(v_pk_2470);
              return (g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(v_prog_240, v_hd_248, v_k_249));
            }
            case TAG_Just: {
              V v_s_2471 = heff_field(v_spec_241, 0);
              V v_ru_24spec_241_24Just = heff_take_reuse_n(v_spec_241, 1ULL, 1);
              HeffT2 v_t_2472 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2471)));
              V v_t_2477;
              {
                V v_field_2473 = v_t_2472.f[0];
                V v_field_2474 = v_t_2472.f[1];
                V v_x_2475 = v_field_2473;
                V v_y_2476 = v_field_2474;
                heff_drop(v_y_2476);
                v_t_2477 = v_x_2475;
              }
              if (heff_strEq_c(v_t_2477, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                heff_drop(v_prog_240);
                heff_drop(v_y_2428);
                heff_drop(v_pk_2470);
                heff_drop(v_s_2471);
                V v_t_2478 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_str5));
                V v_t_2479 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2478, NTAG(TAG_MkUnit)});
                V v_t_2480 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
                V v_t_2481 = heff_tag_at_n(v_ru_24spec_241_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
                V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
                V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
                V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
                V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
                V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
                V f_ = heff_dup(heff_rfield(v_hd_248, 1));
                heff_room[0] = v_t_2486;
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam6, 1, 2, (V[]){v_hd_248, v_k_249});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                heff_drop_cell(v_ru_24x_2410_24Right, 1);
                heff_drop_cell(v_ru_24spec_241_24Just, 1);
                V v_c_2495 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
                V f_ = v_c_2495;
                heff_room[0] = heff_dup(v_hd_248);
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam7, 1, 6, (V[]){v_hd_248, v_s_2471, v_prog_240, v_k_249, v_y_2428, v_pk_2470});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
            default: return heff_nomatch(v_spec_241);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_spec_241 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1944783556x1600707070_lam2, 1, 4, (V[]){v_hd_248, v_k_249, v_spec_241, v_prog_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2413}));
  return heff_tail(heff_dup(v_bind_244), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1, 1, 5, (V[]){v_malg_245, v_bind_244, heff_dup(v_st_240), v_bin_241, v_k_243})});
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2(V self, V *args) {
  V v_v_2416 = args[0];
  return v_v_2416;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4(V self, V *args) {
  V v_d_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_std_2epath_2eparse(v_st_240, v_d_2430));
  V v_t_2432 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str5)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = v_st_240; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_t_2435 = (g_std_2epath_2eparse(v_st_240, v_bin_241));
  V v_t_2436 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str6)));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  V v_t_2438 = ({ V a_0 = v_st_240; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2437); r_; });
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2434, v_t_2438, 0));
  heff_drop(v_t_2434);
  heff_drop(v_t_2438);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_malg_245 = heff_env(self)[4];
  V v_bind_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2427;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    v_path_2427 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    v_path_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_sep_2428;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str2))) {
    v_sep_2428 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str3);
  } else {
    v_sep_2428 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str4);
  }
  V v_t_2429;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2428, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2428);
    v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2427, NTAG(TAG_Nil)});
  } else {
    v_t_2429 = ({ V a_0 = v_sep_2428; V a_1 = v_path_2427; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2428, v_path_2427, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_2428); heff_drop(v_path_2427); r_; });
  }
  V v_t_2439 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2429; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2429); r_; });
  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_malg_245);
    heff_drop(v_bind_244);
    heff_drop(v_t_2439);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2439);
    V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str8)));
    V v_t_2441 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str9)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
    V f_ = v_bind_244;
    heff_room[0] = v_t_2448;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_bin_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2423}));
  V f_ = heff_dup(v_bind_244);
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3, 1, 6, (V[]){v_x_2415, v_st_240, v_bin_241, v_k_243, v_malg_245, v_bind_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_str0, 0, "");
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(V v_rep_240, V v_x1_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x1_241, 0);
    V v_rest_246 = heff_field(v_x1_241, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(MK_INT(2026LL), ((V)&g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_str0), MK_INT(1LL), v_rep_240, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam1, 2, 4, (V[]){v_c_247, v_rep_240, v_acc_242, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam3(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_r_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_r_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_file_2415 = heff_env(self)[1];
  V v_wrong_2417 = heff_env(self)[2];
  V v_reports_2418 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, v_file_2415, v_wrong_2417, v_reports_2418, v_x_2422, v_hd_2420, v_k_2421));
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_2415 = heff_env(self)[2];
  V v_wrong_2417 = heff_env(self)[3];
  V v_reports_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam5, 1, 6, (V[]){v_rep_240, v_file_2415, v_wrong_2417, v_reports_2418, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_242, v_x_2424));
  V v_t_2426 = ({ V a_0 = v_rep_240; V a_1 = v_rest_246; V a_2 = v_t_2425; V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2423;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Settled: {
    V v_r_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_c_2423 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam3, 2, 1, (V[]){v_r_2411});
    break;
  }
  case TAG_Pend: {
    V v_p_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_file_2415 = heff_take_field(v_p_2414, 0);
    V v_outcomes_2416 = heff_take_field(v_p_2414, 3);
    V v_wrong_2417 = heff_take_field(v_p_2414, 1);
    V v_reports_2418 = heff_get_n(v_p_2414, 2, 7);
    V v_c_2419 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_file_2415); V a_2 = v_outcomes_2416; V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_c_2423 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam4, 2, 5, (V[]){v_c_2419, heff_dup(v_rep_240), v_file_2415, v_wrong_2417, v_reports_2418});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam6, 1, 5, (V[]){v_acc_242, v_rep_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_lam2, 1, 5, (V[]){v_rep_240, v_hd_248, v_acc_242, v_rest_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}