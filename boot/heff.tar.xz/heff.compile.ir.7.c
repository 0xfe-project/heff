// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(V, V);
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_clo;
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2efoldList(V, V, V);
V g_heff_2ecompile_2eir_2efoldList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_clo;
HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_clo;
V g_heff_2ecompile_2eonce_2emoved(V, V);
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2emoved_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V, V, V);
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24cpr(V, V);
V g_prelude_2etraverse_24s1218231813x1819446478(V, V);
V g_prelude_2etraverse_24s1218231813x1819446478_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1218231813x1819446478_clo;
V g_prelude_2etraverse_24s1237512785x1947069493(V);
V g_prelude_2etraverse_24s1237512785x1947069493_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1237512785x1947069493_clo;
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
V g_prelude_2etraverse_24s2126788141x1913216601(V);
V g_prelude_2etraverse_24s2126788141x1913216601_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2126788141x1913216601_clo;
HEFF_LIT(g_heff_2ecompile_2eir_2edefaultTag_str0, 1, "_");

static V g_heff_2ecompile_2eir_2edefaultTag_val;
static HEFF_ONCE g_heff_2ecompile_2eir_2edefaultTag_st;
static V g_heff_2ecompile_2eir_2edefaultTag_init(void) {
  return ((V)&g_heff_2ecompile_2eir_2edefaultTag_str0);
}
V g_heff_2ecompile_2eir_2edefaultTag_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eir_2edefaultTag_st)) return g_heff_2ecompile_2eir_2edefaultTag_val;
  return heff_global(&g_heff_2ecompile_2eir_2edefaultTag_val, &g_heff_2ecompile_2eir_2edefaultTag_st, g_heff_2ecompile_2eir_2edefaultTag_init);
}
Clo g_heff_2ecompile_2eir_2efoldList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldList_entry, 3, 0};

V g_heff_2ecompile_2eir_2efoldList(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_es_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), heff_dup(v_e_243), v_acc_242}));
    V t_0 = v_f_240;
    V t_1 = v_es_244;
    V t_2 = v_t_245;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2efoldList_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2efoldList(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eallI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallI_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    if ((heff_dup(v_b_241) == NTAG(TAG_True))) {
      V t_0 = v_bs_242;
      v_x1_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallI(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_t_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_t_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_t_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(V v_lit_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2411 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_248, v_a_249, heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(v_lit_240, v_b_2410, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_241, 0);
    V v_arms_2423 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_lam0, 1, 1, (V[]){v_lit_240}), v_arms_2423));
    return heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2422, v_t_2429});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2443 = heff_field(v_e_241, 0);
    V v_a_2444 = heff_field(v_e_241, 1);
    V v_b_2445 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2446 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2443, v_a_2444, heff_hole()});
    V v_u_2447 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(v_lit_240, v_b_2445, v_cell_2446));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_vs_2426 = heff_field(v_x2_2424, 1);
    V v_b_2427 = heff_field(v_x2_2424, 2);
    V v_ru_24x2_2424_24MkArm = heff_take_reuse_n(v_x2_2424, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2428 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(v_lit_240, v_b_2427));
    return heff_tag_re_n(v_ru_24x2_2424_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2425, v_vs_2426, v_t_2428});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EGlobal: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_ELam: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EApp: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(v_lit_240, v_lit_241, v_b_2411));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_249, v_a_2410, v_x_2415})}});
      } else {
        heff_drop(v_x_249);
        heff_drop(v_a_2410);
        heff_drop_cell(v_ru_24e_242_24ELet, 3);
        heff_drop(v_field_2414);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ERecord: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EProj: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 4); r_; });
  }
  case TAG_ETag: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 3); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_242, 0);
    V v_arms_2426 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2435 = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr_lam0, 1, 2, (V[]){heff_dup(v_lit_240), v_lit_241}), v_arms_2426));
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_x_2438 = v_field_2437;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2425, v_x_2438})}});
      } else {
        heff_drop(v_s_2425);
        heff_drop_cell(v_ru_24e_242_24EMatch, 2);
        heff_drop(v_field_2437);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EPrim: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EPrimCall: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_ECall: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EInt: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFloat: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EStr: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EBytes: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFixed: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EFloat32: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_ESet: {
    V v_xs_2452 = heff_field(v_e_242, 0);
    V v_a_2453 = heff_field(v_e_242, 1);
    V v_b_2454 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(v_lit_240, v_lit_241, v_b_2454));
    {
      V v_field_2457 = v_t_2455.f[1];
      int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
      if ((v_tag_2456 == ((int64_t)0ULL))) {
        V v_x_2458 = v_field_2457;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2452, v_a_2453, v_x_2458})}});
      } else {
        heff_drop(v_xs_2452);
        heff_drop(v_a_2453);
        heff_drop_cell(v_ru_24e_242_24ESet, 3);
        heff_drop(v_field_2457);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EValues: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFix: {
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr_lam0(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    V v_ru_24x2_2427_24MkArm = heff_take_reuse_n(v_x2_2427, 7ULL, 3);
    heff_clo_take(self, 2);
    HeffT2 v_t_2431 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_b_2430; HeffT2 r_ = (g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2433;
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_re_n(v_ru_24x2_2427_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2428, v_vs_2429, v_x_2434})});
      } else {
        heff_drop(v_t_2428);
        heff_drop(v_vs_2429);
        heff_drop_cell(v_ru_24x2_2427_24MkArm, 3);
        heff_drop(v_field_2433);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam24(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam0, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam1, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam2, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam3, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_242, 0);
    V v_a_2414 = heff_field(v_e_242, 1);
    V v_b_2415 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2416 = (g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(v_lit_240, v_lit_241, v_b_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam4, 1, 3, (V[]){v_m_2416, v_x_2413, v_a_2414});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam6, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_ETag: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam7, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EMatch: {
    V v_s_2433 = heff_field(v_e_242, 0);
    V v_arms_2434 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2444 = (g_prelude_2etraverse_24s1218231813x1819446478(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam8, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2434));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam10, 1, 2, (V[]){v_m_2444, v_s_2433});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam11, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam12, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam13, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam14, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam15, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam16, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam17, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam18, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam19, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam20, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EBool: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam21, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_ESet: {
    V v_xs_2473 = heff_field(v_e_242, 0);
    V v_a_2474 = heff_field(v_e_242, 1);
    V v_b_2475 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2476 = (g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(v_lit_240, v_lit_241, v_b_2475));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam22, 1, 3, (V[]){v_m_2476, v_xs_2473, v_a_2474});
  }
  case TAG_EValues: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam23, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam24, 1, 3, (V[]){v_lit_240, v_lit_241, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_244));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_246));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_249));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2412));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam4(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_a_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2413, v_a_2414, v_x_2419}), v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2423));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam6(V self, V *args) {
  V v_a_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2428));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam7(V self, V *args) {
  V v_a_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2432));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam9(V self, V *args) {
  V v_s_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_t_2436 = heff_env(self)[1];
  V v_vs_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_s_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2436, v_vs_2437, v_x_2442}), v_s_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam8(V self, V *args) {
  V v_x2_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkArm: {
    V v_t_2436 = heff_field(v_x2_2435, 0);
    V v_vs_2437 = heff_field(v_x2_2435, 1);
    V v_b_2438 = heff_field(v_x2_2435, 2);
    heff_take_n(v_x2_2435, 7ULL, 3);
    heff_clo_take(self, 2);
    V v_m_2439 = (g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(v_lit_240, v_lit_241, v_b_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam9, 1, 3, (V[]){v_m_2439, v_t_2436, v_vs_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam10(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_s_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2433, v_x_2447}), v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam11(V self, V *args) {
  V v_a_2450 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2450));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam12(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2453));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam13(V self, V *args) {
  V v_a_2456 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2456));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam14(V self, V *args) {
  V v_a_2458 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2458));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam15(V self, V *args) {
  V v_a_2460 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2460));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam16(V self, V *args) {
  V v_a_2462 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2462));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam17(V self, V *args) {
  V v_a_2464 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2464));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam18(V self, V *args) {
  V v_a_2467 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2467));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam19(V self, V *args) {
  V v_a_2469 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2469));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam20(V self, V *args) {
  V v_a_2470 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2470));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam21(V self, V *args) {
  V v_a_2472 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2472));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam22(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_xs_2473 = heff_env(self)[1];
  V v_a_2474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2473, v_a_2474, v_x_2479}), v_s_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam23(V self, V *args) {
  V v_a_2482 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2482));
}
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_lam24(V self, V *args) {
  V v_a_2485 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(v_lit_240, v_lit_241, v_e_242, v_a_2485));
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2412 = heff_field(v_x2_240, 0);
    V v_args_2413 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2414 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_g_2412));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam3, 1, 2, (V[]){v_m_2414, v_args_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2426 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam4, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2435 = heff_field(v_x2_240, 0);
    V v_ts_2436 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s2126788141x1913216601(v_fs_2435));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam5, 1, 2, (V[]){v_m_2437, v_ts_2436});
  }
  case TAG_EProj: {
    V v_e_2442 = heff_field(v_x2_240, 0);
    V v_l_2443 = heff_field(v_x2_240, 1);
    V v_sh_2444 = heff_field(v_x2_240, 2);
    V v_t_2445 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2446 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2442));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam6, 1, 4, (V[]){v_m_2446, v_l_2443, v_sh_2444, v_t_2445});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_args_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2454 = (g_prelude_2etraverse_24s1237512785x1947069493(v_args_2452));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam7, 1, 3, (V[]){v_m_2454, v_t_2451, v_ts_2453});
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_x2_240, 0);
    V v_arms_2460 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_s_2459));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam8, 1, 2, (V[]){v_m_2461, v_arms_2460});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_args_2474 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2475 = (g_prelude_2etraverse_24s1237512785x1947069493(v_args_2474));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam10, 1, 2, (V[]){v_m_2475, v_p_2473});
  }
  case TAG_ECall: {
    V v_g_2480 = heff_field(v_x2_240, 0);
    V v_args_2481 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2482 = (g_prelude_2etraverse_24s1237512785x1947069493(v_args_2481));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam11, 1, 2, (V[]){v_m_2482, v_g_2480});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24101 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24102 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_c_24101));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam19, 1, 1, (V[]){v_m_24102});
  }
  case TAG_ESet: {
    V v_xs_24107 = heff_field(v_x2_240, 0);
    V v_a_24108 = heff_field(v_x2_240, 1);
    V v_b_24109 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_24110 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_24108));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam20, 1, 3, (V[]){v_m_24110, v_b_24109, v_xs_24107});
  }
  case TAG_EValues: {
    V v_es_24119 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24120 = (g_prelude_2etraverse_24s1237512785x1947069493(v_es_24119));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam21, 1, 1, (V[]){v_m_24120});
  }
  case TAG_EFix: {
    V v_x_24125 = heff_field(v_x2_240, 0);
    V v_b_24126 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24127 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_24126));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam22, 1, 2, (V[]){v_m_24127, v_x_24125});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam1(V self, V *args) {
  V v_s_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam3(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_args_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = (g_prelude_2etraverse_24s1237512785x1947069493(v_args_2413));
    V v_x2_2420 = heff_tr(heff_call(v_t_2419, 1, (V[]){v_s_2418}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_s_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_EApp, 2, (V[]){v_x_2417, v_x_2421}), v_s_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam4(V self, V *args) {
  V v_s_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_s_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_s_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_t_2431, 1, (V[]){v_s_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_s_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_x_2429, v_x_2433}), v_s_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam5(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_ts_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2440, v_ts_2436}), v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam6(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  V v_sh_2444 = heff_env(self)[2];
  V v_t_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2449, v_l_2443, v_sh_2444, v_t_2445}), v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam7(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_ts_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2451, v_x_2457, v_ts_2453}), v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam8(V self, V *args) {
  V v_s_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_arms_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_s_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    HeffT2 v_t_2466 = (g_prelude_2etraverse_24s1144925704x1514729383_24cpr(v_arms_2460, v_s_2465));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_x_2469 = v_field_2467;
      V v_s_2470 = v_field_2468;
      return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2464, v_x_2469}), v_s_2470});
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam9(V self, V *args) {
  V v_s_2472 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2472});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam10(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_p_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2473, v_x_2478}), v_s_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam11(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_g_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam12(V self, V *args) {
  V v_s_2488 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2488});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam13(V self, V *args) {
  V v_s_2490 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2490});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam14(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam15(V self, V *args) {
  V v_s_2494 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2494});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam16(V self, V *args) {
  V v_s_2497 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2497});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam17(V self, V *args) {
  V v_s_2499 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_2499});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam18(V self, V *args) {
  V v_s_24100 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_s_24100});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam19(V self, V *args) {
  V v_s_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_s_24103}));
  switch (heff_tag_of(v_x2_24104)) {
  case TAG_MkPair: {
    V v_x_24105 = heff_field(v_x2_24104, 0);
    V v_s_24106 = heff_field(v_x2_24104, 1);
    V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24105}), v_s_24106});
  }
  default: return heff_nomatch(v_x2_24104);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam20(V self, V *args) {
  V v_s_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_b_24109 = heff_env(self)[1];
  V v_xs_24107 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_s_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_s_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24115 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_24109));
    V v_x2_24116 = heff_tr(heff_call(v_t_24115, 1, (V[]){v_s_24114}));
    switch (heff_tag_of(v_x2_24116)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_field(v_x2_24116, 0);
      V v_s_24118 = heff_field(v_x2_24116, 1);
      heff_take_n(v_x2_24116, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24107, v_x_24113, v_x_24117}), v_s_24118});
    }
    default: return heff_nomatch(v_x2_24116);
    }
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24123}), v_s_24124});
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_lam22(V self, V *args) {
  V v_s_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_x_24125 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24129 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_s_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_s_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24125, v_x_24130}), v_s_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(V v_lit_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2411 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_248, v_a_249, heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(v_lit_240, v_b_2410, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_241, 0);
    V v_arms_2423 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_lam0, 1, 1, (V[]){heff_dup(v_lit_240)}), v_arms_2423));
    return heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2422, v_t_2429});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2443 = heff_field(v_e_241, 0);
    V v_a_2444 = heff_field(v_e_241, 1);
    V v_b_2445 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2446 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2443, v_a_2444, heff_hole()});
    V v_u_2447 = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(v_lit_240, v_b_2445, v_cell_2446));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_vs_2426 = heff_field(v_x2_2424, 1);
    V v_b_2427 = heff_field(v_x2_2424, 2);
    V v_ru_24x2_2424_24MkArm = heff_take_reuse_n(v_x2_2424, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2428 = ({ V a_0 = v_lit_240; V a_1 = v_b_2427; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(a_0, a_1)); heff_drop(v_lit_240); r_; });
    return heff_tag_re_n(v_ru_24x2_2424_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2425, v_vs_2426, v_t_2428});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps(v_ys_240, v_t_244, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(a[0], a[1]);
}