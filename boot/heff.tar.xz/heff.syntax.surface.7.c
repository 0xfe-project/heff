// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclDefine 5286
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkSegment 38079
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_f 320
#define LBL_fixities 357800079
#define LBL_head 9693863
#define LBL_i 323
#define LBL_implicits 1321238867
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_waiting 1348170899
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_name__span__ty[] = {LBL_name, LBL_span, LBL_ty};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eabAbove(V, V, V);
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabAbove_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2eplaceDocs(V, V);
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2esigL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2emap_24f2041933216x1458595349(V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_prelude_2etraverse_24s430827533x596660821(V, V, V, V);
V g_prelude_2etraverse_24s430827533x596660821_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s430827533x596660821_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_heff_2esyntax_2esurface_2epiBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiBinders_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_b_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24EPi = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      V v_t_2432;
      switch (heff_tag_of(v_b_2417)) {
      case TAG_PiNamed: {
        V v_x_2419 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 3);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 5);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 4);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2417);
      }
      V v_t_2433 = (g_heff_2esyntax_2esurface_2epiBinders(v_rest_2418));
      return (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x11_241_24EPi, v_t_2432, v_t_2433));
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiBinders(a[0]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2easBinderOn(V v_e_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2easBinderOn_24cpr(v_e_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2enameBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameBinder(V v_e0_240) {
top: ;
  switch (heff_tag_of(v_e0_240)) {
  case TAG_At: {
    V v_e01_241 = heff_dup(heff_field(v_e0_240, 0));
    switch (heff_tag_of(v_e01_241)) {
    case TAG_EVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETag: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EInt: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EString: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EAnn: {
      V v_g_2421 = heff_field(v_e01_241, 0);
      V v_t_2422 = heff_field(v_e01_241, 1);
      V v_ru_24e01_241_24EAnn = heff_take_reuse_n(v_e01_241, 3ULL, 2);
      switch (heff_tag_of(v_e0_240)) {
      case TAG_At: {
        V v_ru_24e0_240_24At = heff_take_reuse_n(v_e0_240, 0ULL, 2);
        V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
        V v_t_2426 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2425, 0, 2), heff_get_n(v_t_2426, 1, 2)});
        V v_t_2428 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a_0)); heff_drop_tag(v_t_2427, 2); r_; });
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop(v_t_2428);
          V v_t_2429 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
          V v_t_2430 = (g_heff_2esyntax_2esurface_2easNameE(heff_get_n(v_t_2429, 0, 2)));
          V v_t_2431 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2421));
          V v_t_2432 = (g_list_2emap_24s1624059865x1140896478(heff_get_n(v_t_2431, 1, 2)));
          V v_e_2433 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, v_t_2432));
          V v_t_2436;
          switch (heff_tag_of(v_e_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_e_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_e_2433);
          }
          V v_t_2439;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_At: {
            V v_s_2438 = heff_dup(heff_field(v_t_2422, 1));
            v_t_2439 = v_s_2438;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24e0_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_e_2433, v_t_2422}), v_t_2440});
        } else {
          heff_drop(v_t_2428);
          V v_t_2443;
          switch (heff_tag_of(v_g_2421)) {
          case TAG_At: {
            V v_s_2442 = heff_dup(heff_field(v_g_2421, 1));
            v_t_2443 = v_s_2442;
            break;
          }
          default: heff_nomatch(v_g_2421);
          }
          V v_t_2446;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_At: {
            V v_s_2445 = heff_dup(heff_field(v_t_2422, 1));
            v_t_2446 = v_s_2445;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2447 = ({ V rv_1 = heff_get_n(v_t_2446, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2443, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24e0_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2447});
        }
      }
      default: return heff_nomatch(v_e0_240);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e01_241, 0ULL, 3);
      return v_e0_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e01_241, 0ULL, 3);
      return v_e0_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EBreak: {
      return v_e0_240;
    }
    case TAG_EContinue: {
      return v_e0_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWith: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    default: return heff_nomatch(v_e01_241);
    }
  }
  default: return heff_nomatch(v_e0_240);
  }
}
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2enameBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eeqnNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eeqnNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Eqn: {
      V v_f_248 = heff_field(v_x11_241, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnNames(v_rest_242));
      return (g_std_2emap_2einsert_24s93785294x875597928(v_t_2411, heff_dup(v_f_248), NTAG(TAG_MkUnit)));
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eeqnNames(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceDocs_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eplaceDocs(V v_src_240, V v_items_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_items__waiting__diags, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_p_245 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2eplaceDocs_lam0, 2, 1, (V[]){heff_dup(v_src_240)}), v_t_242, v_items_241));
  V v_items_246 = heff_take_field(v_p_245, 0);
  V v_waiting_247 = heff_take_field(v_p_245, 1);
  V v_diags_248 = heff_get_n(v_p_245, 2, 3);
  V v_items_249 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_items_246, heff_dup(v_waiting_247)));
  V v_diags_2410 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(v_diags_248, v_waiting_247));
  return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_249, NTAG(TAG_Nil), v_diags_2410});
}
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eplaceDocs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_it_244 = args[1];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_src_240; V a_1 = v_p_243; V a_2 = v_it_244; V r_ = (g_heff_2esyntax_2esurface_2eplaceStep(a_0, a_1, a_2)); heff_drop(v_src_240); r_; });
}
Clo g_heff_2esyntax_2esurface_2epathOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epathOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epathOf(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_text_243 = heff_take_field(v_x_242, 1);
    V v_start_244 = heff_take_field(v_x_242, 3);
    V v_end_245 = heff_get_n(v_x_242, 4, 9);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_text_243, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_acc_241});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EField: {
    V v_e_2453 = heff_field(v_x1_240, 0);
    V v_f_2454 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_2455 = heff_take_field(v_f_2454, 1);
    V v_start_2456 = heff_take_field(v_f_2454, 3);
    V v_end_2457 = heff_get_n(v_f_2454, 4, 9);
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_MkPair, 2, (V[]){v_text_2455, heff_rec_n(2, shape_start__end, (V[]){v_start_2456, v_end_2457})});
    V t_0 = v_e_2453;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return v_acc_241;
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epathOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_243 = heff_take_field(v_x_241, 0);
    V v_pat_244 = heff_get_n(v_x_241, 2, 3);
    V v_t_2413;
    switch (heff_tag_of(v_binder_243)) {
    case TAG_LamName: {
      V v_x_245 = heff_field(v_binder_243, 0);
      V v_ru_24binder_243_24LamName = heff_take_reuse_n(v_binder_243, 1ULL, 2);
      switch (heff_tag_of(v_pat_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24binder_243_24LamName, 2);
        v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_p_247 = heff_field(v_pat_244, 0);
        heff_take_n(v_pat_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        v_t_2413 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24binder_243_24LamName, v_p_247));
        break;
      }
      default: heff_nomatch(v_pat_244);
      }
      break;
    }
    case TAG_LamImplicit: {
      V v_x_248 = heff_field(v_binder_243, 0);
      heff_take_n(v_binder_243, 1ULL, 2);
      heff_drop(v_pat_244);
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamAnn: {
      V v_x_2410 = heff_field(v_binder_243, 0);
      heff_take_n(v_binder_243, 1ULL, 3);
      heff_drop(v_pat_244);
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_binder_243);
    }
    V v_t_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2413, v_t_2414));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str1, 50, "a specialisation sets a field by its name: `x = v`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str2, 45, "a specialisation sets fields: `T @ { x = v }`");
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eopL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243, V v_z_244) {
top: ;
  if (heff_strEq_c(heff_get_n(v_op_242, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eopL_str0))) {
    HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_a_241)));
    V v_m_24529;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_f_248 = v_field_247;
        V v_a_249 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241));
        V v_b_2410 = (g_heff_2esyntax_2ecst_2elastE(v_a_241));
        V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_249, 3, 9), heff_get_n(v_b_2410, 4, 9)});
        v_m_24529 = (g_heff_2esyntax_2esurface_2ebracedL(heff_dup(v_r_240), v_f_248, v_t_2411));
      } else {
        heff_drop(v_field_247);
        switch (heff_tag_of(v_a_241)) {
        case TAG_Atom: {
          V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam0, 1, 1, (V[]){v_m_2413});
          break;
        }
        case TAG_EParen: {
          V v_m_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam1, 1, 1, (V[]){v_m_2424});
          break;
        }
        case TAG_Named: {
          V v_m_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam2, 1, 1, (V[]){v_m_2437});
          break;
        }
        case TAG_Tup: {
          V v_m_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam3, 1, 1, (V[]){v_m_2449});
          break;
        }
        case TAG_Seg: {
          V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam4, 1, 1, (V[]){v_m_2460});
          break;
        }
        case TAG_Braces: {
          V v_m_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam5, 1, 1, (V[]){v_m_2472});
          break;
        }
        case TAG_Update: {
          V v_m_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam6, 1, 1, (V[]){v_m_2486});
          break;
        }
        case TAG_EUSet: {
          V v_m_2497 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam7, 1, 1, (V[]){v_m_2497});
          break;
        }
        case TAG_InstB: {
          V v_o_24105 = heff_field(v_a_241, 0);
          V v_d_24107 = heff_field(v_a_241, 2);
          V v_c_24109 = heff_field(v_a_241, 4);
          heff_take_n(v_a_241, 21ULL, 5);
          V v_m_24110 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_d_24107));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam8, 1, 3, (V[]){v_m_24110, v_o_24105, v_c_24109});
          break;
        }
        case TAG_EFSet: {
          V v_m_24122 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam9, 1, 1, (V[]){v_m_24122});
          break;
        }
        case TAG_EFDefault: {
          V v_m_24133 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam10, 1, 1, (V[]){v_m_24133});
          break;
        }
        case TAG_Sum: {
          V v_m_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam11, 1, 1, (V[]){v_m_24146});
          break;
        }
        case TAG_ECon: {
          V v_m_24156 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam12, 1, 1, (V[]){v_m_24156});
          break;
        }
        case TAG_EField: {
          V v_m_24166 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam13, 1, 1, (V[]){v_m_24166});
          break;
        }
        case TAG_ENeg: {
          V v_m_24176 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam14, 1, 1, (V[]){v_m_24176});
          break;
        }
        case TAG_ETilde: {
          V v_m_24186 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam15, 1, 1, (V[]){v_m_24186});
          break;
        }
        case TAG_App: {
          V v_m_24196 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam16, 1, 1, (V[]){v_m_24196});
          break;
        }
        case TAG_Op: {
          V v_m_24207 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam17, 1, 1, (V[]){v_m_24207});
          break;
        }
        case TAG_Ops: {
          V v_m_24217 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam18, 1, 1, (V[]){v_m_24217});
          break;
        }
        case TAG_OpRhs: {
          V v_m_24227 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam19, 1, 1, (V[]){v_m_24227});
          break;
        }
        case TAG_Ann: {
          V v_m_24238 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam20, 1, 1, (V[]){v_m_24238});
          break;
        }
        case TAG_BVar: {
          V v_m_24247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam21, 1, 1, (V[]){v_m_24247});
          break;
        }
        case TAG_BImp: {
          V v_m_24258 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam22, 1, 1, (V[]){v_m_24258});
          break;
        }
        case TAG_BAnn: {
          V v_m_24271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam23, 1, 1, (V[]){v_m_24271});
          break;
        }
        case TAG_BPat: {
          V v_m_24280 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam24, 1, 1, (V[]){v_m_24280});
          break;
        }
        case TAG_Lam: {
          V v_m_24292 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam25, 1, 1, (V[]){v_m_24292});
          break;
        }
        case TAG_Case: {
          V v_m_24304 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam26, 1, 1, (V[]){v_m_24304});
          break;
        }
        case TAG_EAlt: {
          V v_m_24315 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam27, 1, 1, (V[]){v_m_24315});
          break;
        }
        case TAG_If: {
          V v_m_24329 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam28, 1, 1, (V[]){v_m_24329});
          break;
        }
        case TAG_Do: {
          V v_m_24339 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam29, 1, 1, (V[]){v_m_24339});
          break;
        }
        case TAG_ESBind: {
          V v_m_24350 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam30, 1, 1, (V[]){v_m_24350});
          break;
        }
        case TAG_ELet: {
          V v_m_24364 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam31, 1, 1, (V[]){v_m_24364});
          break;
        }
        case TAG_ELetElse: {
          V v_m_24379 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam32, 1, 1, (V[]){v_m_24379});
          break;
        }
        case TAG_ELetMut: {
          V v_m_24393 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam33, 1, 1, (V[]){v_m_24393});
          break;
        }
        case TAG_EAssign: {
          V v_m_24404 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam34, 1, 1, (V[]){v_m_24404});
          break;
        }
        case TAG_EWhile: {
          V v_m_24416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam35, 1, 1, (V[]){v_m_24416});
          break;
        }
        case TAG_EFor: {
          V v_m_24430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam36, 1, 1, (V[]){v_m_24430});
          break;
        }
        case TAG_EJump: {
          V v_m_24439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam37, 1, 1, (V[]){v_m_24439});
          break;
        }
        case TAG_EReturn: {
          V v_m_24449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam38, 1, 1, (V[]){v_m_24449});
          break;
        }
        case TAG_ENest: {
          V v_m_24461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam39, 1, 1, (V[]){v_m_24461});
          break;
        }
        case TAG_EArrow: {
          V v_m_24471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam40, 1, 1, (V[]){v_m_24471});
          break;
        }
        case TAG_IfThen: {
          V v_m_24483 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam41, 1, 1, (V[]){v_m_24483});
          break;
        }
        case TAG_ETry: {
          V v_m_24495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam42, 1, 1, (V[]){v_m_24495});
          break;
        }
        case TAG_ECatch: {
          V v_m_24507 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam43, 1, 1, (V[]){v_m_24507});
          break;
        }
        case TAG_EWith: {
          V v_m_24521 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24529 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam44, 1, 1, (V[]){v_m_24521});
          break;
        }
        default: heff_nomatch(v_a_241);
        }
      }
    }
    V v_x1_24530 = heff_tr(heff_call(v_m_24529, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24530)) {
    case TAG_MkPair: {
      V v_x11_24531 = heff_field(v_x1_24530, 0);
      V v_st_24532 = heff_field(v_x1_24530, 1);
      V v_ru_24x1_24530_24MkPair = heff_take_reuse_n(v_x1_24530, 3ULL, 2);
      switch (heff_tag_of(v_x11_24531)) {
      case TAG_Left: {
        V v_e_24533 = heff_field(v_x11_24531, 0);
        heff_take_n(v_x11_24531, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24533}), v_st_24532});
      }
      case TAG_Right: {
        V v_x_24534 = heff_field(v_x11_24531, 0);
        heff_take_n(v_x11_24531, 1ULL, 1);
        V v_m_24535 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
        V v_x1_24536 = heff_tr(heff_call(v_m_24535, 1, (V[]){v_st_24532}));
        switch (heff_tag_of(v_x1_24536)) {
        case TAG_MkPair: {
          V v_x11_24537 = heff_field(v_x1_24536, 0);
          V v_st_24538 = heff_field(v_x1_24536, 1);
          heff_take_n(v_x1_24536, 3ULL, 2);
          switch (heff_tag_of(v_x11_24537)) {
          case TAG_Left: {
            V v_e_24539 = heff_field(v_x11_24537, 0);
            heff_take_n(v_x11_24537, 1ULL, 1);
            heff_drop(v_x_24534);
            return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24539}), v_st_24538});
          }
          case TAG_Right: {
            V v_x_24540 = heff_field(v_x11_24537, 0);
            heff_take_n(v_x11_24537, 1ULL, 1);
            V v_x_24541 = heff_tr(g_heff_2esyntax_2esurface_2earrowBinop(v_x_24534, v_x_24540));
            return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24541}), v_st_24538});
          }
          default: return heff_nomatch(v_x11_24537);
          }
        }
        default: return heff_nomatch(v_x1_24536);
        }
      }
      default: return heff_nomatch(v_x11_24531);
      }
    }
    default: return heff_nomatch(v_x1_24530);
    }
  } else {
    V v_m_24542 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
    V v_x1_24543 = heff_tr(heff_call(v_m_24542, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24543)) {
    case TAG_MkPair: {
      V v_x11_24544 = heff_field(v_x1_24543, 0);
      V v_st_24545 = heff_field(v_x1_24543, 1);
      V v_ru_24x1_24543_24MkPair = heff_take_reuse_n(v_x1_24543, 3ULL, 2);
      switch (heff_tag_of(v_x11_24544)) {
      case TAG_Left: {
        V v_e_24546 = heff_field(v_x11_24544, 0);
        heff_take_n(v_x11_24544, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24546}), v_st_24545});
      }
      case TAG_Right: {
        V v_x_24547 = heff_field(v_x11_24544, 0);
        V v_ru_24x11_24544_24Right = heff_take_reuse_n(v_x11_24544, 1ULL, 1);
        HeffT2 v_t_24548 = (g_heff_2esyntax_2esurface_2esettingsOf_24cpr(heff_dup(v_b_243)));
        {
          V v_field_24550 = v_t_24548.f[1];
          int64_t v_tag_24549 = ((int64_t)v_t_24548.f[0]);
          if ((v_tag_24549 == ((int64_t)0ULL))) {
            heff_drop(v_b_243);
            heff_drop_cell(v_ru_24x11_24544_24Right, 1);
            V v_fs_24551 = v_field_24550;
            V v_m_24553 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam45, 1, 1, (V[]){v_r_240}), v_fs_24551));
            V v_x1_24554 = heff_tr(heff_call(v_m_24553, 1, (V[]){v_st_24545}));
            switch (heff_tag_of(v_x1_24554)) {
            case TAG_MkPair: {
              V v_x11_24555 = heff_field(v_x1_24554, 0);
              V v_st_24556 = heff_field(v_x1_24554, 1);
              heff_take_n(v_x1_24554, 3ULL, 2);
              switch (heff_tag_of(v_x11_24555)) {
              case TAG_Left: {
                V v_e_24557 = heff_field(v_x11_24555, 0);
                heff_take_n(v_x11_24555, 1ULL, 1);
                heff_drop(v_x_24547);
                return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24557}), v_st_24556});
              }
              case TAG_Right: {
                V v_x_24558 = heff_field(v_x11_24555, 0);
                heff_take_n(v_x11_24555, 1ULL, 1);
                V v_x_24559 = (g_list_2efoldl_24s1368043225x413679696(((V)&g_heff_2esyntax_2esurface_2eopL_str1), v_x_24547, v_x_24558));
                return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24559}), v_st_24556});
              }
              default: return heff_nomatch(v_x11_24555);
              }
            }
            default: return heff_nomatch(v_x1_24554);
            }
          } else {
            heff_drop(v_field_24550);
            V v_m_24560 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
            V v_x1_24561 = heff_tr(heff_call(v_m_24560, 1, (V[]){v_st_24545}));
            switch (heff_tag_of(v_x1_24561)) {
            case TAG_MkPair: {
              V v_x11_24562 = heff_field(v_x1_24561, 0);
              V v_st_24563 = heff_field(v_x1_24561, 1);
              V v_ru_24x1_24561_24MkPair = heff_take_reuse_n(v_x1_24561, 3ULL, 2);
              switch (heff_tag_of(v_x11_24562)) {
              case TAG_Left: {
                V v_e_24564 = heff_field(v_x11_24562, 0);
                heff_take_n(v_x11_24562, 1ULL, 1);
                heff_drop(v_x_24547);
                heff_drop_cell(v_ru_24x11_24544_24Right, 1);
                heff_drop_cell(v_ru_24x1_24561_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24564}), v_st_24563});
              }
              case TAG_Right: {
                V v_x_24565 = heff_field(v_x11_24562, 0);
                heff_take_n(v_x11_24562, 1ULL, 1);
                V v_t_24568;
                switch (heff_tag_of(v_x_24547)) {
                case TAG_At: {
                  V v_s_24567 = heff_field(v_x_24547, 1);
                  heff_take_n(v_x_24547, 2ULL, 2);
                  v_t_24568 = v_s_24567;
                  break;
                }
                default: heff_nomatch(v_x_24547);
                }
                V v_t_24571;
                switch (heff_tag_of(v_x_24565)) {
                case TAG_At: {
                  V v_s_24570 = heff_field(v_x_24565, 1);
                  heff_take_n(v_x_24565, 2ULL, 2);
                  v_t_24571 = v_s_24570;
                  break;
                }
                default: heff_nomatch(v_x_24565);
                }
                V v_t_24572 = ({ V rv_1 = heff_get_n(v_t_24571, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24568, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24573 = heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24544_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eopL_str2)}), v_t_24572});
                return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24573}), v_st_24563});
              }
              default: return heff_nomatch(v_x11_24562);
              }
            }
            default: return heff_nomatch(v_x1_24561);
            }
          }
        }
      }
      default: return heff_nomatch(v_x11_24544);
      }
    }
    default: return heff_nomatch(v_x1_24543);
    }
  }
}
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2414}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_MkPair: {
    V v_x11_2416 = heff_field(v_x1_2415, 0);
    V v_st_2417 = heff_field(v_x1_2415, 1);
    V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
    switch (heff_tag_of(v_x11_2416)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x11_2416, 0);
      heff_take_n(v_x11_2416, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x11_2416, 0);
      V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 1ULL, 1);
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2419})});
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_st_2417});
    }
    default: return heff_nomatch(v_x11_2416);
    }
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args) {
  V v_st_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2425}));
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkPair: {
    V v_x11_2427 = heff_field(v_x1_2426, 0);
    V v_st_2428 = heff_field(v_x1_2426, 1);
    V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_Left: {
      V v_e_2429 = heff_field(v_x11_2427, 0);
      heff_take_n(v_x11_2427, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2429}), v_st_2428});
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Right = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      V v_t_2431 = heff_tag_at_n(v_ru_24x11_2427_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2430})});
      return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2428});
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args) {
  V v_st_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_st_2438}));
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_MkPair: {
    V v_x11_2440 = heff_field(v_x1_2439, 0);
    V v_st_2441 = heff_field(v_x1_2439, 1);
    V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
    switch (heff_tag_of(v_x11_2440)) {
    case TAG_Left: {
      V v_e_2442 = heff_field(v_x11_2440, 0);
      heff_take_n(v_x11_2440, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
    }
    case TAG_Right: {
      V v_x_2443 = heff_field(v_x11_2440, 0);
      V v_ru_24x11_2440_24Right = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
      V v_t_2444 = heff_tag_at_n(v_ru_24x11_2440_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2443})});
      return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){v_t_2444, v_st_2441});
    }
    default: return heff_nomatch(v_x11_2440);
    }
  }
  default: return heff_nomatch(v_x1_2439);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args) {
  V v_st_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_st_2450}));
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_MkPair: {
    V v_x11_2452 = heff_field(v_x1_2451, 0);
    V v_st_2453 = heff_field(v_x1_2451, 1);
    V v_ru_24x1_2451_24MkPair = heff_take_reuse_n(v_x1_2451, 3ULL, 2);
    switch (heff_tag_of(v_x11_2452)) {
    case TAG_Left: {
      V v_e_2454 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2454}), v_st_2453});
    }
    case TAG_Right: {
      V v_x_2455 = heff_field(v_x11_2452, 0);
      V v_ru_24x11_2452_24Right = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
      V v_t_2456 = heff_tag_at_n(v_ru_24x11_2452_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2455})});
      return heff_tag_at_n(v_ru_24x1_2451_24MkPair, TAG_MkPair, 2, (V[]){v_t_2456, v_st_2453});
    }
    default: return heff_nomatch(v_x11_2452);
    }
  }
  default: return heff_nomatch(v_x1_2451);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args) {
  V v_st_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_st_2461}));
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_MkPair: {
    V v_x11_2463 = heff_field(v_x1_2462, 0);
    V v_st_2464 = heff_field(v_x1_2462, 1);
    V v_ru_24x1_2462_24MkPair = heff_take_reuse_n(v_x1_2462, 3ULL, 2);
    switch (heff_tag_of(v_x11_2463)) {
    case TAG_Left: {
      V v_e_2465 = heff_field(v_x11_2463, 0);
      heff_take_n(v_x11_2463, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2465}), v_st_2464});
    }
    case TAG_Right: {
      V v_x_2466 = heff_field(v_x11_2463, 0);
      V v_ru_24x11_2463_24Right = heff_take_reuse_n(v_x11_2463, 1ULL, 1);
      V v_t_2467 = heff_tag_at_n(v_ru_24x11_2463_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2466})});
      return heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, (V[]){v_t_2467, v_st_2464});
    }
    default: return heff_nomatch(v_x11_2463);
    }
  }
  default: return heff_nomatch(v_x1_2462);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args) {
  V v_st_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_st_2473}));
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_MkPair: {
    V v_x11_2475 = heff_field(v_x1_2474, 0);
    V v_st_2476 = heff_field(v_x1_2474, 1);
    V v_ru_24x1_2474_24MkPair = heff_take_reuse_n(v_x1_2474, 3ULL, 2);
    switch (heff_tag_of(v_x11_2475)) {
    case TAG_Left: {
      V v_e_2477 = heff_field(v_x11_2475, 0);
      heff_take_n(v_x11_2475, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2477}), v_st_2476});
    }
    case TAG_Right: {
      V v_x_2478 = heff_field(v_x11_2475, 0);
      V v_ru_24x11_2475_24Right = heff_take_reuse_n(v_x11_2475, 1ULL, 1);
      V v_t_2479 = heff_tag_at_n(v_ru_24x11_2475_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2478})});
      return heff_tag_at_n(v_ru_24x1_2474_24MkPair, TAG_MkPair, 2, (V[]){v_t_2479, v_st_2476});
    }
    default: return heff_nomatch(v_x11_2475);
    }
  }
  default: return heff_nomatch(v_x1_2474);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args) {
  V v_st_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2488 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_st_2487}));
  switch (heff_tag_of(v_x1_2488)) {
  case TAG_MkPair: {
    V v_x11_2489 = heff_field(v_x1_2488, 0);
    V v_st_2490 = heff_field(v_x1_2488, 1);
    V v_ru_24x1_2488_24MkPair = heff_take_reuse_n(v_x1_2488, 3ULL, 2);
    switch (heff_tag_of(v_x11_2489)) {
    case TAG_Left: {
      V v_e_2491 = heff_field(v_x11_2489, 0);
      heff_take_n(v_x11_2489, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2491}), v_st_2490});
    }
    case TAG_Right: {
      V v_x_2492 = heff_field(v_x11_2489, 0);
      V v_ru_24x11_2489_24Right = heff_take_reuse_n(v_x11_2489, 1ULL, 1);
      V v_t_2493 = heff_tag_at_n(v_ru_24x11_2489_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2492})});
      return heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_MkPair, 2, (V[]){v_t_2493, v_st_2490});
    }
    default: return heff_nomatch(v_x11_2489);
    }
  }
  default: return heff_nomatch(v_x1_2488);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args) {
  V v_st_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_st_2498}));
  switch (heff_tag_of(v_x1_2499)) {
  case TAG_MkPair: {
    V v_x11_24100 = heff_field(v_x1_2499, 0);
    V v_st_24101 = heff_field(v_x1_2499, 1);
    V v_ru_24x1_2499_24MkPair = heff_take_reuse_n(v_x1_2499, 3ULL, 2);
    switch (heff_tag_of(v_x11_24100)) {
    case TAG_Left: {
      V v_e_24102 = heff_field(v_x11_24100, 0);
      heff_take_n(v_x11_24100, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24102}), v_st_24101});
    }
    case TAG_Right: {
      V v_x_24103 = heff_field(v_x11_24100, 0);
      V v_ru_24x11_24100_24Right = heff_take_reuse_n(v_x11_24100, 1ULL, 1);
      V v_t_24104 = heff_tag_at_n(v_ru_24x11_24100_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24103})});
      return heff_tag_at_n(v_ru_24x1_2499_24MkPair, TAG_MkPair, 2, (V[]){v_t_24104, v_st_24101});
    }
    default: return heff_nomatch(v_x11_24100);
    }
  }
  default: return heff_nomatch(v_x1_2499);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args) {
  V v_st_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_o_24105 = heff_env(self)[1];
  V v_c_24109 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_st_24111}));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      heff_drop_rec(v_o_24105, 9);
      heff_drop_rec(v_c_24109, 9);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      V v_ru_24x11_24113_24Right = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
      V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24105, 3, 9), heff_get_n(v_c_24109, 4, 9)});
      V v_t_24118 = heff_tag_at_n(v_ru_24x11_24113_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Bracketed, 2, (V[]){v_x_24116, v_t_24117})});
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){v_t_24118, v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      V v_ru_24x11_24125_24Right = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
      V v_t_24129 = heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24128})});
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){v_t_24129, v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args) {
  V v_st_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_st_24134}));
  switch (heff_tag_of(v_x1_24135)) {
  case TAG_MkPair: {
    V v_x11_24136 = heff_field(v_x1_24135, 0);
    V v_st_24137 = heff_field(v_x1_24135, 1);
    V v_ru_24x1_24135_24MkPair = heff_take_reuse_n(v_x1_24135, 3ULL, 2);
    switch (heff_tag_of(v_x11_24136)) {
    case TAG_Left: {
      V v_e_24138 = heff_field(v_x11_24136, 0);
      heff_take_n(v_x11_24136, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24138}), v_st_24137});
    }
    case TAG_Right: {
      V v_x_24139 = heff_field(v_x11_24136, 0);
      V v_ru_24x11_24136_24Right = heff_take_reuse_n(v_x11_24136, 1ULL, 1);
      V v_t_24140 = heff_tag_at_n(v_ru_24x11_24136_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24139})});
      return heff_tag_at_n(v_ru_24x1_24135_24MkPair, TAG_MkPair, 2, (V[]){v_t_24140, v_st_24137});
    }
    default: return heff_nomatch(v_x11_24136);
    }
  }
  default: return heff_nomatch(v_x1_24135);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args) {
  V v_st_24147 = args[0];
  V v_m_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24148 = heff_tr(heff_call(v_m_24146, 1, (V[]){v_st_24147}));
  switch (heff_tag_of(v_x1_24148)) {
  case TAG_MkPair: {
    V v_x11_24149 = heff_field(v_x1_24148, 0);
    V v_st_24150 = heff_field(v_x1_24148, 1);
    V v_ru_24x1_24148_24MkPair = heff_take_reuse_n(v_x1_24148, 3ULL, 2);
    switch (heff_tag_of(v_x11_24149)) {
    case TAG_Left: {
      V v_e_24151 = heff_field(v_x11_24149, 0);
      heff_take_n(v_x11_24149, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24148_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24151}), v_st_24150});
    }
    case TAG_Right: {
      V v_x_24152 = heff_field(v_x11_24149, 0);
      V v_ru_24x11_24149_24Right = heff_take_reuse_n(v_x11_24149, 1ULL, 1);
      V v_t_24153 = heff_tag_at_n(v_ru_24x11_24149_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24152})});
      return heff_tag_at_n(v_ru_24x1_24148_24MkPair, TAG_MkPair, 2, (V[]){v_t_24153, v_st_24150});
    }
    default: return heff_nomatch(v_x11_24149);
    }
  }
  default: return heff_nomatch(v_x1_24148);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args) {
  V v_st_24157 = args[0];
  V v_m_24156 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24158 = heff_tr(heff_call(v_m_24156, 1, (V[]){v_st_24157}));
  switch (heff_tag_of(v_x1_24158)) {
  case TAG_MkPair: {
    V v_x11_24159 = heff_field(v_x1_24158, 0);
    V v_st_24160 = heff_field(v_x1_24158, 1);
    V v_ru_24x1_24158_24MkPair = heff_take_reuse_n(v_x1_24158, 3ULL, 2);
    switch (heff_tag_of(v_x11_24159)) {
    case TAG_Left: {
      V v_e_24161 = heff_field(v_x11_24159, 0);
      heff_take_n(v_x11_24159, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24158_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24161}), v_st_24160});
    }
    case TAG_Right: {
      V v_x_24162 = heff_field(v_x11_24159, 0);
      V v_ru_24x11_24159_24Right = heff_take_reuse_n(v_x11_24159, 1ULL, 1);
      V v_t_24163 = heff_tag_at_n(v_ru_24x11_24159_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24162})});
      return heff_tag_at_n(v_ru_24x1_24158_24MkPair, TAG_MkPair, 2, (V[]){v_t_24163, v_st_24160});
    }
    default: return heff_nomatch(v_x11_24159);
    }
  }
  default: return heff_nomatch(v_x1_24158);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args) {
  V v_st_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_st_24167}));
  switch (heff_tag_of(v_x1_24168)) {
  case TAG_MkPair: {
    V v_x11_24169 = heff_field(v_x1_24168, 0);
    V v_st_24170 = heff_field(v_x1_24168, 1);
    V v_ru_24x1_24168_24MkPair = heff_take_reuse_n(v_x1_24168, 3ULL, 2);
    switch (heff_tag_of(v_x11_24169)) {
    case TAG_Left: {
      V v_e_24171 = heff_field(v_x11_24169, 0);
      heff_take_n(v_x11_24169, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24171}), v_st_24170});
    }
    case TAG_Right: {
      V v_x_24172 = heff_field(v_x11_24169, 0);
      V v_ru_24x11_24169_24Right = heff_take_reuse_n(v_x11_24169, 1ULL, 1);
      V v_t_24173 = heff_tag_at_n(v_ru_24x11_24169_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24172})});
      return heff_tag_at_n(v_ru_24x1_24168_24MkPair, TAG_MkPair, 2, (V[]){v_t_24173, v_st_24170});
    }
    default: return heff_nomatch(v_x11_24169);
    }
  }
  default: return heff_nomatch(v_x1_24168);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args) {
  V v_st_24177 = args[0];
  V v_m_24176 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24178 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_st_24177}));
  switch (heff_tag_of(v_x1_24178)) {
  case TAG_MkPair: {
    V v_x11_24179 = heff_field(v_x1_24178, 0);
    V v_st_24180 = heff_field(v_x1_24178, 1);
    V v_ru_24x1_24178_24MkPair = heff_take_reuse_n(v_x1_24178, 3ULL, 2);
    switch (heff_tag_of(v_x11_24179)) {
    case TAG_Left: {
      V v_e_24181 = heff_field(v_x11_24179, 0);
      heff_take_n(v_x11_24179, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24181}), v_st_24180});
    }
    case TAG_Right: {
      V v_x_24182 = heff_field(v_x11_24179, 0);
      V v_ru_24x11_24179_24Right = heff_take_reuse_n(v_x11_24179, 1ULL, 1);
      V v_t_24183 = heff_tag_at_n(v_ru_24x11_24179_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24182})});
      return heff_tag_at_n(v_ru_24x1_24178_24MkPair, TAG_MkPair, 2, (V[]){v_t_24183, v_st_24180});
    }
    default: return heff_nomatch(v_x11_24179);
    }
  }
  default: return heff_nomatch(v_x1_24178);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args) {
  V v_st_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_st_24187}));
  switch (heff_tag_of(v_x1_24188)) {
  case TAG_MkPair: {
    V v_x11_24189 = heff_field(v_x1_24188, 0);
    V v_st_24190 = heff_field(v_x1_24188, 1);
    V v_ru_24x1_24188_24MkPair = heff_take_reuse_n(v_x1_24188, 3ULL, 2);
    switch (heff_tag_of(v_x11_24189)) {
    case TAG_Left: {
      V v_e_24191 = heff_field(v_x11_24189, 0);
      heff_take_n(v_x11_24189, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24191}), v_st_24190});
    }
    case TAG_Right: {
      V v_x_24192 = heff_field(v_x11_24189, 0);
      V v_ru_24x11_24189_24Right = heff_take_reuse_n(v_x11_24189, 1ULL, 1);
      V v_t_24193 = heff_tag_at_n(v_ru_24x11_24189_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24192})});
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){v_t_24193, v_st_24190});
    }
    default: return heff_nomatch(v_x11_24189);
    }
  }
  default: return heff_nomatch(v_x1_24188);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args) {
  V v_st_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_st_24197}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      V v_ru_24x11_24199_24Right = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
      V v_t_24203 = heff_tag_at_n(v_ru_24x11_24199_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24202})});
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){v_t_24203, v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args) {
  V v_st_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24209 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_st_24208}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_MkPair: {
    V v_x11_24210 = heff_field(v_x1_24209, 0);
    V v_st_24211 = heff_field(v_x1_24209, 1);
    V v_ru_24x1_24209_24MkPair = heff_take_reuse_n(v_x1_24209, 3ULL, 2);
    switch (heff_tag_of(v_x11_24210)) {
    case TAG_Left: {
      V v_e_24212 = heff_field(v_x11_24210, 0);
      heff_take_n(v_x11_24210, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24212}), v_st_24211});
    }
    case TAG_Right: {
      V v_x_24213 = heff_field(v_x11_24210, 0);
      V v_ru_24x11_24210_24Right = heff_take_reuse_n(v_x11_24210, 1ULL, 1);
      V v_t_24214 = heff_tag_at_n(v_ru_24x11_24210_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24213})});
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){v_t_24214, v_st_24211});
    }
    default: return heff_nomatch(v_x11_24210);
    }
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args) {
  V v_st_24218 = args[0];
  V v_m_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24219 = heff_tr(heff_call(v_m_24217, 1, (V[]){v_st_24218}));
  switch (heff_tag_of(v_x1_24219)) {
  case TAG_MkPair: {
    V v_x11_24220 = heff_field(v_x1_24219, 0);
    V v_st_24221 = heff_field(v_x1_24219, 1);
    V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
    switch (heff_tag_of(v_x11_24220)) {
    case TAG_Left: {
      V v_e_24222 = heff_field(v_x11_24220, 0);
      heff_take_n(v_x11_24220, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
    }
    case TAG_Right: {
      V v_x_24223 = heff_field(v_x11_24220, 0);
      V v_ru_24x11_24220_24Right = heff_take_reuse_n(v_x11_24220, 1ULL, 1);
      V v_t_24224 = heff_tag_at_n(v_ru_24x11_24220_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24223})});
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){v_t_24224, v_st_24221});
    }
    default: return heff_nomatch(v_x11_24220);
    }
  }
  default: return heff_nomatch(v_x1_24219);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args) {
  V v_st_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_st_24228}));
  switch (heff_tag_of(v_x1_24229)) {
  case TAG_MkPair: {
    V v_x11_24230 = heff_field(v_x1_24229, 0);
    V v_st_24231 = heff_field(v_x1_24229, 1);
    V v_ru_24x1_24229_24MkPair = heff_take_reuse_n(v_x1_24229, 3ULL, 2);
    switch (heff_tag_of(v_x11_24230)) {
    case TAG_Left: {
      V v_e_24232 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24232}), v_st_24231});
    }
    case TAG_Right: {
      V v_x_24233 = heff_field(v_x11_24230, 0);
      V v_ru_24x11_24230_24Right = heff_take_reuse_n(v_x11_24230, 1ULL, 1);
      V v_t_24234 = heff_tag_at_n(v_ru_24x11_24230_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24233})});
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){v_t_24234, v_st_24231});
    }
    default: return heff_nomatch(v_x11_24230);
    }
  }
  default: return heff_nomatch(v_x1_24229);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args) {
  V v_st_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_st_24239}));
  switch (heff_tag_of(v_x1_24240)) {
  case TAG_MkPair: {
    V v_x11_24241 = heff_field(v_x1_24240, 0);
    V v_st_24242 = heff_field(v_x1_24240, 1);
    V v_ru_24x1_24240_24MkPair = heff_take_reuse_n(v_x1_24240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24241)) {
    case TAG_Left: {
      V v_e_24243 = heff_field(v_x11_24241, 0);
      heff_take_n(v_x11_24241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24243}), v_st_24242});
    }
    case TAG_Right: {
      V v_x_24244 = heff_field(v_x11_24241, 0);
      V v_ru_24x11_24241_24Right = heff_take_reuse_n(v_x11_24241, 1ULL, 1);
      V v_t_24245 = heff_tag_at_n(v_ru_24x11_24241_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24244})});
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){v_t_24245, v_st_24242});
    }
    default: return heff_nomatch(v_x11_24241);
    }
  }
  default: return heff_nomatch(v_x1_24240);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      V v_ru_24x11_24250_24Right = heff_take_reuse_n(v_x11_24250, 1ULL, 1);
      V v_t_24254 = heff_tag_at_n(v_ru_24x11_24250_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24253})});
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){v_t_24254, v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args) {
  V v_st_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24260 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_st_24259}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_MkPair: {
    V v_x11_24261 = heff_field(v_x1_24260, 0);
    V v_st_24262 = heff_field(v_x1_24260, 1);
    V v_ru_24x1_24260_24MkPair = heff_take_reuse_n(v_x1_24260, 3ULL, 2);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_Left: {
      V v_e_24263 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24263}), v_st_24262});
    }
    case TAG_Right: {
      V v_x_24264 = heff_field(v_x11_24261, 0);
      V v_ru_24x11_24261_24Right = heff_take_reuse_n(v_x11_24261, 1ULL, 1);
      V v_t_24265 = heff_tag_at_n(v_ru_24x11_24261_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24264})});
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){v_t_24265, v_st_24262});
    }
    default: return heff_nomatch(v_x11_24261);
    }
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args) {
  V v_st_24272 = args[0];
  V v_m_24271 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24273 = heff_tr(heff_call(v_m_24271, 1, (V[]){v_st_24272}));
  switch (heff_tag_of(v_x1_24273)) {
  case TAG_MkPair: {
    V v_x11_24274 = heff_field(v_x1_24273, 0);
    V v_st_24275 = heff_field(v_x1_24273, 1);
    V v_ru_24x1_24273_24MkPair = heff_take_reuse_n(v_x1_24273, 3ULL, 2);
    switch (heff_tag_of(v_x11_24274)) {
    case TAG_Left: {
      V v_e_24276 = heff_field(v_x11_24274, 0);
      heff_take_n(v_x11_24274, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24276}), v_st_24275});
    }
    case TAG_Right: {
      V v_x_24277 = heff_field(v_x11_24274, 0);
      V v_ru_24x11_24274_24Right = heff_take_reuse_n(v_x11_24274, 1ULL, 1);
      V v_t_24278 = heff_tag_at_n(v_ru_24x11_24274_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24277})});
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){v_t_24278, v_st_24275});
    }
    default: return heff_nomatch(v_x11_24274);
    }
  }
  default: return heff_nomatch(v_x1_24273);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args) {
  V v_st_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24281}));
  switch (heff_tag_of(v_x1_24282)) {
  case TAG_MkPair: {
    V v_x11_24283 = heff_field(v_x1_24282, 0);
    V v_st_24284 = heff_field(v_x1_24282, 1);
    V v_ru_24x1_24282_24MkPair = heff_take_reuse_n(v_x1_24282, 3ULL, 2);
    switch (heff_tag_of(v_x11_24283)) {
    case TAG_Left: {
      V v_e_24285 = heff_field(v_x11_24283, 0);
      heff_take_n(v_x11_24283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24285}), v_st_24284});
    }
    case TAG_Right: {
      V v_x_24286 = heff_field(v_x11_24283, 0);
      V v_ru_24x11_24283_24Right = heff_take_reuse_n(v_x11_24283, 1ULL, 1);
      V v_t_24287 = heff_tag_at_n(v_ru_24x11_24283_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24286})});
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){v_t_24287, v_st_24284});
    }
    default: return heff_nomatch(v_x11_24283);
    }
  }
  default: return heff_nomatch(v_x1_24282);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args) {
  V v_st_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24294 = heff_tr(heff_call(v_m_24292, 1, (V[]){v_st_24293}));
  switch (heff_tag_of(v_x1_24294)) {
  case TAG_MkPair: {
    V v_x11_24295 = heff_field(v_x1_24294, 0);
    V v_st_24296 = heff_field(v_x1_24294, 1);
    V v_ru_24x1_24294_24MkPair = heff_take_reuse_n(v_x1_24294, 3ULL, 2);
    switch (heff_tag_of(v_x11_24295)) {
    case TAG_Left: {
      V v_e_24297 = heff_field(v_x11_24295, 0);
      heff_take_n(v_x11_24295, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24297}), v_st_24296});
    }
    case TAG_Right: {
      V v_x_24298 = heff_field(v_x11_24295, 0);
      V v_ru_24x11_24295_24Right = heff_take_reuse_n(v_x11_24295, 1ULL, 1);
      V v_t_24299 = heff_tag_at_n(v_ru_24x11_24295_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24298})});
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){v_t_24299, v_st_24296});
    }
    default: return heff_nomatch(v_x11_24295);
    }
  }
  default: return heff_nomatch(v_x1_24294);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args) {
  V v_st_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24306 = heff_tr(heff_call(v_m_24304, 1, (V[]){v_st_24305}));
  switch (heff_tag_of(v_x1_24306)) {
  case TAG_MkPair: {
    V v_x11_24307 = heff_field(v_x1_24306, 0);
    V v_st_24308 = heff_field(v_x1_24306, 1);
    V v_ru_24x1_24306_24MkPair = heff_take_reuse_n(v_x1_24306, 3ULL, 2);
    switch (heff_tag_of(v_x11_24307)) {
    case TAG_Left: {
      V v_e_24309 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24309}), v_st_24308});
    }
    case TAG_Right: {
      V v_x_24310 = heff_field(v_x11_24307, 0);
      V v_ru_24x11_24307_24Right = heff_take_reuse_n(v_x11_24307, 1ULL, 1);
      V v_t_24311 = heff_tag_at_n(v_ru_24x11_24307_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24310})});
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){v_t_24311, v_st_24308});
    }
    default: return heff_nomatch(v_x11_24307);
    }
  }
  default: return heff_nomatch(v_x1_24306);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args) {
  V v_st_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24317 = heff_tr(heff_call(v_m_24315, 1, (V[]){v_st_24316}));
  switch (heff_tag_of(v_x1_24317)) {
  case TAG_MkPair: {
    V v_x11_24318 = heff_field(v_x1_24317, 0);
    V v_st_24319 = heff_field(v_x1_24317, 1);
    V v_ru_24x1_24317_24MkPair = heff_take_reuse_n(v_x1_24317, 3ULL, 2);
    switch (heff_tag_of(v_x11_24318)) {
    case TAG_Left: {
      V v_e_24320 = heff_field(v_x11_24318, 0);
      heff_take_n(v_x11_24318, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24320}), v_st_24319});
    }
    case TAG_Right: {
      V v_x_24321 = heff_field(v_x11_24318, 0);
      V v_ru_24x11_24318_24Right = heff_take_reuse_n(v_x11_24318, 1ULL, 1);
      V v_t_24322 = heff_tag_at_n(v_ru_24x11_24318_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24321})});
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){v_t_24322, v_st_24319});
    }
    default: return heff_nomatch(v_x11_24318);
    }
  }
  default: return heff_nomatch(v_x1_24317);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Right = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      V v_t_24336 = heff_tag_at_n(v_ru_24x11_24332_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24335})});
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){v_t_24336, v_st_24333});
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args) {
  V v_st_24340 = args[0];
  V v_m_24339 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24341 = heff_tr(heff_call(v_m_24339, 1, (V[]){v_st_24340}));
  switch (heff_tag_of(v_x1_24341)) {
  case TAG_MkPair: {
    V v_x11_24342 = heff_field(v_x1_24341, 0);
    V v_st_24343 = heff_field(v_x1_24341, 1);
    V v_ru_24x1_24341_24MkPair = heff_take_reuse_n(v_x1_24341, 3ULL, 2);
    switch (heff_tag_of(v_x11_24342)) {
    case TAG_Left: {
      V v_e_24344 = heff_field(v_x11_24342, 0);
      heff_take_n(v_x11_24342, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24344}), v_st_24343});
    }
    case TAG_Right: {
      V v_x_24345 = heff_field(v_x11_24342, 0);
      V v_ru_24x11_24342_24Right = heff_take_reuse_n(v_x11_24342, 1ULL, 1);
      V v_t_24346 = heff_tag_at_n(v_ru_24x11_24342_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24345})});
      return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){v_t_24346, v_st_24343});
    }
    default: return heff_nomatch(v_x11_24342);
    }
  }
  default: return heff_nomatch(v_x1_24341);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args) {
  V v_st_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_st_24351}));
  switch (heff_tag_of(v_x1_24352)) {
  case TAG_MkPair: {
    V v_x11_24353 = heff_field(v_x1_24352, 0);
    V v_st_24354 = heff_field(v_x1_24352, 1);
    V v_ru_24x1_24352_24MkPair = heff_take_reuse_n(v_x1_24352, 3ULL, 2);
    switch (heff_tag_of(v_x11_24353)) {
    case TAG_Left: {
      V v_e_24355 = heff_field(v_x11_24353, 0);
      heff_take_n(v_x11_24353, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24355}), v_st_24354});
    }
    case TAG_Right: {
      V v_x_24356 = heff_field(v_x11_24353, 0);
      V v_ru_24x11_24353_24Right = heff_take_reuse_n(v_x11_24353, 1ULL, 1);
      V v_t_24357 = heff_tag_at_n(v_ru_24x11_24353_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24356})});
      return heff_tag_at_n(v_ru_24x1_24352_24MkPair, TAG_MkPair, 2, (V[]){v_t_24357, v_st_24354});
    }
    default: return heff_nomatch(v_x11_24353);
    }
  }
  default: return heff_nomatch(v_x1_24352);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam31(V self, V *args) {
  V v_st_24365 = args[0];
  V v_m_24364 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24366 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_st_24365}));
  switch (heff_tag_of(v_x1_24366)) {
  case TAG_MkPair: {
    V v_x11_24367 = heff_field(v_x1_24366, 0);
    V v_st_24368 = heff_field(v_x1_24366, 1);
    V v_ru_24x1_24366_24MkPair = heff_take_reuse_n(v_x1_24366, 3ULL, 2);
    switch (heff_tag_of(v_x11_24367)) {
    case TAG_Left: {
      V v_e_24369 = heff_field(v_x11_24367, 0);
      heff_take_n(v_x11_24367, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24369}), v_st_24368});
    }
    case TAG_Right: {
      V v_x_24370 = heff_field(v_x11_24367, 0);
      V v_ru_24x11_24367_24Right = heff_take_reuse_n(v_x11_24367, 1ULL, 1);
      V v_t_24371 = heff_tag_at_n(v_ru_24x11_24367_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24370})});
      return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){v_t_24371, v_st_24368});
    }
    default: return heff_nomatch(v_x11_24367);
    }
  }
  default: return heff_nomatch(v_x1_24366);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam32(V self, V *args) {
  V v_st_24380 = args[0];
  V v_m_24379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24381 = heff_tr(heff_call(v_m_24379, 1, (V[]){v_st_24380}));
  switch (heff_tag_of(v_x1_24381)) {
  case TAG_MkPair: {
    V v_x11_24382 = heff_field(v_x1_24381, 0);
    V v_st_24383 = heff_field(v_x1_24381, 1);
    V v_ru_24x1_24381_24MkPair = heff_take_reuse_n(v_x1_24381, 3ULL, 2);
    switch (heff_tag_of(v_x11_24382)) {
    case TAG_Left: {
      V v_e_24384 = heff_field(v_x11_24382, 0);
      heff_take_n(v_x11_24382, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
    }
    case TAG_Right: {
      V v_x_24385 = heff_field(v_x11_24382, 0);
      V v_ru_24x11_24382_24Right = heff_take_reuse_n(v_x11_24382, 1ULL, 1);
      V v_t_24386 = heff_tag_at_n(v_ru_24x11_24382_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24385})});
      return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){v_t_24386, v_st_24383});
    }
    default: return heff_nomatch(v_x11_24382);
    }
  }
  default: return heff_nomatch(v_x1_24381);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam33(V self, V *args) {
  V v_st_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_st_24394}));
  switch (heff_tag_of(v_x1_24395)) {
  case TAG_MkPair: {
    V v_x11_24396 = heff_field(v_x1_24395, 0);
    V v_st_24397 = heff_field(v_x1_24395, 1);
    V v_ru_24x1_24395_24MkPair = heff_take_reuse_n(v_x1_24395, 3ULL, 2);
    switch (heff_tag_of(v_x11_24396)) {
    case TAG_Left: {
      V v_e_24398 = heff_field(v_x11_24396, 0);
      heff_take_n(v_x11_24396, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24398}), v_st_24397});
    }
    case TAG_Right: {
      V v_x_24399 = heff_field(v_x11_24396, 0);
      V v_ru_24x11_24396_24Right = heff_take_reuse_n(v_x11_24396, 1ULL, 1);
      V v_t_24400 = heff_tag_at_n(v_ru_24x11_24396_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24399})});
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){v_t_24400, v_st_24397});
    }
    default: return heff_nomatch(v_x11_24396);
    }
  }
  default: return heff_nomatch(v_x1_24395);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam34(V self, V *args) {
  V v_st_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_st_24405}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      V v_ru_24x11_24407_24Right = heff_take_reuse_n(v_x11_24407, 1ULL, 1);
      V v_t_24411 = heff_tag_at_n(v_ru_24x11_24407_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24410})});
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){v_t_24411, v_st_24408});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam35(V self, V *args) {
  V v_st_24417 = args[0];
  V v_m_24416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24418 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_st_24417}));
  switch (heff_tag_of(v_x1_24418)) {
  case TAG_MkPair: {
    V v_x11_24419 = heff_field(v_x1_24418, 0);
    V v_st_24420 = heff_field(v_x1_24418, 1);
    V v_ru_24x1_24418_24MkPair = heff_take_reuse_n(v_x1_24418, 3ULL, 2);
    switch (heff_tag_of(v_x11_24419)) {
    case TAG_Left: {
      V v_e_24421 = heff_field(v_x11_24419, 0);
      heff_take_n(v_x11_24419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24421}), v_st_24420});
    }
    case TAG_Right: {
      V v_x_24422 = heff_field(v_x11_24419, 0);
      V v_ru_24x11_24419_24Right = heff_take_reuse_n(v_x11_24419, 1ULL, 1);
      V v_t_24423 = heff_tag_at_n(v_ru_24x11_24419_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24422})});
      return heff_tag_at_n(v_ru_24x1_24418_24MkPair, TAG_MkPair, 2, (V[]){v_t_24423, v_st_24420});
    }
    default: return heff_nomatch(v_x11_24419);
    }
  }
  default: return heff_nomatch(v_x1_24418);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam36(V self, V *args) {
  V v_st_24431 = args[0];
  V v_m_24430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24432 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_st_24431}));
  switch (heff_tag_of(v_x1_24432)) {
  case TAG_MkPair: {
    V v_x11_24433 = heff_field(v_x1_24432, 0);
    V v_st_24434 = heff_field(v_x1_24432, 1);
    V v_ru_24x1_24432_24MkPair = heff_take_reuse_n(v_x1_24432, 3ULL, 2);
    switch (heff_tag_of(v_x11_24433)) {
    case TAG_Left: {
      V v_e_24435 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24435}), v_st_24434});
    }
    case TAG_Right: {
      V v_x_24436 = heff_field(v_x11_24433, 0);
      V v_ru_24x11_24433_24Right = heff_take_reuse_n(v_x11_24433, 1ULL, 1);
      V v_t_24437 = heff_tag_at_n(v_ru_24x11_24433_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24436})});
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){v_t_24437, v_st_24434});
    }
    default: return heff_nomatch(v_x11_24433);
    }
  }
  default: return heff_nomatch(v_x1_24432);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam37(V self, V *args) {
  V v_st_24440 = args[0];
  V v_m_24439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24441 = heff_tr(heff_call(v_m_24439, 1, (V[]){v_st_24440}));
  switch (heff_tag_of(v_x1_24441)) {
  case TAG_MkPair: {
    V v_x11_24442 = heff_field(v_x1_24441, 0);
    V v_st_24443 = heff_field(v_x1_24441, 1);
    V v_ru_24x1_24441_24MkPair = heff_take_reuse_n(v_x1_24441, 3ULL, 2);
    switch (heff_tag_of(v_x11_24442)) {
    case TAG_Left: {
      V v_e_24444 = heff_field(v_x11_24442, 0);
      heff_take_n(v_x11_24442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24444}), v_st_24443});
    }
    case TAG_Right: {
      V v_x_24445 = heff_field(v_x11_24442, 0);
      V v_ru_24x11_24442_24Right = heff_take_reuse_n(v_x11_24442, 1ULL, 1);
      V v_t_24446 = heff_tag_at_n(v_ru_24x11_24442_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24445})});
      return heff_tag_at_n(v_ru_24x1_24441_24MkPair, TAG_MkPair, 2, (V[]){v_t_24446, v_st_24443});
    }
    default: return heff_nomatch(v_x11_24442);
    }
  }
  default: return heff_nomatch(v_x1_24441);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam38(V self, V *args) {
  V v_st_24450 = args[0];
  V v_m_24449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24451 = heff_tr(heff_call(v_m_24449, 1, (V[]){v_st_24450}));
  switch (heff_tag_of(v_x1_24451)) {
  case TAG_MkPair: {
    V v_x11_24452 = heff_field(v_x1_24451, 0);
    V v_st_24453 = heff_field(v_x1_24451, 1);
    V v_ru_24x1_24451_24MkPair = heff_take_reuse_n(v_x1_24451, 3ULL, 2);
    switch (heff_tag_of(v_x11_24452)) {
    case TAG_Left: {
      V v_e_24454 = heff_field(v_x11_24452, 0);
      heff_take_n(v_x11_24452, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24454}), v_st_24453});
    }
    case TAG_Right: {
      V v_x_24455 = heff_field(v_x11_24452, 0);
      V v_ru_24x11_24452_24Right = heff_take_reuse_n(v_x11_24452, 1ULL, 1);
      V v_t_24456 = heff_tag_at_n(v_ru_24x11_24452_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24455})});
      return heff_tag_at_n(v_ru_24x1_24451_24MkPair, TAG_MkPair, 2, (V[]){v_t_24456, v_st_24453});
    }
    default: return heff_nomatch(v_x11_24452);
    }
  }
  default: return heff_nomatch(v_x1_24451);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam39(V self, V *args) {
  V v_st_24462 = args[0];
  V v_m_24461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24463 = heff_tr(heff_call(v_m_24461, 1, (V[]){v_st_24462}));
  switch (heff_tag_of(v_x1_24463)) {
  case TAG_MkPair: {
    V v_x11_24464 = heff_field(v_x1_24463, 0);
    V v_st_24465 = heff_field(v_x1_24463, 1);
    V v_ru_24x1_24463_24MkPair = heff_take_reuse_n(v_x1_24463, 3ULL, 2);
    switch (heff_tag_of(v_x11_24464)) {
    case TAG_Left: {
      V v_e_24466 = heff_field(v_x11_24464, 0);
      heff_take_n(v_x11_24464, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24466}), v_st_24465});
    }
    case TAG_Right: {
      V v_x_24467 = heff_field(v_x11_24464, 0);
      V v_ru_24x11_24464_24Right = heff_take_reuse_n(v_x11_24464, 1ULL, 1);
      V v_t_24468 = heff_tag_at_n(v_ru_24x11_24464_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24467})});
      return heff_tag_at_n(v_ru_24x1_24463_24MkPair, TAG_MkPair, 2, (V[]){v_t_24468, v_st_24465});
    }
    default: return heff_nomatch(v_x11_24464);
    }
  }
  default: return heff_nomatch(v_x1_24463);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam40(V self, V *args) {
  V v_st_24472 = args[0];
  V v_m_24471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24473 = heff_tr(heff_call(v_m_24471, 1, (V[]){v_st_24472}));
  switch (heff_tag_of(v_x1_24473)) {
  case TAG_MkPair: {
    V v_x11_24474 = heff_field(v_x1_24473, 0);
    V v_st_24475 = heff_field(v_x1_24473, 1);
    V v_ru_24x1_24473_24MkPair = heff_take_reuse_n(v_x1_24473, 3ULL, 2);
    switch (heff_tag_of(v_x11_24474)) {
    case TAG_Left: {
      V v_e_24476 = heff_field(v_x11_24474, 0);
      heff_take_n(v_x11_24474, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24476}), v_st_24475});
    }
    case TAG_Right: {
      V v_x_24477 = heff_field(v_x11_24474, 0);
      V v_ru_24x11_24474_24Right = heff_take_reuse_n(v_x11_24474, 1ULL, 1);
      V v_t_24478 = heff_tag_at_n(v_ru_24x11_24474_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24477})});
      return heff_tag_at_n(v_ru_24x1_24473_24MkPair, TAG_MkPair, 2, (V[]){v_t_24478, v_st_24475});
    }
    default: return heff_nomatch(v_x11_24474);
    }
  }
  default: return heff_nomatch(v_x1_24473);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam41(V self, V *args) {
  V v_st_24484 = args[0];
  V v_m_24483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24485 = heff_tr(heff_call(v_m_24483, 1, (V[]){v_st_24484}));
  switch (heff_tag_of(v_x1_24485)) {
  case TAG_MkPair: {
    V v_x11_24486 = heff_field(v_x1_24485, 0);
    V v_st_24487 = heff_field(v_x1_24485, 1);
    V v_ru_24x1_24485_24MkPair = heff_take_reuse_n(v_x1_24485, 3ULL, 2);
    switch (heff_tag_of(v_x11_24486)) {
    case TAG_Left: {
      V v_e_24488 = heff_field(v_x11_24486, 0);
      heff_take_n(v_x11_24486, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24488}), v_st_24487});
    }
    case TAG_Right: {
      V v_x_24489 = heff_field(v_x11_24486, 0);
      V v_ru_24x11_24486_24Right = heff_take_reuse_n(v_x11_24486, 1ULL, 1);
      V v_t_24490 = heff_tag_at_n(v_ru_24x11_24486_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24489})});
      return heff_tag_at_n(v_ru_24x1_24485_24MkPair, TAG_MkPair, 2, (V[]){v_t_24490, v_st_24487});
    }
    default: return heff_nomatch(v_x11_24486);
    }
  }
  default: return heff_nomatch(v_x1_24485);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam42(V self, V *args) {
  V v_st_24496 = args[0];
  V v_m_24495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24497 = heff_tr(heff_call(v_m_24495, 1, (V[]){v_st_24496}));
  switch (heff_tag_of(v_x1_24497)) {
  case TAG_MkPair: {
    V v_x11_24498 = heff_field(v_x1_24497, 0);
    V v_st_24499 = heff_field(v_x1_24497, 1);
    V v_ru_24x1_24497_24MkPair = heff_take_reuse_n(v_x1_24497, 3ULL, 2);
    switch (heff_tag_of(v_x11_24498)) {
    case TAG_Left: {
      V v_e_24500 = heff_field(v_x11_24498, 0);
      heff_take_n(v_x11_24498, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24500}), v_st_24499});
    }
    case TAG_Right: {
      V v_x_24501 = heff_field(v_x11_24498, 0);
      V v_ru_24x11_24498_24Right = heff_take_reuse_n(v_x11_24498, 1ULL, 1);
      V v_t_24502 = heff_tag_at_n(v_ru_24x11_24498_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24501})});
      return heff_tag_at_n(v_ru_24x1_24497_24MkPair, TAG_MkPair, 2, (V[]){v_t_24502, v_st_24499});
    }
    default: return heff_nomatch(v_x11_24498);
    }
  }
  default: return heff_nomatch(v_x1_24497);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam43(V self, V *args) {
  V v_st_24508 = args[0];
  V v_m_24507 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24509 = heff_tr(heff_call(v_m_24507, 1, (V[]){v_st_24508}));
  switch (heff_tag_of(v_x1_24509)) {
  case TAG_MkPair: {
    V v_x11_24510 = heff_field(v_x1_24509, 0);
    V v_st_24511 = heff_field(v_x1_24509, 1);
    V v_ru_24x1_24509_24MkPair = heff_take_reuse_n(v_x1_24509, 3ULL, 2);
    switch (heff_tag_of(v_x11_24510)) {
    case TAG_Left: {
      V v_e_24512 = heff_field(v_x11_24510, 0);
      heff_take_n(v_x11_24510, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24512}), v_st_24511});
    }
    case TAG_Right: {
      V v_x_24513 = heff_field(v_x11_24510, 0);
      V v_ru_24x11_24510_24Right = heff_take_reuse_n(v_x11_24510, 1ULL, 1);
      V v_t_24514 = heff_tag_at_n(v_ru_24x11_24510_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24513})});
      return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){v_t_24514, v_st_24511});
    }
    default: return heff_nomatch(v_x11_24510);
    }
  }
  default: return heff_nomatch(v_x1_24509);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam44(V self, V *args) {
  V v_st_24522 = args[0];
  V v_m_24521 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24523 = heff_tr(heff_call(v_m_24521, 1, (V[]){v_st_24522}));
  switch (heff_tag_of(v_x1_24523)) {
  case TAG_MkPair: {
    V v_x11_24524 = heff_field(v_x1_24523, 0);
    V v_st_24525 = heff_field(v_x1_24523, 1);
    V v_ru_24x1_24523_24MkPair = heff_take_reuse_n(v_x1_24523, 3ULL, 2);
    switch (heff_tag_of(v_x11_24524)) {
    case TAG_Left: {
      V v_e_24526 = heff_field(v_x11_24524, 0);
      heff_take_n(v_x11_24524, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24523_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24526}), v_st_24525});
    }
    case TAG_Right: {
      V v_x_24527 = heff_field(v_x11_24524, 0);
      V v_ru_24x11_24524_24Right = heff_take_reuse_n(v_x11_24524, 1ULL, 1);
      V v_t_24528 = heff_tag_at_n(v_ru_24x11_24524_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24527})});
      return heff_tag_at_n(v_ru_24x1_24523_24MkPair, TAG_MkPair, 2, (V[]){v_t_24528, v_st_24525});
    }
    default: return heff_nomatch(v_x11_24524);
    }
  }
  default: return heff_nomatch(v_x1_24523);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam45(V self, V *args) {
  V v_m_24552 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_24552));
}
Clo g_heff_2esyntax_2esurface_2etwoToS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etwoToS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etwoToS(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etwoToS(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_entry, 6, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith(V v_r_240, V v_last_241, V v_sp_242, V v_p_243, V v_s_244, V v_z_245) {
top: ;
  V v_x2_246 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam0, 1, 2, (V[]){v_x2_246, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam1, 2, 5, (V[]){v_r_240, v_p_243, v_sp_242, v_s_244, heff_dup(v_last_241)}), v_z_245));
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x2_246 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_246) == NTAG(TAG_True))) {
    heff_drop(v_x2_246);
    heff_drop(v_sp_242);
    V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_p_247});
  } else {
    heff_drop(v_x2_246);
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_p_247});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_z_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_last_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_2411}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_s_244);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_At: {
        V v_x11_2418 = heff_dup(heff_field(v_x_2417, 0));
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2427 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          v_t_2437 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_IntValue, 1, (V[]){v_v_2427});
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2418);
        }
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      HeffT2 v_t_2438 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_242); V a_2 = v_x_2417; V a_3 = v_t_2437; V a_4 = v_s_244; V a_5 = v_st_2415; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        V v_x11_2441 = v_field_2439;
        V v_st_2442 = v_field_2440;
        switch (heff_tag_of(v_x11_2441)) {
        case TAG_Left: {
          V v_e_2443 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
        }
        case TAG_Right: {
          V v_x_2444 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          if (!(heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_last_241);
            V v_t_2447;
            switch (heff_tag_of(v_x_2444)) {
            case TAG_At: {
              V v_x_2445 = heff_dup(heff_field(v_x_2444, 0));
              v_t_2447 = v_x_2445;
              break;
            }
            default: heff_nomatch(v_x_2444);
            }
            V v_t_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2447); r_; });
            if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
              heff_drop(v_x_2444);
              heff_drop(v_t_2448);
              V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2449}), v_st_2442});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2448);
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
            }
          } else {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
          }
        }
        default: return heff_nomatch(v_x11_2441);
        }
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eargL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eargL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eargL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EParen: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Named: {
    V v_o_246 = heff_field(v_x2_241, 0);
    V v_x_247 = heff_field(v_x2_241, 1);
    V v_e_249 = heff_field(v_x2_241, 3);
    V v_c_2410 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 27ULL, 5);
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_249}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eargL_lam0, 1, 4, (V[]){v_m_2411, v_x_247, v_o_246, v_c_2410});
  }
  case TAG_Tup: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Seg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Braces: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Update: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EUSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_InstB: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EFDefault: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Sum: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ECon: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EField: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ENeg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ETilde: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_App: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Op: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Ops: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Ann: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BVar: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BImp: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BPat: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Lam: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Case: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_If: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Do: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ELet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ELetElse: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ELetMut: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EAssign: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EWhile: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EFor: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EJump: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EReturn: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ENest: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EArrow: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_IfThen: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ETry: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ECatch: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EWith: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eargL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_o_246 = heff_env(self)[2];
  V v_c_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_x_247, 9);
      heff_drop_rec(v_o_246, 9);
      heff_drop_rec(v_c_2410, 9);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_tag_n(TAG_ENamed, 2, (V[]){heff_get_n(v_x_247, 1, 9), v_x_2417});
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_246, 3, 9), heff_get_n(v_c_2410, 4, 9)});
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419})});
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyPatOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(a[0]);
}
V g_heff_2esyntax_2esurface_2esigL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2esigL_24cpr(V v_r_240, V v_declared_241, V v_start_242, V v_names_243, V v_ty_244, V v_z_245) {
top: ;
  V v_t_246 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_243)));
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_declared_241);
      heff_drop(v_start_242);
      heff_drop(v_names_243);
      heff_drop(v_ty_244);
      V v_d_2410 = v_field_249;
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2410}), v_z_245}});
    } else {
      heff_drop(v_field_249);
      V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_ty_244)}));
      V v_x1_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_245}));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_MkPair: {
        V v_x11_2413 = heff_field(v_x1_2412, 0);
        V v_st_2414 = heff_field(v_x1_2412, 1);
        heff_take_n(v_x1_2412, 3ULL, 2);
        switch (heff_tag_of(v_x11_2413)) {
        case TAG_Left: {
          V v_e_2415 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          heff_drop(v_declared_241);
          heff_drop(v_start_242);
          heff_drop(v_names_243);
          heff_drop(v_ty_244);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
        }
        case TAG_Right: {
          V v_x_2416 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          V v_t_2417 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_243)));
          V v_st_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2esigL_24cpr_lam0, 2, 1, (V[]){heff_dup(v_x_2416)}); V a_1 = v_st_2414; V a_2 = v_t_2417; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
          V v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(v_ty_244));
          V v_b_2425 = heff_get_n(v_t_2424, 4, 9);
          V v_x_2426 = (g_list_2emap_24f2041933216x1458595349(v_declared_241, v_x_2416, v_start_242, v_b_2425, v_names_243));
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2423}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2412)}});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2esigL_24cpr_lam0(V self, V *args) {
  V v_s_2418 = args[0];
  V v_n_2419 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_names_2420 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_2416)));
  V v_implicits_2421 = (g_heff_2esyntax_2esurface_2epiImplicits(v_x_2416));
  V v_t_2422 = heff_rec_n(3, shape_f__names__implicits, (V[]){heff_get_n(v_n_2419, 0, 2), v_names_2420, v_implicits_2421});
  return (g_heff_2esyntax_2esurface_2eaddBinders(v_t_2422, v_s_2418));
}

HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPi: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAnn: {
      V v_x111_2421 = heff_field(v_x11_241, 0);
      V v_t_2422 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_At: {
        V v_x1111_2423 = heff_field(v_x111_2421, 0);
        V v_xsp_2424 = heff_field(v_x111_2421, 1);
        heff_take_n(v_x111_2421, 3ULL, 2);
        switch (heff_tag_of(v_x1111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_x1111_2423, 0);
          heff_take_n(v_x1111_2423, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(3, shape_name__span__ty, (V[]){v_x_2425, v_xsp_2424, v_t_2422})}});
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_na(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EString: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBinary: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERune: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWord: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProject: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ENamed: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPi: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAnn: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESpec: {
          heff_take_n(v_x1111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESig: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESum: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStruct: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EUpdate: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EMatch: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELetIn: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EDo: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELocal: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInvalid: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAssign: {
          heff_take_n(v_x1111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWhile: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFor: {
          heff_take_n(v_x1111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EIfThen: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBreak: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EContinue: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EReturn: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ENest: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELazy: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETuple: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETry: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWith: {
          heff_take_n(v_x1111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1111_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_2421)}});
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      heff_take_n(v_x11_241, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V v_r_240, V v_kw_241, V v_name_242, V v_params_243, V v_body_244, V v_z_245) {
top: ;
  V v_text_246 = heff_take_field(v_name_242, 1);
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_get_n(v_name_242, 4, 9);
  V v_m_2410 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_243));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    heff_take_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_body_244);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2415)));
      V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2416, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1, 1, 7, (V[]){v_m_2417, v_body_244, v_kw_241, v_text_246, v_start_247, v_end_248, v_x_2415}), v_st_2413));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args) {
  V v_m_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_249));
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  V v_kw_241 = heff_env(self)[2];
  V v_text_246 = heff_env(self)[3];
  V v_start_247 = heff_env(self)[4];
  V v_end_248 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_x_2415);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2424 = heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_244)));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2426});
      V v_t_2428 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2415, heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2427}), v_x_2423});
      V v_t_2429 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2430 = heff_get_n(v_t_2429, 4, 9);
      V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2430});
      V v_t_2432 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_t_2431})});
      V v_x_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_fields_245, V v_z_246) {
top: ;
  V v_text_247 = heff_take_field(v_name_243, 1);
  V v_start_248 = heff_take_field(v_name_243, 3);
  V v_end_249 = heff_get_n(v_name_243, 4, 9);
  V v_m_2411 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_MkPair: {
    V v_x11_2413 = heff_field(v_x1_2412, 0);
    V v_st_2414 = heff_field(v_x1_2412, 1);
    heff_take_n(v_x1_2412, 3ULL, 2);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_fields_245);
      heff_drop(v_text_247);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      V v_t_2417 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2416)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2417, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1, 1, 8, (V[]){v_r_240, v_fields_245, v_d_241, v_kw_242, v_text_247, v_start_248, v_end_249, v_x_2416}), v_st_2414));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2412)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_2410));
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_e_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2429}), v_st_2430});
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args) {
  V v_f_2419 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2419)) {
  case TAG_MkTF: {
    V v_xs_2420 = heff_field(v_f_2419, 0);
    V v_ty_2423 = heff_field(v_f_2419, 3);
    V v_d_2424 = heff_field(v_f_2419, 4);
    heff_take_n(v_f_2419, 25ULL, 5);
    V v_t_2425 = (g_list_2emap_24s146946949x1862800301(heff_dup(v_xs_2420)));
    HeffT2 v_t_2426 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2425));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_xs_2420);
        heff_drop(v_ty_2423);
        heff_drop(v_d_2424);
        V v_e_2429 = v_field_2428;
        return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3, 1, 1, (V[]){v_e_2429});
      } else {
        heff_drop(v_field_2428);
        return (g_prelude_2etraverse_24s430827533x596660821(v_r_240, v_ty_2423, v_d_2424, v_xs_2420));
      }
    }
  }
  default: return heff_nomatch(v_f_2419);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_fields_245 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_kw_242 = heff_env(self)[3];
  V v_text_247 = heff_env(self)[4];
  V v_start_248 = heff_env(self)[5];
  V v_end_249 = heff_env(self)[6];
  V v_x_2416 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2431 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2, 1, 1, (V[]){v_r_240}), v_fields_245, v_st_2418));
  {
    V v_field_2432 = v_t_2431.f[0];
    V v_field_2433 = v_t_2431.f[1];
    V v_x11_2434 = v_field_2432;
    V v_st_2435 = v_field_2433;
    switch (heff_tag_of(v_x11_2434)) {
    case TAG_Left: {
      V v_e_2436 = heff_field(v_x11_2434, 0);
      V v_ru_24x11_2434_24Left = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_text_247);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_x_2416);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Left, TAG_Left, 1, (V[]){v_e_2436}), v_st_2435});
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_x11_2434, 0);
      V v_ru_24x11_2434_24Right = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
      V v_t_2438 = ({ V a_0 = v_x_2437; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2437); r_; });
      V v_t_2439 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
      V v_e_2440 = heff_get_n(v_t_2439, 4, 9);
      V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2440});
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_t_2438}), v_t_2441});
      V v_t_2443 = heff_tag_n(TAG_DeclTheory, 4, (V[]){v_text_247, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249}), v_x_2416, v_t_2442});
      V v_t_2444 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
      V v_e_2445 = heff_get_n(v_t_2444, 4, 9);
      V v_t_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2445});
      V v_t_2447 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2446})});
      V v_x_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Right, TAG_Right, 1, (V[]){v_x_2448}), v_st_2435});
    }
    default: return heff_nomatch(v_x11_2434);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V v_r_240, V v_d_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    V v_ru_24d_241_24DImport = heff_take_reuse_n(v_d_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_244 = heff_tag_at_n(v_ru_24d_241_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_244, v_z_242}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_247, v_z_242}});
  }
  case TAG_DSig: {
    V v_names_248 = heff_field(v_d_241, 0);
    V v_ty_2411 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 9ULL, 4);
    V v_t_2416;
    switch (heff_tag_of(v_names_248)) {
    case TAG_Nil: {
      v_t_2416 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_dup(heff_field(v_names_248, 0));
      switch (heff_tag_of(v_x_2412)) {
      case TAG_Nil: {
        v_t_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_t_2414 = heff_field(v_x_2412, 0);
        heff_take_n(v_x_2412, 1ULL, 2);
        v_t_2416 = heff_get_n(v_t_2414, 3, 9);
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      break;
    }
    default: heff_nomatch(v_names_248);
    }
    return (g_heff_2esyntax_2esurface_2esigL_24cpr(v_r_240, NTAG(TAG_AsDefinition), v_t_2416, v_names_248, v_ty_2411, v_z_242));
  }
  case TAG_DInstance: {
    V v_kw_2417 = heff_field(v_d_241, 0);
    V v_names_2418 = heff_field(v_d_241, 1);
    V v_ty_2420 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_2418, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2esurface_2esigL_24cpr(v_r_240, NTAG(TAG_AsInstance), heff_get_n(v_kw_2417, 3, 9), v_t_2421, v_ty_2420, v_z_242));
  }
  case TAG_DEqn: {
    V v_names_2422 = heff_field(v_d_241, 0);
    V v_pats_2423 = heff_field(v_d_241, 1);
    V v_rhs_2425 = heff_field(v_d_241, 3);
    V v_w_2426 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 27ULL, 5);
    return ({ V a_0 = v_r_240; V a_1 = v_names_2422; V a_2 = v_pats_2423; V a_3 = v_rhs_2425; V a_4 = v_w_2426; V a_5 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_w_2426); r_; });
  }
  case TAG_DData: {
    V v_kw_2427 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2428 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2429 = heff_dup(heff_field(v_d_241, 2));
    V v_universe_2430 = heff_dup(heff_field(v_d_241, 3));
    V v_alts_2431 = heff_dup(heff_field(v_d_241, 4));
    return ({ V a_0 = v_r_240; V a_1 = v_d_241; V a_2 = v_kw_2427; V a_3 = v_name_2428; V a_4 = v_params_2429; V a_5 = v_universe_2430; V a_6 = v_alts_2431; V a_7 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_universe_2430); heff_drop(v_alts_2431); r_; });
  }
  case TAG_DType: {
    V v_kw_2432 = heff_field(v_d_241, 0);
    V v_name_2433 = heff_field(v_d_241, 1);
    V v_params_2434 = heff_field(v_d_241, 2);
    V v_body_2436 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24cpr(v_r_240, v_kw_2432, v_name_2433, v_params_2434, v_body_2436, v_z_242));
  }
  case TAG_DTheory: {
    V v_kw_2437 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2438 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2439 = heff_dup(heff_field(v_d_241, 2));
    V v_fields_2441 = heff_dup(heff_field(v_d_241, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24cpr(v_r_240, v_d_241, v_kw_2437, v_name_2438, v_params_2439, v_fields_2441, v_z_242));
  }
  case TAG_DMutual: {
    V v_kw_2442 = heff_field(v_d_241, 0);
    V v_ds_2443 = heff_field(v_d_241, 1);
    heff_take_n(v_d_241, 3ULL, 2);
    return (g_heff_2esyntax_2esurface_2emutualL_24cpr(v_r_240, v_kw_2442, v_ds_2443, v_z_242));
  }
  case TAG_DPrimitive: {
    V v_kw_2444 = heff_field(v_d_241, 0);
    V v_x_2445 = heff_field(v_d_241, 1);
    V v_ty_2447 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(v_r_240, v_kw_2444, v_x_2445, v_ty_2447, v_z_242));
  }
  case TAG_DTest: {
    V v_kw_2448 = heff_field(v_d_241, 0);
    V v_x_2449 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DTest = heff_take_reuse_n(v_d_241, 3ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_text_2450 = heff_take_field(v_x_2449, 1);
    V v_start_2451 = heff_take_field(v_x_2449, 3);
    V v_end_2452 = heff_get_n(v_x_2449, 4, 9);
    V v_t_2453 = heff_tag_at_n(v_ru_24d_241_24DTest, TAG_DeclTest, 2, (V[]){v_text_2450, heff_rec_n(2, shape_start__end, (V[]){v_start_2451, heff_dup(v_end_2452)})});
    V v_t_2454 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2448, 3, 9), v_end_2452});
    V v_t_2455 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2453, v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
    V v_f_2457 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2456});
    return ((HeffT2){{v_f_2457, v_z_242}});
  }
  case TAG_DWatch: {
    V v_w_2458 = heff_field(v_d_241, 0);
    V v_e_2459 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DWatch = heff_take_reuse_n(v_d_241, 3ULL, 2);
    V v_start_2460 = heff_take_field(v_w_2458, 3);
    V v_kind_2461 = heff_get_n(v_w_2458, 0, 9);
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_2459)}));
    V v_x1_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2463)) {
    case TAG_MkPair: {
      V v_x11_2464 = heff_field(v_x1_2463, 0);
      V v_st_2465 = heff_field(v_x1_2463, 1);
      V v_ru_24x1_2463_24MkPair = heff_take_reuse_n(v_x1_2463, 3ULL, 2);
      switch (heff_tag_of(v_x11_2464)) {
      case TAG_Left: {
        V v_e_2466 = heff_field(v_x11_2464, 0);
        V v_ru_24x11_2464_24Left = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
        heff_drop(v_e_2459);
        heff_drop_cell(v_ru_24d_241_24DWatch, 2);
        heff_drop(v_start_2460);
        heff_drop(v_kind_2461);
        heff_drop_cell(v_ru_24x1_2463_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2464_24Left, TAG_Left, 1, (V[]){v_e_2466}), v_st_2465}});
      }
      case TAG_Right: {
        V v_x_2467 = heff_field(v_x11_2464, 0);
        V v_ru_24x11_2464_24Right = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
        V v_t_2468 = (g_heff_2esyntax_2ecst_2elastE(v_e_2459));
        V v_e_2469 = heff_get_n(v_t_2468, 4, 9);
        V v_d_2470 = heff_tag_at_n(v_ru_24d_241_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2467}), heff_rec_n(2, shape_start__end, (V[]){v_start_2460, v_e_2469})});
        V v_t_2471;
        if (heff_strEq_c(v_kind_2461, ((V)&g_heff_2esyntax_2esurface_2edeclL_24cpr_str0))) {
          v_t_2471 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_2470});
        } else {
          v_t_2471 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_2470});
        }
        V v_x_2472 = heff_tag_at_n(v_ru_24x1_2463_24MkPair, TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2464_24Right, TAG_Right, 1, (V[]){v_x_2472}), v_st_2465}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2464)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2463)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabAbove_str0, 68, "`above` names the operators it is above (`below` alone is below all)");
Clo g_heff_2esyntax_2esurface_2eabAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabAbove_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eabAbove(V v_acc_240, V v_w_241, V v_ops_242) {
top: ;
  V v_start_243 = heff_take_field(v_w_241, 2);
  V v_end_244 = heff_get_n(v_w_241, 3, 7);
  V v_above_245 = heff_take_field(v_acc_240, 0);
  V v_below_246 = heff_take_field(v_acc_240, 1);
  V v_loosest_247 = heff_take_field(v_acc_240, 2);
  V v_errors_248 = heff_get_n(v_acc_240, 3, 4);
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eabAbove_str0), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244}), NTAG(TAG_Nothing)});
    return heff_rec_n(4, shape_above__below__loosest__errors, (V[]){v_above_245, v_below_246, v_loosest_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_errors_248})});
  }
  case TAG_Cons: {
    heff_drop(v_start_243);
    heff_drop(v_end_244);
    V v_t_2412 = (g_heff_2esyntax_2esurface_2eappendS(v_above_245, v_ops_242));
    return heff_rec_n(4, shape_above__below__loosest__errors, (V[]){v_t_2412, v_below_246, v_loosest_247, v_errors_248});
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabAbove(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2esyntax_2esurface_2efixDiagsOf(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_x_243)));
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_lit_240, v_lit_241, v_xs_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str3, 1, ":");
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadRun_entry, 6, 0};

V g_heff_2esyntax_2esurface_2ereadRun(V v_src_240, V v_o_241, V v_toks_242, V v_lexDiags_243, V v_declared_244, V v_own_245) {
top: ;
  V v_path_246 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_path_248 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2einitialSt(v_o_241, heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam0, 1, 2, (V[]){v_path_248, heff_dup(v_src_240)}), heff_dup(v_toks_242), v_declared_244, heff_dup(heff_rfield(v_own_245, 0))));
  V v_r_2412 = (g_heff_2esyntax_2esurface_2eprogGo(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_242, MK_INT(0LL), MK_INT(0LL), v_t_247, MK_INT(0LL)}), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2413 = (g_heff_2esyntax_2esurface_2eplaceDocs(v_src_240, heff_rfield(v_r_2412, 0)));
  return (g_heff_2esyntax_2esurface_2ereadPlaced(heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam1, 1, 2, (V[]){v_path_246, heff_dup(v_src_240)}), v_lexDiags_243, v_own_245, v_r_2412, v_t_2413));
}
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2esyntax_2esurface_2ereadRun(a0, a[1], a[2], a[3], a4, a[5]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_248, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str0), 2)) {
    heff_drop(v_path_248);
    return ({ V a_0 = v_src_240; V a_1 = v_i_249; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
  } else {
    V v_t_2410 = ({ V a_0 = v_src_240; V a_1 = v_i_249; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
    return heff_strAppend(v_path_248, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str1), v_t_2410));
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args) {
  V v_i_2414 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_246, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str2), 2)) {
    heff_drop(v_path_246);
    return ({ V a_0 = v_src_240; V a_1 = v_i_2414; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
  } else {
    V v_t_2415 = ({ V a_0 = v_src_240; V a_1 = v_i_2414; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
    return heff_strAppend(v_path_246, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str3), v_t_2415));
  }
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ereadLexed(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  V v_tokens_243 = heff_take_field(v_l_242, 0);
  V v_errors_244 = heff_get_n(v_l_242, 1, 3);
  V v_ltoks_245 = heff_arrayFromList(heff_dup(v_tokens_243));
  V v_t_246 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_tokens_243));
  V v_toks_247 = heff_arrayFromList(v_t_246);
  V v_lexDiags_248 = (g_list_2emap_24s338694954x1326523169(v_errors_244));
  V v_t_249 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_245, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
  V v_t_2410 = ({ V a_0 = v_ltoks_245; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ltoks_245); r_; });
  V v_t_2411 = (g_heff_2esyntax_2esurface_2efixityFrom(heff_dup(heff_rfield(v_o_241, 3)), heff_dup(heff_rfield(v_o_241, 1)), v_t_2410));
  return ({ V a_0 = v_src_240; V a_1 = v_o_241; V a_2 = v_toks_247; V a_3 = v_lexDiags_248; V a_4 = v_t_249; V a_5 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2ereadRun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_249); r_; });
}
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ereadLexed(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(V v_tok_240, V v_inPat_241, V v_sp_242, V v_e_243, V v_v_244, V v_st_245) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_v_244)) {
  case TAG_StrValue: {
    v_t_247 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_247 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_247 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_247 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_247 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_244);
  }
  HeffT2 v_t_248 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_242), heff_dup(v_v_244), v_t_247, v_st_245));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x11_2411 = v_field_249;
    V v_st_2412 = v_field_2410;
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_e_243);
      heff_drop(v_v_244);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 0ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_v_244)) {
      case TAG_StrValue: {
        v_t_2416 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2416 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2416 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2416 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2416 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_244);
      }
      V v_m_2417 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_241, heff_dup(v_sp_242), heff_dup(v_v_244), v_t_2416, NTAG(TAG_SizeDefault)));
      V v_x1_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2412}));
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_e_243);
          heff_drop(v_v_244);
          heff_drop_cell(v_ru_24x11_2411_24Right, 1);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 0ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_v_244)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_244, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2424 = heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_244);
          }
          V v_t_2425 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_243, v_t_2424, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2426 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2425, v_sp_242})});
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V v_tok_240, V v_xs_241, V v_p_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_241, v_p_242, v_st_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope_24tok2(a[0], a[1], a[2], a[3]);
}