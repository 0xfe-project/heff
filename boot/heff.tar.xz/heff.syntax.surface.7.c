// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_TagVariant 25174
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_arms 9498206
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_errors 652506774
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_i 323
#define LBL_id 10114
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_waiting 1348170899
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_e__pat__decl[] = {LBL_e, LBL_pat, LBL_decl};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_name__span__ty[] = {LBL_name, LBL_span, LBL_ty};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot, LBL_arms};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edeclL(V, V, V);
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2epatL(V, V, V);
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erevOnto(V, V);
V g_heff_2esyntax_2esurface_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erevOnto_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esetPatVars(V, V);
V g_heff_2esyntax_2esurface_2esetPatVars_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetPatVars_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2esharedFields(V);
V g_heff_2esyntax_2esurface_2esharedFields_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esharedFields_clo;
V g_heff_2esyntax_2esurface_2esigBinders(V, V, V);
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigBinders_clo;
V g_heff_2esyntax_2esurface_2esigNamesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2esigNamesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNamesFrom_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1389405036x1664963487(V, V, V);
V g_list_2efoldl_24s1389405036x1664963487_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1389405036x1664963487_clo;
V g_list_2ekeepIf_24s2053104128x1598844325(V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2041933216x1458595349(V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s430827533x596660821(V, V, V, V);
V g_prelude_2etraverse_24s430827533x596660821_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s430827533x596660821_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2esetPatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esetPatVars_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esetPatVars(V v_pv_240, V v_s_241) {
top: ;
  V v_known_242 = heff_take_field(v_s_241, 2);
  V v_binders_243 = heff_take_field(v_s_241, 3);
  V v_fix_244 = heff_take_field(v_s_241, 5);
  V v_lenient_245 = heff_take_field(v_s_241, 6);
  V v_at_246 = heff_take_field(v_s_241, 7);
  V v_knot_247 = heff_take_field(v_s_241, 8);
  V v_arms_248 = heff_take_field(v_s_241, 9);
  return ({ V rv_2 = v_known_242; V rv_3 = v_binders_243; V rv_4 = v_pv_240; V rv_5 = v_fix_244; V rv_6 = v_lenient_245; V rv_7 = v_at_246; V rv_8 = v_knot_247; V rv_9 = v_arms_248; V rr_ = heff_rec_reuse_nf(v_s_241, 3ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2esurface_2esetPatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esetPatVars(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2epiBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiBinders_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_b_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24EPi = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      V v_t_2432;
      switch (heff_tag_of(v_b_2417)) {
      case TAG_PiNamed: {
        V v_x_2419 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 3);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 5);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 4);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2417);
      }
      V v_t_2433 = (g_heff_2esyntax_2esurface_2epiBinders(v_rest_2418));
      return (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x11_241_24EPi, v_t_2432, v_t_2433));
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiBinders(a[0]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2easBinderOn(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EAnn: {
      V v_g_244 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_g_246 = v_g_244;
      V v_t_2413;
      switch (heff_tag_of(v_g_246)) {
      case TAG_At: {
        V v_e1_247 = heff_dup(heff_field(v_g_246, 0));
        switch (heff_tag_of(v_e1_247)) {
        case TAG_EApp: {
          V v_h_249 = heff_field(v_e1_247, 0);
          V v_xs_2410 = heff_field(v_e1_247, 1);
          heff_take_n(v_e1_247, 3ULL, 2);
          switch (heff_tag_of(v_g_246)) {
          case TAG_At: {
            v_t_2413 = heff_rec_n(2, shape_head__args, (V[]){v_h_249, v_xs_2410});
            break;
          }
          default: heff_nomatch(v_g_246);
          }
          break;
        }
        default: {
          heff_drop(v_e1_247);
          v_t_2413 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_246), NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_246);
      }
      V v_t_2414 = heff_get_n(v_t_2413, 0, 2);
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2422;
      switch (heff_tag_of(v_g_246)) {
      case TAG_At: {
        V v_e1_2416 = heff_dup(heff_field(v_g_246, 0));
        switch (heff_tag_of(v_e1_2416)) {
        case TAG_EApp: {
          V v_h_2418 = heff_field(v_e1_2416, 0);
          V v_xs_2419 = heff_field(v_e1_2416, 1);
          heff_take_n(v_e1_2416, 3ULL, 2);
          switch (heff_tag_of(v_g_246)) {
          case TAG_At: {
            heff_take_n(v_g_246, 0ULL, 2);
            v_t_2422 = heff_rec_n(2, shape_head__args, (V[]){v_h_2418, v_xs_2419});
            break;
          }
          default: heff_nomatch(v_g_246);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2416);
          v_t_2422 = heff_rec_n(2, shape_head__args, (V[]){v_g_246, NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_246);
      }
      V v_t_2423 = (g_list_2emap_24s878634257x1677201747(heff_get_n(v_t_2422, 1, 2)));
      V v_t_2424 = (g_heff_2esyntax_2esurface_2ecatMaybesS(heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){v_t_2415, v_t_2423})));
      V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2424, heff_dup(heff_rfield(v_p_241, 1))));
      V v_st_2426 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2425, v_p_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_st_2426});
    }
    default: {
      heff_drop(v_e1_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2enameBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameBinder(V v_e0_240) {
top: ;
  switch (heff_tag_of(v_e0_240)) {
  case TAG_At: {
    V v_e01_241 = heff_dup(heff_field(v_e0_240, 0));
    switch (heff_tag_of(v_e01_241)) {
    case TAG_EVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETag: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EInt: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EString: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EAnn: {
      V v_g_2421 = heff_field(v_e01_241, 0);
      V v_t_2422 = heff_field(v_e01_241, 1);
      V v_ru_24e01_241_24EAnn = heff_take_reuse_n(v_e01_241, 3ULL, 2);
      switch (heff_tag_of(v_e0_240)) {
      case TAG_At: {
        V v_ru_24e0_240_24At = heff_take_reuse_n(v_e0_240, 0ULL, 2);
        V v_t_2431;
        switch (heff_tag_of(v_g_2421)) {
        case TAG_At: {
          V v_e1_2425 = heff_dup(heff_field(v_g_2421, 0));
          switch (heff_tag_of(v_e1_2425)) {
          case TAG_EApp: {
            V v_h_2427 = heff_field(v_e1_2425, 0);
            V v_xs_2428 = heff_field(v_e1_2425, 1);
            heff_take_n(v_e1_2425, 3ULL, 2);
            switch (heff_tag_of(v_g_2421)) {
            case TAG_At: {
              v_t_2431 = heff_rec_n(2, shape_head__args, (V[]){v_h_2427, v_xs_2428});
              break;
            }
            default: heff_nomatch(v_g_2421);
            }
            break;
          }
          default: {
            heff_drop(v_e1_2425);
            v_t_2431 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_2421), NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_g_2421);
        }
        V v_t_2432 = ({ V b_0 = heff_get_n(v_t_2431, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eisNameE(b_0)); heff_drop(b_0); r_; });
        if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
          heff_drop(v_t_2432);
          V v_t_2439;
          switch (heff_tag_of(v_g_2421)) {
          case TAG_At: {
            V v_e1_2433 = heff_dup(heff_field(v_g_2421, 0));
            switch (heff_tag_of(v_e1_2433)) {
            case TAG_EApp: {
              V v_h_2435 = heff_field(v_e1_2433, 0);
              V v_xs_2436 = heff_field(v_e1_2433, 1);
              heff_take_n(v_e1_2433, 3ULL, 2);
              switch (heff_tag_of(v_g_2421)) {
              case TAG_At: {
                v_t_2439 = heff_rec_n(2, shape_head__args, (V[]){v_h_2435, v_xs_2436});
                break;
              }
              default: heff_nomatch(v_g_2421);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2433);
              v_t_2439 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_2421), NTAG(TAG_Nil)});
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_g_2421);
          }
          V v_t_2440 = ({ V b_0 = heff_get_n(v_t_2439, 1, 2); V r_ = (g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(b_0)); heff_drop(b_0); r_; });
          if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
            heff_drop(v_t_2440);
            V v_t_2447;
            switch (heff_tag_of(v_g_2421)) {
            case TAG_At: {
              V v_e1_2441 = heff_dup(heff_field(v_g_2421, 0));
              switch (heff_tag_of(v_e1_2441)) {
              case TAG_EApp: {
                V v_h_2443 = heff_field(v_e1_2441, 0);
                V v_xs_2444 = heff_field(v_e1_2441, 1);
                heff_take_n(v_e1_2441, 3ULL, 2);
                switch (heff_tag_of(v_g_2421)) {
                case TAG_At: {
                  v_t_2447 = heff_rec_n(2, shape_head__args, (V[]){v_h_2443, v_xs_2444});
                  break;
                }
                default: heff_nomatch(v_g_2421);
                }
                break;
              }
              default: {
                heff_drop(v_e1_2441);
                v_t_2447 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_2421), NTAG(TAG_Nil)});
                break;
              }
              }
              break;
            }
            default: heff_nomatch(v_g_2421);
            }
            V v_t_2448 = (g_heff_2esyntax_2esurface_2easNameE(heff_get_n(v_t_2447, 0, 2)));
            V v_t_2455;
            switch (heff_tag_of(v_g_2421)) {
            case TAG_At: {
              V v_e1_2449 = heff_dup(heff_field(v_g_2421, 0));
              switch (heff_tag_of(v_e1_2449)) {
              case TAG_EApp: {
                V v_h_2451 = heff_field(v_e1_2449, 0);
                V v_xs_2452 = heff_field(v_e1_2449, 1);
                heff_take_n(v_e1_2449, 3ULL, 2);
                switch (heff_tag_of(v_g_2421)) {
                case TAG_At: {
                  heff_take_n(v_g_2421, 0ULL, 2);
                  v_t_2455 = heff_rec_n(2, shape_head__args, (V[]){v_h_2451, v_xs_2452});
                  break;
                }
                default: heff_nomatch(v_g_2421);
                }
                break;
              }
              default: {
                heff_drop(v_e1_2449);
                v_t_2455 = heff_rec_n(2, shape_head__args, (V[]){v_g_2421, NTAG(TAG_Nil)});
                break;
              }
              }
              break;
            }
            default: heff_nomatch(v_g_2421);
            }
            V v_t_2456 = (g_list_2emap_24s1624059865x1140896478(heff_get_n(v_t_2455, 1, 2)));
            V v_e_2457 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2448, v_t_2456));
            V v_t_2460;
            switch (heff_tag_of(v_e_2457)) {
            case TAG_At: {
              V v_s_2459 = heff_dup(heff_field(v_e_2457, 1));
              v_t_2460 = v_s_2459;
              break;
            }
            default: heff_nomatch(v_e_2457);
            }
            V v_t_2463;
            switch (heff_tag_of(v_t_2422)) {
            case TAG_At: {
              V v_s_2462 = heff_dup(heff_field(v_t_2422, 1));
              v_t_2463 = v_s_2462;
              break;
            }
            default: heff_nomatch(v_t_2422);
            }
            V v_t_2464 = ({ V rv_1 = heff_get_n(v_t_2463, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2460, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24e0_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_e_2457, v_t_2422}), v_t_2464});
          } else {
            heff_drop(v_t_2440);
            V v_t_2467;
            switch (heff_tag_of(v_g_2421)) {
            case TAG_At: {
              V v_s_2466 = heff_dup(heff_field(v_g_2421, 1));
              v_t_2467 = v_s_2466;
              break;
            }
            default: heff_nomatch(v_g_2421);
            }
            V v_t_2470;
            switch (heff_tag_of(v_t_2422)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_t_2422, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_t_2422);
            }
            V v_t_2471 = ({ V rv_1 = heff_get_n(v_t_2470, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2467, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24e0_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2471});
          }
        } else {
          heff_drop(v_t_2432);
          V v_t_2474;
          switch (heff_tag_of(v_g_2421)) {
          case TAG_At: {
            V v_s_2473 = heff_dup(heff_field(v_g_2421, 1));
            v_t_2474 = v_s_2473;
            break;
          }
          default: heff_nomatch(v_g_2421);
          }
          V v_t_2477;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_At: {
            V v_s_2476 = heff_dup(heff_field(v_t_2422, 1));
            v_t_2477 = v_s_2476;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2478 = ({ V rv_1 = heff_get_n(v_t_2477, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2474, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24e0_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2478});
        }
      }
      default: return heff_nomatch(v_e0_240);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e01_241, 0ULL, 3);
      return v_e0_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e01_241, 0ULL, 3);
      return v_e0_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EBreak: {
      return v_e0_240;
    }
    case TAG_EContinue: {
      return v_e0_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWith: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    default: return heff_nomatch(v_e01_241);
    }
  }
  default: return heff_nomatch(v_e0_240);
  }
}
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2enameBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisVarE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str1, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str2, 34, "`), or import the module that does");
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2echeckFixOf(V v_fix_240, V v_lenient_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_fix_240, 2);
    return ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_2410 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam1, 1, 1, (V[]){heff_dup(v_r_245)}), heff_rfield(v_fix_240, 0)));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_rec(v_r_245, 2);
        V v_x_2413 = v_field_2412;
        heff_drop(v_x_2413);
        V t_0 = v_fix_240;
        V t_1 = v_lenient_241;
        V t_2 = v_rest_246;
        v_fix_240 = t_0;
        v_lenient_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_2412);
        if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_245, 2);
          V t_0 = v_fix_240;
          V t_1 = v_lenient_241;
          V t_2 = v_rest_246;
          v_fix_240 = t_0;
          v_lenient_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop_rec(v_fix_240, 2);
          heff_drop(v_rest_246);
          V v_t_2414 = heff_dup(heff_rfield(v_r_245, 0));
          V v_start_2415 = heff_take_field(v_t_2414, 3);
          V v_end_2416 = heff_get_n(v_t_2414, 4, 9);
          return heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam2, 1, 3, (V[]){v_r_245, v_start_2415, v_end_2416});
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2echeckFixOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_st_243});
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args) {
  V v_g_247 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_248}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_247, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args) {
  V v_st_2417 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_start_2415 = heff_env(self)[1];
  V v_end_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_r_245, 0)), 1, 9);
  V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str0), v_t_2418), ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str1));
  V v_t_2420 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2420), ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str2));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2421, heff_rec_n(2, shape_start__end, (V[]){v_start_2415, v_end_2416}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2422}), v_st_2417});
}
Clo g_heff_2esyntax_2esurface_2eassembleGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleGo_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eassembleGo(V v_broken_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_broken_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_it_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_broken_245 = heff_dup(v_broken_240);
    V v_rest_246 = heff_dup(v_rest_244);
    V v_x3_247 = v_it_243;
    V v_x1_2438;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Sig: {
      V v_declared_248 = heff_field(v_x3_247, 0);
      V v_f_249 = heff_field(v_x3_247, 1);
      V v_fsp_2410 = heff_field(v_x3_247, 2);
      V v_ty_2411 = heff_field(v_x3_247, 3);
      V v_sp_2412 = heff_field(v_x3_247, 4);
      V v_ru_24x3_247_24Sig = heff_take_reuse_n(v_x3_247, 31ULL, 5);
      HeffT2 v_t_2413 = ({ V a_0 = v_broken_245; V a_1 = v_f_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_broken_245); r_; });
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_rest_246);
          V v_x_2416 = v_field_2415;
          heff_drop(v_x_2416);
          V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_fsp_2410, 0)), heff_dup(heff_rfield(v_sp_2412, 1))});
          V v_t_2418 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_AbandonWord)});
          V v_t_2419 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_249), heff_dup(v_fsp_2410), NTAG(TAG_Nil), heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_2412)})});
          V v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2417}), NTAG(TAG_Nil)});
          V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x3_247_24Sig, TAG_DeclEquations, 5, (V[]){v_f_249, v_fsp_2410, v_declared_248, v_ty_2411, v_t_2420}), v_sp_2412});
          v_x1_2438 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_field_2415);
          HeffT2 v_t_2422 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_249, v_rest_246));
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              V v_es_2425 = v_field_2424;
              V v_end_2426 = heff_take_field(v_es_2425, 1);
              V v_eqns_2427 = heff_get_n(v_es_2425, 0, 2);
              V v_a_2428 = heff_take_field(v_sp_2412, 0);
              V v_a_2429 = heff_get_n(v_sp_2412, 1, 2);
              V v_b_2430 = v_end_2426;
              V v_t_2431;
              if (heff_intLt_c_lent(v_a_2429, v_b_2430, 0)) {
                heff_drop(v_a_2429);
                v_t_2431 = v_b_2430;
              } else {
                heff_drop(v_b_2430);
                v_t_2431 = v_a_2429;
              }
              V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x3_247_24Sig, TAG_DeclEquations, 5, (V[]){v_f_249, v_fsp_2410, v_declared_248, v_ty_2411, v_eqns_2427}), heff_rec_n(2, shape_start__end, (V[]){v_a_2428, v_t_2431})});
              v_x1_2438 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
            } else {
              heff_drop(v_declared_248);
              heff_drop(v_f_249);
              heff_drop_rec(v_fsp_2410, 2);
              heff_drop(v_ty_2411);
              heff_drop_rec(v_sp_2412, 2);
              heff_drop_cell(v_ru_24x3_247_24Sig, 5);
              heff_drop(v_field_2424);
              v_x1_2438 = NTAG(TAG_Nothing);
            }
          }
        }
      }
      break;
    }
    case TAG_Eqn: {
      heff_take_n(v_x3_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_broken_245);
      heff_drop(v_rest_246);
      v_x1_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Whole: {
      V v_d_2436 = heff_field(v_x3_247, 0);
      V v_ru_24x3_247_24Whole = heff_take_reuse_n(v_x3_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_broken_245);
      heff_drop(v_rest_246);
      v_x1_2438 = heff_tag_at_n(v_ru_24x3_247_24Whole, TAG_Just, 1, (V[]){v_d_2436});
      break;
    }
    case TAG_Doc: {
      V v_d_2437 = heff_field(v_x3_247, 0);
      V v_ru_24x3_247_24Doc = heff_take_reuse_n(v_x3_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_broken_245);
      heff_drop(v_rest_246);
      v_x1_2438 = heff_tag_at_n(v_ru_24x3_247_24Doc, TAG_Just, 1, (V[]){v_d_2437});
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    V v_t_2440;
    switch (heff_tag_of(v_x1_2438)) {
    case TAG_Nothing: {
      v_t_2440 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_x_2439 = heff_field(v_x1_2438, 0);
      heff_take_n(v_x1_2438, 1ULL, 1);
      v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2439, v_acc_242});
      break;
    }
    default: heff_nomatch(v_x1_2438);
    }
    V t_0 = v_broken_240;
    V t_1 = v_rest_244;
    V t_2 = v_t_2440;
    v_broken_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eassembleGo(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eeqnNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eeqnNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Eqn: {
      V v_f_248 = heff_field(v_x11_241, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnNames(v_rest_242));
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2411, heff_dup(v_f_248), NTAG(TAG_MkUnit)));
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eeqnNames(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2erevOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erevOnto_entry, 2, 0};

V g_heff_2esyntax_2esurface_2erevOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erevOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erevOnto(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ekwAtom_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2ekwAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ekwAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ekwAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_fs_241)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_243 = heff_dup(heff_field(v_fs_241, 0));
    V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2ekwAtom_str0));
    V v_t_246 = heff_strAppend(v_t_245, heff_get_n(v_f_243, 1, 9));
    v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_242, 2)), 1, (V[]){v_t_246}));
    break;
  }
  default: heff_nomatch(v_fs_241);
  }
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_242, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  V v_x_2414;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    heff_drop(v_t_248);
    v_x_2414 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
  } else {
    heff_drop(v_t_247);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_2411 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2410}), v_t_2411));
    } else {
      heff_drop(v_t_248);
      V v_e_2412 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
      V v_t_2413 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2412, v_t_2413));
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2414}), v_st_242});
}
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ekwAtom(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2epathOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epathOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epathOf(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_text_243 = heff_take_field(v_x_242, 1);
    V v_start_244 = heff_take_field(v_x_242, 3);
    V v_end_245 = heff_get_n(v_x_242, 4, 9);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_text_243, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_acc_241});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EField: {
    V v_e_2453 = heff_field(v_x1_240, 0);
    V v_f_2454 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_2455 = heff_take_field(v_f_2454, 1);
    V v_start_2456 = heff_take_field(v_f_2454, 3);
    V v_end_2457 = heff_get_n(v_f_2454, 4, 9);
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_MkPair, 2, (V[]){v_text_2455, heff_rec_n(2, shape_start__end, (V[]){v_start_2456, v_end_2457})});
    V t_0 = v_e_2453;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return v_acc_241;
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epathOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedL_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedL_str1, 24, "a field is `name : Type`");
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracedL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracedL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebracedL(V v_r_240, V v_f_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EFDefault: {
    V v_e_243 = heff_field(v_f_241, 0);
    V v_d_245 = heff_field(v_f_241, 2);
    heff_take_n(v_f_241, 5ULL, 3);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_d_245}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam0, 1, 4, (V[]){v_m_246, v_r_240, v_e_243, v_sp_242});
  }
  default: {
    V v_m_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_f_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam1, 1, 2, (V[]){v_m_2429, v_sp_242});
  }
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracedL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_243);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_243}));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2418));
          V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2419}));
          HeffT2 v_t_2421 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2ebracedL_str0), v_t_2420, v_st_2416));
          {
            V v_field_2422 = v_t_2421.f[0];
            V v_field_2423 = v_t_2421.f[1];
            V v_x11_2424 = v_field_2422;
            V v_st_2425 = v_field_2423;
            switch (heff_tag_of(v_x11_2424)) {
            case TAG_Left: {
              V v_e_2426 = heff_field(v_x11_2424, 0);
              heff_take_n(v_x11_2424, 1ULL, 1);
              heff_drop(v_sp_242);
              heff_drop(v_x_2412);
              heff_drop_cell(v_ru_24x11_249_24Right, 1);
              return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Left, 1, (V[]){v_e_2426}), v_st_2425});
            }
            case TAG_Right: {
              V v_x_2427 = heff_field(v_x11_2424, 0);
              heff_take_n(v_x11_2424, 1ULL, 1);
              V v_t_2428 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2427, heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Just, 1, (V[]){v_x_2412}), v_sp_242});
              return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_t_2428}), v_st_2425});
            }
            default: return heff_nomatch(v_x11_2424);
            }
          }
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Left, TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_t_2436 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2435));
      V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2436}));
      HeffT2 v_t_2438 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2ebracedL_str1), v_t_2437, v_st_2433));
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        V v_x11_2441 = v_field_2439;
        V v_st_2442 = v_field_2440;
        switch (heff_tag_of(v_x11_2441)) {
        case TAG_Left: {
          V v_e_2443 = heff_field(v_x11_2441, 0);
          V v_ru_24x11_2441_24Left = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x11_2432_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Left, TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
        }
        case TAG_Right: {
          V v_x_2444 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          V v_t_2445 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2444, NTAG(TAG_Nothing), v_sp_242});
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){v_t_2445}), v_st_2442});
        }
        default: return heff_nomatch(v_x11_2441);
        }
      }
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esharedFields_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2esharedFields_str1, 24, "a field is `name : Type`");
V g_heff_2esyntax_2esurface_2esharedFields_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2esharedFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esharedFields_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2esharedFields_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esharedFields_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esharedFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esharedFields_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esharedFields(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2esurface_2esharedFields_lam0_clo);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_m_246 = (g_heff_2esyntax_2esurface_2esharedFields(v_rest_244));
      return heff_clo_n(g_heff_2esyntax_2esurface_2esharedFields_lam1, 1, 2, (V[]){v_m_246, v_x_245});
    }
    case TAG_Right: {
      V v_f_2439 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_m_2440 = (g_heff_2esyntax_2esurface_2esharedFields(v_rest_244));
      return heff_clo_n(g_heff_2esyntax_2esurface_2esharedFields_lam2, 1, 2, (V[]){v_m_2440, v_f_2439});
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esharedFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esharedFields(a[0]);
}
V g_heff_2esyntax_2esurface_2esharedFields_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_heff_2esyntax_2esurface_2esharedFields_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_x_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_x_2413 = v_x_245;
      V v_start_2414 = heff_take_field(v_x_2413, 3);
      V v_end_2415 = heff_take_field(v_x_2413, 4);
      V v_text_2416 = heff_get_n(v_x_2413, 1, 9);
      V v_x2_2417 = heff_dup(v_x_2412);
      V v_p_2418 = v_st_2410;
      V v_x1_2433;
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x11_249_24Right, 1);
        heff_drop(v_text_2416);
        V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esharedFields_str0), heff_rec_n(2, shape_start__end, (V[]){v_start_2414, v_end_2415}), NTAG(TAG_Nothing)});
        v_x1_2433 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_p_2418});
        break;
      }
      case TAG_Cons: {
        V v_x21_2420 = heff_field(v_x2_2417, 0);
        V v_ru_24x2_2417_24Cons = heff_take_reuse_n(v_x2_2417, 1ULL, 2);
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_At: {
          V v_x211_2422 = heff_field(v_x21_2420, 0);
          V v_sp_2423 = heff_field(v_x21_2420, 1);
          heff_take_n(v_x21_2420, 3ULL, 2);
          switch (heff_tag_of(v_x211_2422)) {
          case TAG_DeclareField: {
            V v_t_2426 = heff_field(v_x211_2422, 2);
            V v_d_2427 = heff_field(v_x211_2422, 3);
            V v_ru_24x211_2422_24DeclareField = heff_take_reuse_n(v_x211_2422, 12ULL, 4);
            V v_t_2428 = heff_tag_at_n(v_ru_24x211_2422_24DeclareField, TAG_DeclareField, 4, (V[]){v_text_2416, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2414), v_end_2415}), v_t_2426, v_d_2427});
            V v_t_2429 = ({ V rv_0 = v_start_2414; V rr_ = heff_rec_reuse_nf(v_sp_2423, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2430 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_2417_24Cons, TAG_At, 2, (V[]){v_t_2428, v_t_2429})});
            v_x1_2433 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_p_2418});
            break;
          }
          case TAG_BadFieldDecl: {
            V v_ru_24x211_2422_24BadFieldDecl = heff_take_reuse_n(v_x211_2422, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_249_24Right, 1);
            heff_drop(v_text_2416);
            heff_drop_cell(v_ru_24x2_2417_24Cons, 2);
            heff_drop_rec(v_sp_2423, 2);
            V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esharedFields_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_2414, v_end_2415}), NTAG(TAG_Nothing)});
            v_x1_2433 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x211_2422_24BadFieldDecl, TAG_Left, 1, (V[]){v_t_2432}), v_p_2418});
            break;
          }
          default: heff_nomatch(v_x211_2422);
          }
          break;
        }
        default: heff_nomatch(v_x21_2420);
        }
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x11_2434 = heff_field(v_x1_2433, 0);
        V v_st_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        switch (heff_tag_of(v_x11_2434)) {
        case TAG_Left: {
          V v_e_2436 = heff_field(v_x11_2434, 0);
          V v_ru_24x11_2434_24Left = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
          heff_drop(v_x_2412);
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Left, TAG_Left, 1, (V[]){v_e_2436}), v_st_2435});
        }
        case TAG_Right: {
          V v_x_2437 = heff_field(v_x11_2434, 0);
          V v_ru_24x11_2434_24Right = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
          V v_t_2438 = heff_tag_at_n(v_ru_24x11_2434_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2437, v_x_2412})});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){v_t_2438, v_st_2435});
        }
        default: return heff_nomatch(v_x11_2434);
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2esharedFields_lam2(V self, V *args) {
  V v_st_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_f_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_st_2441}));
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_MkPair: {
    V v_x11_2443 = heff_field(v_x1_2442, 0);
    V v_st_2444 = heff_field(v_x1_2442, 1);
    V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
    switch (heff_tag_of(v_x11_2443)) {
    case TAG_Left: {
      V v_e_2445 = heff_field(v_x11_2443, 0);
      V v_ru_24x11_2443_24Left = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
      heff_drop(v_f_2439);
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2443_24Left, TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_x11_2443, 0);
      V v_ru_24x11_2443_24Right = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
      V v_t_2447 = heff_tag_at_n(v_ru_24x11_2443_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_f_2439, v_x_2446})});
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_st_2444});
    }
    default: return heff_nomatch(v_x11_2443);
    }
  }
  default: return heff_nomatch(v_x1_2442);
  }
}
Clo g_heff_2esyntax_2esurface_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantOf(V v_e_240) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EApp: {
      V v_h_243 = heff_field(v_e1_241, 0);
      V v_xs_244 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        v_t_247 = heff_rec_n(2, shape_head__args, (V[]){v_h_243, v_xs_244});
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      break;
    }
    default: {
      heff_drop(v_e1_241);
      v_t_247 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_e_240), NTAG(TAG_Nil)});
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_e_240);
  }
  V v_t_248 = heff_get_n(v_t_247, 0, 2);
  switch (heff_tag_of(v_t_248)) {
  case TAG_At: {
    V v_it1_249 = heff_field(v_t_248, 0);
    V v_tsp_2410 = heff_field(v_t_248, 1);
    V v_ru_24t_248_24At = heff_take_reuse_n(v_t_248, 3ULL, 2);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_ETag: {
      V v_t_2411 = heff_field(v_it1_249, 0);
      heff_take_n(v_it1_249, 1ULL, 1);
      V v_t_2418;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_e1_2412 = heff_dup(heff_field(v_e_240, 0));
        switch (heff_tag_of(v_e1_2412)) {
        case TAG_EApp: {
          V v_h_2414 = heff_field(v_e1_2412, 0);
          V v_xs_2415 = heff_field(v_e1_2412, 1);
          heff_take_n(v_e1_2412, 3ULL, 2);
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            v_t_2418 = heff_rec_n(2, shape_head__args, (V[]){v_h_2414, v_xs_2415});
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2412);
          v_t_2418 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_e_240), NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2419 = heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_2411, v_tsp_2410, heff_get_n(v_t_2418, 1, 2)});
      V v_t_2422;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2421 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_248_24At, TAG_At, 2, (V[]){v_t_2419, v_t_2422});
    }
    default: {
      heff_drop(v_it1_249);
      heff_drop(v_tsp_2410);
      V v_t_2425;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_e_240, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2425});
    }
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantOf(a[0]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_243 = heff_take_field(v_x_241, 0);
    V v_pat_244 = heff_get_n(v_x_241, 2, 3);
    V v_t_2413;
    switch (heff_tag_of(v_binder_243)) {
    case TAG_LamName: {
      V v_x_245 = heff_field(v_binder_243, 0);
      V v_ru_24binder_243_24LamName = heff_take_reuse_n(v_binder_243, 1ULL, 2);
      switch (heff_tag_of(v_pat_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24binder_243_24LamName, 2);
        v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_p_247 = heff_field(v_pat_244, 0);
        heff_take_n(v_pat_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        v_t_2413 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24binder_243_24LamName, v_p_247));
        break;
      }
      default: heff_nomatch(v_pat_244);
      }
      break;
    }
    case TAG_LamImplicit: {
      V v_x_248 = heff_field(v_binder_243, 0);
      heff_take_n(v_binder_243, 1ULL, 2);
      heff_drop(v_pat_244);
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamAnn: {
      V v_x_2410 = heff_field(v_binder_243, 0);
      heff_take_n(v_binder_243, 1ULL, 3);
      heff_drop(v_pat_244);
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_binder_243);
    }
    V v_t_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2413, v_t_2414));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str1, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str2, 50, "a specialisation sets a field by its name: `x = v`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str3, 45, "a specialisation sets fields: `T @ { x = v }`");
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eopL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243, V v_z_244) {
top: ;
  if (heff_strEq_c(heff_get_n(v_op_242, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eopL_str0))) {
    HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(v_a_241));
    V v_m_2438;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_f_248 = v_field_247;
        V v_a_249 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241));
        V v_b_2410 = (g_heff_2esyntax_2ecst_2elastE(v_a_241));
        V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_249, 3, 9), heff_get_n(v_b_2410, 4, 9)});
        v_m_2438 = (g_heff_2esyntax_2esurface_2ebracedL(heff_dup(v_r_240), v_f_248, v_t_2411));
      } else {
        heff_drop(v_field_247);
        switch (heff_tag_of(v_a_241)) {
        case TAG_InstB: {
          V v_o_2412 = heff_field(v_a_241, 0);
          V v_d_2414 = heff_field(v_a_241, 2);
          V v_c_2416 = heff_field(v_a_241, 4);
          heff_take_n(v_a_241, 21ULL, 5);
          V v_m_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_d_2414}));
          v_m_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam0, 1, 1, (V[]){v_m_2417}), heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam1, 2, 2, (V[]){v_o_2412, v_c_2416})}));
          break;
        }
        default: {
          V v_m_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam2, 1, 1, (V[]){v_m_2430});
          break;
        }
        }
      }
    }
    V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_2439)) {
    case TAG_MkPair: {
      V v_x11_2440 = heff_field(v_x1_2439, 0);
      V v_st_2441 = heff_field(v_x1_2439, 1);
      V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
      switch (heff_tag_of(v_x11_2440)) {
      case TAG_Left: {
        V v_e_2442 = heff_field(v_x11_2440, 0);
        V v_ru_24x11_2440_24Left = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2440_24Left, TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
      }
      case TAG_Right: {
        V v_x_2443 = heff_field(v_x11_2440, 0);
        V v_ru_24x11_2440_24Right = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
        V v_m_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
        V v_x1_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_st_2441}));
        switch (heff_tag_of(v_x1_2445)) {
        case TAG_MkPair: {
          V v_x11_2446 = heff_field(v_x1_2445, 0);
          V v_st_2447 = heff_field(v_x1_2445, 1);
          heff_take_n(v_x1_2445, 3ULL, 2);
          switch (heff_tag_of(v_x11_2446)) {
          case TAG_Left: {
            V v_e_2448 = heff_field(v_x11_2446, 0);
            V v_ru_24x11_2446_24Left = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
            heff_drop(v_x_2443);
            heff_drop_cell(v_ru_24x11_2440_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2446_24Left, TAG_Left, 1, (V[]){v_e_2448}), v_st_2447});
          }
          case TAG_Right: {
            V v_x_2449 = heff_field(v_x11_2446, 0);
            heff_take_n(v_x11_2446, 1ULL, 1);
            V v_x_2450 = heff_tr(g_heff_2esyntax_2esurface_2earrowBinop(v_x_2443, v_x_2449));
            return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2440_24Right, TAG_Right, 1, (V[]){v_x_2450}), v_st_2447});
          }
          default: return heff_nomatch(v_x11_2446);
          }
        }
        default: return heff_nomatch(v_x1_2445);
        }
      }
      default: return heff_nomatch(v_x11_2440);
      }
    }
    default: return heff_nomatch(v_x1_2439);
    }
  } else {
    V v_m_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
    V v_x1_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_2452)) {
    case TAG_MkPair: {
      V v_x11_2453 = heff_field(v_x1_2452, 0);
      V v_st_2454 = heff_field(v_x1_2452, 1);
      V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
      switch (heff_tag_of(v_x11_2453)) {
      case TAG_Left: {
        V v_e_2455 = heff_field(v_x11_2453, 0);
        V v_ru_24x11_2453_24Left = heff_take_reuse_n(v_x11_2453, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2453_24Left, TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
      }
      case TAG_Right: {
        V v_x_2456 = heff_field(v_x11_2453, 0);
        V v_ru_24x11_2453_24Right = heff_take_reuse_n(v_x11_2453, 1ULL, 1);
        HeffT2 v_t_2457 = (g_heff_2esyntax_2esurface_2esettingsOf_24cpr(v_b_243));
        {
          V v_field_2459 = v_t_2457.f[1];
          int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
          if ((v_tag_2458 == ((int64_t)0ULL))) {
            heff_drop(v_b_243);
            V v_fs_2460 = v_field_2459;
            V v_m_2462 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam3, 1, 1, (V[]){v_r_240}), v_fs_2460));
            V v_x1_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2454}));
            switch (heff_tag_of(v_x1_2463)) {
            case TAG_MkPair: {
              V v_x11_2464 = heff_field(v_x1_2463, 0);
              V v_st_2465 = heff_field(v_x1_2463, 1);
              heff_take_n(v_x1_2463, 3ULL, 2);
              switch (heff_tag_of(v_x11_2464)) {
              case TAG_Left: {
                V v_e_2466 = heff_field(v_x11_2464, 0);
                V v_ru_24x11_2464_24Left = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
                heff_drop(v_x_2456);
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2464_24Left, TAG_Left, 1, (V[]){v_e_2466}), v_st_2465});
              }
              case TAG_Right: {
                V v_x_2467 = heff_field(v_x11_2464, 0);
                heff_take_n(v_x11_2464, 1ULL, 1);
                V v_x_2468 = (g_list_2efoldl_24s1368043225x413679696(((V)&g_heff_2esyntax_2esurface_2eopL_str2), v_x_2456, v_x_2467));
                return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2453_24Right, TAG_Right, 1, (V[]){v_x_2468}), v_st_2465});
              }
              default: return heff_nomatch(v_x11_2464);
              }
            }
            default: return heff_nomatch(v_x1_2463);
            }
          } else {
            heff_drop(v_field_2459);
            V v_m_2469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
            V v_x1_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_st_2454}));
            switch (heff_tag_of(v_x1_2470)) {
            case TAG_MkPair: {
              V v_x11_2471 = heff_field(v_x1_2470, 0);
              V v_st_2472 = heff_field(v_x1_2470, 1);
              V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
              switch (heff_tag_of(v_x11_2471)) {
              case TAG_Left: {
                V v_e_2473 = heff_field(v_x11_2471, 0);
                V v_ru_24x11_2471_24Left = heff_take_reuse_n(v_x11_2471, 1ULL, 1);
                heff_drop(v_x_2456);
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                heff_drop_cell(v_ru_24x1_2470_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2471_24Left, TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
              }
              case TAG_Right: {
                V v_x_2474 = heff_field(v_x11_2471, 0);
                V v_ru_24x11_2471_24Right = heff_take_reuse_n(v_x11_2471, 1ULL, 1);
                V v_t_2477;
                switch (heff_tag_of(v_x_2456)) {
                case TAG_At: {
                  V v_s_2476 = heff_field(v_x_2456, 1);
                  heff_take_n(v_x_2456, 2ULL, 2);
                  v_t_2477 = v_s_2476;
                  break;
                }
                default: heff_nomatch(v_x_2456);
                }
                V v_t_2480;
                switch (heff_tag_of(v_x_2474)) {
                case TAG_At: {
                  V v_s_2479 = heff_field(v_x_2474, 1);
                  heff_take_n(v_x_2474, 2ULL, 2);
                  v_t_2480 = v_s_2479;
                  break;
                }
                default: heff_nomatch(v_x_2474);
                }
                V v_t_2481 = ({ V rv_1 = heff_get_n(v_t_2480, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2477, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_2482 = heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2471_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eopL_str3)}), v_t_2481});
                return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2453_24Right, TAG_Right, 1, (V[]){v_t_2482}), v_st_2472});
              }
              default: return heff_nomatch(v_x11_2471);
              }
            }
            default: return heff_nomatch(v_x1_2470);
            }
          }
        }
      }
      default: return heff_nomatch(v_x11_2453);
      }
    }
    default: return heff_nomatch(v_x1_2452);
    }
  }
}
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Left = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Left, TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      V v_t_2424 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2423));
      V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2424}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_2419_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2eopL_str1), v_t_2425, v_st_2421));
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args) {
  V v_d_27_2426 = args[0];
  V v_st_2427 = args[1];
  V v_o_2412 = heff_env(self)[0];
  V v_c_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2412, 3, 9), heff_get_n(v_c_2416, 4, 9)});
  V v_t_2429 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Bracketed, 2, (V[]){v_d_27_2426, v_t_2428})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_st_2427});
}
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args) {
  V v_st_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_st_2431}));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_MkPair: {
    V v_x11_2433 = heff_field(v_x1_2432, 0);
    V v_st_2434 = heff_field(v_x1_2432, 1);
    V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
    switch (heff_tag_of(v_x11_2433)) {
    case TAG_Left: {
      V v_e_2435 = heff_field(v_x11_2433, 0);
      V v_ru_24x11_2433_24Left = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Left, TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
    }
    case TAG_Right: {
      V v_x_2436 = heff_field(v_x11_2433, 0);
      V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
      V v_t_2437 = heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2436})});
      return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_st_2434});
    }
    default: return heff_nomatch(v_x11_2433);
    }
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args) {
  V v_m_2461 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_2461));
}
Clo g_heff_2esyntax_2esurface_2etwoToS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etwoToS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etwoToS(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etwoToS(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_entry, 6, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith(V v_r_240, V v_last_241, V v_sp_242, V v_p_243, V v_s_244, V v_z_245) {
top: ;
  V v_x2_246 = heff_tr(g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam0, 1, 2, (V[]){v_x2_246, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam1, 2, 5, (V[]){v_r_240, v_p_243, v_sp_242, v_s_244, heff_dup(v_last_241)}), v_z_245));
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x2_246 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_246) == NTAG(TAG_True))) {
    heff_drop(v_x2_246);
    heff_drop(v_sp_242);
    V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_p_247});
  } else {
    heff_drop(v_x2_246);
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_p_247});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_z_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_last_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_2411}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_s_244);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Left, TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_At: {
        V v_x11_2418 = heff_dup(heff_field(v_x_2417, 0));
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2427 = heff_field(v_x11_2418, 0);
          V v_ru_24x11_2418_24PatInt = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
          v_t_2437 = heff_tag_at_n(v_ru_24x11_2418_24PatInt, TAG_IntValue, 1, (V[]){v_v_2427});
          break;
        }
        case TAG_PatFloat: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2418);
        }
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      HeffT2 v_t_2438 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(NTAG(TAG_True), heff_dup(v_sp_242), v_x_2417, v_t_2437, v_s_244, v_st_2415));
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        V v_x11_2441 = v_field_2439;
        V v_st_2442 = v_field_2440;
        switch (heff_tag_of(v_x11_2441)) {
        case TAG_Left: {
          V v_e_2443 = heff_field(v_x11_2441, 0);
          V v_ru_24x11_2441_24Left = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Left, TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
        }
        case TAG_Right: {
          V v_x_2444 = heff_field(v_x11_2441, 0);
          V v_ru_24x11_2441_24Right = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
          if (!(heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_last_241);
            V v_t_2447;
            switch (heff_tag_of(v_x_2444)) {
            case TAG_At: {
              V v_x_2445 = heff_dup(heff_field(v_x_2444, 0));
              v_t_2447 = v_x_2445;
              break;
            }
            default: heff_nomatch(v_x_2444);
            }
            V v_t_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2447); r_; });
            if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24x11_2414_24Right, 1);
              heff_drop(v_x_2444);
              heff_drop(v_t_2448);
              V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Right, TAG_Left, 1, (V[]){v_t_2449}), v_st_2442});
            } else {
              heff_drop(v_sp_242);
              heff_drop_cell(v_ru_24x11_2441_24Right, 1);
              heff_drop(v_t_2448);
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
            }
          } else {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            heff_drop_cell(v_ru_24x11_2441_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
          }
        }
        default: return heff_nomatch(v_x11_2441);
        }
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    V v_ru_24t_241_24Cons = heff_take_reuse_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2424;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24t_241_24Cons, 2);
      v_t_2424 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24Cons = heff_take_reuse_n(v_t_244, 3ULL, 2);
      V v_text_247 = heff_take_field(v_o_245, 1);
      V v_start_248 = heff_take_field(v_o_245, 3);
      V v_end_249 = heff_get_n(v_o_245, 4, 9);
      V v_t_2410 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24t_241_24Cons, 2);
        heff_drop(v_os_246);
        heff_drop_cell(v_ru_24t_244_24Cons, 2);
        heff_drop(v_text_247);
        heff_drop(v_start_248);
        heff_drop(v_end_249);
        v_t_2424 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_2411 = heff_field(v_t_2410, 0);
        V v_it2_2412 = heff_field(v_t_2410, 1);
        V v_ru_24t_2410_24Cons = heff_take_reuse_n(v_t_2410, 3ULL, 2);
        switch (heff_tag_of(v_it2_2412)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_241_24Cons, 2);
          heff_drop(v_os_246);
          heff_drop_cell(v_ru_24t_244_24Cons, 2);
          heff_drop(v_text_247);
          heff_drop(v_start_248);
          heff_drop(v_end_249);
          heff_drop(v_r_2411);
          heff_drop_cell(v_ru_24t_2410_24Cons, 2);
          v_t_2424 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2413 = heff_field(v_it2_2412, 0);
          V v_rest_2414 = heff_field(v_it2_2412, 1);
          V v_ru_24it2_2412_24Cons = heff_take_reuse_n(v_it2_2412, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_x_2415 = v_text_247;
          V v_xsp_2416 = heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249});
          V v_t_2417 = heff_tag_at_n(v_ru_24t_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_2411), NTAG(TAG_Nil)});
          V v_t_2418 = heff_tag_n(TAG_PatOp, 3, (V[]){v_x_2415, heff_dup(v_xsp_2416), heff_tag_at_n(v_ru_24t_244_24Cons, TAG_Cons, 2, (V[]){v_l_2413, v_t_2417})});
          V v_t_2421;
          switch (heff_tag_of(v_r_2411)) {
          case TAG_At: {
            V v_s_2420 = heff_field(v_r_2411, 1);
            heff_take_n(v_r_2411, 2ULL, 2);
            v_t_2421 = v_s_2420;
            break;
          }
          default: heff_nomatch(v_r_2411);
          }
          V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2423 = heff_tag_at_n(v_ru_24t_2410_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it2_2412_24Cons, TAG_At, 2, (V[]){v_t_2418, v_t_2422}), v_rest_2414});
          v_t_2424 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, v_t_2423});
          break;
        }
        default: heff_nomatch(v_it2_2412);
        }
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2424;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EImplicitVar: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EString: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBinary: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERune: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProject: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENamed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPi: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAnn: {
      V v_x111_2421 = heff_field(v_x11_241, 0);
      V v_t_2422 = heff_field(v_x11_241, 1);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_At: {
        V v_x1111_2423 = heff_field(v_x111_2421, 0);
        V v_xsp_2424 = heff_field(v_x111_2421, 1);
        switch (heff_tag_of(v_x1111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_x1111_2423, 0);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(3, shape_name__span__ty, (V[]){heff_dup(v_x_2425), heff_dup(v_xsp_2424), heff_dup(v_t_2422)})}});
        }
        case TAG_EImplicitVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EString: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERune: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWord: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProject: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ENamed: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPi: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAnn: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESpec: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESig: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESum: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStruct: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EUpdate: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EMatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELetIn: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EDo: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELocal: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInvalid: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAssign: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWhile: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFor: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EIfThen: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBreak: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EContinue: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EReturn: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ENest: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELazy: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETuple: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETry: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWith: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1111_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_2421)}});
      }
    }
    case TAG_ESpec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESig: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESum: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStruct: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUpdate: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EDo: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInvalid: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EIfThen: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELazy: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETuple: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETry: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V v_r_240, V v_kw_241, V v_name_242, V v_params_243, V v_body_244, V v_z_245) {
top: ;
  V v_text_246 = heff_take_field(v_name_242, 1);
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_get_n(v_name_242, 4, 9);
  V v_m_2410 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_243));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    heff_take_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_body_244);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2415)));
      V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2416, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1, 1, 7, (V[]){v_m_2417, v_body_244, v_kw_241, v_text_246, v_start_247, v_end_248, v_x_2415}), v_st_2413));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args) {
  V v_m_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_249));
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  V v_kw_241 = heff_env(self)[2];
  V v_text_246 = heff_env(self)[3];
  V v_start_247 = heff_env(self)[4];
  V v_end_248 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Left = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_x_2415);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Left, TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2424 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_244)));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2426});
      V v_t_2428 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2415, heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2427}), v_x_2423});
      V v_t_2429 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2430 = heff_get_n(v_t_2429, 4, 9);
      V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2430});
      V v_t_2432 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_t_2431})});
      V v_x_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){v_x_2433}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_fields_245, V v_z_246) {
top: ;
  V v_text_247 = heff_take_field(v_name_243, 1);
  V v_start_248 = heff_take_field(v_name_243, 3);
  V v_end_249 = heff_get_n(v_name_243, 4, 9);
  V v_m_2411 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_MkPair: {
    V v_x11_2413 = heff_field(v_x1_2412, 0);
    V v_st_2414 = heff_field(v_x1_2412, 1);
    heff_take_n(v_x1_2412, 3ULL, 2);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_fields_245);
      heff_drop(v_text_247);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      V v_t_2417 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2416)));
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1, 1, 1, (V[]){v_r_240}), v_fields_245}));
      V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){v_t_2430, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3, 2, 6, (V[]){v_d_241, v_kw_242, v_text_247, v_start_248, v_end_249, v_x_2416})}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2417, v_t_2444, v_st_2414));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2412)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_2410));
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_e_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args) {
  V v_f_2418 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2418)) {
  case TAG_MkTF: {
    V v_xs_2419 = heff_field(v_f_2418, 0);
    V v_ty_2422 = heff_field(v_f_2418, 3);
    V v_d_2423 = heff_field(v_f_2418, 4);
    heff_take_n(v_f_2418, 25ULL, 5);
    V v_t_2424 = (g_list_2emap_24s146946949x1862800301(heff_dup(v_xs_2419)));
    HeffT2 v_t_2425 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2424));
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_xs_2419);
        heff_drop(v_ty_2422);
        heff_drop(v_d_2423);
        V v_e_2428 = v_field_2427;
        return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2, 1, 1, (V[]){v_e_2428});
      } else {
        heff_drop(v_field_2427);
        return (g_prelude_2etraverse_24s430827533x596660821(v_r_240, v_ty_2422, v_d_2423, v_xs_2419));
      }
    }
  }
  default: return heff_nomatch(v_f_2418);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam3(V self, V *args) {
  V v_fields_27_2431 = args[0];
  V v_z_2432 = args[1];
  V v_d_241 = heff_env(self)[0];
  V v_kw_242 = heff_env(self)[1];
  V v_text_247 = heff_env(self)[2];
  V v_start_248 = heff_env(self)[3];
  V v_end_249 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2433 = ({ V a_0 = v_fields_27_2431; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_fields_27_2431); r_; });
  V v_t_2434 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
  V v_e_2435 = heff_get_n(v_t_2434, 4, 9);
  V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2435});
  V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_t_2433}), v_t_2436});
  V v_t_2438 = heff_tag_n(TAG_DeclTheory, 4, (V[]){v_text_247, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249}), v_x_2416, v_t_2437});
  V v_t_2439 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
  V v_e_2440 = heff_get_n(v_t_2439, 4, 9);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2440});
  V v_t_2442 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_t_2441})});
  V v_x_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2443}), v_z_2432});
}

HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DImport: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DFixity: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DSig: {
      V v_names_246 = heff_field(v_x11_241, 0);
      V v_t_2412;
      switch (heff_tag_of(v_names_246)) {
      case TAG_Nil: {
        v_t_2412 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_names_246, 0);
        v_t_2412 = heff_dup(v_x_2410);
        break;
      }
      default: heff_nomatch(v_names_246);
      }
      V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2edeclNameOf(a_0)); heff_drop(v_t_2412); r_; });
      V v_f_2414 = heff_get_n(v_t_2413, 0, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
    }
    case TAG_DInstance: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DEqn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DData: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DType: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DTheory: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DMutual: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DPrimitive: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DTest: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_DWatch: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V v_r_240, V v_d_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    V v_ru_24d_241_24DImport = heff_take_reuse_n(v_d_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_244 = heff_tag_at_n(v_ru_24d_241_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_244, v_z_242}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_247, v_z_242}});
  }
  case TAG_DSig: {
    V v_names_248 = heff_field(v_d_241, 0);
    V v_ty_2411 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 9ULL, 4);
    V v_r_2412 = v_r_240;
    V v_declared_2413 = NTAG(TAG_AsDefinition);
    V v_start_2418;
    switch (heff_tag_of(v_names_248)) {
    case TAG_Nil: {
      v_start_2418 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_dup(heff_field(v_names_248, 0));
      switch (heff_tag_of(v_x_2414)) {
      case TAG_Nil: {
        v_start_2418 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_t_2416 = heff_field(v_x_2414, 0);
        heff_take_n(v_x_2414, 1ULL, 2);
        v_start_2418 = heff_get_n(v_t_2416, 3, 9);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      break;
    }
    default: heff_nomatch(v_names_248);
    }
    V v_names_2419 = v_names_248;
    V v_ty_2420 = v_ty_2411;
    V v_t_2421 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_2419)));
    HeffT2 v_t_2422 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2421));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop_rec(v_r_2412, 3);
        heff_drop(v_start_2418);
        heff_drop(v_names_2419);
        heff_drop(v_ty_2420);
        V v_d_2425 = v_field_2424;
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2425}), v_z_242}});
      } else {
        heff_drop(v_field_2424);
        V v_m_2426 = heff_tr(heff_call(heff_get_n(v_r_2412, 0, 3), 1, (V[]){heff_dup(v_ty_2420)}));
        V v_x1_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2427)) {
        case TAG_MkPair: {
          V v_x11_2428 = heff_field(v_x1_2427, 0);
          V v_st_2429 = heff_field(v_x1_2427, 1);
          heff_take_n(v_x1_2427, 3ULL, 2);
          switch (heff_tag_of(v_x11_2428)) {
          case TAG_Left: {
            V v_e_2430 = heff_field(v_x11_2428, 0);
            V v_ru_24x11_2428_24Left = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
            heff_drop(v_start_2418);
            heff_drop(v_names_2419);
            heff_drop(v_ty_2420);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2428_24Left, TAG_Left, 1, (V[]){v_e_2430}), v_st_2429}});
          }
          case TAG_Right: {
            V v_x_2431 = heff_field(v_x11_2428, 0);
            V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
            V v_t_2432 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_2419)));
            V v_st_2433 = ({ V a_0 = heff_dup(v_x_2431); V a_1 = v_st_2429; V a_2 = v_t_2432; V r_ = (g_list_2efoldl_24s1389405036x1664963487(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
            V v_t_2434 = (g_heff_2esyntax_2ecst_2elastE(v_ty_2420));
            V v_b_2435 = heff_get_n(v_t_2434, 4, 9);
            V v_x_2436 = (g_list_2emap_24f2041933216x1458595349(v_declared_2413, v_x_2431, v_start_2418, v_b_2435, v_names_2419));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){v_x_2436}), v_st_2433}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2428)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2427)}});
        }
      }
    }
  }
  case TAG_DInstance: {
    V v_kw_2437 = heff_field(v_d_241, 0);
    V v_names_2438 = heff_field(v_d_241, 1);
    V v_ty_2440 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    V v_lit_2441 = v_names_2438;
    V v_r_2442 = v_r_240;
    V v_declared_2443 = NTAG(TAG_AsInstance);
    V v_start_2444 = heff_get_n(v_kw_2437, 3, 9);
    V v_ty_2445 = v_ty_2440;
    HeffT2 v_t_2446 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_lit_2441));
    {
      V v_field_2447 = v_t_2446.f[0];
      heff_drop(v_t_2446.f[1]);
      V v_p_2449 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_field_2447}));
      heff_drop(v_p_2449);
      V v_m_2450 = heff_tr(heff_call(heff_get_n(v_r_2442, 0, 3), 1, (V[]){heff_dup(v_ty_2445)}));
      V v_x1_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2451)) {
      case TAG_MkPair: {
        V v_x11_2452 = heff_field(v_x1_2451, 0);
        V v_st_2453 = heff_field(v_x1_2451, 1);
        V v_ru_24x1_2451_24MkPair = heff_take_reuse_n(v_x1_2451, 3ULL, 2);
        switch (heff_tag_of(v_x11_2452)) {
        case TAG_Left: {
          V v_e_2454 = heff_field(v_x11_2452, 0);
          V v_ru_24x11_2452_24Left = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
          heff_drop(v_lit_2441);
          heff_drop(v_start_2444);
          heff_drop(v_ty_2445);
          heff_drop_cell(v_ru_24x1_2451_24MkPair, 2);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2452_24Left, TAG_Left, 1, (V[]){v_e_2454}), v_st_2453}});
        }
        case TAG_Right: {
          V v_x_2455 = heff_field(v_x11_2452, 0);
          V v_ru_24x11_2452_24Right = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
          V v_t_2456 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_lit_2441));
          V v_z_2457 = (g_heff_2esyntax_2esurface_2esigBinders(heff_dup(v_x_2455), v_st_2453, v_t_2456));
          V v_t_2458 = (g_heff_2esyntax_2ecst_2elastE(v_ty_2445));
          V v_b_2459 = heff_get_n(v_t_2458, 4, 9);
          HeffT2 v_t_2460 = ({ V a_0 = v_lit_2441; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(a_0)); heff_drop(v_lit_2441); r_; });
          {
            V v_field_2461 = v_t_2460.f[0];
            V v_field_2462 = v_t_2460.f[1];
            V v_t_2463 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_2443, v_field_2461, v_field_2462, v_x_2455, heff_rec_n(2, shape_start__end, (V[]){v_start_2444, v_b_2459})});
            V v_t_2464 = heff_tag_at_n(v_ru_24x1_2451_24MkPair, TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2452_24Right, TAG_Right, 1, (V[]){v_t_2464}), v_z_2457}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2452)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2451)}});
      }
    }
  }
  case TAG_DEqn: {
    V v_names_2465 = heff_field(v_d_241, 0);
    V v_pats_2466 = heff_field(v_d_241, 1);
    V v_rhs_2468 = heff_field(v_d_241, 3);
    V v_w_2469 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 27ULL, 5);
    return ({ V a_0 = v_r_240; V a_1 = v_names_2465; V a_2 = v_pats_2466; V a_3 = v_rhs_2468; V a_4 = v_w_2469; V a_5 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_names_2465); heff_drop(v_w_2469); r_; });
  }
  case TAG_DData: {
    V v_kw_2470 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2471 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2472 = heff_dup(heff_field(v_d_241, 2));
    V v_universe_2473 = heff_dup(heff_field(v_d_241, 3));
    V v_alts_2474 = heff_dup(heff_field(v_d_241, 4));
    return ({ V a_0 = v_r_240; V a_1 = v_d_241; V a_2 = v_kw_2470; V a_3 = v_name_2471; V a_4 = v_params_2472; V a_5 = v_universe_2473; V a_6 = v_alts_2474; V a_7 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_universe_2473); heff_drop(v_alts_2474); r_; });
  }
  case TAG_DType: {
    V v_kw_2475 = heff_field(v_d_241, 0);
    V v_name_2476 = heff_field(v_d_241, 1);
    V v_params_2477 = heff_field(v_d_241, 2);
    V v_body_2479 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24cpr(v_r_240, v_kw_2475, v_name_2476, v_params_2477, v_body_2479, v_z_242));
  }
  case TAG_DTheory: {
    V v_kw_2480 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2481 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2482 = heff_dup(heff_field(v_d_241, 2));
    V v_fields_2484 = heff_dup(heff_field(v_d_241, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24cpr(v_r_240, v_d_241, v_kw_2480, v_name_2481, v_params_2482, v_fields_2484, v_z_242));
  }
  case TAG_DMutual: {
    V v_kw_2485 = heff_field(v_d_241, 0);
    V v_ds_2486 = heff_field(v_d_241, 1);
    heff_take_n(v_d_241, 3ULL, 2);
    return (g_heff_2esyntax_2esurface_2emutualL_24cpr(v_r_240, v_kw_2485, v_ds_2486, v_z_242));
  }
  case TAG_DPrimitive: {
    V v_kw_2487 = heff_field(v_d_241, 0);
    V v_x_2488 = heff_field(v_d_241, 1);
    V v_ty_2490 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    V v_r_2491 = v_r_240;
    V v_kw_2492 = v_kw_2487;
    V v_x_2493 = v_x_2488;
    V v_text_2494 = heff_take_field(v_x_2493, 1);
    V v_start_2495 = heff_take_field(v_x_2493, 3);
    V v_end_2496 = heff_get_n(v_x_2493, 4, 9);
    V v_ty_2497 = v_ty_2490;
    V v_m_2498 = heff_tr(heff_call(heff_get_n(v_r_2491, 0, 3), 1, (V[]){heff_dup(v_ty_2497)}));
    V v_x1_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_MkPair: {
      V v_x11_24100 = heff_field(v_x1_2499, 0);
      V v_st_24101 = heff_field(v_x1_2499, 1);
      V v_ru_24x1_2499_24MkPair = heff_take_reuse_n(v_x1_2499, 3ULL, 2);
      switch (heff_tag_of(v_x11_24100)) {
      case TAG_Left: {
        V v_e_24102 = heff_field(v_x11_24100, 0);
        V v_ru_24x11_24100_24Left = heff_take_reuse_n(v_x11_24100, 1ULL, 1);
        heff_drop_rec(v_kw_2492, 9);
        heff_drop(v_text_2494);
        heff_drop(v_start_2495);
        heff_drop(v_end_2496);
        heff_drop(v_ty_2497);
        heff_drop_cell(v_ru_24x1_2499_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_24100_24Left, TAG_Left, 1, (V[]){v_e_24102}), v_st_24101}});
      }
      case TAG_Right: {
        V v_x_24103 = heff_field(v_x11_24100, 0);
        V v_ru_24x11_24100_24Right = heff_take_reuse_n(v_x11_24100, 1ULL, 1);
        V v_t_24104 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){v_text_2494, heff_rec_n(2, shape_start__end, (V[]){v_start_2495, v_end_2496}), v_x_24103});
        V v_t_24105 = (g_heff_2esyntax_2ecst_2elastE(v_ty_2497));
        V v_e_24106 = heff_get_n(v_t_24105, 4, 9);
        V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2492, 3, 9), v_e_24106});
        V v_t_24108 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_2499_24MkPair, TAG_At, 2, (V[]){v_t_24104, v_t_24107})});
        V v_x_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_24100_24Right, TAG_Right, 1, (V[]){v_x_24109}), v_st_24101}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_24100)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2499)}});
    }
  }
  case TAG_DTest: {
    V v_kw_24110 = heff_field(v_d_241, 0);
    V v_x_24111 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DTest = heff_take_reuse_n(v_d_241, 3ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_text_24112 = heff_take_field(v_x_24111, 1);
    V v_start_24113 = heff_take_field(v_x_24111, 3);
    V v_end_24114 = heff_get_n(v_x_24111, 4, 9);
    V v_t_24115 = heff_tag_at_n(v_ru_24d_241_24DTest, TAG_DeclTest, 2, (V[]){v_text_24112, heff_rec_n(2, shape_start__end, (V[]){v_start_24113, heff_dup(v_end_24114)})});
    V v_t_24116 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24110, 3, 9), v_end_24114});
    V v_t_24117 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24115, v_t_24116})});
    V v_t_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
    V v_f_24119 = heff_tag_n(TAG_Right, 1, (V[]){v_t_24118});
    return ((HeffT2){{v_f_24119, v_z_242}});
  }
  case TAG_DWatch: {
    V v_w_24120 = heff_field(v_d_241, 0);
    V v_e_24121 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DWatch = heff_take_reuse_n(v_d_241, 3ULL, 2);
    V v_start_24122 = heff_take_field(v_w_24120, 3);
    V v_kind_24123 = heff_get_n(v_w_24120, 0, 9);
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24121)}));
    V v_x1_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24125)) {
    case TAG_MkPair: {
      V v_x11_24126 = heff_field(v_x1_24125, 0);
      V v_st_24127 = heff_field(v_x1_24125, 1);
      V v_ru_24x1_24125_24MkPair = heff_take_reuse_n(v_x1_24125, 3ULL, 2);
      switch (heff_tag_of(v_x11_24126)) {
      case TAG_Left: {
        V v_e_24128 = heff_field(v_x11_24126, 0);
        V v_ru_24x11_24126_24Left = heff_take_reuse_n(v_x11_24126, 1ULL, 1);
        heff_drop(v_e_24121);
        heff_drop_cell(v_ru_24d_241_24DWatch, 2);
        heff_drop(v_start_24122);
        heff_drop(v_kind_24123);
        heff_drop_cell(v_ru_24x1_24125_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_24126_24Left, TAG_Left, 1, (V[]){v_e_24128}), v_st_24127}});
      }
      case TAG_Right: {
        V v_x_24129 = heff_field(v_x11_24126, 0);
        V v_ru_24x11_24126_24Right = heff_take_reuse_n(v_x11_24126, 1ULL, 1);
        V v_t_24130 = (g_heff_2esyntax_2ecst_2elastE(v_e_24121));
        V v_e_24131 = heff_get_n(v_t_24130, 4, 9);
        V v_d_24132 = heff_tag_at_n(v_ru_24d_241_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_24129}), heff_rec_n(2, shape_start__end, (V[]){v_start_24122, v_e_24131})});
        V v_t_24133;
        if (heff_strEq_c(v_kind_24123, ((V)&g_heff_2esyntax_2esurface_2edeclL_24cpr_str0))) {
          v_t_24133 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_24132});
        } else {
          v_t_24133 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_24132});
        }
        V v_x_24134 = heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_24126_24Right, TAG_Right, 1, (V[]){v_x_24134}), v_st_24127}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_24126)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_24125)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_241)}});
  }
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam0, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam1, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam2, 2, 0};

static V g_heff_2esyntax_2esurface_2elw_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2elw_st;
static V g_heff_2esyntax_2esurface_2elw_init(void) {
  return heff_rec_n(3, shape_e__pat__decl, (V[]){((V)&g_heff_2esyntax_2esurface_2elw_lam0_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam1_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam2_clo)});
}
V g_heff_2esyntax_2esurface_2elw_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2elw_st)) return g_heff_2esyntax_2esurface_2elw_val;
  return heff_global(&g_heff_2esyntax_2esurface_2elw_val, &g_heff_2esyntax_2esurface_2elw_st, g_heff_2esyntax_2esurface_2elw_init);
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_st_241 = args[1];
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_241));
}
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args) {
  V v_p_242 = args[0];
  V v_st_243 = args[1];
  return (g_heff_2esyntax_2esurface_2epatL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_p_242, v_st_243));
}
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args) {
  V v_d_244 = args[0];
  V v_st_245 = args[1];
  return (g_heff_2esyntax_2esurface_2edeclL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_244, v_st_245));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str4, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str5, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str7, 1, ",");
HEFF_LIT(g_heff_2esyntax_2esurface_2esigNamesFrom_str8, 1, ")");
Clo g_heff_2esyntax_2esurface_2esigNamesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigNamesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2esigNamesFrom(V v_ts_240, V v_box_24k_241, V v_acc_242) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if (((((int64_t)0ULL) <= v_k_241) && (v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_243 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_k_241), 2);
    V v_text_244 = heff_take_field(v_t_243, 1);
    V v_kind_245 = heff_get_n(v_t_243, 0, 7);
    int64_t v_i_246 = (v_k_241 + ((int64_t)1ULL));
    if (((((int64_t)0ULL) <= v_i_246) && (v_i_246 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_u_247 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_246), 2);
      V v_kind_248 = heff_take_field(v_u_247, 0);
      V v_text_249 = heff_get_n(v_u_247, 1, 7);
      if (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str0), 2)) {
        heff_drop(v_text_244);
        heff_drop(v_kind_245);
        heff_drop(v_kind_248);
        heff_drop(v_text_249);
        V t_0 = v_ts_240;
        int64_t t_1 = (v_k_241 + ((int64_t)2ULL));
        V t_2 = v_acc_242;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str1), 2) ? 0 : (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str2), 2) ? 0 : !heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str3), 2)))) {
          heff_drop(v_acc_242);
          heff_drop(v_text_244);
          heff_drop(v_kind_245);
          heff_drop(v_kind_248);
          heff_drop(v_text_249);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_kind_245);
          if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str4), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str5), 2))) {
            heff_drop(v_kind_248);
            heff_drop(v_text_249);
            if (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str6), 2)) {
              heff_drop(v_text_244);
              return v_acc_242;
            } else {
              return heff_tag_n(TAG_Cons, 2, (V[]){v_text_244, v_acc_242});
            }
          } else {
            heff_drop(v_kind_248);
            if (heff_strEq_c(v_text_249, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str7))) {
              V v_t_2410;
              if (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2esurface_2esigNamesFrom_str8), 2)) {
                heff_drop(v_text_244);
                v_t_2410 = v_acc_242;
              } else {
                v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_244, v_acc_242});
              }
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)2ULL));
              V t_2 = v_t_2410;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            } else {
              heff_drop(v_acc_242);
              heff_drop(v_text_244);
              return NTAG(TAG_Nil);
            }
          }
        }
      }
    } else {
      heff_drop(v_acc_242);
      heff_drop(v_text_244);
      heff_drop(v_kind_245);
      return NTAG(TAG_Nil);
    }
  } else {
    heff_drop(v_acc_242);
    return NTAG(TAG_Nil);
  }
}
V g_heff_2esyntax_2esurface_2esigNamesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esigNamesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_u_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_242, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_rest_243;
      V t_1 = v_cell_244;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_u_242, 7);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupOfDecl_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupOfDecl(V v_place_240, V v_d_241) {
top: ;
  V v_ops_242 = heff_take_field(v_d_241, 1);
  V v_assoc_243 = heff_take_field(v_d_241, 0);
  V v_loosest_244 = heff_take_field(v_d_241, 4);
  V v_line_245 = heff_get_n(v_d_241, 7, 8);
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    heff_drop(v_place_240);
    heff_drop(v_assoc_243);
    heff_drop(v_loosest_244);
    heff_drop(v_line_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_op_246 = heff_dup(heff_field(v_ops_242, 0));
    V v_t_248 = (g_list_2emap_24s1006818869x590968200(v_ops_242));
    V v_t_2410;
    if (heff_strEq_c_lent(v_place_240, ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str0), 2)) {
      heff_drop(v_place_240);
      heff_drop(v_line_245);
      v_t_2410 = ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str1);
    } else {
      V v_t_249 = heff_intShow(heff_intAdd(v_line_245, MK_INT(1LL)));
      v_t_2410 = heff_strAppend(heff_strAppend(v_place_240, ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str2)), v_t_249);
    }
    V v_t_2411 = heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){heff_get_n(v_op_246, 1, 7), v_assoc_243, v_t_248, v_loosest_244, v_t_2410});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2egroupOfDecl(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2esyntax_2esurface_2efixDiagsOf(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_x_243)));
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_lit_240, v_lit_241, v_xs_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V v_kw_240, V v_name_241, V v_params_242, V v_body_243, V v_z_244) {
top: ;
  V v_text_245 = heff_take_field(v_name_241, 1);
  V v_start_246 = heff_take_field(v_name_241, 3);
  V v_end_247 = heff_get_n(v_name_241, 4, 9);
  V v_m_248 = (g_prelude_2etraverse_24s518454301x170091462(v_params_242));
  V v_x1_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_body_243);
      heff_drop(v_text_245);
      heff_drop(v_start_246);
      heff_drop(v_end_247);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2413)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2414, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0, 1, 6, (V[]){v_body_243, v_kw_240, v_text_245, v_start_246, v_end_247, v_x_2413}), v_st_2411));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0(V self, V *args) {
  V v_st_2415 = args[0];
  V v_body_243 = heff_env(self)[0];
  V v_kw_240 = heff_env(self)[1];
  V v_text_245 = heff_env(self)[2];
  V v_start_246 = heff_env(self)[3];
  V v_end_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2416 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_body_243), v_st_2415));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
      heff_drop(v_body_243);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_text_245);
      heff_drop(v_start_246);
      heff_drop(v_end_247);
      heff_drop(v_x_2413);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
      V v_t_2421 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2422 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_243)));
      V v_e_2423 = heff_get_n(v_t_2422, 4, 9);
      V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_240, 3)), v_e_2423});
      V v_t_2425 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), v_x_2413, heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2424}), v_x_2420});
      V v_t_2426 = (g_heff_2esyntax_2ecst_2elastE(v_body_243));
      V v_e_2427 = heff_get_n(v_t_2426, 4, 9);
      V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2427});
      V v_t_2429 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2428})});
      V v_x_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_Right, 1, (V[]){v_x_2430}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str3, 1, ":");
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadRun_entry, 6, 0};

V g_heff_2esyntax_2esurface_2ereadRun(V v_src_240, V v_o_241, V v_toks_242, V v_lexDiags_243, V v_declared_244, V v_own_245) {
top: ;
  V v_path_246 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_o_248 = heff_dup(v_o_241);
  V v_fixities_249 = heff_take_field(v_o_248, 1);
  V v_lenient_2410 = heff_take_field(v_o_248, 2);
  V v_known_2411 = heff_get_n(v_o_248, 0, 5);
  V v_path_2412 = heff_get_n(v_o_241, 4, 5);
  V v_at_2415 = heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam0, 1, 2, (V[]){v_path_2412, heff_dup(v_src_240)});
  V v_toks_2416 = heff_dup(v_toks_242);
  V v_declared_2417 = v_declared_244;
  V v_own_2418 = heff_dup(heff_rfield(v_own_245, 0));
  V v_groups_2419 = heff_take_field(v_own_2418, 0);
  V v_above_2420 = heff_get_n(v_own_2418, 1, 2);
  V v_declared_2421 = ({ V a_0 = v_declared_2417; V r_ = (g_heff_2esyntax_2esurface_2enameSet(a_0)); heff_drop(v_declared_2417); r_; });
  V v_a_2422 = v_fixities_249;
  V v_groups_2423 = heff_take_field(v_a_2422, 0);
  V v_above_2424 = heff_get_n(v_a_2422, 1, 2);
  V v_t_2425 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_2423, v_groups_2419));
  V v_t_2426 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2425));
  V v_t_2427 = (g_heff_2esyntax_2efixity_2eappendF(v_above_2424, v_above_2420));
  V v_t_2428 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2427));
  V v_fix_2429 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2426, v_t_2428});
  V v_lenient_2430 = v_lenient_2410;
  V v_t_2437 = heff_rec_n(10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, (V[]){v_toks_2416, NTAG(TAG_Nil), heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam1, 1, 2, (V[]){v_known_2411, v_declared_2421}), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), v_fix_2429, v_lenient_2430, v_at_2415, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
  V v_r_2438 = (g_heff_2esyntax_2esurface_2eprogGo(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_242, MK_INT(0LL), MK_INT(0LL), v_t_247, MK_INT(0LL)}), v_t_2437, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_src_2439 = heff_dup(v_src_240);
  V v_items_2440 = heff_dup(heff_rfield(v_r_2438, 0));
  V v_t_2441 = heff_rec_n(3, shape_items__waiting__diags, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_p_2444 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam2, 2, 1, (V[]){v_src_2439}); V a_1 = v_t_2441; V a_2 = v_items_2440; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2440); r_; });
  V v_items_2445 = heff_take_field(v_p_2444, 0);
  V v_waiting_2446 = heff_take_field(v_p_2444, 1);
  V v_diags_2447 = heff_get_n(v_p_2444, 2, 3);
  V v_items_2448 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_items_2445, heff_dup(v_waiting_2446)));
  V v_diags_2449 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(v_diags_2447, v_waiting_2446));
  V v_t_2450 = heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2448, NTAG(TAG_Nil), v_diags_2449});
  return (g_heff_2esyntax_2esurface_2ereadPlaced(heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam3, 1, 2, (V[]){v_path_246, v_src_240}), v_lexDiags_243, v_own_245, v_r_2438, v_t_2450));
}
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadRun(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args) {
  V v_i_2413 = args[0];
  V v_path_2412 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_2412, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str0), 2)) {
    heff_drop(v_path_2412);
    return ({ V a_0 = v_src_240; V a_1 = v_i_2413; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
  } else {
    V v_t_2414 = ({ V a_0 = v_src_240; V a_1 = v_i_2413; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
    return heff_strAppend(heff_strAppend(v_path_2412, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str1)), v_t_2414);
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_known_2411 = heff_env(self)[0];
  V v_declared_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_known_2411, 1, (V[]){heff_dup(v_x_2431)}));
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    heff_drop(v_declared_2421);
    heff_drop(v_t_2432);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2432);
    HeffT2 v_t_2433 = ({ V a_0 = v_declared_2421; V a_1 = v_x_2431; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_declared_2421); heff_drop(v_x_2431); r_; });
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2434 == ((int64_t)0ULL)) && ({ V v_x_2436 = heff_dup(v_field_2435); int c_ = 1; heff_drop(v_x_2436); c_; })));
      heff_drop(v_field_2435);
      return v_ret_24bool;
    }
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_lam2(V self, V *args) {
  V v_p_2442 = args[0];
  V v_it_2443 = args[1];
  V v_src_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_src_2439; V a_1 = v_p_2442; V a_2 = v_it_2443; V r_ = (g_heff_2esyntax_2esurface_2eplaceStep(a_0, a_1, a_2)); heff_drop(v_src_2439); r_; });
}
V g_heff_2esyntax_2esurface_2ereadRun_lam3(V self, V *args) {
  V v_i_2451 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_246, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str2), 2)) {
    heff_drop(v_path_246);
    return ({ V a_0 = v_src_240; V a_1 = v_i_2451; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
  } else {
    V v_t_2452 = ({ V a_0 = v_src_240; V a_1 = v_i_2451; V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
    return heff_strAppend(heff_strAppend(v_path_246, ((V)&g_heff_2esyntax_2esurface_2ereadRun_str3)), v_t_2452);
  }
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ereadLexed(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  V v_tokens_243 = heff_take_field(v_l_242, 0);
  V v_errors_244 = heff_get_n(v_l_242, 1, 3);
  V v_ltoks_245 = heff_arrayFromList(heff_dup(v_tokens_243));
  V v_t_246 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_tokens_243));
  V v_toks_247 = heff_arrayFromList(v_t_246);
  V v_lexDiags_248 = (g_list_2emap_24s338694954x1326523169(v_errors_244));
  V v_t_249 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_245, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2efixDecls(v_ltoks_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2efixityFrom(heff_dup(heff_rfield(v_o_241, 3)), heff_dup(heff_rfield(v_o_241, 1)), v_t_2410));
  return (g_heff_2esyntax_2esurface_2ereadRun(v_src_240, v_o_241, v_toks_247, v_lexDiags_248, v_t_249, v_t_2411));
}
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadLexed(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V v_place_240, V v_decls_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s2053104128x1598844325(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_241)));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0, 1, 1, (V[]){v_place_240}), v_t_242));
  V v_groups_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_247 = heff_rec_n(2, shape_groups__above, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_edges_248 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_t_247, v_decls_241));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_2410 = heff_rec_n(2, shape_groups__above, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(heff_dup(v_edges_248)));
  V v_t_2413 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2411, v_t_2412});
  V v_t_2414 = ({ V a_0 = v_t_2410; V a_1 = v_t_2413; V a_2 = v_decls_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a_0, a_1, a_2)); heff_drop(v_decls_241); r_; });
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_245, v_edges_248}), v_t_2414});
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_243));
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry, 3, 0};

V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V v_tok_240, V v_e_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EAnn: {
      V v_g_245 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EAnn = heff_take_reuse_n(v_e1_243, 1ULL, 2);
      V v_g_247 = v_g_245;
      V v_t_2414;
      switch (heff_tag_of(v_g_247)) {
      case TAG_At: {
        V v_e1_248 = heff_dup(heff_field(v_g_247, 0));
        switch (heff_tag_of(v_e1_248)) {
        case TAG_EApp: {
          V v_h_2410 = heff_field(v_e1_248, 0);
          V v_xs_2411 = heff_field(v_e1_248, 1);
          heff_take_n(v_e1_248, 3ULL, 2);
          switch (heff_tag_of(v_g_247)) {
          case TAG_At: {
            v_t_2414 = heff_rec_n(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
            break;
          }
          default: heff_nomatch(v_g_247);
          }
          break;
        }
        default: {
          heff_drop(v_e1_248);
          v_t_2414 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_247), NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_247);
      }
      V v_t_2415 = heff_get_n(v_t_2414, 0, 2);
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_t_2415); r_; });
      V v_t_2423;
      switch (heff_tag_of(v_g_247)) {
      case TAG_At: {
        V v_e1_2417 = heff_dup(heff_field(v_g_247, 0));
        switch (heff_tag_of(v_e1_2417)) {
        case TAG_EApp: {
          V v_h_2419 = heff_field(v_e1_2417, 0);
          V v_xs_2420 = heff_field(v_e1_2417, 1);
          heff_take_n(v_e1_2417, 3ULL, 2);
          switch (heff_tag_of(v_g_247)) {
          case TAG_At: {
            heff_take_n(v_g_247, 0ULL, 2);
            v_t_2423 = heff_rec_n(2, shape_head__args, (V[]){v_h_2419, v_xs_2420});
            break;
          }
          default: heff_nomatch(v_g_247);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2417);
          v_t_2423 = heff_rec_n(2, shape_head__args, (V[]){v_g_247, NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_247);
      }
      V v_t_2424 = (g_list_2emap_24s878634257x1677201747(heff_get_n(v_t_2423, 1, 2)));
      V v_t_2425 = (g_heff_2esyntax_2esurface_2ecatMaybesS(heff_tag_at_n(v_ru_24e1_243_24EAnn, TAG_Cons, 2, (V[]){v_t_2416, v_t_2424})));
      V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2425, heff_dup(heff_rfield(v_p_242, 1))));
      V v_st_2427 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2426, v_p_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Right, 1, (V[]){v_e_241}), v_st_2427});
    }
    default: {
      heff_drop(v_e1_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Right, 1, (V[]){v_e_241}), v_p_242});
    }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn_24tok1(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_24tok2_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V v_tok_240, V v_p_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_p_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_q_246 = v_field_245;
      V v_name_247 = heff_take_field(v_q_246, 0);
      V v_span_248 = heff_take_field(v_q_246, 1);
      V v_ty_249 = heff_get_n(v_q_246, 2, 3);
      V v_t_2412;
      switch (heff_tag_of(v_ty_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_ty_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_ty_249);
      }
      V v_t_2413 = ({ V rv_0 = heff_dup(heff_rfield(v_span_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2414 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_247, v_span_248, v_ty_249}), v_t_2413});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2414}), v_z_242});
    } else {
      heff_drop(v_field_245);
      V v_t_2417;
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_p_241, 1);
        v_t_2417 = heff_dup(v_s_2416);
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_24tok2_str0), v_t_2417, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_z_242});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparamOf_24tok2(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2evarAtom_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry, 4, 0};

V g_heff_2esyntax_2esurface_2evarAtom_24tok1(V v_tok_240, V v_t_241, V v_fs_242, V v_st_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_241, 1))}));
  V v_t_245 = (g_list_2eany(v_t_244, heff_rfield(v_st_243, 1)));
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_243, 8), heff_rfield(v_t_241, 1)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_x_2421;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_k_249 = v_field_248;
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_t_245);
        heff_drop(v_k_249);
        V v_e_2410 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_241));
        V v_t_2411 = (g_list_2emap_24s513201124x806973253(v_fs_242));
        v_x_2421 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2410, v_t_2411));
      } else {
        heff_drop(v_t_245);
        V v_t_2412 = heff_intAdd(heff_dup(heff_rfield(v_t_241, 3)), heff_strLength_lent(v_k_249, 0));
        V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_241, 3)), heff_intAdd(v_t_2412, MK_INT(2LL))});
        V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EVar, 1, (V[]){v_k_249}), v_t_2413});
        V v_t_2415 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_t_241, 1)});
        V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
        V v_t_2417 = (g_list_2emap_24s513201124x806973253(v_fs_242));
        V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416}), v_t_2417});
        v_x_2421 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2418));
      }
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_t_245);
      heff_drop(v_field_248);
      V v_e_2419 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_241));
      V v_t_2420 = (g_list_2emap_24s513201124x806973253(v_fs_242));
      v_x_2421 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2419, v_t_2420));
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_243});
  }
}
V g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evarAtom_24tok1(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V v_tok_240, V v_xs_241, V v_p_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_241, v_p_242, v_st_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope_24tok2(a[0], a[1], a[2], a[3]);
}