// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclDefine 5286
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_f 320
#define LBL_fixities 357800079
#define LBL_head 9693863
#define LBL_i 323
#define LBL_implicits 1321238867
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_path 9928940
#define LBL_prims 308293287
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_waiting 1348170899
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_name__span__ty[] = {LBL_name, LBL_span, LBL_ty};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eabAbove(V, V, V);
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabAbove_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2eplaceDocs(V, V);
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
HeffT4 g_heff_2esyntax_2esurface_2ereadLexed_24cpr(V, V, V);
HeffT4 g_heff_2esyntax_2esurface_2ereadPlaced_24cpr(V, V, V, V, V);
HeffT4 g_heff_2esyntax_2esurface_2ereadRun_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2esigL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_heff_2esyntax_2esurface_2etraverseS(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2esurface_2epiBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiBinders_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_b_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      V v_t_2432;
      switch (heff_tag_of(v_b_2417)) {
      case TAG_PiNamed: {
        V v_x_2419 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 3);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 5);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 4);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2417);
      }
      V v_t_2433 = (g_heff_2esyntax_2esurface_2epiBinders(v_rest_2418));
      return (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_t_2433));
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiBinders(a[0]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2easBinderOn(V v_e_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2easBinderOn_24cpr(v_e_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2enameBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameBinder(V v_e0_240) {
top: ;
  switch (heff_tag_of(v_e0_240)) {
  case TAG_At: {
    V v_e01_241 = heff_dup(heff_field(v_e0_240, 0));
    switch (heff_tag_of(v_e01_241)) {
    case TAG_EVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETag: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EInt: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EString: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EAnn: {
      V v_g_2421 = heff_field(v_e01_241, 0);
      V v_t_2422 = heff_field(v_e01_241, 1);
      V v_ru_24e01_241_24EAnn = heff_take_reuse_n(v_e01_241, 3ULL, 2);
      heff_drop_tag(v_e0_240, 2);
      V v_t_2423 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2423, 0, 2), heff_get_n(v_t_2424, 1, 2)});
      V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a_0)); heff_drop_tag(v_t_2425, 2); r_; });
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
        V v_t_2428 = (g_heff_2esyntax_2esurface_2easNameE(heff_get_n(v_t_2427, 0, 2)));
        V v_t_2429 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2421));
        V v_t_2430 = (g_list_2emap_24s1624059865x1140896478(heff_get_n(v_t_2429, 1, 2)));
        V v_e_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, v_t_2430));
        V v_t_2434;
        switch (heff_tag_of(v_e_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_e_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_e_2431);
        }
        V v_t_2437;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_t_2422, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2438 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_e_2431, v_t_2422}), v_t_2438});
      } else {
        heff_drop(v_t_2426);
        V v_t_2441;
        switch (heff_tag_of(v_g_2421)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_g_2421, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_g_2421);
        }
        V v_t_2444;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2422, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2445 = ({ V rv_1 = heff_get_n(v_t_2444, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2441, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2445});
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    default: return heff_nomatch(v_e01_241);
    }
  }
  default: return heff_nomatch(v_e0_240);
  }
}
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2enameBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eeqnNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eeqnNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Eqn: {
      V v_f_248 = heff_field(v_x11_241, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnNames(v_rest_242));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_248), NTAG(TAG_MkUnit), v_t_2411));
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eeqnNames(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceDocs_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eplaceDocs(V v_src_240, V v_items_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_items__waiting__diags, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_p_245 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2eplaceDocs_lam0, 2, 1, (V[]){v_src_240}), v_t_242, v_items_241));
  V v_items_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_245, 0), heff_dup(heff_rfield(v_p_245, 1))));
  V v_diags_247 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_245, 2), heff_get_n(v_p_245, 1, 3)));
  return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_246, NTAG(TAG_Nil), v_diags_247});
}
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eplaceDocs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_it_244 = args[1];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eplaceStep(v_src_240, v_p_243, v_it_244));
}
Clo g_heff_2esyntax_2esurface_2epathOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epathOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epathOf(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_take_field(v_x_242, 4)});
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_242, 1, 9), v_t_243});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_acc_241});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EField: {
    V v_e_2451 = heff_field(v_x1_240, 0);
    V v_f_2452 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2453 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_f_2452, 3), heff_take_field(v_f_2452, 4)});
    V v_t_2454 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_MkPair, 2, (V[]){heff_get_n(v_f_2452, 1, 9), v_t_2453});
    V t_0 = v_e_2451;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return v_acc_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epathOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 2);
    V v_t_2411;
    switch (heff_tag_of(v_t_243)) {
    case TAG_LamName: {
      V v_x_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamImplicit: {
      V v_x_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamAnn: {
      V v_x_248 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 3);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str1, 50, "a specialisation sets a field by its name: `x = v`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str2, 45, "a specialisation sets fields: `T ~ { x = v }`");
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eopL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243, V v_z_244) {
top: ;
  if (heff_strEq_c(heff_get_n(v_op_242, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eopL_str0))) {
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_a_241)));
    V v_m_24355;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_f_2410 = v_field_248;
        V v_a_2411 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241));
        V v_b_2412 = (g_heff_2esyntax_2ecst_2elastE(v_a_241));
        V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2411, 3, 9), heff_get_n(v_b_2412, 4, 9)});
        v_m_24355 = (g_heff_2esyntax_2esurface_2ebracedL(heff_dup(v_r_240), v_f_2410, v_t_2413));
      } else {
        heff_drop(v_field_248);
        switch (heff_tag_of(v_a_241)) {
        case TAG_Atom: {
          V v_m_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam0, 1, 1, (V[]){v_m_2415});
          break;
        }
        case TAG_EParen: {
          V v_m_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam1, 1, 1, (V[]){v_m_2426});
          break;
        }
        case TAG_Named: {
          V v_m_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam2, 1, 1, (V[]){v_m_2439});
          break;
        }
        case TAG_Tup: {
          V v_m_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam3, 1, 1, (V[]){v_m_2451});
          break;
        }
        case TAG_Seg: {
          V v_m_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam4, 1, 1, (V[]){v_m_2462});
          break;
        }
        case TAG_Braces: {
          V v_m_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam5, 1, 1, (V[]){v_m_2474});
          break;
        }
        case TAG_Update: {
          V v_m_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam6, 1, 1, (V[]){v_m_2488});
          break;
        }
        case TAG_EUSet: {
          V v_m_2499 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam7, 1, 1, (V[]){v_m_2499});
          break;
        }
        case TAG_InstB: {
          V v_o_24107 = heff_field(v_a_241, 0);
          V v_d_24109 = heff_field(v_a_241, 2);
          V v_c_24111 = heff_field(v_a_241, 4);
          heff_take_n(v_a_241, 21ULL, 5);
          V v_m_24112 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_d_24109));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam8, 1, 3, (V[]){v_m_24112, v_o_24107, v_c_24111});
          break;
        }
        case TAG_EFSet: {
          V v_m_24124 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam9, 1, 1, (V[]){v_m_24124});
          break;
        }
        case TAG_EFDefault: {
          V v_m_24135 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam10, 1, 1, (V[]){v_m_24135});
          break;
        }
        case TAG_Sum: {
          V v_m_24148 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam11, 1, 1, (V[]){v_m_24148});
          break;
        }
        case TAG_ECon: {
          V v_m_24158 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam12, 1, 1, (V[]){v_m_24158});
          break;
        }
        case TAG_EField: {
          V v_m_24168 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam13, 1, 1, (V[]){v_m_24168});
          break;
        }
        case TAG_ENeg: {
          V v_m_24178 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam14, 1, 1, (V[]){v_m_24178});
          break;
        }
        case TAG_App: {
          V v_m_24188 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam15, 1, 1, (V[]){v_m_24188});
          break;
        }
        case TAG_Op: {
          V v_m_24199 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam16, 1, 1, (V[]){v_m_24199});
          break;
        }
        case TAG_Ops: {
          V v_m_24209 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam17, 1, 1, (V[]){v_m_24209});
          break;
        }
        case TAG_OpRhs: {
          V v_m_24219 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam18, 1, 1, (V[]){v_m_24219});
          break;
        }
        case TAG_Ann: {
          V v_m_24230 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam19, 1, 1, (V[]){v_m_24230});
          break;
        }
        case TAG_BVar: {
          V v_m_24239 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam20, 1, 1, (V[]){v_m_24239});
          break;
        }
        case TAG_BImp: {
          V v_m_24250 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam21, 1, 1, (V[]){v_m_24250});
          break;
        }
        case TAG_BAnn: {
          V v_m_24263 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam22, 1, 1, (V[]){v_m_24263});
          break;
        }
        case TAG_Lam: {
          V v_m_24275 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam23, 1, 1, (V[]){v_m_24275});
          break;
        }
        case TAG_Case: {
          V v_m_24287 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam24, 1, 1, (V[]){v_m_24287});
          break;
        }
        case TAG_EAlt: {
          V v_m_24298 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam25, 1, 1, (V[]){v_m_24298});
          break;
        }
        case TAG_If: {
          V v_m_24312 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam26, 1, 1, (V[]){v_m_24312});
          break;
        }
        case TAG_Do: {
          V v_m_24322 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam27, 1, 1, (V[]){v_m_24322});
          break;
        }
        case TAG_ESBind: {
          V v_m_24333 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam28, 1, 1, (V[]){v_m_24333});
          break;
        }
        case TAG_ELet: {
          V v_m_24347 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
          v_m_24355 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam29, 1, 1, (V[]){v_m_24347});
          break;
        }
        default: heff_nomatch(v_a_241);
        }
      }
    }
    V v_x1_24356 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24356)) {
    case TAG_MkPair: {
      V v_x11_24357 = heff_field(v_x1_24356, 0);
      V v_st_24358 = heff_field(v_x1_24356, 1);
      V v_ru_24x1_24356_24MkPair = heff_take_reuse_n(v_x1_24356, 3ULL, 2);
      switch (heff_tag_of(v_x11_24357)) {
      case TAG_Left: {
        V v_e_24359 = heff_field(v_x11_24357, 0);
        heff_take_n(v_x11_24357, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24359}), v_st_24358});
      }
      case TAG_Right: {
        V v_x_24360 = heff_field(v_x11_24357, 0);
        heff_take_n(v_x11_24357, 1ULL, 1);
        V v_m_24361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
        V v_x1_24362 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_st_24358}));
        switch (heff_tag_of(v_x1_24362)) {
        case TAG_MkPair: {
          V v_x11_24363 = heff_field(v_x1_24362, 0);
          V v_st_24364 = heff_field(v_x1_24362, 1);
          heff_take_n(v_x1_24362, 3ULL, 2);
          switch (heff_tag_of(v_x11_24363)) {
          case TAG_Left: {
            V v_e_24365 = heff_field(v_x11_24363, 0);
            heff_take_n(v_x11_24363, 1ULL, 1);
            heff_drop(v_x_24360);
            return heff_tag_at_n(v_ru_24x1_24356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24365}), v_st_24364});
          }
          case TAG_Right: {
            V v_x_24366 = heff_field(v_x11_24363, 0);
            heff_take_n(v_x11_24363, 1ULL, 1);
            V v_x_24367 = heff_tr(g_heff_2esyntax_2esurface_2earrowBinop(v_x_24360, v_x_24366));
            return heff_tag_at_n(v_ru_24x1_24356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24367}), v_st_24364});
          }
          default: return heff_nomatch(v_x11_24363);
          }
        }
        default: return heff_nomatch(v_x1_24362);
        }
      }
      default: return heff_nomatch(v_x11_24357);
      }
    }
    default: return heff_nomatch(v_x1_24356);
    }
  } else {
    V v_m_24368 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
    V v_x1_24369 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24369)) {
    case TAG_MkPair: {
      V v_x11_24370 = heff_field(v_x1_24369, 0);
      V v_st_24371 = heff_field(v_x1_24369, 1);
      V v_ru_24x1_24369_24MkPair = heff_take_reuse_n(v_x1_24369, 3ULL, 2);
      switch (heff_tag_of(v_x11_24370)) {
      case TAG_Left: {
        V v_e_24372 = heff_field(v_x11_24370, 0);
        heff_take_n(v_x11_24370, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24372}), v_st_24371});
      }
      case TAG_Right: {
        V v_x_24373 = heff_field(v_x11_24370, 0);
        V v_ru_24x11_24370_24Right = heff_take_reuse_n(v_x11_24370, 1ULL, 1);
        HeffT2 v_t_24374 = (g_heff_2esyntax_2esurface_2esettingsOf_24cpr(heff_dup(v_b_243)));
        {
          V v_field_24376 = v_t_24374.f[1];
          int64_t v_tag_24375 = ((int64_t)v_t_24374.f[0]);
          if ((v_tag_24375 == ((int64_t)0ULL))) {
            heff_drop(v_b_243);
            heff_drop_cell(v_ru_24x11_24370_24Right, 1);
            V v_fs_24378 = v_field_24376;
            V v_m_24380 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam30, 1, 1, (V[]){v_r_240}), v_fs_24378));
            V v_x1_24381 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_st_24371}));
            switch (heff_tag_of(v_x1_24381)) {
            case TAG_MkPair: {
              V v_x11_24382 = heff_field(v_x1_24381, 0);
              V v_st_24383 = heff_field(v_x1_24381, 1);
              heff_take_n(v_x1_24381, 3ULL, 2);
              switch (heff_tag_of(v_x11_24382)) {
              case TAG_Left: {
                V v_e_24384 = heff_field(v_x11_24382, 0);
                heff_take_n(v_x11_24382, 1ULL, 1);
                heff_drop(v_x_24373);
                return heff_tag_at_n(v_ru_24x1_24369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
              }
              case TAG_Right: {
                V v_x_24385 = heff_field(v_x11_24382, 0);
                heff_take_n(v_x11_24382, 1ULL, 1);
                V v_x_24386 = (g_list_2efoldl_24s1368043225x413679696(((V)&g_heff_2esyntax_2esurface_2eopL_str1), v_x_24373, v_x_24385));
                return heff_tag_at_n(v_ru_24x1_24369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24386}), v_st_24383});
              }
              default: return heff_nomatch(v_x11_24382);
              }
            }
            default: return heff_nomatch(v_x1_24381);
            }
          } else {
            heff_drop(v_field_24376);
            V v_m_24387 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
            V v_x1_24388 = heff_tr(heff_call(v_m_24387, 1, (V[]){v_st_24371}));
            switch (heff_tag_of(v_x1_24388)) {
            case TAG_MkPair: {
              V v_x11_24389 = heff_field(v_x1_24388, 0);
              V v_st_24390 = heff_field(v_x1_24388, 1);
              V v_ru_24x1_24388_24MkPair = heff_take_reuse_n(v_x1_24388, 3ULL, 2);
              switch (heff_tag_of(v_x11_24389)) {
              case TAG_Left: {
                V v_e_24391 = heff_field(v_x11_24389, 0);
                heff_take_n(v_x11_24389, 1ULL, 1);
                heff_drop(v_x_24373);
                heff_drop_cell(v_ru_24x11_24370_24Right, 1);
                heff_drop_cell(v_ru_24x1_24388_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_24369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24391}), v_st_24390});
              }
              case TAG_Right: {
                V v_x_24392 = heff_field(v_x11_24389, 0);
                heff_take_n(v_x11_24389, 1ULL, 1);
                V v_t_24395;
                switch (heff_tag_of(v_x_24373)) {
                case TAG_At: {
                  V v_s_24394 = heff_field(v_x_24373, 1);
                  heff_take_n(v_x_24373, 2ULL, 2);
                  v_t_24395 = v_s_24394;
                  break;
                }
                default: heff_nomatch(v_x_24373);
                }
                V v_t_24398;
                switch (heff_tag_of(v_x_24392)) {
                case TAG_At: {
                  V v_s_24397 = heff_field(v_x_24392, 1);
                  heff_take_n(v_x_24392, 2ULL, 2);
                  v_t_24398 = v_s_24397;
                  break;
                }
                default: heff_nomatch(v_x_24392);
                }
                V v_t_24399 = ({ V rv_1 = heff_get_n(v_t_24398, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24395, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24400 = heff_tag_at_n(v_ru_24x1_24388_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24370_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eopL_str2)}), v_t_24399});
                return heff_tag_at_n(v_ru_24x1_24369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24400}), v_st_24390});
              }
              default: return heff_nomatch(v_x11_24389);
              }
            }
            default: return heff_nomatch(v_x1_24388);
            }
          }
        }
      }
      default: return heff_nomatch(v_x11_24370);
      }
    }
    default: return heff_nomatch(v_x1_24369);
    }
  }
}
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_t_2422 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2421})});
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args) {
  V v_st_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_st_2427}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_MkPair: {
    V v_x11_2429 = heff_field(v_x1_2428, 0);
    V v_st_2430 = heff_field(v_x1_2428, 1);
    V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_Left: {
      V v_e_2431 = heff_field(v_x11_2429, 0);
      heff_take_n(v_x11_2429, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      V v_t_2433 = heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2432})});
      return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){v_t_2433, v_st_2430});
    }
    default: return heff_nomatch(v_x11_2429);
    }
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
      V v_t_2446 = heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2445})});
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){v_t_2446, v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
      V v_t_2458 = heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2457})});
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){v_t_2458, v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2469 = heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2468})});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){v_t_2469, v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args) {
  V v_st_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_st_2475}));
  switch (heff_tag_of(v_x1_2476)) {
  case TAG_MkPair: {
    V v_x11_2477 = heff_field(v_x1_2476, 0);
    V v_st_2478 = heff_field(v_x1_2476, 1);
    V v_ru_24x1_2476_24MkPair = heff_take_reuse_n(v_x1_2476, 3ULL, 2);
    switch (heff_tag_of(v_x11_2477)) {
    case TAG_Left: {
      V v_e_2479 = heff_field(v_x11_2477, 0);
      heff_take_n(v_x11_2477, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2479}), v_st_2478});
    }
    case TAG_Right: {
      V v_x_2480 = heff_field(v_x11_2477, 0);
      V v_ru_24x11_2477_24Right = heff_take_reuse_n(v_x11_2477, 1ULL, 1);
      V v_t_2481 = heff_tag_at_n(v_ru_24x11_2477_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2480})});
      return heff_tag_at_n(v_ru_24x1_2476_24MkPair, TAG_MkPair, 2, (V[]){v_t_2481, v_st_2478});
    }
    default: return heff_nomatch(v_x11_2477);
    }
  }
  default: return heff_nomatch(v_x1_2476);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args) {
  V v_st_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_st_2489}));
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_MkPair: {
    V v_x11_2491 = heff_field(v_x1_2490, 0);
    V v_st_2492 = heff_field(v_x1_2490, 1);
    V v_ru_24x1_2490_24MkPair = heff_take_reuse_n(v_x1_2490, 3ULL, 2);
    switch (heff_tag_of(v_x11_2491)) {
    case TAG_Left: {
      V v_e_2493 = heff_field(v_x11_2491, 0);
      heff_take_n(v_x11_2491, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2493}), v_st_2492});
    }
    case TAG_Right: {
      V v_x_2494 = heff_field(v_x11_2491, 0);
      V v_ru_24x11_2491_24Right = heff_take_reuse_n(v_x11_2491, 1ULL, 1);
      V v_t_2495 = heff_tag_at_n(v_ru_24x11_2491_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2494})});
      return heff_tag_at_n(v_ru_24x1_2490_24MkPair, TAG_MkPair, 2, (V[]){v_t_2495, v_st_2492});
    }
    default: return heff_nomatch(v_x11_2491);
    }
  }
  default: return heff_nomatch(v_x1_2490);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args) {
  V v_st_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24101 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_st_24100}));
  switch (heff_tag_of(v_x1_24101)) {
  case TAG_MkPair: {
    V v_x11_24102 = heff_field(v_x1_24101, 0);
    V v_st_24103 = heff_field(v_x1_24101, 1);
    V v_ru_24x1_24101_24MkPair = heff_take_reuse_n(v_x1_24101, 3ULL, 2);
    switch (heff_tag_of(v_x11_24102)) {
    case TAG_Left: {
      V v_e_24104 = heff_field(v_x11_24102, 0);
      heff_take_n(v_x11_24102, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24101_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24104}), v_st_24103});
    }
    case TAG_Right: {
      V v_x_24105 = heff_field(v_x11_24102, 0);
      V v_ru_24x11_24102_24Right = heff_take_reuse_n(v_x11_24102, 1ULL, 1);
      V v_t_24106 = heff_tag_at_n(v_ru_24x11_24102_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24105})});
      return heff_tag_at_n(v_ru_24x1_24101_24MkPair, TAG_MkPair, 2, (V[]){v_t_24106, v_st_24103});
    }
    default: return heff_nomatch(v_x11_24102);
    }
  }
  default: return heff_nomatch(v_x1_24101);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args) {
  V v_st_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_o_24107 = heff_env(self)[1];
  V v_c_24111 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_st_24113}));
  switch (heff_tag_of(v_x1_24114)) {
  case TAG_MkPair: {
    V v_x11_24115 = heff_field(v_x1_24114, 0);
    V v_st_24116 = heff_field(v_x1_24114, 1);
    V v_ru_24x1_24114_24MkPair = heff_take_reuse_n(v_x1_24114, 3ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_Left: {
      V v_e_24117 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      heff_drop_rec(v_o_24107, 9);
      heff_drop_rec(v_c_24111, 9);
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24117}), v_st_24116});
    }
    case TAG_Right: {
      V v_x_24118 = heff_field(v_x11_24115, 0);
      V v_ru_24x11_24115_24Right = heff_take_reuse_n(v_x11_24115, 1ULL, 1);
      V v_t_24119 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24107, 3, 9), heff_get_n(v_c_24111, 4, 9)});
      V v_t_24120 = heff_tag_at_n(v_ru_24x11_24115_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Bracketed, 2, (V[]){v_x_24118, v_t_24119})});
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){v_t_24120, v_st_24116});
    }
    default: return heff_nomatch(v_x11_24115);
    }
  }
  default: return heff_nomatch(v_x1_24114);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24131 = heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24130})});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){v_t_24131, v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args) {
  V v_st_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24137 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_st_24136}));
  switch (heff_tag_of(v_x1_24137)) {
  case TAG_MkPair: {
    V v_x11_24138 = heff_field(v_x1_24137, 0);
    V v_st_24139 = heff_field(v_x1_24137, 1);
    V v_ru_24x1_24137_24MkPair = heff_take_reuse_n(v_x1_24137, 3ULL, 2);
    switch (heff_tag_of(v_x11_24138)) {
    case TAG_Left: {
      V v_e_24140 = heff_field(v_x11_24138, 0);
      heff_take_n(v_x11_24138, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24140}), v_st_24139});
    }
    case TAG_Right: {
      V v_x_24141 = heff_field(v_x11_24138, 0);
      V v_ru_24x11_24138_24Right = heff_take_reuse_n(v_x11_24138, 1ULL, 1);
      V v_t_24142 = heff_tag_at_n(v_ru_24x11_24138_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24141})});
      return heff_tag_at_n(v_ru_24x1_24137_24MkPair, TAG_MkPair, 2, (V[]){v_t_24142, v_st_24139});
    }
    default: return heff_nomatch(v_x11_24138);
    }
  }
  default: return heff_nomatch(v_x1_24137);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args) {
  V v_st_24149 = args[0];
  V v_m_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24150 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_st_24149}));
  switch (heff_tag_of(v_x1_24150)) {
  case TAG_MkPair: {
    V v_x11_24151 = heff_field(v_x1_24150, 0);
    V v_st_24152 = heff_field(v_x1_24150, 1);
    V v_ru_24x1_24150_24MkPair = heff_take_reuse_n(v_x1_24150, 3ULL, 2);
    switch (heff_tag_of(v_x11_24151)) {
    case TAG_Left: {
      V v_e_24153 = heff_field(v_x11_24151, 0);
      heff_take_n(v_x11_24151, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24150_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24153}), v_st_24152});
    }
    case TAG_Right: {
      V v_x_24154 = heff_field(v_x11_24151, 0);
      V v_ru_24x11_24151_24Right = heff_take_reuse_n(v_x11_24151, 1ULL, 1);
      V v_t_24155 = heff_tag_at_n(v_ru_24x11_24151_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24154})});
      return heff_tag_at_n(v_ru_24x1_24150_24MkPair, TAG_MkPair, 2, (V[]){v_t_24155, v_st_24152});
    }
    default: return heff_nomatch(v_x11_24151);
    }
  }
  default: return heff_nomatch(v_x1_24150);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args) {
  V v_st_24159 = args[0];
  V v_m_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24160 = heff_tr(heff_call(v_m_24158, 1, (V[]){v_st_24159}));
  switch (heff_tag_of(v_x1_24160)) {
  case TAG_MkPair: {
    V v_x11_24161 = heff_field(v_x1_24160, 0);
    V v_st_24162 = heff_field(v_x1_24160, 1);
    V v_ru_24x1_24160_24MkPair = heff_take_reuse_n(v_x1_24160, 3ULL, 2);
    switch (heff_tag_of(v_x11_24161)) {
    case TAG_Left: {
      V v_e_24163 = heff_field(v_x11_24161, 0);
      heff_take_n(v_x11_24161, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24163}), v_st_24162});
    }
    case TAG_Right: {
      V v_x_24164 = heff_field(v_x11_24161, 0);
      V v_ru_24x11_24161_24Right = heff_take_reuse_n(v_x11_24161, 1ULL, 1);
      V v_t_24165 = heff_tag_at_n(v_ru_24x11_24161_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24164})});
      return heff_tag_at_n(v_ru_24x1_24160_24MkPair, TAG_MkPair, 2, (V[]){v_t_24165, v_st_24162});
    }
    default: return heff_nomatch(v_x11_24161);
    }
  }
  default: return heff_nomatch(v_x1_24160);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args) {
  V v_st_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_st_24169}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
      V v_t_24175 = heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24174})});
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){v_t_24175, v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args) {
  V v_st_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_st_24179}));
  switch (heff_tag_of(v_x1_24180)) {
  case TAG_MkPair: {
    V v_x11_24181 = heff_field(v_x1_24180, 0);
    V v_st_24182 = heff_field(v_x1_24180, 1);
    V v_ru_24x1_24180_24MkPair = heff_take_reuse_n(v_x1_24180, 3ULL, 2);
    switch (heff_tag_of(v_x11_24181)) {
    case TAG_Left: {
      V v_e_24183 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
    }
    case TAG_Right: {
      V v_x_24184 = heff_field(v_x11_24181, 0);
      V v_ru_24x11_24181_24Right = heff_take_reuse_n(v_x11_24181, 1ULL, 1);
      V v_t_24185 = heff_tag_at_n(v_ru_24x11_24181_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24184})});
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){v_t_24185, v_st_24182});
    }
    default: return heff_nomatch(v_x11_24181);
    }
  }
  default: return heff_nomatch(v_x1_24180);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args) {
  V v_st_24189 = args[0];
  V v_m_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24190 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_st_24189}));
  switch (heff_tag_of(v_x1_24190)) {
  case TAG_MkPair: {
    V v_x11_24191 = heff_field(v_x1_24190, 0);
    V v_st_24192 = heff_field(v_x1_24190, 1);
    V v_ru_24x1_24190_24MkPair = heff_take_reuse_n(v_x1_24190, 3ULL, 2);
    switch (heff_tag_of(v_x11_24191)) {
    case TAG_Left: {
      V v_e_24193 = heff_field(v_x11_24191, 0);
      heff_take_n(v_x11_24191, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24190_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24193}), v_st_24192});
    }
    case TAG_Right: {
      V v_x_24194 = heff_field(v_x11_24191, 0);
      V v_ru_24x11_24191_24Right = heff_take_reuse_n(v_x11_24191, 1ULL, 1);
      V v_t_24195 = heff_tag_at_n(v_ru_24x11_24191_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24194})});
      return heff_tag_at_n(v_ru_24x1_24190_24MkPair, TAG_MkPair, 2, (V[]){v_t_24195, v_st_24192});
    }
    default: return heff_nomatch(v_x11_24191);
    }
  }
  default: return heff_nomatch(v_x1_24190);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args) {
  V v_st_24200 = args[0];
  V v_m_24199 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24201 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_st_24200}));
  switch (heff_tag_of(v_x1_24201)) {
  case TAG_MkPair: {
    V v_x11_24202 = heff_field(v_x1_24201, 0);
    V v_st_24203 = heff_field(v_x1_24201, 1);
    V v_ru_24x1_24201_24MkPair = heff_take_reuse_n(v_x1_24201, 3ULL, 2);
    switch (heff_tag_of(v_x11_24202)) {
    case TAG_Left: {
      V v_e_24204 = heff_field(v_x11_24202, 0);
      heff_take_n(v_x11_24202, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24204}), v_st_24203});
    }
    case TAG_Right: {
      V v_x_24205 = heff_field(v_x11_24202, 0);
      V v_ru_24x11_24202_24Right = heff_take_reuse_n(v_x11_24202, 1ULL, 1);
      V v_t_24206 = heff_tag_at_n(v_ru_24x11_24202_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24205})});
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){v_t_24206, v_st_24203});
    }
    default: return heff_nomatch(v_x11_24202);
    }
  }
  default: return heff_nomatch(v_x1_24201);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args) {
  V v_st_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_st_24210}));
  switch (heff_tag_of(v_x1_24211)) {
  case TAG_MkPair: {
    V v_x11_24212 = heff_field(v_x1_24211, 0);
    V v_st_24213 = heff_field(v_x1_24211, 1);
    V v_ru_24x1_24211_24MkPair = heff_take_reuse_n(v_x1_24211, 3ULL, 2);
    switch (heff_tag_of(v_x11_24212)) {
    case TAG_Left: {
      V v_e_24214 = heff_field(v_x11_24212, 0);
      heff_take_n(v_x11_24212, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24214}), v_st_24213});
    }
    case TAG_Right: {
      V v_x_24215 = heff_field(v_x11_24212, 0);
      V v_ru_24x11_24212_24Right = heff_take_reuse_n(v_x11_24212, 1ULL, 1);
      V v_t_24216 = heff_tag_at_n(v_ru_24x11_24212_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24215})});
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){v_t_24216, v_st_24213});
    }
    default: return heff_nomatch(v_x11_24212);
    }
  }
  default: return heff_nomatch(v_x1_24211);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args) {
  V v_st_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24221 = heff_tr(heff_call(v_m_24219, 1, (V[]){v_st_24220}));
  switch (heff_tag_of(v_x1_24221)) {
  case TAG_MkPair: {
    V v_x11_24222 = heff_field(v_x1_24221, 0);
    V v_st_24223 = heff_field(v_x1_24221, 1);
    V v_ru_24x1_24221_24MkPair = heff_take_reuse_n(v_x1_24221, 3ULL, 2);
    switch (heff_tag_of(v_x11_24222)) {
    case TAG_Left: {
      V v_e_24224 = heff_field(v_x11_24222, 0);
      heff_take_n(v_x11_24222, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24221_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24224}), v_st_24223});
    }
    case TAG_Right: {
      V v_x_24225 = heff_field(v_x11_24222, 0);
      V v_ru_24x11_24222_24Right = heff_take_reuse_n(v_x11_24222, 1ULL, 1);
      V v_t_24226 = heff_tag_at_n(v_ru_24x11_24222_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24225})});
      return heff_tag_at_n(v_ru_24x1_24221_24MkPair, TAG_MkPair, 2, (V[]){v_t_24226, v_st_24223});
    }
    default: return heff_nomatch(v_x11_24222);
    }
  }
  default: return heff_nomatch(v_x1_24221);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args) {
  V v_st_24231 = args[0];
  V v_m_24230 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24232 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_st_24231}));
  switch (heff_tag_of(v_x1_24232)) {
  case TAG_MkPair: {
    V v_x11_24233 = heff_field(v_x1_24232, 0);
    V v_st_24234 = heff_field(v_x1_24232, 1);
    V v_ru_24x1_24232_24MkPair = heff_take_reuse_n(v_x1_24232, 3ULL, 2);
    switch (heff_tag_of(v_x11_24233)) {
    case TAG_Left: {
      V v_e_24235 = heff_field(v_x11_24233, 0);
      heff_take_n(v_x11_24233, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24235}), v_st_24234});
    }
    case TAG_Right: {
      V v_x_24236 = heff_field(v_x11_24233, 0);
      V v_ru_24x11_24233_24Right = heff_take_reuse_n(v_x11_24233, 1ULL, 1);
      V v_t_24237 = heff_tag_at_n(v_ru_24x11_24233_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24236})});
      return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){v_t_24237, v_st_24234});
    }
    default: return heff_nomatch(v_x11_24233);
    }
  }
  default: return heff_nomatch(v_x1_24232);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args) {
  V v_st_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_st_24240}));
  switch (heff_tag_of(v_x1_24241)) {
  case TAG_MkPair: {
    V v_x11_24242 = heff_field(v_x1_24241, 0);
    V v_st_24243 = heff_field(v_x1_24241, 1);
    V v_ru_24x1_24241_24MkPair = heff_take_reuse_n(v_x1_24241, 3ULL, 2);
    switch (heff_tag_of(v_x11_24242)) {
    case TAG_Left: {
      V v_e_24244 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24244}), v_st_24243});
    }
    case TAG_Right: {
      V v_x_24245 = heff_field(v_x11_24242, 0);
      V v_ru_24x11_24242_24Right = heff_take_reuse_n(v_x11_24242, 1ULL, 1);
      V v_t_24246 = heff_tag_at_n(v_ru_24x11_24242_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24245})});
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){v_t_24246, v_st_24243});
    }
    default: return heff_nomatch(v_x11_24242);
    }
  }
  default: return heff_nomatch(v_x1_24241);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args) {
  V v_st_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_st_24251}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_MkPair: {
    V v_x11_24253 = heff_field(v_x1_24252, 0);
    V v_st_24254 = heff_field(v_x1_24252, 1);
    V v_ru_24x1_24252_24MkPair = heff_take_reuse_n(v_x1_24252, 3ULL, 2);
    switch (heff_tag_of(v_x11_24253)) {
    case TAG_Left: {
      V v_e_24255 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24255}), v_st_24254});
    }
    case TAG_Right: {
      V v_x_24256 = heff_field(v_x11_24253, 0);
      V v_ru_24x11_24253_24Right = heff_take_reuse_n(v_x11_24253, 1ULL, 1);
      V v_t_24257 = heff_tag_at_n(v_ru_24x11_24253_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24256})});
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){v_t_24257, v_st_24254});
    }
    default: return heff_nomatch(v_x11_24253);
    }
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args) {
  V v_st_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_st_24264}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_MkPair: {
    V v_x11_24266 = heff_field(v_x1_24265, 0);
    V v_st_24267 = heff_field(v_x1_24265, 1);
    V v_ru_24x1_24265_24MkPair = heff_take_reuse_n(v_x1_24265, 3ULL, 2);
    switch (heff_tag_of(v_x11_24266)) {
    case TAG_Left: {
      V v_e_24268 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24268}), v_st_24267});
    }
    case TAG_Right: {
      V v_x_24269 = heff_field(v_x11_24266, 0);
      V v_ru_24x11_24266_24Right = heff_take_reuse_n(v_x11_24266, 1ULL, 1);
      V v_t_24270 = heff_tag_at_n(v_ru_24x11_24266_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24269})});
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){v_t_24270, v_st_24267});
    }
    default: return heff_nomatch(v_x11_24266);
    }
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args) {
  V v_st_24276 = args[0];
  V v_m_24275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24277 = heff_tr(heff_call(v_m_24275, 1, (V[]){v_st_24276}));
  switch (heff_tag_of(v_x1_24277)) {
  case TAG_MkPair: {
    V v_x11_24278 = heff_field(v_x1_24277, 0);
    V v_st_24279 = heff_field(v_x1_24277, 1);
    V v_ru_24x1_24277_24MkPair = heff_take_reuse_n(v_x1_24277, 3ULL, 2);
    switch (heff_tag_of(v_x11_24278)) {
    case TAG_Left: {
      V v_e_24280 = heff_field(v_x11_24278, 0);
      heff_take_n(v_x11_24278, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24280}), v_st_24279});
    }
    case TAG_Right: {
      V v_x_24281 = heff_field(v_x11_24278, 0);
      V v_ru_24x11_24278_24Right = heff_take_reuse_n(v_x11_24278, 1ULL, 1);
      V v_t_24282 = heff_tag_at_n(v_ru_24x11_24278_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24281})});
      return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){v_t_24282, v_st_24279});
    }
    default: return heff_nomatch(v_x11_24278);
    }
  }
  default: return heff_nomatch(v_x1_24277);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args) {
  V v_st_24288 = args[0];
  V v_m_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24289 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_st_24288}));
  switch (heff_tag_of(v_x1_24289)) {
  case TAG_MkPair: {
    V v_x11_24290 = heff_field(v_x1_24289, 0);
    V v_st_24291 = heff_field(v_x1_24289, 1);
    V v_ru_24x1_24289_24MkPair = heff_take_reuse_n(v_x1_24289, 3ULL, 2);
    switch (heff_tag_of(v_x11_24290)) {
    case TAG_Left: {
      V v_e_24292 = heff_field(v_x11_24290, 0);
      heff_take_n(v_x11_24290, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24292}), v_st_24291});
    }
    case TAG_Right: {
      V v_x_24293 = heff_field(v_x11_24290, 0);
      V v_ru_24x11_24290_24Right = heff_take_reuse_n(v_x11_24290, 1ULL, 1);
      V v_t_24294 = heff_tag_at_n(v_ru_24x11_24290_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24293})});
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){v_t_24294, v_st_24291});
    }
    default: return heff_nomatch(v_x11_24290);
    }
  }
  default: return heff_nomatch(v_x1_24289);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args) {
  V v_st_24299 = args[0];
  V v_m_24298 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24300 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_st_24299}));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_MkPair: {
    V v_x11_24301 = heff_field(v_x1_24300, 0);
    V v_st_24302 = heff_field(v_x1_24300, 1);
    V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
    switch (heff_tag_of(v_x11_24301)) {
    case TAG_Left: {
      V v_e_24303 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
    }
    case TAG_Right: {
      V v_x_24304 = heff_field(v_x11_24301, 0);
      V v_ru_24x11_24301_24Right = heff_take_reuse_n(v_x11_24301, 1ULL, 1);
      V v_t_24305 = heff_tag_at_n(v_ru_24x11_24301_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24304})});
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){v_t_24305, v_st_24302});
    }
    default: return heff_nomatch(v_x11_24301);
    }
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args) {
  V v_st_24313 = args[0];
  V v_m_24312 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24314 = heff_tr(heff_call(v_m_24312, 1, (V[]){v_st_24313}));
  switch (heff_tag_of(v_x1_24314)) {
  case TAG_MkPair: {
    V v_x11_24315 = heff_field(v_x1_24314, 0);
    V v_st_24316 = heff_field(v_x1_24314, 1);
    V v_ru_24x1_24314_24MkPair = heff_take_reuse_n(v_x1_24314, 3ULL, 2);
    switch (heff_tag_of(v_x11_24315)) {
    case TAG_Left: {
      V v_e_24317 = heff_field(v_x11_24315, 0);
      heff_take_n(v_x11_24315, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24314_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24317}), v_st_24316});
    }
    case TAG_Right: {
      V v_x_24318 = heff_field(v_x11_24315, 0);
      V v_ru_24x11_24315_24Right = heff_take_reuse_n(v_x11_24315, 1ULL, 1);
      V v_t_24319 = heff_tag_at_n(v_ru_24x11_24315_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24318})});
      return heff_tag_at_n(v_ru_24x1_24314_24MkPair, TAG_MkPair, 2, (V[]){v_t_24319, v_st_24316});
    }
    default: return heff_nomatch(v_x11_24315);
    }
  }
  default: return heff_nomatch(v_x1_24314);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args) {
  V v_st_24323 = args[0];
  V v_m_24322 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24324 = heff_tr(heff_call(v_m_24322, 1, (V[]){v_st_24323}));
  switch (heff_tag_of(v_x1_24324)) {
  case TAG_MkPair: {
    V v_x11_24325 = heff_field(v_x1_24324, 0);
    V v_st_24326 = heff_field(v_x1_24324, 1);
    V v_ru_24x1_24324_24MkPair = heff_take_reuse_n(v_x1_24324, 3ULL, 2);
    switch (heff_tag_of(v_x11_24325)) {
    case TAG_Left: {
      V v_e_24327 = heff_field(v_x11_24325, 0);
      heff_take_n(v_x11_24325, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24324_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24327}), v_st_24326});
    }
    case TAG_Right: {
      V v_x_24328 = heff_field(v_x11_24325, 0);
      V v_ru_24x11_24325_24Right = heff_take_reuse_n(v_x11_24325, 1ULL, 1);
      V v_t_24329 = heff_tag_at_n(v_ru_24x11_24325_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24328})});
      return heff_tag_at_n(v_ru_24x1_24324_24MkPair, TAG_MkPair, 2, (V[]){v_t_24329, v_st_24326});
    }
    default: return heff_nomatch(v_x11_24325);
    }
  }
  default: return heff_nomatch(v_x1_24324);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args) {
  V v_st_24334 = args[0];
  V v_m_24333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24335 = heff_tr(heff_call(v_m_24333, 1, (V[]){v_st_24334}));
  switch (heff_tag_of(v_x1_24335)) {
  case TAG_MkPair: {
    V v_x11_24336 = heff_field(v_x1_24335, 0);
    V v_st_24337 = heff_field(v_x1_24335, 1);
    V v_ru_24x1_24335_24MkPair = heff_take_reuse_n(v_x1_24335, 3ULL, 2);
    switch (heff_tag_of(v_x11_24336)) {
    case TAG_Left: {
      V v_e_24338 = heff_field(v_x11_24336, 0);
      heff_take_n(v_x11_24336, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24335_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24338}), v_st_24337});
    }
    case TAG_Right: {
      V v_x_24339 = heff_field(v_x11_24336, 0);
      V v_ru_24x11_24336_24Right = heff_take_reuse_n(v_x11_24336, 1ULL, 1);
      V v_t_24340 = heff_tag_at_n(v_ru_24x11_24336_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24339})});
      return heff_tag_at_n(v_ru_24x1_24335_24MkPair, TAG_MkPair, 2, (V[]){v_t_24340, v_st_24337});
    }
    default: return heff_nomatch(v_x11_24336);
    }
  }
  default: return heff_nomatch(v_x1_24335);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args) {
  V v_st_24348 = args[0];
  V v_m_24347 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24349 = heff_tr(heff_call(v_m_24347, 1, (V[]){v_st_24348}));
  switch (heff_tag_of(v_x1_24349)) {
  case TAG_MkPair: {
    V v_x11_24350 = heff_field(v_x1_24349, 0);
    V v_st_24351 = heff_field(v_x1_24349, 1);
    V v_ru_24x1_24349_24MkPair = heff_take_reuse_n(v_x1_24349, 3ULL, 2);
    switch (heff_tag_of(v_x11_24350)) {
    case TAG_Left: {
      V v_e_24352 = heff_field(v_x11_24350, 0);
      heff_take_n(v_x11_24350, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24352}), v_st_24351});
    }
    case TAG_Right: {
      V v_x_24353 = heff_field(v_x11_24350, 0);
      V v_ru_24x11_24350_24Right = heff_take_reuse_n(v_x11_24350, 1ULL, 1);
      V v_t_24354 = heff_tag_at_n(v_ru_24x11_24350_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24353})});
      return heff_tag_at_n(v_ru_24x1_24349_24MkPair, TAG_MkPair, 2, (V[]){v_t_24354, v_st_24351});
    }
    default: return heff_nomatch(v_x11_24350);
    }
  }
  default: return heff_nomatch(v_x1_24349);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args) {
  V v_m_24379 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_24379));
}
Clo g_heff_2esyntax_2esurface_2etwoToS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etwoToS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etwoToS(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etwoToS(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_entry, 6, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith(V v_r_240, V v_last_241, V v_sp_242, V v_p_243, V v_s_244, V v_z_245) {
top: ;
  V v_x2_246 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam0, 1, 2, (V[]){v_x2_246, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam1, 2, 5, (V[]){v_r_240, v_p_243, v_sp_242, v_s_244, heff_dup(v_last_241)}), v_z_245));
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x2_246 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_246) == NTAG(TAG_True))) {
    heff_drop(v_x2_246);
    heff_drop(v_sp_242);
    V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_p_247});
  } else {
    heff_drop(v_x2_246);
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_p_247});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_z_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_last_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_2411}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_s_244);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_At: {
        V v_x11_2418 = heff_dup(heff_field(v_x_2417, 0));
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2427 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          v_t_2437 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_IntValue, 1, (V[]){v_v_2427});
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2418);
        }
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      HeffT2 v_t_2438 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_242); V a_2 = v_x_2417; V a_3 = v_t_2437; V a_4 = v_s_244; V a_5 = v_st_2415; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        V v_x11_2441 = v_field_2439;
        V v_st_2442 = v_field_2440;
        switch (heff_tag_of(v_x11_2441)) {
        case TAG_Left: {
          V v_e_2443 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
        }
        case TAG_Right: {
          V v_x_2444 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          if ((heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
          } else {
            heff_drop(v_last_241);
            V v_t_2447;
            switch (heff_tag_of(v_x_2444)) {
            case TAG_At: {
              V v_x_2445 = heff_dup(heff_field(v_x_2444, 0));
              v_t_2447 = v_x_2445;
              break;
            }
            default: heff_nomatch(v_x_2444);
            }
            V v_t_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2447); r_; });
            if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
              heff_drop(v_x_2444);
              heff_drop(v_t_2448);
              V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2449}), v_st_2442});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2448);
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2442});
            }
          }
        }
        default: return heff_nomatch(v_x11_2441);
        }
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eargL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eargL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eargL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EParen: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Named: {
    V v_o_246 = heff_field(v_x2_241, 0);
    V v_x_247 = heff_field(v_x2_241, 1);
    V v_e_249 = heff_field(v_x2_241, 3);
    V v_c_2410 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 27ULL, 5);
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_249}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eargL_lam0, 1, 4, (V[]){v_m_2411, v_x_247, v_o_246, v_c_2410});
  }
  case TAG_Tup: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Seg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Braces: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Update: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EUSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_InstB: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EFDefault: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Sum: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ECon: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EField: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ENeg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_App: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Op: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Ops: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Ann: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BVar: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BImp: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Lam: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Case: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_If: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_Do: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  case TAG_ELet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eargL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_o_246 = heff_env(self)[2];
  V v_c_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_x_247, 9);
      heff_drop_rec(v_o_246, 9);
      heff_drop_rec(v_c_2410, 9);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_tag_n(TAG_ENamed, 2, (V[]){heff_get_n(v_x_247, 1, 9), v_x_2417});
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_246, 3, 9), heff_get_n(v_c_2410, 4, 9)});
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419})});
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyPatOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2esigL_24cpr(V v_r_240, V v_declared_241, V v_start_242, V v_names_243, V v_ty_244, V v_z_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_ty_244)}));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_declared_241);
      heff_drop(v_start_242);
      heff_drop(v_ty_244);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
      V v_f_2413 = heff_get_n(v_t_2412, 0, 2);
      V v_names_2414 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_2411)));
      V v_implicits_2415 = (g_heff_2esyntax_2esurface_2epiImplicits(heff_dup(v_x_2411)));
      V v_t_2416 = (g_heff_2esyntax_2esurface_2eaddBinders(heff_rec_n(3, shape_f__names__implicits, (V[]){v_f_2413, v_names_2414, v_implicits_2415}), v_st_249));
      V v_t_2417 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
      V v_t_2418 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
      V v_t_2419 = (g_heff_2esyntax_2ecst_2elastE(v_ty_244));
      V v_b_2420 = heff_get_n(v_t_2419, 4, 9);
      V v_t_2421 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_241, heff_get_n(v_t_2417, 0, 2), heff_get_n(v_t_2418, 1, 2), v_x_2411, heff_rec_n(2, shape_start__end, (V[]){v_start_242, v_b_2420})});
      V v_x_2422 = heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){v_x_2422}), v_t_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPi: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAnn: {
      V v_x111_2421 = heff_field(v_x11_241, 0);
      V v_t_2422 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_At: {
        V v_x1111_2423 = heff_field(v_x111_2421, 0);
        V v_xsp_2424 = heff_field(v_x111_2421, 1);
        heff_take_n(v_x111_2421, 3ULL, 2);
        switch (heff_tag_of(v_x1111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_x1111_2423, 0);
          heff_take_n(v_x1111_2423, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(3, shape_name__span__ty, (V[]){v_x_2425, v_xsp_2424, v_t_2422})}});
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_na(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EString: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBinary: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERune: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EWord: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProject: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ENamed: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPi: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAnn: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESpec: {
          heff_take_n(v_x1111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESig: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESum: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStruct: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EUpdate: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EMatch: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELetIn: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EDo: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELocal: {
          heff_take_n(v_x1111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInvalid: {
          heff_take_n(v_x1111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1111_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_2421)}});
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etypeL_24cpr(V v_r_240, V v_kw_241, V v_name_242, V v_params_243, V v_body_244, V v_z_245) {
top: ;
  V v_m_247 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_243));
  V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    heff_take_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_body_244);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410}});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2412)));
      V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2413, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1, 1, 5, (V[]){v_m_2414, v_name_242, v_body_244, v_kw_241, v_x_2412}), v_st_2410));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_249)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam0(V self, V *args) {
  V v_m_246 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_246));
}
V g_heff_2esyntax_2esurface_2etypeL_24cpr_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2412);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
      V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
      V v_t_2422 = heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_244)));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2424});
      V v_t_2426 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2421, v_x_2412, heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2425}), v_x_2420});
      V v_t_2427 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2428 = heff_get_n(v_t_2427, 4, 9);
      V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2428});
      V v_t_2430 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_t_2429})});
      V v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2431}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24cpr(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_fields_245, V v_z_246) {
top: ;
  V v_m_248 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop_rec(v_name_243, 9);
      heff_drop(v_fields_245);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2413)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2414, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1, 1, 6, (V[]){v_r_240, v_fields_245, v_name_243, v_d_241, v_kw_242, v_x_2413}), v_st_2411));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam0(V self, V *args) {
  V v_m_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_247));
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2(V self, V *args) {
  V v_f_2416 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2etheoryFieldL(v_r_240, v_f_2416));
}
V g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_fields_245 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_kw_242 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2417 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24cpr_lam2, 1, 1, (V[]){v_r_240}), v_fields_245, v_st_2415));
  {
    V v_field_2418 = v_t_2417.f[0];
    V v_field_2419 = v_t_2417.f[1];
    V v_x11_2420 = v_field_2418;
    V v_st_2421 = v_field_2419;
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Left = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      heff_drop_rec(v_name_243, 9);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_x_2413);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Left, TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_243, 3), heff_take_field(v_name_243, 4)});
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2426});
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_x_2423}), v_t_2427});
      V v_t_2429 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_243, 1, 9), v_t_2424, v_x_2413, v_t_2428});
      V v_t_2430 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
      V v_e_2431 = heff_get_n(v_t_2430, 4, 9);
      V v_t_2432 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2431});
      V v_t_2433 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2432})});
      V v_x_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){v_x_2434}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V v_r_240, V v_d_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    V v_ru_24d_241_24DImport = heff_take_reuse_n(v_d_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_244 = heff_tag_at_n(v_ru_24d_241_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_244, v_z_242}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_247, v_z_242}});
  }
  case TAG_DSig: {
    V v_names_248 = heff_field(v_d_241, 0);
    V v_ty_2410 = heff_field(v_d_241, 2);
    heff_take_n(v_d_241, 5ULL, 3);
    V v_t_2413;
    switch (heff_tag_of(v_names_248)) {
    case TAG_Nil: {
      v_t_2413 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_t_2411 = heff_dup(heff_field(v_names_248, 0));
      v_t_2413 = heff_get_n(v_t_2411, 3, 9);
      break;
    }
    default: heff_nomatch(v_names_248);
    }
    return ({ V a_0 = v_r_240; V a_1 = NTAG(TAG_AsDefinition); V a_2 = v_t_2413; V a_3 = v_names_248; V a_4 = v_ty_2410; V a_5 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esigL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_names_248); r_; });
  }
  case TAG_DInstance: {
    V v_kw_2414 = heff_field(v_d_241, 0);
    V v_names_2415 = heff_field(v_d_241, 1);
    V v_ty_2417 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    return ({ V a_0 = v_r_240; V a_1 = NTAG(TAG_AsInstance); V a_2 = heff_get_n(v_kw_2414, 3, 9); V a_3 = v_names_2415; V a_4 = v_ty_2417; V a_5 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esigL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_names_2415); r_; });
  }
  case TAG_DEqn: {
    V v_names_2418 = heff_field(v_d_241, 0);
    V v_pats_2419 = heff_field(v_d_241, 1);
    V v_rhs_2421 = heff_field(v_d_241, 3);
    V v_w_2422 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 27ULL, 5);
    return ({ V a_0 = v_r_240; V a_1 = v_names_2418; V a_2 = v_pats_2419; V a_3 = v_rhs_2421; V a_4 = v_w_2422; V a_5 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_names_2418); heff_drop(v_w_2422); r_; });
  }
  case TAG_DData: {
    V v_kw_2423 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2424 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2425 = heff_dup(heff_field(v_d_241, 2));
    V v_universe_2426 = heff_dup(heff_field(v_d_241, 3));
    V v_alts_2427 = heff_dup(heff_field(v_d_241, 4));
    return ({ V a_0 = v_r_240; V a_1 = v_d_241; V a_2 = v_kw_2423; V a_3 = v_name_2424; V a_4 = v_params_2425; V a_5 = v_universe_2426; V a_6 = v_alts_2427; V a_7 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_universe_2426); heff_drop(v_alts_2427); r_; });
  }
  case TAG_DType: {
    V v_kw_2428 = heff_field(v_d_241, 0);
    V v_name_2429 = heff_field(v_d_241, 1);
    V v_params_2430 = heff_field(v_d_241, 2);
    V v_body_2432 = heff_field(v_d_241, 4);
    heff_take_n(v_d_241, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24cpr(v_r_240, v_kw_2428, v_name_2429, v_params_2430, v_body_2432, v_z_242));
  }
  case TAG_DTheory: {
    V v_kw_2433 = heff_dup(heff_field(v_d_241, 0));
    V v_name_2434 = heff_dup(heff_field(v_d_241, 1));
    V v_params_2435 = heff_dup(heff_field(v_d_241, 2));
    V v_fields_2437 = heff_dup(heff_field(v_d_241, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24cpr(v_r_240, v_d_241, v_kw_2433, v_name_2434, v_params_2435, v_fields_2437, v_z_242));
  }
  case TAG_DPrimitive: {
    V v_kw_2438 = heff_field(v_d_241, 0);
    V v_x_2439 = heff_field(v_d_241, 1);
    V v_ty_2441 = heff_field(v_d_241, 3);
    heff_take_n(v_d_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(v_r_240, v_kw_2438, v_x_2439, v_ty_2441, v_z_242));
  }
  case TAG_DTest: {
    V v_kw_2442 = heff_field(v_d_241, 0);
    V v_x_2443 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DTest = heff_take_reuse_n(v_d_241, 3ULL, 2);
    heff_drop_rec(v_r_240, 3);
    V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2443, 3), heff_dup(heff_rfield(v_x_2443, 4))});
    V v_t_2445 = heff_tag_at_n(v_ru_24d_241_24DTest, TAG_DeclTest, 2, (V[]){heff_dup(heff_rfield(v_x_2443, 1)), v_t_2444});
    V v_t_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2442, 3, 9), heff_get_n(v_x_2443, 4, 9)});
    V v_t_2447 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
    V v_f_2449 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2448});
    return ((HeffT2){{v_f_2449, v_z_242}});
  }
  case TAG_DWatch: {
    V v_w_2450 = heff_field(v_d_241, 0);
    V v_e_2451 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24DWatch = heff_take_reuse_n(v_d_241, 3ULL, 2);
    V v_m_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_2451)}));
    V v_x1_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_MkPair: {
      V v_x11_2454 = heff_field(v_x1_2453, 0);
      V v_st_2455 = heff_field(v_x1_2453, 1);
      V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
      switch (heff_tag_of(v_x11_2454)) {
      case TAG_Left: {
        V v_e_2456 = heff_field(v_x11_2454, 0);
        V v_ru_24x11_2454_24Left = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
        heff_drop_rec(v_w_2450, 9);
        heff_drop(v_e_2451);
        heff_drop_cell(v_ru_24d_241_24DWatch, 2);
        heff_drop_cell(v_ru_24x1_2453_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2454_24Left, TAG_Left, 1, (V[]){v_e_2456}), v_st_2455}});
      }
      case TAG_Right: {
        V v_x_2457 = heff_field(v_x11_2454, 0);
        V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
        V v_t_2458 = (g_heff_2esyntax_2ecst_2elastE(v_e_2451));
        V v_e_2459 = heff_get_n(v_t_2458, 4, 9);
        V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_2450, 3), v_e_2459});
        V v_d_2461 = heff_tag_at_n(v_ru_24d_241_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2457}), v_t_2460});
        V v_t_2463;
        if (heff_strEq_c(heff_get_n(v_w_2450, 0, 9), ((V)&g_heff_2esyntax_2esurface_2edeclL_24cpr_str0))) {
          v_t_2463 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_2461});
        } else {
          v_t_2463 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_2461});
        }
        V v_x_2464 = heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){v_x_2464}), v_st_2455}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2454)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2453)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabAbove_str0, 68, "`above` names the operators it is above (`below` alone is below all)");
Clo g_heff_2esyntax_2esurface_2eabAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabAbove_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eabAbove(V v_acc_240, V v_w_241, V v_ops_242) {
top: ;
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_241, 2), heff_get_n(v_w_241, 3, 7)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eabAbove_str0), v_t_243, NTAG(TAG_Nothing)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_240, 3)});
    return ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_240, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Cons: {
    heff_drop_rec(v_w_241, 7);
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_acc_240, 0), v_ops_242));
    return ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_240, 14ULL, 4, shape_above__below__loosest__errors, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabAbove(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2esyntax_2esurface_2efixDiagsOf(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_x_243)));
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_lit_240, v_lit_241, v_xs_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2ereadPlaced_24cpr_lam0(V self, V *args);

HeffT4 g_heff_2esyntax_2esurface_2ereadPlaced_24cpr(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_placed_244, 0)));
  V v_t_246 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_f_247 = ({ V a_0 = v_t_246; V a_1 = v_items_245; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_placed_244, 2, 3)));
  V v_items_249 = heff_dup(heff_rfield(v_r_243, 0));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2esigNames(v_items_249));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_249));
  V v_t_2413 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_t_2412; V a_3 = v_items_249; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_t_2411); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2413));
  V v_t_2415 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2419 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_24cpr_lam0, 2, 1, (V[]){v_at_240}), v_t_2415, heff_rfield(v_r_243, 0)));
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2419, 3, 4)));
  V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2414, v_t_2420));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eappendS(v_t_248, v_t_2421));
  V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_r_243, 1), v_t_2422));
  V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_own_242, 1), v_t_2423));
  V v_f_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2424));
  V v_f_2426 = heff_get_n(v_own_242, 0, 2);
  V v_f_2427 = heff_get_n(v_r_243, 2, 3);
  return ((HeffT4){{v_f_247, v_f_2425, v_f_2426, v_f_2427}});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_24cpr_lam0(V self, V *args) {
  V v_d_2416 = args[0];
  V v_it_2417 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2416, 2)), v_it_2417));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2416; V a_2 = v_t_2418; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_24cpr_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_24cpr_str3, 1, ":");
V g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam1(V self, V *args);

HeffT4 g_heff_2esyntax_2esurface_2ereadRun_24cpr(V v_src_240, V v_o_241, V v_toks_242, V v_lexDiags_243, V v_declared_244, V v_own_245) {
top: ;
  V v_path_246 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_path_248 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2einitialSt(v_o_241, heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam0, 1, 2, (V[]){v_path_248, heff_dup(v_src_240)}), heff_dup(v_toks_242), v_declared_244, heff_dup(heff_rfield(v_own_245, 0))));
  V v_r_2413 = (g_heff_2esyntax_2esurface_2eprogGo(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_242, MK_INT(0LL), MK_INT(0LL), v_t_247, MK_INT(0LL)}), v_t_2412, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2414 = (g_heff_2esyntax_2esurface_2eplaceDocs(heff_dup(v_src_240), heff_rfield(v_r_2413, 0)));
  return (g_heff_2esyntax_2esurface_2ereadPlaced_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam1, 1, 2, (V[]){v_path_246, v_src_240}), v_lexDiags_243, v_own_245, v_r_2413, v_t_2414));
}
V g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_248, ((V)&g_heff_2esyntax_2esurface_2ereadRun_24cpr_str0), 2)) {
    heff_drop(v_path_248);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2411 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_248, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_24cpr_str1), v_t_2411));
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_24cpr_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c_lent(v_path_246, ((V)&g_heff_2esyntax_2esurface_2ereadRun_24cpr_str2), 2)) {
    heff_drop(v_path_246);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2417 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_246, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_24cpr_str3), v_t_2417));
  }
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ereadLexed(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  HeffT4 v_t_243 = (g_heff_2esyntax_2esurface_2ereadLexed_24cpr(v_src_240, v_o_241, v_l_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_field_247 = v_t_243.f[3];
    return heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){v_field_244, v_field_245, v_field_246, v_field_247});
  }
}
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadLexed(a[0], a[1], a[2]);
}