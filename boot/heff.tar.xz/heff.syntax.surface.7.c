// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclDefine 5286
#define TAG_DeclTest 38719
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_head 9693863
#define LBL_i 323
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_waiting 1348170899
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2etoks_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etoks_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etoks_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eabAbove(V, V, V);
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabAbove_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_clo;
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(V, V);
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclAt(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclAt_clo;
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2eplaceDocs(V, V);
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo;
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esettingsOf(V);
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingsOf_clo;
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_clo;
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s589588949x194367275(V, V, V);
V g_list_2efoldl_24s589588949x194367275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s589588949x194367275_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_heff_2esyntax_2esurface_2etraverseS(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2esurface_2epiBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiBinders_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_b_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      V v_t_2432;
      switch (heff_tag_of(v_b_2417)) {
      case TAG_PiNamed: {
        V v_x_2419 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 3);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 5);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 4);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2417);
      }
      V v_t_2433 = (g_heff_2esyntax_2esurface_2epiBinders(v_rest_2418));
      return (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_t_2433));
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiBinders(a[0]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2easBinderOn(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EBytes: {
      V v_ru_24e1_242_24EBytes = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBytes, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ENamed: {
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EAnn: {
      V v_g_2422 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2422)));
      V v_t_2426 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2422));
      V v_t_2427 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2425, 0, 2), heff_get_n(v_t_2426, 1, 2)});
      V v_t_2428 = (g_list_2emap_24s878634257x1677201747(v_t_2427));
      V v_sc_2429 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(heff_take_field(v_p_241, 1), v_t_2428));
      V v_t_2430 = ({ V rv_1 = v_sc_2429; V rr_ = heff_rec_reuse_nf(v_p_241, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x1_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2430});
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_MkPair: {
        V v_x11_2432 = heff_field(v_x1_2431, 0);
        V v_st_2433 = heff_field(v_x1_2431, 1);
        V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
        switch (heff_tag_of(v_x11_2432)) {
        case TAG_Left: {
          V v_e_2434 = heff_field(v_x11_2432, 0);
          heff_take_n(v_x11_2432, 1ULL, 1);
          heff_drop_tag(v_e_240, 2);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2432, 0ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_st_2433});
        }
        default: return heff_nomatch(v_x11_2432);
        }
      }
      default: return heff_nomatch(v_x1_2431);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_242_24EUpdate = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2enameBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameBinder(V v_e0_240) {
top: ;
  switch (heff_tag_of(v_e0_240)) {
  case TAG_At: {
    V v_e01_241 = heff_dup(heff_field(v_e0_240, 0));
    switch (heff_tag_of(v_e01_241)) {
    case TAG_EVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETag: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EInt: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EFloat: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EString: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EBytes: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EAnn: {
      V v_g_2421 = heff_field(v_e01_241, 0);
      V v_t_2422 = heff_field(v_e01_241, 1);
      V v_ru_24e01_241_24EAnn = heff_take_reuse_n(v_e01_241, 3ULL, 2);
      heff_drop_tag(v_e0_240, 2);
      V v_t_2423 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2425 = heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2423, 0, 2), heff_get_n(v_t_2424, 1, 2)});
      V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a_0)); heff_drop_tag(v_t_2425, 2); r_; });
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
        V v_t_2428 = (g_heff_2esyntax_2esurface_2easNameE(heff_get_n(v_t_2427, 0, 2)));
        V v_t_2429 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2421));
        V v_t_2430 = (g_list_2emap_24s1624059865x1140896478(heff_get_n(v_t_2429, 1, 2)));
        V v_e_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, v_t_2430));
        V v_a_2434;
        switch (heff_tag_of(v_e_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_e_2431, 1));
          v_a_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_e_2431);
        }
        V v_b_2437;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_t_2422, 1));
          v_b_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2438 = ({ V rv_1 = heff_get_n(v_b_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_2431, v_t_2422}), v_t_2438});
      } else {
        heff_drop(v_t_2426);
        V v_a_2441;
        switch (heff_tag_of(v_g_2421)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_g_2421, 1));
          v_a_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_g_2421);
        }
        V v_b_2444;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2422, 1));
          v_b_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2445 = ({ V rv_1 = heff_get_n(v_b_2444, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2441, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2445});
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    default: return heff_nomatch(v_e01_241);
    }
  }
  default: return heff_nomatch(v_e0_240);
  }
}
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2enameBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eeqnNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eeqnNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Eqn: {
      V v_f_248 = heff_field(v_x11_241, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnNames(v_rest_242));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_248), NTAG(TAG_MkUnit), v_t_2411));
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eeqnNames(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceDocs_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eplaceDocs(V v_src_240, V v_items_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_items__waiting__diags, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_p_245 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2eplaceDocs_lam0, 2, 1, (V[]){v_src_240}), v_t_242, v_items_241));
  V v_items_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_245, 0), heff_dup(heff_rfield(v_p_245, 1))));
  V v_diags_247 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_245, 2), heff_get_n(v_p_245, 1, 3)));
  return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_246, NTAG(TAG_Nil), v_diags_247});
}
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eplaceDocs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_it_244 = args[1];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eplaceStep(v_src_240, v_p_243, v_it_244));
}
Clo g_heff_2esyntax_2esurface_2epathOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epathOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epathOf(V v_e_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_take_field(v_x_242, 4)});
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_242, 1, 9), v_t_243});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_acc_241});
  }
  case TAG_EParen: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Named: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Tup: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Braces: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Update: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EUSet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_InstB: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_EFSet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EFDefault: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Sum: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_ECon: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EField: {
    V v_e1_2448 = heff_field(v_e_240, 0);
    V v_f_2449 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EField = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_f_2449, 3), heff_take_field(v_f_2449, 4)});
    V v_t_2451 = heff_tag_at_n(v_ru_24e_240_24EField, TAG_MkPair, 2, (V[]){heff_get_n(v_f_2449, 1, 9), v_t_2450});
    V t_0 = v_e1_2448;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_acc_241});
    v_e_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_App: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Op: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Ops: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_OpRhs: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Ann: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_BImp: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BAnn: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Lam: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Case: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EAlt: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_If: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_Do: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ESBind: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epathOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 2);
    V v_t_2411;
    switch (heff_tag_of(v_t_243)) {
    case TAG_LamName: {
      V v_x_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamImplicit: {
      V v_x_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamAnn: {
      V v_x_248 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 3);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str1, 45, "a specialisation sets fields: `T ~ { x = v }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str2, 50, "a specialisation sets a field by its name: `x = v`");
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eopL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243, V v_z_244) {
top: ;
  if (heff_strEq_c(heff_get_n(v_op_242, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eopL_str0))) {
    V v_t_246 = (g_heff_2esyntax_2esurface_2ebracedOne(v_a_241));
    V v_m_24341;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_a_241)) {
      case TAG_Atom: {
        V v_m_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam0, 1, 1, (V[]){v_m_248});
        break;
      }
      case TAG_EParen: {
        V v_m_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam1, 1, 1, (V[]){v_m_2419});
        break;
      }
      case TAG_Named: {
        V v_m_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam2, 1, 1, (V[]){v_m_2432});
        break;
      }
      case TAG_Tup: {
        V v_m_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam3, 1, 1, (V[]){v_m_2444});
        break;
      }
      case TAG_Braces: {
        V v_m_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam4, 1, 1, (V[]){v_m_2456});
        break;
      }
      case TAG_Update: {
        V v_m_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam5, 1, 1, (V[]){v_m_2470});
        break;
      }
      case TAG_EUSet: {
        V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam6, 1, 1, (V[]){v_m_2481});
        break;
      }
      case TAG_InstB: {
        V v_o_2489 = heff_field(v_a_241, 0);
        V v_d_2491 = heff_field(v_a_241, 2);
        V v_c_2493 = heff_field(v_a_241, 4);
        heff_take_n(v_a_241, 21ULL, 5);
        V v_m_2494 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_d_2491));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam7, 1, 3, (V[]){v_m_2494, v_o_2489, v_c_2493});
        break;
      }
      case TAG_EFSet: {
        V v_m_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam8, 1, 1, (V[]){v_m_24106});
        break;
      }
      case TAG_EFDefault: {
        V v_m_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam9, 1, 1, (V[]){v_m_24117});
        break;
      }
      case TAG_Sum: {
        V v_m_24130 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam10, 1, 1, (V[]){v_m_24130});
        break;
      }
      case TAG_ECon: {
        V v_m_24140 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam11, 1, 1, (V[]){v_m_24140});
        break;
      }
      case TAG_EField: {
        V v_m_24150 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam12, 1, 1, (V[]){v_m_24150});
        break;
      }
      case TAG_ENeg: {
        V v_m_24160 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam13, 1, 1, (V[]){v_m_24160});
        break;
      }
      case TAG_App: {
        V v_m_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam14, 1, 1, (V[]){v_m_24170});
        break;
      }
      case TAG_Op: {
        V v_m_24181 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam15, 1, 1, (V[]){v_m_24181});
        break;
      }
      case TAG_Ops: {
        V v_m_24191 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam16, 1, 1, (V[]){v_m_24191});
        break;
      }
      case TAG_OpRhs: {
        V v_m_24201 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam17, 1, 1, (V[]){v_m_24201});
        break;
      }
      case TAG_Ann: {
        V v_m_24212 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam18, 1, 1, (V[]){v_m_24212});
        break;
      }
      case TAG_BVar: {
        V v_m_24221 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam19, 1, 1, (V[]){v_m_24221});
        break;
      }
      case TAG_BImp: {
        V v_m_24232 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam20, 1, 1, (V[]){v_m_24232});
        break;
      }
      case TAG_BAnn: {
        V v_m_24245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam21, 1, 1, (V[]){v_m_24245});
        break;
      }
      case TAG_Lam: {
        V v_m_24257 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam22, 1, 1, (V[]){v_m_24257});
        break;
      }
      case TAG_Case: {
        V v_m_24269 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam23, 1, 1, (V[]){v_m_24269});
        break;
      }
      case TAG_EAlt: {
        V v_m_24280 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam24, 1, 1, (V[]){v_m_24280});
        break;
      }
      case TAG_If: {
        V v_m_24294 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam25, 1, 1, (V[]){v_m_24294});
        break;
      }
      case TAG_Do: {
        V v_m_24304 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam26, 1, 1, (V[]){v_m_24304});
        break;
      }
      case TAG_ESBind: {
        V v_m_24315 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam27, 1, 1, (V[]){v_m_24315});
        break;
      }
      case TAG_ELet: {
        V v_m_24329 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24341 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam28, 1, 1, (V[]){v_m_24329});
        break;
      }
      default: heff_nomatch(v_a_241);
      }
      break;
    }
    case TAG_Just: {
      V v_f_24337 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_a_24338 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241));
      V v_b_24339 = (g_heff_2esyntax_2ecst_2elastE(v_a_241));
      V v_t_24340 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24338, 3, 9), heff_get_n(v_b_24339, 4, 9)});
      v_m_24341 = (g_heff_2esyntax_2esurface_2ebracedL(heff_dup(v_r_240), v_f_24337, v_t_24340));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_x1_24342 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24342)) {
    case TAG_MkPair: {
      V v_x11_24343 = heff_field(v_x1_24342, 0);
      V v_st_24344 = heff_field(v_x1_24342, 1);
      V v_ru_24x1_24342_24MkPair = heff_take_reuse_n(v_x1_24342, 3ULL, 2);
      switch (heff_tag_of(v_x11_24343)) {
      case TAG_Left: {
        V v_e_24345 = heff_field(v_x11_24343, 0);
        heff_take_n(v_x11_24343, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24345}), v_st_24344});
      }
      case TAG_Right: {
        V v_x_24346 = heff_field(v_x11_24343, 0);
        heff_take_n(v_x11_24343, 1ULL, 1);
        V v_m_24347 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
        V v_x1_24348 = heff_tr(heff_call(v_m_24347, 1, (V[]){v_st_24344}));
        switch (heff_tag_of(v_x1_24348)) {
        case TAG_MkPair: {
          V v_x11_24349 = heff_field(v_x1_24348, 0);
          V v_st_24350 = heff_field(v_x1_24348, 1);
          heff_take_n(v_x1_24348, 3ULL, 2);
          switch (heff_tag_of(v_x11_24349)) {
          case TAG_Left: {
            V v_e_24351 = heff_field(v_x11_24349, 0);
            heff_take_n(v_x11_24349, 1ULL, 1);
            heff_drop(v_x_24346);
            return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24351}), v_st_24350});
          }
          case TAG_Right: {
            V v_x_24352 = heff_field(v_x11_24349, 0);
            heff_take_n(v_x11_24349, 1ULL, 1);
            V v_x_24353 = heff_tr(g_heff_2esyntax_2esurface_2earrowBinop(v_x_24346, v_x_24352));
            return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24353}), v_st_24350});
          }
          default: return heff_nomatch(v_x11_24349);
          }
        }
        default: return heff_nomatch(v_x1_24348);
        }
      }
      default: return heff_nomatch(v_x11_24343);
      }
    }
    default: return heff_nomatch(v_x1_24342);
    }
  } else {
    V v_m_24354 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
    V v_x1_24355 = heff_tr(heff_call(v_m_24354, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24355)) {
    case TAG_MkPair: {
      V v_x11_24356 = heff_field(v_x1_24355, 0);
      V v_st_24357 = heff_field(v_x1_24355, 1);
      V v_ru_24x1_24355_24MkPair = heff_take_reuse_n(v_x1_24355, 3ULL, 2);
      switch (heff_tag_of(v_x11_24356)) {
      case TAG_Left: {
        V v_e_24358 = heff_field(v_x11_24356, 0);
        heff_take_n(v_x11_24356, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24355_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24358}), v_st_24357});
      }
      case TAG_Right: {
        V v_x_24359 = heff_field(v_x11_24356, 0);
        V v_ru_24x11_24356_24Right = heff_take_reuse_n(v_x11_24356, 1ULL, 1);
        V v_t_24360 = (g_heff_2esyntax_2esurface_2esettingsOf(v_b_243));
        switch (heff_tag_of(v_t_24360)) {
        case TAG_Nothing: {
          V v_m_24361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
          V v_x1_24362 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_st_24357}));
          switch (heff_tag_of(v_x1_24362)) {
          case TAG_MkPair: {
            V v_x11_24363 = heff_field(v_x1_24362, 0);
            V v_st_24364 = heff_field(v_x1_24362, 1);
            V v_ru_24x1_24362_24MkPair = heff_take_reuse_n(v_x1_24362, 3ULL, 2);
            switch (heff_tag_of(v_x11_24363)) {
            case TAG_Left: {
              V v_e_24365 = heff_field(v_x11_24363, 0);
              heff_take_n(v_x11_24363, 1ULL, 1);
              heff_drop(v_x_24359);
              heff_drop_cell(v_ru_24x11_24356_24Right, 1);
              heff_drop_cell(v_ru_24x1_24362_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_24355_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24365}), v_st_24364});
            }
            case TAG_Right: {
              V v_x_24366 = heff_field(v_x11_24363, 0);
              heff_take_n(v_x11_24363, 1ULL, 1);
              V v_a_24369;
              switch (heff_tag_of(v_x_24359)) {
              case TAG_At: {
                V v_s_24368 = heff_field(v_x_24359, 1);
                heff_take_n(v_x_24359, 2ULL, 2);
                v_a_24369 = v_s_24368;
                break;
              }
              default: heff_nomatch(v_x_24359);
              }
              V v_b_24372;
              switch (heff_tag_of(v_x_24366)) {
              case TAG_At: {
                V v_s_24371 = heff_field(v_x_24366, 1);
                heff_take_n(v_x_24366, 2ULL, 2);
                v_b_24372 = v_s_24371;
                break;
              }
              default: heff_nomatch(v_x_24366);
              }
              V v_t_24373 = ({ V rv_1 = heff_get_n(v_b_24372, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_24369, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_x_24374 = heff_tag_at_n(v_ru_24x1_24355_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eopL_str1)}), v_t_24373});
              return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24356_24Right, TAG_Right, 1, (V[]){v_x_24374}), v_st_24364});
            }
            default: return heff_nomatch(v_x11_24363);
            }
          }
          default: return heff_nomatch(v_x1_24362);
          }
        }
        case TAG_Just: {
          V v_fs_24375 = heff_field(v_t_24360, 0);
          heff_take_n(v_t_24360, 1ULL, 1);
          heff_drop(v_b_243);
          heff_drop_cell(v_ru_24x11_24356_24Right, 1);
          V v_m_24377 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam29, 1, 1, (V[]){v_r_240}), v_fs_24375));
          V v_x1_24378 = heff_tr(heff_call(v_m_24377, 1, (V[]){v_st_24357}));
          switch (heff_tag_of(v_x1_24378)) {
          case TAG_MkPair: {
            V v_x11_24379 = heff_field(v_x1_24378, 0);
            V v_st_24380 = heff_field(v_x1_24378, 1);
            heff_take_n(v_x1_24378, 3ULL, 2);
            switch (heff_tag_of(v_x11_24379)) {
            case TAG_Left: {
              V v_e_24381 = heff_field(v_x11_24379, 0);
              heff_take_n(v_x11_24379, 1ULL, 1);
              heff_drop(v_x_24359);
              return heff_tag_at_n(v_ru_24x1_24355_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24381}), v_st_24380});
            }
            case TAG_Right: {
              V v_x_24382 = heff_field(v_x11_24379, 0);
              heff_take_n(v_x11_24379, 1ULL, 1);
              V v_x_24383 = (g_list_2efoldl_24s589588949x194367275(((V)&g_heff_2esyntax_2esurface_2eopL_str2), v_x_24359, v_x_24382));
              return heff_tag_at_n(v_ru_24x1_24355_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24383}), v_st_24380});
            }
            default: return heff_nomatch(v_x11_24379);
            }
          }
          default: return heff_nomatch(v_x1_24378);
          }
        }
        default: return heff_nomatch(v_t_24360);
        }
      }
      default: return heff_nomatch(v_x11_24356);
      }
    }
    default: return heff_nomatch(v_x1_24355);
    }
  }
}
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2414})});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args) {
  V v_st_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_st_2420}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_MkPair: {
    V v_x11_2422 = heff_field(v_x1_2421, 0);
    V v_st_2423 = heff_field(v_x1_2421, 1);
    V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
    switch (heff_tag_of(v_x11_2422)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x11_2422, 0);
      heff_take_n(v_x11_2422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x11_2422, 0);
      V v_ru_24x11_2422_24Right = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
      V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2425})});
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2423});
    }
    default: return heff_nomatch(v_x11_2422);
    }
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args) {
  V v_st_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_st_2433}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_MkPair: {
    V v_x11_2435 = heff_field(v_x1_2434, 0);
    V v_st_2436 = heff_field(v_x1_2434, 1);
    V v_ru_24x1_2434_24MkPair = heff_take_reuse_n(v_x1_2434, 3ULL, 2);
    switch (heff_tag_of(v_x11_2435)) {
    case TAG_Left: {
      V v_e_2437 = heff_field(v_x11_2435, 0);
      heff_take_n(v_x11_2435, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2437}), v_st_2436});
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_x11_2435, 0);
      V v_ru_24x11_2435_24Right = heff_take_reuse_n(v_x11_2435, 1ULL, 1);
      V v_t_2439 = heff_tag_at_n(v_ru_24x11_2435_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2438})});
      return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2439, v_st_2436});
    }
    default: return heff_nomatch(v_x11_2435);
    }
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args) {
  V v_st_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_st_2445}));
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_MkPair: {
    V v_x11_2447 = heff_field(v_x1_2446, 0);
    V v_st_2448 = heff_field(v_x1_2446, 1);
    V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
    switch (heff_tag_of(v_x11_2447)) {
    case TAG_Left: {
      V v_e_2449 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
    }
    case TAG_Right: {
      V v_x_2450 = heff_field(v_x11_2447, 0);
      V v_ru_24x11_2447_24Right = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
      V v_t_2451 = heff_tag_at_n(v_ru_24x11_2447_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2450})});
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){v_t_2451, v_st_2448});
    }
    default: return heff_nomatch(v_x11_2447);
    }
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args) {
  V v_st_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_st_2457}));
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_MkPair: {
    V v_x11_2459 = heff_field(v_x1_2458, 0);
    V v_st_2460 = heff_field(v_x1_2458, 1);
    V v_ru_24x1_2458_24MkPair = heff_take_reuse_n(v_x1_2458, 3ULL, 2);
    switch (heff_tag_of(v_x11_2459)) {
    case TAG_Left: {
      V v_e_2461 = heff_field(v_x11_2459, 0);
      heff_take_n(v_x11_2459, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2461}), v_st_2460});
    }
    case TAG_Right: {
      V v_x_2462 = heff_field(v_x11_2459, 0);
      V v_ru_24x11_2459_24Right = heff_take_reuse_n(v_x11_2459, 1ULL, 1);
      V v_t_2463 = heff_tag_at_n(v_ru_24x11_2459_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2462})});
      return heff_tag_at_n(v_ru_24x1_2458_24MkPair, TAG_MkPair, 2, (V[]){v_t_2463, v_st_2460});
    }
    default: return heff_nomatch(v_x11_2459);
    }
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args) {
  V v_st_2471 = args[0];
  V v_m_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2472 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_st_2471}));
  switch (heff_tag_of(v_x1_2472)) {
  case TAG_MkPair: {
    V v_x11_2473 = heff_field(v_x1_2472, 0);
    V v_st_2474 = heff_field(v_x1_2472, 1);
    V v_ru_24x1_2472_24MkPair = heff_take_reuse_n(v_x1_2472, 3ULL, 2);
    switch (heff_tag_of(v_x11_2473)) {
    case TAG_Left: {
      V v_e_2475 = heff_field(v_x11_2473, 0);
      heff_take_n(v_x11_2473, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2475}), v_st_2474});
    }
    case TAG_Right: {
      V v_x_2476 = heff_field(v_x11_2473, 0);
      V v_ru_24x11_2473_24Right = heff_take_reuse_n(v_x11_2473, 1ULL, 1);
      V v_t_2477 = heff_tag_at_n(v_ru_24x11_2473_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2476})});
      return heff_tag_at_n(v_ru_24x1_2472_24MkPair, TAG_MkPair, 2, (V[]){v_t_2477, v_st_2474});
    }
    default: return heff_nomatch(v_x11_2473);
    }
  }
  default: return heff_nomatch(v_x1_2472);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args) {
  V v_st_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_st_2482}));
  switch (heff_tag_of(v_x1_2483)) {
  case TAG_MkPair: {
    V v_x11_2484 = heff_field(v_x1_2483, 0);
    V v_st_2485 = heff_field(v_x1_2483, 1);
    V v_ru_24x1_2483_24MkPair = heff_take_reuse_n(v_x1_2483, 3ULL, 2);
    switch (heff_tag_of(v_x11_2484)) {
    case TAG_Left: {
      V v_e_2486 = heff_field(v_x11_2484, 0);
      heff_take_n(v_x11_2484, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2486}), v_st_2485});
    }
    case TAG_Right: {
      V v_x_2487 = heff_field(v_x11_2484, 0);
      V v_ru_24x11_2484_24Right = heff_take_reuse_n(v_x11_2484, 1ULL, 1);
      V v_t_2488 = heff_tag_at_n(v_ru_24x11_2484_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2487})});
      return heff_tag_at_n(v_ru_24x1_2483_24MkPair, TAG_MkPair, 2, (V[]){v_t_2488, v_st_2485});
    }
    default: return heff_nomatch(v_x11_2484);
    }
  }
  default: return heff_nomatch(v_x1_2483);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  V v_o_2489 = heff_env(self)[1];
  V v_c_2493 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      heff_drop_rec(v_o_2489, 9);
      heff_drop_rec(v_c_2493, 9);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24101 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2489, 3, 9), heff_get_n(v_c_2493, 4, 9)});
      V v_t_24102 = heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_Bracketed, 2, (V[]){v_x_24100, v_t_24101})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24102, v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args) {
  V v_st_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_st_24107}));
  switch (heff_tag_of(v_x1_24108)) {
  case TAG_MkPair: {
    V v_x11_24109 = heff_field(v_x1_24108, 0);
    V v_st_24110 = heff_field(v_x1_24108, 1);
    V v_ru_24x1_24108_24MkPair = heff_take_reuse_n(v_x1_24108, 3ULL, 2);
    switch (heff_tag_of(v_x11_24109)) {
    case TAG_Left: {
      V v_e_24111 = heff_field(v_x11_24109, 0);
      heff_take_n(v_x11_24109, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24111}), v_st_24110});
    }
    case TAG_Right: {
      V v_x_24112 = heff_field(v_x11_24109, 0);
      V v_ru_24x11_24109_24Right = heff_take_reuse_n(v_x11_24109, 1ULL, 1);
      V v_t_24113 = heff_tag_at_n(v_ru_24x11_24109_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24112})});
      return heff_tag_at_n(v_ru_24x1_24108_24MkPair, TAG_MkPair, 2, (V[]){v_t_24113, v_st_24110});
    }
    default: return heff_nomatch(v_x11_24109);
    }
  }
  default: return heff_nomatch(v_x1_24108);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args) {
  V v_st_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_st_24118}));
  switch (heff_tag_of(v_x1_24119)) {
  case TAG_MkPair: {
    V v_x11_24120 = heff_field(v_x1_24119, 0);
    V v_st_24121 = heff_field(v_x1_24119, 1);
    V v_ru_24x1_24119_24MkPair = heff_take_reuse_n(v_x1_24119, 3ULL, 2);
    switch (heff_tag_of(v_x11_24120)) {
    case TAG_Left: {
      V v_e_24122 = heff_field(v_x11_24120, 0);
      heff_take_n(v_x11_24120, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24122}), v_st_24121});
    }
    case TAG_Right: {
      V v_x_24123 = heff_field(v_x11_24120, 0);
      V v_ru_24x11_24120_24Right = heff_take_reuse_n(v_x11_24120, 1ULL, 1);
      V v_t_24124 = heff_tag_at_n(v_ru_24x11_24120_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24123})});
      return heff_tag_at_n(v_ru_24x1_24119_24MkPair, TAG_MkPair, 2, (V[]){v_t_24124, v_st_24121});
    }
    default: return heff_nomatch(v_x11_24120);
    }
  }
  default: return heff_nomatch(v_x1_24119);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args) {
  V v_st_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24132 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_st_24131}));
  switch (heff_tag_of(v_x1_24132)) {
  case TAG_MkPair: {
    V v_x11_24133 = heff_field(v_x1_24132, 0);
    V v_st_24134 = heff_field(v_x1_24132, 1);
    V v_ru_24x1_24132_24MkPair = heff_take_reuse_n(v_x1_24132, 3ULL, 2);
    switch (heff_tag_of(v_x11_24133)) {
    case TAG_Left: {
      V v_e_24135 = heff_field(v_x11_24133, 0);
      heff_take_n(v_x11_24133, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24135}), v_st_24134});
    }
    case TAG_Right: {
      V v_x_24136 = heff_field(v_x11_24133, 0);
      V v_ru_24x11_24133_24Right = heff_take_reuse_n(v_x11_24133, 1ULL, 1);
      V v_t_24137 = heff_tag_at_n(v_ru_24x11_24133_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24136})});
      return heff_tag_at_n(v_ru_24x1_24132_24MkPair, TAG_MkPair, 2, (V[]){v_t_24137, v_st_24134});
    }
    default: return heff_nomatch(v_x11_24133);
    }
  }
  default: return heff_nomatch(v_x1_24132);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args) {
  V v_st_24141 = args[0];
  V v_m_24140 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24142 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_st_24141}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_MkPair: {
    V v_x11_24143 = heff_field(v_x1_24142, 0);
    V v_st_24144 = heff_field(v_x1_24142, 1);
    V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
    switch (heff_tag_of(v_x11_24143)) {
    case TAG_Left: {
      V v_e_24145 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
    }
    case TAG_Right: {
      V v_x_24146 = heff_field(v_x11_24143, 0);
      V v_ru_24x11_24143_24Right = heff_take_reuse_n(v_x11_24143, 1ULL, 1);
      V v_t_24147 = heff_tag_at_n(v_ru_24x11_24143_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24146})});
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){v_t_24147, v_st_24144});
    }
    default: return heff_nomatch(v_x11_24143);
    }
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args) {
  V v_st_24151 = args[0];
  V v_m_24150 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24152 = heff_tr(heff_call(v_m_24150, 1, (V[]){v_st_24151}));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_MkPair: {
    V v_x11_24153 = heff_field(v_x1_24152, 0);
    V v_st_24154 = heff_field(v_x1_24152, 1);
    V v_ru_24x1_24152_24MkPair = heff_take_reuse_n(v_x1_24152, 3ULL, 2);
    switch (heff_tag_of(v_x11_24153)) {
    case TAG_Left: {
      V v_e_24155 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24155}), v_st_24154});
    }
    case TAG_Right: {
      V v_x_24156 = heff_field(v_x11_24153, 0);
      V v_ru_24x11_24153_24Right = heff_take_reuse_n(v_x11_24153, 1ULL, 1);
      V v_t_24157 = heff_tag_at_n(v_ru_24x11_24153_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24156})});
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){v_t_24157, v_st_24154});
    }
    default: return heff_nomatch(v_x11_24153);
    }
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args) {
  V v_st_24161 = args[0];
  V v_m_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24162 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_st_24161}));
  switch (heff_tag_of(v_x1_24162)) {
  case TAG_MkPair: {
    V v_x11_24163 = heff_field(v_x1_24162, 0);
    V v_st_24164 = heff_field(v_x1_24162, 1);
    V v_ru_24x1_24162_24MkPair = heff_take_reuse_n(v_x1_24162, 3ULL, 2);
    switch (heff_tag_of(v_x11_24163)) {
    case TAG_Left: {
      V v_e_24165 = heff_field(v_x11_24163, 0);
      heff_take_n(v_x11_24163, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24162_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24165}), v_st_24164});
    }
    case TAG_Right: {
      V v_x_24166 = heff_field(v_x11_24163, 0);
      V v_ru_24x11_24163_24Right = heff_take_reuse_n(v_x11_24163, 1ULL, 1);
      V v_t_24167 = heff_tag_at_n(v_ru_24x11_24163_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24166})});
      return heff_tag_at_n(v_ru_24x1_24162_24MkPair, TAG_MkPair, 2, (V[]){v_t_24167, v_st_24164});
    }
    default: return heff_nomatch(v_x11_24163);
    }
  }
  default: return heff_nomatch(v_x1_24162);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args) {
  V v_st_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_st_24171}));
  switch (heff_tag_of(v_x1_24172)) {
  case TAG_MkPair: {
    V v_x11_24173 = heff_field(v_x1_24172, 0);
    V v_st_24174 = heff_field(v_x1_24172, 1);
    V v_ru_24x1_24172_24MkPair = heff_take_reuse_n(v_x1_24172, 3ULL, 2);
    switch (heff_tag_of(v_x11_24173)) {
    case TAG_Left: {
      V v_e_24175 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24175}), v_st_24174});
    }
    case TAG_Right: {
      V v_x_24176 = heff_field(v_x11_24173, 0);
      V v_ru_24x11_24173_24Right = heff_take_reuse_n(v_x11_24173, 1ULL, 1);
      V v_t_24177 = heff_tag_at_n(v_ru_24x11_24173_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24176})});
      return heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, (V[]){v_t_24177, v_st_24174});
    }
    default: return heff_nomatch(v_x11_24173);
    }
  }
  default: return heff_nomatch(v_x1_24172);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24188 = heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24187})});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){v_t_24188, v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args) {
  V v_st_24192 = args[0];
  V v_m_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24193 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_st_24192}));
  switch (heff_tag_of(v_x1_24193)) {
  case TAG_MkPair: {
    V v_x11_24194 = heff_field(v_x1_24193, 0);
    V v_st_24195 = heff_field(v_x1_24193, 1);
    V v_ru_24x1_24193_24MkPair = heff_take_reuse_n(v_x1_24193, 3ULL, 2);
    switch (heff_tag_of(v_x11_24194)) {
    case TAG_Left: {
      V v_e_24196 = heff_field(v_x11_24194, 0);
      heff_take_n(v_x11_24194, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24196}), v_st_24195});
    }
    case TAG_Right: {
      V v_x_24197 = heff_field(v_x11_24194, 0);
      V v_ru_24x11_24194_24Right = heff_take_reuse_n(v_x11_24194, 1ULL, 1);
      V v_t_24198 = heff_tag_at_n(v_ru_24x11_24194_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24197})});
      return heff_tag_at_n(v_ru_24x1_24193_24MkPair, TAG_MkPair, 2, (V[]){v_t_24198, v_st_24195});
    }
    default: return heff_nomatch(v_x11_24194);
    }
  }
  default: return heff_nomatch(v_x1_24193);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args) {
  V v_st_24202 = args[0];
  V v_m_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24203 = heff_tr(heff_call(v_m_24201, 1, (V[]){v_st_24202}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_MkPair: {
    V v_x11_24204 = heff_field(v_x1_24203, 0);
    V v_st_24205 = heff_field(v_x1_24203, 1);
    V v_ru_24x1_24203_24MkPair = heff_take_reuse_n(v_x1_24203, 3ULL, 2);
    switch (heff_tag_of(v_x11_24204)) {
    case TAG_Left: {
      V v_e_24206 = heff_field(v_x11_24204, 0);
      heff_take_n(v_x11_24204, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24203_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24206}), v_st_24205});
    }
    case TAG_Right: {
      V v_x_24207 = heff_field(v_x11_24204, 0);
      V v_ru_24x11_24204_24Right = heff_take_reuse_n(v_x11_24204, 1ULL, 1);
      V v_t_24208 = heff_tag_at_n(v_ru_24x11_24204_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24207})});
      return heff_tag_at_n(v_ru_24x1_24203_24MkPair, TAG_MkPair, 2, (V[]){v_t_24208, v_st_24205});
    }
    default: return heff_nomatch(v_x11_24204);
    }
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args) {
  V v_st_24213 = args[0];
  V v_m_24212 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24214 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_st_24213}));
  switch (heff_tag_of(v_x1_24214)) {
  case TAG_MkPair: {
    V v_x11_24215 = heff_field(v_x1_24214, 0);
    V v_st_24216 = heff_field(v_x1_24214, 1);
    V v_ru_24x1_24214_24MkPair = heff_take_reuse_n(v_x1_24214, 3ULL, 2);
    switch (heff_tag_of(v_x11_24215)) {
    case TAG_Left: {
      V v_e_24217 = heff_field(v_x11_24215, 0);
      heff_take_n(v_x11_24215, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24217}), v_st_24216});
    }
    case TAG_Right: {
      V v_x_24218 = heff_field(v_x11_24215, 0);
      V v_ru_24x11_24215_24Right = heff_take_reuse_n(v_x11_24215, 1ULL, 1);
      V v_t_24219 = heff_tag_at_n(v_ru_24x11_24215_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24218})});
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){v_t_24219, v_st_24216});
    }
    default: return heff_nomatch(v_x11_24215);
    }
  }
  default: return heff_nomatch(v_x1_24214);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args) {
  V v_st_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24223 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_st_24222}));
  switch (heff_tag_of(v_x1_24223)) {
  case TAG_MkPair: {
    V v_x11_24224 = heff_field(v_x1_24223, 0);
    V v_st_24225 = heff_field(v_x1_24223, 1);
    V v_ru_24x1_24223_24MkPair = heff_take_reuse_n(v_x1_24223, 3ULL, 2);
    switch (heff_tag_of(v_x11_24224)) {
    case TAG_Left: {
      V v_e_24226 = heff_field(v_x11_24224, 0);
      heff_take_n(v_x11_24224, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24223_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24226}), v_st_24225});
    }
    case TAG_Right: {
      V v_x_24227 = heff_field(v_x11_24224, 0);
      V v_ru_24x11_24224_24Right = heff_take_reuse_n(v_x11_24224, 1ULL, 1);
      V v_t_24228 = heff_tag_at_n(v_ru_24x11_24224_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24227})});
      return heff_tag_at_n(v_ru_24x1_24223_24MkPair, TAG_MkPair, 2, (V[]){v_t_24228, v_st_24225});
    }
    default: return heff_nomatch(v_x11_24224);
    }
  }
  default: return heff_nomatch(v_x1_24223);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args) {
  V v_st_24233 = args[0];
  V v_m_24232 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24234 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_st_24233}));
  switch (heff_tag_of(v_x1_24234)) {
  case TAG_MkPair: {
    V v_x11_24235 = heff_field(v_x1_24234, 0);
    V v_st_24236 = heff_field(v_x1_24234, 1);
    V v_ru_24x1_24234_24MkPair = heff_take_reuse_n(v_x1_24234, 3ULL, 2);
    switch (heff_tag_of(v_x11_24235)) {
    case TAG_Left: {
      V v_e_24237 = heff_field(v_x11_24235, 0);
      heff_take_n(v_x11_24235, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24237}), v_st_24236});
    }
    case TAG_Right: {
      V v_x_24238 = heff_field(v_x11_24235, 0);
      V v_ru_24x11_24235_24Right = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
      V v_t_24239 = heff_tag_at_n(v_ru_24x11_24235_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24238})});
      return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){v_t_24239, v_st_24236});
    }
    default: return heff_nomatch(v_x11_24235);
    }
  }
  default: return heff_nomatch(v_x1_24234);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args) {
  V v_st_24246 = args[0];
  V v_m_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24247 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_st_24246}));
  switch (heff_tag_of(v_x1_24247)) {
  case TAG_MkPair: {
    V v_x11_24248 = heff_field(v_x1_24247, 0);
    V v_st_24249 = heff_field(v_x1_24247, 1);
    V v_ru_24x1_24247_24MkPair = heff_take_reuse_n(v_x1_24247, 3ULL, 2);
    switch (heff_tag_of(v_x11_24248)) {
    case TAG_Left: {
      V v_e_24250 = heff_field(v_x11_24248, 0);
      heff_take_n(v_x11_24248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24250}), v_st_24249});
    }
    case TAG_Right: {
      V v_x_24251 = heff_field(v_x11_24248, 0);
      V v_ru_24x11_24248_24Right = heff_take_reuse_n(v_x11_24248, 1ULL, 1);
      V v_t_24252 = heff_tag_at_n(v_ru_24x11_24248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24251})});
      return heff_tag_at_n(v_ru_24x1_24247_24MkPair, TAG_MkPair, 2, (V[]){v_t_24252, v_st_24249});
    }
    default: return heff_nomatch(v_x11_24248);
    }
  }
  default: return heff_nomatch(v_x1_24247);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args) {
  V v_st_24258 = args[0];
  V v_m_24257 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24259 = heff_tr(heff_call(v_m_24257, 1, (V[]){v_st_24258}));
  switch (heff_tag_of(v_x1_24259)) {
  case TAG_MkPair: {
    V v_x11_24260 = heff_field(v_x1_24259, 0);
    V v_st_24261 = heff_field(v_x1_24259, 1);
    V v_ru_24x1_24259_24MkPair = heff_take_reuse_n(v_x1_24259, 3ULL, 2);
    switch (heff_tag_of(v_x11_24260)) {
    case TAG_Left: {
      V v_e_24262 = heff_field(v_x11_24260, 0);
      heff_take_n(v_x11_24260, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24259_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24262}), v_st_24261});
    }
    case TAG_Right: {
      V v_x_24263 = heff_field(v_x11_24260, 0);
      V v_ru_24x11_24260_24Right = heff_take_reuse_n(v_x11_24260, 1ULL, 1);
      V v_t_24264 = heff_tag_at_n(v_ru_24x11_24260_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24263})});
      return heff_tag_at_n(v_ru_24x1_24259_24MkPair, TAG_MkPair, 2, (V[]){v_t_24264, v_st_24261});
    }
    default: return heff_nomatch(v_x11_24260);
    }
  }
  default: return heff_nomatch(v_x1_24259);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args) {
  V v_st_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_st_24270}));
  switch (heff_tag_of(v_x1_24271)) {
  case TAG_MkPair: {
    V v_x11_24272 = heff_field(v_x1_24271, 0);
    V v_st_24273 = heff_field(v_x1_24271, 1);
    V v_ru_24x1_24271_24MkPair = heff_take_reuse_n(v_x1_24271, 3ULL, 2);
    switch (heff_tag_of(v_x11_24272)) {
    case TAG_Left: {
      V v_e_24274 = heff_field(v_x11_24272, 0);
      heff_take_n(v_x11_24272, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24274}), v_st_24273});
    }
    case TAG_Right: {
      V v_x_24275 = heff_field(v_x11_24272, 0);
      V v_ru_24x11_24272_24Right = heff_take_reuse_n(v_x11_24272, 1ULL, 1);
      V v_t_24276 = heff_tag_at_n(v_ru_24x11_24272_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24275})});
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){v_t_24276, v_st_24273});
    }
    default: return heff_nomatch(v_x11_24272);
    }
  }
  default: return heff_nomatch(v_x1_24271);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args) {
  V v_st_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24281}));
  switch (heff_tag_of(v_x1_24282)) {
  case TAG_MkPair: {
    V v_x11_24283 = heff_field(v_x1_24282, 0);
    V v_st_24284 = heff_field(v_x1_24282, 1);
    V v_ru_24x1_24282_24MkPair = heff_take_reuse_n(v_x1_24282, 3ULL, 2);
    switch (heff_tag_of(v_x11_24283)) {
    case TAG_Left: {
      V v_e_24285 = heff_field(v_x11_24283, 0);
      heff_take_n(v_x11_24283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24285}), v_st_24284});
    }
    case TAG_Right: {
      V v_x_24286 = heff_field(v_x11_24283, 0);
      V v_ru_24x11_24283_24Right = heff_take_reuse_n(v_x11_24283, 1ULL, 1);
      V v_t_24287 = heff_tag_at_n(v_ru_24x11_24283_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24286})});
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){v_t_24287, v_st_24284});
    }
    default: return heff_nomatch(v_x11_24283);
    }
  }
  default: return heff_nomatch(v_x1_24282);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args) {
  V v_st_24295 = args[0];
  V v_m_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24296 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_st_24295}));
  switch (heff_tag_of(v_x1_24296)) {
  case TAG_MkPair: {
    V v_x11_24297 = heff_field(v_x1_24296, 0);
    V v_st_24298 = heff_field(v_x1_24296, 1);
    V v_ru_24x1_24296_24MkPair = heff_take_reuse_n(v_x1_24296, 3ULL, 2);
    switch (heff_tag_of(v_x11_24297)) {
    case TAG_Left: {
      V v_e_24299 = heff_field(v_x11_24297, 0);
      heff_take_n(v_x11_24297, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24296_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24299}), v_st_24298});
    }
    case TAG_Right: {
      V v_x_24300 = heff_field(v_x11_24297, 0);
      V v_ru_24x11_24297_24Right = heff_take_reuse_n(v_x11_24297, 1ULL, 1);
      V v_t_24301 = heff_tag_at_n(v_ru_24x11_24297_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24300})});
      return heff_tag_at_n(v_ru_24x1_24296_24MkPair, TAG_MkPair, 2, (V[]){v_t_24301, v_st_24298});
    }
    default: return heff_nomatch(v_x11_24297);
    }
  }
  default: return heff_nomatch(v_x1_24296);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args) {
  V v_st_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24306 = heff_tr(heff_call(v_m_24304, 1, (V[]){v_st_24305}));
  switch (heff_tag_of(v_x1_24306)) {
  case TAG_MkPair: {
    V v_x11_24307 = heff_field(v_x1_24306, 0);
    V v_st_24308 = heff_field(v_x1_24306, 1);
    V v_ru_24x1_24306_24MkPair = heff_take_reuse_n(v_x1_24306, 3ULL, 2);
    switch (heff_tag_of(v_x11_24307)) {
    case TAG_Left: {
      V v_e_24309 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24309}), v_st_24308});
    }
    case TAG_Right: {
      V v_x_24310 = heff_field(v_x11_24307, 0);
      V v_ru_24x11_24307_24Right = heff_take_reuse_n(v_x11_24307, 1ULL, 1);
      V v_t_24311 = heff_tag_at_n(v_ru_24x11_24307_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24310})});
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){v_t_24311, v_st_24308});
    }
    default: return heff_nomatch(v_x11_24307);
    }
  }
  default: return heff_nomatch(v_x1_24306);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args) {
  V v_st_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24317 = heff_tr(heff_call(v_m_24315, 1, (V[]){v_st_24316}));
  switch (heff_tag_of(v_x1_24317)) {
  case TAG_MkPair: {
    V v_x11_24318 = heff_field(v_x1_24317, 0);
    V v_st_24319 = heff_field(v_x1_24317, 1);
    V v_ru_24x1_24317_24MkPair = heff_take_reuse_n(v_x1_24317, 3ULL, 2);
    switch (heff_tag_of(v_x11_24318)) {
    case TAG_Left: {
      V v_e_24320 = heff_field(v_x11_24318, 0);
      heff_take_n(v_x11_24318, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24320}), v_st_24319});
    }
    case TAG_Right: {
      V v_x_24321 = heff_field(v_x11_24318, 0);
      V v_ru_24x11_24318_24Right = heff_take_reuse_n(v_x11_24318, 1ULL, 1);
      V v_t_24322 = heff_tag_at_n(v_ru_24x11_24318_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24321})});
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){v_t_24322, v_st_24319});
    }
    default: return heff_nomatch(v_x11_24318);
    }
  }
  default: return heff_nomatch(v_x1_24317);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Right = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      V v_t_24336 = heff_tag_at_n(v_ru_24x11_24332_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24335})});
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){v_t_24336, v_st_24333});
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args) {
  V v_m_24376 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_24376));
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eargL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eargL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eargL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EParen: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Named: {
    V v_o_246 = heff_field(v_e_241, 0);
    V v_x_247 = heff_field(v_e_241, 1);
    V v_e4_249 = heff_field(v_e_241, 3);
    V v_c_2410 = heff_field(v_e_241, 4);
    heff_take_n(v_e_241, 27ULL, 5);
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e4_249}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eargL_lam0, 1, 4, (V[]){v_m_2411, v_x_247, v_o_246, v_c_2410});
  }
  case TAG_Tup: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Braces: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Update: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EUSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_InstB: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EFDefault: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Sum: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ECon: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EField: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ENeg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_App: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Op: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Ops: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Ann: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BVar: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BImp: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Lam: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Case: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_If: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Do: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eargL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_o_246 = heff_env(self)[2];
  V v_c_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_x_247, 9);
      heff_drop_rec(v_o_246, 9);
      heff_drop_rec(v_c_2410, 9);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_ENamed, 2, (V[]){heff_get_n(v_x_247, 1, 9), v_x_2417});
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_246, 3, 9), heff_get_n(v_c_2410, 4, 9)});
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyPatOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabAbove_str0, 68, "`above` names the operators it is above (`below` alone is below all)");
Clo g_heff_2esyntax_2esurface_2eabAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabAbove_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eabAbove(V v_acc_240, V v_w_241, V v_ops_242) {
top: ;
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_241, 2), heff_get_n(v_w_241, 3, 7)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eabAbove_str0), v_t_243, NTAG(TAG_Nothing)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_240, 3)});
    return ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_240, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Cons: {
    heff_drop_rec(v_w_241, 7);
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_acc_240, 0), v_ops_242));
    return ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_240, 14ULL, 4, shape_above__below__loosest__errors, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabAbove(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str1, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str2, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str3, 6, "infixr");
Clo g_heff_2esyntax_2esurface_2efixDeclAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclAt_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDeclAt(V v_ts_240, V v_k_241, V v_t_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_242, 6));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str0))) {
        V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 1))}));
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str1), NTAG(TAG_Nil)});
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str3), v_t_247})});
        V v_t_249 = ({ V a_0 = v_t_246; V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_248, 2); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_t_2410 = (g_heff_2esyntax_2esurface_2efixDeclOf(v_ts_240, v_k_241, v_t_242));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
        } else {
          heff_drop(v_ts_240);
          heff_drop(v_k_241);
          heff_drop_rec(v_t_242, 7);
          heff_drop(v_t_249);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_ts_240);
        heff_drop(v_k_241);
        heff_drop_rec(v_t_242, 7);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_ts_240);
      heff_drop(v_k_241);
      heff_drop_rec(v_t_242, 7);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_ts_240);
    heff_drop(v_k_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_243);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2esyntax_2esurface_2efixDeclAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDeclAt(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
  V v_f_246 = heff_get_n(v_t_245, 0, 2);
  V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(v_f_246, heff_rfield(v_st_244, 3)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_x1_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_249}), v_st_244});
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_pats_241);
      heff_drop(v_rhs_242);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_pv_2416 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2414));
      V v_t_2417 = ({ V rv_4 = v_pv_2416; V rr_ = heff_rec_reuse_nf(v_st_2412, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_pats_241);
          heff_drop(v_rhs_242);
          heff_drop(v_x_2414);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          V v_m_2423 = (g_heff_2esyntax_2esurface_2etraverseS(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
          V v_x1_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_st_2420}));
          switch (heff_tag_of(v_x1_2424)) {
          case TAG_MkPair: {
            V v_x11_2425 = heff_field(v_x1_2424, 0);
            V v_st_2426 = heff_field(v_x1_2424, 1);
            heff_take_n(v_x1_2424, 3ULL, 2);
            switch (heff_tag_of(v_x11_2425)) {
            case TAG_Left: {
              V v_e_2427 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              heff_drop(v_pats_241);
              heff_drop(v_rhs_242);
              heff_drop(v_x_2414);
              return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
            }
            case TAG_Right: {
              V v_x_2428 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
              V v_t_2429 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2414));
              V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2429}));
              V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
              V v_t_2432 = ({ V a_0 = v_x_2414; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_x_2414); r_; });
              V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2431, v_t_2432));
              V v_t_2434 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2426, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2433, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), heff_dup(v_names_240), v_x_2428}), v_t_2434));
            }
            default: return heff_nomatch(v_x11_2425);
            }
          }
          default: return heff_nomatch(v_x1_2424);
          }
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1(V self, V *args) {
  V v_st_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2440}), v_st_2441});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0(V self, V *args) {
  V v_st_2435 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2428);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      V v_ru_24x11_2437_24Right = heff_take_reuse_n(v_x11_2437, 1ULL, 1);
      V v_m_2445;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_m_2445 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1, 1, 1, (V[]){v_x_2440});
        break;
      }
      case TAG_Just: {
        V v_it1_2442 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        switch (heff_tag_of(v_it1_2442)) {
        case TAG_MkPair: {
          V v_kw_2443 = heff_field(v_it1_2442, 0);
          V v_ds_2444 = heff_field(v_it1_2442, 1);
          heff_take_n(v_it1_2442, 3ULL, 2);
          v_m_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo), 3, (V[]){v_kw_2443, v_ds_2444, v_x_2440}));
          break;
        }
        default: heff_nomatch(v_it1_2442);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      V v_x1_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_st_2438}));
      switch (heff_tag_of(v_x1_2446)) {
      case TAG_MkPair: {
        V v_x11_2447 = heff_field(v_x1_2446, 0);
        V v_st_2448 = heff_field(v_x1_2446, 1);
        V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
        switch (heff_tag_of(v_x11_2447)) {
        case TAG_Left: {
          V v_e_2449 = heff_field(v_x11_2447, 0);
          heff_take_n(v_x11_2447, 1ULL, 1);
          heff_drop(v_names_240);
          heff_drop(v_x_2428);
          heff_drop_cell(v_ru_24x11_2437_24Right, 1);
          heff_drop_cell(v_ru_24x1_2446_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
        }
        case TAG_Right: {
          V v_x_2450 = heff_field(v_x11_2447, 0);
          heff_take_n(v_x11_2447, 1ULL, 1);
          V v_t_2451 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2452 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2453 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2454 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2452, 0, 2), heff_get_n(v_t_2453, 1, 2), v_x_2428, heff_dup(v_x_2450)});
          V v_a_2457;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_a_2457 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2455 = heff_dup(heff_field(v_names_240, 0));
            v_a_2457 = heff_get_n(v_t_2455, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2460;
          switch (heff_tag_of(v_x_2450)) {
          case TAG_At: {
            V v_s_2459 = heff_dup(heff_field(v_x_2450, 1));
            v_t_2460 = v_s_2459;
            break;
          }
          default: heff_nomatch(v_x_2450);
          }
          V v_b_2461 = heff_get_n(v_t_2460, 1, 2);
          V v_t_2462 = heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_At, 2, (V[]){v_t_2454, heff_rec_n(2, shape_start__end, (V[]){v_a_2457, v_b_2461})});
          V v_a_2465;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_a_2465 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2463 = heff_field(v_names_240, 0);
            heff_take_n(v_names_240, 1ULL, 2);
            v_a_2465 = heff_get_n(v_t_2463, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2468;
          switch (heff_tag_of(v_x_2450)) {
          case TAG_At: {
            V v_s_2467 = heff_field(v_x_2450, 1);
            heff_take_n(v_x_2450, 2ULL, 2);
            v_t_2468 = v_s_2467;
            break;
          }
          default: heff_nomatch(v_x_2450);
          }
          V v_b_2469 = heff_get_n(v_t_2468, 1, 2);
          V v_t_2470 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2451, 0, 2), v_t_2462, heff_rec_n(2, shape_start__end, (V[]){v_a_2465, v_b_2469})});
          V v_x_2471 = heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2437_24Right, TAG_Right, 1, (V[]){v_x_2471}), v_st_2448});
        }
        default: return heff_nomatch(v_x11_2447);
        }
      }
      default: return heff_nomatch(v_x1_2446);
      }
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry, 7, 0};

V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245, V v_z_246) {
top: ;
  V v_m_247 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_params_243));
  V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
      V v_t_2413 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2412)));
      V v_m_2422;
      switch (heff_tag_of(v_universe_244)) {
      case TAG_Nothing: {
        v_m_2422 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0, 1, 1, (V[]){heff_dup(v_name_242)});
        break;
      }
      case TAG_Just: {
        V v_it1_2418 = heff_field(v_universe_244, 0);
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_MkPair: {
          V v_u_2420 = heff_field(v_it1_2418, 1);
          v_m_2422 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam1, 1, 1, (V[]){heff_dup(v_u_2420)});
          break;
        }
        default: heff_nomatch(v_it1_2418);
        }
        break;
      }
      default: heff_nomatch(v_universe_244);
      }
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2413, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam2, 1, 6, (V[]){v_m_2422, heff_dup(v_alts_245), v_name_242, v_d_240, v_kw_241, v_x_2412}), v_st_2410));
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(a[0], a[1], a[2], a[3], a4, a5, a[6]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_name_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_get_n(v_name_242, 4, 9)});
  V v_t_2417 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_st_2414});
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam1(V self, V *args) {
  V v_st_2421 = args[0];
  V v_u_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_u_2420, v_st_2421));
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam2(V self, V *args) {
  V v_st_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_alts_245 = heff_env(self)[1];
  V v_name_242 = heff_env(self)[2];
  V v_d_240 = heff_env(self)[3];
  V v_kw_241 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_st_2423}));
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_MkPair: {
    V v_x11_2425 = heff_field(v_x1_2424, 0);
    V v_st_2426 = heff_field(v_x1_2424, 1);
    V v_ru_24x1_2424_24MkPair = heff_take_reuse_n(v_x1_2424, 3ULL, 2);
    switch (heff_tag_of(v_x11_2425)) {
    case TAG_Left: {
      V v_e_2427 = heff_field(v_x11_2425, 0);
      heff_take_n(v_x11_2425, 1ULL, 1);
      heff_drop(v_alts_245);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2412);
      return heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
    }
    case TAG_Right: {
      V v_x_2428 = heff_field(v_x11_2425, 0);
      V v_ru_24x11_2425_24Right = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
      V v_t_2433;
      switch (heff_tag_of(v_alts_245)) {
      case TAG_Nothing: {
        v_t_2433 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2429 = heff_field(v_alts_245, 0);
        heff_take_n(v_alts_245, 1ULL, 1);
        switch (heff_tag_of(v_x11_2429)) {
        case TAG_MkDAlts: {
          V v_alts_2431 = heff_field(v_x11_2429, 1);
          heff_take_n(v_x11_2429, 2ULL, 3);
          v_t_2433 = v_alts_2431;
          break;
        }
        default: heff_nomatch(v_x11_2429);
        }
        break;
      }
      default: heff_nomatch(v_alts_245);
      }
      V v_m_2434 = (g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(v_t_2433));
      V v_x1_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_st_2426}));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_MkPair: {
        V v_x11_2436 = heff_field(v_x1_2435, 0);
        V v_st_2437 = heff_field(v_x1_2435, 1);
        V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
        switch (heff_tag_of(v_x11_2436)) {
        case TAG_Left: {
          V v_e_2438 = heff_field(v_x11_2436, 0);
          heff_take_n(v_x11_2436, 1ULL, 1);
          heff_drop_rec(v_name_242, 9);
          heff_drop(v_d_240);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_x_2412);
          heff_drop(v_x_2428);
          heff_drop_cell(v_ru_24x11_2425_24Right, 1);
          heff_drop_cell(v_ru_24x1_2435_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
        }
        case TAG_Right: {
          V v_x_2439 = heff_field(v_x11_2436, 0);
          V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
          V v_t_2440 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
          V v_t_2441 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
          V v_e_2442 = heff_get_n(v_t_2441, 4, 9);
          V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2442});
          V v_t_2444 = heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ESum, 1, (V[]){v_x_2439}), v_t_2443});
          V v_t_2445 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2440, v_x_2412, v_x_2428, v_t_2444});
          V v_t_2446 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
          V v_e_2447 = heff_get_n(v_t_2446, 4, 9);
          V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2447});
          V v_t_2449 = heff_tag_at_n(v_ru_24x11_2425_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2448})});
          V v_x_2450 = heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_Right, 1, (V[]){v_x_2450}), v_st_2437});
        }
        default: return heff_nomatch(v_x11_2436);
        }
      }
      default: return heff_nomatch(v_x1_2435);
      }
    }
    default: return heff_nomatch(v_x11_2425);
    }
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_str0, 7, "doctest");
Clo g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(V v_d_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    V v_ru_24d_240_24DImport = heff_take_reuse_n(v_d_240, 0ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24d_240_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_z_241});
  }
  case TAG_DFixity: {
    V v_ru_24d_240_24DFixity = heff_take_reuse_n(v_d_240, 0ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24d_240_24DFixity, TAG_MkPair, 2, (V[]){v_t_246, v_z_241});
  }
  case TAG_DSig: {
    V v_names_247 = heff_field(v_d_240, 0);
    V v_ty_249 = heff_field(v_d_240, 2);
    heff_take_n(v_d_240, 5ULL, 3);
    V v_t_2412;
    switch (heff_tag_of(v_names_247)) {
    case TAG_Nil: {
      v_t_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_t_2410 = heff_dup(heff_field(v_names_247, 0));
      v_t_2412 = heff_get_n(v_t_2410, 3, 9);
      break;
    }
    default: heff_nomatch(v_names_247);
    }
    return ({ V a_0 = NTAG(TAG_AsDefinition); V a_1 = v_t_2412; V a_2 = v_names_247; V a_3 = v_ty_249; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_247); r_; });
  }
  case TAG_DInstance: {
    V v_kw_2413 = heff_field(v_d_240, 0);
    V v_names_2414 = heff_field(v_d_240, 1);
    V v_ty_2416 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return ({ V a_0 = NTAG(TAG_AsInstance); V a_1 = heff_get_n(v_kw_2413, 3, 9); V a_2 = v_names_2414; V a_3 = v_ty_2416; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2414); r_; });
  }
  case TAG_DEqn: {
    V v_names_2417 = heff_field(v_d_240, 0);
    V v_pats_2418 = heff_field(v_d_240, 1);
    V v_rhs_2420 = heff_field(v_d_240, 3);
    V v_w_2421 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 27ULL, 5);
    return ({ V a_0 = v_names_2417; V a_1 = v_pats_2418; V a_2 = v_rhs_2420; V a_3 = v_w_2421; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2417); heff_drop(v_w_2421); r_; });
  }
  case TAG_DData: {
    V v_kw_2422 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2423 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2424 = heff_dup(heff_field(v_d_240, 2));
    V v_universe_2425 = heff_dup(heff_field(v_d_240, 3));
    V v_alts_2426 = heff_dup(heff_field(v_d_240, 4));
    return ({ V a_0 = v_d_240; V a_1 = v_kw_2422; V a_2 = v_name_2423; V a_3 = v_params_2424; V a_4 = v_universe_2425; V a_5 = v_alts_2426; V a_6 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_universe_2425); heff_drop(v_alts_2426); r_; });
  }
  case TAG_DType: {
    V v_kw_2427 = heff_field(v_d_240, 0);
    V v_name_2428 = heff_field(v_d_240, 1);
    V v_params_2429 = heff_field(v_d_240, 2);
    V v_body_2431 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(v_kw_2427, v_name_2428, v_params_2429, v_body_2431, v_z_241));
  }
  case TAG_DTheory: {
    V v_kw_2432 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2433 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2434 = heff_dup(heff_field(v_d_240, 2));
    V v_fields_2436 = heff_dup(heff_field(v_d_240, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(v_d_240, v_kw_2432, v_name_2433, v_params_2434, v_fields_2436, v_z_241));
  }
  case TAG_DPrimitive: {
    V v_kw_2437 = heff_field(v_d_240, 0);
    V v_x_2438 = heff_field(v_d_240, 1);
    V v_ty_2440 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(v_kw_2437, v_x_2438, v_ty_2440, v_z_241));
  }
  case TAG_DTest: {
    V v_kw_2441 = heff_field(v_d_240, 0);
    V v_x_2442 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DTest = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2442, 3), heff_dup(heff_rfield(v_x_2442, 4))});
    V v_t_2444 = heff_tag_at_n(v_ru_24d_240_24DTest, TAG_DeclTest, 2, (V[]){heff_dup(heff_rfield(v_x_2442, 1)), v_t_2443});
    V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2441, 3, 9), heff_get_n(v_x_2442, 4, 9)});
    V v_t_2446 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2447}), v_z_241});
  }
  case TAG_DWatch: {
    V v_w_2448 = heff_field(v_d_240, 0);
    V v_e_2449 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DWatch = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_x1_2450 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_2449), v_z_241));
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_MkPair: {
      V v_x11_2451 = heff_field(v_x1_2450, 0);
      V v_st_2452 = heff_field(v_x1_2450, 1);
      V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
      switch (heff_tag_of(v_x11_2451)) {
      case TAG_Left: {
        V v_e_2453 = heff_field(v_x11_2451, 0);
        heff_take_n(v_x11_2451, 1ULL, 1);
        heff_drop_rec(v_w_2448, 9);
        heff_drop(v_e_2449);
        heff_drop_cell(v_ru_24x1_2450_24MkPair, 2);
        return heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
      }
      case TAG_Right: {
        V v_x_2454 = heff_field(v_x11_2451, 0);
        V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
        V v_t_2455 = (g_heff_2esyntax_2ecst_2elastE(v_e_2449));
        V v_e_2456 = heff_get_n(v_t_2455, 4, 9);
        V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_2448, 3), v_e_2456});
        V v_d_2458 = heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2454}), v_t_2457});
        V v_t_2460;
        if (heff_strEq_c(heff_get_n(v_w_2448, 0, 9), ((V)&g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_str0))) {
          v_t_2460 = heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Doc, 1, (V[]){v_d_2458});
        } else {
          v_t_2460 = heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Whole, 1, (V[]){v_d_2458});
        }
        V v_x_2461 = heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2452});
      }
      default: return heff_nomatch(v_x11_2451);
      }
    }
    default: return heff_nomatch(v_x1_2450);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str3, 1, ":");
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadRun_entry, 6, 0};

V g_heff_2esyntax_2esurface_2ereadRun(V v_src_240, V v_o_241, V v_toks_242, V v_lexDiags_243, V v_declared_244, V v_own_245) {
top: ;
  V v_path_246 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_path_248 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2einitialSt(v_o_241, heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam0, 1, 2, (V[]){v_path_248, heff_dup(v_src_240)}), heff_dup(v_toks_242), v_declared_244, heff_dup(heff_rfield(v_own_245, 0))));
  V v_r_2413 = (g_heff_2esyntax_2esurface_2eprogGo(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_242, MK_INT(0LL), MK_INT(0LL), v_t_247, MK_INT(0LL)}), v_t_2412, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2414 = (g_heff_2esyntax_2esurface_2eplaceDocs(heff_dup(v_src_240), heff_rfield(v_r_2413, 0)));
  return (g_heff_2esyntax_2esurface_2ereadPlaced(heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam1, 1, 2, (V[]){v_path_246, v_src_240}), v_lexDiags_243, v_own_245, v_r_2413, v_t_2414));
}
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2esurface_2ereadRun(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_path_248), ((V)&g_heff_2esyntax_2esurface_2ereadRun_str0))) {
    heff_drop(v_path_248);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2411 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_248, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str1), v_t_2411));
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_path_246), ((V)&g_heff_2esyntax_2esurface_2ereadRun_str2))) {
    heff_drop(v_path_246);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2417 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_246, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str3), v_t_2417));
  }
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ereadLexed(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  V v_ltoks_243 = heff_arrayFromList(heff_dup(heff_rfield(v_l_242, 0)));
  V v_t_244 = (g_heff_2esyntax_2efmt_2etoks_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), heff_take_field(v_l_242, 0)));
  V v_toks_245 = heff_arrayFromList(v_t_244);
  V v_lexDiags_246 = (g_list_2emap_24s338694954x1326523169(heff_get_n(v_l_242, 1, 3)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2eprescanGo(heff_dup(v_ltoks_243), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_248 = (g_heff_2esyntax_2esurface_2efixDecls(v_ltoks_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249 = (g_heff_2esyntax_2esurface_2efixityFrom(heff_dup(heff_rfield(v_o_241, 3)), heff_dup(heff_rfield(v_o_241, 1)), v_t_248));
  return ({ V a_0 = v_src_240; V a_1 = v_o_241; V a_2 = v_toks_245; V a_3 = v_lexDiags_246; V a_4 = v_t_247; V a_5 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2ereadRun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
}
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadLexed(a[0], a[1], a[2]);
}