// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclDefine 5286
#define TAG_DeclTest 38719
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_head 9693863
#define LBL_i 323
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_waiting 1348170899
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eabAbove(V, V, V);
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabAbove_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754(V, V, V);
V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_clo;
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(V, V);
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclAt(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclAt_clo;
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2eplaceDocs(V, V);
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo;
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esettingsOf(V);
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingsOf_clo;
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etraverseS_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etraverseS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_heff_2esyntax_2esurface_2etraverseS(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2esurface_2epiBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiBinders_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_b_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      V v_t_2432;
      switch (heff_tag_of(v_b_2417)) {
      case TAG_PiNamed: {
        V v_x_2419 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 3);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 5);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_b_2417, 0);
        heff_take_n(v_b_2417, 1ULL, 4);
        v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2417);
      }
      V v_t_2433 = (g_heff_2esyntax_2esurface_2epiBinders(v_rest_2418));
      return (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_t_2433));
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiBinders(a[0]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2easBinderOn(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ENamed: {
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EAnn: {
      V v_g_2422 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2422)));
      V v_t_2426 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2422));
      V v_t_2427 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2425, 0, 2), heff_get_n(v_t_2426, 1, 2)});
      V v_t_2428 = (g_list_2emap_24s878634257x1677201747(v_t_2427));
      V v_sc_2429 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(heff_take_field(v_p_241, 1), v_t_2428));
      V v_t_2430 = ({ V rv_1 = v_sc_2429; V rr_ = heff_rec_reuse_nf(v_p_241, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x1_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2430});
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_MkPair: {
        V v_x11_2432 = heff_field(v_x1_2431, 0);
        V v_st_2433 = heff_field(v_x1_2431, 1);
        V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
        switch (heff_tag_of(v_x11_2432)) {
        case TAG_Left: {
          V v_e_2434 = heff_field(v_x11_2432, 0);
          heff_take_n(v_x11_2432, 1ULL, 1);
          heff_drop_tag(v_e_240, 2);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2432, 0ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_st_2433});
        }
        default: return heff_nomatch(v_x11_2432);
        }
      }
      default: return heff_nomatch(v_x1_2431);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_242_24EUpdate = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      return heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_Right, 1, (V[]){v_e_240}), v_p_241});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2enameBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameBinder(V v_e0_240) {
top: ;
  switch (heff_tag_of(v_e0_240)) {
  case TAG_At: {
    V v_e01_241 = heff_dup(heff_field(v_e0_240, 0));
    switch (heff_tag_of(v_e01_241)) {
    case TAG_EVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ETag: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EInt: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EString: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EAnn: {
      V v_g_2421 = heff_field(v_e01_241, 0);
      V v_t_2422 = heff_field(v_e01_241, 1);
      V v_ru_24e01_241_24EAnn = heff_take_reuse_n(v_e01_241, 3ULL, 2);
      heff_drop_tag(v_e0_240, 2);
      V v_t_2423 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2423, 0, 2), heff_get_n(v_t_2424, 1, 2)});
      V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a_0)); heff_drop_tag(v_t_2425, 2); r_; });
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2421)));
        V v_t_2428 = (g_heff_2esyntax_2esurface_2easNameE(heff_get_n(v_t_2427, 0, 2)));
        V v_t_2429 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2421));
        V v_t_2430 = (g_list_2emap_24s1624059865x1140896478(heff_get_n(v_t_2429, 1, 2)));
        V v_e_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, v_t_2430));
        V v_t_2434;
        switch (heff_tag_of(v_e_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_e_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_e_2431);
        }
        V v_t_2437;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_t_2422, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2438 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_e_2431, v_t_2422}), v_t_2438});
      } else {
        heff_drop(v_t_2426);
        V v_t_2441;
        switch (heff_tag_of(v_g_2421)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_g_2421, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_g_2421);
        }
        V v_t_2444;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2422, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2445 = ({ V rv_1 = heff_get_n(v_t_2444, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2441, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e01_241_24EAnn, TAG_EAnn, 2, (V[]){v_g_2421, v_t_2422}), v_t_2445});
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e01_241, 0ULL, 4);
      return v_e0_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e01_241, 0ULL, 2);
      return v_e0_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e01_241, 0ULL, 1);
      return v_e0_240;
    }
    default: return heff_nomatch(v_e01_241);
    }
  }
  default: return heff_nomatch(v_e0_240);
  }
}
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2enameBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eeqnNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eeqnNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Eqn: {
      V v_f_248 = heff_field(v_x11_241, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnNames(v_rest_242));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_248), NTAG(TAG_MkUnit), v_t_2411));
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eeqnNames(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eplaceDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceDocs_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eplaceDocs(V v_src_240, V v_items_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_items__waiting__diags, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_p_245 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2eplaceDocs_lam0, 2, 1, (V[]){v_src_240}), v_t_242, v_items_241));
  V v_items_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_245, 0), heff_dup(heff_rfield(v_p_245, 1))));
  V v_diags_247 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_245, 2), heff_get_n(v_p_245, 1, 3)));
  return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_246, NTAG(TAG_Nil), v_diags_247});
}
V g_heff_2esyntax_2esurface_2eplaceDocs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eplaceDocs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eplaceDocs_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_it_244 = args[1];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eplaceStep(v_src_240, v_p_243, v_it_244));
}
Clo g_heff_2esyntax_2esurface_2epathOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epathOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epathOf(V v_e_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_take_field(v_x_242, 4)});
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_242, 1, 9), v_t_243});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_acc_241});
  }
  case TAG_EParen: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Named: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Tup: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Seg: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Braces: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Update: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_EUSet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_InstB: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_EFSet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EFDefault: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Sum: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_ECon: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EField: {
    V v_e1_2451 = heff_field(v_e_240, 0);
    V v_f_2452 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EField = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2453 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_f_2452, 3), heff_take_field(v_f_2452, 4)});
    V v_t_2454 = heff_tag_at_n(v_ru_24e_240_24EField, TAG_MkPair, 2, (V[]){heff_get_n(v_f_2452, 1, 9), v_t_2453});
    V t_0 = v_e1_2451;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_acc_241});
    v_e_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_App: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Op: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_Ops: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_OpRhs: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_Ann: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_BImp: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_BAnn: {
    heff_take_n(v_e_240, 0ULL, 5);
    return v_acc_241;
  }
  case TAG_Lam: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_Case: {
    heff_take_n(v_e_240, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_EAlt: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_If: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  case TAG_Do: {
    heff_take_n(v_e_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ESBind: {
    heff_take_n(v_e_240, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 6);
    return v_acc_241;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epathOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 2);
    V v_t_2411;
    switch (heff_tag_of(v_t_243)) {
    case TAG_LamName: {
      V v_x_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamImplicit: {
      V v_x_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LamAnn: {
      V v_x_248 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 3);
      v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str1, 45, "a specialisation sets fields: `T ~ { x = v }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eopL_str2, 50, "a specialisation sets a field by its name: `x = v`");
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eopL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eopL(V v_r_240, V v_a_241, V v_op_242, V v_b_243, V v_z_244) {
top: ;
  if (heff_strEq_c(heff_get_n(v_op_242, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eopL_str0))) {
    V v_t_246 = (g_heff_2esyntax_2esurface_2ebracedOne(v_a_241));
    V v_m_24352;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_a_241)) {
      case TAG_Atom: {
        V v_m_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam0, 1, 1, (V[]){v_m_248});
        break;
      }
      case TAG_EParen: {
        V v_m_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam1, 1, 1, (V[]){v_m_2419});
        break;
      }
      case TAG_Named: {
        V v_m_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam2, 1, 1, (V[]){v_m_2432});
        break;
      }
      case TAG_Tup: {
        V v_m_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam3, 1, 1, (V[]){v_m_2444});
        break;
      }
      case TAG_Seg: {
        V v_m_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam4, 1, 1, (V[]){v_m_2455});
        break;
      }
      case TAG_Braces: {
        V v_m_2467 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam5, 1, 1, (V[]){v_m_2467});
        break;
      }
      case TAG_Update: {
        V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam6, 1, 1, (V[]){v_m_2481});
        break;
      }
      case TAG_EUSet: {
        V v_m_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam7, 1, 1, (V[]){v_m_2492});
        break;
      }
      case TAG_InstB: {
        V v_o_24100 = heff_field(v_a_241, 0);
        V v_d_24102 = heff_field(v_a_241, 2);
        V v_c_24104 = heff_field(v_a_241, 4);
        heff_take_n(v_a_241, 21ULL, 5);
        V v_m_24105 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_d_24102));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam8, 1, 3, (V[]){v_m_24105, v_o_24100, v_c_24104});
        break;
      }
      case TAG_EFSet: {
        V v_m_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam9, 1, 1, (V[]){v_m_24117});
        break;
      }
      case TAG_EFDefault: {
        V v_m_24128 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam10, 1, 1, (V[]){v_m_24128});
        break;
      }
      case TAG_Sum: {
        V v_m_24141 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam11, 1, 1, (V[]){v_m_24141});
        break;
      }
      case TAG_ECon: {
        V v_m_24151 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam12, 1, 1, (V[]){v_m_24151});
        break;
      }
      case TAG_EField: {
        V v_m_24161 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam13, 1, 1, (V[]){v_m_24161});
        break;
      }
      case TAG_ENeg: {
        V v_m_24171 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam14, 1, 1, (V[]){v_m_24171});
        break;
      }
      case TAG_App: {
        V v_m_24181 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam15, 1, 1, (V[]){v_m_24181});
        break;
      }
      case TAG_Op: {
        V v_m_24192 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam16, 1, 1, (V[]){v_m_24192});
        break;
      }
      case TAG_Ops: {
        V v_m_24202 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam17, 1, 1, (V[]){v_m_24202});
        break;
      }
      case TAG_OpRhs: {
        V v_m_24212 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam18, 1, 1, (V[]){v_m_24212});
        break;
      }
      case TAG_Ann: {
        V v_m_24223 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam19, 1, 1, (V[]){v_m_24223});
        break;
      }
      case TAG_BVar: {
        V v_m_24232 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam20, 1, 1, (V[]){v_m_24232});
        break;
      }
      case TAG_BImp: {
        V v_m_24243 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam21, 1, 1, (V[]){v_m_24243});
        break;
      }
      case TAG_BAnn: {
        V v_m_24256 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam22, 1, 1, (V[]){v_m_24256});
        break;
      }
      case TAG_Lam: {
        V v_m_24268 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam23, 1, 1, (V[]){v_m_24268});
        break;
      }
      case TAG_Case: {
        V v_m_24280 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam24, 1, 1, (V[]){v_m_24280});
        break;
      }
      case TAG_EAlt: {
        V v_m_24291 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam25, 1, 1, (V[]){v_m_24291});
        break;
      }
      case TAG_If: {
        V v_m_24305 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam26, 1, 1, (V[]){v_m_24305});
        break;
      }
      case TAG_Do: {
        V v_m_24315 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam27, 1, 1, (V[]){v_m_24315});
        break;
      }
      case TAG_ESBind: {
        V v_m_24326 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam28, 1, 1, (V[]){v_m_24326});
        break;
      }
      case TAG_ELet: {
        V v_m_24340 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
        v_m_24352 = heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam29, 1, 1, (V[]){v_m_24340});
        break;
      }
      default: heff_nomatch(v_a_241);
      }
      break;
    }
    case TAG_Just: {
      V v_f_24348 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_a_24349 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241));
      V v_b_24350 = (g_heff_2esyntax_2ecst_2elastE(v_a_241));
      V v_t_24351 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24349, 3, 9), heff_get_n(v_b_24350, 4, 9)});
      v_m_24352 = (g_heff_2esyntax_2esurface_2ebracedL(heff_dup(v_r_240), v_f_24348, v_t_24351));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_x1_24353 = heff_tr(heff_call(v_m_24352, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24353)) {
    case TAG_MkPair: {
      V v_x11_24354 = heff_field(v_x1_24353, 0);
      V v_st_24355 = heff_field(v_x1_24353, 1);
      V v_ru_24x1_24353_24MkPair = heff_take_reuse_n(v_x1_24353, 3ULL, 2);
      switch (heff_tag_of(v_x11_24354)) {
      case TAG_Left: {
        V v_e_24356 = heff_field(v_x11_24354, 0);
        heff_take_n(v_x11_24354, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24356}), v_st_24355});
      }
      case TAG_Right: {
        V v_x_24357 = heff_field(v_x11_24354, 0);
        heff_take_n(v_x11_24354, 1ULL, 1);
        V v_m_24358 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
        V v_x1_24359 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_st_24355}));
        switch (heff_tag_of(v_x1_24359)) {
        case TAG_MkPair: {
          V v_x11_24360 = heff_field(v_x1_24359, 0);
          V v_st_24361 = heff_field(v_x1_24359, 1);
          heff_take_n(v_x1_24359, 3ULL, 2);
          switch (heff_tag_of(v_x11_24360)) {
          case TAG_Left: {
            V v_e_24362 = heff_field(v_x11_24360, 0);
            heff_take_n(v_x11_24360, 1ULL, 1);
            heff_drop(v_x_24357);
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24362}), v_st_24361});
          }
          case TAG_Right: {
            V v_x_24363 = heff_field(v_x11_24360, 0);
            heff_take_n(v_x11_24360, 1ULL, 1);
            V v_x_24364 = heff_tr(g_heff_2esyntax_2esurface_2earrowBinop(v_x_24357, v_x_24363));
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24364}), v_st_24361});
          }
          default: return heff_nomatch(v_x11_24360);
          }
        }
        default: return heff_nomatch(v_x1_24359);
        }
      }
      default: return heff_nomatch(v_x11_24354);
      }
    }
    default: return heff_nomatch(v_x1_24353);
    }
  } else {
    V v_m_24365 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_241}));
    V v_x1_24366 = heff_tr(heff_call(v_m_24365, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24366)) {
    case TAG_MkPair: {
      V v_x11_24367 = heff_field(v_x1_24366, 0);
      V v_st_24368 = heff_field(v_x1_24366, 1);
      V v_ru_24x1_24366_24MkPair = heff_take_reuse_n(v_x1_24366, 3ULL, 2);
      switch (heff_tag_of(v_x11_24367)) {
      case TAG_Left: {
        V v_e_24369 = heff_field(v_x11_24367, 0);
        heff_take_n(v_x11_24367, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_b_243);
        return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24369}), v_st_24368});
      }
      case TAG_Right: {
        V v_x_24370 = heff_field(v_x11_24367, 0);
        V v_ru_24x11_24367_24Right = heff_take_reuse_n(v_x11_24367, 1ULL, 1);
        V v_t_24371 = (g_heff_2esyntax_2esurface_2esettingsOf(v_b_243));
        switch (heff_tag_of(v_t_24371)) {
        case TAG_Nothing: {
          V v_m_24372 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_b_243}));
          V v_x1_24373 = heff_tr(heff_call(v_m_24372, 1, (V[]){v_st_24368}));
          switch (heff_tag_of(v_x1_24373)) {
          case TAG_MkPair: {
            V v_x11_24374 = heff_field(v_x1_24373, 0);
            V v_st_24375 = heff_field(v_x1_24373, 1);
            V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
            switch (heff_tag_of(v_x11_24374)) {
            case TAG_Left: {
              V v_e_24376 = heff_field(v_x11_24374, 0);
              heff_take_n(v_x11_24374, 1ULL, 1);
              heff_drop(v_x_24370);
              heff_drop_cell(v_ru_24x11_24367_24Right, 1);
              heff_drop_cell(v_ru_24x1_24373_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
            }
            case TAG_Right: {
              V v_x_24377 = heff_field(v_x11_24374, 0);
              heff_take_n(v_x11_24374, 1ULL, 1);
              V v_t_24380;
              switch (heff_tag_of(v_x_24370)) {
              case TAG_At: {
                V v_s_24379 = heff_field(v_x_24370, 1);
                heff_take_n(v_x_24370, 2ULL, 2);
                v_t_24380 = v_s_24379;
                break;
              }
              default: heff_nomatch(v_x_24370);
              }
              V v_t_24383;
              switch (heff_tag_of(v_x_24377)) {
              case TAG_At: {
                V v_s_24382 = heff_field(v_x_24377, 1);
                heff_take_n(v_x_24377, 2ULL, 2);
                v_t_24383 = v_s_24382;
                break;
              }
              default: heff_nomatch(v_x_24377);
              }
              V v_t_24384 = ({ V rv_1 = heff_get_n(v_t_24383, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24380, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_24385 = heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24367_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eopL_str1)}), v_t_24384});
              return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24385}), v_st_24375});
            }
            default: return heff_nomatch(v_x11_24374);
            }
          }
          default: return heff_nomatch(v_x1_24373);
          }
        }
        case TAG_Just: {
          V v_fs_24386 = heff_field(v_t_24371, 0);
          heff_take_n(v_t_24371, 1ULL, 1);
          heff_drop(v_b_243);
          heff_drop_cell(v_ru_24x11_24367_24Right, 1);
          V v_m_24388 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eopL_lam30, 1, 1, (V[]){v_r_240}), v_fs_24386));
          V v_x1_24389 = heff_tr(heff_call(v_m_24388, 1, (V[]){v_st_24368}));
          switch (heff_tag_of(v_x1_24389)) {
          case TAG_MkPair: {
            V v_x11_24390 = heff_field(v_x1_24389, 0);
            V v_st_24391 = heff_field(v_x1_24389, 1);
            heff_take_n(v_x1_24389, 3ULL, 2);
            switch (heff_tag_of(v_x11_24390)) {
            case TAG_Left: {
              V v_e_24392 = heff_field(v_x11_24390, 0);
              heff_take_n(v_x11_24390, 1ULL, 1);
              heff_drop(v_x_24370);
              return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24392}), v_st_24391});
            }
            case TAG_Right: {
              V v_x_24393 = heff_field(v_x11_24390, 0);
              heff_take_n(v_x11_24390, 1ULL, 1);
              V v_x_24394 = (g_list_2efoldl_24s1368043225x413679696(((V)&g_heff_2esyntax_2esurface_2eopL_str2), v_x_24370, v_x_24393));
              return heff_tag_at_n(v_ru_24x1_24366_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24394}), v_st_24391});
            }
            default: return heff_nomatch(v_x11_24390);
            }
          }
          default: return heff_nomatch(v_x1_24389);
          }
        }
        default: return heff_nomatch(v_t_24371);
        }
      }
      default: return heff_nomatch(v_x11_24367);
      }
    }
    default: return heff_nomatch(v_x1_24366);
    }
  }
}
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2eopL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2414})});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam1(V self, V *args) {
  V v_st_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_st_2420}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_MkPair: {
    V v_x11_2422 = heff_field(v_x1_2421, 0);
    V v_st_2423 = heff_field(v_x1_2421, 1);
    V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
    switch (heff_tag_of(v_x11_2422)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x11_2422, 0);
      heff_take_n(v_x11_2422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x11_2422, 0);
      V v_ru_24x11_2422_24Right = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
      V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2425})});
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2423});
    }
    default: return heff_nomatch(v_x11_2422);
    }
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam2(V self, V *args) {
  V v_st_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_st_2433}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_MkPair: {
    V v_x11_2435 = heff_field(v_x1_2434, 0);
    V v_st_2436 = heff_field(v_x1_2434, 1);
    V v_ru_24x1_2434_24MkPair = heff_take_reuse_n(v_x1_2434, 3ULL, 2);
    switch (heff_tag_of(v_x11_2435)) {
    case TAG_Left: {
      V v_e_2437 = heff_field(v_x11_2435, 0);
      heff_take_n(v_x11_2435, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2437}), v_st_2436});
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_x11_2435, 0);
      V v_ru_24x11_2435_24Right = heff_take_reuse_n(v_x11_2435, 1ULL, 1);
      V v_t_2439 = heff_tag_at_n(v_ru_24x11_2435_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2438})});
      return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2439, v_st_2436});
    }
    default: return heff_nomatch(v_x11_2435);
    }
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam3(V self, V *args) {
  V v_st_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_st_2445}));
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_MkPair: {
    V v_x11_2447 = heff_field(v_x1_2446, 0);
    V v_st_2448 = heff_field(v_x1_2446, 1);
    V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
    switch (heff_tag_of(v_x11_2447)) {
    case TAG_Left: {
      V v_e_2449 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
    }
    case TAG_Right: {
      V v_x_2450 = heff_field(v_x11_2447, 0);
      V v_ru_24x11_2447_24Right = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
      V v_t_2451 = heff_tag_at_n(v_ru_24x11_2447_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2450})});
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){v_t_2451, v_st_2448});
    }
    default: return heff_nomatch(v_x11_2447);
    }
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam4(V self, V *args) {
  V v_st_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_st_2456}));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_MkPair: {
    V v_x11_2458 = heff_field(v_x1_2457, 0);
    V v_st_2459 = heff_field(v_x1_2457, 1);
    V v_ru_24x1_2457_24MkPair = heff_take_reuse_n(v_x1_2457, 3ULL, 2);
    switch (heff_tag_of(v_x11_2458)) {
    case TAG_Left: {
      V v_e_2460 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2460}), v_st_2459});
    }
    case TAG_Right: {
      V v_x_2461 = heff_field(v_x11_2458, 0);
      V v_ru_24x11_2458_24Right = heff_take_reuse_n(v_x11_2458, 1ULL, 1);
      V v_t_2462 = heff_tag_at_n(v_ru_24x11_2458_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2461})});
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){v_t_2462, v_st_2459});
    }
    default: return heff_nomatch(v_x11_2458);
    }
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam5(V self, V *args) {
  V v_st_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_st_2468}));
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_MkPair: {
    V v_x11_2470 = heff_field(v_x1_2469, 0);
    V v_st_2471 = heff_field(v_x1_2469, 1);
    V v_ru_24x1_2469_24MkPair = heff_take_reuse_n(v_x1_2469, 3ULL, 2);
    switch (heff_tag_of(v_x11_2470)) {
    case TAG_Left: {
      V v_e_2472 = heff_field(v_x11_2470, 0);
      heff_take_n(v_x11_2470, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2472}), v_st_2471});
    }
    case TAG_Right: {
      V v_x_2473 = heff_field(v_x11_2470, 0);
      V v_ru_24x11_2470_24Right = heff_take_reuse_n(v_x11_2470, 1ULL, 1);
      V v_t_2474 = heff_tag_at_n(v_ru_24x11_2470_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2473})});
      return heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_MkPair, 2, (V[]){v_t_2474, v_st_2471});
    }
    default: return heff_nomatch(v_x11_2470);
    }
  }
  default: return heff_nomatch(v_x1_2469);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam6(V self, V *args) {
  V v_st_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_st_2482}));
  switch (heff_tag_of(v_x1_2483)) {
  case TAG_MkPair: {
    V v_x11_2484 = heff_field(v_x1_2483, 0);
    V v_st_2485 = heff_field(v_x1_2483, 1);
    V v_ru_24x1_2483_24MkPair = heff_take_reuse_n(v_x1_2483, 3ULL, 2);
    switch (heff_tag_of(v_x11_2484)) {
    case TAG_Left: {
      V v_e_2486 = heff_field(v_x11_2484, 0);
      heff_take_n(v_x11_2484, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2486}), v_st_2485});
    }
    case TAG_Right: {
      V v_x_2487 = heff_field(v_x11_2484, 0);
      V v_ru_24x11_2484_24Right = heff_take_reuse_n(v_x11_2484, 1ULL, 1);
      V v_t_2488 = heff_tag_at_n(v_ru_24x11_2484_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2487})});
      return heff_tag_at_n(v_ru_24x1_2483_24MkPair, TAG_MkPair, 2, (V[]){v_t_2488, v_st_2485});
    }
    default: return heff_nomatch(v_x11_2484);
    }
  }
  default: return heff_nomatch(v_x1_2483);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam7(V self, V *args) {
  V v_st_2493 = args[0];
  V v_m_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2494 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_st_2493}));
  switch (heff_tag_of(v_x1_2494)) {
  case TAG_MkPair: {
    V v_x11_2495 = heff_field(v_x1_2494, 0);
    V v_st_2496 = heff_field(v_x1_2494, 1);
    V v_ru_24x1_2494_24MkPair = heff_take_reuse_n(v_x1_2494, 3ULL, 2);
    switch (heff_tag_of(v_x11_2495)) {
    case TAG_Left: {
      V v_e_2497 = heff_field(v_x11_2495, 0);
      heff_take_n(v_x11_2495, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2497}), v_st_2496});
    }
    case TAG_Right: {
      V v_x_2498 = heff_field(v_x11_2495, 0);
      V v_ru_24x11_2495_24Right = heff_take_reuse_n(v_x11_2495, 1ULL, 1);
      V v_t_2499 = heff_tag_at_n(v_ru_24x11_2495_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_2498})});
      return heff_tag_at_n(v_ru_24x1_2494_24MkPair, TAG_MkPair, 2, (V[]){v_t_2499, v_st_2496});
    }
    default: return heff_nomatch(v_x11_2495);
    }
  }
  default: return heff_nomatch(v_x1_2494);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam8(V self, V *args) {
  V v_st_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_o_24100 = heff_env(self)[1];
  V v_c_24104 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_st_24106}));
  switch (heff_tag_of(v_x1_24107)) {
  case TAG_MkPair: {
    V v_x11_24108 = heff_field(v_x1_24107, 0);
    V v_st_24109 = heff_field(v_x1_24107, 1);
    V v_ru_24x1_24107_24MkPair = heff_take_reuse_n(v_x1_24107, 3ULL, 2);
    switch (heff_tag_of(v_x11_24108)) {
    case TAG_Left: {
      V v_e_24110 = heff_field(v_x11_24108, 0);
      heff_take_n(v_x11_24108, 1ULL, 1);
      heff_drop_rec(v_o_24100, 9);
      heff_drop_rec(v_c_24104, 9);
      return heff_tag_at_n(v_ru_24x1_24107_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24110}), v_st_24109});
    }
    case TAG_Right: {
      V v_x_24111 = heff_field(v_x11_24108, 0);
      V v_ru_24x11_24108_24Right = heff_take_reuse_n(v_x11_24108, 1ULL, 1);
      V v_t_24112 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24100, 3, 9), heff_get_n(v_c_24104, 4, 9)});
      V v_t_24113 = heff_tag_at_n(v_ru_24x11_24108_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Bracketed, 2, (V[]){v_x_24111, v_t_24112})});
      return heff_tag_at_n(v_ru_24x1_24107_24MkPair, TAG_MkPair, 2, (V[]){v_t_24113, v_st_24109});
    }
    default: return heff_nomatch(v_x11_24108);
    }
  }
  default: return heff_nomatch(v_x1_24107);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam9(V self, V *args) {
  V v_st_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_st_24118}));
  switch (heff_tag_of(v_x1_24119)) {
  case TAG_MkPair: {
    V v_x11_24120 = heff_field(v_x1_24119, 0);
    V v_st_24121 = heff_field(v_x1_24119, 1);
    V v_ru_24x1_24119_24MkPair = heff_take_reuse_n(v_x1_24119, 3ULL, 2);
    switch (heff_tag_of(v_x11_24120)) {
    case TAG_Left: {
      V v_e_24122 = heff_field(v_x11_24120, 0);
      heff_take_n(v_x11_24120, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24122}), v_st_24121});
    }
    case TAG_Right: {
      V v_x_24123 = heff_field(v_x11_24120, 0);
      V v_ru_24x11_24120_24Right = heff_take_reuse_n(v_x11_24120, 1ULL, 1);
      V v_t_24124 = heff_tag_at_n(v_ru_24x11_24120_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24123})});
      return heff_tag_at_n(v_ru_24x1_24119_24MkPair, TAG_MkPair, 2, (V[]){v_t_24124, v_st_24121});
    }
    default: return heff_nomatch(v_x11_24120);
    }
  }
  default: return heff_nomatch(v_x1_24119);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam10(V self, V *args) {
  V v_st_24129 = args[0];
  V v_m_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24130 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_st_24129}));
  switch (heff_tag_of(v_x1_24130)) {
  case TAG_MkPair: {
    V v_x11_24131 = heff_field(v_x1_24130, 0);
    V v_st_24132 = heff_field(v_x1_24130, 1);
    V v_ru_24x1_24130_24MkPair = heff_take_reuse_n(v_x1_24130, 3ULL, 2);
    switch (heff_tag_of(v_x11_24131)) {
    case TAG_Left: {
      V v_e_24133 = heff_field(v_x11_24131, 0);
      heff_take_n(v_x11_24131, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24130_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24133}), v_st_24132});
    }
    case TAG_Right: {
      V v_x_24134 = heff_field(v_x11_24131, 0);
      V v_ru_24x11_24131_24Right = heff_take_reuse_n(v_x11_24131, 1ULL, 1);
      V v_t_24135 = heff_tag_at_n(v_ru_24x11_24131_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24134})});
      return heff_tag_at_n(v_ru_24x1_24130_24MkPair, TAG_MkPair, 2, (V[]){v_t_24135, v_st_24132});
    }
    default: return heff_nomatch(v_x11_24131);
    }
  }
  default: return heff_nomatch(v_x1_24130);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam11(V self, V *args) {
  V v_st_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_st_24142}));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
      V v_t_24148 = heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24147})});
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){v_t_24148, v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam12(V self, V *args) {
  V v_st_24152 = args[0];
  V v_m_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24153 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_st_24152}));
  switch (heff_tag_of(v_x1_24153)) {
  case TAG_MkPair: {
    V v_x11_24154 = heff_field(v_x1_24153, 0);
    V v_st_24155 = heff_field(v_x1_24153, 1);
    V v_ru_24x1_24153_24MkPair = heff_take_reuse_n(v_x1_24153, 3ULL, 2);
    switch (heff_tag_of(v_x11_24154)) {
    case TAG_Left: {
      V v_e_24156 = heff_field(v_x11_24154, 0);
      heff_take_n(v_x11_24154, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24156}), v_st_24155});
    }
    case TAG_Right: {
      V v_x_24157 = heff_field(v_x11_24154, 0);
      V v_ru_24x11_24154_24Right = heff_take_reuse_n(v_x11_24154, 1ULL, 1);
      V v_t_24158 = heff_tag_at_n(v_ru_24x11_24154_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24157})});
      return heff_tag_at_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, (V[]){v_t_24158, v_st_24155});
    }
    default: return heff_nomatch(v_x11_24154);
    }
  }
  default: return heff_nomatch(v_x1_24153);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam13(V self, V *args) {
  V v_st_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24163 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_st_24162}));
  switch (heff_tag_of(v_x1_24163)) {
  case TAG_MkPair: {
    V v_x11_24164 = heff_field(v_x1_24163, 0);
    V v_st_24165 = heff_field(v_x1_24163, 1);
    V v_ru_24x1_24163_24MkPair = heff_take_reuse_n(v_x1_24163, 3ULL, 2);
    switch (heff_tag_of(v_x11_24164)) {
    case TAG_Left: {
      V v_e_24166 = heff_field(v_x11_24164, 0);
      heff_take_n(v_x11_24164, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24166}), v_st_24165});
    }
    case TAG_Right: {
      V v_x_24167 = heff_field(v_x11_24164, 0);
      V v_ru_24x11_24164_24Right = heff_take_reuse_n(v_x11_24164, 1ULL, 1);
      V v_t_24168 = heff_tag_at_n(v_ru_24x11_24164_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24167})});
      return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){v_t_24168, v_st_24165});
    }
    default: return heff_nomatch(v_x11_24164);
    }
  }
  default: return heff_nomatch(v_x1_24163);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam14(V self, V *args) {
  V v_st_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_st_24172}));
  switch (heff_tag_of(v_x1_24173)) {
  case TAG_MkPair: {
    V v_x11_24174 = heff_field(v_x1_24173, 0);
    V v_st_24175 = heff_field(v_x1_24173, 1);
    V v_ru_24x1_24173_24MkPair = heff_take_reuse_n(v_x1_24173, 3ULL, 2);
    switch (heff_tag_of(v_x11_24174)) {
    case TAG_Left: {
      V v_e_24176 = heff_field(v_x11_24174, 0);
      heff_take_n(v_x11_24174, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24176}), v_st_24175});
    }
    case TAG_Right: {
      V v_x_24177 = heff_field(v_x11_24174, 0);
      V v_ru_24x11_24174_24Right = heff_take_reuse_n(v_x11_24174, 1ULL, 1);
      V v_t_24178 = heff_tag_at_n(v_ru_24x11_24174_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24177})});
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){v_t_24178, v_st_24175});
    }
    default: return heff_nomatch(v_x11_24174);
    }
  }
  default: return heff_nomatch(v_x1_24173);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam15(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24188 = heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24187})});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){v_t_24188, v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam16(V self, V *args) {
  V v_st_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_st_24193}));
  switch (heff_tag_of(v_x1_24194)) {
  case TAG_MkPair: {
    V v_x11_24195 = heff_field(v_x1_24194, 0);
    V v_st_24196 = heff_field(v_x1_24194, 1);
    V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
    switch (heff_tag_of(v_x11_24195)) {
    case TAG_Left: {
      V v_e_24197 = heff_field(v_x11_24195, 0);
      heff_take_n(v_x11_24195, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24197}), v_st_24196});
    }
    case TAG_Right: {
      V v_x_24198 = heff_field(v_x11_24195, 0);
      V v_ru_24x11_24195_24Right = heff_take_reuse_n(v_x11_24195, 1ULL, 1);
      V v_t_24199 = heff_tag_at_n(v_ru_24x11_24195_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24198})});
      return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){v_t_24199, v_st_24196});
    }
    default: return heff_nomatch(v_x11_24195);
    }
  }
  default: return heff_nomatch(v_x1_24194);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam17(V self, V *args) {
  V v_st_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24204 = heff_tr(heff_call(v_m_24202, 1, (V[]){v_st_24203}));
  switch (heff_tag_of(v_x1_24204)) {
  case TAG_MkPair: {
    V v_x11_24205 = heff_field(v_x1_24204, 0);
    V v_st_24206 = heff_field(v_x1_24204, 1);
    V v_ru_24x1_24204_24MkPair = heff_take_reuse_n(v_x1_24204, 3ULL, 2);
    switch (heff_tag_of(v_x11_24205)) {
    case TAG_Left: {
      V v_e_24207 = heff_field(v_x11_24205, 0);
      heff_take_n(v_x11_24205, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24204_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24207}), v_st_24206});
    }
    case TAG_Right: {
      V v_x_24208 = heff_field(v_x11_24205, 0);
      V v_ru_24x11_24205_24Right = heff_take_reuse_n(v_x11_24205, 1ULL, 1);
      V v_t_24209 = heff_tag_at_n(v_ru_24x11_24205_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24208})});
      return heff_tag_at_n(v_ru_24x1_24204_24MkPair, TAG_MkPair, 2, (V[]){v_t_24209, v_st_24206});
    }
    default: return heff_nomatch(v_x11_24205);
    }
  }
  default: return heff_nomatch(v_x1_24204);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam18(V self, V *args) {
  V v_st_24213 = args[0];
  V v_m_24212 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24214 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_st_24213}));
  switch (heff_tag_of(v_x1_24214)) {
  case TAG_MkPair: {
    V v_x11_24215 = heff_field(v_x1_24214, 0);
    V v_st_24216 = heff_field(v_x1_24214, 1);
    V v_ru_24x1_24214_24MkPair = heff_take_reuse_n(v_x1_24214, 3ULL, 2);
    switch (heff_tag_of(v_x11_24215)) {
    case TAG_Left: {
      V v_e_24217 = heff_field(v_x11_24215, 0);
      heff_take_n(v_x11_24215, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24217}), v_st_24216});
    }
    case TAG_Right: {
      V v_x_24218 = heff_field(v_x11_24215, 0);
      V v_ru_24x11_24215_24Right = heff_take_reuse_n(v_x11_24215, 1ULL, 1);
      V v_t_24219 = heff_tag_at_n(v_ru_24x11_24215_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24218})});
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){v_t_24219, v_st_24216});
    }
    default: return heff_nomatch(v_x11_24215);
    }
  }
  default: return heff_nomatch(v_x1_24214);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam19(V self, V *args) {
  V v_st_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_st_24224}));
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_MkPair: {
    V v_x11_24226 = heff_field(v_x1_24225, 0);
    V v_st_24227 = heff_field(v_x1_24225, 1);
    V v_ru_24x1_24225_24MkPair = heff_take_reuse_n(v_x1_24225, 3ULL, 2);
    switch (heff_tag_of(v_x11_24226)) {
    case TAG_Left: {
      V v_e_24228 = heff_field(v_x11_24226, 0);
      heff_take_n(v_x11_24226, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24228}), v_st_24227});
    }
    case TAG_Right: {
      V v_x_24229 = heff_field(v_x11_24226, 0);
      V v_ru_24x11_24226_24Right = heff_take_reuse_n(v_x11_24226, 1ULL, 1);
      V v_t_24230 = heff_tag_at_n(v_ru_24x11_24226_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24229})});
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){v_t_24230, v_st_24227});
    }
    default: return heff_nomatch(v_x11_24226);
    }
  }
  default: return heff_nomatch(v_x1_24225);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam20(V self, V *args) {
  V v_st_24233 = args[0];
  V v_m_24232 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24234 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_st_24233}));
  switch (heff_tag_of(v_x1_24234)) {
  case TAG_MkPair: {
    V v_x11_24235 = heff_field(v_x1_24234, 0);
    V v_st_24236 = heff_field(v_x1_24234, 1);
    V v_ru_24x1_24234_24MkPair = heff_take_reuse_n(v_x1_24234, 3ULL, 2);
    switch (heff_tag_of(v_x11_24235)) {
    case TAG_Left: {
      V v_e_24237 = heff_field(v_x11_24235, 0);
      heff_take_n(v_x11_24235, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24237}), v_st_24236});
    }
    case TAG_Right: {
      V v_x_24238 = heff_field(v_x11_24235, 0);
      V v_ru_24x11_24235_24Right = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
      V v_t_24239 = heff_tag_at_n(v_ru_24x11_24235_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24238})});
      return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){v_t_24239, v_st_24236});
    }
    default: return heff_nomatch(v_x11_24235);
    }
  }
  default: return heff_nomatch(v_x1_24234);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam21(V self, V *args) {
  V v_st_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_st_24244}));
  switch (heff_tag_of(v_x1_24245)) {
  case TAG_MkPair: {
    V v_x11_24246 = heff_field(v_x1_24245, 0);
    V v_st_24247 = heff_field(v_x1_24245, 1);
    V v_ru_24x1_24245_24MkPair = heff_take_reuse_n(v_x1_24245, 3ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_Left: {
      V v_e_24248 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24248}), v_st_24247});
    }
    case TAG_Right: {
      V v_x_24249 = heff_field(v_x11_24246, 0);
      V v_ru_24x11_24246_24Right = heff_take_reuse_n(v_x11_24246, 1ULL, 1);
      V v_t_24250 = heff_tag_at_n(v_ru_24x11_24246_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24249})});
      return heff_tag_at_n(v_ru_24x1_24245_24MkPair, TAG_MkPair, 2, (V[]){v_t_24250, v_st_24247});
    }
    default: return heff_nomatch(v_x11_24246);
    }
  }
  default: return heff_nomatch(v_x1_24245);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam22(V self, V *args) {
  V v_st_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24258 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_st_24257}));
  switch (heff_tag_of(v_x1_24258)) {
  case TAG_MkPair: {
    V v_x11_24259 = heff_field(v_x1_24258, 0);
    V v_st_24260 = heff_field(v_x1_24258, 1);
    V v_ru_24x1_24258_24MkPair = heff_take_reuse_n(v_x1_24258, 3ULL, 2);
    switch (heff_tag_of(v_x11_24259)) {
    case TAG_Left: {
      V v_e_24261 = heff_field(v_x11_24259, 0);
      heff_take_n(v_x11_24259, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24258_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24261}), v_st_24260});
    }
    case TAG_Right: {
      V v_x_24262 = heff_field(v_x11_24259, 0);
      V v_ru_24x11_24259_24Right = heff_take_reuse_n(v_x11_24259, 1ULL, 1);
      V v_t_24263 = heff_tag_at_n(v_ru_24x11_24259_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24262})});
      return heff_tag_at_n(v_ru_24x1_24258_24MkPair, TAG_MkPair, 2, (V[]){v_t_24263, v_st_24260});
    }
    default: return heff_nomatch(v_x11_24259);
    }
  }
  default: return heff_nomatch(v_x1_24258);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam23(V self, V *args) {
  V v_st_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24270 = heff_tr(heff_call(v_m_24268, 1, (V[]){v_st_24269}));
  switch (heff_tag_of(v_x1_24270)) {
  case TAG_MkPair: {
    V v_x11_24271 = heff_field(v_x1_24270, 0);
    V v_st_24272 = heff_field(v_x1_24270, 1);
    V v_ru_24x1_24270_24MkPair = heff_take_reuse_n(v_x1_24270, 3ULL, 2);
    switch (heff_tag_of(v_x11_24271)) {
    case TAG_Left: {
      V v_e_24273 = heff_field(v_x11_24271, 0);
      heff_take_n(v_x11_24271, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24273}), v_st_24272});
    }
    case TAG_Right: {
      V v_x_24274 = heff_field(v_x11_24271, 0);
      V v_ru_24x11_24271_24Right = heff_take_reuse_n(v_x11_24271, 1ULL, 1);
      V v_t_24275 = heff_tag_at_n(v_ru_24x11_24271_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24274})});
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){v_t_24275, v_st_24272});
    }
    default: return heff_nomatch(v_x11_24271);
    }
  }
  default: return heff_nomatch(v_x1_24270);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam24(V self, V *args) {
  V v_st_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24281}));
  switch (heff_tag_of(v_x1_24282)) {
  case TAG_MkPair: {
    V v_x11_24283 = heff_field(v_x1_24282, 0);
    V v_st_24284 = heff_field(v_x1_24282, 1);
    V v_ru_24x1_24282_24MkPair = heff_take_reuse_n(v_x1_24282, 3ULL, 2);
    switch (heff_tag_of(v_x11_24283)) {
    case TAG_Left: {
      V v_e_24285 = heff_field(v_x11_24283, 0);
      heff_take_n(v_x11_24283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24285}), v_st_24284});
    }
    case TAG_Right: {
      V v_x_24286 = heff_field(v_x11_24283, 0);
      V v_ru_24x11_24283_24Right = heff_take_reuse_n(v_x11_24283, 1ULL, 1);
      V v_t_24287 = heff_tag_at_n(v_ru_24x11_24283_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24286})});
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){v_t_24287, v_st_24284});
    }
    default: return heff_nomatch(v_x11_24283);
    }
  }
  default: return heff_nomatch(v_x1_24282);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam25(V self, V *args) {
  V v_st_24292 = args[0];
  V v_m_24291 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24293 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_st_24292}));
  switch (heff_tag_of(v_x1_24293)) {
  case TAG_MkPair: {
    V v_x11_24294 = heff_field(v_x1_24293, 0);
    V v_st_24295 = heff_field(v_x1_24293, 1);
    V v_ru_24x1_24293_24MkPair = heff_take_reuse_n(v_x1_24293, 3ULL, 2);
    switch (heff_tag_of(v_x11_24294)) {
    case TAG_Left: {
      V v_e_24296 = heff_field(v_x11_24294, 0);
      heff_take_n(v_x11_24294, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24293_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24296}), v_st_24295});
    }
    case TAG_Right: {
      V v_x_24297 = heff_field(v_x11_24294, 0);
      V v_ru_24x11_24294_24Right = heff_take_reuse_n(v_x11_24294, 1ULL, 1);
      V v_t_24298 = heff_tag_at_n(v_ru_24x11_24294_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24297})});
      return heff_tag_at_n(v_ru_24x1_24293_24MkPair, TAG_MkPair, 2, (V[]){v_t_24298, v_st_24295});
    }
    default: return heff_nomatch(v_x11_24294);
    }
  }
  default: return heff_nomatch(v_x1_24293);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam26(V self, V *args) {
  V v_st_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24307 = heff_tr(heff_call(v_m_24305, 1, (V[]){v_st_24306}));
  switch (heff_tag_of(v_x1_24307)) {
  case TAG_MkPair: {
    V v_x11_24308 = heff_field(v_x1_24307, 0);
    V v_st_24309 = heff_field(v_x1_24307, 1);
    V v_ru_24x1_24307_24MkPair = heff_take_reuse_n(v_x1_24307, 3ULL, 2);
    switch (heff_tag_of(v_x11_24308)) {
    case TAG_Left: {
      V v_e_24310 = heff_field(v_x11_24308, 0);
      heff_take_n(v_x11_24308, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24310}), v_st_24309});
    }
    case TAG_Right: {
      V v_x_24311 = heff_field(v_x11_24308, 0);
      V v_ru_24x11_24308_24Right = heff_take_reuse_n(v_x11_24308, 1ULL, 1);
      V v_t_24312 = heff_tag_at_n(v_ru_24x11_24308_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24311})});
      return heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_MkPair, 2, (V[]){v_t_24312, v_st_24309});
    }
    default: return heff_nomatch(v_x11_24308);
    }
  }
  default: return heff_nomatch(v_x1_24307);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam27(V self, V *args) {
  V v_st_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24317 = heff_tr(heff_call(v_m_24315, 1, (V[]){v_st_24316}));
  switch (heff_tag_of(v_x1_24317)) {
  case TAG_MkPair: {
    V v_x11_24318 = heff_field(v_x1_24317, 0);
    V v_st_24319 = heff_field(v_x1_24317, 1);
    V v_ru_24x1_24317_24MkPair = heff_take_reuse_n(v_x1_24317, 3ULL, 2);
    switch (heff_tag_of(v_x11_24318)) {
    case TAG_Left: {
      V v_e_24320 = heff_field(v_x11_24318, 0);
      heff_take_n(v_x11_24318, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24320}), v_st_24319});
    }
    case TAG_Right: {
      V v_x_24321 = heff_field(v_x11_24318, 0);
      V v_ru_24x11_24318_24Right = heff_take_reuse_n(v_x11_24318, 1ULL, 1);
      V v_t_24322 = heff_tag_at_n(v_ru_24x11_24318_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24321})});
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){v_t_24322, v_st_24319});
    }
    default: return heff_nomatch(v_x11_24318);
    }
  }
  default: return heff_nomatch(v_x1_24317);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam28(V self, V *args) {
  V v_st_24327 = args[0];
  V v_m_24326 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24328 = heff_tr(heff_call(v_m_24326, 1, (V[]){v_st_24327}));
  switch (heff_tag_of(v_x1_24328)) {
  case TAG_MkPair: {
    V v_x11_24329 = heff_field(v_x1_24328, 0);
    V v_st_24330 = heff_field(v_x1_24328, 1);
    V v_ru_24x1_24328_24MkPair = heff_take_reuse_n(v_x1_24328, 3ULL, 2);
    switch (heff_tag_of(v_x11_24329)) {
    case TAG_Left: {
      V v_e_24331 = heff_field(v_x11_24329, 0);
      heff_take_n(v_x11_24329, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24328_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24331}), v_st_24330});
    }
    case TAG_Right: {
      V v_x_24332 = heff_field(v_x11_24329, 0);
      V v_ru_24x11_24329_24Right = heff_take_reuse_n(v_x11_24329, 1ULL, 1);
      V v_t_24333 = heff_tag_at_n(v_ru_24x11_24329_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24332})});
      return heff_tag_at_n(v_ru_24x1_24328_24MkPair, TAG_MkPair, 2, (V[]){v_t_24333, v_st_24330});
    }
    default: return heff_nomatch(v_x11_24329);
    }
  }
  default: return heff_nomatch(v_x1_24328);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam29(V self, V *args) {
  V v_st_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_st_24341}));
  switch (heff_tag_of(v_x1_24342)) {
  case TAG_MkPair: {
    V v_x11_24343 = heff_field(v_x1_24342, 0);
    V v_st_24344 = heff_field(v_x1_24342, 1);
    V v_ru_24x1_24342_24MkPair = heff_take_reuse_n(v_x1_24342, 3ULL, 2);
    switch (heff_tag_of(v_x11_24343)) {
    case TAG_Left: {
      V v_e_24345 = heff_field(v_x11_24343, 0);
      heff_take_n(v_x11_24343, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24345}), v_st_24344});
    }
    case TAG_Right: {
      V v_x_24346 = heff_field(v_x11_24343, 0);
      V v_ru_24x11_24343_24Right = heff_take_reuse_n(v_x11_24343, 1ULL, 1);
      V v_t_24347 = heff_tag_at_n(v_ru_24x11_24343_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Plain, 1, (V[]){v_x_24346})});
      return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){v_t_24347, v_st_24344});
    }
    default: return heff_nomatch(v_x11_24343);
    }
  }
  default: return heff_nomatch(v_x1_24342);
  }
}
V g_heff_2esyntax_2esurface_2eopL_lam30(V self, V *args) {
  V v_m_24387 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_24387));
}
Clo g_heff_2esyntax_2esurface_2etwoToS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etwoToS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etwoToS(V v_k_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etwoToS(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_str0, 48, "a number's segment is an integer: `1`, `258::16`");
Clo g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_entry, 3, 0};

V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754(V v_sp_240, V v_v_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_StrValue: {
    heff_drop(v_sp_240);
    V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_IntValue: {
    V v_ru_24v_241_24IntValue = heff_take_reuse_n(v_v_241, 0ULL, 1);
    V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_str0), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_245}), v_p_242});
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_240);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str0, 69, "a segment of a binary pattern holds a name, `_`, a number or a string");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_str1, 93, "only the last segment takes the bytes that are left: say this one's size, `x::binary-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_entry, 6, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith(V v_r_240, V v_last_241, V v_sp_242, V v_p_243, V v_s_244, V v_z_245) {
top: ;
  V v_x2_246 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam0, 1, 2, (V[]){v_x2_246, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_lam1, 2, 5, (V[]){v_r_240, v_p_243, v_sp_242, v_s_244, heff_dup(v_last_241)}), v_z_245));
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x2_246 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_246) == NTAG(TAG_True))) {
    heff_drop(v_x2_246);
    heff_drop(v_sp_242);
    V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_p_247});
  } else {
    heff_drop(v_x2_246);
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_p_247});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_z_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_last_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_2411}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_s_244);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_At: {
        V v_x11_2418 = heff_dup(heff_field(v_x_2417, 0));
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2427 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          v_t_2437 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_IntValue, 1, (V[]){v_v_2427});
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2414_24Right, 1);
          v_t_2437 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2418);
        }
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      V v_m_2438 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_242); V a_2 = v_x_2417; V a_3 = v_t_2437; V a_4 = v_s_244; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2415}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        heff_take_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          if ((heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2443}), v_st_2441});
          } else {
            heff_drop(v_last_241);
            V v_t_2446;
            switch (heff_tag_of(v_x_2443)) {
            case TAG_At: {
              V v_x_2444 = heff_dup(heff_field(v_x_2443, 0));
              v_t_2446 = v_x_2444;
              break;
            }
            default: heff_nomatch(v_x_2443);
            }
            V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2446); r_; });
            if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
              heff_drop(v_x_2443);
              heff_drop(v_t_2447);
              V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2448}), v_st_2441});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2447);
              return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2443}), v_st_2441});
            }
          }
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eargL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eargL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eargL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EParen: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Named: {
    V v_o_246 = heff_field(v_e_241, 0);
    V v_x_247 = heff_field(v_e_241, 1);
    V v_e4_249 = heff_field(v_e_241, 3);
    V v_c_2410 = heff_field(v_e_241, 4);
    heff_take_n(v_e_241, 27ULL, 5);
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e4_249}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eargL_lam0, 1, 4, (V[]){v_m_2411, v_x_247, v_o_246, v_c_2410});
  }
  case TAG_Tup: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Seg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Braces: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Update: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EUSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_InstB: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EFDefault: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Sum: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ECon: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EField: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ENeg: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_App: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Op: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Ops: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Ann: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BVar: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BImp: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Lam: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Case: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_If: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_Do: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    return heff_tail(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eargL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eargL_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_o_246 = heff_env(self)[2];
  V v_c_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_x_247, 9);
      heff_drop_rec(v_o_246, 9);
      heff_drop_rec(v_c_2410, 9);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_tag_n(TAG_ENamed, 2, (V[]){heff_get_n(v_x_247, 1, 9), v_x_2417});
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_246, 3, 9), heff_get_n(v_c_2410, 4, 9)});
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419})});
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyPatOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabAbove_str0, 68, "`above` names the operators it is above (`below` alone is below all)");
Clo g_heff_2esyntax_2esurface_2eabAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabAbove_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eabAbove(V v_acc_240, V v_w_241, V v_ops_242) {
top: ;
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_241, 2), heff_get_n(v_w_241, 3, 7)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eabAbove_str0), v_t_243, NTAG(TAG_Nothing)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_240, 3)});
    return ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_240, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Cons: {
    heff_drop_rec(v_w_241, 7);
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_acc_240, 0), v_ops_242));
    return ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_240, 14ULL, 4, shape_above__below__loosest__errors, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eabAbove_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabAbove(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str1, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str2, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_str3, 6, "infixr");
Clo g_heff_2esyntax_2esurface_2efixDeclAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclAt_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDeclAt(V v_ts_240, V v_k_241, V v_t_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_242, 6));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str0))) {
        V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 1))}));
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str1), NTAG(TAG_Nil)});
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_str3), v_t_247})});
        V v_t_249 = ({ V a_0 = v_t_246; V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_248, 2); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_t_2410 = (g_heff_2esyntax_2esurface_2efixDeclOf(v_ts_240, v_k_241, v_t_242));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
        } else {
          heff_drop(v_ts_240);
          heff_drop(v_k_241);
          heff_drop_rec(v_t_242, 7);
          heff_drop(v_t_249);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_ts_240);
        heff_drop(v_k_241);
        heff_drop_rec(v_t_242, 7);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_ts_240);
      heff_drop(v_k_241);
      heff_drop_rec(v_t_242, 7);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_ts_240);
    heff_drop(v_k_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_243);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2esyntax_2esurface_2efixDeclAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDeclAt(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
  V v_f_246 = heff_get_n(v_t_245, 0, 2);
  V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(v_f_246, heff_rfield(v_st_244, 3)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_x1_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_249}), v_st_244});
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_pats_241);
      heff_drop(v_rhs_242);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_pv_2416 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2414));
      V v_t_2417 = ({ V rv_4 = v_pv_2416; V rr_ = heff_rec_reuse_nf(v_st_2412, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_pats_241);
          heff_drop(v_rhs_242);
          heff_drop(v_x_2414);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          V v_m_2423 = (g_heff_2esyntax_2esurface_2etraverseS(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
          V v_x1_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_st_2420}));
          switch (heff_tag_of(v_x1_2424)) {
          case TAG_MkPair: {
            V v_x11_2425 = heff_field(v_x1_2424, 0);
            V v_st_2426 = heff_field(v_x1_2424, 1);
            heff_take_n(v_x1_2424, 3ULL, 2);
            switch (heff_tag_of(v_x11_2425)) {
            case TAG_Left: {
              V v_e_2427 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              heff_drop(v_pats_241);
              heff_drop(v_rhs_242);
              heff_drop(v_x_2414);
              return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
            }
            case TAG_Right: {
              V v_x_2428 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
              V v_t_2429 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2414));
              V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2429}));
              V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
              V v_t_2432 = ({ V a_0 = v_x_2414; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_x_2414); r_; });
              V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2431, v_t_2432));
              V v_t_2434 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2426, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2433, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), heff_dup(v_names_240), v_x_2428}), v_t_2434));
            }
            default: return heff_nomatch(v_x11_2425);
            }
          }
          default: return heff_nomatch(v_x1_2424);
          }
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1(V self, V *args) {
  V v_st_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2440}), v_st_2441});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam0(V self, V *args) {
  V v_st_2435 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2428);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_m_2445;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_m_2445 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_lam1, 1, 1, (V[]){v_x_2440});
        break;
      }
      case TAG_Just: {
        V v_it1_2442 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        switch (heff_tag_of(v_it1_2442)) {
        case TAG_MkPair: {
          V v_kw_2443 = heff_field(v_it1_2442, 0);
          V v_ds_2444 = heff_field(v_it1_2442, 1);
          heff_take_n(v_it1_2442, 3ULL, 2);
          v_m_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo), 3, (V[]){v_kw_2443, v_ds_2444, v_x_2440}));
          break;
        }
        default: heff_nomatch(v_it1_2442);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      V v_x1_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_st_2438}));
      switch (heff_tag_of(v_x1_2446)) {
      case TAG_MkPair: {
        V v_x11_2447 = heff_field(v_x1_2446, 0);
        V v_st_2448 = heff_field(v_x1_2446, 1);
        V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
        switch (heff_tag_of(v_x11_2447)) {
        case TAG_Left: {
          V v_e_2449 = heff_field(v_x11_2447, 0);
          heff_take_n(v_x11_2447, 1ULL, 1);
          heff_drop(v_names_240);
          heff_drop(v_x_2428);
          heff_drop_cell(v_ru_24x1_2446_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
        }
        case TAG_Right: {
          V v_x_2450 = heff_field(v_x11_2447, 0);
          heff_take_n(v_x11_2447, 1ULL, 1);
          V v_t_2451 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2452 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2453 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2454 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2452, 0, 2), heff_get_n(v_t_2453, 1, 2), v_x_2428, heff_dup(v_x_2450)});
          V v_t_2457;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_t_2457 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2455 = heff_dup(heff_field(v_names_240, 0));
            v_t_2457 = heff_get_n(v_t_2455, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2460;
          switch (heff_tag_of(v_x_2450)) {
          case TAG_At: {
            V v_s_2459 = heff_dup(heff_field(v_x_2450, 1));
            v_t_2460 = v_s_2459;
            break;
          }
          default: heff_nomatch(v_x_2450);
          }
          V v_t_2461 = ({ V rv_0 = v_t_2457; V rr_ = heff_rec_reuse_nf(v_t_2460, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2464;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_t_2464 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2462 = heff_field(v_names_240, 0);
            heff_take_n(v_names_240, 1ULL, 2);
            v_t_2464 = heff_get_n(v_t_2462, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2467;
          switch (heff_tag_of(v_x_2450)) {
          case TAG_At: {
            V v_s_2466 = heff_field(v_x_2450, 1);
            heff_take_n(v_x_2450, 2ULL, 2);
            v_t_2467 = v_s_2466;
            break;
          }
          default: heff_nomatch(v_x_2450);
          }
          V v_t_2468 = ({ V rv_0 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_t_2467, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2469 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2451, 0, 2), heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_At, 2, (V[]){v_t_2454, v_t_2461}), v_t_2468});
          V v_x_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2470}), v_st_2448});
        }
        default: return heff_nomatch(v_x11_2447);
        }
      }
      default: return heff_nomatch(v_x1_2446);
      }
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry, 7, 0};

V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245, V v_z_246) {
top: ;
  V v_m_247 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_params_243));
  V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
      V v_t_2413 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2412)));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2413, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0, 1, 6, (V[]){heff_dup(v_universe_244), v_name_242, heff_dup(v_alts_245), v_d_240, v_kw_241, v_x_2412}), v_st_2410));
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(a[0], a[1], a[2], a[3], a4, a5, a[6]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_universe_244 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_alts_245 = heff_env(self)[2];
  V v_d_240 = heff_env(self)[3];
  V v_kw_241 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2421;
  switch (heff_tag_of(v_universe_244)) {
  case TAG_Nothing: {
    V v_t_2415 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
    V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_name_242, 3)), heff_dup(heff_rfield(v_name_242, 4))});
    V v_t_2417 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416})});
    v_x1_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_st_2414});
    break;
  }
  case TAG_Just: {
    V v_it1_2418 = heff_field(v_universe_244, 0);
    heff_take_n(v_universe_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_2418)) {
    case TAG_MkPair: {
      V v_u_2420 = heff_field(v_it1_2418, 1);
      heff_take_n(v_it1_2418, 2ULL, 2);
      v_x1_2421 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_u_2420, v_st_2414));
      break;
    }
    default: heff_nomatch(v_it1_2418);
    }
    break;
  }
  default: heff_nomatch(v_universe_244);
  }
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_MkPair: {
    V v_x11_2422 = heff_field(v_x1_2421, 0);
    V v_st_2423 = heff_field(v_x1_2421, 1);
    V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
    switch (heff_tag_of(v_x11_2422)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x11_2422, 0);
      heff_take_n(v_x11_2422, 1ULL, 1);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_alts_245);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2412);
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x11_2422, 0);
      V v_ru_24x11_2422_24Right = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
      V v_t_2430;
      switch (heff_tag_of(v_alts_245)) {
      case TAG_Nothing: {
        v_t_2430 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2426 = heff_field(v_alts_245, 0);
        heff_take_n(v_alts_245, 1ULL, 1);
        switch (heff_tag_of(v_x11_2426)) {
        case TAG_MkDAlts: {
          V v_alts_2428 = heff_field(v_x11_2426, 1);
          heff_take_n(v_x11_2426, 2ULL, 3);
          v_t_2430 = v_alts_2428;
          break;
        }
        default: heff_nomatch(v_x11_2426);
        }
        break;
      }
      default: heff_nomatch(v_alts_245);
      }
      V v_m_2431 = (g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(v_t_2430));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_st_2423}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          heff_take_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_name_242, 9);
          heff_drop(v_d_240);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_x_2412);
          heff_drop(v_x_2425);
          heff_drop_cell(v_ru_24x11_2422_24Right, 1);
          heff_drop_cell(v_ru_24x1_2432_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
          V v_t_2438 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
          V v_e_2439 = heff_get_n(v_t_2438, 4, 9);
          V v_t_2440 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2439});
          V v_t_2441 = heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_ESum, 1, (V[]){v_x_2436}), v_t_2440});
          V v_t_2442 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2437, v_x_2412, v_x_2425, v_t_2441});
          V v_t_2443 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
          V v_e_2444 = heff_get_n(v_t_2443, 4, 9);
          V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2444});
          V v_t_2446 = heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2445})});
          V v_x_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2447}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    }
    default: return heff_nomatch(v_x11_2422);
    }
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_str0, 7, "doctest");
Clo g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(V v_d_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    V v_ru_24d_240_24DImport = heff_take_reuse_n(v_d_240, 0ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24d_240_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_z_241});
  }
  case TAG_DFixity: {
    V v_ru_24d_240_24DFixity = heff_take_reuse_n(v_d_240, 0ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24d_240_24DFixity, TAG_MkPair, 2, (V[]){v_t_246, v_z_241});
  }
  case TAG_DSig: {
    V v_names_247 = heff_field(v_d_240, 0);
    V v_ty_249 = heff_field(v_d_240, 2);
    heff_take_n(v_d_240, 5ULL, 3);
    V v_t_2412;
    switch (heff_tag_of(v_names_247)) {
    case TAG_Nil: {
      v_t_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_t_2410 = heff_dup(heff_field(v_names_247, 0));
      v_t_2412 = heff_get_n(v_t_2410, 3, 9);
      break;
    }
    default: heff_nomatch(v_names_247);
    }
    return ({ V a_0 = NTAG(TAG_AsDefinition); V a_1 = v_t_2412; V a_2 = v_names_247; V a_3 = v_ty_249; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_247); r_; });
  }
  case TAG_DInstance: {
    V v_kw_2413 = heff_field(v_d_240, 0);
    V v_names_2414 = heff_field(v_d_240, 1);
    V v_ty_2416 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return ({ V a_0 = NTAG(TAG_AsInstance); V a_1 = heff_get_n(v_kw_2413, 3, 9); V a_2 = v_names_2414; V a_3 = v_ty_2416; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2414); r_; });
  }
  case TAG_DEqn: {
    V v_names_2417 = heff_field(v_d_240, 0);
    V v_pats_2418 = heff_field(v_d_240, 1);
    V v_rhs_2420 = heff_field(v_d_240, 3);
    V v_w_2421 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 27ULL, 5);
    return ({ V a_0 = v_names_2417; V a_1 = v_pats_2418; V a_2 = v_rhs_2420; V a_3 = v_w_2421; V a_4 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2417); heff_drop(v_w_2421); r_; });
  }
  case TAG_DData: {
    V v_kw_2422 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2423 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2424 = heff_dup(heff_field(v_d_240, 2));
    V v_universe_2425 = heff_dup(heff_field(v_d_240, 3));
    V v_alts_2426 = heff_dup(heff_field(v_d_240, 4));
    return ({ V a_0 = v_d_240; V a_1 = v_kw_2422; V a_2 = v_name_2423; V a_3 = v_params_2424; V a_4 = v_universe_2425; V a_5 = v_alts_2426; V a_6 = v_z_241; V r_ = (g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_universe_2425); heff_drop(v_alts_2426); r_; });
  }
  case TAG_DType: {
    V v_kw_2427 = heff_field(v_d_240, 0);
    V v_name_2428 = heff_field(v_d_240, 1);
    V v_params_2429 = heff_field(v_d_240, 2);
    V v_body_2431 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(v_kw_2427, v_name_2428, v_params_2429, v_body_2431, v_z_241));
  }
  case TAG_DTheory: {
    V v_kw_2432 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2433 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2434 = heff_dup(heff_field(v_d_240, 2));
    V v_fields_2436 = heff_dup(heff_field(v_d_240, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(v_d_240, v_kw_2432, v_name_2433, v_params_2434, v_fields_2436, v_z_241));
  }
  case TAG_DPrimitive: {
    V v_kw_2437 = heff_field(v_d_240, 0);
    V v_x_2438 = heff_field(v_d_240, 1);
    V v_ty_2440 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(v_kw_2437, v_x_2438, v_ty_2440, v_z_241));
  }
  case TAG_DTest: {
    V v_kw_2441 = heff_field(v_d_240, 0);
    V v_x_2442 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DTest = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2442, 3), heff_dup(heff_rfield(v_x_2442, 4))});
    V v_t_2444 = heff_tag_at_n(v_ru_24d_240_24DTest, TAG_DeclTest, 2, (V[]){heff_dup(heff_rfield(v_x_2442, 1)), v_t_2443});
    V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2441, 3, 9), heff_get_n(v_x_2442, 4, 9)});
    V v_t_2446 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2447}), v_z_241});
  }
  case TAG_DWatch: {
    V v_w_2448 = heff_field(v_d_240, 0);
    V v_e_2449 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DWatch = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_x1_2450 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_2449), v_z_241));
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_MkPair: {
      V v_x11_2451 = heff_field(v_x1_2450, 0);
      V v_st_2452 = heff_field(v_x1_2450, 1);
      V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
      switch (heff_tag_of(v_x11_2451)) {
      case TAG_Left: {
        V v_e_2453 = heff_field(v_x11_2451, 0);
        heff_take_n(v_x11_2451, 1ULL, 1);
        heff_drop_rec(v_w_2448, 9);
        heff_drop(v_e_2449);
        heff_drop_cell(v_ru_24x1_2450_24MkPair, 2);
        return heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
      }
      case TAG_Right: {
        V v_x_2454 = heff_field(v_x11_2451, 0);
        V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
        V v_t_2455 = (g_heff_2esyntax_2ecst_2elastE(v_e_2449));
        V v_e_2456 = heff_get_n(v_t_2455, 4, 9);
        V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_2448, 3), v_e_2456});
        V v_d_2458 = heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2454}), v_t_2457});
        V v_t_2460;
        if (heff_strEq_c(heff_get_n(v_w_2448, 0, 9), ((V)&g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_str0))) {
          v_t_2460 = heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Doc, 1, (V[]){v_d_2458});
        } else {
          v_t_2460 = heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Whole, 1, (V[]){v_d_2458});
        }
        V v_x_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2452});
      }
      default: return heff_nomatch(v_x11_2451);
      }
    }
    default: return heff_nomatch(v_x1_2450);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ereadRun_str3, 1, ":");
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadRun_entry, 6, 0};

V g_heff_2esyntax_2esurface_2ereadRun(V v_src_240, V v_o_241, V v_toks_242, V v_lexDiags_243, V v_declared_244, V v_own_245) {
top: ;
  V v_path_246 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_path_248 = heff_dup(heff_rfield(v_o_241, 4));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2einitialSt(v_o_241, heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam0, 1, 2, (V[]){v_path_248, heff_dup(v_src_240)}), heff_dup(v_toks_242), v_declared_244, heff_dup(heff_rfield(v_own_245, 0))));
  V v_r_2413 = (g_heff_2esyntax_2esurface_2eprogGo(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_242, MK_INT(0LL), MK_INT(0LL), v_t_247, MK_INT(0LL)}), v_t_2412, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2414 = (g_heff_2esyntax_2esurface_2eplaceDocs(heff_dup(v_src_240), heff_rfield(v_r_2413, 0)));
  return (g_heff_2esyntax_2esurface_2ereadPlaced(heff_clo_n(g_heff_2esyntax_2esurface_2ereadRun_lam1, 1, 2, (V[]){v_path_246, v_src_240}), v_lexDiags_243, v_own_245, v_r_2413, v_t_2414));
}
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2esurface_2ereadRun(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2esyntax_2esurface_2ereadRun_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_path_248), ((V)&g_heff_2esyntax_2esurface_2ereadRun_str0))) {
    heff_drop(v_path_248);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2411 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_249, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_248, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str1), v_t_2411));
  }
}
V g_heff_2esyntax_2esurface_2ereadRun_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_path_246), ((V)&g_heff_2esyntax_2esurface_2ereadRun_str2))) {
    heff_drop(v_path_246);
    return (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
  } else {
    V v_t_2417 = (g_heff_2esyntax_2esurface_2elineColFrom(v_src_240, v_i_2415, MK_INT(1LL), MK_INT(0LL)));
    return heff_strAppend(v_path_246, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ereadRun_str3), v_t_2417));
  }
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ereadLexed(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  V v_ltoks_243 = heff_arrayFromList(heff_dup(heff_rfield(v_l_242, 0)));
  V v_t_244 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), heff_take_field(v_l_242, 0)));
  V v_toks_245 = heff_arrayFromList(v_t_244);
  V v_lexDiags_246 = (g_list_2emap_24s338694954x1326523169(heff_get_n(v_l_242, 1, 3)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2eprescanGo(heff_dup(v_ltoks_243), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_248 = (g_heff_2esyntax_2esurface_2efixDecls(v_ltoks_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249 = (g_heff_2esyntax_2esurface_2efixityFrom(heff_dup(heff_rfield(v_o_241, 3)), heff_dup(heff_rfield(v_o_241, 1)), v_t_248));
  return ({ V a_0 = v_src_240; V a_1 = v_o_241; V a_2 = v_toks_245; V a_3 = v_lexDiags_246; V a_4 = v_t_247; V a_5 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2ereadRun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
}
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadLexed(a[0], a[1], a[2]);
}