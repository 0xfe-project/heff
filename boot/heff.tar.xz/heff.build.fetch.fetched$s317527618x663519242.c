// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_clo;
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139(V, V, V);
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_clo;
HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(V, V, V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str0, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str1, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str3, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str6, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str8, 4, " in ");
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(V v_x_240, V v_x_241, V v_hd_242, V v_path_243, V v_v_244, V v_k_245, V v_x_246) {
top: ;
  V v_out_247 = heff_take_field(v_x_240, 1);
  V v_ended_248 = heff_get_n(v_x_240, 0, 3);
  V v_s_249 = v_out_247;
  V v_t_2410 = (g_prelude_2eskipSpaces(v_s_249, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_s_249, 0)) - ((int64_t)1ULL));
  V v_t_2412 = (g_prelude_2eskipSpaces(v_s_249, heff_box_word(v_t_2411), MK_INT(-1LL)));
  V v_t_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  V v_x_2414 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str0), v_t_2413);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str1))));
  return ({ V a_0 = v_t_2415; V a_1 = heff_strAppend(heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str2)); V a_2 = heff_dup(v_hd_242); V a_3 = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam0, 1, 8, (V[]){v_ended_248, heff_dup(v_x_246), v_path_243, v_v_244, v_hd_242, v_k_245, v_x_2414, v_x_241}); V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam1(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_drop(v_x_2432);
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ended_248 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  V v_x_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = v_ended_248;
  V v_t_2421;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Exited: {
    V v_n_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    v_t_2421 = heff_bool(heff_intEq_c_lent(v_n_2418, MK_INT(0LL), 2));
    heff_drop(v_n_2418);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2417, 0ULL, 1);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2417, 0ULL, 1);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_t_2437;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    V v_t_2440;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Left: {
      heff_take_n(v_x_246, 0ULL, 1);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x_246, 0ULL, 1);
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      v_t_2437 = v_x_2416;
      break;
    }
    case TAG_False: {
      heff_drop(v_x_2416);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_x_246);
    heff_drop(v_t_2421);
    v_t_2437 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    heff_drop(v_x_241);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str3), v_path_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str4));
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_v_244), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str5));
    V v_t_2426 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_242, heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_lam1, 1, 2, (V[]){v_k_245, v_x_2414})));
  }
  case TAG_False: {
    heff_drop(v_hd_242);
    heff_drop(v_x_2414);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str6), v_path_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str7));
    V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, v_v_244), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0_str8));
    V v_t_2435 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2434, v_x_241)});
    V f_ = v_k_245;
    args[0] = v_t_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(V v_x_240, V v_hd_241, V v_x_242, V v_path_243, V v_v_244, V v_k_245, V v_x_246) {
top: ;
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_ReadOnly, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam0_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam1, 1, 6, (V[]){v_x_242, v_x_240, v_hd_241, v_path_243, v_v_244, v_k_245})));
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_x_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2416_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2417}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Left: {
      V v_err_2419 = heff_field(v_y_2418, 0);
      V v_ru_24y_2418_24Left = heff_take_reuse_n(v_y_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_x_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2419}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_x_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Right, 1, (V[]){v_x_2420}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2418);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str0, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str2, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str4, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str6, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str7, 4, ".git");
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam4(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam4, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam6(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam6, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam8(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam8, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(V v_path_240, V v_v_241, V v_hd_242, V v_x_243, V v_ps_244, V v_k_245, V v_x_246) {
top: ;
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str0), heff_dup(v_path_240)), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str1));
  V v_t_249 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(v_t_247, heff_dup(v_v_241)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam0_clo)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam1, 1, 6, (V[]){v_v_241, v_path_240, v_x_243, v_hd_242, v_ps_244, v_k_245})));
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam4(V self, V *args) {
  V v_r_2428 = args[0];
  return v_r_2428;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam6(V self, V *args) {
  V v_r_2443 = args[0];
  return v_r_2443;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_path_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Left: {
    V v_x_2451 = heff_field(v_x_2450, 0);
    V v_ru_24x_2450_24Left = heff_take_reuse_n(v_x_2450, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_x_243; V a_1 = v_hd_242; V a_2 = v_x_2435; V a_3 = v_path_240; V a_4 = v_v_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2450_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2451}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2452 = heff_field(v_x_2450, 0);
    V v_ru_24x_2450_24Right = heff_take_reuse_n(v_x_2450, 1ULL, 1);
    switch (heff_tag_of(v_y_2452)) {
    case TAG_Left: {
      V v_err_2453 = heff_field(v_y_2452, 0);
      V v_ru_24y_2452_24Left = heff_take_reuse_n(v_y_2452, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2450_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_x_243; V a_1 = v_hd_242; V a_2 = v_x_2435; V a_3 = v_path_240; V a_4 = v_v_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2452_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2453}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_y_2452, 0);
      heff_take_n(v_y_2452, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_x_243; V a_1 = v_hd_242; V a_2 = v_x_2435; V a_3 = v_path_240; V a_4 = v_v_241; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2450_24Right, TAG_Right, 1, (V[]){v_x_2454}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2452);
    }
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_ps_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_path_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2436 = heff_get_n(v_ps_244, 5, 6);
  V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_2436), heff_dup(v_x_243)));
  V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2436), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str7)));
  V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
  V v_s_2440 = ({ V a_0 = v_st_2436; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2439); r_; });
  V v_path_2441 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2440));
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2441; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2441); r_; });
  V v_a_2444 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2442, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam6_clo)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2449, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam7, 1, 6, (V[]){v_x_243, v_hd_242, v_x_2435, v_path_240, v_v_241, v_k_245})));
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam8(V self, V *args) {
  V v_r_2458 = args[0];
  return v_r_2458;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam9(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_why_2455 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    heff_take_n(v_x_2465, 0ULL, 1);
    heff_clo_take(self, 2);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2455});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2467 = heff_field(v_x_2465, 0);
    heff_take_n(v_x_2465, 1ULL, 1);
    switch (heff_tag_of(v_y_2467)) {
    case TAG_Left: {
      heff_take_n(v_y_2467, 0ULL, 1);
      heff_clo_take(self, 2);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2455});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2467, 0ULL, 1);
      heff_clo_take(self, 2);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2455});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2467);
    }
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_ps_244 = heff_env(self)[3];
  V v_path_240 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_drop(v_x_2423);
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
    V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2424); r_; });
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str4), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str6), v_t_2426}), v_t_2425, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2429 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2427, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam4_clo)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam5, 1, 6, (V[]){v_ps_244, v_x_243, v_hd_242, v_path_240, v_v_241, v_k_245})));
  }
  case TAG_Just: {
    V v_why_2455 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Just = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    heff_drop_rec(v_ps_244, 6);
    heff_drop(v_path_240);
    heff_drop(v_v_241);
    V v_path_2456 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
    V v_t_2457 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2456; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2456); r_; });
    V v_a_2459 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2457, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam8_clo)});
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2420_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2464, v_hd_242, heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam9, 1, 2, (V[]){v_k_245, v_why_2455})));
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_ps_244 = heff_env(self)[3];
  V v_path_240 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam3, 1, 7, (V[]){v_x_2420, v_x_243, v_hd_242, v_ps_244, v_path_240, v_v_241, v_k_245})));
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_ps_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_t_2412 = ({ V a_0 = v_v_241; V b_1 = ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_str3), v_v_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  HeffT3 v_t_2413 = ({ V a_0 = v_t_2412; HeffT3 r_ = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(a_0)); heff_drop(v_t_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    V v_t_2419;
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_time_2417 = v_field_2415;
      V v_hash_2418 = v_field_2416;
      v_t_2419 = (g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745(heff_dup(v_path_240), heff_dup(v_v_241), v_time_2417, v_hash_2418, heff_dup(v_x_243)));
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2419 = (g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139(heff_dup(v_path_240), heff_dup(v_v_241), heff_dup(v_x_243)));
    }
    heff_clo_take(self, 6);
    V f_ = v_t_2419;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2_lam2, 1, 7, (V[]){v_x_2411, v_hd_242, v_x_243, v_ps_244, v_path_240, v_v_241, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(V v_ps_240, V v_x_241, V v_hd_242, V v_path_243, V v_v_244, V v_k_245, V v_x_246) {
top: ;
  V v_st_247 = heff_dup(heff_rfield(v_ps_240, 5));
  HeffT3 v_t_248 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_247), heff_dup(v_x_241)));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    V v_d_2412 = v_field_249;
    V v_a_2413 = v_field_2410;
    V v_xs_2414 = v_field_2411;
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
    V v_xs_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2415; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_t_2418 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2412, v_a_2413, v_t_2417});
    V v_s_2419 = ({ V a_0 = v_st_247; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop_tag(v_t_2418, 3); r_; });
    V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2419));
    V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2420; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2420); r_; });
    V v_a_2423 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam0_clo)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2428, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam1, 1, 6, (V[]){v_path_243, v_v_244, v_hd_242, v_x_241, v_ps_240, v_k_245})));
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam0(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_ps_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_x_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_path_243; V a_1 = v_v_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_ps_240; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2429_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2430}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Left: {
      V v_err_2432 = heff_field(v_y_2431, 0);
      V v_ru_24y_2431_24Left = heff_take_reuse_n(v_y_2431, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2429_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_path_243; V a_1 = v_v_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_ps_240; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2431_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2432}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_y_2431, 0);
      heff_take_n(v_y_2431, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_path_243; V a_1 = v_v_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_ps_240; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Right, 1, (V[]){v_x_2433}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2431);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(V v_x_240, V v_hd_241, V v_ps_242, V v_path_243, V v_v_244, V v_k_245, V v_x_246) {
top: ;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_ru_24x_246_24Left = heff_take_reuse_n(v_x_246, 0ULL, 1);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam0_clo)});
    V v_t_2412 = heff_tag_at_n(v_ru_24x_246_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2416, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam1, 1, 6, (V[]){v_ps_242, v_x_240, v_hd_241, v_path_243, v_v_244, v_k_245})));
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_hd_241);
    heff_drop(v_ps_242);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    V v_t_2423 = (g_prelude_2eskipSpaces(v_y_2422, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_y_2422, 0)) - ((int64_t)1ULL));
    V v_t_2425 = (g_prelude_2eskipSpaces(v_y_2422, heff_box_word(v_t_2424), MK_INT(-1LL)));
    V v_t_2426 = heff_strSlice(v_y_2422, v_t_2423, heff_intAdd(v_t_2425, MK_INT(1LL)));
    V v_x_2427 = heff_tag_at_n(v_ru_24x_246_24Right, TAG_Right, 1, (V[]){v_t_2426});
    return heff_tail(v_k_245, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_x_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_ps_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2418}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2419)) {
    case TAG_Left: {
      V v_err_2420 = heff_field(v_y_2419, 0);
      V v_ru_24y_2419_24Left = heff_take_reuse_n(v_y_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_ps_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2420}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_y_2419, 0);
      heff_take_n(v_y_2419, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_ps_242; V a_1 = v_x_240; V a_2 = v_hd_241; V a_3 = v_path_243; V a_4 = v_v_244; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Right, 1, (V[]){v_x_2421}); V r_ = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2419);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}