// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Args 26338
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_name 9869138
V g_co_2eop_24s1745984779x111653409(V);
V g_co_2eop_24s1745984779x111653409_entry(V self, V *a);
extern Clo g_co_2eop_24s1745984779x111653409_clo;
V g_co_2eop_24s889957542x331748716(V, V, V);
V g_co_2eop_24s889957542x331748716_entry(V self, V *a);
extern Clo g_co_2eop_24s889957542x331748716_clo;
V g_run_24entry_get(void);
V g_std_2eprogress_2eshown_24s241685406x889772080(V);
V g_std_2eprogress_2eshown_24s241685406x889772080_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s241685406x889772080_clo;
HEFF_LIT(g_run_24entry_str0, 6, "heff: ");
HEFF_LIT(g_run_24entry_str1, 1, "\012");
HEFF_LIT(g_run_24entry_str2, 2, ": ");
HEFF_LIT(g_run_24entry_str3, 6, "heff: ");
HEFF_LIT(g_run_24entry_str4, 1, "\012");
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 1, 0};
V g_run_24entry_lam3(V self, V *args);
V g_run_24entry_lam4(V self, V *args);
V g_run_24entry_lam2(V self, V *args);
V g_run_24entry_lam1(V self, V *args);

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  V v_t_241 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_run_24entry_lam0_clo)})});
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_c_247 = (g_co_2eop_24s1745984779x111653409(heff_tag_n(TAG_InR, 1, (V[]){v_t_246})));
  return (g_std_2eprogress_2eshown_24s241685406x889772080(heff_clo_n(g_run_24entry_lam1, 2, 1, (V[]){v_c_247})));
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}
V g_run_24entry_lam0(V self, V *args) {
  V v_a_240 = args[0];
  return v_a_240;
}
V g_run_24entry_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_p_2412 = heff_env(self)[0];
  V v_p_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  return (g_co_2eop_24s889957542x331748716(MK_INT(1LL), v_p_2412, v_p_2413));
}
V g_run_24entry_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_p_2412 = heff_env(self)[0];
  V v_p_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  return (g_co_2eop_24s889957542x331748716(MK_INT(1LL), v_p_2412, v_p_2413));
}
V g_run_24entry_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2411 = v_x_2410;
  V v_p_2412 = v_hd_248;
  V v_p_2413 = v_k_249;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24Left = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    V v_t_2415 = heff_strAppend(((V)&g_run_24entry_str0), heff_get_n(v_err_2414, 2, 3));
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_run_24entry_str1)), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_at_n(v_ru_24x1_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
    V f_ = heff_dup(heff_rfield(v_p_2412, 1));
    heff_room[0] = v_t_2422;
    heff_room[1] = heff_clo_n(g_run_24entry_lam3, 1, 2, (V[]){v_p_2412, v_p_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x11_2424 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24Right = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_err_2425 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      V v_name_2426 = heff_take_field(v_err_2425, 1);
      V v_message_2427 = heff_get_n(v_err_2425, 2, 3);
      V v_t_2428 = heff_strAppend(heff_strAppend(v_name_2426, ((V)&g_run_24entry_str2)), v_message_2427);
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_run_24entry_str3), v_t_2428), ((V)&g_run_24entry_str4));
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_at_n(v_ru_24x1_2411_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Left, TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
      V f_ = heff_dup(heff_rfield(v_p_2412, 1));
      heff_room[0] = v_t_2436;
      heff_room[1] = heff_clo_n(g_run_24entry_lam4, 1, 2, (V[]){v_p_2412, v_p_2413});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      heff_take_n(v_x11_2424, 0ULL, 1);
      heff_drop_rec(v_p_2412, 3);
      heff_drop_cell(v_ru_24x1_2411_24Right, 1);
      V f_ = v_p_2413;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_run_24entry_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_run_24entry_lam2, 1, 2, (V[]){v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}