// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_app_2eheff_2emain_2eprogram_24s1186933347x1892999545(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eprogram_24s1186933347x1892999545_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1186933347x1892999545_clo;
V g_run_24entry_get(void);
V g_std_2eprogress_2eshown_24s22240543x27787974(V);
V g_std_2eprogress_2eshown_24s22240543x27787974_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s22240543x27787974_clo;
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 1, 0};
V g_run_24entry_lam1(V self, V *args); static Clo g_run_24entry_lam1_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam1, 1, 0};
V g_run_24entry_lam2(V self, V *args); static Clo g_run_24entry_lam2_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam2, 1, 0};
V g_run_24entry_lam3(V self, V *args); static Clo g_run_24entry_lam3_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam3, 1, 0};
V g_run_24entry_lam4(V self, V *args); static Clo g_run_24entry_lam4_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam4, 1, 0};
V g_run_24entry_lam5(V self, V *args); static Clo g_run_24entry_lam5_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam5, 1, 0};

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  V v_t_2412 = heff_tr(heff_call(((V)&g_app_2eheff_2emain_2eprogram_24s1186933347x1892999545_clo), 6, (V[]){((V)&g_run_24entry_lam0_clo), ((V)&g_run_24entry_lam1_clo), ((V)&g_run_24entry_lam2_clo), ((V)&g_run_24entry_lam3_clo), ((V)&g_run_24entry_lam4_clo), ((V)&g_run_24entry_lam5_clo)}));
  return (g_std_2eprogress_2eshown_24s22240543x27787974(v_t_2412));
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}
V g_run_24entry_lam0(V self, V *args) {
  V v_p_240 = args[0];
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_240});
}
V g_run_24entry_lam1(V self, V *args) {
  V v_p_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_241})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
}
V g_run_24entry_lam2(V self, V *args) {
  V v_p_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_246});
}
V g_run_24entry_lam3(V self, V *args) {
  V v_p_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_247})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
}
V g_run_24entry_lam4(V self, V *args) {
  V v_p_249 = args[0];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_249})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2410});
}
V g_run_24entry_lam5(V self, V *args) {
  V v_p_2411 = args[0];
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2411})});
}