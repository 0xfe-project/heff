// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_run_24entry_get(void);
V g_std_2eprogress_2eshown_24s432087847x424507035_get(void);
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 1, 0};

static V g_run_24entry_val;
static int g_run_24entry_st;
static V g_run_24entry_init(void) {
  return heff_tail(heff_dup(g_std_2eprogress_2eshown_24s432087847x424507035_get()), 1, (V[]){((V)&g_run_24entry_lam0_clo)});
}
V g_run_24entry_get(void) {
  if (g_run_24entry_st == 2) return g_run_24entry_val;
  if (g_run_24entry_st == 1) heff_fail("defined by itself");
  g_run_24entry_st = 1;
  g_run_24entry_val = heff_tr(g_run_24entry_init());
  g_run_24entry_st = 2;
  return g_run_24entry_val;
}
V g_run_24entry_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(v_x_240);
  return NTAG(TAG_MkUnit);
}