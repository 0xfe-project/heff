// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_run_24entry_get(void);
V g_std_2eprogress_2eshown_24s1929445196x1856941725_get(void);

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  return heff_dup(g_std_2eprogress_2eshown_24s1929445196x1856941725_get());
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}