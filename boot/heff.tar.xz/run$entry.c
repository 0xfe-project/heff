// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_run_24entry_get(void);
V g_std_2eprogress_2eshown_24s1929537511x1486304887(V);
V g_std_2eprogress_2eshown_24s1929537511x1486304887_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s1929537511x1486304887_clo;
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 1, 0};

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  return (g_std_2eprogress_2eshown_24s1929537511x1486304887(((V)&g_run_24entry_lam0_clo)));
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}
V g_run_24entry_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(v_x_240);
  return NTAG(TAG_MkUnit);
}