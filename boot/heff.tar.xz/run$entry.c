// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_bind 9519364
#define LBL_malg 9839318
#define LBL_ret 322331
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_app_2eheff_2emain_2emain(V, V, V);
V g_app_2eheff_2emain_2emain_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2emain_clo;
V g_run_24entry_get(void);
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 2, 0};
V g_run_24entry_lam2(V self, V *args);
V g_run_24entry_lam1(V self, V *args); static Clo g_run_24entry_lam1_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam1, 3, 0};
V g_run_24entry_lam3(V self, V *args); static Clo g_run_24entry_lam3_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam3, 2, 0};
V g_run_24entry_lam4(V self, V *args); static Clo g_run_24entry_lam4_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam4, 2, 0};
V g_run_24entry_lam5(V self, V *args); static Clo g_run_24entry_lam5_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam5, 1, 0};

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  return (g_app_2eheff_2emain_2emain(heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_run_24entry_lam0_clo), ((V)&g_run_24entry_lam1_clo), ((V)&g_run_24entry_lam3_clo)}), ((V)&g_run_24entry_lam4_clo), ((V)&g_run_24entry_lam5_clo)));
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}
V g_run_24entry_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_k_241 = args[1];
  V f_ = v_k_241;
  args[0] = v_x_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_f_243;
  heff_room[0] = v_x_245;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_run_24entry_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_f_243 = args[1];
  V v_k_244 = args[2];
  V f_ = v_m_242;
  args[0] = heff_clo_n(g_run_24entry_lam2, 1, 2, (V[]){v_f_243, v_k_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam3(V self, V *args) {
  V v_p_246 = args[0];
  V v_k_247 = args[1];
  return heff_perform(v_p_246, v_k_247);
}
V g_run_24entry_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_249 = args[1];
  V f_ = v_k_249;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam5(V self, V *args) {
  V v_x_2410 = args[0];
  heff_drop(v_x_2410);
  return NTAG(TAG_MkUnit);
}