// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_bind 9519364
#define LBL_malg 9839318
#define LBL_ret 322331
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_app_2eheff_2emain_2emain(V, V, V);
V g_app_2eheff_2emain_2emain_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2emain_clo;
V g_run_24entry_get(void);
V g_run_24entry_lam0(V self, V *args); static Clo g_run_24entry_lam0_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam0, 2, 0};
V g_run_24entry_lam2(V self, V *args);
V g_run_24entry_lam1(V self, V *args); static Clo g_run_24entry_lam1_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam1, 3, 0};
V g_run_24entry_lam3(V self, V *args); static Clo g_run_24entry_lam3_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam3, 2, 0};
V g_run_24entry_lam4(V self, V *args); static Clo g_run_24entry_lam4_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam4, 2, 0};
V g_run_24entry_lam5(V self, V *args); static Clo g_run_24entry_lam5_clo = {{0x80000000u, K_CLO, 0}, g_run_24entry_lam5, 1, 0};

static V g_run_24entry_val;
static HEFF_ONCE g_run_24entry_st;
static V g_run_24entry_init(void) {
  return (g_app_2eheff_2emain_2emain(heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_run_24entry_lam0_clo), ((V)&g_run_24entry_lam1_clo), ((V)&g_run_24entry_lam3_clo)}), ((V)&g_run_24entry_lam4_clo), ((V)&g_run_24entry_lam5_clo)));
}
V g_run_24entry_get(void) {
  if (HEFF_DONE(g_run_24entry_st)) return g_run_24entry_val;
  return heff_global(&g_run_24entry_val, &g_run_24entry_st, g_run_24entry_init);
}
V g_run_24entry_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_k_241 = args[1];
  V f_ = v_k_241;
  args[0] = v_x_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_f_243;
  heff_room[0] = v_x_245;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_run_24entry_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_f_243 = args[1];
  V v_k_244 = args[2];
  V f_ = v_m_242;
  args[0] = heff_clo_n(g_run_24entry_lam2, 1, 2, (V[]){v_f_243, v_k_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam3(V self, V *args) {
  V v_p_246 = args[0];
  V v_k_247 = args[1];
  switch (heff_tag_of(v_p_246)) {
  case TAG_InL: {
    V v_w_23l0_248 = heff_field(v_p_246, 0);
    heff_take_n(v_p_246, 1ULL, 1);
    switch (heff_tag_of(v_w_23l0_248)) {
    case TAG_InL: {
      V v_w_23l1_249 = heff_field(v_w_23l0_248, 0);
      heff_take_n(v_w_23l0_248, 1ULL, 1);
      V v_w_23p2_2410 = v_w_23l1_249;
      V v_w_23k2_2411 = v_k_247;
      switch (heff_tag_of(v_w_23p2_2410)) {
      case TAG_InL: {
        V v_w_23l2_2412 = heff_field(v_w_23p2_2410, 0);
        heff_take_n(v_w_23p2_2410, 1ULL, 1);
        V v_w_23p3_2413 = v_w_23l2_2412;
        V v_w_23k3_2414 = v_w_23k2_2411;
        switch (heff_tag_of(v_w_23p3_2413)) {
        case TAG_InL: {
          V v_w_23l3_2415 = heff_field(v_w_23p3_2413, 0);
          heff_take_n(v_w_23p3_2413, 1ULL, 1);
          V v_w_23p4_2416 = v_w_23l3_2415;
          V v_w_23k4_2417 = v_w_23k3_2414;
          switch (heff_tag_of(v_w_23p4_2416)) {
          case TAG_InL: {
            V v_w_23l4_2418 = heff_field(v_w_23p4_2416, 0);
            heff_take_n(v_w_23p4_2416, 1ULL, 1);
            V v_w_23p5_2419 = v_w_23l4_2418;
            V v_w_23k5_2420 = v_w_23k4_2417;
            switch (heff_tag_of(v_w_23p5_2419)) {
            case TAG_InL: {
              V v_w_23l5_2421 = heff_field(v_w_23p5_2419, 0);
              heff_take_n(v_w_23p5_2419, 1ULL, 1);
              V v_w_23p6_2422 = v_w_23l5_2421;
              V v_w_23k6_2423 = v_w_23k5_2420;
              switch (heff_tag_of(v_w_23p6_2422)) {
              case TAG_InL: {
                V v_w_23l6_2424 = heff_field(v_w_23p6_2422, 0);
                heff_take_n(v_w_23p6_2422, 1ULL, 1);
                V v_w_23p7_2425 = v_w_23l6_2424;
                V v_w_23k7_2426 = v_w_23k6_2423;
                switch (heff_tag_of(v_w_23p7_2425)) {
                case TAG_InL: {
                  V v_w_23l7_2427 = heff_field(v_w_23p7_2425, 0);
                  heff_take_n(v_w_23p7_2425, 1ULL, 1);
                  return heff_performAt(0, v_w_23l7_2427, v_w_23k7_2426);
                }
                case TAG_InR: {
                  V v_w_23r7_2428 = heff_field(v_w_23p7_2425, 0);
                  heff_take_n(v_w_23p7_2425, 1ULL, 1);
                  return heff_performAt(1, v_w_23r7_2428, v_w_23k7_2426);
                }
                default: return heff_nomatch(v_w_23p7_2425);
                }
              }
              case TAG_InR: {
                V v_w_23r6_2429 = heff_field(v_w_23p6_2422, 0);
                heff_take_n(v_w_23p6_2422, 1ULL, 1);
                return heff_performAt(2, v_w_23r6_2429, v_w_23k6_2423);
              }
              default: return heff_nomatch(v_w_23p6_2422);
              }
            }
            case TAG_InR: {
              V v_w_23r5_2430 = heff_field(v_w_23p5_2419, 0);
              heff_take_n(v_w_23p5_2419, 1ULL, 1);
              return heff_performAt(3, v_w_23r5_2430, v_w_23k5_2420);
            }
            default: return heff_nomatch(v_w_23p5_2419);
            }
          }
          case TAG_InR: {
            V v_w_23r4_2431 = heff_field(v_w_23p4_2416, 0);
            heff_take_n(v_w_23p4_2416, 1ULL, 1);
            return heff_performAt(4, v_w_23r4_2431, v_w_23k4_2417);
          }
          default: return heff_nomatch(v_w_23p4_2416);
          }
        }
        case TAG_InR: {
          V v_w_23r3_2432 = heff_field(v_w_23p3_2413, 0);
          heff_take_n(v_w_23p3_2413, 1ULL, 1);
          return heff_performAt(5, v_w_23r3_2432, v_w_23k3_2414);
        }
        default: return heff_nomatch(v_w_23p3_2413);
        }
      }
      case TAG_InR: {
        V v_w_23r2_2433 = heff_field(v_w_23p2_2410, 0);
        heff_take_n(v_w_23p2_2410, 1ULL, 1);
        return heff_performAt(6, v_w_23r2_2433, v_w_23k2_2411);
      }
      default: return heff_nomatch(v_w_23p2_2410);
      }
    }
    case TAG_InR: {
      V v_w_23r1_2434 = heff_field(v_w_23l0_248, 0);
      heff_take_n(v_w_23l0_248, 1ULL, 1);
      return heff_performAt(7, v_w_23r1_2434, v_k_247);
    }
    default: return heff_nomatch(v_w_23l0_248);
    }
  }
  case TAG_InR: {
    V v_w_23r0_2435 = heff_field(v_p_246, 0);
    heff_take_n(v_p_246, 1ULL, 1);
    return heff_performAt(8, v_w_23r0_2435, v_k_247);
  }
  default: return heff_nomatch(v_p_246);
  }
}
V g_run_24entry_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2437 = args[1];
  V f_ = v_k_2437;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_run_24entry_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  heff_drop(v_x_2438);
  return NTAG(TAG_MkUnit);
}