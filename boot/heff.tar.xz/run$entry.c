// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_run_24entry_val;
static int g_run_24entry_st;
static V g_run_24entry_init(void) {
  return heff_dup(g_std_2eprogress_2eshown_24s843_24s851_24s1354_24s1359_24s1363_get());
}
V g_run_24entry_get(void) {
  if (g_run_24entry_st == 2) return g_run_24entry_val;
  if (g_run_24entry_st == 1) heff_fail("defined by itself");
  g_run_24entry_st = 1;
  g_run_24entry_val = heff_tr(g_run_24entry_init());
  g_run_24entry_st = 2;
  return g_run_24entry_val;
}