// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CDrop 58400
#define TAG_EProject 35489
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkFieldPat 14710
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SBytes 19273
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SInt 64711
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_body 9524841
#define LBL_defines 1776893014
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_id 10114
#define LBL_key 315609
#define LBL_long 9823043
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_protos 967342774
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_text 10052084
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2erepr_2ekeptOne(V, V, V, V);
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ekeptOne_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2esimplify_2etagLeaves(V);
V g_heff_2ecompile_2esimplify_2etagLeaves_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagLeaves_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2esyntax_2eformat_2ealtKey(V, V);
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ealtKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1022178817x2079624138(V);
V g_list_2efilter_24s1022178817x2079624138_entry(V self, V *a);
extern Clo g_list_2efilter_24s1022178817x2079624138_clo;
V g_list_2efilter_24s1022178817x2079624138_24dps(V, V);
V g_list_2efilter_24s1022178817x2079624138_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1022178817x2079624138_24dps_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efilter_24s1623010005x1805617852_24dps(V, V);
V g_list_2efilter_24s1623010005x1805617852_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_24dps_clo;
V g_list_2efilter_24s1828661527x837139534(V, V);
V g_list_2efilter_24s1828661527x837139534_entry(V self, V *a);
extern Clo g_list_2efilter_24s1828661527x837139534_clo;
V g_list_2efilter_24s1828661527x837139534_24dps(V, V, V);
V g_list_2efilter_24s1828661527x837139534_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1828661527x837139534_24dps_clo;
V g_list_2efilter_24s334334379x923000927_24dps(V, V, V);
V g_list_2efilter_24s334334379x923000927_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s334334379x923000927_24dps_clo;
V g_list_2efilter_24s561186959x2071570661_24dps(V, V, V, V);
V g_list_2efilter_24s561186959x2071570661_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s561186959x2071570661_24dps_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efilter_24s727803713x1346936525_24dps(V, V, V);
V g_list_2efilter_24s727803713x1346936525_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_24dps_clo;
V g_list_2efind_24s361650052x1432786508(V, V);
V g_list_2efind_24s361650052x1432786508_entry(V self, V *a);
extern Clo g_list_2efind_24s361650052x1432786508_clo;
V g_list_2efind_24s727666736x1458251130(V, V);
V g_list_2efind_24s727666736x1458251130_entry(V self, V *a);
extern Clo g_list_2efind_24s727666736x1458251130_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24f552047357x993882406(V, V);
V g_list_2efoldl_24f552047357x993882406_entry(V self, V *a);
extern Clo g_list_2efoldl_24f552047357x993882406_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s1885006984x1134653659(V, V);
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885006984x1134653659_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f1457339348x592422294_24dps(V, V, V, V);
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_24dps_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24f1539731936x1117725130_24dps(V, V, V, V);
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_24dps_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24s1004924153x684987219_24dps(V, V, V, V);
V g_list_2emap_24s1004924153x684987219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1004924153x684987219_24dps_clo;
V g_list_2emap_24s1047941608x1265580215_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1047941608x1265580215_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1047941608x1265580215_24dps_clo;
V g_list_2emap_24s1152414072x2935301(V, V);
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_clo;
V g_list_2emap_24s1152414072x2935301_24dps(V, V, V);
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_24dps_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1230649048x711093514(V, V);
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_clo;
V g_list_2emap_24s1230649048x711093514_24dps(V, V, V);
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_24dps_clo;
V g_list_2emap_24s137457135x961689574_24dps(V, V);
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_24dps_clo;
V g_list_2emap_24s1386495485x1391533176_24dps(V, V, V);
V g_list_2emap_24s1386495485x1391533176_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_24dps_clo;
V g_list_2emap_24s1427000880x1925304966_24dps(V, V, V);
V g_list_2emap_24s1427000880x1925304966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_24dps_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_list_2emap_24s143096761x246530315_24dps(V, V);
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_24dps_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1585362143x1323498048_24dps(V, V);
V g_list_2emap_24s1585362143x1323498048_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_24dps_clo;
V g_list_2emap_24s1721231741x1085491812(V);
V g_list_2emap_24s1721231741x1085491812_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_clo;
V g_list_2emap_24s1721231741x1085491812_24dps(V, V);
V g_list_2emap_24s1721231741x1085491812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_24dps_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s179832492x431904054_24dps(V, V);
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_24dps_clo;
V g_list_2emap_24s1846289357x1055790465(V, V);
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_clo;
V g_list_2emap_24s1846289357x1055790465_24dps(V, V, V);
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_24dps_clo;
V g_list_2emap_24s1901363476x1479927424_24dps(V, V);
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_24dps_clo;
V g_list_2emap_24s1917875516x88484758_24dps(V, V);
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_24dps_clo;
V g_list_2emap_24s1943354043x700174004(V, V, V);
V g_list_2emap_24s1943354043x700174004_entry(V self, V *a);
extern Clo g_list_2emap_24s1943354043x700174004_clo;
V g_list_2emap_24s1943354043x700174004_24dps(V, V, V, V);
V g_list_2emap_24s1943354043x700174004_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1943354043x700174004_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24dps(V, V);
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24dps_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s2130193383x1335133353_24dps(V, V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s244350250x1728178626_24dps(V, V);
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_24dps_clo;
V g_list_2emap_24s353858844x950951807(V, V, V, V);
V g_list_2emap_24s353858844x950951807_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_clo;
V g_list_2emap_24s353858844x950951807_24dps(V, V, V, V, V);
V g_list_2emap_24s353858844x950951807_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_24dps_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emerge_24s1081221956x1079757426(V, V);
V g_list_2emerge_24s1081221956x1079757426_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_clo;
V g_list_2emerge_24s1081221956x1079757426_24dps(V, V, V);
V g_list_2emerge_24s1081221956x1079757426_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_24dps_clo;
V g_list_2emerge_24s1840066165x1513718921(V, V);
V g_list_2emerge_24s1840066165x1513718921_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_clo;
V g_list_2esortBy_24s390982605x1732870695(V);
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a);
extern Clo g_list_2esortBy_24s390982605x1732870695_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_list_2ezipWith_24s706961545x2112949112(V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_clo;
V g_list_2ezipWith_24s706961545x2112949112_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1876717925x1404326288_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_247;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1173914895x100384474_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_entry, 1, 0};

V g_list_2emap_24s1173914895x100384474(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1173914895x100384474_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474(a[0]);
}
Clo g_list_2efilter_24s727803713x1346936525_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s727803713x1346936525_entry, 2, 0};

V g_list_2efilter_24s727803713x1346936525(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s727803713x1346936525_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s727803713x1346936525(a[0], a[1]);
}
Clo g_list_2emap_24s2029035892x1571084362_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_entry, 1, 0};

V g_list_2emap_24s2029035892x1571084362(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2029035892x1571084362_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362(a[0]);
}
Clo g_list_2efilter_24s1828661527x837139534_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1828661527x837139534_entry, 2, 0};

V g_list_2efilter_24s1828661527x837139534(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1828661527x837139534_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1828661527x837139534_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1828661527x837139534(a[0], a[1]);
}
Clo g_list_2emerge_24s1081221956x1079757426_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1081221956x1079757426_entry, 2, 0};

V g_list_2emerge_24s1081221956x1079757426(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 6);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1081221956x1079757426_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1081221956x1079757426_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1081221956x1079757426_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1081221956x1079757426(a[0], a[1]);
}
Clo g_list_2emap_24s137457135x961689574_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s137457135x961689574_24dps_entry, 2, 0};

V g_list_2emap_24s137457135x961689574_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s137457135x961689574_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1729787689x465380098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_entry, 1, 0};

V g_list_2emap_24s1729787689x465380098(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1729787689x465380098_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098(a[0]);
}
Clo g_list_2emap_24s244350250x1728178626_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_entry, 1, 0};

V g_list_2emap_24s244350250x1728178626(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24MkAlt = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24a_243_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s244350250x1728178626_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s244350250x1728178626(a[0]);
}
Clo g_list_2emap_24s2130193383x1335133353_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2130193383x1335133353_24dps_entry, 5, 0};

V g_list_2emap_24s2130193383x1335133353_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_x_245; V r_ = (g_heff_2esyntax_2esurface_2eassembleDiagOne(a_0, a_1, a_2, a_3)); heff_drop(v_x_245); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24s2130193383x1335133353_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s513201124x806973253_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_entry, 1, 0};

V g_list_2emap_24s513201124x806973253(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_get_n(v_x_241, 4, 9)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, v_t_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s513201124x806973253_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513201124x806973253(a[0]);
}
HEFF_LIT(g_list_2emap_24s143096761x246530315_str0, 7, "Float64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str10, 1, "_");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str11, 1, "\?");
Clo g_list_2emap_24s143096761x246530315_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s143096761x246530315_entry, 1, 0};

V g_list_2emap_24s143096761x246530315(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_FtFloat: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str1);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str2);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str3);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str4);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str5);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str6);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str7);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str8);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str9);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str11);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s143096761x246530315_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s143096761x246530315_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s143096761x246530315(a[0]);
}
Clo g_list_2eany_24s228396297x1310020012_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s228396297x1310020012_entry, 1, 0};

V g_list_2eany_24s228396297x1310020012(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if ((heff_dup(v_x_241) == NTAG(TAG_True))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s228396297x1310020012(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str10, 7, "Float64");
Clo g_list_2emap_24s2090270526x1588636862_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_entry, 1, 0};

V g_list_2emap_24s2090270526x1588636862(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str1);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str2);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str3);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str4);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str5);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str6);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str7);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str8);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str9);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str10);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2090270526x1588636862_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862(a[0]);
}
Clo g_list_2emap_24s1917875516x88484758_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917875516x88484758_24dps_entry, 2, 0};

V g_list_2emap_24s1917875516x88484758_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, NTAG(TAG_RepV)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917875516x88484758_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1275727578x1654209034_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1275727578x1654209034_entry, 2, 0};

V g_list_2efoldl_24s1275727578x1654209034(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_y_245 = heff_field(v_x_242, 1);
      v_t_2417 = (g_heff_2ecompile_2erepr_2eunite(v_z_240, heff_dup(v_x_244), heff_dup(v_y_245)));
      break;
    }
    case TAG_Boxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Binds: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Pinned: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Kept: {
      v_t_2417 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2417;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1275727578x1654209034(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1674844076x2137676876_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1674844076x2137676876_entry, 4, 0};

V g_list_2efoldl_24s1674844076x2137676876(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2erepr_2ekeptOne(v_lit_240, v_lit_241, v_z_242, v_x_244));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s1674844076x2137676876(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2efilter_24s1022178817x2079624138_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1022178817x2079624138_entry, 1, 0};

V g_list_2efilter_24s1022178817x2079624138(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_241)) {
    case TAG_SLocal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2440 = (g_list_2efilter_24s1022178817x2079624138_24dps(v_xs_242, heff_dup(v_cell_2439)));
      heff_drop(v_u_2440);
      return v_cell_2439;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2438);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1022178817x2079624138_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1022178817x2079624138(a[0]);
}
Clo g_list_2emap_24s1901363476x1479927424_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1901363476x1479927424_24dps_entry, 2, 0};

V g_list_2emap_24s1901363476x1479927424_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_242, NTAG(TAG_Nothing)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_t_244}), heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1901363476x1479927424_24dps(a[0], a[1]);
}
V g_list_2efoldl_24s1885006984x1134653659_lam0(V self, V *args);
Clo g_list_2efoldl_24s1885006984x1134653659_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1885006984x1134653659_entry, 2, 0};

V g_list_2efoldl_24s1885006984x1134653659(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s1885006984x1134653659_lam0, 2, 1, (V[]){v_x_242}); V a_1 = v_z_240; V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1885006984x1134653659(a[0], a[1]);
}
V g_list_2efoldl_24s1885006984x1134653659_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_g_247 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_247), v_acc_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    v_t_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), v_t_2410});
  return (g_map_2einsert_24s1341440536x470972936(v_g_247, v_t_2411, v_acc_246));
}
Clo g_list_2emap_24s1585362143x1323498048_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1585362143x1323498048_entry, 1, 0};

V g_list_2emap_24s1585362143x1323498048(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_241)) {
    case TAG_PartVal: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24PartVal = heff_take_reuse_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_a_243)) {
      case TAG_SVar: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_a_245 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2428 = heff_tag_at_n(v_ru_24x_241_24PartVal, TAG_Just, 1, (V[]){v_a_245});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_a_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2428 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = (g_list_2emap_24s1585362143x1323498048_24dps(v_xs_242, heff_dup(v_cell_2429)));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1585362143x1323498048(a[0]);
}
Clo g_list_2emap_24s1585362143x1323498048_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1585362143x1323498048_24dps_entry, 2, 0};

V g_list_2emap_24s1585362143x1323498048_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24PartVal = heff_take_reuse_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24x_242_24PartVal, TAG_Just, 1, (V[]){v_a_246});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_a_244, 0ULL, 4);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2429 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2430 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
    heff_drop(v_u_2431);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2430;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1585362143x1323498048_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1585362143x1323498048_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s152505078x225062837_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_entry, 1, 0};

V g_list_2emap_24s152505078x225062837(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s152505078x225062837_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s152505078x225062837(a[0]);
}
Clo g_list_2ezipWith_24s706961545x2112949112_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s706961545x2112949112_entry, 5, 0};

V g_list_2ezipWith_24s706961545x2112949112(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_245, heff_dup(v_lit_242)));
      V v_t_2410 = heff_strAppend(heff_intShow(v_y_247), v_t_249);
      V v_cell_2411 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2410), heff_hole()});
      V v_u_2412 = (g_list_2ezipWith_24s706961545x2112949112_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s706961545x2112949112_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s706961545x2112949112(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s353858844x950951807_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s353858844x950951807_entry, 4, 0};

V g_list_2emap_24s353858844x950951807(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_x_244)), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_intShow(v_x_244), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s353858844x950951807_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s353858844x950951807_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s353858844x950951807(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s292588827x1477362994_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s292588827x1477362994_entry, 2, 0};

V g_list_2efoldl_24s292588827x1477362994(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 0)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s292588827x1477362994(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1427000880x1925304966_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1427000880x1925304966_24dps_entry, 3, 0};

V g_list_2emap_24s1427000880x1925304966_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2411 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_t_2411));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2413;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1427000880x1925304966_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1427000880x1925304966_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1386495485x1391533176_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386495485x1391533176_24dps_entry, 3, 0};

V g_list_2emap_24s1386495485x1391533176_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2eclauses_2erenameAlt(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1386495485x1391533176_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386495485x1391533176_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1846289357x1055790465_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1846289357x1055790465_entry, 2, 0};

V g_list_2emap_24s1846289357x1055790465(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1846289357x1055790465_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1846289357x1055790465(a[0], a[1]);
}
Clo g_list_2emap_24s1230649048x711093514_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230649048x711093514_entry, 2, 0};

V g_list_2emap_24s1230649048x711093514(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1230649048x711093514_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230649048x711093514(a[0], a[1]);
}
Clo g_list_2efilter_24s334334379x923000927_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s334334379x923000927_24dps_entry, 3, 0};

V g_list_2efilter_24s334334379x923000927_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s334334379x923000927_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s334334379x923000927_24dps(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_24s390982605x1732870695_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s390982605x1732870695_entry, 1, 0};

V g_list_2esortBy_24s390982605x1732870695(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s390982605x1732870695(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s390982605x1732870695(v_t_249));
      return (g_list_2emerge_24s1840066165x1513718921(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s390982605x1732870695(a[0]);
}
Clo g_list_2emap_24s1047941608x1265580215_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1047941608x1265580215_24dps_entry, 8, 0};

V g_list_2emap_24s1047941608x1265580215_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkFieldPat: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      V v_ru_24x_248_24MkFieldPat = heff_take_reuse_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2411));
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_a_2414 = heff_tag_at_n(v_ru_24x_248_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_2410, v_t_2413});
      V v_a_2415 = (g_list_2emap_24s231073986x752637537(heff_dup(v_lit_242), v_a_2414));
      V v_t_2418;
      switch (heff_tag_of(v_a_2415)) {
      case TAG_Nil: {
        v_t_2418 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_a_2415, 0);
        V v_a_2417 = heff_field(v_a_2415, 1);
        heff_take_n(v_a_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2416; V a_2 = v_a_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2417); r_; });
        break;
      }
      default: heff_nomatch(v_a_2415);
      }
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2418, heff_dup(v_lit_245)));
      v_t_2420 = heff_strAppend(heff_dup(v_lit_240), v_t_2419);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2421;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1047941608x1265580215_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1047941608x1265580215_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1152414072x2935301_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1152414072x2935301_entry, 2, 0};

V g_list_2emap_24s1152414072x2935301(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2ealtKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1152414072x2935301_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1152414072x2935301(a[0], a[1]);
}
Clo g_list_2emap_24s179832492x431904054_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s179832492x431904054_24dps_entry, 2, 0};

V g_list_2emap_24s179832492x431904054_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s179832492x431904054_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1721231741x1085491812_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1721231741x1085491812_entry, 1, 0};

V g_list_2emap_24s1721231741x1085491812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_get_n(v_t_245, 0, 4);
    V v_t_2445;
    switch (heff_tag_of(v_t_246)) {
    case TAG_SLocal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      V v_ru_24t_246_24SPrim = heff_take_reuse_n(v_t_246, 0ULL, 1);
      V v_t_2433;
      switch (heff_tag_of(v_x_241)) {
      case TAG_MkPair: {
        V v_a_2431 = heff_field(v_x_241, 0);
        heff_take_n(v_x_241, 1ULL, 2);
        v_t_2433 = v_a_2431;
        break;
      }
      default: heff_nomatch(v_x_241);
      }
      v_t_2445 = heff_tag_at_n(v_ru_24t_246_24SPrim, TAG_Just, 1, (V[]){v_t_2433});
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop(v_x_241);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_cell_2446 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2445, heff_hole()});
    V v_u_2447 = (g_list_2emap_24s1721231741x1085491812_24dps(v_xs_242, heff_dup(v_cell_2446)));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1721231741x1085491812_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1721231741x1085491812(a[0]);
}
Clo g_list_2efind_24s361650052x1432786508_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s361650052x1432786508_entry, 2, 0};

V g_list_2efind_24s361650052x1432786508(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    if (heff_intLe_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(v_lit_240))) {
      if (heff_intLe_c(heff_dup(v_lit_240), heff_get_n(v_a_244, 1, 2))) {
        heff_drop(v_lit_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s361650052x1432786508_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s361650052x1432786508(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1004924153x684987219_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1004924153x684987219_24dps_entry, 4, 0};

V g_list_2emap_24s1004924153x684987219_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 2);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_lit_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(heff_rfield(v_lit_241, 1)))));
    V v_t_248 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_lit_240, 3)), v_x_244, v_t_247});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1004924153x684987219_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1004924153x684987219_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1996724342x1838336560_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1996724342x1838336560_entry, 1, 0};

V g_list_2eany_24s1996724342x1838336560(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_list_2efilter_24s1064353769x1815078842(heff_dup(heff_rfield(v_x_241, 6))));
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1996724342x1838336560(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1943354043x700174004_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1943354043x700174004_entry, 3, 0};

V g_list_2emap_24s1943354043x700174004(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_a_245), heff_dup(heff_rfield(v_lit_241, 2)), v_t_246);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_249 = heff_strSlice(v_a_245, v_t_248, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(v_x_243, v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1943354043x700174004_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1943354043x700174004_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1943354043x700174004(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s727666736x1458251130_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s727666736x1458251130_entry, 2, 0};

V g_list_2efind_24s727666736x1458251130(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s727666736x1458251130_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s727666736x1458251130(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2eany_24s1497517957x114012878_str0, 16, "refactor.rewrite");
Clo g_list_2eany_24s1497517957x114012878_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1497517957x114012878_entry, 1, 0};

V g_list_2eany_24s1497517957x114012878(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JInt: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JString: {
      V v_k_246 = heff_field(v_x_241, 0);
      V v_t_247 = heff_strSlice(((V)&g_list_2eany_24s1497517957x114012878_str0), MK_INT(0LL), heff_strLength_lent(v_k_246, 0));
      if (heff_strEq_c_lent(v_t_247, v_k_246, 1)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    case TAG_JArray: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JObject: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1497517957x114012878(a0); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s561186959x2071570661_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s561186959x2071570661_24dps_entry, 4, 0};

V g_list_2efilter_24s561186959x2071570661_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s561186959x2071570661_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s561186959x2071570661_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1623010005x1805617852_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1623010005x1805617852_24dps_entry, 2, 0};

V g_list_2efilter_24s1623010005x1805617852_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1623010005x1805617852_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1623010005x1805617852_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f552047357x993882406_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f552047357x993882406_entry, 2, 0};

V g_list_2efoldl_24f552047357x993882406(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2ecompile_2esimplify_2etagLeaves(a_0)); heff_drop(v_t_247); r_; });
    V t_0 = heff_intAdd(v_z_240, v_x_248);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f552047357x993882406_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f552047357x993882406(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1457339348x592422294_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1457339348x592422294_24dps_entry, 4, 0};

V g_list_2emap_24f1457339348x592422294_24dps(V v_lit_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = heff_intShow(heff_strByteAt_lent(v_lit_240, v_a_241, 0));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
    V t_2 = v_b_242;
    V t_3 = v_cell_246;
    v_lit_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1457339348x592422294_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1882859809x1518778929_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1882859809x1518778929_entry, 3, 0};

V g_list_2efoldl_24f1882859809x1518778929(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_241, 0);
    V v_ds_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_d_243);
      heff_drop(v_ds_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_e_245 = heff_field(v_x2_242, 0);
      V v_es_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_d_243, v_e_245});
      V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ds_244;
      V t_2 = v_es_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1882859809x1518778929(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1539731936x1117725130_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1539731936x1117725130_entry, 3, 0};

V g_list_2emap_24f1539731936x1117725130(V v_lit_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = (g_list_2emap_24f1539731936x1117725130_24dps(v_lit_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_n_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1539731936x1117725130(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f768999161x1997188166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_entry, 3, 0};

V g_list_2emap_24f768999161x1997188166(V v_lit_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, v_i_241, 0), heff_hole()});
    V v_u_245 = (g_list_2emap_24f768999161x1997188166_24dps(v_lit_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_n_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f768999161x1997188166(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2efoldl_24f1677743806x2032371213_str0, 1, "_");
Clo g_list_2efoldl_24f1677743806x2032371213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1677743806x2032371213_entry, 2, 0};

V g_list_2efoldl_24f1677743806x2032371213(V v_z_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_sp_243 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_list_2efoldl_24f1677743806x2032371213_str0), 2)) {
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_244);
        return v_z_240;
      } else {
        V v_x_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_243, NTAG(TAG_False)});
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_246, v_z_240}), NTAG(TAG_Nil));
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2422);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2426);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_p12_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_sp_243);
      V v_x_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_p12_2429, NTAG(TAG_False)});
      V t_0 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2431, v_z_240});
      V t_1 = v_q_2430;
      v_z_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1677743806x2032371213(a[0], a[1]);
}