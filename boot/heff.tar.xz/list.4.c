// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayKeeps 39370
#define TAG_At 8900
#define TAG_CDrop 58400
#define TAG_CondBool 38021
#define TAG_Doc 16324
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Eqn 17358
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RDup 30328
#define TAG_RPrimAt 2075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_Sig 30557
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Whole 6035
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_frameworks 717666174
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_out 319944
#define LBL_outcome 1272833429
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_group__arity[] = {LBL_group, LBL_arity};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ecompile_2ecpr_2emergeTy(V, V);
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeTy_clo;
V g_heff_2ecompile_2eemitc_2eglueProvider(V);
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2eglue_2eisGlobalTy(V, V);
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr(V, V, V);
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_list_2eany_24s1760441014x1099436736(V, V);
V g_list_2eany_24s1760441014x1099436736_entry(V self, V *a);
extern Clo g_list_2eany_24s1760441014x1099436736_clo;
V g_list_2eany_24s257543591x25063085(V, V);
V g_list_2eany_24s257543591x25063085_entry(V self, V *a);
extern Clo g_list_2eany_24s257543591x25063085_clo;
V g_list_2ecollapse_24s929646560x1354573257(V, V);
V g_list_2ecollapse_24s929646560x1354573257_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s929646560x1354573257_clo;
V g_list_2edescending_24s136597790x1673774577(V, V, V);
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a);
extern Clo g_list_2edescending_24s136597790x1673774577_clo;
V g_list_2edescending_24s1432586697x321478004(V, V, V);
V g_list_2edescending_24s1432586697x321478004_entry(V self, V *a);
extern Clo g_list_2edescending_24s1432586697x321478004_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1603368658x2028032749(V, V, V);
V g_list_2efoldl_24s1603368658x2028032749_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1603368658x2028032749_clo;
V g_list_2efoldl_24s1885006984x1134653659(V, V);
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885006984x1134653659_clo;
V g_list_2efoldl_24s2147120392x1124384541(V, V, V);
V g_list_2efoldl_24s2147120392x1124384541_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2147120392x1124384541_clo;
V g_list_2efoldl_24s291344770x1790586136(V, V);
V g_list_2efoldl_24s291344770x1790586136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s291344770x1790586136_clo;
V g_list_2efoldl_24s586092072x139578797(V, V);
V g_list_2efoldl_24s586092072x139578797_entry(V self, V *a);
extern Clo g_list_2efoldl_24s586092072x139578797_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s110788034x1785682300_24dps(V, V);
V g_list_2ekeepIf_24s110788034x1785682300_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_24dps_clo;
V g_list_2ekeepIf_24s1190092672x1539603713_24dps(V, V, V);
V g_list_2ekeepIf_24s1190092672x1539603713_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1190092672x1539603713_24dps_clo;
V g_list_2ekeepIf_24s1615580983x376857327_24dps(V, V);
V g_list_2ekeepIf_24s1615580983x376857327_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1615580983x376857327_24dps_clo;
V g_list_2ekeepIf_24s1911725233x106069160_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s1911725233x106069160_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1911725233x106069160_24dps_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2ekeepIf_24s537296923x1092827761_24dps(V, V, V);
V g_list_2ekeepIf_24s537296923x1092827761_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_24dps_clo;
V g_list_2ekeepIf_24s735270044x1288664053_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1457339348x592422294_24dps(V, V, V, V);
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_24dps_clo;
V g_list_2emap_24f1730403549x1479772376(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_clo;
V g_list_2emap_24f1730403549x1479772376_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_24dps_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24s1068270568x176847536_24dps(V, V);
V g_list_2emap_24s1068270568x176847536_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1068270568x176847536_24dps_clo;
V g_list_2emap_24s1113395621x248103432_24dps(V, V);
V g_list_2emap_24s1113395621x248103432_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_24dps_clo;
V g_list_2emap_24s1136209598x1881409718(V);
V g_list_2emap_24s1136209598x1881409718_entry(V self, V *a);
extern Clo g_list_2emap_24s1136209598x1881409718_clo;
V g_list_2emap_24s1136209598x1881409718_24dps(V, V);
V g_list_2emap_24s1136209598x1881409718_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1136209598x1881409718_24dps_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s1325317589x1506218481_24dps(V, V, V, V);
V g_list_2emap_24s1325317589x1506218481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_24dps_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_list_2emap_24s143096761x246530315_24dps(V, V);
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_24dps_clo;
V g_list_2emap_24s1435185561x202019164_24dps(V, V);
V g_list_2emap_24s1435185561x202019164_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_24dps_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_list_2emap_24s146946949x1862800301_24dps(V, V);
V g_list_2emap_24s146946949x1862800301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_24dps_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s1498757180x165099811_24dps(V, V);
V g_list_2emap_24s1498757180x165099811_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_24dps_clo;
V g_list_2emap_24s1556510018x266294768_24dps(V, V);
V g_list_2emap_24s1556510018x266294768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1556510018x266294768_24dps_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1585362143x1323498048_24dps(V, V);
V g_list_2emap_24s1585362143x1323498048_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_24dps_clo;
V g_list_2emap_24s1700608285x1639860354(V);
V g_list_2emap_24s1700608285x1639860354_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_clo;
V g_list_2emap_24s1700608285x1639860354_24dps(V, V);
V g_list_2emap_24s1700608285x1639860354_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_24dps_clo;
V g_list_2emap_24s1839428429x1874782624(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1839428429x1874782624_entry(V self, V *a);
extern Clo g_list_2emap_24s1839428429x1874782624_clo;
V g_list_2emap_24s1839428429x1874782624_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1839428429x1874782624_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1839428429x1874782624_24dps_clo;
V g_list_2emap_24s1901363476x1479927424_24dps(V, V);
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24dps(V, V);
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24dps_clo;
V g_list_2emap_24s2130193383x1335133353_24dps(V, V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s3575633x347355318_24dps(V, V);
V g_list_2emap_24s3575633x347355318_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_24dps_clo;
V g_list_2emap_24s620499005x2067584111_24dps(V, V, V);
V g_list_2emap_24s620499005x2067584111_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_24dps_clo;
V g_list_2emap_24s70140105x1635164657_24dps(V, V);
V g_list_2emap_24s70140105x1635164657_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s70140105x1635164657_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_clo;
V g_list_2ezipWith_24s1680834068x1673006787_24dps(V, V, V);
V g_list_2ezipWith_24s1680834068x1673006787_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;

HeffT3 g_list_2edrop_24cpr(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242), heff_dup(v_xs_243)}});
    } else {
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1876717925x1404326288_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s1876717925x1404326288_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s114050048x1903860601_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s114050048x1903860601_entry, 2, 0};

V g_list_2efoldl_24s114050048x1903860601(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd_lent(v_z_240, v_x_242, 1);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s114050048x1903860601(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2029035892x1571084362_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_entry, 1, 0};

V g_list_2emap_24s2029035892x1571084362(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2029035892x1571084362_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362(a[0]);
}
Clo g_list_2eany_24s1760441014x1099436736_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1760441014x1099436736_entry, 2, 0};

V g_list_2eany_24s1760441014x1099436736(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_lit_240, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_intEq_c_lent(v_t_246, v_x_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1760441014x1099436736_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1760441014x1099436736(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s291344770x1790586136_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s291344770x1790586136_entry, 2, 0};

V g_list_2efoldl_24s291344770x1790586136(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_body_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_key_245 = heff_dup(heff_rfield(v_x_242, 0));
    V v_t_246 = v_body_244;
    V v_t_2446;
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ELam: {
      V v_a_249 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_2446 = ({ V a_0 = v_z_240; V a_1 = v_key_245; V a_2 = v_a_249; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_245); heff_drop(v_a_249); r_; });
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_key_245);
      v_t_2446 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V t_0 = v_t_2446;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s291344770x1790586136_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s291344770x1790586136(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1911725233x106069160_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1911725233x106069160_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s1911725233x106069160_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_list_2efoldl_24s65689923x209800052(v_lit_240, heff_dup(v_lit_241), v_x_245));
    if (heff_intLe_c_lent(v_lit_242, v_a_247, 2)) {
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_u_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s1911725233x106069160_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2ekeepIf_24s1911725233x106069160_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2ecollapse_24s929646560x1354573257_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s929646560x1354573257_entry, 2, 0};

V g_list_2ecollapse_24s929646560x1354573257(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_2410;
      switch (heff_tag_of(v_below_245)) {
      case TAG_Nil: {
        v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_field(v_below_245, 0);
        switch (heff_tag_of(v_run_240)) {
        case TAG_Nil: {
          v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_dup(heff_field(v_run_240, 0));
          if (heff_intLe_c(heff_dup(heff_rfield(v_a_246, 0)), heff_get_n(v_b_248, 0, 6))) {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          } else {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(NTAG(TAG_False), v_run_240, heff_dup(v_below_245)));
          }
          break;
        }
        default: heff_nomatch(v_run_240);
        }
        break;
      }
      default: heff_nomatch(v_below_245);
      }
      V t_0 = v_t_2410;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s929646560x1354573257_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s929646560x1354573257(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s620499005x2067584111_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s620499005x2067584111_24dps_entry, 3, 0};

V g_list_2emap_24s620499005x2067584111_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s620499005x2067584111_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s620499005x2067584111_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_24dps_str0, 1, "`");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_24dps_str1, 30, "` has a type but no definition");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_24dps_str2, 1, "`");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_24dps_str3, 17, "` needs a type: `");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_24dps_str4, 7, " : ...`");
Clo g_list_2emap_24s2130193383x1335133353_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2130193383x1335133353_24dps_entry, 5, 0};

V g_list_2emap_24s2130193383x1335133353_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_broken_247 = heff_dup(v_lit_240);
    V v_sigs_248 = heff_dup(v_lit_241);
    V v_eqns_249 = heff_dup(v_lit_242);
    V v_x4_2410 = v_x_245;
    V v_t_2442;
    switch (heff_tag_of(v_x4_2410)) {
    case TAG_Sig: {
      V v_f_2412 = heff_field(v_x4_2410, 1);
      V v_fsp_2413 = heff_field(v_x4_2410, 2);
      heff_take_n(v_x4_2410, 6ULL, 5);
      heff_drop(v_sigs_248);
      HeffT2 v_t_2416 = ({ V a_0 = v_eqns_249; V a_1 = v_f_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_eqns_249); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          heff_drop(v_broken_247);
          heff_drop(v_f_2412);
          heff_drop(v_fsp_2413);
          V v_x_2419 = v_field_2418;
          heff_drop(v_x_2419);
          v_t_2442 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2418);
          HeffT2 v_t_2420 = ({ V a_0 = v_broken_247; V a_1 = v_f_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_broken_247); r_; });
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop(v_f_2412);
              heff_drop(v_fsp_2413);
              V v_x_2423 = v_field_2422;
              heff_drop(v_x_2423);
              v_t_2442 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_field_2422);
              V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2130193383x1335133353_24dps_str0), v_f_2412), ((V)&g_list_2emap_24s2130193383x1335133353_24dps_str1));
              V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2424, v_fsp_2413, NTAG(TAG_Nothing)});
              v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
            }
          }
        }
      }
      break;
    }
    case TAG_Eqn: {
      V v_f_2426 = heff_field(v_x4_2410, 0);
      V v_sp_2428 = heff_field(v_x4_2410, 2);
      heff_take_n(v_x4_2410, 5ULL, 3);
      heff_drop(v_eqns_249);
      HeffT2 v_t_2429 = ({ V a_0 = v_sigs_248; V a_1 = v_f_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_sigs_248); r_; });
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          heff_drop(v_broken_247);
          heff_drop(v_f_2426);
          heff_drop(v_sp_2428);
          V v_x_2432 = v_field_2431;
          heff_drop(v_x_2432);
          v_t_2442 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2431);
          HeffT2 v_t_2433 = ({ V a_0 = v_broken_247; V a_1 = v_f_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_broken_247); r_; });
          {
            V v_field_2435 = v_t_2433.f[1];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              heff_drop(v_f_2426);
              heff_drop(v_sp_2428);
              V v_x_2436 = v_field_2435;
              heff_drop(v_x_2436);
              v_t_2442 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_field_2435);
              V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2130193383x1335133353_24dps_str2), heff_dup(v_f_2426)), ((V)&g_list_2emap_24s2130193383x1335133353_24dps_str3));
              V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, v_f_2426), ((V)&g_list_2emap_24s2130193383x1335133353_24dps_str4));
              V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2438, v_sp_2428, NTAG(TAG_Nothing)});
              v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
            }
          }
        }
      }
      break;
    }
    case TAG_Whole: {
      heff_take_n(v_x4_2410, 0ULL, 1);
      heff_drop(v_broken_247);
      heff_drop(v_sigs_248);
      heff_drop(v_eqns_249);
      v_t_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Doc: {
      heff_take_n(v_x4_2410, 0ULL, 1);
      heff_drop(v_broken_247);
      heff_drop(v_sigs_248);
      heff_drop(v_eqns_249);
      v_t_2442 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x4_2410);
    }
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2442, heff_hole()});
    V v_u_2444 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2443);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2444;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24s2130193383x1335133353_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24s146946949x1862800301_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s146946949x1862800301_entry, 1, 0};

V g_list_2emap_24s146946949x1862800301(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_243 = heff_take_field(v_x_241, 1);
    V v_start_244 = heff_take_field(v_x_241, 3);
    V v_end_245 = heff_get_n(v_x_241, 4, 9);
    V v_t_246 = heff_rec_n(2, shape_name__span, (V[]){v_text_243, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s146946949x1862800301_24dps(v_xs_242, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s146946949x1862800301(a[0]);
}
HEFF_LIT(g_list_2emap_24s143096761x246530315_str0, 7, "Float64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str10, 1, "_");
HEFF_LIT(g_list_2emap_24s143096761x246530315_str11, 1, "\?");
Clo g_list_2emap_24s143096761x246530315_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s143096761x246530315_entry, 1, 0};

V g_list_2emap_24s143096761x246530315(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_FtFloat: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str1);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str2);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str3);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str4);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str5);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str6);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str7);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str8);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str9);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_244 = ((V)&g_list_2emap_24s143096761x246530315_str11);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s143096761x246530315_24dps(v_xs_242, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s143096761x246530315_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s143096761x246530315(a[0]);
}
Clo g_list_2emap_24s1556510018x266294768_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1556510018x266294768_24dps_entry, 2, 0};

V g_list_2emap_24s1556510018x266294768_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2447;
    switch (heff_tag_of(v_t_247)) {
    case TAG_EVar: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_247, 0ULL, 3);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_247, 0ULL, 4);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_247, 0ULL, 3);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_247, 0ULL, 3);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_cell_2448 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2447, heff_hole()});
    V v_u_2449 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2448);
    V t_0 = v_xs_243;
    V t_1 = v_u_2449;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1556510018x266294768_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1556510018x266294768_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s110788034x1785682300_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s110788034x1785682300_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s110788034x1785682300_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_RepV: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_246, 0ULL, 1);
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_243;
      V t_1 = v_u_249;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      V v_cell_2410 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2410);
      V t_0 = v_xs_243;
      V t_1 = v_u_2411;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepInt: {
      V v_cell_2412 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
      V t_0 = v_xs_243;
      V t_1 = v_u_2413;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s110788034x1785682300_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s110788034x1785682300_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1885006984x1134653659_lam0(V self, V *args);
Clo g_list_2efoldl_24s1885006984x1134653659_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1885006984x1134653659_entry, 2, 0};

V g_list_2efoldl_24s1885006984x1134653659(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_body_244 = heff_take_field(v_x_242, 2);
    V v_key_245 = heff_get_n(v_x_242, 0, 3);
    V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_244));
    V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
    V v_t_2415 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s1885006984x1134653659_lam0, 2, 1, (V[]){v_key_245}); V a_1 = v_z_240; V a_2 = v_t_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_247); r_; });
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1885006984x1134653659(a[0], a[1]);
}
V g_list_2efoldl_24s1885006984x1134653659_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_g_249 = args[1];
  V v_key_245 = heff_env(self)[0];
  HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_acc_248, v_g_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_t_2414;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2414 = v_x_2413;
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = NTAG(TAG_Nil);
    }
    heff_clo_take(self, 1);
    return ({ V a_0 = v_acc_248; V a_1 = v_g_249; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_245, v_t_2414}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(v_g_249); heff_drop(b_2); r_; });
  }
}
Clo g_list_2efoldl_24s2147120392x1124384541_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2147120392x1124384541_entry, 3, 0};

V g_list_2efoldl_24s2147120392x1124384541(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_a_248 = v_field_246;
      V v_a_249 = v_field_247;
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_a_249, 0, 2)));
      V v_t_2411 = ({ V rv_2 = v_a_248; V rr_ = heff_rec_reuse_nf(v_x_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI(v_t_2410, v_t_2412));
      V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, v_z_241));
      V t_0 = v_lit_240;
      V t_1 = v_t_2414;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2147120392x1124384541_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24s2147120392x1124384541(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1901363476x1479927424_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1901363476x1479927424_24dps_entry, 2, 0};

V g_list_2emap_24s1901363476x1479927424_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_242, NTAG(TAG_Nothing)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_t_244}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1901363476x1479927424_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1068270568x176847536_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1068270568x176847536_24dps_entry, 2, 0};

V g_list_2emap_24s1068270568x176847536_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_242, NTAG(TAG_Nothing)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1068270568x176847536_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1068270568x176847536_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1700608285x1639860354_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1700608285x1639860354_entry, 1, 0};

V g_list_2emap_24s1700608285x1639860354(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1700608285x1639860354_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1700608285x1639860354_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1700608285x1639860354(a[0]);
}
Clo g_list_2emap_24s1136209598x1881409718_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1136209598x1881409718_entry, 1, 0};

V g_list_2emap_24s1136209598x1881409718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_b_243 = heff_field(v_x_241, 0);
      V v_r_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RDup, 1, (V[]){v_b_243}), NTAG(TAG_Nil)});
      V v_t_246 = heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayKeeps), v_r_244, v_t_245});
      v_t_247 = heff_tag_n(TAG_CondBool, 1, (V[]){v_t_246});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1136209598x1881409718_24dps(v_xs_242, v_cell_248));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1136209598x1881409718_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1136209598x1881409718(a[0]);
}
Clo g_list_2ezipWith_24s1680834068x1673006787_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1680834068x1673006787_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1680834068x1673006787_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1680834068x1673006787_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s1680834068x1673006787_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2efoldl_24s1603368658x2028032749_str0, 0, "");
V g_list_2efoldl_24s1603368658x2028032749_lam0(V self, V *args);
Clo g_list_2efoldl_24s1603368658x2028032749_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1603368658x2028032749_entry, 3, 0};

V g_list_2efoldl_24s1603368658x2028032749(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_bodies_245 = heff_dup(v_lit_240);
    V v_c_246 = v_z_241;
    V v_ks_247 = heff_dup(v_x_243);
    V v_t_2462 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s1603368658x2028032749_lam0, 2, 2, (V[]){heff_dup(v_ks_247), v_bodies_245}); V a_1 = v_c_246; V a_2 = v_ks_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ks_247); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_t_2462;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1603368658x2028032749_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s1603368658x2028032749(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_list_2efoldl_24s1603368658x2028032749_lam0(V self, V *args) {
  V v_c2_248 = args[0];
  V v_k_249 = args[1];
  V v_ks_247 = heff_env(self)[0];
  V v_bodies_245 = heff_env(self)[1];
  V v_group_2410 = heff_take_field(v_c2_248, 0);
  V v_arity_2411 = heff_take_field(v_c2_248, 1);
  V v_t_2414;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_ks_247)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_list_2efoldl_24s1603368658x2028032749_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_ks_247, 0);
    heff_take_n(v_ks_247, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_ks_247);
  }
  V v_t_2415 = ({ V a_0 = v_group_2410; V a_1 = v_k_249; V a_2 = v_t_2414; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  HeffT2 v_t_2416 = ({ V a_0 = v_bodies_245; V a_1 = v_k_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_245); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_x1_2420;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_x1_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_x1_2420 = NTAG(TAG_EAbandon);
    }
    V v_t_2460;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_EVar: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ELam: {
      V v_xs_2423 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 2);
      v_t_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x1_2420, 0ULL, 4);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EAbandon: {
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = MK_INT(1000000LL);
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2461 = ({ V a_0 = v_arity_2411; V a_1 = v_k_249; V a_2 = v_t_2460; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_249); heff_drop(v_t_2460); r_; });
    return ({ V rv_0 = v_t_2415; V rv_1 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_c2_248, 0ULL, 2, shape_group__arity, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
}
Clo g_list_2emap_24s1839428429x1874782624_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1839428429x1874782624_entry, 11, 0};

V g_list_2emap_24s1839428429x1874782624(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24MkPair = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = ({ V a_0 = v_a_2413; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2413); r_; });
      V v_a_2416 = (g_list_2emap_24tok2(v_ru_24x_2411_24MkPair, heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2414)));
      V v_t_2417 = ({ V a_0 = v_a_2416; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2416); r_; });
      V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2415), heff_dup(v_lit_243));
      V v_t_2419 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2418), heff_dup(v_lit_244));
      V v_t_2420 = heff_strAppend(heff_strAppend(heff_dup(v_lit_246), v_t_2417), heff_dup(v_lit_247));
      V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_lit_245), v_t_2420), heff_dup(v_lit_248));
      v_t_2422 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2421), heff_dup(v_lit_249));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_lit_249; V a_10 = v_xs_2412; V a_11 = v_cell_2423; V r_ = (g_list_2emap_24s1839428429x1874782624_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_243); heff_drop(v_lit_244); heff_drop(v_lit_245); heff_drop(v_lit_246); heff_drop(v_lit_247); heff_drop(v_lit_248); heff_drop(v_lit_249); r_; });
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s1839428429x1874782624_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1839428429x1874782624(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2emap_24s70140105x1635164657_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s70140105x1635164657_24dps_entry, 2, 0};

V g_list_2emap_24s70140105x1635164657_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
    V t_0 = v_xs_243;
    V t_1 = v_u_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s70140105x1635164657_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s70140105x1635164657_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1585362143x1323498048_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1585362143x1323498048_entry, 1, 0};

V g_list_2emap_24s1585362143x1323498048(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_241)) {
    case TAG_PartVal: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24PartVal = heff_take_reuse_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_a_243)) {
      case TAG_SVar: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_a_245 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2428 = heff_tag_at_n(v_ru_24x_241_24PartVal, TAG_Just, 1, (V[]){v_a_245});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_a_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x_241_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2428 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = (g_list_2emap_24s1585362143x1323498048_24dps(v_xs_242, v_cell_2429));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1585362143x1323498048(a[0]);
}
Clo g_list_2emap_24s1325317589x1506218481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1325317589x1506218481_entry, 3, 0};

V g_list_2emap_24s1325317589x1506218481(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_list_2emap_24s1325317589x1506218481_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1325317589x1506218481(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_24dps_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_24dps_str1, 1, "-");
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_24dps_str2, 1, " ");
Clo g_list_2ekeepIf_24s1615580983x376857327_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1615580983x376857327_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1615580983x376857327_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24s1615580983x376857327_24dps_str0), 2) || (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_list_2ekeepIf_24s1615580983x376857327_24dps_str1)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_list_2ekeepIf_24s1615580983x376857327_24dps_str2), v_x_242, MK_INT(0LL), 5))))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
      V t_0 = v_xs_243;
      V t_1 = v_u_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1615580983x376857327_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s1615580983x376857327_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1190092672x1539603713_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1190092672x1539603713_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1190092672x1539603713_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = (g_heff_2ecompile_2eglue_2eisGlobalTy(v_lit_240, heff_get_n(v_t_247, 1, 4)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_2410;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1190092672x1539603713_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1190092672x1539603713_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s537296923x1092827761_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s537296923x1092827761_entry, 2, 0};

V g_list_2ekeepIf_24s537296923x1092827761(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s537296923x1092827761_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s537296923x1092827761(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2edescending_24s136597790x1673774577_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s136597790x1673774577_entry, 3, 0};

V g_list_2edescending_24s136597790x1673774577(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 0, 2), heff_dup(heff_rfield(v_y_243, 0)))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_243, v_ys_244})});
    } else {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s136597790x1673774577(a[0], a[1], a[2]);
}
Clo g_list_2edescending_24s1432586697x321478004_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1432586697x321478004_entry, 3, 0};

V g_list_2edescending_24s1432586697x321478004(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 7);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 2, 7), heff_dup(heff_rfield(v_y_243, 2)))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_243, v_ys_244})});
    } else {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s1432586697x321478004_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1432586697x321478004(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s586092072x139578797_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s586092072x139578797_entry, 2, 0};

V g_list_2efoldl_24s586092072x139578797(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s586092072x139578797_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s586092072x139578797(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1435185561x202019164_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1435185561x202019164_24dps_entry, 2, 0};

V g_list_2emap_24s1435185561x202019164_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eglueProvider(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1435185561x202019164_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1435185561x202019164_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_24dps_str5, 0, "");
Clo g_list_2emap_24s1113395621x248103432_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1113395621x248103432_24dps_entry, 2, 0};

V g_list_2emap_24s1113395621x248103432_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_JNull: {
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str0);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str1);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str2);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str3);
      break;
    }
    case TAG_JString: {
      V v_t_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_t_247;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str4);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = ((V)&g_list_2emap_24s1113395621x248103432_24dps_str5);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
    V t_0 = v_xs_243;
    V t_1 = v_u_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1113395621x248103432_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1113395621x248103432_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1498757180x165099811_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1498757180x165099811_entry, 1, 0};

V g_list_2emap_24s1498757180x165099811(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1498757180x165099811_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1498757180x165099811(a[0]);
}
Clo g_list_2eany_24s257543591x25063085_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s257543591x25063085_entry, 2, 0};

V g_list_2eany_24s257543591x25063085(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 2)), heff_dup(v_x_242))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s257543591x25063085_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s257543591x25063085(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s735270044x1288664053_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s735270044x1288664053_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s735270044x1288664053_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_245)) {
    case TAG_JNull: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JBool: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JInt: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JFloat: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JString: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JArray: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_JObject: {
      V v_a_2412 = heff_dup(heff_field(v_x_245, 0));
      HeffT2 v_t_2413 = ({ V a_0 = v_lit_240; V a_1 = v_a_2412; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_a_2412); r_; });
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_a_2416 = v_field_2415;
          V v_t_2419;
          switch (heff_tag_of(v_a_2416)) {
          case TAG_MkPair: {
            V v_a_2418 = heff_field(v_a_2416, 1);
            heff_take_n(v_a_2416, 2ULL, 2);
            v_t_2419 = v_a_2418;
            break;
          }
          default: heff_nomatch(v_a_2416);
          }
          switch (heff_tag_of(v_t_2419)) {
          case TAG_JNull: {
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          case TAG_JString: {
            V v_a_2423 = heff_field(v_t_2419, 0);
            heff_take_n(v_t_2419, 1ULL, 1);
            v_t_2426 = heff_bool((heff_strEq_c_lent(v_a_2423, v_lit_241, 0) || heff_strEq_c_lent(v_a_2423, v_lit_242, 0)));
            heff_drop(v_a_2423);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2419);
          }
        } else {
          heff_drop(v_field_2415);
          v_t_2426 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      V v_cell_2427 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_2428 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2427);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_u_2428;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2426);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s735270044x1288664053_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2ekeepIf_24s735270044x1288664053_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24s3575633x347355318_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s3575633x347355318_entry, 1, 0};

V g_list_2emap_24s3575633x347355318(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2eterminal_2ewidget_2ecolumns(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s3575633x347355318_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s3575633x347355318_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s3575633x347355318(a[0]);
}
Clo g_list_2emap_24f1457339348x592422294_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1457339348x592422294_24dps_entry, 4, 0};

V g_list_2emap_24f1457339348x592422294_24dps(V v_lit_240, V v_box_24a_241, V v_box_24b_242, V v_d_243) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
  int64_t v_b_242 = heff_peek_word(v_box_24b_242);
top: ;
  if ((v_b_242 < v_a_241)) {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_244 = heff_intShow(heff_strByteAt_lent(v_lit_240, heff_box_word(v_a_241), 2));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_245);
    V t_0 = v_lit_240;
    int64_t t_1 = (v_a_241 + ((int64_t)1ULL));
    int64_t t_2 = v_b_242;
    V t_3 = v_u_246;
    v_lit_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24f1457339348x592422294_24dps(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1882859809x1518778929_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1882859809x1518778929_entry, 3, 0};

V g_list_2efoldl_24f1882859809x1518778929(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_241, 0);
    V v_ds_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_d_243);
      heff_drop(v_ds_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_k_245 = heff_field(v_x2_242, 0);
      V v_ks_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_d_243, v_k_245});
      V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ds_244;
      V t_2 = v_ks_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1882859809x1518778929(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f768999161x1997188166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_entry, 3, 0};

V g_list_2emap_24f768999161x1997188166(V v_lit_240, V v_box_24i_241, V v_n_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_peek_word(v_n_242) <= v_i_241)) {
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, heff_box_word(v_i_241), 2), heff_hole()});
    V v_u_244 = ({ V a_0 = v_lit_240; V a_1 = heff_box_word((v_i_241 + ((int64_t)1ULL))); V a_2 = v_n_242; V a_3 = v_cell_243; V r_ = (g_list_2emap_24f768999161x1997188166_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_n_242); r_; });
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f768999161x1997188166(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1730403549x1479772376_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1730403549x1479772376_entry, 12, 0};

V g_list_2emap_24f1730403549x1479772376(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_peek_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_peek_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_peek_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_peek_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2414 = heff_take_field(v_x_2412, 0);
    V v_key_2415 = heff_get_n(v_x_2412, 1, 2);
    V v_a_2416 = v_name_2414;
    if ((heff_intLe_c_lent(v_lit_240, heff_strFind_lent(v_lit_241, v_a_2416, v_lit_242, 0), 2) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2416);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_key_2415, heff_hole()});
      V v_u_2418 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V b_3 = heff_box_word(v_lit_243); V a_4 = v_lit_244; V a_5 = v_lit_245; V b_6 = heff_box_word(v_lit_246); V b_7 = heff_box_word(v_lit_247); V a_8 = v_lit_248; V a_9 = v_lit_249; V b_10 = heff_box_word(v_lit_2410); V a_11 = v_xs_2413; V a_12 = v_cell_2417; V r_ = (g_list_2emap_24f1730403549x1479772376_24dps(a_0, a_1, a_2, b_3, a_4, a_5, b_6, b_7, a_8, a_9, b_10, a_11, a_12)); heff_drop(b_3); heff_drop(b_6); heff_drop(b_7); heff_drop(b_10); r_; });
      heff_drop(v_u_2418);
      return v_cell_2417;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_key_2415);
      heff_drop(v_a_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V r = g_list_2emap_24f1730403549x1479772376(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a[11]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); return r;
}