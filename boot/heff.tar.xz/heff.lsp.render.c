// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_line 9817275
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_off 319465
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
static uint32_t shape_line__off__col[] = {LBL_line, LBL_off, LBL_col};
V g_heff_2elsp_2erender_2ecutLine(V, V, V);
V g_heff_2elsp_2erender_2ecutLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ecutLine_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2efirstLines(V, V, V, V, V);
V g_heff_2elsp_2erender_2efirstLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2efirstLines_clo;
V g_heff_2elsp_2erender_2einsideLine(V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideLine_clo;
V g_heff_2elsp_2erender_2einsideRange(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideRange_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideRange_clo;
V g_heff_2elsp_2erender_2einsideRange_24dps(V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideRange_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideRange_24dps_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2elsp_2erender_2elineStartFrom(V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineStartFrom_clo;
V g_heff_2elsp_2erender_2elineText(V, V);
V g_heff_2elsp_2erender_2elineText_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineText_clo;
V g_heff_2elsp_2erender_2elinesPretty(V, V, V, V);
V g_heff_2elsp_2erender_2elinesPretty_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elinesPretty_clo;
V g_heff_2elsp_2erender_2elinesPrettyAt(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2elinesPrettyAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elinesPrettyAt_clo;
V g_heff_2elsp_2erender_2emiddleLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2emiddleLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2emiddleLines_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2eoneLine(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLine_clo;
V g_heff_2elsp_2erender_2eoneLineIn(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLineIn_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2elsp_2erender_2erepeated_24acc(V, V, V);
V g_heff_2elsp_2erender_2erepeated_24acc_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_24acc_clo;
V g_heff_2elsp_2erender_2espacesBefore(V, V);
V g_heff_2elsp_2erender_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espacesBefore_clo;
V g_heff_2elsp_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espanLines_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HEFF_LIT(g_heff_2elsp_2erender_2elineColAt_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2elineColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineColAt_entry, 5, 0};

V g_heff_2elsp_2erender_2elineColAt(V v_src_240, V v_i_241, V v_l_242, V v_start_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_start_243), heff_dup(v_i_241), MK_INT(0LL)));
    return heff_rec_n(3, shape_line__off__col, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243), v_t_245});
  }
  case TAG_Just: {
    V v_nl_246 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    if (heff_intLe_c(heff_dup(v_i_241), heff_dup(v_nl_246))) {
      heff_drop(v_nl_246);
      V v_t_248 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_start_243), heff_dup(v_i_241), MK_INT(0LL)));
      return heff_rec_n(3, shape_line__off__col, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243), v_t_248});
    } else {
      heff_drop(v_start_243);
      V v_t_249 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2elineColAt_str0), heff_dup(v_src_240), heff_intAdd(heff_dup(v_nl_246), MK_INT(1LL))));
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_246, MK_INT(1LL));
      V t_4 = v_t_249;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2elineColAt(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elsp_2erender_2enumDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2enumDigits_entry, 1, 0};

V g_heff_2elsp_2erender_2enumDigits(V v_x_240) {
top: ;
  if (heff_intLt_c(heff_dup(v_x_240), MK_INT(10LL))) {
    heff_drop(v_x_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2elsp_2erender_2enumDigits(heff_intDiv(v_x_240, MK_INT(10LL))));
    return heff_intAdd(MK_INT(1LL), v_t_242);
  }
}
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2enumDigits(a[0]);
}
HEFF_LIT(g_heff_2elsp_2erender_2erepeated_str0, 0, "");
Clo g_heff_2elsp_2erender_2erepeated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2erepeated_entry, 2, 0};

V g_heff_2elsp_2erender_2erepeated(V v_k_240, V v_c_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2erender_2erepeated_str0);
  } else {
    V v_s_243 = heff_dup(v_c_241);
    return (g_heff_2elsp_2erender_2erepeated_24acc(heff_intSub(v_k_240, MK_INT(1LL)), v_c_241, v_s_243));
  }
}
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2erepeated(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2erender_2erepeated_24acc_str0, 0, "");
Clo g_heff_2elsp_2erender_2erepeated_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2erepeated_24acc_entry, 3, 0};

V g_heff_2elsp_2erender_2erepeated_24acc(V v_k_240, V v_c_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return heff_strAppend(v_acc_242, ((V)&g_heff_2elsp_2erender_2erepeated_24acc_str0));
  } else {
    V v_s_244 = heff_strAppend(v_acc_242, heff_dup(v_c_241));
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_c_241;
    V t_2 = v_s_244;
    v_k_240 = t_0;
    v_c_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2erender_2erepeated_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2erepeated_24acc(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2erender_2elineStartFrom_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2elineStartFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineStartFrom_entry, 3, 0};

V g_heff_2elsp_2erender_2elineStartFrom(V v_src_240, V v_l_241, V v_start_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2elineStartFrom_str0), heff_dup(v_src_240), v_start_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_strLength(v_src_240);
  }
  case TAG_Just: {
    V v_nl_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    if (heff_intEq_c(heff_dup(v_l_241), MK_INT(1LL))) {
      heff_drop(v_src_240);
      heff_drop(v_l_241);
      return heff_intAdd(v_nl_244, MK_INT(1LL));
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_l_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_nl_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_l_241 = t_1;
      v_start_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2elineStartFrom(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2erender_2elineText_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2elineText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineText_entry, 2, 0};

V g_heff_2elsp_2erender_2elineText(V v_src_240, V v_l_241) {
top: ;
  V v_t_243;
  if (heff_intEq_c(heff_dup(v_l_241), MK_INT(0LL))) {
    v_t_243 = MK_INT(0LL);
  } else {
    v_t_243 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_240), heff_dup(v_l_241), MK_INT(0LL)));
  }
  V v_start_245;
  if (heff_intEq_c(heff_dup(v_l_241), MK_INT(0LL))) {
    heff_drop(v_l_241);
    v_start_245 = MK_INT(0LL);
  } else {
    v_start_245 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_241, MK_INT(0LL)));
  }
  V v_t_246 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2elineText_str0), heff_dup(v_src_240), v_start_245));
  V v_t_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_248 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_nl_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_248 = v_nl_247;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strSlice(v_src_240, v_t_243, v_t_248);
}
V g_heff_2elsp_2erender_2elineText_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2elineText(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str4, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str5, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str6, 5, "|\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str7, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str9, 1, " ");
Clo g_heff_2elsp_2erender_2einsideLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideLine_entry, 5, 0};

V g_heff_2elsp_2erender_2einsideLine(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244) {
top: ;
  V v_t_245 = heff_intShow(heff_intAdd(heff_dup(v_l_244), MK_INT(1LL)));
  V v_t_246 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd(heff_dup(v_l_244), MK_INT(1LL))));
  V v_t_247 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_246), ((V)&g_heff_2elsp_2erender_2einsideLine_str0)));
  V v_s_248 = heff_strAppend(v_t_245, heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2erender_2einsideLine_str1)));
  V v_t_249;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str2), heff_strAppend(v_s_248, ((V)&g_heff_2elsp_2erender_2einsideLine_str3)));
  } else {
    v_t_249 = v_s_248;
  }
  V v_t_2411;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_2410 = heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str4), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2einsideLine_str5)));
    v_t_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2erender_2einsideLine_str6));
  } else {
    heff_drop(v_code_241);
    v_t_2411 = ((V)&g_heff_2elsp_2erender_2einsideLine_str7);
  }
  V v_t_2412 = (g_heff_2elsp_2erender_2elineText(v_src_242, v_l_244));
  V v_t_2413 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str8), v_t_2412));
  return heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str9), v_t_2413));
}
V g_heff_2elsp_2erender_2einsideLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2einsideLine(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str1, 3, "...");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str4, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str5, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str6, 5, "|\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str7, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2ecutLine_str8, 1, " ");
Clo g_heff_2elsp_2erender_2ecutLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2ecutLine_entry, 3, 0};

V g_heff_2elsp_2erender_2ecutLine(V v_color_240, V v_code_241, V v_w_242) {
top: ;
  V v_t_243 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_242, MK_INT(1LL)), ((V)&g_heff_2elsp_2erender_2ecutLine_str0)));
  V v_s_244 = heff_strAppend(((V)&g_heff_2elsp_2erender_2ecutLine_str1), v_t_243);
  V v_t_245;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_245 = heff_strAppend(((V)&g_heff_2elsp_2erender_2ecutLine_str2), heff_strAppend(v_s_244, ((V)&g_heff_2elsp_2erender_2ecutLine_str3)));
  } else {
    v_t_245 = v_s_244;
  }
  V v_t_247;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_246 = heff_strAppend(((V)&g_heff_2elsp_2erender_2ecutLine_str4), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2ecutLine_str5)));
    v_t_247 = heff_strAppend(v_t_246, ((V)&g_heff_2elsp_2erender_2ecutLine_str6));
  } else {
    heff_drop(v_code_241);
    v_t_247 = ((V)&g_heff_2elsp_2erender_2ecutLine_str7);
  }
  return heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2elsp_2erender_2ecutLine_str8), v_t_247));
}
V g_heff_2elsp_2erender_2ecutLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2ecutLine(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2erender_2einsideRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideRange_entry, 6, 0};

V g_heff_2elsp_2erender_2einsideRange(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_le_245) {
top: ;
  if (heff_intLt_c(heff_dup(v_le_245), heff_dup(v_l_244))) {
    heff_drop(v_code_241);
    heff_drop(v_src_242);
    heff_drop(v_w_243);
    heff_drop(v_l_244);
    heff_drop(v_le_245);
    return NTAG(TAG_Nil);
  } else {
    V v_t_247 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_l_244)));
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2elsp_2erender_2einsideRange_24dps(v_color_240, v_code_241, v_src_242, v_w_243, heff_intAdd(v_l_244, MK_INT(1LL)), v_le_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
}
V g_heff_2elsp_2erender_2einsideRange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2einsideRange(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2erender_2einsideRange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideRange_24dps_entry, 7, 0};

V g_heff_2elsp_2erender_2einsideRange_24dps(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_le_245, V v_d_246) {
top: ;
  if (heff_intLt_c(heff_dup(v_le_245), heff_dup(v_l_244))) {
    heff_drop(v_code_241);
    heff_drop(v_src_242);
    heff_drop(v_w_243);
    heff_drop(v_l_244);
    heff_drop(v_le_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_248 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_l_244)));
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_color_240;
    V t_1 = v_code_241;
    V t_2 = v_src_242;
    V t_3 = v_w_243;
    V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
    V t_5 = v_le_245;
    V t_6 = v_cell_249;
    v_color_240 = t_0;
    v_code_241 = t_1;
    v_src_242 = t_2;
    v_w_243 = t_3;
    v_l_244 = t_4;
    v_le_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
}
V g_heff_2elsp_2erender_2einsideRange_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2einsideRange_24dps(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2erender_2emiddleLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2emiddleLines_entry, 6, 0};

V g_heff_2elsp_2erender_2emiddleLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_ls_244, V v_le_245) {
top: ;
  V v_t_246 = heff_intAdd(heff_intSub(heff_dup(v_le_245), heff_dup(v_ls_244)), MK_INT(1LL));
  if (heff_intLt_c(MK_INT(6LL), v_t_246)) {
    V v_t_248 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_intAdd(v_ls_244, MK_INT(1LL))));
    V v_t_249 = (g_heff_2elsp_2erender_2ecutLine(v_color_240, heff_dup(v_code_241), heff_dup(v_w_243)));
    V v_t_2410 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, v_code_241, v_src_242, v_w_243, heff_intSub(v_le_245, MK_INT(1LL))));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2411})});
  } else {
    HEFF_LAST return g_heff_2elsp_2erender_2einsideRange(v_color_240, v_code_241, v_src_242, v_w_243, heff_intAdd(v_ls_244, MK_INT(1LL)), heff_intSub(v_le_245, MK_INT(1LL)));
  }
}
V g_heff_2elsp_2erender_2emiddleLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2emiddleLines(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2espacesBefore_str0, 0, "");
Clo g_heff_2elsp_2erender_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2espacesBefore_entry, 2, 0};

V g_heff_2elsp_2erender_2espacesBefore(V v_src_240, V v_s_241) {
top: ;
  V v_l_242 = heff_dup(heff_rfield(v_s_241, 0));
  V v_t_244;
  if (heff_intEq_c(heff_dup(v_l_242), MK_INT(0LL))) {
    heff_drop(v_l_242);
    v_t_244 = MK_INT(0LL);
  } else {
    v_t_244 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_242, MK_INT(0LL)));
  }
  V v_l_245 = heff_take_field(v_s_241, 0);
  V v_t_247;
  if (heff_intEq_c(heff_dup(v_l_245), MK_INT(0LL))) {
    heff_drop(v_l_245);
    v_t_247 = MK_INT(0LL);
  } else {
    v_t_247 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_245, MK_INT(0LL)));
  }
  V v_t_248 = heff_intAdd(v_t_247, heff_get_n(v_s_241, 1, 3));
  V v_s_249 = heff_strSlice(v_src_240, v_t_244, v_t_248);
  V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_s_249)), MK_INT(1LL));
  V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), v_t_2411, MK_INT(-1LL)));
  V v_t_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  return heff_strEq(v_t_2413, ((V)&g_heff_2elsp_2erender_2espacesBefore_str0));
}
V g_heff_2elsp_2erender_2espacesBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2espacesBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str4, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str5, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str6, 5, "/\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str7, 1, "/");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str11, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str12, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str13, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str14, 3, "   ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str15, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str16, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str17, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str18, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str19, 1, "_");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str20, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str21, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str22, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str23, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str24, 2, "  ");
Clo g_heff_2elsp_2erender_2efirstLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2efirstLines_entry, 5, 0};

V g_heff_2elsp_2erender_2efirstLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2elsp_2erender_2espacesBefore(heff_dup(v_src_242), heff_dup(v_s_244)));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_l_246 = heff_dup(heff_rfield(v_s_244, 0));
    V v_t_247 = heff_intShow(heff_intAdd(heff_dup(v_l_246), MK_INT(1LL)));
    V v_t_248 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd(v_l_246, MK_INT(1LL))));
    V v_t_249 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_248), ((V)&g_heff_2elsp_2erender_2efirstLines_str0)));
    V v_s_2410 = heff_strAppend(v_t_247, heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2erender_2efirstLines_str1)));
    V v_t_2411;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2411 = heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str2), heff_strAppend(v_s_2410, ((V)&g_heff_2elsp_2erender_2efirstLines_str3)));
    } else {
      v_t_2411 = v_s_2410;
    }
    V v_t_2413;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      V v_t_2412 = heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str4), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2efirstLines_str5)));
      v_t_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2erender_2efirstLines_str6));
    } else {
      heff_drop(v_code_241);
      v_t_2413 = ((V)&g_heff_2elsp_2erender_2efirstLines_str7);
    }
    V v_t_2414 = (g_heff_2elsp_2erender_2elineText(v_src_242, heff_get_n(v_s_244, 0, 3)));
    V v_t_2415 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str8), v_t_2414));
    V v_t_2416 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str9), v_t_2415));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_245);
    V v_l_2417 = heff_dup(heff_rfield(v_s_244, 0));
    V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_l_2417), MK_INT(1LL)));
    V v_t_2419 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd(v_l_2417, MK_INT(1LL))));
    V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(heff_dup(v_w_243), v_t_2419), ((V)&g_heff_2elsp_2erender_2efirstLines_str10)));
    V v_s_2421 = heff_strAppend(v_t_2418, heff_strAppend(v_t_2420, ((V)&g_heff_2elsp_2erender_2efirstLines_str11)));
    V v_t_2422;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2422 = heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str12), heff_strAppend(v_s_2421, ((V)&g_heff_2elsp_2erender_2efirstLines_str13)));
    } else {
      v_t_2422 = v_s_2421;
    }
    V v_t_2423 = (g_heff_2elsp_2erender_2elineText(v_src_242, heff_take_field(v_s_244, 0)));
    V v_t_2424 = heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str14), v_t_2423));
    V v_t_2425 = (g_heff_2elsp_2erender_2erepeated(v_w_243, ((V)&g_heff_2elsp_2erender_2efirstLines_str15)));
    V v_s_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2elsp_2erender_2efirstLines_str16));
    V v_t_2427;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2427 = heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str17), heff_strAppend(v_s_2426, ((V)&g_heff_2elsp_2erender_2efirstLines_str18)));
    } else {
      v_t_2427 = v_s_2426;
    }
    V v_t_2428 = heff_intAdd(heff_get_n(v_s_244, 2, 3), MK_INT(1LL));
    V v_t_2429 = (g_heff_2elsp_2erender_2erepeated(v_t_2428, ((V)&g_heff_2elsp_2erender_2efirstLines_str19)));
    V v_s_2430 = heff_strAppend(v_t_2429, ((V)&g_heff_2elsp_2erender_2efirstLines_str20));
    V v_t_2432;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      V v_t_2431 = heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str21), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2efirstLines_str22)));
      v_t_2432 = heff_strAppend(v_t_2431, heff_strAppend(v_s_2430, ((V)&g_heff_2elsp_2erender_2efirstLines_str23)));
    } else {
      heff_drop(v_code_241);
      v_t_2432 = v_s_2430;
    }
    V v_t_2433 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str24), v_t_2432));
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2434});
  }
}
V g_heff_2elsp_2erender_2efirstLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2efirstLines(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str4, 1, "_");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str5, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str6, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str7, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str8, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str9, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str12, 1, "\012");
Clo g_heff_2elsp_2erender_2espanLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2espanLines_entry, 6, 0};

V g_heff_2elsp_2erender_2espanLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244, V v_e_245) {
top: ;
  V v_t_246 = (g_heff_2elsp_2erender_2efirstLines(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_s_244)));
  V v_t_247 = (g_heff_2elsp_2erender_2emiddleLines(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_get_n(v_s_244, 0, 3), heff_dup(heff_rfield(v_e_245, 0))));
  V v_t_248 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), v_src_242, heff_dup(v_w_243), heff_take_field(v_e_245, 0)));
  V v_t_249 = (g_heff_2elsp_2erender_2erepeated(v_w_243, ((V)&g_heff_2elsp_2erender_2espanLines_str0)));
  V v_s_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2erender_2espanLines_str1));
  V v_t_2411;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2411 = heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str2), heff_strAppend(v_s_2410, ((V)&g_heff_2elsp_2erender_2espanLines_str3)));
  } else {
    v_t_2411 = v_s_2410;
  }
  V v_t_2412 = heff_intAdd(heff_get_n(v_e_245, 2, 3), MK_INT(1LL));
  V v_t_2413 = (g_heff_2elsp_2erender_2erepeated(v_t_2412, ((V)&g_heff_2elsp_2erender_2espanLines_str4)));
  V v_s_2414 = heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str5), heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2erender_2espanLines_str6)));
  V v_t_2416;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_2415 = heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str7), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2espanLines_str8)));
    v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(v_s_2414, ((V)&g_heff_2elsp_2erender_2espanLines_str9)));
  } else {
    heff_drop(v_code_241);
    v_t_2416 = v_s_2414;
  }
  V v_t_2417 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str10), v_t_2416));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2418})));
  V v_x2_2420 = (g_prelude_2e_2b_2b(v_t_246, v_t_2419));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    return ((V)&g_heff_2elsp_2erender_2espanLines_str11);
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2elsp_2erender_2espanLines_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2espanLines(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str4, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str5, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str6, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str7, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str9, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str10, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str11, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str12, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str13, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str14, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str15, 1, " ");
Clo g_heff_2elsp_2erender_2eoneLineIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2eoneLineIn_entry, 8, 0};

V g_heff_2elsp_2erender_2eoneLineIn(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_ls_245, V v_b_246, V v_e_247) {
top: ;
  V v_t_248 = heff_intShow(heff_intAdd(heff_dup(v_l_244), MK_INT(1LL)));
  V v_t_249 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd(heff_dup(v_l_244), MK_INT(1LL))));
  V v_t_2410 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(heff_dup(v_w_243), v_t_249), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str0)));
  V v_s_2411 = heff_strAppend(v_t_248, heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str1)));
  V v_t_2412;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2412 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str2), heff_strAppend(v_s_2411, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str3)));
  } else {
    v_t_2412 = v_s_2411;
  }
  V v_t_2413 = (g_heff_2elsp_2erender_2elineText(heff_dup(v_src_242), heff_dup(v_l_244)));
  V v_t_2414 = heff_intShow(heff_intAdd(heff_dup(v_l_244), MK_INT(1LL)));
  V v_t_2415 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd(v_l_244, MK_INT(1LL))));
  V v_t_2416 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_2415), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str4)));
  V v_s_2417 = heff_strAppend(v_t_2414, heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str5)));
  V v_t_2418;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2418 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str6), heff_strAppend(v_s_2417, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str7)));
  } else {
    v_t_2418 = v_s_2417;
  }
  V v_t_2419 = (g_heff_2eutil_2erune_2erunesGo(heff_dup(v_src_242), v_ls_245, heff_dup(v_b_246), MK_INT(0LL)));
  V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(v_t_2419, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str8)));
  V v_y_2421 = (g_heff_2eutil_2erune_2erunesGo(v_src_242, v_b_246, v_e_247, MK_INT(0LL)));
  V v_t_2423;
  if (heff_intLe_c(MK_INT(1LL), heff_dup(v_y_2421))) {
    v_t_2423 = v_y_2421;
  } else {
    heff_drop(v_y_2421);
    v_t_2423 = MK_INT(1LL);
  }
  V v_s_2424 = (g_heff_2elsp_2erender_2erepeated(v_t_2423, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str9)));
  V v_t_2426;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_2425 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str10), heff_strAppend(v_code_241, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str11)));
    v_t_2426 = heff_strAppend(v_t_2425, heff_strAppend(v_s_2424, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str12)));
  } else {
    heff_drop(v_code_241);
    v_t_2426 = v_s_2424;
  }
  V v_t_2427 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str13), heff_strAppend(v_t_2420, v_t_2426));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str14), heff_strAppend(v_t_2418, v_t_2427));
  V v_t_2429 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str15), heff_strAppend(v_t_2413, v_t_2428));
  return heff_strAppend(v_t_2412, v_t_2429);
}
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2eoneLineIn(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2eoneLine_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2eoneLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2eoneLine_entry, 6, 0};

V g_heff_2elsp_2erender_2eoneLine(V v_color_240, V v_code_241, V v_src_242, V v_sp_243, V v_w_244, V v_l_245) {
top: ;
  V v_t_247;
  if (heff_intEq_c(heff_dup(v_l_245), MK_INT(0LL))) {
    v_t_247 = MK_INT(0LL);
  } else {
    v_t_247 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
  }
  V v_x_249;
  if (heff_intEq_c(heff_dup(v_l_245), MK_INT(0LL))) {
    v_x_249 = MK_INT(0LL);
  } else {
    v_x_249 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
  }
  V v_y_2410 = heff_take_field(v_sp_243, 0);
  V v_t_2412;
  if (heff_intLe_c(heff_dup(v_x_249), heff_dup(v_y_2410))) {
    heff_drop(v_x_249);
    v_t_2412 = v_y_2410;
  } else {
    heff_drop(v_y_2410);
    v_t_2412 = v_x_249;
  }
  V v_start_2414;
  if (heff_intEq_c(heff_dup(v_l_245), MK_INT(0LL))) {
    v_start_2414 = MK_INT(0LL);
  } else {
    v_start_2414 = (g_heff_2elsp_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
  }
  V v_t_2415 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2eoneLine_str0), heff_dup(v_src_242), v_start_2414));
  V v_x_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x_2417 = heff_strLength(heff_dup(v_src_242));
    break;
  }
  case TAG_Just: {
    V v_nl_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_x_2417 = v_nl_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_y_2418 = heff_get_n(v_sp_243, 1, 2);
  V v_t_2420;
  if (heff_intLe_c(heff_dup(v_x_2417), heff_dup(v_y_2418))) {
    heff_drop(v_y_2418);
    v_t_2420 = v_x_2417;
  } else {
    heff_drop(v_x_2417);
    v_t_2420 = v_y_2418;
  }
  return (g_heff_2elsp_2erender_2eoneLineIn(v_color_240, v_code_241, v_src_242, v_w_244, v_l_245, v_t_247, v_t_2412, v_t_2420));
}
V g_heff_2elsp_2erender_2eoneLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2eoneLine(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2erender_2elinesPrettyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elinesPrettyAt_entry, 6, 0};

V g_heff_2elsp_2erender_2elinesPrettyAt(V v_color_240, V v_code_241, V v_src_242, V v_sp_243, V v_s_244, V v_e_245) {
top: ;
  if (heff_intEq_c(heff_dup(heff_rfield(v_s_244, 0)), heff_dup(heff_rfield(v_e_245, 0)))) {
    heff_drop_rec(v_e_245, 3);
    V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(1LL));
    V v_t_248 = (g_heff_2elsp_2erender_2enumDigits(v_t_247));
    HEFF_LAST return g_heff_2elsp_2erender_2eoneLine(v_color_240, v_code_241, v_src_242, v_sp_243, v_t_248, heff_get_n(v_s_244, 0, 3));
  } else {
    heff_drop(v_sp_243);
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_e_245, 0)), MK_INT(1LL));
    V v_t_2410 = (g_heff_2elsp_2erender_2enumDigits(v_t_249));
    HEFF_LAST return g_heff_2elsp_2erender_2espanLines(v_color_240, v_code_241, v_src_242, v_t_2410, v_s_244, v_e_245);
  }
}
V g_heff_2elsp_2erender_2elinesPrettyAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2elinesPrettyAt(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2elinesPretty_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2elinesPretty_str1, 1, "\012");
Clo g_heff_2elsp_2erender_2elinesPretty_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elinesPretty_entry, 4, 0};

V g_heff_2elsp_2erender_2elinesPretty(V v_color_240, V v_code_241, V v_src_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2elinesPretty_str0), heff_dup(v_src_242), MK_INT(0LL)));
  V v_t_245 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_242), heff_dup(heff_rfield(v_sp_243, 0)), MK_INT(0LL), MK_INT(0LL), v_t_244));
  V v_x_246 = heff_dup(heff_rfield(v_sp_243, 0));
  V v_y_247 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), MK_INT(1LL));
  V v_t_249;
  if (heff_intLe_c(heff_dup(v_x_246), heff_dup(v_y_247))) {
    heff_drop(v_x_246);
    v_t_249 = v_y_247;
  } else {
    heff_drop(v_y_247);
    v_t_249 = v_x_246;
  }
  V v_t_2410 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2elinesPretty_str1), heff_dup(v_src_242), MK_INT(0LL)));
  V v_t_2411 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_242), v_t_249, MK_INT(0LL), MK_INT(0LL), v_t_2410));
  return (g_heff_2elsp_2erender_2elinesPrettyAt(v_color_240, v_code_241, v_src_242, v_sp_243, v_t_245, v_t_2411));
}
V g_heff_2elsp_2erender_2elinesPretty_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2elinesPretty(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str0, 5, "error");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str1, 7, "warning");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str2, 5, "debug");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str3, 1, "E");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str4, 1, "W");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str5, 1, "D");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str6, 1, "0");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str7, 1, "[");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str8, 1, "]");
Clo g_heff_2elsp_2erender_2eprtCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2eprtCode_entry, 1, 0};

V g_heff_2elsp_2erender_2eprtCode(V v_d_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_d_240, 1));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SError: {
    v_t_242 = ((V)&g_heff_2elsp_2erender_2eprtCode_str0);
    break;
  }
  case TAG_SWarning: {
    v_t_242 = ((V)&g_heff_2elsp_2erender_2eprtCode_str1);
    break;
  }
  case TAG_SDebug: {
    v_t_242 = ((V)&g_heff_2elsp_2erender_2eprtCode_str2);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_take_field(v_d_240, 1);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str5);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_240, 0))));
  V v_t_246 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_245), ((V)&g_heff_2elsp_2erender_2eprtCode_str6)));
  V v_t_247 = heff_intShow(heff_get_n(v_d_240, 0, 5));
  V v_t_248 = heff_strAppend(v_t_244, heff_strAppend(v_t_246, v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2erender_2eprtCode_str7), heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2erender_2eprtCode_str8)));
  return heff_strAppend(v_t_242, v_t_249);
}
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2eprtCode(a[0]);
}
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str0, 4, "1;31");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str1, 4, "1;33");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str2, 4, "1;36");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str3, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str4, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str5, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str6, 4, "1;31");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str7, 4, "1;33");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str8, 4, "1;36");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str10, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str11, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2erenderDiag_str12, 2, ": ");
Clo g_heff_2elsp_2erender_2erenderDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2erenderDiag_entry, 3, 0};

V g_heff_2elsp_2erender_2erenderDiag(V v_color_240, V v_src_241, V v_d_242) {
top: ;
  V v_s_243 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_242)));
  V v_t_247;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_244 = heff_dup(heff_rfield(v_d_242, 1));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SError: {
      v_t_245 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str0);
      break;
    }
    case TAG_SWarning: {
      v_t_245 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str1);
      break;
    }
    case TAG_SDebug: {
      v_t_245 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str2);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = heff_strAppend(((V)&g_heff_2elsp_2erender_2erenderDiag_str3), heff_strAppend(v_t_245, ((V)&g_heff_2elsp_2erender_2erenderDiag_str4)));
    v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_s_243, ((V)&g_heff_2elsp_2erender_2erenderDiag_str5)));
  } else {
    v_t_247 = v_s_243;
  }
  V v_t_248 = heff_take_field(v_d_242, 1);
  V v_t_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_SError: {
    v_t_249 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str6);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str7);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str8);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2410 = (g_heff_2elsp_2erender_2elinesPretty(v_color_240, v_t_249, v_src_241, heff_take_field(v_d_242, 3)));
  V v_t_2411 = heff_take_field(v_d_242, 4);
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2elsp_2erender_2erenderDiag_str9);
    break;
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2413 = heff_strAppend(((V)&g_heff_2elsp_2erender_2erenderDiag_str10), v_n_2412);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2414 = heff_strAppend(((V)&g_heff_2elsp_2erender_2erenderDiag_str11), heff_strAppend(v_t_2410, v_t_2413));
  V v_t_2415 = heff_strAppend(heff_get_n(v_d_242, 2, 5), v_t_2414);
  return heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2elsp_2erender_2erenderDiag_str12), v_t_2415));
}
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2erenderDiag(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str2, 1, ":");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str3, 1, ":");
Clo g_heff_2elsp_2erender_2ediagWhere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2ediagWhere_entry, 3, 0};

V g_heff_2elsp_2erender_2ediagWhere(V v_path_240, V v_src_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_d_242, 3)), 0, 2);
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2ediagWhere_str0), heff_dup(v_src_241), MK_INT(0LL)));
  V v_t_245 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_241), v_t_243, MK_INT(0LL), MK_INT(0LL), v_t_244));
  V v_t_246 = heff_intAdd(heff_get_n(v_t_245, 0, 3), MK_INT(1LL));
  V v_t_247 = heff_get_n(heff_get_n(v_d_242, 3, 5), 0, 2);
  V v_t_248 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2erender_2ediagWhere_str1), heff_dup(v_src_241), MK_INT(0LL)));
  V v_t_249 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, v_t_247, MK_INT(0LL), MK_INT(0LL), v_t_248));
  V v_t_2410 = heff_intAdd(heff_get_n(v_t_249, 2, 3), MK_INT(1LL));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2elsp_2erender_2ediagWhere_str2), heff_intShow(v_t_2410));
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_246), v_t_2411);
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2elsp_2erender_2ediagWhere_str3), v_t_2412));
}
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2ediagWhere(a[0], a[1], a[2]);
}