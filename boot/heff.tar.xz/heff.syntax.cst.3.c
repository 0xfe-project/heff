// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EFDefault 38038
#define TAG_EField 26142
#define TAG_ELetMut 54984
#define TAG_ESBind 62182
#define TAG_EWhile 39339
#define TAG_Get 18914
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_blockArg 80527375
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_head 9693863
#define LBL_i 323
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_raw 322210
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_clo;
V g_heff_2esyntax_2ecst_2eappF_24s994352733x211901757(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s994352733x211901757_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s994352733x211901757_clo;
V g_heff_2esyntax_2ecst_2earmF(V, V, V);
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earmF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataLast(V, V, V, V);
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataLast_clo;
HeffT2 g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2eforF(V, V, V);
V g_heff_2esyntax_2ecst_2eforF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eforF_clo;
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eletMutF(V, V, V);
V g_heff_2esyntax_2ecst_2eletMutF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletMutF_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emutualDecl(V, V);
V g_heff_2esyntax_2ecst_2emutualDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emutualDecl_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2estmtF(V, V, V);
V g_heff_2esyntax_2ecst_2estmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estmtF_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etryPartF(V, V, V);
V g_heff_2esyntax_2ecst_2etryPartF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryPartF_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_245, 1)); V rr_ = heff_rec_reuse_nf(v_s_245, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2415, heff_dup(v_col_241)));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242}), v_hd_243, v_k_244));
  } else {
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_t_2416);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2412, v_acc_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V f_ = heff_dup(v_item_240);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Put, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam0, 1, 6, (V[]){heff_dup(v_sep_240), v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_sep_240; V a_1 = v_p_241; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}); V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}); V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2esyntax_2ecst_2esepGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_p_241);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_p_241);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldsGo_str0, 5, "field");
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_EField, 2, (V[]){v_e_240, v_x_247}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2efieldsGo_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str1, 17, "a variable's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str2, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str3, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str4, 1, "=");
V g_heff_2esyntax_2ecst_2eletMutF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletMutF_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletMutF_lam7, 2, 0};
V g_heff_2esyntax_2ecst_2eletMutF_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletMutF_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletMutF_lam8, 2, 0};
V g_heff_2esyntax_2ecst_2eletMutF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletMutF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletMutF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletMutF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletMutF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletMutF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_x_2414})});
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam6, 1, 2, (V[]){v_x_2413, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2411), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam5, 1, 3, (V[]){v_g_240, v_hd_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2eletMutF_lam7(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam8(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam11(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ELetMut, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_2421, v_x_2422, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam10(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam11, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_2421, v_x_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletMutF_str4), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam10, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_2421})));
}
V g_heff_2esyntax_2ecst_2eletMutF_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eletMutF_str2))) {
    if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eletMutF_str3))) {
      v_t_2420 = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam4, 2, 1, (V[]){heff_dup(v_g_240)});
    } else {
      v_t_2420 = ((V)&g_heff_2esyntax_2ecst_2eletMutF_lam7_clo);
    }
  } else {
    heff_drop_rec(v_x_248, 9);
    v_t_2420 = ((V)&g_heff_2esyntax_2ecst_2eletMutF_lam8_clo);
  }
  V f_ = v_t_2420;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam9, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam3, 1, 6, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eletMutF_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2eletMutF_str1); V a_2 = heff_dup(v_hd_241); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eletMutF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etryPartF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2etryPartF_str1, 5, "catch");
V g_heff_2esyntax_2ecst_2etryPartF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2etryPartF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etryPartF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2etryPartF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etryPartF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etryPartF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etryPartF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etryPartF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etryPartF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etryPartF(V v_part_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2etryPartF_lam0, 1, 3, (V[]){v_hd_241, v_part_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2etryPartF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etryPartF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etryPartF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_get_n(v_s_246, 3, 5);
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    return v_x_248;
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2esyntax_2ecst_2etryPartF_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etryPartF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etryPartF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_part_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2etryPartF_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2etryPartF_str1))) {
      V v_t_2415 = heff_take_field(v_x_245, 6);
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        if (heff_intLe_c(v_x_2412, heff_get_n(v_x_245, 5, 9))) {
          V f_ = v_part_240;
          heff_room[0] = v_hd_241;
          heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2etryPartF_lam3, 1, 1, (V[]){v_k_242});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_part_240);
          heff_drop_rec(v_hd_241, 3);
          V f_ = v_k_242;
          args[0] = NTAG(TAG_Nothing);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      } else {
        heff_drop(v_x_2412);
        heff_drop_rec(v_x_245, 9);
        heff_drop(v_t_2415);
        V f_ = v_part_240;
        heff_room[0] = v_hd_241;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2etryPartF_lam4, 1, 1, (V[]){v_k_242});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_x_2412);
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_part_240);
      heff_drop_rec(v_hd_241, 3);
      V f_ = v_k_242;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2412);
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_part_240);
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2etryPartF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_part_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2etryPartF_lam1_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2etryPartF_lam2, 1, 4, (V[]){v_x_245, v_part_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str1, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str3, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str5, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str7, 5, "while");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str8, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str10, 3, "for");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str12, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str13, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str14, 2, "<-");
V g_heff_2esyntax_2ecst_2estmtF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2estmtF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estmtF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2estmtF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2estmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2estmtF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2estmtF_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EWhile, 4, (V[]){v_x_2419, v_x_2420, v_x_2421, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam6, 1, 4, (V[]){v_k_242, v_x_2419, v_x_2420, v_x_2421})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2estmtF_str8), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam5, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2419, v_x_2420})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 13));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam4, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_2419});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estmtF_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam9, 1, 3, (V[]){v_k_242, v_x_2427, v_x_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estmtF_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam8, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam12(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2432, v_x_2433, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam11(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam12, 1, 3, (V[]){v_k_242, v_x_2432, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estmtF_lam10(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam11, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2432})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str0)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str1)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str3))))));
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_t_2414);
    return (g_heff_2esyntax_2ecst_2eletMutF(v_g_240, v_hd_241, v_k_242));
  } else {
    heff_drop(v_t_2414);
    V v_t_2416 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str5))));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 9);
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_t_2416);
      return (g_heff_2esyntax_2ecst_2eletStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      heff_drop(v_t_2416);
      V v_t_2418 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str7))));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_x_245, 9);
        heff_drop(v_t_2418);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam3, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
      } else {
        heff_drop(v_t_2418);
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str9))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estmtF_str10))) {
            heff_drop_rec(v_x_2410, 9);
            heff_drop_rec(v_x_245, 9);
            return (g_heff_2esyntax_2ecst_2eforF(v_g_240, v_hd_241, v_k_242));
          } else {
            if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estmtF_str11))) {
              if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estmtF_str12))) {
                return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam7, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
              } else {
                return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
              }
            } else {
              heff_drop_rec(v_x_2410, 9);
              return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
            }
          }
        } else {
          if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estmtF_str13))) {
            if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estmtF_str14))) {
              return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam10, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
            } else {
              return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
            }
          } else {
            heff_drop_rec(v_x_2410, 9);
            return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2estmtF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2estmtF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam2, 1, 4, (V[]){v_x_245, v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4, 1, 3, (V[]){v_k_241, v_x_242, v_x_249})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6, 1, 3, (V[]){v_k_241, v_x_242, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str1))) {
      heff_drop_rec(v_x_245, 9);
      if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
        heff_drop(v_x_246);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_242;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_246);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str2))) {
        if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
          heff_drop(v_x_246);
          heff_drop_rec(v_hd_240, 3);
          V f_ = v_k_241;
          args[0] = v_x_242;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_246);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
        }
      } else {
        heff_drop(v_x_246);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_242;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  } else {
    heff_drop(v_x_246);
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2, 1, 4, (V[]){v_x_245, v_k_241, v_x_242, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_entry, 13, 0};

V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_hd_2412) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_2412), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam0, 1, 13, (V[]){v_hd_2412, v_lit_249, v_lit_2410, heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, heff_dup(v_lit_243), v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908(a0, a1, a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_lit_249 = heff_env(self)[3];
  V v_lit_2410 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_244 = heff_env(self)[9];
  V v_lit_245 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  V v_lit_247 = heff_env(self)[12];
  V v_lit_248 = heff_env(self)[13];
  V v_lit_2411 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2426, v_x_2427}), NTAG(TAG_Nil)});
  V v_t_2429 = (g_prelude_2e_2b_2b(v_x_2414, v_t_2428));
  V v_x_2430 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_249, v_x_2430}), v_lit_2410});
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_t_2431; V a_10 = v_lit_2411; V r_ = (g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_lit_249 = heff_env(self)[3];
  V v_lit_2410 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_244 = heff_env(self)[9];
  V v_lit_245 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  V v_lit_247 = heff_env(self)[12];
  V v_lit_248 = heff_env(self)[13];
  V v_lit_2411 = heff_env(self)[14];
  heff_clo_take(self, 15);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_2412, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam5, 1, 15, (V[]){v_x_2426, v_x_2414, v_x_2413, v_lit_249, v_lit_2410, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_lit_249 = heff_env(self)[3];
  V v_lit_2410 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_244 = heff_env(self)[9];
  V v_lit_245 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  V v_lit_247 = heff_env(self)[12];
  V v_lit_248 = heff_env(self)[13];
  V v_lit_2411 = heff_env(self)[14];
  V v_hd_2412 = heff_env(self)[15];
  heff_clo_take(self, 16);
  V v_t_2419 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16));
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2417, 0)), ((V)&g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_str0))) {
      if (heff_strEq_c(heff_get_n(v_x_2417, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_str1))) {
        if ((heff_dup(v_x_2418) == NTAG(TAG_True))) {
          heff_drop(v_x_2418);
          heff_drop_rec(v_hd_2412, 3);
          V v_t_2424;
          switch (heff_tag_of(v_x_2414)) {
          case TAG_Nil: {
            v_t_2424 = v_x_2413;
            break;
          }
          case TAG_Cons: {
            v_t_2424 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
            break;
          }
          default: heff_nomatch(v_x_2414);
          }
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_249, v_t_2424}), v_lit_2410});
          return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_t_2425; V a_10 = v_lit_2411; V r_ = (g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
        } else {
          heff_drop(v_x_2418);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2412), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam4, 1, 15, (V[]){v_hd_2412, v_x_2414, v_x_2413, v_lit_249, v_lit_2410, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411})));
        }
      } else {
        heff_drop(v_x_2418);
        heff_drop_rec(v_hd_2412, 3);
        V v_t_2434;
        switch (heff_tag_of(v_x_2414)) {
        case TAG_Nil: {
          v_t_2434 = v_x_2413;
          break;
        }
        case TAG_Cons: {
          v_t_2434 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
          break;
        }
        default: heff_nomatch(v_x_2414);
        }
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_249, v_t_2434}), v_lit_2410});
        return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_t_2435; V a_10 = v_lit_2411; V r_ = (g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
      }
    } else {
      heff_drop(v_x_2418);
      heff_drop_rec(v_x_2417, 9);
      heff_drop_rec(v_hd_2412, 3);
      V v_t_2438;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_Nil: {
        v_t_2438 = v_x_2413;
        break;
      }
      case TAG_Cons: {
        v_t_2438 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_249, v_t_2438}), v_lit_2410});
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_t_2439; V a_10 = v_lit_2411; V r_ = (g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
    }
  } else {
    heff_drop(v_x_2418);
    heff_drop_rec(v_x_2417, 9);
    heff_drop_rec(v_hd_2412, 3);
    heff_drop(v_t_2419);
    V v_t_2442;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Nil: {
      v_t_2442 = v_x_2413;
      break;
    }
    case TAG_Cons: {
      v_t_2442 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_249, v_t_2442}), v_lit_2410});
    return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_t_2443; V a_10 = v_lit_2411; V r_ = (g_heff_2esyntax_2ecst_2eoperandsF_24s594297444x1889531530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_lit_249 = heff_env(self)[3];
  V v_lit_2410 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_244 = heff_env(self)[9];
  V v_lit_245 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  V v_lit_247 = heff_env(self)[12];
  V v_lit_248 = heff_env(self)[13];
  V v_lit_2411 = heff_env(self)[14];
  heff_clo_take(self, 15);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_2412), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam3, 1, 16, (V[]){v_x_2417, v_x_2414, v_x_2413, v_lit_249, v_lit_2410, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411, v_hd_2412})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_lit_249 = heff_env(self)[2];
  V v_lit_2410 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_244 = heff_env(self)[8];
  V v_lit_245 = heff_env(self)[9];
  V v_lit_246 = heff_env(self)[10];
  V v_lit_247 = heff_env(self)[11];
  V v_lit_248 = heff_env(self)[12];
  V v_lit_2411 = heff_env(self)[13];
  heff_clo_take(self, 14);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam2, 1, 15, (V[]){v_hd_2412, v_x_2414, v_x_2413, v_lit_249, v_lit_2410, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_lit_249 = heff_env(self)[1];
  V v_lit_2410 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_244 = heff_env(self)[7];
  V v_lit_245 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  V v_lit_247 = heff_env(self)[10];
  V v_lit_248 = heff_env(self)[11];
  V v_lit_2411 = heff_env(self)[12];
  heff_clo_take(self, 13);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_2412), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1424584060x1274329908_lam1, 1, 14, (V[]){v_hd_2412, v_x_2413, v_lit_249, v_lit_2410, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_2411})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str1))) {
      if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_2410);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2410);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(v_x_244));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_entry, 11, 0};

V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_acc_249, V v_hd_2410) {
top: ;
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2410, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam0, 1, 11, (V[]){v_hd_2410, v_acc_249, heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, heff_dup(v_lit_243), v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006(a0, a1, a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_acc_249 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_lit_247 = heff_env(self)[9];
  V v_lit_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2432, v_x_2437}), v_acc_249});
  V v_x_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2438));
  V v_t_2442;
  if (heff_strEq_c_lent(v_lit_240, v_lit_241, 2)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    v_t_2442 = v_lit_242;
  } else {
    heff_drop(v_lit_242);
    if (heff_strEq_c(v_lit_240, v_lit_243)) {
      heff_drop(v_lit_245);
      v_t_2442 = v_lit_244;
    } else {
      heff_drop(v_lit_244);
      v_t_2442 = v_lit_245;
    }
  }
  V v_t_2445;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Nil: {
    v_t_2445 = v_lit_246;
    break;
  }
  case TAG_Cons: {
    v_t_2445 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_246, v_x_2439});
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2442, v_t_2445, v_lit_247, v_lit_248));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_acc_249 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_lit_247 = heff_env(self)[9];
  V v_lit_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2432, v_x_2451}), v_acc_249});
  V v_x_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2452));
  V v_t_2456;
  if (heff_strEq_c_lent(v_lit_240, v_lit_241, 2)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    v_t_2456 = v_lit_242;
  } else {
    heff_drop(v_lit_242);
    if (heff_strEq_c(v_lit_240, v_lit_243)) {
      heff_drop(v_lit_245);
      v_t_2456 = v_lit_244;
    } else {
      heff_drop(v_lit_244);
      v_t_2456 = v_lit_245;
    }
  }
  V v_t_2459;
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Nil: {
    v_t_2459 = v_lit_246;
    break;
  }
  case TAG_Cons: {
    v_t_2459 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_246, v_x_2453});
    break;
  }
  default: heff_nomatch(v_x_2453);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2456, v_t_2459, v_lit_247, v_lit_248));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_acc_249 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_244 = heff_env(self)[7];
  V v_lit_245 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  V v_lit_247 = heff_env(self)[10];
  V v_lit_248 = heff_env(self)[11];
  heff_clo_take(self, 12);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2435, 1)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str1))) {
    heff_drop_rec(v_x_2435, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam4, 1, 11, (V[]){v_x_2432, v_acc_249, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2435, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str2))) {
      V v_t_2447 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2435, 1, 9)}));
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str3), NTAG(TAG_Nil)});
      V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str5), v_t_2448})});
      V v_t_2450 = ({ V a_0 = v_t_2447; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str6), v_t_2449}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
        heff_drop(v_t_2450);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam5, 1, 11, (V[]){v_x_2432, v_acc_249, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248})));
      } else {
        heff_drop(v_t_2450);
        return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_x_2432; V a_10 = v_acc_249; V a_11 = heff_dup(v_hd_2410); V a_12 = v_hd_2410; V r_ = (g_heff_2esyntax_2ecst_2eappF_24s994352733x211901757(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
      }
    } else {
      heff_drop_rec(v_x_2435, 9);
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_lit_248; V a_9 = v_x_2432; V a_10 = v_acc_249; V a_11 = heff_dup(v_hd_2410); V a_12 = v_hd_2410; V r_ = (g_heff_2esyntax_2ecst_2eappF_24s994352733x211901757(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_acc_249 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_lit_247 = heff_env(self)[9];
  V v_lit_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2433}));
  V f_ = heff_dup(heff_rfield(v_hd_2410, 1));
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam3, 1, 12, (V[]){v_hd_2410, v_x_2432, v_acc_249, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_249 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_lit_247 = heff_env(self)[9];
  V v_lit_248 = heff_env(self)[10];
  V v_hd_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_str0))) {
    V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2413, 1, 9)}));
    V v_x1_2417 = ({ V a_0 = v_t_2416; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2417) == NTAG(TAG_True))) {
      heff_drop(v_x_2414);
      heff_drop_rec(v_hd_2410, 3);
      heff_drop(v_x1_2417);
      V v_x_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_249));
      V v_t_2421;
      if (heff_strEq_c_lent(v_lit_240, v_lit_241, 2)) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        v_t_2421 = v_lit_242;
      } else {
        heff_drop(v_lit_242);
        if (heff_strEq_c(v_lit_240, v_lit_243)) {
          heff_drop(v_lit_245);
          v_t_2421 = v_lit_244;
        } else {
          heff_drop(v_lit_244);
          v_t_2421 = v_lit_245;
        }
      }
      V v_t_2424;
      switch (heff_tag_of(v_x_2418)) {
      case TAG_Nil: {
        v_t_2424 = v_lit_246;
        break;
      }
      case TAG_Cons: {
        v_t_2424 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_246, v_x_2418});
        break;
      }
      default: heff_nomatch(v_x_2418);
      }
      return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2421, v_t_2424, v_lit_247, v_lit_248));
    } else {
      heff_drop(v_x1_2417);
      if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
        heff_drop(v_x_2414);
        heff_drop_rec(v_hd_2410, 3);
        V v_x_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_249));
        V v_t_2428;
        if (heff_strEq_c_lent(v_lit_240, v_lit_241, 2)) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_243);
          heff_drop(v_lit_244);
          heff_drop(v_lit_245);
          v_t_2428 = v_lit_242;
        } else {
          heff_drop(v_lit_242);
          if (heff_strEq_c(v_lit_240, v_lit_243)) {
            heff_drop(v_lit_245);
            v_t_2428 = v_lit_244;
          } else {
            heff_drop(v_lit_244);
            v_t_2428 = v_lit_245;
          }
        }
        V v_t_2431;
        switch (heff_tag_of(v_x_2425)) {
        case TAG_Nil: {
          v_t_2431 = v_lit_246;
          break;
        }
        case TAG_Cons: {
          v_t_2431 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_246, v_x_2425});
          break;
        }
        default: heff_nomatch(v_x_2425);
        }
        return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2428, v_t_2431, v_lit_247, v_lit_248));
      } else {
        heff_drop(v_x_2414);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2410), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam2, 1, 11, (V[]){v_hd_2410, v_acc_249, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248})));
      }
    }
  } else {
    heff_drop(v_x_2414);
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_hd_2410, 3);
    V v_x_2460 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_249));
    V v_t_2463;
    if (heff_strEq_c_lent(v_lit_240, v_lit_241, 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      v_t_2463 = v_lit_242;
    } else {
      heff_drop(v_lit_242);
      if (heff_strEq_c(v_lit_240, v_lit_243)) {
        heff_drop(v_lit_245);
        v_t_2463 = v_lit_244;
      } else {
        heff_drop(v_lit_244);
        v_t_2463 = v_lit_245;
      }
    }
    V v_t_2466;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_Nil: {
      v_t_2466 = v_lit_246;
      break;
    }
    case TAG_Cons: {
      v_t_2466 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_246, v_x_2460});
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2463, v_t_2466, v_lit_247, v_lit_248));
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_acc_249 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_lit_247 = heff_env(self)[9];
  V v_lit_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_2410), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s591390973x103325006_lam1, 1, 12, (V[]){v_x_2413, v_acc_249, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_hd_2410})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry, 7, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_hd_246) {
top: ;
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sep_2414 = heff_env(self)[0];
  V v_items_2415 = heff_env(self)[1];
  V v_seps_2416 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2414, v_items_2415, v_x_2423, v_seps_2416, heff_dup(v_hd_2417), v_k_2418, v_hd_2417));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_sep_2414 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_items_2415 = heff_env(self)[2];
  V v_seps_2416 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2421, 1, 9), heff_dup(v_sep_2414))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4, 1, 5, (V[]){v_sep_2414, v_items_2415, v_seps_2416, v_hd_2417, v_k_2418})));
  } else {
    heff_drop(v_sep_2414);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2415));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2416));
    V v_x_2426 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2424, v_t_2425});
    V f_ = v_k_2418;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sep_2429 = heff_env(self)[0];
  V v_items_2430 = heff_env(self)[1];
  V v_seps_2431 = heff_env(self)[2];
  V v_hd_2432 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2429, v_items_2430, v_x_2438, v_seps_2431, heff_dup(v_hd_2432), v_k_2433, v_hd_2432));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sep_2429 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_items_2430 = heff_env(self)[2];
  V v_seps_2431 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2436, 1, 9), heff_dup(v_sep_2429))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2432), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8, 1, 5, (V[]){v_sep_2429, v_items_2430, v_seps_2431, v_hd_2432, v_k_2433})));
  } else {
    heff_drop(v_sep_2429);
    heff_drop_rec(v_hd_2432, 3);
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2430));
    V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2431));
    V v_x_2441 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2439, v_t_2440});
    V f_ = v_k_2433;
    args[0] = v_x_2441;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2429 = v_lit_240;
  V v_items_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2427, v_x_2428}), v_lit_241});
  V v_seps_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2432 = v_lit_244;
  V v_k_2433 = v_lit_245;
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2432, 2)), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(heff_rfield(v_hd_2432, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7, 1, 5, (V[]){v_sep_2429, v_hd_2432, v_items_2430, v_seps_2431, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2427, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_sep_2443 = heff_env(self)[0];
  V v_items_2444 = heff_env(self)[1];
  V v_seps_2445 = heff_env(self)[2];
  V v_hd_2446 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2443, v_items_2444, v_x_2452, v_seps_2445, heff_dup(v_hd_2446), v_k_2447, v_hd_2446));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_sep_2443 = heff_env(self)[0];
  V v_hd_2446 = heff_env(self)[1];
  V v_items_2444 = heff_env(self)[2];
  V v_seps_2445 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2450, 1, 9), heff_dup(v_sep_2443))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2446), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10, 1, 5, (V[]){v_sep_2443, v_items_2444, v_seps_2445, v_hd_2446, v_k_2447})));
  } else {
    heff_drop(v_sep_2443);
    heff_drop_rec(v_hd_2446, 3);
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2444));
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2445));
    V v_x_2455 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2453, v_t_2454});
    V f_ = v_k_2447;
    args[0] = v_x_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam14(V self, V *args) {
  V v_x_2467 = args[0];
  V v_sep_2458 = heff_env(self)[0];
  V v_items_2459 = heff_env(self)[1];
  V v_seps_2460 = heff_env(self)[2];
  V v_hd_2461 = heff_env(self)[3];
  V v_k_2462 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2458, v_items_2459, v_x_2467, v_seps_2460, heff_dup(v_hd_2461), v_k_2462, v_hd_2461));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam13(V self, V *args) {
  V v_x_2465 = args[0];
  V v_sep_2458 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_items_2459 = heff_env(self)[2];
  V v_seps_2460 = heff_env(self)[3];
  V v_k_2462 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2465, 1, 9), heff_dup(v_sep_2458))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2461), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam14, 1, 5, (V[]){v_sep_2458, v_items_2459, v_seps_2460, v_hd_2461, v_k_2462})));
  } else {
    heff_drop(v_sep_2458);
    heff_drop_rec(v_hd_2461, 3);
    V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2459));
    V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2460));
    V v_x_2470 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2468, v_t_2469});
    V f_ = v_k_2462;
    args[0] = v_x_2470;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2456 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2458 = v_lit_240;
  V v_items_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2456, v_x_2457}), v_lit_241});
  V v_seps_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2461 = v_lit_244;
  V v_k_2462 = v_lit_245;
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2461, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_hd_2461, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam13, 1, 5, (V[]){v_sep_2458, v_hd_2461, v_items_2459, v_seps_2460, v_k_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2456, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam16(V self, V *args) {
  V v_x_2480 = args[0];
  V v_sep_2471 = heff_env(self)[0];
  V v_items_2472 = heff_env(self)[1];
  V v_seps_2473 = heff_env(self)[2];
  V v_hd_2474 = heff_env(self)[3];
  V v_k_2475 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2471, v_items_2472, v_x_2480, v_seps_2473, heff_dup(v_hd_2474), v_k_2475, v_hd_2474));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam15(V self, V *args) {
  V v_x_2478 = args[0];
  V v_sep_2471 = heff_env(self)[0];
  V v_hd_2474 = heff_env(self)[1];
  V v_items_2472 = heff_env(self)[2];
  V v_seps_2473 = heff_env(self)[3];
  V v_k_2475 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2478, 1, 9), heff_dup(v_sep_2471))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2474), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam16, 1, 5, (V[]){v_sep_2471, v_items_2472, v_seps_2473, v_hd_2474, v_k_2475})));
  } else {
    heff_drop(v_sep_2471);
    heff_drop_rec(v_hd_2474, 3);
    V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2472));
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2473));
    V v_x_2483 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2481, v_t_2482});
    V f_ = v_k_2475;
    args[0] = v_x_2483;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam18(V self, V *args) {
  V v_x_2493 = args[0];
  V v_sep_2484 = heff_env(self)[0];
  V v_items_2485 = heff_env(self)[1];
  V v_seps_2486 = heff_env(self)[2];
  V v_hd_2487 = heff_env(self)[3];
  V v_k_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2484, v_items_2485, v_x_2493, v_seps_2486, heff_dup(v_hd_2487), v_k_2488, v_hd_2487));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam17(V self, V *args) {
  V v_x_2491 = args[0];
  V v_sep_2484 = heff_env(self)[0];
  V v_hd_2487 = heff_env(self)[1];
  V v_items_2485 = heff_env(self)[2];
  V v_seps_2486 = heff_env(self)[3];
  V v_k_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2491, 1, 9), heff_dup(v_sep_2484))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2487), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam18, 1, 5, (V[]){v_sep_2484, v_items_2485, v_seps_2486, v_hd_2487, v_k_2488})));
  } else {
    heff_drop(v_sep_2484);
    heff_drop_rec(v_hd_2487, 3);
    V v_t_2494 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2485));
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2486));
    V v_x_2496 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2494, v_t_2495});
    V f_ = v_k_2488;
    args[0] = v_x_2496;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1))) {
      heff_drop_rec(v_x_2410, 9);
      if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_246, 3);
        V v_sep_2414 = v_lit_240;
        V v_items_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
        V v_seps_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
        V v_hd_2417 = v_lit_244;
        V v_k_2418 = v_lit_245;
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
        V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2419}));
        V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
        heff_room[0] = v_t_2420;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3, 1, 5, (V[]){v_sep_2414, v_hd_2417, v_items_2415, v_seps_2416, v_k_2418});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2411);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2))) {
        if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
          heff_drop(v_x_2411);
          heff_drop_rec(v_hd_246, 3);
          V v_sep_2443 = v_lit_240;
          V v_items_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
          V v_seps_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
          V v_hd_2446 = v_lit_244;
          V v_k_2447 = v_lit_245;
          V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
          V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2448}));
          V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
          heff_room[0] = v_t_2449;
          heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9, 1, 5, (V[]){v_sep_2443, v_hd_2446, v_items_2444, v_seps_2445, v_k_2447});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_x_2411);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
        }
      } else {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_246, 3);
        V v_sep_2471 = v_lit_240;
        V v_items_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
        V v_seps_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
        V v_hd_2474 = v_lit_244;
        V v_k_2475 = v_lit_245;
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
        V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2474, 2)), 1, (V[]){v_t_2476}));
        V f_ = heff_dup(heff_rfield(v_hd_2474, 1));
        heff_room[0] = v_t_2477;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam15, 1, 5, (V[]){v_sep_2471, v_hd_2474, v_items_2472, v_seps_2473, v_k_2475});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_246, 3);
    V v_sep_2484 = v_lit_240;
    V v_items_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
    V v_seps_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
    V v_hd_2487 = v_lit_244;
    V v_k_2488 = v_lit_245;
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2487, 2)), 1, (V[]){v_t_2489}));
    V f_ = heff_dup(heff_rfield(v_hd_2487, 1));
    heff_room[0] = v_t_2490;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam17, 1, 5, (V[]){v_sep_2484, v_hd_2487, v_items_2485, v_seps_2486, v_k_2488});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2, 1, 9, (V[]){v_x_2410, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_hd_246})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str6, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str9, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2415, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0))) {
      v_t_248 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1);
    } else {
      V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2));
      v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3), v_t_247);
    }
    V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4), v_t_248), v_t_249, NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_245);
    V v_x1_2413 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244)));
    if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
      heff_drop(v_x1_2413);
      V v_c_2414 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244));
      V f_ = v_c_2414;
      heff_room[0] = heff_dup(v_hd_240);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2413);
      V v_t_2418;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str5))) {
        v_t_2418 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str6);
      } else {
        V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str7));
        v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str8), v_t_2417);
      }
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str9), v_t_2418), v_t_2419, NTAG(TAG_Nothing)});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2422;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str2, 58, "an instance is declared at the top level, not in a `where`");
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_st_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str1))) {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_call(heff_take_field(v_st_240, 2), 1, (V[]){v_t_249}));
      V f_ = heff_get_n(v_st_240, 1, 3);
      heff_room[0] = v_t_2410;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
    }
  } else {
    return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_244, 1)); V rr_ = heff_rec_reuse_nf(v_s_244, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    return (g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_t_2415);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2esyntax_2ecst_2emutualDecl(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str2, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str3, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str4, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str5, 4, "type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str6, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str7, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str8, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str9, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str10, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str11, 3, "con");

HeffT2 g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr(V v_t_240, V v_u_241) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str0))) {
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str1), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str3), v_t_244})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str5), v_t_245})});
    v_t_247 = ({ V a_0 = v_t_243; V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_246, 2); r_; });
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_247);
    V v_f_248 = heff_get_n(v_u_241, 1, 9);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  } else {
    heff_drop(v_t_247);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str6))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str7))) {
        heff_drop_rec(v_t_240, 9);
        V v_f_2411 = heff_get_n(v_u_241, 1, 9);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      } else {
        heff_drop_rec(v_u_241, 9);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str8))) {
          V v_f_2413 = heff_get_n(v_t_240, 1, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str9))) {
            V v_f_2415 = heff_get_n(v_t_240, 1, 9);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
          } else {
            heff_drop_rec(v_t_240, 9);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    } else {
      heff_drop_rec(v_u_241, 9);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str10))) {
        V v_f_2417 = heff_get_n(v_t_240, 1, 9);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str11))) {
          V v_f_2419 = heff_get_n(v_t_240, 1, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
        } else {
          heff_drop_rec(v_t_240, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_n_244)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str0), ((V)&g_heff_2esyntax_2ecst_2efirstD_str1), ((V)&g_heff_2esyntax_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_n_244, 0);
      return heff_dup(v_x_247);
    }
    default: return heff_nomatch(v_n_244);
    }
  }
  case TAG_DInstance: {
    V v_kw_249 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_249);
  }
  case TAG_DEqn: {
    V v_n_2413 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_n_2413)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str3), ((V)&g_heff_2esyntax_2ecst_2efirstD_str4), ((V)&g_heff_2esyntax_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_n_2413, 0);
      return heff_dup(v_x_2418);
    }
    default: return heff_nomatch(v_n_2413);
    }
  }
  case TAG_DData: {
    V v_kw_2420 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2420);
  }
  case TAG_DType: {
    V v_kw_2425 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2425);
  }
  case TAG_DTheory: {
    V v_kw_2430 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2430);
  }
  case TAG_DMutual: {
    V v_kw_2435 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2435);
  }
  case TAG_DPrimitive: {
    V v_kw_2437 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2437);
  }
  case TAG_DTest: {
    V v_kw_2441 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2441);
  }
  case TAG_DWatch: {
    V v_w_2443 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2443);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstD(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      return v_kw_242;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      heff_drop(v_kw_242);
      return v_x_245;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_DSig: {
    V v_ty_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_249);
  }
  case TAG_DInstance: {
    V v_ty_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2413);
  }
  case TAG_DEqn: {
    V v_rhs_2417 = heff_field(v_x1_240, 3);
    V v_x15_2418 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_x15_2418)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_rhs_2417);
    }
    case TAG_Just: {
      V v_x151_2419 = heff_field(v_x15_2418, 0);
      heff_take_n(v_x15_2418, 1ULL, 1);
      heff_drop(v_rhs_2417);
      switch (heff_tag_of(v_x151_2419)) {
      case TAG_MkPair: {
        V v_kw_2420 = heff_field(v_x151_2419, 0);
        V v_ds_2421 = heff_field(v_x151_2419, 1);
        heff_take_n(v_x151_2419, 3ULL, 2);
        V v_x1_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2421));
        switch (heff_tag_of(v_x1_2422)) {
        case TAG_Nil: {
          return v_kw_2420;
        }
        case TAG_Cons: {
          V v_x_2423 = heff_field(v_x1_2422, 0);
          heff_take_n(v_x1_2422, 1ULL, 2);
          heff_drop(v_kw_2420);
          V t_0 = v_x_2423;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2422);
        }
      }
      default: return heff_nomatch(v_x151_2419);
      }
    }
    default: return heff_nomatch(v_x15_2418);
    }
  }
  case TAG_DData: {
    V v_name_2426 = heff_field(v_x1_240, 1);
    V v_params_2427 = heff_field(v_x1_240, 2);
    V v_universe_2428 = heff_field(v_x1_240, 3);
    V v_alts_2429 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    return ({ V a_0 = v_name_2426; V a_1 = v_params_2427; V a_2 = v_universe_2428; V a_3 = v_alts_2429; V r_ = (g_heff_2esyntax_2ecst_2edataLast(a_0, a_1, a_2, a_3)); heff_drop(v_universe_2428); heff_drop(v_alts_2429); r_; });
  }
  case TAG_DType: {
    V v_body_2434 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_body_2434);
  }
  case TAG_DTheory: {
    V v_w_2438 = heff_field(v_x1_240, 3);
    V v_fields_2439 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2439));
    switch (heff_tag_of(v_x1_2440)) {
    case TAG_Nil: {
      return v_w_2438;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x1_2440, 0);
      heff_take_n(v_x1_2440, 1ULL, 2);
      heff_drop(v_w_2438);
      switch (heff_tag_of(v_x_2441)) {
      case TAG_MkTF: {
        V v_ty_2445 = heff_field(v_x_2441, 2);
        V v_x14_2446 = heff_field(v_x_2441, 3);
        heff_take_n(v_x_2441, 12ULL, 4);
        switch (heff_tag_of(v_x14_2446)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2445);
        }
        case TAG_Just: {
          V v_x141_2447 = heff_field(v_x14_2446, 0);
          heff_take_n(v_x14_2446, 1ULL, 1);
          heff_drop(v_ty_2445);
          switch (heff_tag_of(v_x141_2447)) {
          case TAG_MkPair: {
            V v_d_2449 = heff_field(v_x141_2447, 1);
            heff_take_n(v_x141_2447, 2ULL, 2);
            HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_d_2449);
          }
          default: return heff_nomatch(v_x141_2447);
          }
        }
        default: return heff_nomatch(v_x14_2446);
        }
      }
      default: return heff_nomatch(v_x_2441);
      }
    }
    default: return heff_nomatch(v_x1_2440);
    }
  }
  case TAG_DMutual: {
    V v_kw_2450 = heff_field(v_x1_240, 0);
    V v_ds_2451 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2451));
    switch (heff_tag_of(v_x1_2452)) {
    case TAG_Nil: {
      return v_kw_2450;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x1_2452, 0);
      heff_take_n(v_x1_2452, 1ULL, 2);
      heff_drop(v_kw_2450);
      V t_0 = v_x_2453;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2452);
    }
  }
  case TAG_DPrimitive: {
    V v_ty_2458 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2458);
  }
  case TAG_DTest: {
    V v_x_2460 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2460;
  }
  case TAG_DWatch: {
    V v_e_2462 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_e_2462);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastD(a[0]);
}