// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_EFDefault 38038
#define TAG_EField 26142
#define TAG_Get 18914
#define TAG_Left 13886
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_raw 322210
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataLast(V, V, V, V);
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataLast_clo;
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
HeffT2 g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_245, 1)); V rr_ = heff_rec_reuse_nf(v_s_245, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2415, heff_dup(v_col_241)));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242}), v_hd_243, v_k_244));
  } else {
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_t_2416);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2412, v_acc_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V f_ = heff_dup(v_item_240);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Put, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam0, 1, 6, (V[]){v_sep_240, v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2esepGo(v_sep_240, v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}), v_hd_244, v_k_245));
}
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_p_241);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_p_241);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldsGo_str0, 5, "field");
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_EField, 2, (V[]){v_e_240, v_x_247}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2efieldsGo_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry, 7, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_hd_246) {
top: ;
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_sep_2418 = heff_env(self)[0];
  V v_items_2419 = heff_env(self)[1];
  V v_seps_2420 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2418, v_items_2419, v_x_2427, v_seps_2420, heff_dup(v_hd_2421), v_k_2422, v_hd_2421));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_sep_2418 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_items_2419 = heff_env(self)[2];
  V v_seps_2420 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2425, 1, 9), heff_dup(v_sep_2418))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2421), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6, 1, 5, (V[]){v_sep_2418, v_items_2419, v_seps_2420, v_hd_2421, v_k_2422})));
  } else {
    heff_drop(v_sep_2418);
    heff_drop_rec(v_hd_2421, 3);
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2420));
    V v_x_2430 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2428, v_t_2429});
    V f_ = v_k_2422;
    args[0] = v_x_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2418 = v_lit_240;
  V v_items_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2416, v_x_2417}), v_lit_241});
  V v_seps_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2421 = v_lit_244;
  V v_k_2422 = v_lit_245;
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2421, 2)), 1, (V[]){v_t_2423}));
  V f_ = heff_dup(heff_rfield(v_hd_2421, 1));
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5, 1, 5, (V[]){v_sep_2418, v_hd_2421, v_items_2419, v_seps_2420, v_k_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2416, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sep_2431 = heff_env(self)[0];
  V v_items_2432 = heff_env(self)[1];
  V v_seps_2433 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2431, v_items_2432, v_x_2440, v_seps_2433, heff_dup(v_hd_2434), v_k_2435, v_hd_2434));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sep_2431 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_items_2432 = heff_env(self)[2];
  V v_seps_2433 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2438, 1, 9), heff_dup(v_sep_2431))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2434), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8, 1, 5, (V[]){v_sep_2431, v_items_2432, v_seps_2433, v_hd_2434, v_k_2435})));
  } else {
    heff_drop(v_sep_2431);
    heff_drop_rec(v_hd_2434, 3);
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2432));
    V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2433));
    V v_x_2443 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2441, v_t_2442});
    V f_ = v_k_2435;
    args[0] = v_x_2443;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args) {
  V v_x_2453 = args[0];
  V v_sep_2444 = heff_env(self)[0];
  V v_items_2445 = heff_env(self)[1];
  V v_seps_2446 = heff_env(self)[2];
  V v_hd_2447 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2444, v_items_2445, v_x_2453, v_seps_2446, heff_dup(v_hd_2447), v_k_2448, v_hd_2447));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args) {
  V v_x_2451 = args[0];
  V v_sep_2444 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_items_2445 = heff_env(self)[2];
  V v_seps_2446 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2451, 1, 9), heff_dup(v_sep_2444))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2447), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10, 1, 5, (V[]){v_sep_2444, v_items_2445, v_seps_2446, v_hd_2447, v_k_2448})));
  } else {
    heff_drop(v_sep_2444);
    heff_drop_rec(v_hd_2447, 3);
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2445));
    V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2446));
    V v_x_2456 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2454, v_t_2455});
    V f_ = v_k_2448;
    args[0] = v_x_2456;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_244 = heff_env(self)[7];
  V v_lit_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0))) {
    V v_t_2415 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1)) ? !(heff_dup(v_x_2411) == NTAG(TAG_True)) : (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2)) && !(heff_dup(v_x_2411) == NTAG(TAG_True)))));
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
    } else {
      heff_drop_rec(v_hd_246, 3);
      heff_drop(v_t_2415);
      V v_sep_2431 = v_lit_240;
      V v_items_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
      V v_seps_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
      V v_hd_2434 = v_lit_244;
      V v_k_2435 = v_lit_245;
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
      V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){v_t_2436}));
      V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
      heff_room[0] = v_t_2437;
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7, 1, 5, (V[]){v_sep_2431, v_hd_2434, v_items_2432, v_seps_2433, v_k_2435});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_246, 3);
    V v_sep_2444 = v_lit_240;
    V v_items_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
    V v_seps_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
    V v_hd_2447 = v_lit_244;
    V v_k_2448 = v_lit_245;
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2447, 2)), 1, (V[]){v_t_2449}));
    V f_ = heff_dup(heff_rfield(v_hd_2447, 1));
    heff_room[0] = v_t_2450;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9, 1, 5, (V[]){v_sep_2444, v_hd_2447, v_items_2445, v_seps_2446, v_k_2448});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2, 1, 9, (V[]){v_x_2410, v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2416, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_bool(((heff_dup(v_x_245) == NTAG(TAG_True)) || ({ V v_x1_246 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244))); int c_ = !(heff_dup(v_x1_246) == NTAG(TAG_True)); heff_drop(v_x1_246); c_; })));
  heff_drop(v_x_245);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0))) {
      v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1);
    } else {
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2));
      v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3), v_t_249);
    }
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4), v_t_2410), v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_247);
    V v_c_2415 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str2, 58, "an instance is declared at the top level, not in a `where`");
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_st_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str1))) {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_call(heff_take_field(v_st_240, 2), 1, (V[]){v_t_249}));
      V f_ = heff_get_n(v_st_240, 1, 3);
      heff_room[0] = v_t_2410;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
    }
  } else {
    return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str2, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str3, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str4, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str5, 4, "type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str6, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str7, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str8, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str9, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str10, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str11, 3, "con");

HeffT2 g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr(V v_t_240, V v_u_241) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str0))) {
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str1), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str3), v_t_244})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str5), v_t_245})});
    v_t_247 = ({ V a_0 = v_t_243; V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_246, 2); r_; });
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_247);
    V v_f_248 = heff_get_n(v_u_241, 1, 9);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  } else {
    heff_drop(v_t_247);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str6))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str7))) {
        heff_drop_rec(v_t_240, 9);
        V v_f_2411 = heff_get_n(v_u_241, 1, 9);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      } else {
        heff_drop_rec(v_u_241, 9);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str8))) {
          V v_f_2413 = heff_get_n(v_t_240, 1, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str9))) {
            V v_f_2415 = heff_get_n(v_t_240, 1, 9);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
          } else {
            heff_drop_rec(v_t_240, 9);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    } else {
      heff_drop_rec(v_u_241, 9);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str10))) {
        V v_f_2417 = heff_get_n(v_t_240, 1, 9);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_24cpr_str11))) {
          V v_f_2419 = heff_get_n(v_t_240, 1, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
        } else {
          heff_drop_rec(v_t_240, 9);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str2, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str3, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str6, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str7, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str9, 35, "the file does not parse (at offset ");
Clo g_heff_2esyntax_2ecst_2eprogramGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprogramGo_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eprogramGo(V v_s_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_243 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 1)), v_t_242, heff_dup(heff_rfield(v_s_240, 1))});
  V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(v_t_243, heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_244, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str0))) {
    heff_drop_rec(v_s_240, 5);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_246});
  } else {
    V v_it_247 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_s_240));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_s2_249 = heff_field(v_it_247, 1);
      V v_ru_24it_247_24MkPair = heff_take_reuse_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_Left: {
        V v_d_2410 = heff_field(v_it1_248, 0);
        V v_ru_24it1_248_24Left = heff_take_reuse_n(v_it1_248, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop_rec(v_s2_249, 5);
        heff_drop_cell(v_ru_24it_247_24MkPair, 2);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_d_2410, 3)), 0, 2);
        V v_t_2412 = heff_strAppend(heff_get_n(v_d_2410, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str1));
        V v_t_2413 = heff_strAppend(heff_intShow(v_t_2411), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str2), v_t_2412));
        return heff_tag_at_n(v_ru_24it1_248_24Left, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str3), v_t_2413)});
      }
      case TAG_Right: {
        V v_d_2414 = heff_field(v_it1_248, 0);
        V v_ru_24it1_248_24Right = heff_take_reuse_n(v_it1_248, 1ULL, 1);
        V v_t_2415 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_dup(heff_rfield(v_s2_249, 1))));
        if (heff_strEq_c(heff_get_n(v_t_2415, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str4))) {
          heff_drop_cell(v_ru_24it1_248_24Right, 1);
          V t_0 = v_s2_249;
          V t_1 = heff_tag_at_n(v_ru_24it_247_24MkPair, TAG_Cons, 2, (V[]){v_d_2414, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_247_24MkPair, 2);
          heff_drop(v_d_2414);
          V v_t_2417 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_dup(heff_rfield(v_s2_249, 1))));
          V v_t_2418 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_get_n(v_s2_249, 1, 5)));
          V v_t_2419 = heff_strAppend(heff_get_n(v_t_2418, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str5));
          V v_msg_2420 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str6), v_t_2419);
          V v_t_2421 = heff_intShow(heff_get_n(v_t_2417, 3, 9));
          V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str7), heff_strAppend(v_msg_2420, ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str8)));
          V v_t_2423 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str9), heff_strAppend(v_t_2421, v_t_2422));
          return heff_tag_at_n(v_ru_24it1_248_24Right, TAG_Left, 1, (V[]){v_t_2423});
        }
      }
      default: return heff_nomatch(v_it1_248);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
}
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprogramGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_n_244)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str0), ((V)&g_heff_2esyntax_2ecst_2efirstD_str1), ((V)&g_heff_2esyntax_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_n_244, 0);
      return heff_dup(v_x_247);
    }
    default: return heff_nomatch(v_n_244);
    }
  }
  case TAG_DInstance: {
    V v_kw_249 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_249);
  }
  case TAG_DEqn: {
    V v_n_2413 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_n_2413)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str3), ((V)&g_heff_2esyntax_2ecst_2efirstD_str4), ((V)&g_heff_2esyntax_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_n_2413, 0);
      return heff_dup(v_x_2418);
    }
    default: return heff_nomatch(v_n_2413);
    }
  }
  case TAG_DData: {
    V v_kw_2420 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2420);
  }
  case TAG_DType: {
    V v_kw_2425 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2425);
  }
  case TAG_DTheory: {
    V v_kw_2430 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2430);
  }
  case TAG_DPrimitive: {
    V v_kw_2435 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2435);
  }
  case TAG_DTest: {
    V v_kw_2439 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2439);
  }
  case TAG_DWatch: {
    V v_w_2441 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2441);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstD(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      return v_kw_242;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      heff_drop(v_kw_242);
      return v_x_245;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_DSig: {
    V v_ty_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_249);
  }
  case TAG_DInstance: {
    V v_ty_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2413);
  }
  case TAG_DEqn: {
    V v_rhs_2417 = heff_field(v_x1_240, 3);
    V v_x15_2418 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_x15_2418)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_rhs_2417);
    }
    case TAG_Just: {
      V v_x151_2419 = heff_field(v_x15_2418, 0);
      heff_take_n(v_x15_2418, 1ULL, 1);
      heff_drop(v_rhs_2417);
      switch (heff_tag_of(v_x151_2419)) {
      case TAG_MkPair: {
        V v_kw_2420 = heff_field(v_x151_2419, 0);
        V v_ds_2421 = heff_field(v_x151_2419, 1);
        heff_take_n(v_x151_2419, 3ULL, 2);
        V v_x1_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2421));
        switch (heff_tag_of(v_x1_2422)) {
        case TAG_Nil: {
          return v_kw_2420;
        }
        case TAG_Cons: {
          V v_x_2423 = heff_field(v_x1_2422, 0);
          heff_take_n(v_x1_2422, 1ULL, 2);
          heff_drop(v_kw_2420);
          V t_0 = v_x_2423;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2422);
        }
      }
      default: return heff_nomatch(v_x151_2419);
      }
    }
    default: return heff_nomatch(v_x15_2418);
    }
  }
  case TAG_DData: {
    V v_name_2426 = heff_field(v_x1_240, 1);
    V v_params_2427 = heff_field(v_x1_240, 2);
    V v_universe_2428 = heff_field(v_x1_240, 3);
    V v_alts_2429 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    return ({ V a_0 = v_name_2426; V a_1 = v_params_2427; V a_2 = v_universe_2428; V a_3 = v_alts_2429; V r_ = (g_heff_2esyntax_2ecst_2edataLast(a_0, a_1, a_2, a_3)); heff_drop(v_universe_2428); heff_drop(v_alts_2429); r_; });
  }
  case TAG_DType: {
    V v_body_2434 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_body_2434);
  }
  case TAG_DTheory: {
    V v_w_2438 = heff_field(v_x1_240, 3);
    V v_fields_2439 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2439));
    switch (heff_tag_of(v_x1_2440)) {
    case TAG_Nil: {
      return v_w_2438;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x1_2440, 0);
      heff_take_n(v_x1_2440, 1ULL, 2);
      heff_drop(v_w_2438);
      switch (heff_tag_of(v_x_2441)) {
      case TAG_MkTF: {
        V v_ty_2445 = heff_field(v_x_2441, 2);
        V v_x14_2446 = heff_field(v_x_2441, 3);
        heff_take_n(v_x_2441, 12ULL, 4);
        switch (heff_tag_of(v_x14_2446)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2445);
        }
        case TAG_Just: {
          V v_x141_2447 = heff_field(v_x14_2446, 0);
          heff_take_n(v_x14_2446, 1ULL, 1);
          heff_drop(v_ty_2445);
          switch (heff_tag_of(v_x141_2447)) {
          case TAG_MkPair: {
            V v_d_2449 = heff_field(v_x141_2447, 1);
            heff_take_n(v_x141_2447, 2ULL, 2);
            HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_d_2449);
          }
          default: return heff_nomatch(v_x141_2447);
          }
        }
        default: return heff_nomatch(v_x14_2446);
        }
      }
      default: return heff_nomatch(v_x_2441);
      }
    }
    default: return heff_nomatch(v_x1_2440);
    }
  }
  case TAG_DPrimitive: {
    V v_ty_2453 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2453);
  }
  case TAG_DTest: {
    V v_x_2455 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2455;
  }
  case TAG_DWatch: {
    V v_e_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_e_2457);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastD(a[0]);
}