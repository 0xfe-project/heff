// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Atom 28502
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_EFDefault 38038
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EParen 58248
#define TAG_EUSet 22856
#define TAG_Get 18914
#define TAG_Left 13886
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Throw 56084
#define TAG_Tup 31899
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataLast(V, V, V, V);
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataLast_clo;
V g_heff_2esyntax_2ecst_2edeclAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclAt_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2efieldDefault(V, V);
V g_heff_2esyntax_2ecst_2efieldDefault_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldDefault_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
V g_heff_2esyntax_2ecst_2eletHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletHeadF_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eparensF(V, V, V);
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2ecst_2ereadH_get(void);
V g_heff_2esyntax_2ecst_2ereadSumAlg(V, V);
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo;
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(V);
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etheoryField(V, V);
V g_heff_2esyntax_2ecst_2etheoryField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryField_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF(V, V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam1, 3, 0};

static V g_heff_2esyntax_2ecst_2ereadH_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2ereadH_st;
static V g_heff_2esyntax_2ecst_2ereadH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2esyntax_2ecst_2ereadH_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2ereadH_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2ereadSumAlg_clo)});
}
V g_heff_2esyntax_2ecst_2ereadH_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2ereadH_st)) return g_heff_2esyntax_2ecst_2ereadH_val;
  return heff_global(&g_heff_2esyntax_2ecst_2ereadH_val, &g_heff_2esyntax_2ecst_2ereadH_st, g_heff_2esyntax_2ecst_2ereadH_init);
}
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatBoundary_str0, 3, "eof");
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_lam0, 1, 0};
Clo g_heff_2esyntax_2ecst_2eatBoundary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatBoundary(V v_hd_240, V v_k2_241) {
top: ;
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo)})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_240, 1, 3), 2, (V[]){v_t_2417, v_k2_241});
}
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatBoundary(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
  if (heff_strEq_c(heff_get_n(v_t_243, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eatBoundary_str0))) {
    heff_drop_rec(v_s_242, 5);
    return NTAG(TAG_True);
  } else {
    V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
    V v_t_246 = heff_get_n(v_t_245, 6, 9);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
      V v_t_248 = heff_take_field(v_s_242, 3);
      V v_x2_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_x2_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 2);
        v_x2_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_249});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_t_2413 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_t_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_ret_24bool = heff_bool((heff_intLe_c(heff_dup(heff_rfield(v_t_247, 5)), heff_dup(v_t_2413)) && !heff_intEq_c(heff_dup(heff_rfield(v_s_242, 1)), heff_dup(heff_rfield(v_s_242, 4)))));
      heff_drop_rec(v_s_242, 5);
      heff_drop_rec(v_t_247, 9);
      heff_drop(v_t_2413);
      return v_ret_24bool;
    } else {
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str2, 12, "expected `:`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str3, 12, "expected `:`");
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectAnn_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexpectAnn(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectAnn_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectAnn(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str1))) {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_240, v_k_241));
    } else {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_249}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2410;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str3), v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_245, 1)); V rr_ = heff_rec_reuse_nf(v_s_245, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2415, heff_dup(v_col_241)));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242}), v_hd_243, v_k_244));
  } else {
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_t_2416);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2412, v_acc_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V f_ = heff_dup(v_item_240);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Put, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam0, 1, 6, (V[]){v_sep_240, v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2esepGo(v_sep_240, v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}), v_hd_244, v_k_245));
}
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_p_241);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_p_241);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldsGo_str0, 5, "field");
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_EField, 2, (V[]){v_e_240, v_x_247}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2efieldsGo_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str1, 51, "an update sets a field by its name: `{ r | x = v }`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str2, 1, "=");
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateSettingF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eupdateSettingF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateSettingF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EUSet, 3, (V[]){v_x_2413, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam4, 1, 3, (V[]){v_k_242, v_x_2413, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_Atom, 1, (V[]){v_x_2412}), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam2, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str0)));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_247);
    V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str1), v_t_248, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_t_247);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam1, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str4, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str7, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str9, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str12, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eparensF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2418}), v_x_2419});
  V f_ = v_k_245;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam6, 1, 3, (V[]){v_x_243, v_x_2418, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_243, v_x_2426, v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str8), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam10, 1, 5, (V[]){v_k_245, v_x_243, v_x_2426, v_x_2427, v_x_2428})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam9, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam8, 1, 5, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2440;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkSep: {
    V v_items_2438 = heff_field(v_x_2436, 0);
    V v_seps_2439 = heff_field(v_x_2436, 1);
    heff_take_n(v_x_2436, 3ULL, 2);
    v_x_2440 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2438, v_seps_2439, v_x_2437});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V f_ = v_k_245;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str11), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam14, 1, 3, (V[]){v_x_2436, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, v_x_2430, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2433, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str9))) {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparensF_str10), heff_get_n(v_g_240, 0, 13), v_t_2435, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam13, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_drop_rec(v_g_240, 13);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str12), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam15, 1, 3, (V[]){v_k_245, v_x_243, v_x_2430})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2431}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam12, 1, 5, (V[]){v_x_2430, v_g_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str0)) && ({ V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_248, 1))})); int c_ = ({ V v_x1_2416 = ({ V a_0 = heff_dup(v_t_2415); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = ((heff_dup(v_x1_2416) == NTAG(TAG_True)) ? 0 : heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str1))); heff_drop(v_x1_2416); c_; }); heff_drop(v_t_2415); c_; })));
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_x_248, 9);
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_2417);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam5, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_drop(v_t_2417);
    V v_t_2425 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str2)) ? (heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str4))) : (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str5)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str7))))));
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_x_248, 9);
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam7, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243})));
    } else {
      heff_drop(v_t_2425);
      V f_ = heff_dup(heff_rfield(v_g_240, 0));
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam11, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam1, 2, 2, (V[]){v_x_243, v_g_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3_clo);
  } else {
    v_c_2417 = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4, 2, 1, (V[]){v_item_240});
  }
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str2, 1, "=");
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletHeadF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_lam5, 2, 0};
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletHeadF_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_lam6, 2, 0};
V g_heff_2esyntax_2ecst_2eletHeadF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 5)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam4, 1, 2, (V[]){v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_249), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam3, 1, 3, (V[]){v_g_240, v_hd_249, v_k_2410})));
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_MkLetHead, 4, (V[]){v_x_243, v_x_2419, v_x_2420, v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam8(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam9, 1, 4, (V[]){v_k_242, v_x_243, v_x_2419, v_x_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletHeadF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam8, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_2419})));
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2418;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str1))) {
      v_c_2418 = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam2, 2, 1, (V[]){heff_dup(v_g_240)});
    } else {
      v_c_2418 = ((V)&g_heff_2esyntax_2ecst_2eletHeadF_lam5_clo);
    }
  } else {
    heff_drop_rec(v_x_246, 9);
    v_c_2418 = ((V)&g_heff_2esyntax_2ecst_2eletHeadF_lam6_clo);
  }
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam7, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str1, 2, "in");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str2, 2, "in");
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletStmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletStmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2417;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_2412 = heff_field(v_x_244, 0);
    V v_ann_2413 = heff_field(v_x_244, 1);
    V v_eq_2414 = heff_field(v_x_244, 2);
    V v_e_2415 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_x_2411})});
    v_x_2417 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2412, v_ann_2413, v_eq_2414, v_e_2415, v_t_2416});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam4, 1, 4, (V[]){v_x_244, v_x_2410, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str1))));
  heff_drop_rec(v_x_247, 9);
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletStmtF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam3, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_249);
    V v_x_2422;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkLetHead: {
      V v_p_2418 = heff_field(v_x_244, 0);
      V v_ann_2419 = heff_field(v_x_244, 1);
      V v_eq_2420 = heff_field(v_x_244, 2);
      V v_e_2421 = heff_field(v_x_244, 3);
      heff_take_n(v_x_244, 15ULL, 4);
      v_x_2422 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2418, v_ann_2419, v_eq_2420, v_e_2421, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V f_ = v_k_242;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3_clo);
  } else {
    v_c_2417 = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4, 2, 1, (V[]){v_item_240});
  }
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2417, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_bool(((heff_dup(v_x_245) == NTAG(TAG_True)) || ({ V v_x1_246 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244))); int c_ = !(heff_dup(v_x1_246) == NTAG(TAG_True)); heff_drop(v_x1_246); c_; })));
  heff_drop(v_x_245);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str0))) {
      v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str1);
    } else {
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str2));
      v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str3), v_t_249);
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str4), v_t_2410);
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2411, v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_247);
    V v_c_2416 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4, 1, 3, (V[]){v_k_241, v_x_242, v_x_2411})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str0))) {
    V v_t_2410 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str1)) ? !(heff_dup(v_x_246) == NTAG(TAG_True)) : (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str2)) && !(heff_dup(v_x_246) == NTAG(TAG_True)))));
    heff_drop(v_x_246);
    heff_drop_rec(v_x_245, 9);
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    } else {
      heff_drop_rec(v_hd_240, 3);
      heff_drop(v_t_2410);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_246);
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2, 1, 4, (V[]){v_x_245, v_hd_240, v_k_241, v_x_242})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(v_sep_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2417, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_bool(((heff_dup(v_x_245) == NTAG(TAG_True)) || ({ V v_x1_246 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244))); int c_ = !(heff_dup(v_x1_246) == NTAG(TAG_True)); heff_drop(v_x1_246); c_; })));
  heff_drop(v_x_245);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0))) {
      v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1);
    } else {
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2));
      v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3), v_t_249);
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4), v_t_2410);
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2411, v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_247);
    V v_c_2416 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str2, 24, "a field is `name : Type`");
V g_heff_2esyntax_2ecst_2etheoryField_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etheoryField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etheoryField_entry, 2, 0};

V g_heff_2esyntax_2ecst_2etheoryField(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2etheoryField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etheoryField(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2etheoryField_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_MkTF, 4, (V[]){v_x_242, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etheoryField_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2efieldDefault(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam3, 1, 4, (V[]){v_k_241, v_x_242, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etheoryField_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etheoryField_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str0)) || heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str1))));
  if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
  } else {
    heff_drop(v_x1_244);
    V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str2), v_t_248, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str2, 58, "an instance is declared at the top level, not in a `where`");
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_st_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str1))) {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_call(heff_take_field(v_st_240, 2), 1, (V[]){v_t_249}));
      V f_ = heff_get_n(v_st_240, 1, 3);
      heff_room[0] = v_t_2410;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
    }
  } else {
    return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get_n(v_s_2410, 3, 5);
  V v_x2_2414;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    v_x2_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    v_x2_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 5, 9), heff_take_field(v_s_2425, 3)});
  return ({ V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_s_2425, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2434, 3)));
  return ({ V rv_3 = v_k_2435; V rr_ = heff_rec_reuse_nf(v_s_2434, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9, 1, 2, (V[]){v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo)})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2436}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(heff_get_n(v_x_244, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_dup(heff_rfield(v_x_244, 6));
  V v_t_2420 = heff_bool(((heff_dup(v_t_2419) == NTAG(TAG_True)) && heff_intLe_c(heff_dup(heff_rfield(v_x_244, 5)), heff_dup(v_x_2418))));
  heff_drop(v_x_2418);
  heff_drop(v_t_2419);
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2), v_t_2421, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2420);
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2427}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0))) {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo)})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0, 2, 0};
Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry, 1, 0};

V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(V v_st_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_st_240), heff_dup(heff_rfield(v_st_240, 1))));
  V v_x1_242 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241}), v_st_240});
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_st_244 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24MkPair = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_245}), v_st_244});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24MkPair, 2);
      return (g_heff_2esyntax_2ecst_2edeclAt(v_x_246, heff_dup(g_heff_2esyntax_2ecst_2ereadH_get()), ((V)&g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0_clo), v_st_244));
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(a[0]);
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_248 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_247}), v_st_248});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str2, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str3, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str6, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str7, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str8, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str9, 35, "the file does not parse (at offset ");
Clo g_heff_2esyntax_2ecst_2eprogramGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprogramGo_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eprogramGo(V v_s_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_243 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 1)), v_t_242, heff_dup(heff_rfield(v_s_240, 1))});
  V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(v_t_243, heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_244, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str0))) {
    heff_drop_rec(v_s_240, 5);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_246});
  } else {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_248 = ({ V rv_2 = heff_dup(heff_rfield(v_s_240, 1)); V rv_3 = v_t_247; V rv_4 = heff_dup(heff_rfield(v_s_240, 1)); V rr_ = heff_rec_reuse_nf(v_s_240, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_it_249 = heff_tr(g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(v_t_248));
    switch (heff_tag_of(v_it_249)) {
    case TAG_MkPair: {
      V v_it1_2410 = heff_field(v_it_249, 0);
      V v_s2_2411 = heff_field(v_it_249, 1);
      V v_ru_24it_249_24MkPair = heff_take_reuse_n(v_it_249, 3ULL, 2);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Left: {
        V v_d_2412 = heff_field(v_it1_2410, 0);
        V v_ru_24it1_2410_24Left = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop_rec(v_s2_2411, 5);
        heff_drop_cell(v_ru_24it_249_24MkPair, 2);
        V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_d_2412, 3)), 0, 2);
        V v_t_2414 = heff_strAppend(heff_get_n(v_d_2412, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str1));
        V v_t_2415 = heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str2), v_t_2414));
        return heff_tag_at_n(v_ru_24it1_2410_24Left, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str3), v_t_2415)});
      }
      case TAG_Right: {
        V v_d_2416 = heff_field(v_it1_2410, 0);
        V v_ru_24it1_2410_24Right = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
        V v_t_2417 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2411), heff_dup(heff_rfield(v_s2_2411, 1))));
        if (heff_strEq_c(heff_get_n(v_t_2417, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str4))) {
          heff_drop_cell(v_ru_24it1_2410_24Right, 1);
          V t_0 = v_s2_2411;
          V t_1 = heff_tag_at_n(v_ru_24it_249_24MkPair, TAG_Cons, 2, (V[]){v_d_2416, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_249_24MkPair, 2);
          heff_drop(v_d_2416);
          V v_t_2419 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2411), heff_dup(heff_rfield(v_s2_2411, 1))));
          V v_t_2420 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2411), heff_get_n(v_s2_2411, 1, 5)));
          V v_t_2421 = heff_strAppend(heff_get_n(v_t_2420, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str5));
          V v_msg_2422 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str6), v_t_2421);
          V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2419, 3), heff_get_n(v_t_2419, 4, 9)});
          V v_d_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2422, v_t_2423, NTAG(TAG_Nothing)});
          V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_d_2424, 3)), 0, 2);
          V v_t_2426 = heff_strAppend(heff_get_n(v_d_2424, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str7));
          V v_t_2427 = heff_strAppend(heff_intShow(v_t_2425), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str8), v_t_2426));
          return heff_tag_at_n(v_ru_24it1_2410_24Right, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str9), v_t_2427)});
        }
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_it_249);
    }
  }
}
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprogramGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2ecst_2efirstP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_243);
  }
  case TAG_PParen: {
    V v_o_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_244);
  }
  case TAG_PList: {
    V v_o_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_247);
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_x1_240, 0);
    V t_0 = v_l_2411;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_PField: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2418);
  }
  case TAG_PAs: {
    V v_x_2421 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2421);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstP(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_args_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      return v_t_241;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 2);
      heff_drop(v_t_241);
      V t_0 = v_x_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  case TAG_PAtom: {
    V v_t_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_246;
  }
  case TAG_PParen: {
    V v_c_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_249;
  }
  case TAG_PList: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_POp: {
    V v_r_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_r_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_c_2420 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2420;
  }
  case TAG_PField: {
    V v_p_2423 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2423;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PAs: {
    V v_p_2426 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2426;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastP(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_x1_240, 0);
    V v_x2_249;
    switch (heff_tag_of(v_n_244)) {
    case TAG_Nil: {
      v_x2_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_n_244, 0);
      v_x2_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_247)});
      break;
    }
    default: heff_nomatch(v_n_244);
    }
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str0), ((V)&g_heff_2esyntax_2ecst_2efirstD_str1), ((V)&g_heff_2esyntax_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      return v_x_2410;
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_DInstance: {
    V v_kw_2411 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2411);
  }
  case TAG_DEqn: {
    V v_n_2415 = heff_field(v_x1_240, 0);
    V v_x2_2422;
    switch (heff_tag_of(v_n_2415)) {
    case TAG_Nil: {
      v_x2_2422 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_n_2415, 0);
      v_x2_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2420)});
      break;
    }
    default: heff_nomatch(v_n_2415);
    }
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nothing: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str3), ((V)&g_heff_2esyntax_2ecst_2efirstD_str4), ((V)&g_heff_2esyntax_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      heff_take_n(v_x2_2422, 1ULL, 1);
      return v_x_2423;
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    V v_kw_2424 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2424);
  }
  case TAG_DType: {
    V v_kw_2429 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2429);
  }
  case TAG_DTheory: {
    V v_kw_2434 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2434);
  }
  case TAG_DPrimitive: {
    V v_kw_2439 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2439);
  }
  case TAG_DTest: {
    V v_kw_2443 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2443);
  }
  case TAG_DWatch: {
    V v_w_2445 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2445);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstD(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    V v_x2_247;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      v_x2_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      v_x2_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      return v_kw_242;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      heff_drop(v_kw_242);
      return v_x_248;
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DSig: {
    V v_ty_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2411);
  }
  case TAG_DInstance: {
    V v_ty_2415 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2415);
  }
  case TAG_DEqn: {
    V v_rhs_2419 = heff_field(v_x1_240, 3);
    V v_x15_2420 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_x15_2420)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_rhs_2419);
    }
    case TAG_Just: {
      V v_x151_2421 = heff_field(v_x15_2420, 0);
      heff_take_n(v_x15_2420, 1ULL, 1);
      heff_drop(v_rhs_2419);
      switch (heff_tag_of(v_x151_2421)) {
      case TAG_MkPair: {
        V v_kw_2422 = heff_field(v_x151_2421, 0);
        V v_ds_2423 = heff_field(v_x151_2421, 1);
        heff_take_n(v_x151_2421, 3ULL, 2);
        V v_x1_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2423));
        switch (heff_tag_of(v_x1_2424)) {
        case TAG_Nil: {
          return v_kw_2422;
        }
        case TAG_Cons: {
          V v_x_2425 = heff_field(v_x1_2424, 0);
          heff_take_n(v_x1_2424, 1ULL, 2);
          heff_drop(v_kw_2422);
          V t_0 = v_x_2425;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2424);
        }
      }
      default: return heff_nomatch(v_x151_2421);
      }
    }
    default: return heff_nomatch(v_x15_2420);
    }
  }
  case TAG_DData: {
    V v_name_2428 = heff_field(v_x1_240, 1);
    V v_params_2429 = heff_field(v_x1_240, 2);
    V v_universe_2430 = heff_field(v_x1_240, 3);
    V v_alts_2431 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    return ({ V a_0 = v_name_2428; V a_1 = v_params_2429; V a_2 = v_universe_2430; V a_3 = v_alts_2431; V r_ = (g_heff_2esyntax_2ecst_2edataLast(a_0, a_1, a_2, a_3)); heff_drop(v_universe_2430); r_; });
  }
  case TAG_DType: {
    V v_body_2436 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_body_2436);
  }
  case TAG_DTheory: {
    V v_w_2440 = heff_field(v_x1_240, 3);
    V v_fields_2441 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2441));
    V v_x2_2445;
    switch (heff_tag_of(v_x1_2442)) {
    case TAG_Nil: {
      v_x2_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2443 = heff_field(v_x1_2442, 0);
      heff_take_n(v_x1_2442, 1ULL, 2);
      v_x2_2445 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2443});
      break;
    }
    default: heff_nomatch(v_x1_2442);
    }
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_Nothing: {
      return v_w_2440;
    }
    case TAG_Just: {
      V v_f_2446 = heff_field(v_x2_2445, 0);
      heff_take_n(v_x2_2445, 1ULL, 1);
      heff_drop(v_w_2440);
      switch (heff_tag_of(v_f_2446)) {
      case TAG_MkTF: {
        V v_ty_2449 = heff_field(v_f_2446, 2);
        V v_x14_2450 = heff_field(v_f_2446, 3);
        heff_take_n(v_f_2446, 12ULL, 4);
        switch (heff_tag_of(v_x14_2450)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2449);
        }
        case TAG_Just: {
          V v_x141_2451 = heff_field(v_x14_2450, 0);
          heff_take_n(v_x14_2450, 1ULL, 1);
          heff_drop(v_ty_2449);
          switch (heff_tag_of(v_x141_2451)) {
          case TAG_MkPair: {
            V v_d_2453 = heff_field(v_x141_2451, 1);
            heff_take_n(v_x141_2451, 2ULL, 2);
            HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_d_2453);
          }
          default: return heff_nomatch(v_x141_2451);
          }
        }
        default: return heff_nomatch(v_x14_2450);
        }
      }
      default: return heff_nomatch(v_f_2446);
      }
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  case TAG_DPrimitive: {
    V v_ty_2457 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2457);
  }
  case TAG_DTest: {
    V v_x_2459 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2459;
  }
  case TAG_DWatch: {
    V v_e_2461 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_e_2461);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastD(a[0]);
}