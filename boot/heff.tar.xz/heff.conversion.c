// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2econversion_2eeqHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2econversion_2eeqHead_entry, 2, 0};

V g_heff_2econversion_2eeqHead(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_HLocal: {
    V v_i_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      V v_j_243 = heff_field(v_x2_241, 0);
      return heff_intEq(heff_dup(v_i_242), heff_dup(v_j_243));
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HGlobal: {
    V v_x_246 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_y_248 = heff_field(v_x2_241, 0);
      return heff_strEq(heff_dup(v_x_246), heff_dup(v_y_248));
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HMeta: {
    V v_m_2410 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      V v_m_27_2413 = heff_field(v_x2_241, 0);
      return heff_intEq(heff_dup(v_m_2410), heff_dup(v_m_27_2413));
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HError: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2econversion_2eeqHead_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2econversion_2eeqHead(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2econversion_2ecanon_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2econversion_2ecanon_lam1(V self, V *args);
V g_heff_2econversion_2ecanon_lam0(V self, V *args);
V g_heff_2econversion_2ecanon_lam2(V self, V *args);
Clo g_heff_2econversion_2ecanon_clo = {{0x80000000u, K_CLO, 0}, g_heff_2econversion_2ecanon_entry, 1, 0};

V g_heff_2econversion_2ecanon(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_ty_243 = heff_dup(heff_field(v_v_240, 2));
    V v_expansion_244 = heff_dup(heff_field(v_v_240, 3));
    V v_t_246 = heff_tr(heff_apply(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_247 = (g_heff_2evalue_2ebehavior(v_t_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeFunction: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_expansion_244);
      V v_t_2415 = heff_tag(TAG_MkClo, 3, (V[]){((V)&g_heff_2econversion_2ecanon_str0), NTAG(TAG_LNil), heff_clo(g_heff_2econversion_2ecanon_lam0, 1, 1, (V[]){v_v_240})});
      return heff_tag(TAG_VLam, 2, (V[]){v_ty_243, v_t_2415});
    }
    case TAG_LikeRecord: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_v_240);
      heff_drop(v_ty_243);
      V v_t_2419 = heff_tr(heff_apply(v_expansion_244, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_IntoCons: {
        V v_fields_2420 = heff_field(v_t_2419, 0);
        V v_ru_24t_2419_24IntoCons = heff_take_reuse(v_t_2419, 1ULL);
        V v_xs_2421 = heff_get(heff_dup(v_fields_2420), LBL_values);
        V v_t_2424 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2421)), heff_clo(g_heff_2econversion_2ecanon_lam2, 1, 1, (V[]){v_xs_2421}));
        V v_t_2425 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_fields_2420), LBL_keys), heff_get(v_fields_2420, LBL_byName), v_t_2424});
        return heff_tag_at(v_ru_24t_2419_24IntoCons, TAG_VCons, 1, (V[]){v_t_2425});
      }
      case TAG_NotApplicable: {
        heff_drop(v_t_2419);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeInt: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      heff_drop(v_t_247);
      return v_v_240;
    }
    case TAG_LikeFloat: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      heff_drop(v_t_247);
      return v_v_240;
    }
    case TAG_LikeString: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      heff_drop(v_t_247);
      return v_v_240;
    }
    case TAG_LikeArray: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_NoRules: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      heff_drop(v_t_247);
      return v_v_240;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VCode: {
    return v_v_240;
  }
  case TAG_VLam: {
    return v_v_240;
  }
  case TAG_VCons: {
    return v_v_240;
  }
  case TAG_VOpaque: {
    return v_v_240;
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2econversion_2ecanon_entry(V self, V *a) {
  (void)self;
  return g_heff_2econversion_2ecanon(a[0]);
}
V g_heff_2econversion_2ecanon_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_w_2413 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2414);
  return ({ V a_0 = v_w_2413; V a_1 = MK_INT(0LL); V r_ = (g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_w_2413); r_; });
}
V g_heff_2econversion_2ecanon_lam0(V self, V *args) {
  V v_w_2413 = args[0];
  V v_v_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2evalue_2eapp(v_v_240, heff_clo(g_heff_2econversion_2ecanon_lam1, 1, 1, (V[]){v_w_2413})));
}
V g_heff_2econversion_2ecanon_lam2(V self, V *args) {
  V v_i_2422 = args[0];
  V v_xs_2421 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2423 = heff_arrayIndex(v_xs_2421, v_i_2422);
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2423});
}