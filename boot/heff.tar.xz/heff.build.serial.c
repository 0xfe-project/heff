// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2eserial_2eabsOf(V, V);
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eabsOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_clo;
V g_heff_2ebuild_2eserial_2etakeDict(V);
V g_heff_2ebuild_2eserial_2etakeDict_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_clo;
V g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010(V, V);
V g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_clo;
V g_heff_2ebuild_2eserial_2etakeFixed(V, V);
V g_heff_2ebuild_2eserial_2etakeFixed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFixed_clo;
V g_heff_2ebuild_2eserial_2etermOf(V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf(V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_lit_240, v_x_243));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245))});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_a_247); r_; })});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_rest_244;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_2410 = heff_intShow(heff_strLength(heff_dup(v_a_248)));
      V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(v_lit_240, v_a_248));
      V v_a_2412 = heff_arrayToList(v_a_249);
      V v_a_2413 = (g_list_2efoldl_24s1116451536x2100070357(v_lit_241, v_lit_242, v_a_2412));
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2413), ({ V a_0 = v_a_2412; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2412); r_; })});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2411, v_t_2414});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SmallU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_x2_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_243), v_rest_241))});
  }
  case TAG_SFunction: {
    V v_level_244 = heff_field(v_x2_240, 0);
    V v_dom_245 = heff_field(v_x2_240, 1);
    V v_cod_246 = heff_field(v_x2_240, 2);
    V v_implicit_247 = heff_field(v_x2_240, 3);
    V v_dflt_248 = heff_field(v_x2_240, 4);
    V v_t_249;
    switch (heff_tag_of(v_level_244)) {
    case TAG_Small: {
      v_t_249 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5);
      break;
    }
    case TAG_Large: {
      v_t_249 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6);
      break;
    }
    case TAG_TopL: {
      v_t_249 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7);
      break;
    }
    default: heff_nomatch(v_level_244);
    }
    V v_t_2410;
    switch (heff_tag_of(v_implicit_247)) {
    case TAG_Expl: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10);
      break;
    }
    default: heff_nomatch(v_implicit_247);
    }
    V v_t_2412;
    switch (heff_tag_of(v_dflt_248)) {
    case TAG_Nothing: {
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_248, 0);
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2411), v_rest_241))});
      break;
    }
    default: heff_nomatch(v_dflt_248);
    }
    V v_rest_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
    V v_rest_2420;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_cod_246, 0);
      V v_e_2415 = heff_field(v_cod_246, 1);
      V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_x_2414)));
      V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13), heff_dup(v_x_2414)));
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2415, v_rest_2413))});
      v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14), v_t_2418});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2419 = heff_field(v_cod_246, 0);
      v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15), (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2419, v_rest_2413))});
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_245, v_rest_2420));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2421})});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_x2_240, 0);
    V v_fs_2423 = heff_field(v_x2_240, 1);
    V v_ds_2424 = heff_field(v_x2_240, 2);
    V v_t_2425;
    switch (heff_tag_of(v_level_2422)) {
    case TAG_Small: {
      v_t_2425 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17);
      break;
    }
    case TAG_Large: {
      v_t_2425 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2425 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19);
      break;
    }
    default: heff_nomatch(v_level_2422);
    }
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2424, 2)));
    V v_xs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_i_2429 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2428));
    V v_rest_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2429), (g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20), v_xs_2428, v_rest_241))});
    V v_t_2431 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2423, 0)));
    V v_t_2432 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2423, 2)));
    V v_xs_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
    V v_i_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2434), (g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21), v_xs_2433, v_rest_2430))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2435})});
  }
  case TAG_SSum: {
    V v_vs_2436 = heff_field(v_x2_240, 0);
    V v_t_2437 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2436, 0)));
    V v_t_2438 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2436, 2)));
    V v_xs_2439 = (g_heff_2eutil_2edict_2ezipKV(v_t_2437, v_t_2438));
    V v_i_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2440), (g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2439, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24), v_t_2441});
  }
  case TAG_SIsTy: {
    V v_t2_2442 = heff_field(v_x2_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25), (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_t2_2442, v_rest_241))});
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28), v_rest_241});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2443 = heff_field(v_x2_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30), (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_t2_2443, v_rest_241))});
  }
  case TAG_SFixed: {
    V v_w_2444 = heff_field(v_x2_240, 0);
    V v_t_2445;
    switch (heff_tag_of(v_w_2444)) {
    case TAG_I8: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31);
      break;
    }
    case TAG_I16: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32);
      break;
    }
    case TAG_I32: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33);
      break;
    }
    case TAG_I64: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34);
      break;
    }
    case TAG_U8: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35);
      break;
    }
    case TAG_U16: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36);
      break;
    }
    case TAG_U32: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37);
      break;
    }
    case TAG_U64: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38);
      break;
    }
    case TAG_F32: {
      v_t_2445 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39);
      break;
    }
    default: heff_nomatch(v_w_2444);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2418;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s1116451536x2100070357(v_lit_241, v_lit_242, v_a_2415));
        v_t_2418 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), (g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(v_lit_243, v_a_2415, v_a_2416))});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2418});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_244)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1), v_x_244));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_rest_241})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3), ({ V a_0 = v_t_247; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_247); r_; })});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_x2_240, 0);
    V v_a_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_249, v_rest_241));
    V v_t_2411 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_248, v_rest_2410));
    return heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4), v_t_2411});
  }
  case TAG_SLam: {
    V v_t_2412 = heff_field(v_x2_240, 0);
    V v_b_2413 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2420;
    switch (heff_tag_of(v_b_2413)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_b_2413, 0);
      V v_e_2415 = heff_field(v_b_2413, 1);
      V v_ru_24b_2413_24MkAbs = heff_take_reuse_n(v_b_2413, 3ULL, 2);
      V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_x_2414)));
      V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5), v_x_2414));
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){v_t_2417, (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2415, v_rest_241))});
      v_rest_2420 = heff_tag_at_n(v_ru_24b_2413_24MkAbs, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6), v_t_2418});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2419 = heff_field(v_b_2413, 0);
      heff_take_n(v_b_2413, 1ULL, 1);
      v_rest_2420 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2419, v_rest_241))});
      break;
    }
    default: heff_nomatch(v_b_2413);
    }
    V v_t_2421 = ({ V a_0 = v_t_2412; V a_1 = v_rest_2420; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2412); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8), v_t_2421});
  }
  case TAG_SCons: {
    V v_d_2422 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2423 = heff_arrayToList(heff_take_field(v_d_2422, 0));
    V v_t_2424 = heff_arrayToList(heff_get_n(v_d_2422, 2, 3));
    V v_xs_2425 = (g_heff_2eutil_2edict_2ezipKV(v_t_2423, v_t_2424));
    V v_i_2426 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2425));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2426), (g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9), v_xs_2425, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10), v_t_2427});
  }
  case TAG_SProj: {
    V v_e2_2428 = heff_field(v_x2_240, 0);
    V v_l_2429 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2430 = heff_intShow(heff_strLength(heff_dup(v_l_2429)));
    V v_t_2431 = heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11), v_l_2429));
    return heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_rest_241})))});
  }
  case TAG_STag: {
    V v_t_2432 = heff_field(v_x2_240, 0);
    V v_as_2433 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2434 = heff_intShow(heff_strLength(heff_dup(v_t_2432)));
    V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13), v_t_2432));
    V v_xs_2436 = heff_arrayToList(v_as_2433);
    V v_i_2437 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2436));
    V v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2437), ({ V a_0 = v_xs_2436; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2436); r_; })});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  }
  case TAG_SMatch: {
    V v_e2_2439 = heff_field(v_x2_240, 0);
    V v_cs_2440 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = heff_arrayToList(heff_take_field(v_cs_2440, 0));
    V v_t_2442 = heff_arrayToList(heff_get_n(v_cs_2440, 2, 3));
    V v_xs_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_i_2444 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_rest_2445 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2444), (g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16), v_xs_2443, v_rest_241))});
    V v_t_2446 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2439, v_rest_2445));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17), v_t_2446});
  }
  case TAG_SSpecialize: {
    V v_e2_2447 = heff_field(v_x2_240, 0);
    V v_l_2448 = heff_field(v_x2_240, 1);
    V v_v_2449 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2450 = heff_intShow(heff_strLength(heff_dup(v_l_2448)));
    V v_t_2451 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18), v_l_2448));
    V v_rest_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2449, v_rest_241))});
    V v_t_2453 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2447, v_rest_2452));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19), v_t_2453});
  }
  case TAG_SIs: {
    V v_e2_2454 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2454, v_rest_241))});
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21), v_rest_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22), v_rest_241});
  }
  case TAG_SRec: {
    V v_e2_2455 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2455, v_rest_241))});
  }
  case TAG_SFix: {
    V v_t_2456 = heff_field(v_x2_240, 0);
    V v_b_2457 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2464;
    switch (heff_tag_of(v_b_2457)) {
    case TAG_MkAbs: {
      V v_x_2458 = heff_field(v_b_2457, 0);
      V v_e_2459 = heff_field(v_b_2457, 1);
      V v_ru_24b_2457_24MkAbs = heff_take_reuse_n(v_b_2457, 3ULL, 2);
      V v_t_2460 = heff_intShow(heff_strLength(heff_dup(v_x_2458)));
      V v_t_2461 = heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24), v_x_2458));
      V v_t_2462 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){v_t_2461, (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2459, v_rest_241))});
      v_rest_2464 = heff_tag_at_n(v_ru_24b_2457_24MkAbs, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25), v_t_2462});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2463 = heff_field(v_b_2457, 0);
      heff_take_n(v_b_2457, 1ULL, 1);
      v_rest_2464 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26), (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2463, v_rest_241))});
      break;
    }
    default: heff_nomatch(v_b_2457);
    }
    V v_t_2465 = ({ V a_0 = v_t_2456; V a_1 = v_rest_2464; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2456); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27), v_t_2465});
  }
  case TAG_SImplicit: {
    V v_x_2466 = heff_field(v_x2_240, 0);
    V v_e2_2467 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2468 = heff_intShow(heff_strLength(heff_dup(v_x_2466)));
    V v_t_2469 = heff_strAppend(v_t_2468, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28), v_x_2466));
    V v_t_2470 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){v_t_2469, (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2467, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29), v_t_2470});
  }
  case TAG_SPrim: {
    V v_x_2471 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2472 = heff_intShow(heff_strLength(heff_dup(v_x_2471)));
    V v_t_2473 = heff_strAppend(v_t_2472, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30), v_x_2471));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_rest_241})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32), v_rest_241});
  }
  case TAG_SLitInt: {
    V v_i_2477 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2478 = heff_intShow(v_i_2477);
    V v_t_2479 = heff_intShow(heff_strLength(heff_dup(v_s_2478)));
    V v_t_2480 = heff_strAppend(v_t_2479, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33), v_s_2478));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, v_rest_241})});
  }
  case TAG_SLitFloat: {
    V v_x_2481 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2482 = heff_floatShow(v_x_2481);
    V v_t_2483 = heff_intShow(heff_strLength(heff_dup(v_s_2482)));
    V v_t_2484 = heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35), v_s_2482));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, v_rest_241})});
  }
  case TAG_SLitString: {
    V v_s_2485 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2486 = heff_intShow(heff_strLength(heff_dup(v_s_2485)));
    V v_t_2487 = heff_strAppend(v_t_2486, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37), v_s_2485));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, v_rest_241})});
  }
  case TAG_SLitRune: {
    V v_c_2488 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2489 = heff_intShow(v_c_2488);
    V v_t_2490 = heff_intShow(heff_strLength(heff_dup(v_s_2489)));
    V v_t_2491 = heff_strAppend(v_t_2490, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39), v_s_2489));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, v_rest_241})});
  }
  case TAG_SLitFixed: {
    V v_w_2492 = heff_field(v_x2_240, 0);
    V v_n_2493 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2494;
    switch (heff_tag_of(v_w_2492)) {
    case TAG_I8: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41);
      break;
    }
    case TAG_I16: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42);
      break;
    }
    case TAG_I32: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43);
      break;
    }
    case TAG_I64: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44);
      break;
    }
    case TAG_U8: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45);
      break;
    }
    case TAG_U16: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46);
      break;
    }
    case TAG_U32: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47);
      break;
    }
    case TAG_U64: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48);
      break;
    }
    case TAG_F32: {
      v_t_2494 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49);
      break;
    }
    default: heff_nomatch(v_w_2492);
    }
    V v_s_2495 = heff_intShow(v_n_2493);
    V v_t_2496 = heff_intShow(heff_strLength(heff_dup(v_s_2495)));
    V v_t_2497 = heff_strAppend(v_t_2496, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50), v_s_2495));
    V v_t_2498 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_2494, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51), v_t_2498});
  }
  case TAG_SLitFloat32: {
    V v_x_2499 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24100 = heff_floatShow(v_x_2499);
    V v_t_24101 = heff_intShow(heff_strLength(heff_dup(v_s_24100)));
    V v_t_24102 = heff_strAppend(v_t_24101, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52), v_s_24100));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24102, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str8, 7, "Float32");
V g_heff_2ebuild_2eserial_2etakeFixed_lam0(V self, V *args);
Clo g_heff_2ebuild_2eserial_2etakeFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFixed_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeFixed(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_248 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eserial_2etakeFixed_lam0, 1, 1, (V[]){v_x_244}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_j_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_j_245})});
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eserial_2etakeFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFixed(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2etakeFixed_lam0(V self, V *args) {
  V v_w_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_w_246)) {
  case TAG_I8: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str0);
    break;
  }
  case TAG_I16: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str1);
    break;
  }
  case TAG_I32: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str2);
    break;
  }
  case TAG_I64: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str3);
    break;
  }
  case TAG_U8: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str4);
    break;
  }
  case TAG_U16: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str5);
    break;
  }
  case TAG_U32: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str6);
    break;
  }
  case TAG_U64: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str7);
    break;
  }
  case TAG_F32: {
    v_t_247 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str8);
    break;
  }
  default: heff_nomatch(v_w_246);
  }
  return heff_strEq(v_t_247, v_x_244);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_str1, 1, "_");
V g_heff_2ebuild_2eserial_2eabsOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2eabsOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2eserial_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eabsOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eabsOf(V v_d_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2eabsOf_str0))) {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ebuild_2eserial_2eabsOf_lam0, 2, 1, (V[]){v_d_240});
  } else {
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_str1))) {
      return heff_clo_n(g_heff_2ebuild_2eserial_2eabsOf_lam1, 2, 1, (V[]){v_d_240});
    } else {
      heff_drop(v_d_240);
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eabsOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2eabsOf_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_i_244));
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    heff_drop(v_s_243);
    heff_drop(v_d_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_x3_249 = heff_tr(heff_apply(v_d_240, 2, (V[]){v_s_243, v_j_248}));
      switch (heff_tag_of(v_x3_249)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_245_24Just, 1);
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2410 = heff_field(v_x3_249, 0);
        heff_take_n(v_x3_249, 1ULL, 1);
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          heff_take_n(v_x31_2410, 3ULL, 2);
          V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
          return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
        }
        default: return heff_nomatch(v_x31_2410);
        }
      }
      default: return heff_nomatch(v_x3_249);
      }
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ebuild_2eserial_2eabsOf_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_i_2416 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2417 = heff_tr(heff_apply(v_d_240, 2, (V[]){v_s_2415, v_i_2416}));
  switch (heff_tag_of(v_x3_2417)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2418 = heff_field(v_x3_2417, 0);
    V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
    switch (heff_tag_of(v_x31_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x31_2418, 0);
      V v_j_2420 = heff_field(v_x31_2418, 1);
      V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
      V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_AbsConst, 1, (V[]){v_x_2419}), v_j_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    }
    default: return heff_nomatch(v_x31_2418);
    }
  }
  default: return heff_nomatch(v_x3_2417);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2etakeDict_lam1(V self, V *args);
Clo g_heff_2ebuild_2eserial_2etakeDict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeDict_entry, 1, 0};

V g_heff_2ebuild_2eserial_2etakeDict(V v_d_240) {
top: ;
  V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 1, (V[]){heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_lam0, 2, 1, (V[]){v_d_240})}));
  V v_m_2413 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo), 1, (V[]){v_t_2412}));
  return heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_lam1, 2, 1, (V[]){v_m_2413});
}
V g_heff_2ebuild_2eserial_2etakeDict_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeDict(a[0]);
}
V g_heff_2ebuild_2eserial_2etakeDict_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    heff_drop(v_d_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_apply(v_d_240, 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_249}), v_j_2410});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_i_2415 = args[1];
  V v_m_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2416 = heff_tr(heff_apply(v_m_2413, 2, (V[]){v_s_2414, v_i_2415}));
  switch (heff_tag_of(v_x3_2416)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2417 = heff_field(v_x3_2416, 0);
    V v_ru_24x3_2416_24Just = heff_take_reuse_n(v_x3_2416, 1ULL, 1);
    switch (heff_tag_of(v_x31_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x31_2417, 0);
      V v_j_2419 = heff_field(v_x31_2417, 1);
      heff_take_n(v_x31_2417, 3ULL, 2);
      V v_t_2420 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2418)));
      V v_t_2421 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2418));
      V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_x_2418));
      V v_x_2423 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2420), v_t_2421, heff_arrayFromList(v_t_2422)});
      return heff_tag_at_n(v_ru_24x3_2416_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_j_2419})});
    }
    default: return heff_nomatch(v_x31_2417);
    }
  }
  default: return heff_nomatch(v_x3_2416);
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_245), v_x_249});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_j_2410})});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str22, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str23, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str24, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str25, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str28, 0, "");
V g_heff_2ebuild_2eserial_2etermOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam1, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam2(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam3(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam4(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam5(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam6(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam7(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam8(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam9(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam10(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam11(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam11, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam12(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam12, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam13(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam14(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam15(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_lam16(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam16, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam17(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam17, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam18(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam18, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam19(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam19, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam20(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam20, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam21(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam21, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_lam22(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_lam22, 2, 0};
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str0))) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam0_clo);
  } else {
    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str1))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_x2_241);
      return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam1_clo);
    } else {
      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str2))) {
        heff_drop(v_x2_241);
        return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam2, 2, 1, (V[]){v_k_240});
      } else {
        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str3))) {
          heff_drop(v_x2_241);
          return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam3, 2, 1, (V[]){v_k_240});
        } else {
          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str4))) {
            heff_drop(v_x2_241);
            return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam4, 2, 1, (V[]){v_k_240});
          } else {
            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str5))) {
              heff_drop(v_x2_241);
              V v_m_2461 = (g_heff_2ebuild_2eserial_2etakeDict(heff_get_n(v_k_240, 0, 2)));
              return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam5, 2, 1, (V[]){v_m_2461});
            } else {
              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str6))) {
                heff_drop(v_x2_241);
                return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam6, 2, 1, (V[]){v_k_240});
              } else {
                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str7))) {
                  heff_drop(v_x2_241);
                  return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam7, 2, 1, (V[]){v_k_240});
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str8))) {
                    heff_drop(v_x2_241);
                    return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam8, 2, 1, (V[]){v_k_240});
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str9))) {
                      heff_drop(v_x2_241);
                      return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam9, 2, 1, (V[]){v_k_240});
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str10))) {
                        heff_drop(v_x2_241);
                        return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam10, 2, 1, (V[]){v_k_240});
                      } else {
                        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str11))) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_x2_241);
                          return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam11_clo);
                        } else {
                          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str12))) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_x2_241);
                            return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam12_clo);
                          } else {
                            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str13))) {
                              heff_drop(v_x2_241);
                              return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam13, 2, 1, (V[]){v_k_240});
                            } else {
                              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str14))) {
                                heff_drop(v_x2_241);
                                return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam14, 2, 1, (V[]){v_k_240});
                              } else {
                                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str15))) {
                                  heff_drop(v_x2_241);
                                  return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_lam15, 2, 1, (V[]){v_k_240});
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str16))) {
                                    heff_drop(v_x2_241);
                                    return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam16_clo);
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str17))) {
                                      heff_drop(v_x2_241);
                                      return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam17_clo);
                                    } else {
                                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str18))) {
                                        heff_drop(v_x2_241);
                                        return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam18_clo);
                                      } else {
                                        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str22))) {
                                          heff_drop(v_x2_241);
                                          return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam19_clo);
                                        } else {
                                          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str23))) {
                                            heff_drop(v_x2_241);
                                            return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam20_clo);
                                          } else {
                                            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str24))) {
                                              heff_drop(v_x2_241);
                                              return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam21_clo);
                                            } else {
                                              if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_str25))) {
                                                return ((V)&g_heff_2ebuild_2eserial_2etermOf_lam22_clo);
                                              } else {
                                                return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2etermOf_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_x3_245 = (g_heff_2ebuild_2edecoder_2eword(v_s_243, v_i_244));
  V v_x3_2410;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    v_x3_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_x_249 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_247));
      v_x3_2410 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_j_248})});
      break;
    }
    default: heff_nomatch(v_x31_246);
    }
    break;
  }
  default: heff_nomatch(v_x3_245);
  }
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2411 = heff_field(v_x3_2410, 0);
    V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
    switch (heff_tag_of(v_x31_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x31_2411, 0);
      V v_j_2413 = heff_field(v_x31_2411, 1);
      V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
      V v_t_2414 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_SLocal, 1, (V[]){v_x_2412}), v_j_2413});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    }
    default: return heff_nomatch(v_x31_2411);
    }
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_i_2417 = args[1];
  V v_x3_2418 = (g_heff_2ebuild_2edecoder_2estr(v_s_2416, v_i_2417));
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x31_2419, 0);
      V v_j_2421 = heff_field(v_x31_2419, 1);
      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_SGlobal, 1, (V[]){v_x_2420}), v_j_2421});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
    }
    default: return heff_nomatch(v_x31_2419);
    }
  }
  default: return heff_nomatch(v_x3_2418);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_i_2425 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2426 = heff_tr(heff_apply(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_s_2424, v_i_2425}));
  switch (heff_tag_of(v_x3_2426)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2427 = heff_field(v_x3_2426, 0);
    V v_ru_24x3_2426_24Just = heff_take_reuse_n(v_x3_2426, 1ULL, 1);
    switch (heff_tag_of(v_x31_2427)) {
    case TAG_MkPair: {
      V v_x_2428 = heff_field(v_x31_2427, 0);
      V v_j_2429 = heff_field(v_x31_2427, 1);
      V v_ru_24x31_2427_24MkPair = heff_take_reuse_n(v_x31_2427, 3ULL, 2);
      V v_t_2430 = heff_tag_at_n(v_ru_24x31_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2426_24Just, TAG_SCode, 1, (V[]){v_x_2428}), v_j_2429});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
    }
    default: return heff_nomatch(v_x31_2427);
    }
  }
  default: return heff_nomatch(v_x3_2426);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam3(V self, V *args) {
  V v_s_2432 = args[0];
  V v_i_2433 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2434 = heff_tr(heff_apply(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_s_2432), v_i_2433}));
  switch (heff_tag_of(v_x3_2434)) {
  case TAG_Nothing: {
    heff_drop(v_s_2432);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2435 = heff_field(v_x3_2434, 0);
    V v_ru_24x3_2434_24Just = heff_take_reuse_n(v_x3_2434, 1ULL, 1);
    switch (heff_tag_of(v_x31_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x31_2435, 0);
      V v_j_2437 = heff_field(v_x31_2435, 1);
      V v_ru_24x31_2435_24MkPair = heff_take_reuse_n(v_x31_2435, 3ULL, 2);
      V v_x3_2438 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_2432, v_j_2437}));
      switch (heff_tag_of(v_x3_2438)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2434_24Just, 1);
        heff_drop(v_x_2436);
        heff_drop_cell(v_ru_24x31_2435_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2439 = heff_field(v_x3_2438, 0);
        heff_take_n(v_x3_2438, 1ULL, 1);
        switch (heff_tag_of(v_x31_2439)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_x31_2439, 0);
          V v_j_2441 = heff_field(v_x31_2439, 1);
          heff_take_n(v_x31_2439, 3ULL, 2);
          V v_t_2442 = heff_tag_at_n(v_ru_24x31_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2436, v_x_2440}), v_j_2441});
          return heff_tag_at_n(v_ru_24x3_2434_24Just, TAG_Just, 1, (V[]){v_t_2442});
        }
        default: return heff_nomatch(v_x31_2439);
        }
      }
      default: return heff_nomatch(v_x3_2438);
      }
    }
    default: return heff_nomatch(v_x31_2435);
    }
  }
  default: return heff_nomatch(v_x3_2434);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam4(V self, V *args) {
  V v_s_2444 = args[0];
  V v_i_2445 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2446 = heff_tr(heff_apply(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_s_2444), v_i_2445}));
  switch (heff_tag_of(v_x3_2446)) {
  case TAG_Nothing: {
    heff_drop(v_s_2444);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2447 = heff_field(v_x3_2446, 0);
    V v_ru_24x3_2446_24Just = heff_take_reuse_n(v_x3_2446, 1ULL, 1);
    switch (heff_tag_of(v_x31_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x31_2447, 0);
      V v_j_2449 = heff_field(v_x31_2447, 1);
      V v_ru_24x31_2447_24MkPair = heff_take_reuse_n(v_x31_2447, 3ULL, 2);
      V v_x3_2450 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2444), v_j_2449));
      V v_x3_2455;
      switch (heff_tag_of(v_x3_2450)) {
      case TAG_Nothing: {
        heff_drop(v_s_2444);
        heff_drop_rec(v_k_240, 2);
        v_x3_2455 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2451 = heff_field(v_x3_2450, 0);
        heff_take_n(v_x3_2450, 1ULL, 1);
        switch (heff_tag_of(v_x31_2451)) {
        case TAG_MkPair: {
          V v_x_2452 = heff_field(v_x31_2451, 0);
          V v_j_2453 = heff_field(v_x31_2451, 1);
          heff_take_n(v_x31_2451, 3ULL, 2);
          V v_t_2454 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_2452));
          v_x3_2455 = heff_tr(heff_apply(v_t_2454, 2, (V[]){v_s_2444, v_j_2453}));
          break;
        }
        default: heff_nomatch(v_x31_2451);
        }
        break;
      }
      default: heff_nomatch(v_x3_2450);
      }
      switch (heff_tag_of(v_x3_2455)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2446_24Just, 1);
        heff_drop(v_x_2448);
        heff_drop_cell(v_ru_24x31_2447_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2456 = heff_field(v_x3_2455, 0);
        heff_take_n(v_x3_2455, 1ULL, 1);
        switch (heff_tag_of(v_x31_2456)) {
        case TAG_MkPair: {
          V v_x_2457 = heff_field(v_x31_2456, 0);
          V v_j_2458 = heff_field(v_x31_2456, 1);
          heff_take_n(v_x31_2456, 3ULL, 2);
          V v_t_2459 = heff_tag_at_n(v_ru_24x31_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2448, v_x_2457}), v_j_2458});
          return heff_tag_at_n(v_ru_24x3_2446_24Just, TAG_Just, 1, (V[]){v_t_2459});
        }
        default: return heff_nomatch(v_x31_2456);
        }
      }
      default: return heff_nomatch(v_x3_2455);
      }
    }
    default: return heff_nomatch(v_x31_2447);
    }
  }
  default: return heff_nomatch(v_x3_2446);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam5(V self, V *args) {
  V v_s_2462 = args[0];
  V v_i_2463 = args[1];
  V v_m_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2464 = heff_tr(heff_apply(v_m_2461, 2, (V[]){v_s_2462, v_i_2463}));
  switch (heff_tag_of(v_x3_2464)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2465 = heff_field(v_x3_2464, 0);
    V v_ru_24x3_2464_24Just = heff_take_reuse_n(v_x3_2464, 1ULL, 1);
    switch (heff_tag_of(v_x31_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x31_2465, 0);
      V v_j_2467 = heff_field(v_x31_2465, 1);
      V v_ru_24x31_2465_24MkPair = heff_take_reuse_n(v_x31_2465, 3ULL, 2);
      V v_t_2468 = heff_tag_at_n(v_ru_24x31_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2464_24Just, TAG_SCons, 1, (V[]){v_x_2466}), v_j_2467});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2468});
    }
    default: return heff_nomatch(v_x31_2465);
    }
  }
  default: return heff_nomatch(v_x3_2464);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam6(V self, V *args) {
  V v_s_2470 = args[0];
  V v_i_2471 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2472 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_s_2470), v_i_2471}));
  switch (heff_tag_of(v_x3_2472)) {
  case TAG_Nothing: {
    heff_drop(v_s_2470);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2473 = heff_field(v_x3_2472, 0);
    V v_ru_24x3_2472_24Just = heff_take_reuse_n(v_x3_2472, 1ULL, 1);
    switch (heff_tag_of(v_x31_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x31_2473, 0);
      V v_j_2475 = heff_field(v_x31_2473, 1);
      V v_ru_24x31_2473_24MkPair = heff_take_reuse_n(v_x31_2473, 3ULL, 2);
      V v_x3_2476 = (g_heff_2ebuild_2edecoder_2estr(v_s_2470, v_j_2475));
      switch (heff_tag_of(v_x3_2476)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2472_24Just, 1);
        heff_drop(v_x_2474);
        heff_drop_cell(v_ru_24x31_2473_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2477 = heff_field(v_x3_2476, 0);
        heff_take_n(v_x3_2476, 1ULL, 1);
        switch (heff_tag_of(v_x31_2477)) {
        case TAG_MkPair: {
          V v_x_2478 = heff_field(v_x31_2477, 0);
          V v_j_2479 = heff_field(v_x31_2477, 1);
          heff_take_n(v_x31_2477, 3ULL, 2);
          V v_t_2480 = heff_tag_at_n(v_ru_24x31_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2474, v_x_2478}), v_j_2479});
          return heff_tag_at_n(v_ru_24x3_2472_24Just, TAG_Just, 1, (V[]){v_t_2480});
        }
        default: return heff_nomatch(v_x31_2477);
        }
      }
      default: return heff_nomatch(v_x3_2476);
      }
    }
    default: return heff_nomatch(v_x31_2473);
    }
  }
  default: return heff_nomatch(v_x3_2472);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam7(V self, V *args) {
  V v_s_2482 = args[0];
  V v_i_2483 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2484 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_2482), v_i_2483));
  switch (heff_tag_of(v_x3_2484)) {
  case TAG_Nothing: {
    heff_drop(v_s_2482);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2485 = heff_field(v_x3_2484, 0);
    V v_ru_24x3_2484_24Just = heff_take_reuse_n(v_x3_2484, 1ULL, 1);
    switch (heff_tag_of(v_x31_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x31_2485, 0);
      V v_j_2487 = heff_field(v_x31_2485, 1);
      V v_ru_24x31_2485_24MkPair = heff_take_reuse_n(v_x31_2485, 3ULL, 2);
      V v_t_2488 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 1, (V[]){heff_get_n(v_k_240, 0, 2)}));
      V v_m_2489 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo), 1, (V[]){v_t_2488}));
      V v_x3_2490 = heff_tr(heff_apply(v_m_2489, 2, (V[]){v_s_2482, v_j_2487}));
      switch (heff_tag_of(v_x3_2490)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2484_24Just, 1);
        heff_drop(v_x_2486);
        heff_drop_cell(v_ru_24x31_2485_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2491 = heff_field(v_x3_2490, 0);
        heff_take_n(v_x3_2490, 1ULL, 1);
        switch (heff_tag_of(v_x31_2491)) {
        case TAG_MkPair: {
          V v_x_2492 = heff_field(v_x31_2491, 0);
          V v_j_2493 = heff_field(v_x31_2491, 1);
          heff_take_n(v_x31_2491, 3ULL, 2);
          V v_t_2494 = heff_tag_at_n(v_ru_24x31_2485_24MkPair, TAG_STag, 2, (V[]){v_x_2486, heff_arrayFromList(v_x_2492)});
          return heff_tag_at_n(v_ru_24x3_2484_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_j_2493})});
        }
        default: return heff_nomatch(v_x31_2491);
        }
      }
      default: return heff_nomatch(v_x3_2490);
      }
    }
    default: return heff_nomatch(v_x31_2485);
    }
  }
  default: return heff_nomatch(v_x3_2484);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam8(V self, V *args) {
  V v_s_2496 = args[0];
  V v_i_2497 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2498 = heff_tr(heff_apply(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_s_2496), v_i_2497}));
  switch (heff_tag_of(v_x3_2498)) {
  case TAG_Nothing: {
    heff_drop(v_s_2496);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2499 = heff_field(v_x3_2498, 0);
    V v_ru_24x3_2498_24Just = heff_take_reuse_n(v_x3_2498, 1ULL, 1);
    switch (heff_tag_of(v_x31_2499)) {
    case TAG_MkPair: {
      V v_x_24100 = heff_field(v_x31_2499, 0);
      V v_j_24101 = heff_field(v_x31_2499, 1);
      V v_ru_24x31_2499_24MkPair = heff_take_reuse_n(v_x31_2499, 3ULL, 2);
      V v_t_24102 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
      V v_m_24103 = (g_heff_2ebuild_2eserial_2etakeDict(v_t_24102));
      V v_x3_24104 = heff_tr(heff_apply(v_m_24103, 2, (V[]){v_s_2496, v_j_24101}));
      switch (heff_tag_of(v_x3_24104)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2498_24Just, 1);
        heff_drop(v_x_24100);
        heff_drop_cell(v_ru_24x31_2499_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24105 = heff_field(v_x3_24104, 0);
        heff_take_n(v_x3_24104, 1ULL, 1);
        switch (heff_tag_of(v_x31_24105)) {
        case TAG_MkPair: {
          V v_x_24106 = heff_field(v_x31_24105, 0);
          V v_j_24107 = heff_field(v_x31_24105, 1);
          heff_take_n(v_x31_24105, 3ULL, 2);
          V v_t_24108 = heff_tag_at_n(v_ru_24x31_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24100, v_x_24106}), v_j_24107});
          return heff_tag_at_n(v_ru_24x3_2498_24Just, TAG_Just, 1, (V[]){v_t_24108});
        }
        default: return heff_nomatch(v_x31_24105);
        }
      }
      default: return heff_nomatch(v_x3_24104);
      }
    }
    default: return heff_nomatch(v_x31_2499);
    }
  }
  default: return heff_nomatch(v_x3_2498);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam9(V self, V *args) {
  V v_s_24110 = args[0];
  V v_i_24111 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24112 = heff_tr(heff_apply(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_s_24110), v_i_24111}));
  switch (heff_tag_of(v_x3_24112)) {
  case TAG_Nothing: {
    heff_drop(v_s_24110);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24113 = heff_field(v_x3_24112, 0);
    V v_ru_24x3_24112_24Just = heff_take_reuse_n(v_x3_24112, 1ULL, 1);
    switch (heff_tag_of(v_x31_24113)) {
    case TAG_MkPair: {
      V v_x_24114 = heff_field(v_x31_24113, 0);
      V v_j_24115 = heff_field(v_x31_24113, 1);
      V v_ru_24x31_24113_24MkPair = heff_take_reuse_n(v_x31_24113, 3ULL, 2);
      V v_x3_24116 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_24110), v_j_24115));
      switch (heff_tag_of(v_x3_24116)) {
      case TAG_Nothing: {
        heff_drop(v_s_24110);
        heff_drop_rec(v_k_240, 2);
        heff_drop_cell(v_ru_24x3_24112_24Just, 1);
        heff_drop(v_x_24114);
        heff_drop_cell(v_ru_24x31_24113_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24117 = heff_field(v_x3_24116, 0);
        heff_take_n(v_x3_24116, 1ULL, 1);
        switch (heff_tag_of(v_x31_24117)) {
        case TAG_MkPair: {
          V v_x_24118 = heff_field(v_x31_24117, 0);
          V v_j_24119 = heff_field(v_x31_24117, 1);
          heff_take_n(v_x31_24117, 3ULL, 2);
          V v_x3_24120 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_24110, v_j_24119}));
          switch (heff_tag_of(v_x3_24120)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_24112_24Just, 1);
            heff_drop(v_x_24114);
            heff_drop_cell(v_ru_24x31_24113_24MkPair, 2);
            heff_drop(v_x_24118);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_24121 = heff_field(v_x3_24120, 0);
            heff_take_n(v_x3_24120, 1ULL, 1);
            switch (heff_tag_of(v_x31_24121)) {
            case TAG_MkPair: {
              V v_x_24122 = heff_field(v_x31_24121, 0);
              V v_j_24123 = heff_field(v_x31_24121, 1);
              heff_take_n(v_x31_24121, 3ULL, 2);
              V v_t_24124 = heff_tag_at_n(v_ru_24x31_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24114, v_x_24118, v_x_24122}), v_j_24123});
              return heff_tag_at_n(v_ru_24x3_24112_24Just, TAG_Just, 1, (V[]){v_t_24124});
            }
            default: return heff_nomatch(v_x31_24121);
            }
          }
          default: return heff_nomatch(v_x3_24120);
          }
        }
        default: return heff_nomatch(v_x31_24117);
        }
      }
      default: return heff_nomatch(v_x3_24116);
      }
    }
    default: return heff_nomatch(v_x31_24113);
    }
  }
  default: return heff_nomatch(v_x3_24112);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam10(V self, V *args) {
  V v_s_24126 = args[0];
  V v_i_24127 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24128 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_24126, v_i_24127}));
  switch (heff_tag_of(v_x3_24128)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24129 = heff_field(v_x3_24128, 0);
    V v_ru_24x3_24128_24Just = heff_take_reuse_n(v_x3_24128, 1ULL, 1);
    switch (heff_tag_of(v_x31_24129)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_field(v_x31_24129, 0);
      V v_j_24131 = heff_field(v_x31_24129, 1);
      V v_ru_24x31_24129_24MkPair = heff_take_reuse_n(v_x31_24129, 3ULL, 2);
      V v_t_24132 = heff_tag_at_n(v_ru_24x31_24129_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24128_24Just, TAG_SIs, 1, (V[]){v_x_24130}), v_j_24131});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24132});
    }
    default: return heff_nomatch(v_x31_24129);
    }
  }
  default: return heff_nomatch(v_x3_24128);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam11(V self, V *args) {
  V v_s_24134 = args[0];
  V v_i_24135 = args[1];
  heff_drop(v_s_24134);
  V v_t_24136 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_i_24135});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24136});
}
V g_heff_2ebuild_2eserial_2etermOf_lam12(V self, V *args) {
  V v_s_24138 = args[0];
  V v_i_24139 = args[1];
  heff_drop(v_s_24138);
  V v_t_24140 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_i_24139});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24140});
}
V g_heff_2ebuild_2eserial_2etermOf_lam13(V self, V *args) {
  V v_s_24142 = args[0];
  V v_i_24143 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24144 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_24142, v_i_24143}));
  switch (heff_tag_of(v_x3_24144)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24145 = heff_field(v_x3_24144, 0);
    V v_ru_24x3_24144_24Just = heff_take_reuse_n(v_x3_24144, 1ULL, 1);
    switch (heff_tag_of(v_x31_24145)) {
    case TAG_MkPair: {
      V v_x_24146 = heff_field(v_x31_24145, 0);
      V v_j_24147 = heff_field(v_x31_24145, 1);
      V v_ru_24x31_24145_24MkPair = heff_take_reuse_n(v_x31_24145, 3ULL, 2);
      V v_t_24148 = heff_tag_at_n(v_ru_24x31_24145_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24144_24Just, TAG_SRec, 1, (V[]){v_x_24146}), v_j_24147});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24148});
    }
    default: return heff_nomatch(v_x31_24145);
    }
  }
  default: return heff_nomatch(v_x3_24144);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam14(V self, V *args) {
  V v_s_24150 = args[0];
  V v_i_24151 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24152 = heff_tr(heff_apply(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_s_24150), v_i_24151}));
  switch (heff_tag_of(v_x3_24152)) {
  case TAG_Nothing: {
    heff_drop(v_s_24150);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24153 = heff_field(v_x3_24152, 0);
    V v_ru_24x3_24152_24Just = heff_take_reuse_n(v_x3_24152, 1ULL, 1);
    switch (heff_tag_of(v_x31_24153)) {
    case TAG_MkPair: {
      V v_x_24154 = heff_field(v_x31_24153, 0);
      V v_j_24155 = heff_field(v_x31_24153, 1);
      V v_ru_24x31_24153_24MkPair = heff_take_reuse_n(v_x31_24153, 3ULL, 2);
      V v_x3_24156 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24150), v_j_24155));
      V v_x3_24161;
      switch (heff_tag_of(v_x3_24156)) {
      case TAG_Nothing: {
        heff_drop(v_s_24150);
        heff_drop_rec(v_k_240, 2);
        v_x3_24161 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_24157 = heff_field(v_x3_24156, 0);
        heff_take_n(v_x3_24156, 1ULL, 1);
        switch (heff_tag_of(v_x31_24157)) {
        case TAG_MkPair: {
          V v_x_24158 = heff_field(v_x31_24157, 0);
          V v_j_24159 = heff_field(v_x31_24157, 1);
          heff_take_n(v_x31_24157, 3ULL, 2);
          V v_t_24160 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_24158));
          v_x3_24161 = heff_tr(heff_apply(v_t_24160, 2, (V[]){v_s_24150, v_j_24159}));
          break;
        }
        default: heff_nomatch(v_x31_24157);
        }
        break;
      }
      default: heff_nomatch(v_x3_24156);
      }
      switch (heff_tag_of(v_x3_24161)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24152_24Just, 1);
        heff_drop(v_x_24154);
        heff_drop_cell(v_ru_24x31_24153_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24162 = heff_field(v_x3_24161, 0);
        heff_take_n(v_x3_24161, 1ULL, 1);
        switch (heff_tag_of(v_x31_24162)) {
        case TAG_MkPair: {
          V v_x_24163 = heff_field(v_x31_24162, 0);
          V v_j_24164 = heff_field(v_x31_24162, 1);
          heff_take_n(v_x31_24162, 3ULL, 2);
          V v_t_24165 = heff_tag_at_n(v_ru_24x31_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24154, v_x_24163}), v_j_24164});
          return heff_tag_at_n(v_ru_24x3_24152_24Just, TAG_Just, 1, (V[]){v_t_24165});
        }
        default: return heff_nomatch(v_x31_24162);
        }
      }
      default: return heff_nomatch(v_x3_24161);
      }
    }
    default: return heff_nomatch(v_x31_24153);
    }
  }
  default: return heff_nomatch(v_x3_24152);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam15(V self, V *args) {
  V v_s_24167 = args[0];
  V v_i_24168 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24169 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_24167), v_i_24168));
  switch (heff_tag_of(v_x3_24169)) {
  case TAG_Nothing: {
    heff_drop(v_s_24167);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24170 = heff_field(v_x3_24169, 0);
    V v_ru_24x3_24169_24Just = heff_take_reuse_n(v_x3_24169, 1ULL, 1);
    switch (heff_tag_of(v_x31_24170)) {
    case TAG_MkPair: {
      V v_x_24171 = heff_field(v_x31_24170, 0);
      V v_j_24172 = heff_field(v_x31_24170, 1);
      V v_ru_24x31_24170_24MkPair = heff_take_reuse_n(v_x31_24170, 3ULL, 2);
      V v_x3_24173 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_24167, v_j_24172}));
      switch (heff_tag_of(v_x3_24173)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24169_24Just, 1);
        heff_drop(v_x_24171);
        heff_drop_cell(v_ru_24x31_24170_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24174 = heff_field(v_x3_24173, 0);
        heff_take_n(v_x3_24173, 1ULL, 1);
        switch (heff_tag_of(v_x31_24174)) {
        case TAG_MkPair: {
          V v_x_24175 = heff_field(v_x31_24174, 0);
          V v_j_24176 = heff_field(v_x31_24174, 1);
          heff_take_n(v_x31_24174, 3ULL, 2);
          V v_t_24177 = heff_tag_at_n(v_ru_24x31_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24171, v_x_24175}), v_j_24176});
          return heff_tag_at_n(v_ru_24x3_24169_24Just, TAG_Just, 1, (V[]){v_t_24177});
        }
        default: return heff_nomatch(v_x31_24174);
        }
      }
      default: return heff_nomatch(v_x3_24173);
      }
    }
    default: return heff_nomatch(v_x31_24170);
    }
  }
  default: return heff_nomatch(v_x3_24169);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam16(V self, V *args) {
  V v_s_24179 = args[0];
  V v_i_24180 = args[1];
  V v_x3_24181 = (g_heff_2ebuild_2edecoder_2estr(v_s_24179, v_i_24180));
  switch (heff_tag_of(v_x3_24181)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24182 = heff_field(v_x3_24181, 0);
    V v_ru_24x3_24181_24Just = heff_take_reuse_n(v_x3_24181, 1ULL, 1);
    switch (heff_tag_of(v_x31_24182)) {
    case TAG_MkPair: {
      V v_x_24183 = heff_field(v_x31_24182, 0);
      V v_j_24184 = heff_field(v_x31_24182, 1);
      V v_ru_24x31_24182_24MkPair = heff_take_reuse_n(v_x31_24182, 3ULL, 2);
      V v_t_24185 = heff_tag_at_n(v_ru_24x31_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24181_24Just, TAG_SPrim, 1, (V[]){v_x_24183}), v_j_24184});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24185});
    }
    default: return heff_nomatch(v_x31_24182);
    }
  }
  default: return heff_nomatch(v_x3_24181);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam17(V self, V *args) {
  V v_s_24187 = args[0];
  V v_i_24188 = args[1];
  V v_x3_24189 = (g_heff_2ebuild_2edecoder_2estr(v_s_24187, v_i_24188));
  switch (heff_tag_of(v_x3_24189)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24190 = heff_field(v_x3_24189, 0);
    V v_ru_24x3_24189_24Just = heff_take_reuse_n(v_x3_24189, 1ULL, 1);
    switch (heff_tag_of(v_x31_24190)) {
    case TAG_MkPair: {
      V v_x_24191 = heff_field(v_x31_24190, 0);
      V v_j_24192 = heff_field(v_x31_24190, 1);
      V v_ru_24x31_24190_24MkPair = heff_take_reuse_n(v_x31_24190, 3ULL, 2);
      V v_x_24193 = heff_tag_at_n(v_ru_24x3_24189_24Just, TAG_SLitInt, 1, (V[]){(g_heff_2esyntax_2esurface_2eintOfText(v_x_24191))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24190_24MkPair, TAG_MkPair, 2, (V[]){v_x_24193, v_j_24192})});
    }
    default: return heff_nomatch(v_x31_24190);
    }
  }
  default: return heff_nomatch(v_x3_24189);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam18(V self, V *args) {
  V v_s_24195 = args[0];
  V v_i_24196 = args[1];
  V v_x3_24197 = (g_heff_2ebuild_2edecoder_2estr(v_s_24195, v_i_24196));
  switch (heff_tag_of(v_x3_24197)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24198 = heff_field(v_x3_24197, 0);
    V v_ru_24x3_24197_24Just = heff_take_reuse_n(v_x3_24197, 1ULL, 1);
    switch (heff_tag_of(v_x31_24198)) {
    case TAG_MkPair: {
      V v_x_24199 = heff_field(v_x31_24198, 0);
      V v_j_24200 = heff_field(v_x31_24198, 1);
      V v_ru_24x31_24198_24MkPair = heff_take_reuse_n(v_x31_24198, 3ULL, 2);
      V v_x2_24201 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_str19), v_x_24199, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_24204;
      switch (heff_tag_of(v_x2_24201)) {
      case TAG_Nil: {
        v_t_24204 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_24202 = heff_field(v_x2_24201, 0);
        V v_xs_24203 = heff_field(v_x2_24201, 1);
        heff_take_n(v_x2_24201, 3ULL, 2);
        v_t_24204 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str21); V a_1 = v_x_24202; V a_2 = v_xs_24203; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24203); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24201);
      }
      V v_x_24205 = heff_tag_at_n(v_ru_24x3_24197_24Just, TAG_SLitFloat, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24204))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24198_24MkPair, TAG_MkPair, 2, (V[]){v_x_24205, v_j_24200})});
    }
    default: return heff_nomatch(v_x31_24198);
    }
  }
  default: return heff_nomatch(v_x3_24197);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam19(V self, V *args) {
  V v_s_24207 = args[0];
  V v_i_24208 = args[1];
  V v_x3_24209 = (g_heff_2ebuild_2edecoder_2estr(v_s_24207, v_i_24208));
  switch (heff_tag_of(v_x3_24209)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24210 = heff_field(v_x3_24209, 0);
    V v_ru_24x3_24209_24Just = heff_take_reuse_n(v_x3_24209, 1ULL, 1);
    switch (heff_tag_of(v_x31_24210)) {
    case TAG_MkPair: {
      V v_x_24211 = heff_field(v_x31_24210, 0);
      V v_j_24212 = heff_field(v_x31_24210, 1);
      V v_ru_24x31_24210_24MkPair = heff_take_reuse_n(v_x31_24210, 3ULL, 2);
      V v_t_24213 = heff_tag_at_n(v_ru_24x31_24210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24209_24Just, TAG_SLitString, 1, (V[]){v_x_24211}), v_j_24212});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24213});
    }
    default: return heff_nomatch(v_x31_24210);
    }
  }
  default: return heff_nomatch(v_x3_24209);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam20(V self, V *args) {
  V v_s_24215 = args[0];
  V v_i_24216 = args[1];
  V v_x3_24217 = (g_heff_2ebuild_2edecoder_2estr(v_s_24215, v_i_24216));
  switch (heff_tag_of(v_x3_24217)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24218 = heff_field(v_x3_24217, 0);
    V v_ru_24x3_24217_24Just = heff_take_reuse_n(v_x3_24217, 1ULL, 1);
    switch (heff_tag_of(v_x31_24218)) {
    case TAG_MkPair: {
      V v_x_24219 = heff_field(v_x31_24218, 0);
      V v_j_24220 = heff_field(v_x31_24218, 1);
      V v_ru_24x31_24218_24MkPair = heff_take_reuse_n(v_x31_24218, 3ULL, 2);
      V v_x_24221 = heff_tag_at_n(v_ru_24x3_24217_24Just, TAG_SLitRune, 1, (V[]){(g_heff_2esyntax_2esurface_2eintOfText(v_x_24219))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24218_24MkPair, TAG_MkPair, 2, (V[]){v_x_24221, v_j_24220})});
    }
    default: return heff_nomatch(v_x31_24218);
    }
  }
  default: return heff_nomatch(v_x3_24217);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam21(V self, V *args) {
  V v_s_24223 = args[0];
  V v_i_24224 = args[1];
  V v_x3_24225 = (g_heff_2ebuild_2eserial_2etakeFixed(heff_dup(v_s_24223), v_i_24224));
  switch (heff_tag_of(v_x3_24225)) {
  case TAG_Nothing: {
    heff_drop(v_s_24223);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24226 = heff_field(v_x3_24225, 0);
    V v_ru_24x3_24225_24Just = heff_take_reuse_n(v_x3_24225, 1ULL, 1);
    switch (heff_tag_of(v_x31_24226)) {
    case TAG_MkPair: {
      V v_x_24227 = heff_field(v_x31_24226, 0);
      V v_j_24228 = heff_field(v_x31_24226, 1);
      V v_ru_24x31_24226_24MkPair = heff_take_reuse_n(v_x31_24226, 3ULL, 2);
      V v_x3_24229 = (g_heff_2ebuild_2edecoder_2estr(v_s_24223, v_j_24228));
      switch (heff_tag_of(v_x3_24229)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24225_24Just, 1);
        heff_drop(v_x_24227);
        heff_drop_cell(v_ru_24x31_24226_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24230 = heff_field(v_x3_24229, 0);
        heff_take_n(v_x3_24229, 1ULL, 1);
        switch (heff_tag_of(v_x31_24230)) {
        case TAG_MkPair: {
          V v_x_24231 = heff_field(v_x31_24230, 0);
          V v_j_24232 = heff_field(v_x31_24230, 1);
          heff_take_n(v_x31_24230, 3ULL, 2);
          V v_x_24233 = heff_tag_at_n(v_ru_24x31_24226_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24227, (g_heff_2esyntax_2esurface_2eintOfText(v_x_24231))});
          return heff_tag_at_n(v_ru_24x3_24225_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24233, v_j_24232})});
        }
        default: return heff_nomatch(v_x31_24230);
        }
      }
      default: return heff_nomatch(v_x3_24229);
      }
    }
    default: return heff_nomatch(v_x31_24226);
    }
  }
  default: return heff_nomatch(v_x3_24225);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_lam22(V self, V *args) {
  V v_s_24235 = args[0];
  V v_i_24236 = args[1];
  V v_x3_24237 = (g_heff_2ebuild_2edecoder_2estr(v_s_24235, v_i_24236));
  switch (heff_tag_of(v_x3_24237)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24238 = heff_field(v_x3_24237, 0);
    V v_ru_24x3_24237_24Just = heff_take_reuse_n(v_x3_24237, 1ULL, 1);
    switch (heff_tag_of(v_x31_24238)) {
    case TAG_MkPair: {
      V v_x_24239 = heff_field(v_x31_24238, 0);
      V v_j_24240 = heff_field(v_x31_24238, 1);
      V v_ru_24x31_24238_24MkPair = heff_take_reuse_n(v_x31_24238, 3ULL, 2);
      V v_x2_24241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_str26), v_x_24239, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_24244;
      switch (heff_tag_of(v_x2_24241)) {
      case TAG_Nil: {
        v_t_24244 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_24242 = heff_field(v_x2_24241, 0);
        V v_xs_24243 = heff_field(v_x2_24241, 1);
        heff_take_n(v_x2_24241, 3ULL, 2);
        v_t_24244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str28); V a_1 = v_x_24242; V a_2 = v_xs_24243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24243); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24241);
      }
      V v_x_24245 = heff_tag_at_n(v_ru_24x3_24237_24Just, TAG_SLitFloat32, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24244))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24238_24MkPair, TAG_MkPair, 2, (V[]){v_x_24245, v_j_24240})});
    }
    default: return heff_nomatch(v_x31_24238);
    }
  }
  default: return heff_nomatch(v_x3_24237);
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2edefaultOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str0))) {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ebuild_2eserial_2edefaultOf_lam0, 2, 1, (V[]){v_k_240});
  } else {
    heff_drop_rec(v_k_240, 2);
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str1))) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2edefaultOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_245 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_243, v_i_244}));
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_x_247}), v_j_248});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_2412 = args[1];
  heff_drop(v_s_2411);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2412});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str11, 2, "px");
V g_heff_2ebuild_2eserial_2etypeOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam1(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam2(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam3(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam4(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam5(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam6(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_lam6, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_lam7(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_lam7, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_lam8(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_lam8, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_lam9(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_lam9, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_lam10(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_lam11(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_lam11, 2, 0};
Clo g_heff_2ebuild_2eserial_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etypeOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str0))) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo);
  } else {
    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str1))) {
      heff_drop(v_x2_241);
      return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam0, 2, 1, (V[]){v_k_240});
    } else {
      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str2))) {
        heff_drop(v_x2_241);
        return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam1, 2, 1, (V[]){v_k_240});
      } else {
        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str3))) {
          heff_drop(v_x2_241);
          return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam2, 2, 1, (V[]){v_k_240});
        } else {
          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str4))) {
            heff_drop(v_x2_241);
            V v_t_2461 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 1, (V[]){heff_get_n(v_k_240, 1, 2)}));
            V v_m_2462 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo), 1, (V[]){v_t_2461}));
            V v_m_2470 = (g_heff_2ebuild_2eserial_2etakeDict(heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam3, 2, 1, (V[]){v_m_2462})));
            return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam4, 2, 1, (V[]){v_m_2470});
          } else {
            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str5))) {
              heff_drop(v_x2_241);
              return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam5, 2, 1, (V[]){v_k_240});
            } else {
              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str6))) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_x2_241);
                return ((V)&g_heff_2ebuild_2eserial_2etypeOf_lam6_clo);
              } else {
                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str7))) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_x2_241);
                  return ((V)&g_heff_2ebuild_2eserial_2etypeOf_lam7_clo);
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str8))) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_x2_241);
                    return ((V)&g_heff_2ebuild_2eserial_2etypeOf_lam8_clo);
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str9))) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_x2_241);
                      return ((V)&g_heff_2ebuild_2eserial_2etypeOf_lam9_clo);
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str10))) {
                        heff_drop(v_x2_241);
                        return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_lam10, 2, 1, (V[]){v_k_240});
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_str11))) {
                          return ((V)&g_heff_2ebuild_2eserial_2etypeOf_lam11_clo);
                        } else {
                          return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2etypeOf_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_i_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = heff_tr(heff_apply(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_244, v_i_245}));
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_246_24Just, TAG_SDecode, 1, (V[]){v_x_248}), v_j_249});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_i_2413 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2414 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_s_2412), v_i_2413));
  switch (heff_tag_of(v_x3_2414)) {
  case TAG_Nothing: {
    heff_drop(v_s_2412);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2415 = heff_field(v_x3_2414, 0);
    V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
    switch (heff_tag_of(v_x31_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x31_2415, 0);
      V v_j_2417 = heff_field(v_x31_2415, 1);
      V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
      V v_x3_2418 = heff_tr(heff_apply(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_s_2412), v_j_2417}));
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_Nothing: {
        heff_drop(v_s_2412);
        heff_drop_rec(v_k_240, 2);
        heff_drop_cell(v_ru_24x3_2414_24Just, 1);
        heff_drop(v_x_2416);
        heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2419 = heff_field(v_x3_2418, 0);
        heff_take_n(v_x3_2418, 1ULL, 1);
        switch (heff_tag_of(v_x31_2419)) {
        case TAG_MkPair: {
          V v_x_2420 = heff_field(v_x31_2419, 0);
          V v_j_2421 = heff_field(v_x31_2419, 1);
          heff_take_n(v_x31_2419, 3ULL, 2);
          V v_x3_2422 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2412), v_j_2421));
          V v_x3_2427;
          switch (heff_tag_of(v_x3_2422)) {
          case TAG_Nothing: {
            v_x3_2427 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2423 = heff_field(v_x3_2422, 0);
            heff_take_n(v_x3_2422, 1ULL, 1);
            switch (heff_tag_of(v_x31_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_x31_2423, 0);
              V v_j_2425 = heff_field(v_x31_2423, 1);
              heff_take_n(v_x31_2423, 3ULL, 2);
              V v_t_2426 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(v_k_240, 1)), v_x_2424));
              v_x3_2427 = heff_tr(heff_apply(v_t_2426, 2, (V[]){heff_dup(v_s_2412), v_j_2425}));
              break;
            }
            default: heff_nomatch(v_x31_2423);
            }
            break;
          }
          default: heff_nomatch(v_x3_2422);
          }
          switch (heff_tag_of(v_x3_2427)) {
          case TAG_Nothing: {
            heff_drop(v_s_2412);
            heff_drop_rec(v_k_240, 2);
            heff_drop_cell(v_ru_24x3_2414_24Just, 1);
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
            heff_drop(v_x_2420);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2428 = heff_field(v_x3_2427, 0);
            heff_take_n(v_x3_2427, 1ULL, 1);
            switch (heff_tag_of(v_x31_2428)) {
            case TAG_MkPair: {
              V v_x_2429 = heff_field(v_x31_2428, 0);
              V v_j_2430 = heff_field(v_x31_2428, 1);
              heff_take_n(v_x31_2428, 3ULL, 2);
              V v_x3_2431 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(heff_dup(v_s_2412), v_j_2430));
              switch (heff_tag_of(v_x3_2431)) {
              case TAG_Nothing: {
                heff_drop(v_s_2412);
                heff_drop_rec(v_k_240, 2);
                heff_drop_cell(v_ru_24x3_2414_24Just, 1);
                heff_drop(v_x_2416);
                heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
                heff_drop(v_x_2420);
                heff_drop(v_x_2429);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2432 = heff_field(v_x3_2431, 0);
                heff_take_n(v_x3_2431, 1ULL, 1);
                switch (heff_tag_of(v_x31_2432)) {
                case TAG_MkPair: {
                  V v_x_2433 = heff_field(v_x31_2432, 0);
                  V v_j_2434 = heff_field(v_x31_2432, 1);
                  heff_take_n(v_x31_2432, 3ULL, 2);
                  V v_t_2435 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                  V v_m_2436 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo), 1, (V[]){v_t_2435}));
                  V v_x3_2437 = heff_tr(heff_apply(v_m_2436, 2, (V[]){v_s_2412, v_j_2434}));
                  switch (heff_tag_of(v_x3_2437)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x3_2414_24Just, 1);
                    heff_drop(v_x_2416);
                    heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
                    heff_drop(v_x_2420);
                    heff_drop(v_x_2429);
                    heff_drop(v_x_2433);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2438 = heff_field(v_x3_2437, 0);
                    heff_take_n(v_x3_2437, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2438)) {
                    case TAG_MkPair: {
                      V v_x_2439 = heff_field(v_x31_2438, 0);
                      V v_j_2440 = heff_field(v_x31_2438, 1);
                      heff_take_n(v_x31_2438, 3ULL, 2);
                      V v_t_2441 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2416, v_x_2420, v_x_2429, v_x_2433, v_x_2439}), v_j_2440});
                      return heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_Just, 1, (V[]){v_t_2441});
                    }
                    default: return heff_nomatch(v_x31_2438);
                    }
                  }
                  default: return heff_nomatch(v_x3_2437);
                  }
                }
                default: return heff_nomatch(v_x31_2432);
                }
              }
              default: return heff_nomatch(v_x3_2431);
              }
            }
            default: return heff_nomatch(v_x31_2428);
            }
          }
          default: return heff_nomatch(v_x3_2427);
          }
        }
        default: return heff_nomatch(v_x31_2419);
        }
      }
      default: return heff_nomatch(v_x3_2418);
      }
    }
    default: return heff_nomatch(v_x31_2415);
    }
  }
  default: return heff_nomatch(v_x3_2414);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam2(V self, V *args) {
  V v_s_2443 = args[0];
  V v_i_2444 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2445 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_s_2443), v_i_2444));
  switch (heff_tag_of(v_x3_2445)) {
  case TAG_Nothing: {
    heff_drop(v_s_2443);
    heff_drop_rec(v_k_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2446 = heff_field(v_x3_2445, 0);
    V v_ru_24x3_2445_24Just = heff_take_reuse_n(v_x3_2445, 1ULL, 1);
    switch (heff_tag_of(v_x31_2446)) {
    case TAG_MkPair: {
      V v_x_2447 = heff_field(v_x31_2446, 0);
      V v_j_2448 = heff_field(v_x31_2446, 1);
      V v_ru_24x31_2446_24MkPair = heff_take_reuse_n(v_x31_2446, 3ULL, 2);
      V v_m_2449 = (g_heff_2ebuild_2eserial_2etakeDict(heff_take_field(v_k_240, 1)));
      V v_x3_2450 = heff_tr(heff_apply(v_m_2449, 2, (V[]){heff_dup(v_s_2443), v_j_2448}));
      switch (heff_tag_of(v_x3_2450)) {
      case TAG_Nothing: {
        heff_drop(v_s_2443);
        heff_drop_rec(v_k_240, 2);
        heff_drop_cell(v_ru_24x3_2445_24Just, 1);
        heff_drop(v_x_2447);
        heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2451 = heff_field(v_x3_2450, 0);
        heff_take_n(v_x3_2450, 1ULL, 1);
        switch (heff_tag_of(v_x31_2451)) {
        case TAG_MkPair: {
          V v_x_2452 = heff_field(v_x31_2451, 0);
          V v_j_2453 = heff_field(v_x31_2451, 1);
          heff_take_n(v_x31_2451, 3ULL, 2);
          V v_m_2454 = (g_heff_2ebuild_2eserial_2etakeDict(heff_get_n(v_k_240, 0, 2)));
          V v_x3_2455 = heff_tr(heff_apply(v_m_2454, 2, (V[]){v_s_2443, v_j_2453}));
          switch (heff_tag_of(v_x3_2455)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_2445_24Just, 1);
            heff_drop(v_x_2447);
            heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
            heff_drop(v_x_2452);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2456 = heff_field(v_x3_2455, 0);
            heff_take_n(v_x3_2455, 1ULL, 1);
            switch (heff_tag_of(v_x31_2456)) {
            case TAG_MkPair: {
              V v_x_2457 = heff_field(v_x31_2456, 0);
              V v_j_2458 = heff_field(v_x31_2456, 1);
              heff_take_n(v_x31_2456, 3ULL, 2);
              V v_t_2459 = heff_tag_at_n(v_ru_24x31_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2447, v_x_2452, v_x_2457}), v_j_2458});
              return heff_tag_at_n(v_ru_24x3_2445_24Just, TAG_Just, 1, (V[]){v_t_2459});
            }
            default: return heff_nomatch(v_x31_2456);
            }
          }
          default: return heff_nomatch(v_x3_2455);
          }
        }
        default: return heff_nomatch(v_x31_2451);
        }
      }
      default: return heff_nomatch(v_x3_2450);
      }
    }
    default: return heff_nomatch(v_x31_2446);
    }
  }
  default: return heff_nomatch(v_x3_2445);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam3(V self, V *args) {
  V v_s_2463 = args[0];
  V v_i_2464 = args[1];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2465 = heff_tr(heff_apply(v_m_2462, 2, (V[]){v_s_2463, v_i_2464}));
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2466 = heff_field(v_x3_2465, 0);
    V v_ru_24x3_2465_24Just = heff_take_reuse_n(v_x3_2465, 1ULL, 1);
    switch (heff_tag_of(v_x31_2466)) {
    case TAG_MkPair: {
      V v_x_2467 = heff_field(v_x31_2466, 0);
      V v_j_2468 = heff_field(v_x31_2466, 1);
      V v_ru_24x31_2466_24MkPair = heff_take_reuse_n(v_x31_2466, 3ULL, 2);
      V v_t_2469 = heff_tag_at_n(v_ru_24x31_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2467), v_j_2468});
      return heff_tag_at_n(v_ru_24x3_2465_24Just, TAG_Just, 1, (V[]){v_t_2469});
    }
    default: return heff_nomatch(v_x31_2466);
    }
  }
  default: return heff_nomatch(v_x3_2465);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam4(V self, V *args) {
  V v_s_2471 = args[0];
  V v_i_2472 = args[1];
  V v_m_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2473 = heff_tr(heff_apply(v_m_2470, 2, (V[]){v_s_2471, v_i_2472}));
  switch (heff_tag_of(v_x3_2473)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2474 = heff_field(v_x3_2473, 0);
    V v_ru_24x3_2473_24Just = heff_take_reuse_n(v_x3_2473, 1ULL, 1);
    switch (heff_tag_of(v_x31_2474)) {
    case TAG_MkPair: {
      V v_x_2475 = heff_field(v_x31_2474, 0);
      V v_j_2476 = heff_field(v_x31_2474, 1);
      V v_ru_24x31_2474_24MkPair = heff_take_reuse_n(v_x31_2474, 3ULL, 2);
      V v_t_2477 = heff_tag_at_n(v_ru_24x31_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2473_24Just, TAG_SSum, 1, (V[]){v_x_2475}), v_j_2476});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2477});
    }
    default: return heff_nomatch(v_x31_2474);
    }
  }
  default: return heff_nomatch(v_x3_2473);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam5(V self, V *args) {
  V v_s_2479 = args[0];
  V v_i_2480 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2481 = heff_tr(heff_apply(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_s_2479, v_i_2480}));
  switch (heff_tag_of(v_x3_2481)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2482 = heff_field(v_x3_2481, 0);
    V v_ru_24x3_2481_24Just = heff_take_reuse_n(v_x3_2481, 1ULL, 1);
    switch (heff_tag_of(v_x31_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x31_2482, 0);
      V v_j_2484 = heff_field(v_x31_2482, 1);
      V v_ru_24x31_2482_24MkPair = heff_take_reuse_n(v_x31_2482, 3ULL, 2);
      V v_t_2485 = heff_tag_at_n(v_ru_24x31_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2481_24Just, TAG_SIsTy, 1, (V[]){v_x_2483}), v_j_2484});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2485});
    }
    default: return heff_nomatch(v_x31_2482);
    }
  }
  default: return heff_nomatch(v_x3_2481);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam6(V self, V *args) {
  V v_s_2487 = args[0];
  V v_i_2488 = args[1];
  heff_drop(v_s_2487);
  V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_i_2488});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2489});
}
V g_heff_2ebuild_2eserial_2etypeOf_lam7(V self, V *args) {
  V v_s_2491 = args[0];
  V v_i_2492 = args[1];
  heff_drop(v_s_2491);
  V v_t_2493 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_i_2492});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2493});
}
V g_heff_2ebuild_2eserial_2etypeOf_lam8(V self, V *args) {
  V v_s_2495 = args[0];
  V v_i_2496 = args[1];
  heff_drop(v_s_2495);
  V v_t_2497 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_i_2496});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2497});
}
V g_heff_2ebuild_2eserial_2etypeOf_lam9(V self, V *args) {
  V v_s_2499 = args[0];
  V v_i_24100 = args[1];
  heff_drop(v_s_2499);
  V v_t_24101 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_i_24100});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24101});
}
V g_heff_2ebuild_2eserial_2etypeOf_lam10(V self, V *args) {
  V v_s_24103 = args[0];
  V v_i_24104 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_24105 = heff_tr(heff_apply(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_s_24103, v_i_24104}));
  switch (heff_tag_of(v_x3_24105)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24106 = heff_field(v_x3_24105, 0);
    V v_ru_24x3_24105_24Just = heff_take_reuse_n(v_x3_24105, 1ULL, 1);
    switch (heff_tag_of(v_x31_24106)) {
    case TAG_MkPair: {
      V v_x_24107 = heff_field(v_x31_24106, 0);
      V v_j_24108 = heff_field(v_x31_24106, 1);
      V v_ru_24x31_24106_24MkPair = heff_take_reuse_n(v_x31_24106, 3ULL, 2);
      V v_t_24109 = heff_tag_at_n(v_ru_24x31_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24105_24Just, TAG_SPrimArray, 1, (V[]){v_x_24107}), v_j_24108});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24109});
    }
    default: return heff_nomatch(v_x31_24106);
    }
  }
  default: return heff_nomatch(v_x3_24105);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_lam11(V self, V *args) {
  V v_s_24111 = args[0];
  V v_i_24112 = args[1];
  V v_x3_24113 = (g_heff_2ebuild_2eserial_2etakeFixed(v_s_24111, v_i_24112));
  switch (heff_tag_of(v_x3_24113)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24114 = heff_field(v_x3_24113, 0);
    V v_ru_24x3_24113_24Just = heff_take_reuse_n(v_x3_24113, 1ULL, 1);
    switch (heff_tag_of(v_x31_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x31_24114, 0);
      V v_j_24116 = heff_field(v_x31_24114, 1);
      V v_ru_24x31_24114_24MkPair = heff_take_reuse_n(v_x31_24114, 3ULL, 2);
      V v_t_24117 = heff_tag_at_n(v_ru_24x31_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24113_24Just, TAG_SFixed, 1, (V[]){v_x_24115}), v_j_24116});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24117});
    }
    default: return heff_nomatch(v_x31_24114);
    }
  }
  default: return heff_nomatch(v_x3_24113);
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static int g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (g_heff_2ebuild_2eserial_2edk_st == 2) return g_heff_2ebuild_2eserial_2edk_val;
  if (g_heff_2ebuild_2eserial_2edk_st == 1) heff_fail("defined by itself");
  g_heff_2ebuild_2eserial_2edk_st = 1;
  g_heff_2ebuild_2eserial_2edk_val = heff_tr(g_heff_2ebuild_2eserial_2edk_init());
  g_heff_2ebuild_2eserial_2edk_st = 2;
  return g_heff_2ebuild_2eserial_2edk_val;
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_k_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_t_247 = (g_heff_2ebuild_2eserial_2etermOf(v_k_242, v_x_245));
      V f_ = v_t_247;
      args[0] = v_s_240;
      args[1] = v_j_246;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_i_249 = args[1];
  V v_k_2410 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  V v_x3_2411 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_248), v_i_249));
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nothing: {
    heff_drop(v_s_248);
    heff_drop(v_k_2410);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2412 = heff_field(v_x3_2411, 0);
    heff_take_n(v_x3_2411, 1ULL, 1);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x31_2412, 0);
      V v_j_2414 = heff_field(v_x31_2412, 1);
      heff_take_n(v_x31_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2ebuild_2eserial_2etypeOf(v_k_2410, v_x_2413));
      V f_ = v_t_2415;
      args[0] = v_s_248;
      args[1] = v_j_2414;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_245));
      V v_x3_2411;
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        v_x3_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_248));
          v_x3_2411 = heff_tr(heff_apply(v_t_2410, 2, (V[]){v_s_240, v_j_249}));
          break;
        }
        default: heff_nomatch(v_x31_247);
        }
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        heff_take_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          heff_take_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_244), v_x_2413});
          return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_j_2414})});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(a[0], a[1]);
}
Clo g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_246 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_244)));
      V v_t_247 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_244));
      V v_t_248 = (g_list_2emap_24s1173914895x100384474(v_x_244));
      V v_x_249 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_246), v_t_247, heff_arrayFromList(v_t_248)});
      return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_j_245})});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str22, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str23, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str24, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str25, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str28, 0, "");
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam1, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam2(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam2, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam3(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam3, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam4(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam4, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam5(V self, V *args);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam6(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam6, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam7(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam7, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam8(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam8, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam9(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam9, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam10(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam10, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam11(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam11, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam12(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam12, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam13(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam13, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam14(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam14, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam15(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam15, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam16(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam16, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam17(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam17, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam18(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam18, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam19(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam19, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam20(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam20, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam21(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam21, 2, 0};
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam22(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam22, 2, 0};
Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry, 1, 0};

V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V v_x2_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str0))) {
    heff_drop(v_x2_240);
    return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam0_clo);
  } else {
    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str1))) {
      heff_drop(v_x2_240);
      return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam1_clo);
    } else {
      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str2))) {
        heff_drop(v_x2_240);
        return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam2_clo);
      } else {
        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str3))) {
          heff_drop(v_x2_240);
          return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam3_clo);
        } else {
          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str4))) {
            heff_drop(v_x2_240);
            return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam4_clo);
          } else {
            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str5))) {
              heff_drop(v_x2_240);
              V v_m_2480 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0))));
              return heff_clo_n(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam5, 2, 1, (V[]){v_m_2480});
            } else {
              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str6))) {
                heff_drop(v_x2_240);
                return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam6_clo);
              } else {
                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str7))) {
                  heff_drop(v_x2_240);
                  return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam7_clo);
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str8))) {
                    heff_drop(v_x2_240);
                    return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam8_clo);
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str9))) {
                      heff_drop(v_x2_240);
                      return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam9_clo);
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str10))) {
                        heff_drop(v_x2_240);
                        return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam10_clo);
                      } else {
                        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str11))) {
                          heff_drop(v_x2_240);
                          return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam11_clo);
                        } else {
                          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str12))) {
                            heff_drop(v_x2_240);
                            return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam12_clo);
                          } else {
                            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str13))) {
                              heff_drop(v_x2_240);
                              return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam13_clo);
                            } else {
                              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str14))) {
                                heff_drop(v_x2_240);
                                return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam14_clo);
                              } else {
                                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str15))) {
                                  heff_drop(v_x2_240);
                                  return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam15_clo);
                                } else {
                                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str16))) {
                                    heff_drop(v_x2_240);
                                    return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam16_clo);
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str17))) {
                                      heff_drop(v_x2_240);
                                      return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam17_clo);
                                    } else {
                                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str18))) {
                                        heff_drop(v_x2_240);
                                        return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam18_clo);
                                      } else {
                                        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str22))) {
                                          heff_drop(v_x2_240);
                                          return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam19_clo);
                                        } else {
                                          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str23))) {
                                            heff_drop(v_x2_240);
                                            return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam20_clo);
                                          } else {
                                            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str24))) {
                                              heff_drop(v_x2_240);
                                              return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam21_clo);
                                            } else {
                                              if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str25))) {
                                                return ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam22_clo);
                                              } else {
                                                return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(a[0]);
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  V v_x3_244 = (g_heff_2ebuild_2edecoder_2eword(v_s_242, v_i_243));
  V v_x3_249;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_x3_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      heff_take_n(v_x31_245, 3ULL, 2);
      V v_x_248 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_246));
      v_x3_249 = heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_j_247})});
      break;
    }
    default: heff_nomatch(v_x31_245);
    }
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2410 = heff_field(v_x3_249, 0);
    V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
    switch (heff_tag_of(v_x31_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x31_2410, 0);
      V v_j_2412 = heff_field(v_x31_2410, 1);
      V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_249_24Just, TAG_SLocal, 1, (V[]){v_x_2411}), v_j_2412});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_x31_2410);
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_i_2416 = args[1];
  V v_x3_2417 = (g_heff_2ebuild_2edecoder_2estr(v_s_2415, v_i_2416));
  switch (heff_tag_of(v_x3_2417)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2418 = heff_field(v_x3_2417, 0);
    V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
    switch (heff_tag_of(v_x31_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x31_2418, 0);
      V v_j_2420 = heff_field(v_x31_2418, 1);
      V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
      V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_SGlobal, 1, (V[]){v_x_2419}), v_j_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    }
    default: return heff_nomatch(v_x31_2418);
    }
  }
  default: return heff_nomatch(v_x3_2417);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_i_2424 = args[1];
  V v_x3_2425 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2423), v_i_2424));
  V v_x3_2430;
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nothing: {
    heff_drop(v_s_2423);
    v_x3_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2426 = heff_field(v_x3_2425, 0);
    heff_take_n(v_x3_2425, 1ULL, 1);
    switch (heff_tag_of(v_x31_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x31_2426, 0);
      V v_j_2428 = heff_field(v_x31_2426, 1);
      heff_take_n(v_x31_2426, 3ULL, 2);
      V v_t_2429 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2427));
      v_x3_2430 = heff_tr(heff_apply(v_t_2429, 2, (V[]){v_s_2423, v_j_2428}));
      break;
    }
    default: heff_nomatch(v_x31_2426);
    }
    break;
  }
  default: heff_nomatch(v_x3_2425);
  }
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2431 = heff_field(v_x3_2430, 0);
    V v_ru_24x3_2430_24Just = heff_take_reuse_n(v_x3_2430, 1ULL, 1);
    switch (heff_tag_of(v_x31_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x31_2431, 0);
      V v_j_2433 = heff_field(v_x31_2431, 1);
      V v_ru_24x31_2431_24MkPair = heff_take_reuse_n(v_x31_2431, 3ULL, 2);
      V v_t_2434 = heff_tag_at_n(v_ru_24x31_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2430_24Just, TAG_SCode, 1, (V[]){v_x_2432}), v_j_2433});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
    }
    default: return heff_nomatch(v_x31_2431);
    }
  }
  default: return heff_nomatch(v_x3_2430);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam3(V self, V *args) {
  V v_s_2436 = args[0];
  V v_i_2437 = args[1];
  V v_x3_2438 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2436), v_i_2437));
  V v_x3_2443;
  switch (heff_tag_of(v_x3_2438)) {
  case TAG_Nothing: {
    v_x3_2443 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2439 = heff_field(v_x3_2438, 0);
    heff_take_n(v_x3_2438, 1ULL, 1);
    switch (heff_tag_of(v_x31_2439)) {
    case TAG_MkPair: {
      V v_x_2440 = heff_field(v_x31_2439, 0);
      V v_j_2441 = heff_field(v_x31_2439, 1);
      heff_take_n(v_x31_2439, 3ULL, 2);
      V v_t_2442 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2440));
      v_x3_2443 = heff_tr(heff_apply(v_t_2442, 2, (V[]){heff_dup(v_s_2436), v_j_2441}));
      break;
    }
    default: heff_nomatch(v_x31_2439);
    }
    break;
  }
  default: heff_nomatch(v_x3_2438);
  }
  switch (heff_tag_of(v_x3_2443)) {
  case TAG_Nothing: {
    heff_drop(v_s_2436);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2444 = heff_field(v_x3_2443, 0);
    V v_ru_24x3_2443_24Just = heff_take_reuse_n(v_x3_2443, 1ULL, 1);
    switch (heff_tag_of(v_x31_2444)) {
    case TAG_MkPair: {
      V v_x_2445 = heff_field(v_x31_2444, 0);
      V v_j_2446 = heff_field(v_x31_2444, 1);
      V v_ru_24x31_2444_24MkPair = heff_take_reuse_n(v_x31_2444, 3ULL, 2);
      V v_x3_2447 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2436), v_j_2446));
      V v_x3_2452;
      switch (heff_tag_of(v_x3_2447)) {
      case TAG_Nothing: {
        heff_drop(v_s_2436);
        v_x3_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2448 = heff_field(v_x3_2447, 0);
        heff_take_n(v_x3_2447, 1ULL, 1);
        switch (heff_tag_of(v_x31_2448)) {
        case TAG_MkPair: {
          V v_x_2449 = heff_field(v_x31_2448, 0);
          V v_j_2450 = heff_field(v_x31_2448, 1);
          heff_take_n(v_x31_2448, 3ULL, 2);
          V v_t_2451 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2449));
          v_x3_2452 = heff_tr(heff_apply(v_t_2451, 2, (V[]){v_s_2436, v_j_2450}));
          break;
        }
        default: heff_nomatch(v_x31_2448);
        }
        break;
      }
      default: heff_nomatch(v_x3_2447);
      }
      switch (heff_tag_of(v_x3_2452)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2443_24Just, 1);
        heff_drop(v_x_2445);
        heff_drop_cell(v_ru_24x31_2444_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2453 = heff_field(v_x3_2452, 0);
        heff_take_n(v_x3_2452, 1ULL, 1);
        switch (heff_tag_of(v_x31_2453)) {
        case TAG_MkPair: {
          V v_x_2454 = heff_field(v_x31_2453, 0);
          V v_j_2455 = heff_field(v_x31_2453, 1);
          heff_take_n(v_x31_2453, 3ULL, 2);
          V v_t_2456 = heff_tag_at_n(v_ru_24x31_2444_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2445, v_x_2454}), v_j_2455});
          return heff_tag_at_n(v_ru_24x3_2443_24Just, TAG_Just, 1, (V[]){v_t_2456});
        }
        default: return heff_nomatch(v_x31_2453);
        }
      }
      default: return heff_nomatch(v_x3_2452);
      }
    }
    default: return heff_nomatch(v_x31_2444);
    }
  }
  default: return heff_nomatch(v_x3_2443);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam4(V self, V *args) {
  V v_s_2458 = args[0];
  V v_i_2459 = args[1];
  V v_x3_2460 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2458), v_i_2459));
  V v_x3_2465;
  switch (heff_tag_of(v_x3_2460)) {
  case TAG_Nothing: {
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2461 = heff_field(v_x3_2460, 0);
    heff_take_n(v_x3_2460, 1ULL, 1);
    switch (heff_tag_of(v_x31_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x31_2461, 0);
      V v_j_2463 = heff_field(v_x31_2461, 1);
      heff_take_n(v_x31_2461, 3ULL, 2);
      V v_t_2464 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2462));
      v_x3_2465 = heff_tr(heff_apply(v_t_2464, 2, (V[]){heff_dup(v_s_2458), v_j_2463}));
      break;
    }
    default: heff_nomatch(v_x31_2461);
    }
    break;
  }
  default: heff_nomatch(v_x3_2460);
  }
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_Nothing: {
    heff_drop(v_s_2458);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2466 = heff_field(v_x3_2465, 0);
    V v_ru_24x3_2465_24Just = heff_take_reuse_n(v_x3_2465, 1ULL, 1);
    switch (heff_tag_of(v_x31_2466)) {
    case TAG_MkPair: {
      V v_x_2467 = heff_field(v_x31_2466, 0);
      V v_j_2468 = heff_field(v_x31_2466, 1);
      V v_ru_24x31_2466_24MkPair = heff_take_reuse_n(v_x31_2466, 3ULL, 2);
      V v_x3_2469 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2458), v_j_2468));
      V v_x3_2474;
      switch (heff_tag_of(v_x3_2469)) {
      case TAG_Nothing: {
        heff_drop(v_s_2458);
        v_x3_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2470 = heff_field(v_x3_2469, 0);
        heff_take_n(v_x3_2469, 1ULL, 1);
        switch (heff_tag_of(v_x31_2470)) {
        case TAG_MkPair: {
          V v_x_2471 = heff_field(v_x31_2470, 0);
          V v_j_2472 = heff_field(v_x31_2470, 1);
          heff_take_n(v_x31_2470, 3ULL, 2);
          V v_t_2473 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_2471));
          v_x3_2474 = heff_tr(heff_apply(v_t_2473, 2, (V[]){v_s_2458, v_j_2472}));
          break;
        }
        default: heff_nomatch(v_x31_2470);
        }
        break;
      }
      default: heff_nomatch(v_x3_2469);
      }
      switch (heff_tag_of(v_x3_2474)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2465_24Just, 1);
        heff_drop(v_x_2467);
        heff_drop_cell(v_ru_24x31_2466_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2475 = heff_field(v_x3_2474, 0);
        heff_take_n(v_x3_2474, 1ULL, 1);
        switch (heff_tag_of(v_x31_2475)) {
        case TAG_MkPair: {
          V v_x_2476 = heff_field(v_x31_2475, 0);
          V v_j_2477 = heff_field(v_x31_2475, 1);
          heff_take_n(v_x31_2475, 3ULL, 2);
          V v_t_2478 = heff_tag_at_n(v_ru_24x31_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2467, v_x_2476}), v_j_2477});
          return heff_tag_at_n(v_ru_24x3_2465_24Just, TAG_Just, 1, (V[]){v_t_2478});
        }
        default: return heff_nomatch(v_x31_2475);
        }
      }
      default: return heff_nomatch(v_x3_2474);
      }
    }
    default: return heff_nomatch(v_x31_2466);
    }
  }
  default: return heff_nomatch(v_x3_2465);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam5(V self, V *args) {
  V v_s_2481 = args[0];
  V v_i_2482 = args[1];
  V v_m_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2483 = heff_tr(heff_apply(v_m_2480, 2, (V[]){v_s_2481, v_i_2482}));
  switch (heff_tag_of(v_x3_2483)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2484 = heff_field(v_x3_2483, 0);
    V v_ru_24x3_2483_24Just = heff_take_reuse_n(v_x3_2483, 1ULL, 1);
    switch (heff_tag_of(v_x31_2484)) {
    case TAG_MkPair: {
      V v_x_2485 = heff_field(v_x31_2484, 0);
      V v_j_2486 = heff_field(v_x31_2484, 1);
      V v_ru_24x31_2484_24MkPair = heff_take_reuse_n(v_x31_2484, 3ULL, 2);
      V v_t_2487 = heff_tag_at_n(v_ru_24x31_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2483_24Just, TAG_SCons, 1, (V[]){v_x_2485}), v_j_2486});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2487});
    }
    default: return heff_nomatch(v_x31_2484);
    }
  }
  default: return heff_nomatch(v_x3_2483);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam6(V self, V *args) {
  V v_s_2489 = args[0];
  V v_i_2490 = args[1];
  V v_x3_2491 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2489), v_i_2490));
  V v_x3_2496;
  switch (heff_tag_of(v_x3_2491)) {
  case TAG_Nothing: {
    v_x3_2496 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2492 = heff_field(v_x3_2491, 0);
    heff_take_n(v_x3_2491, 1ULL, 1);
    switch (heff_tag_of(v_x31_2492)) {
    case TAG_MkPair: {
      V v_x_2493 = heff_field(v_x31_2492, 0);
      V v_j_2494 = heff_field(v_x31_2492, 1);
      heff_take_n(v_x31_2492, 3ULL, 2);
      V v_t_2495 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2493));
      v_x3_2496 = heff_tr(heff_apply(v_t_2495, 2, (V[]){heff_dup(v_s_2489), v_j_2494}));
      break;
    }
    default: heff_nomatch(v_x31_2492);
    }
    break;
  }
  default: heff_nomatch(v_x3_2491);
  }
  switch (heff_tag_of(v_x3_2496)) {
  case TAG_Nothing: {
    heff_drop(v_s_2489);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2497 = heff_field(v_x3_2496, 0);
    V v_ru_24x3_2496_24Just = heff_take_reuse_n(v_x3_2496, 1ULL, 1);
    switch (heff_tag_of(v_x31_2497)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_field(v_x31_2497, 0);
      V v_j_2499 = heff_field(v_x31_2497, 1);
      V v_ru_24x31_2497_24MkPair = heff_take_reuse_n(v_x31_2497, 3ULL, 2);
      V v_x3_24100 = (g_heff_2ebuild_2edecoder_2estr(v_s_2489, v_j_2499));
      switch (heff_tag_of(v_x3_24100)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2496_24Just, 1);
        heff_drop(v_x_2498);
        heff_drop_cell(v_ru_24x31_2497_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24101 = heff_field(v_x3_24100, 0);
        heff_take_n(v_x3_24100, 1ULL, 1);
        switch (heff_tag_of(v_x31_24101)) {
        case TAG_MkPair: {
          V v_x_24102 = heff_field(v_x31_24101, 0);
          V v_j_24103 = heff_field(v_x31_24101, 1);
          heff_take_n(v_x31_24101, 3ULL, 2);
          V v_t_24104 = heff_tag_at_n(v_ru_24x31_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2498, v_x_24102}), v_j_24103});
          return heff_tag_at_n(v_ru_24x3_2496_24Just, TAG_Just, 1, (V[]){v_t_24104});
        }
        default: return heff_nomatch(v_x31_24101);
        }
      }
      default: return heff_nomatch(v_x3_24100);
      }
    }
    default: return heff_nomatch(v_x31_2497);
    }
  }
  default: return heff_nomatch(v_x3_2496);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam7(V self, V *args) {
  V v_s_24106 = args[0];
  V v_i_24107 = args[1];
  V v_x3_24108 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_24106), v_i_24107));
  switch (heff_tag_of(v_x3_24108)) {
  case TAG_Nothing: {
    heff_drop(v_s_24106);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24109 = heff_field(v_x3_24108, 0);
    V v_ru_24x3_24108_24Just = heff_take_reuse_n(v_x3_24108, 1ULL, 1);
    switch (heff_tag_of(v_x31_24109)) {
    case TAG_MkPair: {
      V v_x_24110 = heff_field(v_x31_24109, 0);
      V v_j_24111 = heff_field(v_x31_24109, 1);
      V v_ru_24x31_24109_24MkPair = heff_take_reuse_n(v_x31_24109, 3ULL, 2);
      V v_t_24112 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0))}));
      V v_m_24113 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo), 1, (V[]){v_t_24112}));
      V v_x3_24114 = heff_tr(heff_apply(v_m_24113, 2, (V[]){v_s_24106, v_j_24111}));
      switch (heff_tag_of(v_x3_24114)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24108_24Just, 1);
        heff_drop(v_x_24110);
        heff_drop_cell(v_ru_24x31_24109_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24115 = heff_field(v_x3_24114, 0);
        heff_take_n(v_x3_24114, 1ULL, 1);
        switch (heff_tag_of(v_x31_24115)) {
        case TAG_MkPair: {
          V v_x_24116 = heff_field(v_x31_24115, 0);
          V v_j_24117 = heff_field(v_x31_24115, 1);
          heff_take_n(v_x31_24115, 3ULL, 2);
          V v_t_24118 = heff_tag_at_n(v_ru_24x31_24109_24MkPair, TAG_STag, 2, (V[]){v_x_24110, heff_arrayFromList(v_x_24116)});
          return heff_tag_at_n(v_ru_24x3_24108_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24118, v_j_24117})});
        }
        default: return heff_nomatch(v_x31_24115);
        }
      }
      default: return heff_nomatch(v_x3_24114);
      }
    }
    default: return heff_nomatch(v_x31_24109);
    }
  }
  default: return heff_nomatch(v_x3_24108);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam8(V self, V *args) {
  V v_s_24120 = args[0];
  V v_i_24121 = args[1];
  V v_x3_24122 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24120), v_i_24121));
  V v_x3_24127;
  switch (heff_tag_of(v_x3_24122)) {
  case TAG_Nothing: {
    v_x3_24127 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24123 = heff_field(v_x3_24122, 0);
    heff_take_n(v_x3_24122, 1ULL, 1);
    switch (heff_tag_of(v_x31_24123)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_x31_24123, 0);
      V v_j_24125 = heff_field(v_x31_24123, 1);
      heff_take_n(v_x31_24123, 3ULL, 2);
      V v_t_24126 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24124));
      v_x3_24127 = heff_tr(heff_apply(v_t_24126, 2, (V[]){heff_dup(v_s_24120), v_j_24125}));
      break;
    }
    default: heff_nomatch(v_x31_24123);
    }
    break;
  }
  default: heff_nomatch(v_x3_24122);
  }
  switch (heff_tag_of(v_x3_24127)) {
  case TAG_Nothing: {
    heff_drop(v_s_24120);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24128 = heff_field(v_x3_24127, 0);
    V v_ru_24x3_24127_24Just = heff_take_reuse_n(v_x3_24127, 1ULL, 1);
    switch (heff_tag_of(v_x31_24128)) {
    case TAG_MkPair: {
      V v_x_24129 = heff_field(v_x31_24128, 0);
      V v_j_24130 = heff_field(v_x31_24128, 1);
      V v_ru_24x31_24128_24MkPair = heff_take_reuse_n(v_x31_24128, 3ULL, 2);
      V v_m_24131 = ((V)&g_heff_2ebuild_2eserial_2etakeDict_24s1457287350x1584355010_clo);
      V v_x3_24132 = heff_tr(heff_apply(v_m_24131, 2, (V[]){v_s_24120, v_j_24130}));
      switch (heff_tag_of(v_x3_24132)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24127_24Just, 1);
        heff_drop(v_x_24129);
        heff_drop_cell(v_ru_24x31_24128_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24133 = heff_field(v_x3_24132, 0);
        heff_take_n(v_x3_24132, 1ULL, 1);
        switch (heff_tag_of(v_x31_24133)) {
        case TAG_MkPair: {
          V v_x_24134 = heff_field(v_x31_24133, 0);
          V v_j_24135 = heff_field(v_x31_24133, 1);
          heff_take_n(v_x31_24133, 3ULL, 2);
          V v_t_24136 = heff_tag_at_n(v_ru_24x31_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24129, v_x_24134}), v_j_24135});
          return heff_tag_at_n(v_ru_24x3_24127_24Just, TAG_Just, 1, (V[]){v_t_24136});
        }
        default: return heff_nomatch(v_x31_24133);
        }
      }
      default: return heff_nomatch(v_x3_24132);
      }
    }
    default: return heff_nomatch(v_x31_24128);
    }
  }
  default: return heff_nomatch(v_x3_24127);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam9(V self, V *args) {
  V v_s_24138 = args[0];
  V v_i_24139 = args[1];
  V v_x3_24140 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24138), v_i_24139));
  V v_x3_24145;
  switch (heff_tag_of(v_x3_24140)) {
  case TAG_Nothing: {
    v_x3_24145 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24141 = heff_field(v_x3_24140, 0);
    heff_take_n(v_x3_24140, 1ULL, 1);
    switch (heff_tag_of(v_x31_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x31_24141, 0);
      V v_j_24143 = heff_field(v_x31_24141, 1);
      heff_take_n(v_x31_24141, 3ULL, 2);
      V v_t_24144 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24142));
      v_x3_24145 = heff_tr(heff_apply(v_t_24144, 2, (V[]){heff_dup(v_s_24138), v_j_24143}));
      break;
    }
    default: heff_nomatch(v_x31_24141);
    }
    break;
  }
  default: heff_nomatch(v_x3_24140);
  }
  switch (heff_tag_of(v_x3_24145)) {
  case TAG_Nothing: {
    heff_drop(v_s_24138);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24146 = heff_field(v_x3_24145, 0);
    V v_ru_24x3_24145_24Just = heff_take_reuse_n(v_x3_24145, 1ULL, 1);
    switch (heff_tag_of(v_x31_24146)) {
    case TAG_MkPair: {
      V v_x_24147 = heff_field(v_x31_24146, 0);
      V v_j_24148 = heff_field(v_x31_24146, 1);
      V v_ru_24x31_24146_24MkPair = heff_take_reuse_n(v_x31_24146, 3ULL, 2);
      V v_x3_24149 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_24138), v_j_24148));
      switch (heff_tag_of(v_x3_24149)) {
      case TAG_Nothing: {
        heff_drop(v_s_24138);
        heff_drop_cell(v_ru_24x3_24145_24Just, 1);
        heff_drop(v_x_24147);
        heff_drop_cell(v_ru_24x31_24146_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24150 = heff_field(v_x3_24149, 0);
        heff_take_n(v_x3_24149, 1ULL, 1);
        switch (heff_tag_of(v_x31_24150)) {
        case TAG_MkPair: {
          V v_x_24151 = heff_field(v_x31_24150, 0);
          V v_j_24152 = heff_field(v_x31_24150, 1);
          heff_take_n(v_x31_24150, 3ULL, 2);
          V v_x3_24153 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24138), v_j_24152));
          V v_x3_24158;
          switch (heff_tag_of(v_x3_24153)) {
          case TAG_Nothing: {
            heff_drop(v_s_24138);
            v_x3_24158 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_24154 = heff_field(v_x3_24153, 0);
            heff_take_n(v_x3_24153, 1ULL, 1);
            switch (heff_tag_of(v_x31_24154)) {
            case TAG_MkPair: {
              V v_x_24155 = heff_field(v_x31_24154, 0);
              V v_j_24156 = heff_field(v_x31_24154, 1);
              heff_take_n(v_x31_24154, 3ULL, 2);
              V v_t_24157 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24155));
              v_x3_24158 = heff_tr(heff_apply(v_t_24157, 2, (V[]){v_s_24138, v_j_24156}));
              break;
            }
            default: heff_nomatch(v_x31_24154);
            }
            break;
          }
          default: heff_nomatch(v_x3_24153);
          }
          switch (heff_tag_of(v_x3_24158)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_24145_24Just, 1);
            heff_drop(v_x_24147);
            heff_drop_cell(v_ru_24x31_24146_24MkPair, 2);
            heff_drop(v_x_24151);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_24159 = heff_field(v_x3_24158, 0);
            heff_take_n(v_x3_24158, 1ULL, 1);
            switch (heff_tag_of(v_x31_24159)) {
            case TAG_MkPair: {
              V v_x_24160 = heff_field(v_x31_24159, 0);
              V v_j_24161 = heff_field(v_x31_24159, 1);
              heff_take_n(v_x31_24159, 3ULL, 2);
              V v_t_24162 = heff_tag_at_n(v_ru_24x31_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24147, v_x_24151, v_x_24160}), v_j_24161});
              return heff_tag_at_n(v_ru_24x3_24145_24Just, TAG_Just, 1, (V[]){v_t_24162});
            }
            default: return heff_nomatch(v_x31_24159);
            }
          }
          default: return heff_nomatch(v_x3_24158);
          }
        }
        default: return heff_nomatch(v_x31_24150);
        }
      }
      default: return heff_nomatch(v_x3_24149);
      }
    }
    default: return heff_nomatch(v_x31_24146);
    }
  }
  default: return heff_nomatch(v_x3_24145);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam10(V self, V *args) {
  V v_s_24164 = args[0];
  V v_i_24165 = args[1];
  V v_x3_24166 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24164), v_i_24165));
  V v_x3_24171;
  switch (heff_tag_of(v_x3_24166)) {
  case TAG_Nothing: {
    heff_drop(v_s_24164);
    v_x3_24171 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24167 = heff_field(v_x3_24166, 0);
    heff_take_n(v_x3_24166, 1ULL, 1);
    switch (heff_tag_of(v_x31_24167)) {
    case TAG_MkPair: {
      V v_x_24168 = heff_field(v_x31_24167, 0);
      V v_j_24169 = heff_field(v_x31_24167, 1);
      heff_take_n(v_x31_24167, 3ULL, 2);
      V v_t_24170 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24168));
      v_x3_24171 = heff_tr(heff_apply(v_t_24170, 2, (V[]){v_s_24164, v_j_24169}));
      break;
    }
    default: heff_nomatch(v_x31_24167);
    }
    break;
  }
  default: heff_nomatch(v_x3_24166);
  }
  switch (heff_tag_of(v_x3_24171)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24172 = heff_field(v_x3_24171, 0);
    V v_ru_24x3_24171_24Just = heff_take_reuse_n(v_x3_24171, 1ULL, 1);
    switch (heff_tag_of(v_x31_24172)) {
    case TAG_MkPair: {
      V v_x_24173 = heff_field(v_x31_24172, 0);
      V v_j_24174 = heff_field(v_x31_24172, 1);
      V v_ru_24x31_24172_24MkPair = heff_take_reuse_n(v_x31_24172, 3ULL, 2);
      V v_t_24175 = heff_tag_at_n(v_ru_24x31_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24171_24Just, TAG_SIs, 1, (V[]){v_x_24173}), v_j_24174});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24175});
    }
    default: return heff_nomatch(v_x31_24172);
    }
  }
  default: return heff_nomatch(v_x3_24171);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam11(V self, V *args) {
  V v_s_24177 = args[0];
  V v_i_24178 = args[1];
  heff_drop(v_s_24177);
  V v_t_24179 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_i_24178});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24179});
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam12(V self, V *args) {
  V v_s_24181 = args[0];
  V v_i_24182 = args[1];
  heff_drop(v_s_24181);
  V v_t_24183 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_i_24182});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24183});
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam13(V self, V *args) {
  V v_s_24185 = args[0];
  V v_i_24186 = args[1];
  V v_x3_24187 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24185), v_i_24186));
  V v_x3_24192;
  switch (heff_tag_of(v_x3_24187)) {
  case TAG_Nothing: {
    heff_drop(v_s_24185);
    v_x3_24192 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24188 = heff_field(v_x3_24187, 0);
    heff_take_n(v_x3_24187, 1ULL, 1);
    switch (heff_tag_of(v_x31_24188)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_field(v_x31_24188, 0);
      V v_j_24190 = heff_field(v_x31_24188, 1);
      heff_take_n(v_x31_24188, 3ULL, 2);
      V v_t_24191 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24189));
      v_x3_24192 = heff_tr(heff_apply(v_t_24191, 2, (V[]){v_s_24185, v_j_24190}));
      break;
    }
    default: heff_nomatch(v_x31_24188);
    }
    break;
  }
  default: heff_nomatch(v_x3_24187);
  }
  switch (heff_tag_of(v_x3_24192)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24193 = heff_field(v_x3_24192, 0);
    V v_ru_24x3_24192_24Just = heff_take_reuse_n(v_x3_24192, 1ULL, 1);
    switch (heff_tag_of(v_x31_24193)) {
    case TAG_MkPair: {
      V v_x_24194 = heff_field(v_x31_24193, 0);
      V v_j_24195 = heff_field(v_x31_24193, 1);
      V v_ru_24x31_24193_24MkPair = heff_take_reuse_n(v_x31_24193, 3ULL, 2);
      V v_t_24196 = heff_tag_at_n(v_ru_24x31_24193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24192_24Just, TAG_SRec, 1, (V[]){v_x_24194}), v_j_24195});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24196});
    }
    default: return heff_nomatch(v_x31_24193);
    }
  }
  default: return heff_nomatch(v_x3_24192);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam14(V self, V *args) {
  V v_s_24198 = args[0];
  V v_i_24199 = args[1];
  V v_x3_24200 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24198), v_i_24199));
  V v_x3_24205;
  switch (heff_tag_of(v_x3_24200)) {
  case TAG_Nothing: {
    v_x3_24205 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24201 = heff_field(v_x3_24200, 0);
    heff_take_n(v_x3_24200, 1ULL, 1);
    switch (heff_tag_of(v_x31_24201)) {
    case TAG_MkPair: {
      V v_x_24202 = heff_field(v_x31_24201, 0);
      V v_j_24203 = heff_field(v_x31_24201, 1);
      heff_take_n(v_x31_24201, 3ULL, 2);
      V v_t_24204 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24202));
      v_x3_24205 = heff_tr(heff_apply(v_t_24204, 2, (V[]){heff_dup(v_s_24198), v_j_24203}));
      break;
    }
    default: heff_nomatch(v_x31_24201);
    }
    break;
  }
  default: heff_nomatch(v_x3_24200);
  }
  switch (heff_tag_of(v_x3_24205)) {
  case TAG_Nothing: {
    heff_drop(v_s_24198);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24206 = heff_field(v_x3_24205, 0);
    V v_ru_24x3_24205_24Just = heff_take_reuse_n(v_x3_24205, 1ULL, 1);
    switch (heff_tag_of(v_x31_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x31_24206, 0);
      V v_j_24208 = heff_field(v_x31_24206, 1);
      V v_ru_24x31_24206_24MkPair = heff_take_reuse_n(v_x31_24206, 3ULL, 2);
      V v_x3_24209 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24198), v_j_24208));
      V v_x3_24214;
      switch (heff_tag_of(v_x3_24209)) {
      case TAG_Nothing: {
        heff_drop(v_s_24198);
        v_x3_24214 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_24210 = heff_field(v_x3_24209, 0);
        heff_take_n(v_x3_24209, 1ULL, 1);
        switch (heff_tag_of(v_x31_24210)) {
        case TAG_MkPair: {
          V v_x_24211 = heff_field(v_x31_24210, 0);
          V v_j_24212 = heff_field(v_x31_24210, 1);
          heff_take_n(v_x31_24210, 3ULL, 2);
          V v_t_24213 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24211));
          v_x3_24214 = heff_tr(heff_apply(v_t_24213, 2, (V[]){v_s_24198, v_j_24212}));
          break;
        }
        default: heff_nomatch(v_x31_24210);
        }
        break;
      }
      default: heff_nomatch(v_x3_24209);
      }
      switch (heff_tag_of(v_x3_24214)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24205_24Just, 1);
        heff_drop(v_x_24207);
        heff_drop_cell(v_ru_24x31_24206_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24215 = heff_field(v_x3_24214, 0);
        heff_take_n(v_x3_24214, 1ULL, 1);
        switch (heff_tag_of(v_x31_24215)) {
        case TAG_MkPair: {
          V v_x_24216 = heff_field(v_x31_24215, 0);
          V v_j_24217 = heff_field(v_x31_24215, 1);
          heff_take_n(v_x31_24215, 3ULL, 2);
          V v_t_24218 = heff_tag_at_n(v_ru_24x31_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24207, v_x_24216}), v_j_24217});
          return heff_tag_at_n(v_ru_24x3_24205_24Just, TAG_Just, 1, (V[]){v_t_24218});
        }
        default: return heff_nomatch(v_x31_24215);
        }
      }
      default: return heff_nomatch(v_x3_24214);
      }
    }
    default: return heff_nomatch(v_x31_24206);
    }
  }
  default: return heff_nomatch(v_x3_24205);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam15(V self, V *args) {
  V v_s_24220 = args[0];
  V v_i_24221 = args[1];
  V v_x3_24222 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_24220), v_i_24221));
  switch (heff_tag_of(v_x3_24222)) {
  case TAG_Nothing: {
    heff_drop(v_s_24220);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24223 = heff_field(v_x3_24222, 0);
    V v_ru_24x3_24222_24Just = heff_take_reuse_n(v_x3_24222, 1ULL, 1);
    switch (heff_tag_of(v_x31_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x31_24223, 0);
      V v_j_24225 = heff_field(v_x31_24223, 1);
      V v_ru_24x31_24223_24MkPair = heff_take_reuse_n(v_x31_24223, 3ULL, 2);
      V v_x3_24226 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24220), v_j_24225));
      V v_x3_24231;
      switch (heff_tag_of(v_x3_24226)) {
      case TAG_Nothing: {
        heff_drop(v_s_24220);
        v_x3_24231 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_24227 = heff_field(v_x3_24226, 0);
        heff_take_n(v_x3_24226, 1ULL, 1);
        switch (heff_tag_of(v_x31_24227)) {
        case TAG_MkPair: {
          V v_x_24228 = heff_field(v_x31_24227, 0);
          V v_j_24229 = heff_field(v_x31_24227, 1);
          heff_take_n(v_x31_24227, 3ULL, 2);
          V v_t_24230 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24228));
          v_x3_24231 = heff_tr(heff_apply(v_t_24230, 2, (V[]){v_s_24220, v_j_24229}));
          break;
        }
        default: heff_nomatch(v_x31_24227);
        }
        break;
      }
      default: heff_nomatch(v_x3_24226);
      }
      switch (heff_tag_of(v_x3_24231)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24222_24Just, 1);
        heff_drop(v_x_24224);
        heff_drop_cell(v_ru_24x31_24223_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24232 = heff_field(v_x3_24231, 0);
        heff_take_n(v_x3_24231, 1ULL, 1);
        switch (heff_tag_of(v_x31_24232)) {
        case TAG_MkPair: {
          V v_x_24233 = heff_field(v_x31_24232, 0);
          V v_j_24234 = heff_field(v_x31_24232, 1);
          heff_take_n(v_x31_24232, 3ULL, 2);
          V v_t_24235 = heff_tag_at_n(v_ru_24x31_24223_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24224, v_x_24233}), v_j_24234});
          return heff_tag_at_n(v_ru_24x3_24222_24Just, TAG_Just, 1, (V[]){v_t_24235});
        }
        default: return heff_nomatch(v_x31_24232);
        }
      }
      default: return heff_nomatch(v_x3_24231);
      }
    }
    default: return heff_nomatch(v_x31_24223);
    }
  }
  default: return heff_nomatch(v_x3_24222);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam16(V self, V *args) {
  V v_s_24237 = args[0];
  V v_i_24238 = args[1];
  V v_x3_24239 = (g_heff_2ebuild_2edecoder_2estr(v_s_24237, v_i_24238));
  switch (heff_tag_of(v_x3_24239)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24240 = heff_field(v_x3_24239, 0);
    V v_ru_24x3_24239_24Just = heff_take_reuse_n(v_x3_24239, 1ULL, 1);
    switch (heff_tag_of(v_x31_24240)) {
    case TAG_MkPair: {
      V v_x_24241 = heff_field(v_x31_24240, 0);
      V v_j_24242 = heff_field(v_x31_24240, 1);
      V v_ru_24x31_24240_24MkPair = heff_take_reuse_n(v_x31_24240, 3ULL, 2);
      V v_t_24243 = heff_tag_at_n(v_ru_24x31_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24239_24Just, TAG_SPrim, 1, (V[]){v_x_24241}), v_j_24242});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24243});
    }
    default: return heff_nomatch(v_x31_24240);
    }
  }
  default: return heff_nomatch(v_x3_24239);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam17(V self, V *args) {
  V v_s_24245 = args[0];
  V v_i_24246 = args[1];
  V v_x3_24247 = (g_heff_2ebuild_2edecoder_2estr(v_s_24245, v_i_24246));
  switch (heff_tag_of(v_x3_24247)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24248 = heff_field(v_x3_24247, 0);
    V v_ru_24x3_24247_24Just = heff_take_reuse_n(v_x3_24247, 1ULL, 1);
    switch (heff_tag_of(v_x31_24248)) {
    case TAG_MkPair: {
      V v_x_24249 = heff_field(v_x31_24248, 0);
      V v_j_24250 = heff_field(v_x31_24248, 1);
      V v_ru_24x31_24248_24MkPair = heff_take_reuse_n(v_x31_24248, 3ULL, 2);
      V v_x_24251 = heff_tag_at_n(v_ru_24x3_24247_24Just, TAG_SLitInt, 1, (V[]){(g_heff_2esyntax_2esurface_2eintOfText(v_x_24249))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24248_24MkPair, TAG_MkPair, 2, (V[]){v_x_24251, v_j_24250})});
    }
    default: return heff_nomatch(v_x31_24248);
    }
  }
  default: return heff_nomatch(v_x3_24247);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam18(V self, V *args) {
  V v_s_24253 = args[0];
  V v_i_24254 = args[1];
  V v_x3_24255 = (g_heff_2ebuild_2edecoder_2estr(v_s_24253, v_i_24254));
  switch (heff_tag_of(v_x3_24255)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24256 = heff_field(v_x3_24255, 0);
    V v_ru_24x3_24255_24Just = heff_take_reuse_n(v_x3_24255, 1ULL, 1);
    switch (heff_tag_of(v_x31_24256)) {
    case TAG_MkPair: {
      V v_x_24257 = heff_field(v_x31_24256, 0);
      V v_j_24258 = heff_field(v_x31_24256, 1);
      V v_ru_24x31_24256_24MkPair = heff_take_reuse_n(v_x31_24256, 3ULL, 2);
      V v_x2_24259 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str19), v_x_24257, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_24262;
      switch (heff_tag_of(v_x2_24259)) {
      case TAG_Nil: {
        v_t_24262 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_24260 = heff_field(v_x2_24259, 0);
        V v_xs_24261 = heff_field(v_x2_24259, 1);
        heff_take_n(v_x2_24259, 3ULL, 2);
        v_t_24262 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str21); V a_1 = v_x_24260; V a_2 = v_xs_24261; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24261); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24259);
      }
      V v_x_24263 = heff_tag_at_n(v_ru_24x3_24255_24Just, TAG_SLitFloat, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24262))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24256_24MkPair, TAG_MkPair, 2, (V[]){v_x_24263, v_j_24258})});
    }
    default: return heff_nomatch(v_x31_24256);
    }
  }
  default: return heff_nomatch(v_x3_24255);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam19(V self, V *args) {
  V v_s_24265 = args[0];
  V v_i_24266 = args[1];
  V v_x3_24267 = (g_heff_2ebuild_2edecoder_2estr(v_s_24265, v_i_24266));
  switch (heff_tag_of(v_x3_24267)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24268 = heff_field(v_x3_24267, 0);
    V v_ru_24x3_24267_24Just = heff_take_reuse_n(v_x3_24267, 1ULL, 1);
    switch (heff_tag_of(v_x31_24268)) {
    case TAG_MkPair: {
      V v_x_24269 = heff_field(v_x31_24268, 0);
      V v_j_24270 = heff_field(v_x31_24268, 1);
      V v_ru_24x31_24268_24MkPair = heff_take_reuse_n(v_x31_24268, 3ULL, 2);
      V v_t_24271 = heff_tag_at_n(v_ru_24x31_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24267_24Just, TAG_SLitString, 1, (V[]){v_x_24269}), v_j_24270});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24271});
    }
    default: return heff_nomatch(v_x31_24268);
    }
  }
  default: return heff_nomatch(v_x3_24267);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam20(V self, V *args) {
  V v_s_24273 = args[0];
  V v_i_24274 = args[1];
  V v_x3_24275 = (g_heff_2ebuild_2edecoder_2estr(v_s_24273, v_i_24274));
  switch (heff_tag_of(v_x3_24275)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24276 = heff_field(v_x3_24275, 0);
    V v_ru_24x3_24275_24Just = heff_take_reuse_n(v_x3_24275, 1ULL, 1);
    switch (heff_tag_of(v_x31_24276)) {
    case TAG_MkPair: {
      V v_x_24277 = heff_field(v_x31_24276, 0);
      V v_j_24278 = heff_field(v_x31_24276, 1);
      V v_ru_24x31_24276_24MkPair = heff_take_reuse_n(v_x31_24276, 3ULL, 2);
      V v_x_24279 = heff_tag_at_n(v_ru_24x3_24275_24Just, TAG_SLitRune, 1, (V[]){(g_heff_2esyntax_2esurface_2eintOfText(v_x_24277))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24276_24MkPair, TAG_MkPair, 2, (V[]){v_x_24279, v_j_24278})});
    }
    default: return heff_nomatch(v_x31_24276);
    }
  }
  default: return heff_nomatch(v_x3_24275);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam21(V self, V *args) {
  V v_s_24281 = args[0];
  V v_i_24282 = args[1];
  V v_x3_24283 = (g_heff_2ebuild_2eserial_2etakeFixed(heff_dup(v_s_24281), v_i_24282));
  switch (heff_tag_of(v_x3_24283)) {
  case TAG_Nothing: {
    heff_drop(v_s_24281);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24284 = heff_field(v_x3_24283, 0);
    V v_ru_24x3_24283_24Just = heff_take_reuse_n(v_x3_24283, 1ULL, 1);
    switch (heff_tag_of(v_x31_24284)) {
    case TAG_MkPair: {
      V v_x_24285 = heff_field(v_x31_24284, 0);
      V v_j_24286 = heff_field(v_x31_24284, 1);
      V v_ru_24x31_24284_24MkPair = heff_take_reuse_n(v_x31_24284, 3ULL, 2);
      V v_x3_24287 = (g_heff_2ebuild_2edecoder_2estr(v_s_24281, v_j_24286));
      switch (heff_tag_of(v_x3_24287)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_24283_24Just, 1);
        heff_drop(v_x_24285);
        heff_drop_cell(v_ru_24x31_24284_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_24288 = heff_field(v_x3_24287, 0);
        heff_take_n(v_x3_24287, 1ULL, 1);
        switch (heff_tag_of(v_x31_24288)) {
        case TAG_MkPair: {
          V v_x_24289 = heff_field(v_x31_24288, 0);
          V v_j_24290 = heff_field(v_x31_24288, 1);
          heff_take_n(v_x31_24288, 3ULL, 2);
          V v_x_24291 = heff_tag_at_n(v_ru_24x31_24284_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24285, (g_heff_2esyntax_2esurface_2eintOfText(v_x_24289))});
          return heff_tag_at_n(v_ru_24x3_24283_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24291, v_j_24290})});
        }
        default: return heff_nomatch(v_x31_24288);
        }
      }
      default: return heff_nomatch(v_x3_24287);
      }
    }
    default: return heff_nomatch(v_x31_24284);
    }
  }
  default: return heff_nomatch(v_x3_24283);
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_lam22(V self, V *args) {
  V v_s_24293 = args[0];
  V v_i_24294 = args[1];
  V v_x3_24295 = (g_heff_2ebuild_2edecoder_2estr(v_s_24293, v_i_24294));
  switch (heff_tag_of(v_x3_24295)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24296 = heff_field(v_x3_24295, 0);
    V v_ru_24x3_24295_24Just = heff_take_reuse_n(v_x3_24295, 1ULL, 1);
    switch (heff_tag_of(v_x31_24296)) {
    case TAG_MkPair: {
      V v_x_24297 = heff_field(v_x31_24296, 0);
      V v_j_24298 = heff_field(v_x31_24296, 1);
      V v_ru_24x31_24296_24MkPair = heff_take_reuse_n(v_x31_24296, 3ULL, 2);
      V v_x2_24299 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str26), v_x_24297, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_24302;
      switch (heff_tag_of(v_x2_24299)) {
      case TAG_Nil: {
        v_t_24302 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_24300 = heff_field(v_x2_24299, 0);
        V v_xs_24301 = heff_field(v_x2_24299, 1);
        heff_take_n(v_x2_24299, 3ULL, 2);
        v_t_24302 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str28); V a_1 = v_x_24300; V a_2 = v_xs_24301; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24301); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24299);
      }
      V v_x_24303 = heff_tag_at_n(v_ru_24x3_24295_24Just, TAG_SLitFloat32, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24302))});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24296_24MkPair, TAG_MkPair, 2, (V[]){v_x_24303, v_j_24298})});
    }
    default: return heff_nomatch(v_x31_24296);
    }
  }
  default: return heff_nomatch(v_x3_24295);
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry, 1, 0};

V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V v_x2_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str0))) {
    heff_drop(v_x2_240);
    return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam0_clo);
  } else {
    if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str1))) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a[0]);
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  V v_x3_244 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_242), v_i_243));
  V v_x3_249;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_s_242);
    v_x3_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    heff_take_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      heff_take_n(v_x31_245, 3ULL, 2);
      V v_t_248 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_246));
      v_x3_249 = heff_tr(heff_apply(v_t_248, 2, (V[]){v_s_242, v_j_247}));
      break;
    }
    default: heff_nomatch(v_x31_245);
    }
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2410 = heff_field(v_x3_249, 0);
    V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
    switch (heff_tag_of(v_x31_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x31_2410, 0);
      V v_j_2412 = heff_field(v_x31_2410, 1);
      V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_x_2411}), v_j_2412});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_x31_2410);
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_i_2416 = args[1];
  heff_drop(v_s_2415);
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2416});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str11, 2, "px");
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam1, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam2(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam2, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam3(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam4(V self, V *args);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam5(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam5, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam6(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam6, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam7(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam7, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam8(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam8, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam9(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam9, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam10(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam10, 2, 0};
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam11(V self, V *args); static Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam11, 2, 0};
Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry, 1, 0};

V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V v_x2_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str0))) {
    heff_drop(v_x2_240);
    return ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo);
  } else {
    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str1))) {
      heff_drop(v_x2_240);
      return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam0_clo);
    } else {
      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str2))) {
        heff_drop(v_x2_240);
        return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam1_clo);
      } else {
        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str3))) {
          heff_drop(v_x2_240);
          return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam2_clo);
        } else {
          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str4))) {
            heff_drop(v_x2_240);
            V v_t_2468 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1))}));
            V v_m_2469 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo), 1, (V[]){v_t_2468}));
            V v_m_2477 = (g_heff_2ebuild_2eserial_2etakeDict(heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam3, 2, 1, (V[]){v_m_2469})));
            return heff_clo_n(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam4, 2, 1, (V[]){v_m_2477});
          } else {
            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str5))) {
              heff_drop(v_x2_240);
              return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam5_clo);
            } else {
              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str6))) {
                heff_drop(v_x2_240);
                return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam6_clo);
              } else {
                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str7))) {
                  heff_drop(v_x2_240);
                  return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam7_clo);
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str8))) {
                    heff_drop(v_x2_240);
                    return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam8_clo);
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str9))) {
                      heff_drop(v_x2_240);
                      return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam9_clo);
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str10))) {
                        heff_drop(v_x2_240);
                        return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam10_clo);
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str11))) {
                          return ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam11_clo);
                        } else {
                          return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(a[0]);
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_x3_245 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_243), v_i_244));
  V v_x3_2410;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    heff_drop(v_s_243);
    v_x3_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    heff_take_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_247));
      v_x3_2410 = heff_tr(heff_apply(v_t_249, 2, (V[]){v_s_243, v_j_248}));
      break;
    }
    default: heff_nomatch(v_x31_246);
    }
    break;
  }
  default: heff_nomatch(v_x3_245);
  }
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2411 = heff_field(v_x3_2410, 0);
    V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
    switch (heff_tag_of(v_x31_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x31_2411, 0);
      V v_j_2413 = heff_field(v_x31_2411, 1);
      V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
      V v_t_2414 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_SDecode, 1, (V[]){v_x_2412}), v_j_2413});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    }
    default: return heff_nomatch(v_x31_2411);
    }
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_i_2417 = args[1];
  V v_x3_2418 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_s_2416), v_i_2417));
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_Nothing: {
    heff_drop(v_s_2416);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x31_2419, 0);
      V v_j_2421 = heff_field(v_x31_2419, 1);
      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
      V v_x3_2422 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2416), v_j_2421));
      V v_x3_2427;
      switch (heff_tag_of(v_x3_2422)) {
      case TAG_Nothing: {
        v_x3_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2423 = heff_field(v_x3_2422, 0);
        heff_take_n(v_x3_2422, 1ULL, 1);
        switch (heff_tag_of(v_x31_2423)) {
        case TAG_MkPair: {
          V v_x_2424 = heff_field(v_x31_2423, 0);
          V v_j_2425 = heff_field(v_x31_2423, 1);
          heff_take_n(v_x31_2423, 3ULL, 2);
          V v_t_2426 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2424));
          v_x3_2427 = heff_tr(heff_apply(v_t_2426, 2, (V[]){heff_dup(v_s_2416), v_j_2425}));
          break;
        }
        default: heff_nomatch(v_x31_2423);
        }
        break;
      }
      default: heff_nomatch(v_x3_2422);
      }
      switch (heff_tag_of(v_x3_2427)) {
      case TAG_Nothing: {
        heff_drop(v_s_2416);
        heff_drop_cell(v_ru_24x3_2418_24Just, 1);
        heff_drop(v_x_2420);
        heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2428 = heff_field(v_x3_2427, 0);
        heff_take_n(v_x3_2427, 1ULL, 1);
        switch (heff_tag_of(v_x31_2428)) {
        case TAG_MkPair: {
          V v_x_2429 = heff_field(v_x31_2428, 0);
          V v_j_2430 = heff_field(v_x31_2428, 1);
          heff_take_n(v_x31_2428, 3ULL, 2);
          V v_x3_2431 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2416), v_j_2430));
          V v_x3_2436;
          switch (heff_tag_of(v_x3_2431)) {
          case TAG_Nothing: {
            v_x3_2436 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2432 = heff_field(v_x3_2431, 0);
            heff_take_n(v_x3_2431, 1ULL, 1);
            switch (heff_tag_of(v_x31_2432)) {
            case TAG_MkPair: {
              V v_x_2433 = heff_field(v_x31_2432, 0);
              V v_j_2434 = heff_field(v_x31_2432, 1);
              heff_take_n(v_x31_2432, 3ULL, 2);
              V v_t_2435 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_2433));
              v_x3_2436 = heff_tr(heff_apply(v_t_2435, 2, (V[]){heff_dup(v_s_2416), v_j_2434}));
              break;
            }
            default: heff_nomatch(v_x31_2432);
            }
            break;
          }
          default: heff_nomatch(v_x3_2431);
          }
          switch (heff_tag_of(v_x3_2436)) {
          case TAG_Nothing: {
            heff_drop(v_s_2416);
            heff_drop_cell(v_ru_24x3_2418_24Just, 1);
            heff_drop(v_x_2420);
            heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
            heff_drop(v_x_2429);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2437 = heff_field(v_x3_2436, 0);
            heff_take_n(v_x3_2436, 1ULL, 1);
            switch (heff_tag_of(v_x31_2437)) {
            case TAG_MkPair: {
              V v_x_2438 = heff_field(v_x31_2437, 0);
              V v_j_2439 = heff_field(v_x31_2437, 1);
              heff_take_n(v_x31_2437, 3ULL, 2);
              V v_x3_2440 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(heff_dup(v_s_2416), v_j_2439));
              switch (heff_tag_of(v_x3_2440)) {
              case TAG_Nothing: {
                heff_drop(v_s_2416);
                heff_drop_cell(v_ru_24x3_2418_24Just, 1);
                heff_drop(v_x_2420);
                heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                heff_drop(v_x_2429);
                heff_drop(v_x_2438);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2441 = heff_field(v_x3_2440, 0);
                heff_take_n(v_x3_2440, 1ULL, 1);
                switch (heff_tag_of(v_x31_2441)) {
                case TAG_MkPair: {
                  V v_x_2442 = heff_field(v_x31_2441, 0);
                  V v_j_2443 = heff_field(v_x31_2441, 1);
                  heff_take_n(v_x31_2441, 3ULL, 2);
                  V v_x3_2444 = heff_tr(g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779(v_s_2416, v_j_2443));
                  switch (heff_tag_of(v_x3_2444)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x3_2418_24Just, 1);
                    heff_drop(v_x_2420);
                    heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                    heff_drop(v_x_2429);
                    heff_drop(v_x_2438);
                    heff_drop(v_x_2442);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2445 = heff_field(v_x3_2444, 0);
                    heff_take_n(v_x3_2444, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2445)) {
                    case TAG_MkPair: {
                      V v_x_2446 = heff_field(v_x31_2445, 0);
                      V v_j_2447 = heff_field(v_x31_2445, 1);
                      heff_take_n(v_x31_2445, 3ULL, 2);
                      V v_t_2448 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2420, v_x_2429, v_x_2438, v_x_2442, v_x_2446}), v_j_2447});
                      return heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_Just, 1, (V[]){v_t_2448});
                    }
                    default: return heff_nomatch(v_x31_2445);
                    }
                  }
                  default: return heff_nomatch(v_x3_2444);
                  }
                }
                default: return heff_nomatch(v_x31_2441);
                }
              }
              default: return heff_nomatch(v_x3_2440);
              }
            }
            default: return heff_nomatch(v_x31_2437);
            }
          }
          default: return heff_nomatch(v_x3_2436);
          }
        }
        default: return heff_nomatch(v_x31_2428);
        }
      }
      default: return heff_nomatch(v_x3_2427);
      }
    }
    default: return heff_nomatch(v_x31_2419);
    }
  }
  default: return heff_nomatch(v_x3_2418);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam2(V self, V *args) {
  V v_s_2450 = args[0];
  V v_i_2451 = args[1];
  V v_x3_2452 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_s_2450), v_i_2451));
  switch (heff_tag_of(v_x3_2452)) {
  case TAG_Nothing: {
    heff_drop(v_s_2450);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2453 = heff_field(v_x3_2452, 0);
    V v_ru_24x3_2452_24Just = heff_take_reuse_n(v_x3_2452, 1ULL, 1);
    switch (heff_tag_of(v_x31_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x31_2453, 0);
      V v_j_2455 = heff_field(v_x31_2453, 1);
      V v_ru_24x31_2453_24MkPair = heff_take_reuse_n(v_x31_2453, 3ULL, 2);
      V v_m_2456 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1))));
      V v_x3_2457 = heff_tr(heff_apply(v_m_2456, 2, (V[]){heff_dup(v_s_2450), v_j_2455}));
      switch (heff_tag_of(v_x3_2457)) {
      case TAG_Nothing: {
        heff_drop(v_s_2450);
        heff_drop_cell(v_ru_24x3_2452_24Just, 1);
        heff_drop(v_x_2454);
        heff_drop_cell(v_ru_24x31_2453_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2458 = heff_field(v_x3_2457, 0);
        heff_take_n(v_x3_2457, 1ULL, 1);
        switch (heff_tag_of(v_x31_2458)) {
        case TAG_MkPair: {
          V v_x_2459 = heff_field(v_x31_2458, 0);
          V v_j_2460 = heff_field(v_x31_2458, 1);
          heff_take_n(v_x31_2458, 3ULL, 2);
          V v_m_2461 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0))));
          V v_x3_2462 = heff_tr(heff_apply(v_m_2461, 2, (V[]){v_s_2450, v_j_2460}));
          switch (heff_tag_of(v_x3_2462)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_2452_24Just, 1);
            heff_drop(v_x_2454);
            heff_drop_cell(v_ru_24x31_2453_24MkPair, 2);
            heff_drop(v_x_2459);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2463 = heff_field(v_x3_2462, 0);
            heff_take_n(v_x3_2462, 1ULL, 1);
            switch (heff_tag_of(v_x31_2463)) {
            case TAG_MkPair: {
              V v_x_2464 = heff_field(v_x31_2463, 0);
              V v_j_2465 = heff_field(v_x31_2463, 1);
              heff_take_n(v_x31_2463, 3ULL, 2);
              V v_t_2466 = heff_tag_at_n(v_ru_24x31_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2454, v_x_2459, v_x_2464}), v_j_2465});
              return heff_tag_at_n(v_ru_24x3_2452_24Just, TAG_Just, 1, (V[]){v_t_2466});
            }
            default: return heff_nomatch(v_x31_2463);
            }
          }
          default: return heff_nomatch(v_x3_2462);
          }
        }
        default: return heff_nomatch(v_x31_2458);
        }
      }
      default: return heff_nomatch(v_x3_2457);
      }
    }
    default: return heff_nomatch(v_x31_2453);
    }
  }
  default: return heff_nomatch(v_x3_2452);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam3(V self, V *args) {
  V v_s_2470 = args[0];
  V v_i_2471 = args[1];
  V v_m_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2472 = heff_tr(heff_apply(v_m_2469, 2, (V[]){v_s_2470, v_i_2471}));
  switch (heff_tag_of(v_x3_2472)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2473 = heff_field(v_x3_2472, 0);
    V v_ru_24x3_2472_24Just = heff_take_reuse_n(v_x3_2472, 1ULL, 1);
    switch (heff_tag_of(v_x31_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x31_2473, 0);
      V v_j_2475 = heff_field(v_x31_2473, 1);
      V v_ru_24x31_2473_24MkPair = heff_take_reuse_n(v_x31_2473, 3ULL, 2);
      V v_t_2476 = heff_tag_at_n(v_ru_24x31_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2474), v_j_2475});
      return heff_tag_at_n(v_ru_24x3_2472_24Just, TAG_Just, 1, (V[]){v_t_2476});
    }
    default: return heff_nomatch(v_x31_2473);
    }
  }
  default: return heff_nomatch(v_x3_2472);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam4(V self, V *args) {
  V v_s_2478 = args[0];
  V v_i_2479 = args[1];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2480 = heff_tr(heff_apply(v_m_2477, 2, (V[]){v_s_2478, v_i_2479}));
  switch (heff_tag_of(v_x3_2480)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2481 = heff_field(v_x3_2480, 0);
    V v_ru_24x3_2480_24Just = heff_take_reuse_n(v_x3_2480, 1ULL, 1);
    switch (heff_tag_of(v_x31_2481)) {
    case TAG_MkPair: {
      V v_x_2482 = heff_field(v_x31_2481, 0);
      V v_j_2483 = heff_field(v_x31_2481, 1);
      V v_ru_24x31_2481_24MkPair = heff_take_reuse_n(v_x31_2481, 3ULL, 2);
      V v_t_2484 = heff_tag_at_n(v_ru_24x31_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2480_24Just, TAG_SSum, 1, (V[]){v_x_2482}), v_j_2483});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2484});
    }
    default: return heff_nomatch(v_x31_2481);
    }
  }
  default: return heff_nomatch(v_x3_2480);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam5(V self, V *args) {
  V v_s_2486 = args[0];
  V v_i_2487 = args[1];
  V v_x3_2488 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2486), v_i_2487));
  V v_x3_2493;
  switch (heff_tag_of(v_x3_2488)) {
  case TAG_Nothing: {
    heff_drop(v_s_2486);
    v_x3_2493 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2489 = heff_field(v_x3_2488, 0);
    heff_take_n(v_x3_2488, 1ULL, 1);
    switch (heff_tag_of(v_x31_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x31_2489, 0);
      V v_j_2491 = heff_field(v_x31_2489, 1);
      heff_take_n(v_x31_2489, 3ULL, 2);
      V v_t_2492 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2490));
      v_x3_2493 = heff_tr(heff_apply(v_t_2492, 2, (V[]){v_s_2486, v_j_2491}));
      break;
    }
    default: heff_nomatch(v_x31_2489);
    }
    break;
  }
  default: heff_nomatch(v_x3_2488);
  }
  switch (heff_tag_of(v_x3_2493)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2494 = heff_field(v_x3_2493, 0);
    V v_ru_24x3_2493_24Just = heff_take_reuse_n(v_x3_2493, 1ULL, 1);
    switch (heff_tag_of(v_x31_2494)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_field(v_x31_2494, 0);
      V v_j_2496 = heff_field(v_x31_2494, 1);
      V v_ru_24x31_2494_24MkPair = heff_take_reuse_n(v_x31_2494, 3ULL, 2);
      V v_t_2497 = heff_tag_at_n(v_ru_24x31_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2493_24Just, TAG_SIsTy, 1, (V[]){v_x_2495}), v_j_2496});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2497});
    }
    default: return heff_nomatch(v_x31_2494);
    }
  }
  default: return heff_nomatch(v_x3_2493);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam6(V self, V *args) {
  V v_s_2499 = args[0];
  V v_i_24100 = args[1];
  heff_drop(v_s_2499);
  V v_t_24101 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_i_24100});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24101});
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam7(V self, V *args) {
  V v_s_24103 = args[0];
  V v_i_24104 = args[1];
  heff_drop(v_s_24103);
  V v_t_24105 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_i_24104});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24105});
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam8(V self, V *args) {
  V v_s_24107 = args[0];
  V v_i_24108 = args[1];
  heff_drop(v_s_24107);
  V v_t_24109 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_i_24108});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24109});
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam9(V self, V *args) {
  V v_s_24111 = args[0];
  V v_i_24112 = args[1];
  heff_drop(v_s_24111);
  V v_t_24113 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_i_24112});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_24113});
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam10(V self, V *args) {
  V v_s_24115 = args[0];
  V v_i_24116 = args[1];
  V v_x3_24117 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_24115), v_i_24116));
  V v_x3_24122;
  switch (heff_tag_of(v_x3_24117)) {
  case TAG_Nothing: {
    heff_drop(v_s_24115);
    v_x3_24122 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_24118 = heff_field(v_x3_24117, 0);
    heff_take_n(v_x3_24117, 1ULL, 1);
    switch (heff_tag_of(v_x31_24118)) {
    case TAG_MkPair: {
      V v_x_24119 = heff_field(v_x31_24118, 0);
      V v_j_24120 = heff_field(v_x31_24118, 1);
      heff_take_n(v_x31_24118, 3ULL, 2);
      V v_t_24121 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24119));
      v_x3_24122 = heff_tr(heff_apply(v_t_24121, 2, (V[]){v_s_24115, v_j_24120}));
      break;
    }
    default: heff_nomatch(v_x31_24118);
    }
    break;
  }
  default: heff_nomatch(v_x3_24117);
  }
  switch (heff_tag_of(v_x3_24122)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24123 = heff_field(v_x3_24122, 0);
    V v_ru_24x3_24122_24Just = heff_take_reuse_n(v_x3_24122, 1ULL, 1);
    switch (heff_tag_of(v_x31_24123)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_x31_24123, 0);
      V v_j_24125 = heff_field(v_x31_24123, 1);
      V v_ru_24x31_24123_24MkPair = heff_take_reuse_n(v_x31_24123, 3ULL, 2);
      V v_t_24126 = heff_tag_at_n(v_ru_24x31_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24122_24Just, TAG_SPrimArray, 1, (V[]){v_x_24124}), v_j_24125});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24126});
    }
    default: return heff_nomatch(v_x31_24123);
    }
  }
  default: return heff_nomatch(v_x3_24122);
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_lam11(V self, V *args) {
  V v_s_24128 = args[0];
  V v_i_24129 = args[1];
  V v_x3_24130 = (g_heff_2ebuild_2eserial_2etakeFixed(v_s_24128, v_i_24129));
  switch (heff_tag_of(v_x3_24130)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_24131 = heff_field(v_x3_24130, 0);
    V v_ru_24x3_24130_24Just = heff_take_reuse_n(v_x3_24130, 1ULL, 1);
    switch (heff_tag_of(v_x31_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x31_24131, 0);
      V v_j_24133 = heff_field(v_x31_24131, 1);
      V v_ru_24x31_24131_24MkPair = heff_take_reuse_n(v_x31_24131, 3ULL, 2);
      V v_t_24134 = heff_tag_at_n(v_ru_24x31_24131_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24130_24Just, TAG_SFixed, 1, (V[]){v_x_24132}), v_j_24133});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24134});
    }
    default: return heff_nomatch(v_x31_24131);
    }
  }
  default: return heff_nomatch(v_x3_24130);
  }
}