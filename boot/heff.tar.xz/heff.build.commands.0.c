// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Wait 10206
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_modules 1459291593
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_sources 357464573
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866(V);
V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_clo;
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2egoldenPart(V);
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
HeffT2 g_list_2efind_24s1230956425x1562898054_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1819215186x476901667(V, V, V, V);
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_clo;
V g_list_2emap_24s170418522x132668694(V);
V g_list_2emap_24s170418522x132668694_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2emap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2418;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2412;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        heff_take_n(v_x31_2414, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2416)) {
          v_t_2418 = v_x_2415;
        } else {
          heff_drop(v_x_2415);
          v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, v_t_246, v_t_2418));
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenPart_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenPart(V v_n_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_n_240, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_n_240, MK_INT(0LL), 2)) == ((int64_t)46ULL))) {
      return NTAG(TAG_False);
    } else {
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_n_240, 0)) - ((int64_t)1ULL));
      V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_243)));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenPart_lam0, 1, 1, (V[]){heff_dup(v_n_240)}); V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenPart(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2egoldenByte(heff_strByteAt(v_n_240, v_i_245)));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(V v_lit_240, V v_l_241, V v_name_242, V v_outPath_243, V v_file_244, V v_done_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str0), heff_dup(heff_rfield(v_l_241, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam0, 1, 8, (V[]){v_l_241, v_hd_246, v_lit_240, v_k_247, v_file_244, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam2(V self, V *args) {
  V v_c_2413 = args[0];
  V v_sources_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2414 = (g_list_2efind_24s1230956425x1562898054_24cpr(heff_dup(v_c_2413), v_sources_2411));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_s_2418 = v_field_2416;
      V v_t_2419 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2412, v_s_2418));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2413, v_t_2419));
    } else {
      heff_drop(v_x_2412);
      heff_drop(v_field_2416);
      return v_c_2413;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam4(V self, V *args) {
  V v_a_2440 = args[0];
  V v_z_2441 = args[1];
  V v_z_2442 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2440);
  V v_t_2443 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s903439140x919002362(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_2441, v_z_2442));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_l_241 = heff_env(self)[6];
  V v_file_244 = heff_env(self)[7];
  V v_name_242 = heff_env(self)[8];
  V v_outPath_243 = heff_env(self)[9];
  V v_done_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2421);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop_rec(v_x_2410, 2);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_file_244);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_245);
    V v_x2_2423 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2420));
    heff_drop(v_x2_2423);
    V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s903439140x919002362(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_246, v_k_247));
  } else {
    V v_t_2430 = (g_list_2eany_24s1996724342x1838336560(v_x_2420));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 2);
      heff_drop_rec(v_l_241, 5);
      heff_drop(v_file_244);
      heff_drop(v_name_242);
      heff_drop(v_outPath_243);
      heff_drop(v_done_245);
      heff_drop(v_t_2430);
      V v_x2_2431 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2420));
      heff_drop(v_x2_2431);
      V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      return (g_co_2eop_24s903439140x919002362(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_246, v_k_247));
    } else {
      heff_drop(v_t_2430);
      V v_t_2438 = (g_list_2emap_24s170418522x132668694(heff_take_field(v_x_2410, 0)));
      V v_t_2439 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_241, 2), heff_get_n(v_x_2410, 1, 2), v_t_2438});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(v_t_2439, heff_get_n(v_l_241, 0, 5), v_file_244, v_name_242, v_outPath_243, heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam4, 3, 1, (V[]){v_lit_240}), v_done_245, v_x_2420, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_file_244 = heff_env(self)[5];
  V v_name_242 = heff_env(self)[6];
  V v_outPath_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_sources_2411 = heff_dup(heff_rfield(v_l_241, 0));
  V v_x_2412 = (g_list_2emap_24f1819215186x476901667(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_str2), heff_dup(v_sources_2411)));
  V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam2, 1, 2, (V[]){v_sources_2411, v_x_2412}), heff_dup(heff_rfield(v_x_2410, 0))));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_x_2420), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam3, 1, 11, (V[]){v_x_248, v_x_2420, v_lit_240, v_hd_246, v_k_247, v_x_2410, v_l_241, v_file_244, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_file_244 = heff_env(self)[4];
  V v_name_242 = heff_env(self)[5];
  V v_outPath_243 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_l_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_lam1, 1, 9, (V[]){v_l_241, v_hd_246, v_x_248, v_lit_240, v_k_247, v_file_244, v_name_242, v_outPath_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str2, 60, "heff test: cannot run heff; tested again at the next change\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str3, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str7, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str8, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str9, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str10, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541(V v_as_240, V v_n_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_2413;
  if (heff_intEq_c_lent(v_n_241, MK_INT(0LL), 2)) {
    v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam0_clo);
  } else {
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str0), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    v_t_2413 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
  }
  return heff_tail(v_t_2413, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam1, 1, 4, (V[]){v_hd_242, v_as_240, v_k_243, v_n_241})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  return v_s_2415;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  return v_s_2424;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_k_243;
  args[0] = heff_intAdd(v_n_241, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam7(V self, V *args) {
  V v_r_2440 = args[0];
  return v_r_2440;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam9(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V f_ = v_k_243;
  args[0] = heff_intAdd(v_n_241, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_2449 = heff_get_n(v_x_2447, 0, 3);
  V v_t_2453;
  switch (heff_tag_of(v_t_2449)) {
  case TAG_Exited: {
    V v_n_2450 = heff_field(v_t_2449, 0);
    heff_take_n(v_t_2449, 1ULL, 1);
    if (heff_intEq_c(v_n_2450, MK_INT(0LL))) {
      v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str3);
    } else {
      v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str4);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2449, 0ULL, 1);
    v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str5);
    break;
  }
  case TAG_TimedOut: {
    v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str6);
    break;
  }
  case TAG_NotRun: {
    v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str7);
    break;
  }
  default: heff_nomatch(v_t_2449);
  }
  V v_t_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str8), heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str9)));
  V v_t_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str10), heff_strAppend(v_t_2448, v_t_2454));
  V v_t_2456 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str11)), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2461}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam9, 1, 2, (V[]){v_k_243, v_n_241})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nothing: {
    V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str2), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam6, 1, 2, (V[]){v_k_243, v_n_241})));
  }
  case TAG_Just: {
    V v_child_2439 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Just = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    V v_t_2441 = heff_tag_at_n(v_ru_24x_2431_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){v_child_2439, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam7_clo)})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s94900133x232571340(v_t_2446, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam8, 1, 3, (V[]){v_n_241, v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_as_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_n_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2422, v_as_240, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_str1), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam4_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s94900133x232571340(v_t_2430, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam5, 1, 3, (V[]){v_hd_242, v_k_243, v_n_241})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_as_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_n_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_lam3, 1, 4, (V[]){v_as_240, v_hd_242, v_k_243, v_n_241})));
}
Clo g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866(V v_a_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_take_field(v_a_240, 0), MK_INT(0LL));
  V v_t_242 = heff_intAdd(heff_take_field(v_a_240, 1), MK_INT(0LL));
  V v_t_243 = heff_intAdd(heff_take_field(v_a_240, 2), MK_INT(0LL));
  V v_t_244 = heff_intAdd(heff_take_field(v_a_240, 3), MK_INT(0LL));
  V v_t_245 = (g_prelude_2e_2b_2b(heff_take_field(v_a_240, 4), NTAG(TAG_Nil)));
  V v_t_246 = heff_intAdd(heff_take_field(v_a_240, 5), MK_INT(0LL));
  V v_t_247 = heff_intAdd(heff_take_field(v_a_240, 6), MK_INT(0LL));
  V v_t_248 = heff_intAdd(heff_get_n(v_a_240, 7, 8), MK_INT(0LL));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248});
}
V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649(V v_host_240, V v_s_241, V v_p_242, V v_p_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_s_241, 1));
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
  V v_t_246 = heff_strSlice(heff_dup(v_p_244), heff_box_word(v_t_245), heff_strLength_lent(v_p_244, 0));
  V v_t_249;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
    v_t_249 = heff_strSlice(v_p_244, MK_INT(0LL), heff_box_word(v_t_248));
  } else {
    v_t_249 = v_p_244;
  }
  V v_path_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str1));
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2410, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam1, 1, 4, (V[]){v_s_241, v_p_242, heff_dup(v_host_240), v_p_243})));
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam0(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam2(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2440;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop(v_x_2431);
    heff_drop(v_host_240);
    v_x_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2417, 0ULL, 1);
    V v_x1_2439;
    switch (heff_tag_of(v_x_2431)) {
    case TAG_Nothing: {
      heff_drop(v_host_240);
      v_x1_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_t_2433 = heff_field(v_x_2431, 0);
      heff_take_n(v_x_2431, 1ULL, 1);
      V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str4); V a_1 = v_t_2433; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str5), v_t_2433, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_t_2433); r_; });
      V v_t_2435 = (g_list_2emap_24s649333309x1802289391(v_t_2434));
      V v_x1_2436 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2435));
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_Nil: {
        heff_drop(v_host_240);
        v_x1_2439 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        V v_x_2437 = heff_field(v_x1_2436, 0);
        heff_take_n(v_x1_2436, 1ULL, 2);
        v_x1_2439 = heff_strEq(v_x_2437, v_host_240);
        break;
      }
      default: heff_nomatch(v_x1_2436);
      }
      break;
    }
    default: heff_nomatch(v_x_2431);
    }
    v_x_2440 = heff_bool(!(heff_dup(v_x1_2439) == NTAG(TAG_True)));
    heff_drop(v_x1_2439);
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_p_243;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_2418 = heff_get_n(v_s_241, 1, 7);
  int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_2418, 0)) - ((int64_t)3ULL));
  V v_t_2420 = heff_strSlice(heff_dup(v_p_2418), heff_box_word(v_t_2419), heff_strLength_lent(v_p_2418, 0));
  V v_t_2423;
  if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str2))) {
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_2418, 0)) - ((int64_t)3ULL));
    v_t_2423 = heff_strSlice(v_p_2418, MK_INT(0LL), heff_box_word(v_t_2422));
  } else {
    v_t_2423 = v_p_2418;
  }
  V v_path_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_str3));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2424, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam2_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_lam3, 1, 3, (V[]){v_x_2417, v_host_240, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s314333256x1854556840(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str0, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str1, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str2, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str4, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str5, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str6, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str7, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str8, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str10, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str11, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str14, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str15, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str16, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str17, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str18, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str0), NTAG(TAG_Nil)});
  V v_t_246 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str2), v_t_245}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str3), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam4(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam5(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2464);
  V v_t_2465 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam6(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam8(V self, V *args) {
  V v_x_2493 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800(v_v_240, v_pk_241, v_x_2493, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam7(V self, V *args) {
  V v_x_2492 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_x_2492; V a_1 = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()); V a_2 = heff_dup(v_hd_243); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam8, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244}); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(a_0, a_1, a_2, a_3)); heff_drop(v_x_2492); r_; });
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_src_242 = heff_env(self)[4];
  V v_pk_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = heff_take_field(v_x_2414, 0);
  V v_t_2430;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Exited: {
    V v_n_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_t_2430 = heff_bool(!heff_intEq_c_lent(v_n_2427, MK_INT(0LL), 2));
    heff_drop(v_n_2427);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2425, 3);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    heff_drop(v_t_2430);
    V v_s_2431 = heff_get_n(v_x_2414, 2, 3);
    V v_t_2432 = (g_prelude_2eskipSpaces(v_s_2431, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_s_2431, 0)) - ((int64_t)1ULL));
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2431, heff_box_word(v_t_2433), MK_INT(-1LL)));
    V v_t_2435 = heff_strSlice(v_s_2431, v_t_2432, heff_intAdd(v_t_2434, MK_INT(1LL)));
    V v_why_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str10), v_t_2435);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str11), v_why_2436), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str12));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
  } else {
    heff_drop(v_t_2430);
    V v_s_2451 = heff_get_n(v_x_2414, 1, 3);
    V v_t_2452 = (g_prelude_2eskipSpaces(v_s_2451, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2453 = (heff_unbox_word(heff_strLength_lent(v_s_2451, 0)) - ((int64_t)1ULL));
    V v_t_2454 = (g_prelude_2eskipSpaces(v_s_2451, heff_box_word(v_t_2453), MK_INT(-1LL)));
    V v_t_2455 = heff_strSlice(v_s_2451, v_t_2452, heff_intAdd(v_t_2454, MK_INT(1LL)));
    V v_t_2457 = heff_bool(!heff_strEq_c_lent(v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str13), 2));
    heff_drop(v_t_2455);
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2425, 3);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      heff_drop(v_t_2457);
      V v_t_2458 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str14), NTAG(TAG_MkUnit)});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam5, 1, 2, (V[]){v_hd_243, v_k_244})));
    } else {
      heff_drop(v_t_2457);
      V v_t_2471 = heff_get_n(v_x_2425, 0, 3);
      V v_t_2474;
      switch (heff_tag_of(v_t_2471)) {
      case TAG_Exited: {
        V v_n_2472 = heff_field(v_t_2471, 0);
        heff_take_n(v_t_2471, 1ULL, 1);
        v_t_2474 = heff_intEq(v_n_2472, MK_INT(0LL));
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2471, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2471);
      }
      if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        heff_drop(v_t_2474);
        V v_t_2475 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str15), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str16)));
        V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str17), v_t_2475), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str18));
        V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2476, NTAG(TAG_MkUnit)});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam6, 1, 2, (V[]){v_hd_243, v_k_244})));
      } else {
        heff_drop(v_t_2474);
        V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2491 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_t_2490, NTAG(TAG_Nil)));
        V f_ = v_c_2491;
        heff_room[0] = heff_dup(v_hd_243);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam7, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str4), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str6), v_t_2415})});
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str8), v_t_2416}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_str9), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam2_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_lam3, 1, 6, (V[]){v_x_2414, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})));
}