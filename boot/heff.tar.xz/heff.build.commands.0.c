// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_build 295453320
#define LBL_copies 592412158
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hash 9690581
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_own 320000
#define LBL_paths 307797256
#define LBL_prefix 967031229
#define LBL_property 1899481104
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_segments 1801007612
#define LBL_shrinks 154032591
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_watches 1357821955
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeLine(V);
V g_heff_2ebuild_2ecommands_2eoutcomeLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeLine_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_clo;
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2elower_2elowerProgramC(V, V);
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramC_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1875062608x222844981(V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s337063435x1366313299(V, V, V);
V g_list_2efilter_24s337063435x1366313299_entry(V self, V *a);
extern Clo g_list_2efilter_24s337063435x1366313299_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1842223007x322637159(V, V);
V g_list_2efoldl_24s1842223007x322637159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1842223007x322637159_clo;
V g_list_2efoldl_24s2099124872x600887319(V, V);
V g_list_2efoldl_24s2099124872x600887319_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2099124872x600887319_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s809624008x2043497973(V, V);
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a);
extern Clo g_list_2efoldl_24s809624008x2043497973_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s170418522x132668694(V);
V g_list_2emap_24s170418522x132668694_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2esortBy_24s390982605x1732870695(V);
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a);
extern Clo g_list_2esortBy_24s390982605x1732870695_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(v_x_242), v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){v_id_240}), heff_dup(g_map_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(v_id_240, heff_dup(v_text_249), MK_INT(0LL)));
  V v_t_2418;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2412;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        heff_take_n(v_x31_2414, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2416)) {
          v_t_2418 = v_x_2415;
        } else {
          heff_drop(v_x_2415);
          v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_2418, v_m_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str3, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str6, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str8, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str9, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str10, 6, " times");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str11, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str12, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str13, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str14, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str15, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str16, 16, "  (failed after ");
Clo g_heff_2ebuild_2ecommands_2eoutcomeLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeLine_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeLine(V v_o_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_242;
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str0);
  } else {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str1);
  }
  V v_t_243 = heff_dup(heff_rfield(v_o_240, 2));
  V v_t_244 = heff_bool(!(heff_dup(v_t_243) == NTAG(TAG_True)));
  heff_drop(v_t_243);
  V v_t_2420;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str2);
  } else {
    heff_drop(v_t_244);
    V v_t_245 = heff_dup(heff_rfield(v_o_240, 1));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ebuild_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str4)));
    } else {
      heff_drop(v_t_245);
      V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_o_240, 3)));
      V v_t_2410;
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 4)))) {
        V v_t_249 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
        v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str6)));
      } else {
        v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str7);
      }
      V v_n_2411 = heff_dup(heff_rfield(v_o_240, 5));
      V v_t_2415;
      if (heff_intEq_c(heff_dup(v_n_2411), MK_INT(0LL))) {
        heff_drop(v_n_2411);
        v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str8);
      } else {
        if (heff_intEq_c(heff_dup(v_n_2411), MK_INT(1LL))) {
          heff_drop(v_n_2411);
          v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str9);
        } else {
          V v_t_2414 = heff_strAppend(heff_intShow(v_n_2411), ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str10));
          v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str11), v_t_2414);
        }
      }
      V v_t_2416 = heff_intShow(heff_dup(heff_rfield(v_o_240, 9)));
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str12), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str13)));
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str14), heff_strAppend(v_t_2415, v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str15), heff_strAppend(v_t_2410, v_t_2418));
      v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str16), heff_strAppend(v_t_247, v_t_2419));
    }
  }
  V v_t_2421 = heff_strAppend(heff_get_n(v_o_240, 0, 10), v_t_2420);
  return heff_strAppend(v_t_242, v_t_2421);
}
V g_heff_2ebuild_2ecommands_2eoutcomeLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st)) return g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val, &g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st, g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str0, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str1, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str2, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str3, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str4, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str5, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str7, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str8, 33, "main = program (io := here stdio)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str9, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str12, 50, "program : {{io : stdio <: stdio}} -> Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str13, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str15, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str16, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str17, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str8), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str13), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_249})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str17); V a_1 = v_t_241; V a_2 = v_t_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2410, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2413, v_x_2418));
  V v_x_2420 = ({ V a_0 = v_st_2413; V a_1 = v_t_2419; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2413); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str1))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5, 1, 2, (V[]){v_st_2413, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2421 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, heff_dup(v_m_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2419})});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_248;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(V v_ps_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    top_TAG_Nothing: ;
    V v_t_243 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(v_b_241), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(v_ps_240, v_b_241, v_t_243);
  }
  case TAG_Just: {
    V v_kept_244 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_str0), v_kept_244, MK_INT(0LL), 5);
    if (heff_intLt_c(heff_dup(v_j_245), MK_INT(0LL))) {
      heff_drop(v_kept_244);
      heff_drop(v_j_245);
      V t_0 = v_ps_240;
      V t_1 = v_b_241;
      V t_2 = NTAG(TAG_Nothing);
      v_ps_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top_TAG_Nothing;
    } else {
      V v_t_247 = heff_intSub(heff_strLength_lent(v_kept_244, 0), heff_dup(v_j_245));
      if (heff_intEq_c(heff_intSub(v_t_247, MK_INT(1LL)), heff_strLength_lent(v_b_241, 0))) {
        V v_t_249 = heff_strSlice(heff_dup(v_kept_244), heff_intAdd(heff_dup(v_j_245), MK_INT(1LL)), heff_strLength_lent(v_kept_244, 0));
        if (heff_strEq_c_lent(v_t_249, v_b_241, 1)) {
          heff_drop(v_ps_240);
          heff_drop(v_b_241);
          return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0, 2, 2, (V[]){v_kept_244, v_j_245});
        } else {
          heff_drop(v_kept_244);
          heff_drop(v_j_245);
          V t_0 = v_ps_240;
          V t_1 = v_b_241;
          V t_2 = NTAG(TAG_Nothing);
          v_ps_240 = t_0;
          v_b_241 = t_1;
          v_x3_242 = t_2;
          goto top_TAG_Nothing;
        }
      } else {
        heff_drop(v_kept_244);
        heff_drop(v_j_245);
        V t_0 = v_ps_240;
        V t_1 = v_b_241;
        V t_2 = NTAG(TAG_Nothing);
        v_ps_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top_TAG_Nothing;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_kept_244 = heff_env(self)[0];
  V v_j_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_strSlice(v_kept_244, MK_INT(0LL), v_j_245);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3(V self, V *args) {
  V v_ns_2416 = args[0];
  return v_ns_2416;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s954557541x749476273(v_t_2434, v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2424) == NTAG(TAG_True))) {
    heff_drop(v_x_2424);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2424);
    heff_drop(v_done_241);
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str1));
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s954557541x749476273(v_t_2429, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7, 1, 2, (V[]){v_p_243, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_t_2422; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  V v_t_2410;
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_errors_246, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_errors_246);
  }
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  } else {
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    heff_drop(v_t_2410);
    V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s954557541x749476273(v_t_2438, v_p_243, v_p_244));
  }
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V v_bi_240, V v_dir_241, V v_runtime_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = heff_get_n(heff_get_n(v_c_244, 5, 13), 0, 9);
  V v_t_2413 = (g_map_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2414 = (g_list_2emap_24s1173914895x100384474(v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1842223007x322637159(heff_dup(g_map_2eempty_get()), v_bs_2414));
  V v_t_2416 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2414; V r_ = (g_list_2efoldl_24s809624008x2043497973(a_0, a_1)); heff_drop(v_bs_2414); r_; });
  V v_t_2417 = (g_map_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s2099124872x600887319(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2420 = ({ V a_0 = v_runtime_242; V a_1 = v_available_245; V a_2 = v_t_2412; V a_3 = heff_take_field(v_r_246, 0); V a_4 = heff_get_n(v_r_246, 1, 2); V a_5 = heff_dup(heff_rfield(v_bi_240, 1)); V a_6 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2415, v_t_2416}); V a_7 = v_t_2419; V r_ = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2419); r_; });
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(v_bi_240, v_dir_241, v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2420, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str3, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_runtime_244, V v_done_245, V v_c_246, V v_available_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0, 1, 1, (V[]){heff_dup(v_c_246)}), heff_dup(heff_rfield(v_c_246, 7))));
  V v_t_2418 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2417));
  V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2419));
  V v_t_2422 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1, 1, 1, (V[]){heff_dup(v_available_247)}), v_t_2420));
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_c_246); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_runtime_244);
      heff_drop(v_done_245);
      heff_drop_rec(v_c_246, 13);
      heff_drop(v_available_247);
      V v_why_2427 = v_field_2425;
      V v_t_2428 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str0), v_why_2427));
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str1), v_t_2428), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str2));
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2, 1, 2, (V[]){v_z_248, v_z_249})));
    } else {
      heff_drop(v_file_241);
      V v_r_2439 = v_field_2425;
      int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2441 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2440), heff_strLength_lent(v_outPath_243, 0));
      if (heff_strEq_c(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str3))) {
        int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2443)), v_runtime_244, v_done_245, v_c_246, v_available_247, v_r_2439, v_z_248, v_z_249));
      } else {
        heff_drop(v_bi_240);
        V v_t_2444 = (g_list_2eany_24s762674996x1009180162(v_available_247));
        V v_t_2445;
        if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
          heff_drop(v_t_2444);
          v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2444);
          v_t_2445 = NTAG(TAG_Nil);
        }
        V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){heff_take_field(v_r_2439, 1)}));
        V v_t_2447 = heff_get_n(heff_get_n(v_c_246, 5, 13), 0, 9);
        V v_t_2448 = (g_heff_2ecompile_2elower_2elowerProgramC(v_t_2447, heff_get_n(v_r_2439, 0, 2)));
        V v_t_2449 = (g_heff_2ecompile_2eemitc_2eoutputOf(v_runtime_244, v_available_247, heff_rec_n(2, shape_prefix__end, (V[]){v_t_2445, v_t_2446}), v_t_2448));
        return (g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(v_outPath_243, v_done_245, v_t_2449, v_z_248, v_z_249));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0(V self, V *args) {
  V v_o_2410 = args[0];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_246, heff_dup(heff_rfield(v_o_2410, 1))));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_eff_2415 = v_field_2413;
      V v_t_2416 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2410, 0), heff_get_n(v_o_2410, 1, 2), v_eff_2415});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    } else {
      heff_drop_rec(v_o_2410, 2);
      heff_drop(v_field_2413);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1(V self, V *args) {
  V v_k_2421 = args[0];
  V v_available_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_247; V a_1 = v_k_2421; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_247); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2(V self, V *args) {
  V v_x_2434 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s954557541x749476273(v_t_2438, v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str1, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str3, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str4, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str5, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str6, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str7, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str8, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310(V v_who_240, V v_st_241, V v_opt_242, V v_p_243, V v_dir_244, V v_out_245, V v_next_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_dir_244), ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam1, 1, 9, (V[]){heff_dup(v_st_241), v_dir_244, v_p_243, v_hd_247, v_opt_242, v_out_245, v_next_246, v_k_248, v_who_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam0(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_241; V a_1 = v_dir_244; V a_2 = v_n_2417; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam3(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam5(V self, V *args) {
  V v_r_2430 = args[0];
  return v_r_2430;
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s954557541x749476273(v_t_2450, v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_who_240 = heff_env(self)[0];
  V v_out_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_strAppend(v_who_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str8), v_out_245));
  V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str9)), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s954557541x749476273(v_t_2445, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam9, 1, 2, (V[]){v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_next_246 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  V v_who_240 = heff_env(self)[4];
  V v_out_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2434);
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_2432, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_x_2432, 3);
    heff_drop(v_who_240);
    heff_drop(v_out_245);
    V f_ = v_next_246;
    heff_room[0] = v_hd_247;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_246);
    V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2432, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s954557541x749476273(v_t_2439, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam8, 1, 4, (V[]){v_who_240, v_out_245, v_hd_247, v_k_248})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  V v_who_240 = heff_env(self)[4];
  V v_out_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2433 = heff_tag_n(TAG_End, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2433}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam7, 1, 6, (V[]){v_x_2432, v_next_246, v_hd_247, v_k_248, v_who_240, v_out_245})));
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_opt_242 = heff_env(self)[0];
  V v_out_245 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_next_246 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_who_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str3), NTAG(TAG_Nil)});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_opt_242, v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str5), NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str6), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_245), v_t_2426})});
  V v_t_2428 = (g_prelude_2e_2b_2b(v_x_2418, v_t_2427));
  V v_as_2429 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2428));
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2423), ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str7), v_as_2429, ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam5_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam6, 1, 6, (V[]){v_x_2423, v_hd_247, v_next_246, v_k_248, v_who_240, v_out_245})));
}
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_opt_242 = heff_env(self)[4];
  V v_out_245 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  V v_who_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2416 = (g_list_2efilter_24s337063435x1366313299(((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str0), ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str1), v_t_2415));
  V v_x_2418 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam2, 1, 2, (V[]){v_st_241, v_dir_244}), v_t_2416));
  V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2418));
  V v_total_2420 = heff_intAdd(v_t_2419, MK_INT(1LL));
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_243, ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_str2), v_total_2420, ((V)&g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam3_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_lam4, 1, 7, (V[]){v_opt_242, v_out_245, v_x_2418, v_hd_247, v_next_246, v_k_248, v_who_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str3, 1, ".");
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8(V self, V *args) {
  V v_t_2434 = args[0];
  return v_t_2434;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nothing: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2438, 0ULL, 1);
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V f_ = v_k_2433;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_path_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2431, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam9, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam11(V self, V *args) {
  V v_n_2445 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = ({ V a_0 = v_st_2422; V a_1 = v_p_248; V a_2 = v_n_2445; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2422); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2446});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam10(V self, V *args) {
  V v_x_2442 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_ns_2428 = heff_env(self)[4];
  V v_st_2422 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2442) == NTAG(TAG_True))) {
    heff_drop(v_x_2442);
    heff_drop(v_ns_2428);
    heff_drop(v_st_2422);
    heff_drop(v_p_248);
    V v_t_2443 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, v_acc_241));
    V f_ = v_t_2443;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2442);
    V v_t_2444 = (g_list_2efilter_24s2101000672x961294372(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str3), v_ns_2428));
    V v_t_2447 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam11, 1, 2, (V[]){v_st_2422, v_p_248}), v_t_2444));
    V v_t_2448 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2447, v_acc_241));
    V f_ = v_t_2448;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2422;
  if (heff_strEq_c(v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str0))) {
    v_st_2422 = NTAG(TAG_Windows);
  } else {
    v_st_2422 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_top_247);
    heff_drop(v_st_2422);
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_p_248, 0)) - ((int64_t)3ULL));
    V v_t_2424 = heff_strSlice(heff_dup(v_p_248), heff_box_word(v_t_2423), heff_strLength_lent(v_p_248, 0));
    if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str1))) {
      V v_t_2426 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2426;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2427 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, v_acc_241));
      V f_ = v_t_2427;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2428 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_c_2441;
    if ((heff_dup(v_top_247) == NTAG(TAG_True))) {
      heff_drop(v_top_247);
      v_c_2441 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6_clo);
    } else {
      heff_drop(v_top_247);
      V v_path_2431 = (g_std_2epath_2ejoin(v_st_2422, heff_dup(v_p_248), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str2)));
      v_c_2441 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7, 2, 1, (V[]){v_path_2431});
    }
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam10, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2428, v_st_2422, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5, 1, 7, (V[]){v_x_2415, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_top_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0, 1, 5, (V[]){v_cs_242, heff_dup(v_badL_241), v_hd_243, v_k_244, v_file_240})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_2424) == NTAG(TAG_True))) {
    heff_drop(v_x_2424);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2424);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_badL_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_2410 = v_field_248;
      V v_t_2411;
      if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
        heff_drop(v_cs_242);
        heff_drop(v_badL_241);
        v_t_2411 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_241);
        v_t_2411 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_242); r_; });
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_file_240);
        heff_drop_rec(v_c_2410, 13);
        heff_drop(v_t_2411);
        V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
        return (g_co_2eop_24s954557541x749476273(v_t_2415, v_hd_243, v_k_244));
      } else {
        heff_drop(v_t_2411);
        V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_c_2410, 5)), 4, 9);
        V v_t_2417 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2410), v_t_2416));
        V v_t_2418 = (g_list_2esortBy_24s390982605x1732870695(v_t_2417));
        V v_str_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str1); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str2); V a_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str3); V a_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2410, 3, 13); V a_7 = v_t_2418; V r_ = (g_list_2efoldl_24s1149369025x804005338(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2418); r_; });
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2419, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1_clo)})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2, 1, 2, (V[]){v_k_244, v_hd_243})));
      }
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_file_240);
      heff_drop(v_field_248);
      V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      return (g_co_2eop_24s954557541x749476273(v_t_2432, v_hd_243, v_k_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0, 1, 1, (V[]){heff_dup(v_c_2413)}), heff_dup(heff_rfield(v_c_2413, 7))));
      V v_t_2422 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2421));
      V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
      V v_t_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
      V v_xs_2425 = (g_list_2emap_24s803586165x1676441765(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str3), v_t_2424));
      V v_t_2426 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2425));
      V v_c_2427 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(v_sources_241, v_t_2426));
      return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2413, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str7), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0(V self, V *args) {
  V v_o_2414 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2413, heff_dup(heff_rfield(v_o_2414, 1))));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_eff_2419 = v_field_2417;
      V v_t_2420 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2414, 0), heff_get_n(v_o_2414, 1, 2), v_eff_2419});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    } else {
      heff_drop_rec(v_o_2414, 2);
      heff_drop(v_field_2417);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2413 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2429 = (g_list_2efilter_24s1875062608x222844981(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str4), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str5), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str6), v_x_2428));
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2413; V a_6 = v_t_2429; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2(V self, V *args) {
  V v_x_2434 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s954557541x749476273(v_t_2438, v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam0, 2, 5, (V[]){v_c_244, v_file_242, heff_dup(v_name_240), v_outPath_241, v_done_243});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = (g_list_2emap_24s170418522x132668694(heff_dup(heff_rfield(v_x_2410, 0))));
  V v_t_2412 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_247, 2), heff_take_field(v_x_2410, 1), v_t_2411});
  return ({ V a_0 = v_t_2412; V a_1 = heff_get_n(v_x_247, 0, 5); V a_2 = v_file_242; V a_3 = v_name_240; V a_4 = v_outPath_241; V a_5 = v_done_243; V b_6 = heff_intLt(MK_INT(0LL), v_x_248); V a_7 = heff_get_n(v_x_2410, 0, 2); V a_8 = v_hd_245; V a_9 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(a_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(v_name_240); heff_drop(b_6); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_247)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam3, 1, 8, (V[]){v_x_247, v_file_242, v_name_240, v_outPath_241, v_done_243, v_x_248, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_str0), heff_dup(heff_rfield(v_x_247, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam2, 1, 7, (V[]){v_x_247, v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_lam1, 1, 6, (V[]){v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})));
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2414);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2415 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2417, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2415; V a_3 = v_t_2418; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str1));
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2, 1, 1, (V[]){v_k_243})));
  }
  case TAG_Just: {
    V v_src_2415 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_c_2416 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_241)));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2415, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str1, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str2, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str3, 5, "=def ");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 13);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), heff_dup(v_k_244)));
    V v_t_247 = heff_strAppend(heff_dup(v_k_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str0), v_t_246));
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etyDump(heff_dup(heff_rfield(v_c_240, 5)), heff_dup(v_k_244)));
    V v_t_249 = (g_heff_2eelab_2etoplevel_2ebodyDump(heff_dup(heff_rfield(v_c_240, 5)), v_k_244));
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str1), v_t_249), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str2), v_t_248), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str3), v_t_247), v_t_2411});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1, 2, 3, (V[]){v_t_2412, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(v_c_240, v_rest_245));
  V f_ = v_t_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4(V self, V *args) {
  V v_ok_2441 = args[0];
  return v_ok_2441;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2452);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2459);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2414 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2429) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
      heff_drop(v_x_2445);
      heff_drop(v_st_2414);
      heff_drop(v_f_246);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2445);
      heff_drop(v_rest_245);
      V v_t_2446 = ({ V a_0 = v_st_2414; V a_1 = v_dir_240; V a_2 = v_f_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2414); r_; });
      V v_str_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str2), v_t_2446);
      V v_t_2448 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2447, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str3)), NTAG(TAG_MkUnit)});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      return (g_co_2eop_24s954557541x749476273(v_t_2451, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6, 1, 1, (V[]){v_p_243})));
    }
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_x_2429);
    heff_drop(v_rest_245);
    V v_t_2453 = ({ V a_0 = v_st_2414; V a_1 = v_dir_240; V a_2 = v_f_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2414); r_; });
    V v_str_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str4), v_t_2453);
    V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2454, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str5)), NTAG(TAG_MkUnit)});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s954557541x749476273(v_t_2458, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam7, 1, 1, (V[]){v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2430 = (g_std_2epath_2ejoin(v_st_2414, heff_dup(v_dir_240), heff_dup(v_f_246)));
  int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2432 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2431), heff_strLength_lent(v_f_246, 0));
  V v_str_2440;
  if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str1))) {
    HeffT2 v_t_2434 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_x_2438 = v_field_2436;
        heff_drop(v_x_2438);
        v_str_2440 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2439 = v_field_2436;
        v_str_2440 = v_out_2439;
      }
    }
  } else {
    v_str_2440 = v_text_247;
  }
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2430, v_str_2440, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5, 1, 7, (V[]){v_x_2429, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2414, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_s_2415 = (g_std_2epath_2ejoin(v_st_2414, heff_dup(v_dir_240), heff_dup(v_f_246)));
  HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(v_st_2414, v_s_2415));
  V v_t_2423;
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2419));
    V v_xs_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2420; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2420); r_; });
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    v_t_2423 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2417, v_field_2418, v_t_2422});
  }
  V v_path_2424 = (g_std_2epath_2erender(v_st_2414, v_t_2423));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2424, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3, 1, 7, (V[]){v_st_2414, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str0, 3, "PWD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str2, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str3, 7, "heff: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str4, 73, "` cannot name a package: a lowercase letter, then letters, digits and `_`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str6, 63, "heff: `heff` is heff's own package: name the project otherwise\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str7, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str8, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str11, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str12, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str13, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str15, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str0), ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5(V self, V *args) {
  V v_s_2428 = args[0];
  return v_s_2428;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s954557541x749476273(v_t_2451, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s954557541x749476273(v_t_2461, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2462) == NTAG(TAG_True))) {
    heff_drop(v_x_2462);
    V v_t_2463 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str7), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str8)));
    V v_t_2464 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2463, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str9)), NTAG(TAG_MkUnit)});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    return (g_co_2eop_24s954557541x749476273(v_t_2467, v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_2462);
    heff_drop(v_dir_240);
    V v_t_2468 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s954557541x749476273(v_t_2471, v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  return (g_co_2eop_24s954557541x749476273(v_t_2487, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2440 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_x_2435)));
  V v_t_2441 = heff_bool(!(heff_dup(v_x1_2440) == NTAG(TAG_True)));
  heff_drop(v_x1_2440);
  if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    heff_drop(v_dir_240);
    heff_drop(v_x_2438);
    heff_drop(v_t_2441);
    V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str3), heff_strAppend(v_x_2435, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str4)));
    V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str5)), NTAG(TAG_MkUnit)});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s954557541x749476273(v_t_2446, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8, 1, 2, (V[]){v_hd_241, v_k_242})));
  } else {
    heff_drop(v_t_2441);
    if (heff_strEq_c(v_x_2435, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      heff_drop(v_x_2439);
      heff_drop(v_dir_240);
      heff_drop(v_x_2438);
      V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str6), NTAG(TAG_MkUnit)});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      switch (heff_tag_of(v_x_2439)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(heff_dup(v_dir_240), v_x_2438, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2438);
        V v_t_2476;
        switch (heff_tag_of(v_x_2439)) {
        case TAG_Nil: {
          v_t_2476 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2474 = heff_field(v_x_2439, 0);
          V v_xs_2475 = heff_field(v_x_2439, 1);
          heff_take_n(v_x_2439, 3ULL, 2);
          v_t_2476 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str11); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
          break;
        }
        default: heff_nomatch(v_x_2439);
        }
        V v_t_2477 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str12), heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str13)));
        V v_str_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str14), heff_strAppend(v_dir_240, v_t_2477));
        V v_t_2479 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2478, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str15)), NTAG(TAG_MkUnit)});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
        return (g_co_2eop_24s954557541x749476273(v_t_2482, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2439);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2434;
  if (heff_strEq_c(v_x_2432, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str1))) {
    v_t_2434 = NTAG(TAG_Windows);
  } else {
    v_t_2434 = NTAG(TAG_Posix);
  }
  V v_x_2435 = ({ V a_0 = v_t_2434; V a_1 = heff_dup(v_dir_240); V a_2 = v_x_247; V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2434); heff_drop(v_x_247); r_; });
  V v_t_2437;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2436 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    v_t_2437 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_x_2438 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2435), v_t_2437));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(heff_dup(v_dir_240), heff_dup(v_x_2438), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7, 1, 5, (V[]){v_x_2435, v_hd_241, v_k_242, v_dir_240, v_x_2438})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2427;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_x_2427 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    HeffT2 v_t_2415 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_2414));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2413_24Just, 1);
        V v_p_2419 = v_field_2417;
        heff_drop(v_p_2419);
        v_x_2427 = NTAG(TAG_Nothing);
      } else {
        V v_x_2420 = v_field_2417;
        HeffT2 v_t_2421 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2420));
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2413_24Just, 1);
            V v_x_2425 = v_field_2423;
            heff_drop(v_x_2425);
            v_x_2427 = NTAG(TAG_Nothing);
          } else {
            V v_p_2426 = v_field_2423;
            v_x_2427 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2426, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5_clo)})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6, 1, 5, (V[]){v_dir_240, v_x_247, v_x_2427, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_248, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_247, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_247, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str2, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str3, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str4, 24, ": its tag has been moved");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str5, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str6, 1, " ");
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2efilter_24s2128134357x1680551385(heff_dup(v_path_244), heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2efilter_24s50027113x1989932102(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_c_2413 = (g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0, 2, 6, (V[]){v_c_2413, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2436 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_t_2437 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), v_d_2436));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2437, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2414);
    V v_t_2418 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str0), v_why_2417));
    V v_t_2419 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str1), v_t_2418));
    V v_t_2420 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str2), v_t_2419));
    V f_ = v_k_2415;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2420});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2421 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2422 = (g_list_2efilter_24s639151216x1214259357(heff_dup(v_path_244), heff_dup(v_v_245), v_sums_242));
    V v_t_2425;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 2);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Just, 1, (V[]){heff_get_n(v_s_2423, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nothing: {
      heff_drop(v_h_2421);
      V v_t_2426 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2427 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2426, v_path_244));
      V f_ = v_t_2427;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_want_2428 = heff_field(v_t_2425, 0);
      V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
      if (heff_strEq_c_lent(v_h_2421, v_want_2428, 0)) {
        heff_drop(v_h_2421);
        heff_drop(v_want_2428);
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        V v_t_2430 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2431 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2430, v_path_244));
        V f_ = v_t_2431;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_2414);
        V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str3), heff_strAppend(v_want_2428, ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str4)));
        V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str5), heff_strAppend(v_h_2421, v_t_2432));
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str6), heff_strAppend(v_v_245, v_t_2433));
        V v_t_2435 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_path_244, v_t_2434)});
        V f_ = v_k_2415;
        args[0] = v_t_2435;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2415, v_sums_242, v_ps_240, v_hd_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str1, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str6, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str7, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str0), v_x_243));
    V v_p_2413 = (g_std_2epath_2ejoin(v_st_240, v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str1)));
    V v_t_2414 = (g_std_2epath_2ejoin(v_st_240, heff_get_n(v_t_241, 0, 6), v_p_2413));
    V v_x2_2415 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str2), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str3), v_missing_245));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str5); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str6), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str7)));
    V v_str_2420 = heff_strAppend(v_t_2414, v_t_2419);
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2420, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str8)), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s954557541x749476273(v_t_2424, v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str4, 6, ": git ");
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str0), heff_dup(v_as_241), ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_as_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2420;
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_248, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_x_248, 3);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    v_x_2420 = NTAG(TAG_Nothing);
  } else {
    V v_t_2412;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_as_241, 0);
      V v_xs_2411 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2413 = heff_get_n(v_x_248, 2, 3);
    V v_t_2414 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_s_2413, 0)) - ((int64_t)1ULL));
    V v_t_2416 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), heff_box_word(v_t_2415), MK_INT(-1LL)));
    V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
    V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str3), v_t_2417));
    V v_t_2419 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str4), v_t_2418));
    v_x_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  }
  V f_ = v_k_243;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}