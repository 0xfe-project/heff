// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_Collected 38917
#define TAG_Copy 17796
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Holds 53574
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkGroup 19195
#define TAG_MkPath 49630
#define TAG_Move 53768
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Open 48267
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_command 1182252425
#define LBL_copies 592412158
#define LBL_dir 308999
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_groups 709681407
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_jss 315076
#define LBL_keep 9783372
#define LBL_launch 837298910
#define LBL_loaded 849622832
#define LBL_mods 9852536
#define LBL_modules 1459291593
#define LBL_olds 9909235
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_program 2069953735
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s851371283x356629733(V, V, V, V, V);
V g_co_2eop_24s851371283x356629733_entry(V self, V *a);
extern Clo g_co_2eop_24s851371283x356629733_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_clo;
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_clo;
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2egoldenPart(V);
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_clo;
V g_heff_2ebuild_2ecommands_2erevNamed(V);
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevNamed_clo;
V g_heff_2ebuild_2ecommands_2erevSaid(V);
V g_heff_2ebuild_2ecommands_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevSaid_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eproject_2epseudoVersion(V, V, V);
V g_heff_2ebuild_2eproject_2epseudoVersion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoVersion_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s814399109x689165205_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2ekeepIf_24s654566231x1096033(V, V, V, V);
V g_list_2ekeepIf_24s654566231x1096033_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s654566231x1096033_clo;
V g_list_2ekeepIf_24s948662626x57542548(V, V);
V g_list_2ekeepIf_24s948662626x57542548_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s948662626x57542548_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2emap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2418;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2412;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        heff_take_n(v_x31_2414, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2416)) {
          v_t_2418 = v_x_2415;
        } else {
          heff_drop(v_x_2415);
          v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, v_t_246, v_t_2418));
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenPart_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenPart(V v_n_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_n_240, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_n_240, MK_INT(0LL), 2)) == ((int64_t)46ULL))) {
      return NTAG(TAG_False);
    } else {
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_n_240, 0)) - ((int64_t)1ULL));
      V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_243)));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenPart_lam0, 1, 1, (V[]){heff_dup(v_n_240)}); V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenPart(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2egoldenByte(heff_strByteAt(v_n_240, v_i_245)));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  return v_v_2420;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2455;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2428)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2428, 0);
        heff_take_n(v_x_2428, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_x_2428);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_t_2443 = (g_std_2epath_2eparse(v_st_2439, v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str5)));
    V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
    V v_a_2446 = ({ V a_0 = v_st_2439; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2445); r_; });
    V v_t_2447 = (g_std_2epath_2eparse(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str6)));
    V v_t_2448 = (g_std_2epath_2eparse(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str7)));
    V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
    V v_b_2450 = ({ V a_0 = v_st_2439; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2449); r_; });
    V v_t_2451 = (g_std_2epath_2eparse(v_st_2439, v_a_2446));
    V v_t_2452 = (g_std_2epath_2eparse(v_st_2439, v_b_2450));
    V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
    v_x_2455 = ({ V a_0 = v_st_2439; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2453); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2454 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2428);
    heff_drop(v_st_2439);
    v_x_2455 = v_d_2454;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_241;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(v_t_2436, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7, 1, 4, (V[]){v_x_2410, v_x_2419, v_x_2428, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5, 1, 4, (V[]){v_hd_240, v_x_2410, v_x_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3, 1, 3, (V[]){v_hd_240, v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_246));
    V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str0))));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_s_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_path_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2411; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2, 2, 4, (V[]){v_a_2415, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_t_2428 = v_x_2426;
    break;
  }
  case TAG_Just: {
    V v_text_2427 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2427}), v_x_2426});
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V f_ = v_k_2417;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2425 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(v_ps_240, v_rest_245));
  V f_ = v_c_2425;
  heff_room[0] = v_hd_2416;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4, 1, 3, (V[]){v_x_2424, v_m_244, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_a_2415 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(v_t_2423, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_2416, v_m_244, v_k_2417})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3(V self, V *args) {
  V v_ns_2421 = args[0];
  return v_ns_2421;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2433) == NTAG(TAG_True))) {
    heff_drop(v_x_2433);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2433);
    heff_drop(v_done_241);
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str1));
    V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2434, NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7, 1, 2, (V[]){v_p_243, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2432);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    v_t_2431 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2430 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_t_2431; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_path_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2419); r_; });
  V v_a_2422 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s495635622x733177935(v_t_2428, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2452 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str10, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str11, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str17, 1, "\"");
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
      V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0_clo)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})));
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2430 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str2), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str3)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2430});
    }
  }
  case TAG_Just: {
    V v_kept_2431 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2431, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2431);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2431);
        V v_path_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2433; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2433); r_; });
        V v_a_2436 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2434, v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4_clo)});
        V v_t_2437 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
        V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
        return (g_co_2eop_24s495635622x733177935(v_t_2442, v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5, 1, 2, (V[]){v_path_242, v_z_246})));
      } else {
        heff_drop(v_z_245);
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        V v_t_2445 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str6); V a_1 = v_kept_2431; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str7), v_kept_2431, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_kept_2431); r_; });
        V v_t_2446 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str8); V a_1 = v_text_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str9), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_243); r_; });
        HeffT2 v_t_2447 = (g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(MK_INT(1LL), v_t_2445, v_t_2446));
        {
          V v_field_2448 = v_t_2447.f[0];
          V v_field_2449 = v_t_2447.f[1];
          V v_n_2450 = v_field_2448;
          V v_x22_2451 = v_field_2449;
          V v_x_2460;
          switch (heff_tag_of(v_x22_2451)) {
          case TAG_MkPair: {
            V v_kept_2452 = heff_field(v_x22_2451, 0);
            V v_text_2453 = heff_field(v_x22_2451, 1);
            V v_ru_24x22_2451_24MkPair = heff_take_reuse_n(v_x22_2451, 3ULL, 2);
            V v_t_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str10), heff_intShow(v_n_2450));
            V v_t_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str11), heff_strAppend(v_path_242, v_t_2454));
            V v_t_2456 = ({ V a_0 = v_kept_2452; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2452); r_; });
            V v_t_2457 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str13), heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str14)));
            V v_t_2458 = ({ V a_0 = v_text_2453; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2453); r_; });
            V v_t_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str16), heff_strAppend(v_t_2458, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str17)));
            v_x_2460 = heff_tag_at_n(v_ru_24x22_2451_24MkPair, TAG_Wrong, 2, (V[]){v_t_2455, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2457, v_t_2459})});
            break;
          }
          default: heff_nomatch(v_x22_2451);
          }
          return heff_tail(v_z_246, 1, (V[]){v_x_2460});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429;
  if ((heff_dup(v_x_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2428);
    v_t_2429 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2428);
    v_t_2429 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str0), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str1)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  V v_path_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2418; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2418); r_; });
  V v_a_2421 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2419, v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2_clo)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(v_t_2427, v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3, 1, 2, (V[]){v_path_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4(V self, V *args) {
  V v_ok_2435 = args[0];
  return v_ok_2435;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444;
  if ((heff_dup(v_x_2443) == NTAG(TAG_True))) {
    heff_drop(v_x_2443);
    v_t_2444 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2443);
    v_t_2444 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str4), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str5)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(V v_rep_240, V v_opts_241, V v_done_242, V v_x3_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_done_242);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){v_acc_244});
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_x3_243, 0);
    V v_rest_248 = heff_field(v_x3_243, 1);
    V v_p_249 = heff_dup(heff_rfield(v_r_247, 1));
    V v_t_2410 = (g_list_2ekeepIf_24s948662626x57542548(heff_dup(heff_rfield(v_r_247, 0)), heff_dup(v_done_242)));
    V v_t_2411 = (g_list_2esortBy_24s196358923x1153659155(v_t_2410));
    V v_more_2412 = (g_list_2emap_24s1498757180x165099811(v_t_2411));
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_249, 3)), v_more_2412));
    V v_c_2414 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_249, 0)), v_t_2413));
    V v_k_2417 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0, 1, 7, (V[]){v_acc_244, heff_dup(v_rep_240), heff_dup(v_opts_241), v_done_242, heff_dup(v_rest_248), heff_dup(v_z_245), v_z_246});
    return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1, 1, 5, (V[]){v_opts_241, v_k_2417, v_rep_240, v_p_249, v_z_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_acc_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_244, v_x_2415));
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_done_242; V a_3 = v_rest_248; V a_4 = v_t_2416; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rest_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_p_249 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2418)));
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_x_2418);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_249, 7);
    heff_drop(v_z_245);
    heff_drop(v_t_2419);
    V f_ = v_k_2417;
    args[0] = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get());
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2419);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_249, 0)), heff_dup(heff_rfield(v_p_249, 1)), heff_get_n(v_p_249, 2, 7), v_x_2418, v_z_245, v_k_2417));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str1, 0, "");
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(V v_rep_240, V v_prog_241, V v_rx_242, V v_ex_243, V v_opts_244, V v_ready_245, V v_acc_246) {
top: ;
  switch (heff_tag_of(v_ready_245)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_rx_242);
    heff_drop(v_ex_243);
    heff_drop_rec(v_opts_244, 4);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0, 2, 1, (V[]){v_acc_246});
  }
  case TAG_Cons: {
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2, 2, 8, (V[]){v_t_2412, v_rx_242, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246});
  }
  default: return heff_nomatch(v_ready_245);
  }
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_acc_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_acc_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4(V self, V *args) {
  V v_i_2416 = args[0];
  return v_i_2416;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_244 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_acc_246 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2439);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_244; V a_2 = v_x_2433; V a_3 = v_ready_245; V a_4 = v_acc_246; V a_5 = v_hd_2413; V a_6 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_ready_245, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_opts_244 = heff_env(self)[4];
  V v_x_2433 = heff_env(self)[5];
  V v_ready_245 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2437}));
  return (g_co_2eop_24s495635622x733177935(v_t_2438, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8, 1, 7, (V[]){v_rep_240, v_opts_244, v_x_2433, v_ready_245, v_acc_246, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_opts_244 = heff_env(self)[6];
  V v_ready_245 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2434 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tr(heff_call(v_rx_242, 1, (V[]){v_t_2434}));
  return (g_co_2eop_24s495635622x733177935(v_t_2435, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7, 1, 9, (V[]){v_x_2415, v_prog_241, v_hd_2413, v_rep_240, v_opts_244, v_x_2433, v_ready_245, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_244 = heff_env(self)[0];
  V v_ready_245 = heff_env(self)[1];
  V v_ex_243 = heff_env(self)[2];
  V v_rx_242 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_p_2419 = heff_dup(heff_rfield(v_opts_244, 1));
  V v_t_2429;
  if (heff_strEq_c_lent(v_p_2419, ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str1), 2)) {
    heff_drop(v_p_2419);
    v_t_2429 = NTAG(TAG_Nil);
  } else {
    V v_t_2421 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_2419; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2419); r_; });
    V v_t_2422 = (g_list_2emap_24s1007499915x73800978(v_t_2421));
    HeffT2 v_t_2423 = (g_regex_2eallRead_24cpr(v_t_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_why_2427 = v_field_2425;
        heff_drop(v_why_2427);
        v_t_2429 = NTAG(TAG_Nil);
      } else {
        V v_sel_2428 = v_field_2425;
        v_t_2429 = v_sel_2428;
      }
    }
  }
  V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_245)));
  V v_t_2431 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2430; V r_ = (g_list_2efoldl_24s192900907x155689445(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
  V v_c_2432 = ({ V a_0 = v_ex_243; V a_1 = heff_dup(v_rx_242); V a_2 = v_t_2429; V a_3 = heff_dup(heff_rfield(v_opts_244, 2)); V b_4 = heff_tag_n(TAG_MkGroup, 1, (V[]){heff_dup(v_x_2418)}); V a_5 = v_t_2431; V a_6 = MK_INT(0LL); V a_7 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7)); heff_drop(b_4); r_; });
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6, 1, 10, (V[]){v_x_2418, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_opts_244, v_ready_245, v_acc_246, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_rx_242 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_rx_242), 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5, 1, 10, (V[]){v_opts_244, v_ready_245, v_ex_243, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3, 1, 9, (V[]){v_rx_242, v_hd_2413, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s851371283x356629733(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str0, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str1, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str2, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str5, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str6, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str8, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str9, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str11, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str12, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str13, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str14, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str16, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str17, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str18, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str19, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str20, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str21, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str22, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str23, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(V v_rep_240, V v_prog_241, V v_opts_242, V v_at_243, V v_p_244, V v_k_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_p_244, 5)), 0, 5);
  HeffT2 v_t_249 = (g_list_2efind_24s814399109x689165205_24cpr(heff_dup(v_p_244), v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_src_2413 = v_field_2411;
      HeffT2 v_t_2414 = (g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(heff_dup(v_p_244), v_src_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_prog_241);
          heff_drop(v_at_243);
          V v_why_2418 = v_field_2416;
          V v_more_2419 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str0), v_why_2418, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
          V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2419));
          V v_c_2421 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2420));
          return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
        } else {
          V v_l_2425 = v_field_2416;
          V v_t_2426 = heff_strAppend(heff_dup(heff_rfield(v_p_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str1));
          V v_t_2428 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2426, MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2_clo)})}));
          return (g_co_2eop_24s495635622x733177935(v_t_2428, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3, 1, 9, (V[]){v_prog_241, v_z_246, v_l_2425, v_p_244, v_opts_242, v_k_245, v_rep_240, v_at_243, v_z_247})));
        }
      }
    } else {
      heff_drop(v_prog_241);
      heff_drop(v_at_243);
      heff_drop(v_field_2411);
      V v_more_24167 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str22), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str23), MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
      V v_t_24168 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_24167));
      V v_c_24169 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_24168));
      return heff_tail(v_c_24169, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2424});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2422)));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2422);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2423);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2423);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2422, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2(V self, V *args) {
  V v_t_2427 = args[0];
  return v_t_2427;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6(V self, V *args) {
  V v_r_2453 = args[0];
  return v_r_2453;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_z_2459 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2468});
  heff_room[1] = v_z_2458;
  heff_room[2] = v_z_2459;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_2458 = heff_env(self)[2];
  V v_z_2459 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2467 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2466)));
  if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
    heff_drop(v_x_2466);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2467);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2458;
    heff_room[2] = v_z_2459;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2467);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2466, heff_dup(v_z_2458), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10, 1, 3, (V[]){v_k_245, v_z_2458, v_z_2459})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8(V self, V *args) {
  V v_x_2462 = args[0];
  V v_why_2457 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_2458 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_2459 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2462);
  V v_more_2463 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str8), v_why_2457, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_2464 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2463));
  V v_c_2465 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2464));
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_z_2458);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9, 1, 6, (V[]){v_opts_242, v_k_245, v_z_2458, v_z_2459, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7(V self, V *args) {
  V v_why_2457 = args[0];
  V v_z_2458 = args[1];
  V v_z_2459 = args[2];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2460 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2460}));
  return (g_co_2eop_24s495635622x733177935(v_t_2461, heff_dup(v_z_2458), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8, 1, 7, (V[]){v_why_2457, v_p_244, v_opts_242, v_z_2458, v_k_245, v_z_2459, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14(V self, V *args) {
  V v_r_2485 = args[0];
  return v_r_2485;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16(V self, V *args) {
  V v_r_24101 = args[0];
  return v_r_24101;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18(V self, V *args) {
  V v_x_24113 = args[0];
  V v_x_2481 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2497 = heff_env(self)[2];
  V v_x_2482 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_hd_2469 = heff_env(self)[7];
  V v_k_2470 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24113);
  V v_t_24117;
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Left: {
    heff_take_n(v_x_2481, 0ULL, 1);
    v_t_24117 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str10);
    break;
  }
  case TAG_Right: {
    V v_real_24115 = heff_field(v_x_2481, 0);
    heff_take_n(v_x_2481, 1ULL, 1);
    V v_t_24116 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_24117 = ({ V a_0 = v_t_24116; V a_1 = v_real_24115; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24116); heff_drop(v_real_24115); r_; });
    break;
  }
  default: heff_nomatch(v_x_2481);
  }
  V v_t_24121;
  switch (heff_tag_of(v_x_2497)) {
  case TAG_Left: {
    heff_take_n(v_x_2497, 0ULL, 1);
    v_t_24121 = v_x_2482;
    break;
  }
  case TAG_Right: {
    V v_real_24119 = heff_field(v_x_2497, 0);
    heff_take_n(v_x_2497, 1ULL, 1);
    heff_drop(v_x_2482);
    V v_t_24120 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_24121 = ({ V a_0 = v_t_24120; V a_1 = v_real_24119; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24120); heff_drop(v_real_24119); r_; });
    break;
  }
  default: heff_nomatch(v_x_2497);
  }
  V v_t_24122 = heff_get_n(heff_get_n(v_l_2425, 2, 5), 0, 6);
  V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str11), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str12)}), NTAG(TAG_Nil)});
  V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str13), v_t_24122}), v_t_24123});
  V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str14), v_t_24121}), v_t_24124});
  V v_t_24126 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_243, v_p_244, heff_rec_n(2, shape_program__env, (V[]){v_t_24117, v_t_24125})});
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24126});
  heff_room[1] = v_hd_2469;
  heff_room[2] = v_k_2470;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19(V self, V *args) {
  V v_x_24131 = args[0];
  V v_x_2481 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2497 = heff_env(self)[2];
  V v_x_2482 = heff_env(self)[3];
  V v_t_24128 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_hd_2469 = heff_env(self)[8];
  V v_k_2470 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24131);
  V v_t_24135;
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Left: {
    heff_take_n(v_x_2481, 0ULL, 1);
    v_t_24135 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str15);
    break;
  }
  case TAG_Right: {
    V v_real_24133 = heff_field(v_x_2481, 0);
    heff_take_n(v_x_2481, 1ULL, 1);
    V v_t_24134 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_24135 = ({ V a_0 = v_t_24134; V a_1 = v_real_24133; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24134); heff_drop(v_real_24133); r_; });
    break;
  }
  default: heff_nomatch(v_x_2481);
  }
  V v_t_24139;
  switch (heff_tag_of(v_x_2497)) {
  case TAG_Left: {
    heff_take_n(v_x_2497, 0ULL, 1);
    v_t_24139 = v_x_2482;
    break;
  }
  case TAG_Right: {
    V v_real_24137 = heff_field(v_x_2497, 0);
    heff_take_n(v_x_2497, 1ULL, 1);
    heff_drop(v_x_2482);
    V v_t_24138 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_24139 = ({ V a_0 = v_t_24138; V a_1 = v_real_24137; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24138); heff_drop(v_real_24137); r_; });
    break;
  }
  default: heff_nomatch(v_x_2497);
  }
  V v_t_24140 = heff_get_n(heff_get_n(v_l_2425, 2, 5), 5, 6);
  V v_t_24141 = ({ V a_0 = v_t_24140; V a_1 = v_t_24128; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24140); heff_drop(v_t_24128); r_; });
  V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str16), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str17)}), NTAG(TAG_Nil)});
  V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str18), v_t_24141}), v_t_24142});
  V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str19), v_t_24139}), v_t_24143});
  V v_t_24145 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_243, v_p_244, heff_rec_n(2, shape_program__env, (V[]){v_t_24135, v_t_24144})});
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24145});
  heff_room[1] = v_hd_2469;
  heff_room[2] = v_k_2470;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17(V self, V *args) {
  V v_x_24109 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2469 = heff_env(self)[2];
  V v_x_2481 = heff_env(self)[3];
  V v_l_2425 = heff_env(self)[4];
  V v_x_2497 = heff_env(self)[5];
  V v_x_2482 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_p_244 = heff_env(self)[8];
  V v_k_245 = heff_env(self)[9];
  V v_k_2470 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    heff_take_n(v_x_24109, 0ULL, 1);
    V v_t_24111 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
    V v_t_24112 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_24111}));
    return (g_co_2eop_24s495635622x733177935(v_t_24112, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18, 1, 9, (V[]){v_x_2481, v_l_2425, v_x_2497, v_x_2482, v_at_243, v_p_244, v_k_245, v_hd_2469, v_k_2470})));
  }
  case TAG_Right: {
    V v_s_24127 = heff_field(v_x_24109, 0);
    heff_take_n(v_x_24109, 1ULL, 1);
    V v_t_24128 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24127; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_24129 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
    V v_t_24130 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_24129}));
    return (g_co_2eop_24s495635622x733177935(v_t_24130, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19, 1, 10, (V[]){v_x_2481, v_l_2425, v_x_2497, v_x_2482, v_t_24128, v_at_243, v_p_244, v_k_245, v_hd_2469, v_k_2470})));
  }
  default: return heff_nomatch(v_x_24109);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15(V self, V *args) {
  V v_x_2493 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_hd_2469 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2481 = heff_env(self)[4];
  V v_x_2482 = heff_env(self)[5];
  V v_at_243 = heff_env(self)[6];
  V v_p_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  V v_k_2470 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x_2497;
  switch (heff_tag_of(v_x_2493)) {
  case TAG_Left: {
    V v_err_2494 = heff_field(v_x_2493, 0);
    V v_ru_24x_2493_24Left = heff_take_reuse_n(v_x_2493, 1ULL, 1);
    v_x_2497 = heff_tag_at_n(v_ru_24x_2493_24Left, TAG_Left, 1, (V[]){v_err_2494});
    break;
  }
  case TAG_Right: {
    V v_s_2495 = heff_field(v_x_2493, 0);
    V v_ru_24x_2493_24Right = heff_take_reuse_n(v_x_2493, 1ULL, 1);
    V v_t_2496 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2495; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    v_x_2497 = heff_tag_at_n(v_ru_24x_2493_24Right, TAG_Right, 1, (V[]){v_t_2496});
    break;
  }
  default: heff_nomatch(v_x_2493);
  }
  V v_t_2498 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 0, 6);
  V v_path_2499 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_t_2498; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24100 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2499; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2499); r_; });
  V v_a_24102 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24100, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16_clo)});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s495635622x733177935(v_t_24108, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17, 1, 11, (V[]){v_x_2429, v_prog_241, v_hd_2469, v_x_2481, v_l_2425, v_x_2497, v_x_2482, v_at_243, v_p_244, v_k_245, v_k_2470})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_2469 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2481 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_k_2470 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_path_2483 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2482); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2484 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2483; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2483); r_; });
  V v_a_2486 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2484, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14_clo)});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  return (g_co_2eop_24s495635622x733177935(v_t_2492, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15, 1, 10, (V[]){v_l_2425, v_hd_2469, v_x_2429, v_prog_241, v_x_2481, v_x_2482, v_at_243, v_p_244, v_k_245, v_k_2470})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_2469 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_k_2470 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2481;
  switch (heff_tag_of(v_x_2477)) {
  case TAG_Left: {
    V v_err_2478 = heff_field(v_x_2477, 0);
    V v_ru_24x_2477_24Left = heff_take_reuse_n(v_x_2477, 1ULL, 1);
    v_x_2481 = heff_tag_at_n(v_ru_24x_2477_24Left, TAG_Left, 1, (V[]){v_err_2478});
    break;
  }
  case TAG_Right: {
    V v_s_2479 = heff_field(v_x_2477, 0);
    V v_ru_24x_2477_24Right = heff_take_reuse_n(v_x_2477, 1ULL, 1);
    V v_t_2480 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2479; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    v_x_2481 = heff_tag_at_n(v_ru_24x_2477_24Right, TAG_Right, 1, (V[]){v_t_2480});
    break;
  }
  default: heff_nomatch(v_x_2477);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13, 1, 9, (V[]){v_hd_2469, v_l_2425, v_x_2429, v_prog_241, v_x_2481, v_at_243, v_p_244, v_k_245, v_k_2470})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_a_2454 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2454})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  return (g_co_2eop_24s495635622x733177935(v_t_2476, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12, 1, 8, (V[]){v_hd_2469, v_l_2425, v_x_2429, v_prog_241, v_at_243, v_p_244, v_k_245, v_k_2470})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24(V self, V *args) {
  V v_x_24163 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_24150 = heff_env(self)[1];
  V v_z_24151 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24163});
  heff_room[1] = v_z_24150;
  heff_room[2] = v_z_24151;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23(V self, V *args) {
  V v_x_24161 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_24150 = heff_env(self)[2];
  V v_z_24151 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24162 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_24161)));
  if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
    heff_drop(v_x_24161);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_24162);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_24150;
    heff_room[2] = v_z_24151;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24162);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_24161, heff_dup(v_z_24150), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24, 1, 3, (V[]){v_k_245, v_z_24150, v_z_24151})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22(V self, V *args) {
  V v_x_24157 = args[0];
  V v_why_24149 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_24150 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_24151 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24157);
  V v_more_24158 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str20), v_why_24149, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_24159 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_24158));
  V v_c_24160 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_24159));
  V f_ = v_c_24160;
  heff_room[0] = heff_dup(v_z_24150);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23, 1, 6, (V[]){v_opts_242, v_k_245, v_z_24150, v_z_24151, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21(V self, V *args) {
  V v_x_24154 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_24150 = heff_env(self)[2];
  V v_why_24149 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_z_24151 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24154);
  V v_t_24155 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_24156 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_24155}));
  return (g_co_2eop_24s495635622x733177935(v_t_24156, heff_dup(v_z_24150), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22, 1, 7, (V[]){v_why_24149, v_p_244, v_opts_242, v_z_24150, v_k_245, v_z_24151, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20(V self, V *args) {
  V v_why_24149 = args[0];
  V v_z_24150 = args[1];
  V v_z_24151 = args[2];
  V v_x_2432 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24152 = heff_tag_n(TAG_End, 2, (V[]){v_x_2432, NTAG(TAG_MkUnit)});
  V v_t_24153 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_24152}));
  return (g_co_2eop_24s495635622x733177935(v_t_24153, heff_dup(v_z_24150), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21, 1, 9, (V[]){v_x_2429, v_prog_241, v_z_24150, v_why_24149, v_p_244, v_opts_242, v_k_245, v_z_24151, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26(V self, V *args) {
  V v_x_24166 = args[0];
  V v_next_24146 = heff_env(self)[0];
  V v_hd_24164 = heff_env(self)[1];
  V v_k_24165 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24166);
  V f_ = v_next_24146;
  heff_room[0] = v_hd_24164;
  heff_room[1] = v_k_24165;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25(V self, V *args) {
  V v_hd_24164 = args[0];
  V v_k_24165 = args[1];
  V v_t_24148 = heff_env(self)[0];
  V v_next_24146 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_24148, heff_dup(v_hd_24164), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26, 1, 3, (V[]){v_next_24146, v_hd_24164, v_k_24165})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  V v_z_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_dir_2434 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_d_2435 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_st_2436 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
  V v_t_2438 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2439;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Posix: {
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str4);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2440 = (g_std_2epath_2eparse(v_st_2436, v_t_2439));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2437, v_t_2440));
  V v_out_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2441); r_; });
  V v_d_2443 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_st_2444 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2445 = (g_std_2epath_2eparse(v_st_2444, v_d_2443));
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2447;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_Posix: {
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str5);
    break;
  }
  case TAG_Windows: {
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str6);
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2448 = (g_std_2epath_2eparse(v_st_2444, v_t_2447));
  V v_t_2449 = (g_std_2epath_2ejoin(v_t_2445, v_t_2448));
  V v_s_2450 = ({ V a_0 = v_st_2444; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2449); r_; });
  V v_path_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2450; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2452 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2451; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2451); r_; });
  V v_a_2454 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6_clo)});
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str7), NTAG(TAG_Nil)});
  V v_next_24146 = ({ V a_0 = heff_dup(v_prog_241); V a_1 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7, 3, 6, (V[]){heff_dup(v_x_2429), heff_dup(v_prog_241), heff_dup(v_p_244), heff_dup(v_opts_242), heff_dup(v_k_245), heff_dup(v_rep_240)}); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str9); V a_3 = v_t_2455; V a_4 = v_t_2456; V a_5 = heff_dup(v_x_2429); V a_6 = v_dir_2434; V a_7 = v_out_2442; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11, 2, 7, (V[]){v_a_2454, heff_dup(v_l_2425), heff_dup(v_x_2429), heff_dup(v_prog_241), v_at_243, heff_dup(v_p_244), heff_dup(v_k_245)}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2455); r_; });
  V v_t_24147 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2432), NTAG(TAG_MkUnit)});
  V v_t_24148 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_24147}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(heff_dup(v_rep_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20, 3, 7, (V[]){v_x_2432, v_prog_241, v_x_2429, heff_dup(v_p_244), v_opts_242, v_k_245, v_rep_240}), v_l_2425, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get())}), heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str21)), heff_get_n(v_p_244, 0, 7), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25, 2, 2, (V[]){v_t_24148, v_next_24146}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_l_2425 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2429), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str2), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2431, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5, 1, 10, (V[]){v_l_2425, v_p_244, v_prog_241, v_x_2429, v_opts_242, v_k_245, v_rep_240, v_at_243, v_z_246, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28(V self, V *args) {
  V v_x_24172 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24172});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27(V self, V *args) {
  V v_x_24170 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24171 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_24170)));
  if ((heff_dup(v_t_24171) == NTAG(TAG_True))) {
    heff_drop(v_x_24170);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_24171);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24171);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_24170, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2431;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2431 = v_done_245;
  } else {
    V v_s_2410 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(heff_rfield(v_bi_240, 0))));
    V v_path_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2410; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
    V v_a_2414 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0_clo)});
    v_t_2431 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1, 2, 7, (V[]){v_a_2414, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(v_outPath_241, v_t_2431, heff_get_n(v_out_246, 0, 4), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2423);
  V v_t_2424 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str1), heff_take_field(v_bi_240, 2)});
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_t_2427 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_246, 1), heff_take_field(v_out_246, 2), NTAG(TAG_Nil), heff_get_n(v_out_246, 3, 4)});
  V v_t_2428 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2426, v_backs_244}), v_t_2427));
  V v_c_2429 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2424; V a_2 = v_t_2428; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(a_0, a_1, a_2)); heff_drop(v_t_2424); heff_drop(v_t_2428); r_; });
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3, 1, 3, (V[]){v_done_245, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(v_t_2422, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2415, v_done_245, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str1, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s495635622x733177935(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1, 1, 4, (V[]){v_path_240, v_hd_242, v_text_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2(V self, V *args) {
  V v_ok_2429 = args[0];
  return v_ok_2429;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4(V self, V *args) {
  V v_ok_2440 = args[0];
  return v_ok_2440;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2448) == NTAG(TAG_True))) {
    heff_drop(v_x_2448);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2448);
    V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str1), v_path_240), ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str2));
    V v_t_2450 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2449, NTAG(TAG_MkUnit)});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_path_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2439 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2438; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2438); r_; });
  V v_a_2441 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2439, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4_clo)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s495635622x733177935(v_t_2447, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5, 1, 3, (V[]){v_k_243, v_path_240, v_hd_242})));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(v_st_2414, heff_dup(v_path_240)));
  V v_t_2425;
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    V v_d_2419 = v_field_2416;
    V v_a_2420 = v_field_2417;
    V v_xs_2421 = v_field_2418;
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
    v_t_2425 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2419, v_a_2420, v_t_2424});
  }
  V v_s_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2425); r_; });
  V v_path_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2426; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
  V v_a_2430 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2_clo)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(v_t_2436, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3, 1, 4, (V[]){v_path_240, v_text_241, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str1, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str2, 32, "--date=format-local:%Y%m%d%H%M%S");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str3, 15, "--format=%cd %H");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str4, 3, "log");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str5, 2, "-1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str6, 2, "TZ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str7, 4, "UTC0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str8, 3, "git");
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(V v_dir_240, V v_rev_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_rev_241, ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str1)), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str3), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str5), v_t_245})});
  V v_t_247 = ({ V a_0 = v_t_242; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_242); r_; });
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str6), ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str7)}), NTAG(TAG_Nil)});
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_str8), v_t_246, v_t_247, v_t_248, NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2411 = heff_tag_n(TAG_Run, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam1, 2, 1, (V[]){v_a_2411});
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_take_field(v_x_2420, 0);
  V v_x_2432;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Exited: {
    V v_n_2422 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Exited = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    if (heff_intEq_c(v_n_2422, MK_INT(0LL))) {
      V v_x1_2424 = ({ V b_0 = heff_get_n(v_x_2420, 1, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24t_2421_24Exited, 1);
        v_x_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_time_2425 = heff_field(v_x1_2424, 0);
        V v_x12_2426 = heff_field(v_x1_2424, 1);
        heff_take_n(v_x1_2424, 3ULL, 2);
        switch (heff_tag_of(v_x12_2426)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_2421_24Exited, 1);
          heff_drop(v_time_2425);
          v_x_2432 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_hash_2427 = heff_field(v_x12_2426, 0);
          V v_x122_2428 = heff_field(v_x12_2426, 1);
          heff_take_n(v_x12_2426, 3ULL, 2);
          switch (heff_tag_of(v_x122_2428)) {
          case TAG_Nil: {
            v_x_2432 = heff_tag_at_n(v_ru_24t_2421_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_time_2425, v_hash_2427})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x122_2428, 0ULL, 2);
            heff_drop_cell(v_ru_24t_2421_24Exited, 1);
            heff_drop(v_time_2425);
            heff_drop(v_hash_2427);
            v_x_2432 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x122_2428);
          }
          break;
        }
        default: heff_nomatch(v_x12_2426);
        }
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
    } else {
      heff_drop_rec(v_x_2420, 3);
      heff_drop_cell(v_ru_24t_2421_24Exited, 1);
      v_x_2432 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2421, 0ULL, 1);
    heff_drop_rec(v_x_2420, 3);
    v_x_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_TimedOut: {
    heff_drop_rec(v_x_2420, 3);
    v_x_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_NotRun: {
    heff_drop_rec(v_x_2420, 3);
    v_x_2432 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040_lam2, 1, 1, (V[]){v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str0, 7, "commits");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str2, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str4, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str5, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str6, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str10, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str12, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str13, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str15, 3, "no ");
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam9, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940(V v_prog_240, V v_ps_241, V v_path_242, V v_rev_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str0)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_rev_243, v_path_242, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam1(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam3(V self, V *args) {
  V v_ok_2433 = args[0];
  return v_ok_2433;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam5(V self, V *args) {
  V v_t_2445 = args[0];
  return v_t_2445;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam7(V self, V *args) {
  V v_r_2456 = args[0];
  return v_r_2456;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam9(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  heff_drop(v_hd_2469);
  V f_ = v_k_2470;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam10(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  heff_drop(v_hd_2472);
  V f_ = v_k_2473;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam11(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam12(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam14(V self, V *args) {
  V v_ok_2482 = args[0];
  return v_ok_2482;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam16(V self, V *args) {
  V v_x_2493 = args[0];
  V v_x_2464 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_x_2479 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2493);
  V v_t_2494 = heff_take_field(v_x_2464, 0);
  V v_t_2498;
  switch (heff_tag_of(v_t_2494)) {
  case TAG_Exited: {
    V v_n_2495 = heff_field(v_t_2494, 0);
    heff_take_n(v_t_2494, 1ULL, 1);
    v_t_2498 = heff_bool(!heff_intEq_c_lent(v_n_2495, MK_INT(0LL), 2));
    heff_drop(v_n_2495);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2494, 0ULL, 1);
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2494);
  }
  V v_x_24114;
  if ((heff_dup(v_t_2498) == NTAG(TAG_True))) {
    heff_drop(v_x_2479);
    heff_drop(v_rev_243);
    heff_drop(v_t_2498);
    V v_t_2499 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
    V v_s_24100 = heff_get_n(v_x_2464, 2, 3);
    V v_t_24101 = (g_prelude_2eskipSpaces(v_s_24100, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24102 = (heff_unbox_word(heff_strLength_lent(v_s_24100, 0)) - ((int64_t)1ULL));
    V v_t_24103 = (g_prelude_2eskipSpaces(v_s_24100, heff_box_word(v_t_24102), MK_INT(-1LL)));
    V v_t_24104 = heff_strSlice(v_s_24100, v_t_24101, heff_intAdd(v_t_24103, MK_INT(1LL)));
    V v_t_24105 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str10), v_t_2499), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str11), v_t_24104));
    v_x_24114 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str12), v_t_24105)});
  } else {
    heff_drop_rec(v_x_2464, 3);
    heff_drop(v_t_2498);
    switch (heff_tag_of(v_x_2479)) {
    case TAG_Nothing: {
      V v_t_24106 = (g_heff_2ebuild_2ecommands_2erevSaid(v_rev_243));
      V v_t_24107 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
      V v_t_24108 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str13), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str14), v_t_24107));
      V v_t_24109 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str15), heff_strAppend(v_t_24106, v_t_24108));
      v_x_24114 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24109});
      break;
    }
    case TAG_Just: {
      V v_it1_24110 = heff_field(v_x_2479, 0);
      V v_ru_24x_2479_24Just = heff_take_reuse_n(v_x_2479, 1ULL, 1);
      heff_drop(v_rev_243);
      switch (heff_tag_of(v_it1_24110)) {
      case TAG_MkPair: {
        V v_time_24111 = heff_field(v_it1_24110, 0);
        V v_hash_24112 = heff_field(v_it1_24110, 1);
        heff_take_n(v_it1_24110, 3ULL, 2);
        V v_t_24113 = ({ V a_0 = v_path_242; V a_1 = v_time_24111; V a_2 = v_hash_24112; V r_ = (g_heff_2ebuild_2eproject_2epseudoVersion(a_0, a_1, a_2)); heff_drop(v_hash_24112); r_; });
        v_x_24114 = heff_tag_at_n(v_ru_24x_2479_24Just, TAG_Right, 1, (V[]){v_t_24113});
        break;
      }
      default: heff_nomatch(v_it1_24110);
      }
      break;
    }
    default: heff_nomatch(v_x_2479);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam15(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2447 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2464 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_x_2479 = heff_env(self)[5];
  V v_rev_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2490);
  V v_t_2491 = heff_tag_n(TAG_End, 2, (V[]){v_x_2447, NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2491}));
  return (g_co_2eop_24s495635622x733177935(v_t_2492, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam16, 1, 5, (V[]){v_x_2464, v_path_242, v_x_2479, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam13(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_2447 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2464 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_rev_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2480 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2481 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2480; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2480); r_; });
  V v_a_2483 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2481, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam14_clo)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  return (g_co_2eop_24s495635622x733177935(v_t_2489, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam15, 1, 8, (V[]){v_x_2447, v_prog_240, v_hd_245, v_x_2464, v_path_242, v_x_2479, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2447 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2465 = heff_dup(heff_rfield(v_x_2464, 0));
  V v_c_2478;
  switch (heff_tag_of(v_t_2465)) {
  case TAG_Exited: {
    V v_n_2466 = heff_field(v_t_2465, 0);
    heff_take_n(v_t_2465, 1ULL, 1);
    if (heff_intEq_c(v_n_2466, MK_INT(0LL))) {
      V v_t_2468 = (g_heff_2ebuild_2ecommands_2erevNamed(heff_dup(v_rev_243)));
      v_c_2478 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s2000192745x230447040(heff_dup(v_x_244), v_t_2468));
    } else {
      v_c_2478 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam9_clo);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2465, 0ULL, 1);
    v_c_2478 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam10_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2478 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam11_clo);
    break;
  }
  case TAG_NotRun: {
    v_c_2478 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam12_clo);
    break;
  }
  default: heff_nomatch(v_t_2465);
  }
  V f_ = v_c_2478;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam13, 1, 8, (V[]){v_x_244, v_hd_245, v_x_2447, v_prog_240, v_x_2464, v_path_242, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2448 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str3), v_t_2448), v_t_2449});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str5), v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str7), v_t_2451})});
  V v_t_2453 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2454;
  if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
    heff_drop(v_t_2453);
    v_t_2454 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str8);
  } else {
    heff_drop(v_t_2453);
    v_t_2454 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2455 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str9), v_t_2452, v_t_2454, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2457 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam7_clo)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam8, 1, 7, (V[]){v_rev_243, v_x_244, v_hd_245, v_x_2447, v_prog_240, v_path_242, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2441);
  V v_t_2442 = (g_heff_2ebuild_2ecommands_2erevSaid(heff_dup(v_rev_243)));
  V v_t_2443 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str1), heff_dup(v_path_242)));
  V v_name_2444 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_str2), v_t_2443);
  V v_t_2446 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_2444, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam5_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2446, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam6, 1, 6, (V[]){v_path_242, v_x_244, v_hd_245, v_rev_243, v_prog_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2417);
  V v_st_2418 = heff_get_n(v_ps_241, 5, 6);
  HeffT3 v_t_2419 = (g_std_2epath_2eparse_24cpr(v_st_2418, heff_dup(v_x_244)));
  V v_t_2429;
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    V v_d_2423 = v_field_2420;
    V v_a_2424 = v_field_2421;
    V v_xs_2425 = v_field_2422;
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    V v_xs_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2426; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2426); r_; });
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
    v_t_2429 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2423, v_a_2424, v_t_2428});
  }
  V v_s_2430 = ({ V a_0 = v_st_2418; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2429); r_; });
  V v_path_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2430; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2432 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2431; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2431); r_; });
  V v_a_2434 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam3_clo)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s495635622x733177935(v_t_2440, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam4, 1, 6, (V[]){v_rev_243, v_path_242, v_prog_240, v_hd_245, v_x_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_rev_243 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam1_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1118474732x1011780940_lam2, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_rev_243, v_path_242, v_prog_240, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_245); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
    V v_a_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2, 2, 4, (V[]){v_a_2410, v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6(V self, V *args) {
  V v_n_2438 = args[0];
  V v_st_2436 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = (g_std_2epath_2eparse(v_st_2436, v_p_245));
  V v_t_2440 = (g_std_2epath_2eparse(v_st_2436, v_n_2438));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2439, v_t_2440));
  return ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2441); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_ns_2425 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2436;
  if (heff_strEq_c(v_x_2434, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str1))) {
    v_st_2436 = NTAG(TAG_Windows);
  } else {
    v_st_2436 = NTAG(TAG_Posix);
  }
  V v_t_2437 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str2); V a_3 = v_ns_2425; V r_ = (g_list_2ekeepIf_24s654566231x1096033(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2442 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6, 1, 2, (V[]){v_st_2436, v_p_245}), v_t_2437));
  V v_t_2443 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_2442, v_acc_241));
  V f_ = v_t_2443;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_245, 0)) - ((int64_t)3ULL));
    V v_t_2421 = heff_strSlice(heff_dup(v_p_245), heff_box_word(v_t_2420), heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str0))) {
      V v_t_2423 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2423;
      heff_room[0] = v_hd_2411;
      heff_room[1] = v_k_2412;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2424 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_rest_246, v_acc_241));
      V f_ = v_t_2424;
      heff_room[0] = v_hd_2411;
      heff_room[1] = v_k_2412;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2425 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Just = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2419_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4_clo)})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s495635622x733177935(v_t_2433, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5, 1, 6, (V[]){v_ns_2425, v_rest_246, v_p_245, v_acc_241, v_hd_2411, v_k_2412})));
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str2, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_old_242; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_z_246, v_next_244, v_z_247})));
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_path_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_old_242; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_to_2429 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_to_243); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2430 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2428; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2428); r_; });
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2429; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2429); r_; });
    V v_a_2433 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2430, v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3_clo)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s495635622x733177935(v_t_2439, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4, 1, 4, (V[]){v_fresh_241, v_z_246, v_to_243, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2427);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str0), v_to_243));
  V v_t_2420 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str1)), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2, 1, 3, (V[]){v_next_244, v_z_246, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5(V self, V *args) {
  V v_ok_2443 = args[0];
  return v_ok_2443;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7(V self, V *args) {
  V v_x_2461 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str2), v_to_243));
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str4), v_t_2452));
  V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str5)), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7, 1, 2, (V[]){v_z_246, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_path_2441 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_fresh_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2441; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2441); r_; });
  V v_a_2444 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5_clo)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s495635622x733177935(v_t_2450, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_z_246, v_z_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_n_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_244, heff_dup(v_n_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0_clo)})}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1, 2, 7, (V[]){v_t_248, heff_dup(v_st_241), v_home_243, v_n_246, v_t_242, v_prog_240, v_next_245});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5(V self, V *args) {
  V v_ok_2435 = args[0];
  return v_ok_2435;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7(V self, V *args) {
  V v_ok_2452 = args[0];
  return v_ok_2452;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9(V self, V *args) {
  V v_ok_2469 = args[0];
  return v_ok_2469;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11(V self, V *args) {
  V v_ok_2486 = args[0];
  return v_ok_2486;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14(V self, V *args) {
  V v_x_24103 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_24101 = heff_env(self)[1];
  V v_k_24102 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24103);
  V f_ = v_next_245;
  heff_room[0] = v_hd_24101;
  heff_room[1] = v_k_24102;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13(V self, V *args) {
  V v_hd_24101 = args[0];
  V v_k_24102 = args[1];
  V v_t_24100 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_24100, heff_dup(v_hd_24101), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14, 1, 3, (V[]){v_next_245, v_hd_24101, v_k_24102})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12(V self, V *args) {
  V v_x_2494 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_x_2416 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_next_245 = heff_env(self)[8];
  V v_hd_249 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2495 = (g_std_2epath_2eparse(v_st_241, v_home_243));
  V v_t_2496 = (g_std_2epath_2eparse(v_st_241, v_n_246));
  V v_t_2497 = (g_std_2epath_2ejoin(v_t_2495, v_t_2496));
  V v_t_2498 = ({ V a_0 = v_st_241; V a_1 = v_t_2497; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2497); r_; });
  V v_t_2499 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_24100 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2499}));
  return ({ V a_0 = v_t_242; V a_1 = v_x_2416; V a_2 = v_x_2421; V a_3 = v_t_2498; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13, 2, 2, (V[]){v_t_24100, v_next_245}); V a_5 = v_x_2494; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2494); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_n_246 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_x_2421 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2477);
  V v_path_2478 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2479 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2480 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
  V v_t_2481 = (g_std_2epath_2ejoin(v_t_2479, v_t_2480));
  V v_s_2482 = ({ V a_0 = v_st_241; V a_1 = v_t_2481; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2481); r_; });
  V v_to_2483 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2482; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2484 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2478; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2478); r_; });
  V v_t_2485 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2483; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2483); r_; });
  V v_a_2487 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2484, v_t_2485, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11_clo)});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
  return (g_co_2eop_24s495635622x733177935(v_t_2493, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2411, v_prog_240, v_t_242, v_x_2416, v_x_2421, v_next_245, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15(V self, V *args) {
  V v_ok_24106 = args[0];
  return v_ok_24106;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17(V self, V *args) {
  V v_x_24129 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24129);
  V v_t_24130 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
  V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
  V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
  V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
  V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24136}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16(V self, V *args) {
  V v_x_24114 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24114);
  V v_t_24115 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_t_242, 0, 6)));
  V v_t_24116 = (g_std_2epath_2eparse(v_st_241, v_n_246));
  V v_t_24117 = (g_std_2epath_2ejoin(v_t_24115, v_t_24116));
  V v_t_24118 = ({ V a_0 = v_st_241; V a_1 = v_t_24117; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_24117); r_; });
  V v_t_24119 = heff_strAppend(v_t_24118, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str4), v_x_2416));
  V v_why_24120 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str5), v_t_24119);
  V v_t_24121 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str6), v_why_24120), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str7));
  V v_t_24122 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24121, NTAG(TAG_MkUnit)});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
  V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24128}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_t_242 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
    heff_drop(v_x_2460);
    V v_t_2461 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
    V v_t_2462 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
    V v_t_2463 = (g_std_2epath_2ejoin(v_t_2461, v_t_2462));
    V v_s_2464 = ({ V a_0 = v_st_241; V a_1 = v_t_2463; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2463); r_; });
    V v_path_2465 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2464; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_to_2466 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2421); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2467 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2465; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2465); r_; });
    V v_t_2468 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2466; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2466); r_; });
    V v_a_2470 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2467, v_t_2468, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9_clo)});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
    return (g_co_2eop_24s495635622x733177935(v_t_2476, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10, 1, 11, (V[]){v_x_2416, v_st_241, v_home_243, v_n_246, v_hd_249, v_x_2411, v_prog_240, v_t_242, v_x_2421, v_next_245, v_k_2410})));
  } else {
    heff_drop(v_x_2460);
    heff_drop(v_home_243);
    heff_drop(v_x_2421);
    heff_drop(v_x_2411);
    heff_drop(v_prog_240);
    heff_drop(v_next_245);
    V v_path_24104 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_24105 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24104; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24104); r_; });
    V v_a_24107 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_24105, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15_clo)});
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
    return (g_co_2eop_24s495635622x733177935(v_t_24113, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16, 1, 6, (V[]){v_st_241, v_t_242, v_n_246, v_x_2416, v_hd_249, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_home_243 = heff_env(self)[5];
  V v_x_2421 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2445 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
  V v_t_2446 = (g_std_2epath_2ejoin(v_t_2444, v_t_2445));
  V v_s_2447 = ({ V a_0 = v_st_241; V a_1 = v_t_2446; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2446); r_; });
  V v_path_2448 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2447; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_to_2449 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2450 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2448; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2448); r_; });
  V v_t_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2449; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2449); r_; });
  V v_a_2453 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2450, v_t_2451, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7_clo)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s495635622x733177935(v_t_2459, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2421, v_hd_249, v_x_2416, v_x_2411, v_prog_240, v_t_242, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_n_246 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_home_243 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2432);
  V v_path_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2421); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2433; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2433); r_; });
  V v_a_2436 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5_clo)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s495635622x733177935(v_t_2442, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6, 1, 11, (V[]){v_st_241, v_t_242, v_n_246, v_x_2416, v_hd_249, v_home_243, v_x_2421, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str0), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str1)));
  V v_t_2414 = (g_std_2epath_2eparse(v_st_241, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2412, v_t_2414));
  V v_x_2416 = ({ V a_0 = v_st_241; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str2), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str3)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_241, v_t_2418));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
  V v_x_2421 = ({ V a_0 = v_st_241; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_path_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
  V v_a_2425 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3_clo)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s495635622x733177935(v_t_2431, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4, 1, 11, (V[]){v_x_2421, v_hd_249, v_st_241, v_t_242, v_n_246, v_x_2416, v_home_243, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_n_246 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2, 1, 8, (V[]){v_st_241, v_home_243, v_n_246, v_hd_249, v_t_242, v_prog_240, v_next_245, v_k_2410})));
}