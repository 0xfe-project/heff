// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_c 317
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hash 9690581
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_version 583465758
#define LBL_zig 330130
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_clo;
V g_heff_2ebuild_2ecommands_2egoldenPart(V);
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2ecErased(V, V);
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecErased_clo;
V g_list_2eall_24s442836260x1032582242(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a);
extern Clo g_list_2eall_24s442836260x1032582242_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2emap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2416;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2413 = v_field_2412;
      switch (heff_tag_of(v_x31_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x31_2413, 0);
        V v_j_2415 = heff_field(v_x31_2413, 1);
        heff_take_n(v_x31_2413, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2415)) {
          v_t_2416 = v_x_2414;
        } else {
          heff_drop(v_x_2414);
          v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2413);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, v_t_246, v_t_2416));
}
Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenPart_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenPart(V v_n_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_n_240, 0)))) {
    if (!(heff_unbox_word(heff_strByteAt_lent(v_n_240, MK_INT(0LL), 2)) == ((int64_t)46ULL))) {
      int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_n_240, 0)) - ((int64_t)1ULL));
      V v_t_242 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_241)));
      return ({ V a_0 = v_n_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(65LL); V a_4 = MK_INT(90LL); V a_5 = MK_INT(97LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(45LL); V a_8 = MK_INT(95LL); V a_9 = MK_INT(46LL); V a_10 = v_t_242; V r_ = (g_list_2eall_24s442836260x1032582242(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_242); r_; });
    } else {
      return NTAG(TAG_False);
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenPart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_245 = v_field_244;
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_path_245), heff_box_word(v_t_246), heff_strLength_lent(v_path_245, 0));
      V v_t_249;
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str0))) {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
        v_t_249 = heff_strSlice(v_path_245, MK_INT(0LL), heff_box_word(v_t_248));
      } else {
        v_t_249 = v_path_245;
      }
      V v_path_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2411 = ({ V a_0 = v_path_2410; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2410); r_; });
      V v_c_2415 = heff_tr(heff_call(v_c_2411, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0_clo)}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1, 2, 2, (V[]){v_c_2415, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_m_241);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_y_2420})});
    V f_ = v_k_2417;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2, 1, 2, (V[]){v_k_2417, v_m_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str8, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str9, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str15, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str3); V a_6 = v_t_2416; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(v_sources_241, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0, 1, 9, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2413, v_z_249, v_file_242, v_failed_245, v_bi_240, v_done_246})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str15), NTAG(TAG_MkUnit)});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
      return heff_tail(heff_dup(heff_rfield(v_z_248, 1)), 2, (V[]){v_t_2482, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6, 1, 2, (V[]){v_z_248, v_z_249})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V v_exports_2435 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str8); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2436 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2435)));
    V v_t_2437 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 9);
    V v_t_2438 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2437));
    V v_t_2439 = (g_heff_2ecompile_2elower_2ecErased(v_roots_2436, v_t_2438));
    V v_t_2440 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2435, v_t_2439));
    return ({ V a_0 = v_outPath_244; V b_1 = NTAG(TAG_True); V a_2 = v_t_2440; V a_3 = v_z_248; V a_4 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V v_exports_2442 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str9); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2443 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2442)));
    V v_t_2444 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 9);
    V v_t_2445 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2444));
    V v_t_2446 = (g_heff_2ecompile_2elower_2ecErased(v_roots_2443, v_t_2445));
    V v_t_2447 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2442, v_t_2446));
    return ({ V a_0 = v_outPath_244; V b_1 = NTAG(TAG_False); V a_2 = v_t_2447; V a_3 = v_z_248; V a_4 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5(V self, V *args) {
  V v_x_2469 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_why_2458 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_strAppend(v_file_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str13), v_why_2458));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str14), v_t_2470);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_x_2420 = heff_env(self)[6];
  V v_file_242 = heff_env(self)[7];
  V v_failed_245 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2420);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_bi_240);
    heff_drop(v_done_246);
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2424 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2423), heff_strLength_lent(v_outPath_244, 0));
    V v_t_2426;
    if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str6))) {
      int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2426 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2425), 6);
    } else {
      v_t_2426 = heff_dup(v_outPath_244);
    }
    V v_path_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str7)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2428 = ({ V a_0 = v_path_2427; V a_1 = v_x_2422; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2427); r_; });
    V v_c_2432 = heff_tr(heff_call(v_c_2428, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3_clo)}));
    V f_ = v_c_2432;
    heff_room[0] = heff_dup(v_z_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4, 1, 5, (V[]){v_c_2413, v_x_2421, v_outPath_244, v_z_248, v_z_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2449 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
    V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2449); r_; });
    V v_leaves_2451 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2450));
    V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 9);
    V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
    V v_t_2454 = (g_list_2emap_24s164225955x66209884(v_t_2452, v_t_2453, v_leaves_2451));
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2454));
    {
      V v_field_2457 = v_t_2455.f[1];
      int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
      if ((v_tag_2456 == ((int64_t)0ULL))) {
        heff_drop(v_x_2422);
        heff_drop_tag(v_name_243, 1);
        heff_drop(v_outPath_244);
        heff_drop_rec(v_c_2413, 14);
        heff_drop(v_x_2421);
        heff_drop(v_x_2420);
        heff_drop(v_bi_240);
        heff_drop(v_done_246);
        V v_why_2458 = v_field_2457;
        V v_t_2459 = heff_strAppend(heff_dup(v_file_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str10), heff_dup(v_why_2458)));
        V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str11), v_t_2459), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str12));
        V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2460, NTAG(TAG_MkUnit)});
        V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
        V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
        V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
        V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})}));
        V f_ = heff_dup(heff_rfield(v_z_248, 1));
        heff_room[0] = v_t_2468;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5, 1, 5, (V[]){v_file_242, v_why_2458, v_failed_245, v_z_248, v_z_249});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_ms_2471 = v_field_2457;
        V v_glues_2472 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2471));
        V v_t_2473 = (g_list_2emap_24s1435185561x202019164(v_glues_2472));
        V v_t_2474 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2473));
        return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2421, v_x_2422}); V a_5 = v_failed_245; V a_6 = v_done_246; V a_7 = v_c_2413; V a_8 = v_t_2474; V a_9 = v_z_248; V a_10 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop_tag(v_name_243, 1); r_; });
      }
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2, 1, 11, (V[]){v_name_243, v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249, v_x_2420, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1, 1, 10, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2413, v_z_249, v_x_2420, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6(V self, V *args) {
  V v_x_2483 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2490}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_str0, 5, ".hash");
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_247 = heff_take_field(v_x_245, 0);
    V v_version_248 = heff_get_n(v_x_245, 1, 3);
    V v_c_249 = (g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam1, 2, 5, (V[]){v_c_249, v_ps_240, v_path_247, v_version_248, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_path_247 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  V v_version_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    heff_drop(v_version_248);
    V v_t_2423 = ({ V a_0 = v_path_247; V a_1 = heff_take_field(v_root_241, 2); V r_ = (g_list_2ekeepIf_24s1943838498x1969994910(a_0, a_1)); heff_drop(v_path_247); r_; });
    V v_x_2429;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_241, 4);
      v_x_2429 = v_x_2412;
      break;
    }
    case TAG_Cons: {
      V v_r_2424 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 2);
      V v_t_2426 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2424, heff_get_n(v_root_241, 3, 4)));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nil: {
        v_x_2429 = v_x_2412;
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2426, 0ULL, 2);
        v_x_2429 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V f_ = v_k_2411;
    args[0] = v_x_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_t_2431 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_247, heff_take_field(v_root_241, 2)));
    V v_x_2445;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_241, 4);
      V v_t_2432 = (g_prelude_2eskipSpaces(v_y_2430, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_y_2430, 0)) - ((int64_t)1ULL));
      V v_t_2434 = (g_prelude_2eskipSpaces(v_y_2430, heff_box_word(v_t_2433), MK_INT(-1LL)));
      V v_t_2435 = heff_strSlice(v_y_2430, v_t_2432, heff_intAdd(v_t_2434, MK_INT(1LL)));
      v_x_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2435}), v_x_2412});
      break;
    }
    case TAG_Cons: {
      V v_r_2436 = heff_field(v_t_2431, 0);
      V v_ru_24t_2431_24Cons = heff_take_reuse_n(v_t_2431, 1ULL, 2);
      V v_t_2438 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2436, heff_get_n(v_root_241, 3, 4)));
      switch (heff_tag_of(v_t_2438)) {
      case TAG_Nil: {
        V v_t_2439 = (g_prelude_2eskipSpaces(v_y_2430, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_y_2430, 0)) - ((int64_t)1ULL));
        V v_t_2441 = (g_prelude_2eskipSpaces(v_y_2430, heff_box_word(v_t_2440), MK_INT(-1LL)));
        V v_t_2442 = heff_strSlice(v_y_2430, v_t_2439, heff_intAdd(v_t_2441, MK_INT(1LL)));
        v_x_2445 = heff_tag_at_n(v_ru_24t_2431_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2442}), v_x_2412});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2438, 0ULL, 2);
        heff_drop(v_path_247);
        heff_drop(v_version_248);
        heff_drop(v_y_2430);
        heff_drop_cell(v_ru_24t_2431_24Cons, 2);
        v_x_2445 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_t_2438);
      }
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V f_ = v_k_2411;
    args[0] = v_x_2445;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_path_247 = heff_env(self)[1];
  V v_version_248 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_247), heff_dup(v_version_248)));
  V v_s_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_str0));
  V v_path_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2414; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2416 = ({ V a_0 = v_path_2415; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2415); r_; });
  V v_c_2420 = heff_tr(heff_call(v_c_2416, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam3_clo)}));
  V f_ = v_c_2420;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam4, 1, 5, (V[]){v_path_247, v_root_241, v_x_2412, v_k_2411, v_version_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_247 = heff_env(self)[2];
  V v_version_248 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435_lam2, 1, 6, (V[]){v_ps_240, v_path_247, v_version_248, v_hd_2410, v_root_241, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str4, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str8, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str10, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str15, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str17, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str21, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str22, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str23, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str24, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str25, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str26, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str27, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str31, 36, " packages, none fetched: no heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str32, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str33, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str34, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam12, 3, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(V v_prog_240, V v_z_241, V v_z_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam0, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240})});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam7(V self, V *args) {
  V v_x_2471 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2471);
  V v_t_2472 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam8(V self, V *args) {
  V v_by_2482 = args[0];
  V v_path_2483 = args[1];
  V v_v_2484 = args[2];
  V v_prog_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_root_2458 = heff_env(self)[2];
  V v_sums_2479 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370(v_prog_240, v_x_246, v_root_2458, v_sums_2479, v_by_2482, v_path_2483, v_v_2484));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam11(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k_2498 = args[1];
  heff_drop(v_hd_2497);
  V f_ = v_k_2498;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam12(V self, V *args) {
  V v_x_24106 = args[0];
  V v_hd_24107 = args[1];
  V v_k_24108 = args[2];
  heff_drop(v_hd_24107);
  V f_ = v_k_24108;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24106});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam14(V self, V *args) {
  V v_x_24112 = args[0];
  V v_k_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24115;
  switch (heff_tag_of(v_x_24112)) {
  case TAG_Left: {
    heff_take_n(v_x_24112, 0ULL, 1);
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24112, 0ULL, 1);
    v_t_24115 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24112);
  }
  V f_ = v_k_24111;
  args[0] = v_t_24115;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam13(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k_24111 = args[1];
  V v_c_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24109;
  args[0] = v_hd_24110;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam14, 1, 1, (V[]){v_k_24111});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam17(V self, V *args) {
  V v_x_24137 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24137);
  V v_t_24138 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24138})});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24144}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam20(V self, V *args) {
  V v_x_24159 = args[0];
  V v_seen_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24159; V a_1 = v_seen_24157; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_24157); r_; });
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam19(V self, V *args) {
  V v_x_24147 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_x_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_24147)) {
    heff_drop(v_x_2486);
    heff_drop(v_x_2491);
    V v_t_24148 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
    V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24153})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24154}), v_z_241, v_z_242));
  } else {
    V v_seen_24157;
    switch (heff_tag_of(v_x_2486)) {
    case TAG_MkPair: {
      V v_x_24155 = heff_field(v_x_2486, 0);
      heff_take_n(v_x_2486, 1ULL, 2);
      v_seen_24157 = v_x_24155;
      break;
    }
    default: heff_nomatch(v_x_2486);
    }
    V v_t_24158 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_24157)));
    V v_t_24160 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam20, 1, 1, (V[]){v_seen_24157}); V a_3 = v_t_24158; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24158); r_; });
    V v_t_24161 = (g_list_2esortBy_24s492793466x2081132734(v_x_2491));
    V v_x2_24162 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str25), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str26), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str27), v_t_24161));
    V v_t_24165;
    switch (heff_tag_of(v_x2_24162)) {
    case TAG_Nil: {
      v_t_24165 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_24163 = heff_field(v_x2_24162, 0);
      V v_xs_24164 = heff_field(v_x2_24162, 1);
      heff_take_n(v_x2_24162, 3ULL, 2);
      v_t_24165 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str29); V a_1 = v_x_24163; V a_2 = v_xs_24164; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24164); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24162);
    }
    V v_t_24166;
    if (heff_strEq_c(v_t_24165, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str30))) {
      v_t_24166 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str31);
    } else {
      v_t_24166 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str32);
    }
    V v_t_24167 = heff_strAppend(heff_intShow(v_t_24160), v_t_24166);
    V v_str_24168 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str33), v_t_24167);
    V v_t_24169 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24168, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str34)), NTAG(TAG_MkUnit)});
    V v_t_24170 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
    V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24170})});
    V v_t_24172 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24171})});
    V v_t_24173 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24172})});
    V v_t_24174 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24173})});
    V v_t_24175 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24174})});
    V v_t_24176 = heff_tr(heff_call(heff_take_field(v_z_241, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24175})}));
    V f_ = heff_get_n(v_z_241, 1, 3);
    heff_room[0] = v_t_24176;
    heff_room[1] = v_z_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam18(V self, V *args) {
  V v_x_24146 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_x_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str24), heff_get_n(v_x_24146, 1, 5), MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam19, 1, 4, (V[]){v_z_241, v_z_242, v_x_2486, v_x_2491})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam16(V self, V *args) {
  V v_x_24121 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_24117 = heff_env(self)[2];
  V v_x_2486 = heff_env(self)[3];
  V v_x_2491 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_intLt_c(MK_INT(0LL), v_x_24121)) {
    heff_drop(v_x_24117);
    heff_drop(v_x_2486);
    heff_drop(v_x_2491);
    V v_t_24122 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24128}), v_z_241, v_z_242));
  } else {
    if (!(heff_dup(v_x_24117) == NTAG(TAG_True))) {
      heff_drop(v_x_24117);
      heff_drop(v_x_2486);
      heff_drop(v_x_2491);
      V v_t_24129 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str22), NTAG(TAG_MkUnit)});
      V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
      V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
      V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
      V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})}));
      V f_ = heff_dup(heff_rfield(v_z_241, 1));
      heff_room[0] = v_t_24136;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam17, 1, 2, (V[]){v_z_241, v_z_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24117);
      V v_c_24145 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str23)));
      V f_ = v_c_24145;
      heff_room[0] = heff_dup(v_z_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam18, 1, 4, (V[]){v_z_241, v_z_242, v_x_2486, v_x_2491});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam15(V self, V *args) {
  V v_x_24117 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_x_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24120;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_y_24119 = heff_dup(heff_field(v_x_2486, 1));
    v_t_24120 = v_y_24119;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str21), v_t_24120, MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam16, 1, 5, (V[]){v_z_241, v_z_242, v_x_24117, v_x_2486, v_x_2491})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam10(V self, V *args) {
  V v_x_2491 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_x_2486 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2492 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2491)));
  V v_x2_2493 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str9), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str10), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str11), v_t_2492));
  V v_t_2496;
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_Nil: {
    v_t_2496 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_xs_2495 = heff_field(v_x2_2493, 1);
    heff_take_n(v_x2_2493, 3ULL, 2);
    v_t_2496 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str13); V a_1 = v_x_2494; V a_2 = v_xs_2495; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2495); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2493);
  }
  V v_c_24116;
  if (heff_strEq_c(v_t_2496, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str14))) {
    v_c_24116 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam11_clo);
  } else {
    V v_path_2499 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str15); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_24100 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2491)));
    V v_x2_24101 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str16), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str17), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str18), v_t_24100));
    V v_text_24104;
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_Nil: {
      v_text_24104 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_xs_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      v_text_24104 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str20); V a_1 = v_x_24102; V a_2 = v_xs_24103; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24103); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24101);
    }
    V v_c_24105 = ({ V a_0 = v_path_2499; V a_1 = v_text_24104; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2499); r_; });
    V v_c_24109 = heff_tr(heff_call(v_c_24105, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam12_clo)}));
    v_c_24116 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam13, 2, 1, (V[]){v_c_24109});
  }
  V f_ = v_c_24116;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam15, 1, 4, (V[]){v_x_2486, v_z_241, v_z_242, v_x_2491});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam9(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_root_2458 = heff_env(self)[1];
  V v_z_241 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2489;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_dup(heff_field(v_x_2486, 0));
    v_t_2489 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_c_2490 = (g_heff_2ebuild_2ecommands_2esumsOf_24s875744077x1087349435(v_x_246, v_root_2458, v_t_2489));
  V f_ = v_c_2490;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam10, 1, 3, (V[]){v_z_241, v_x_2486, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_root_2458 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Left: {
    V v_why_2461 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Left = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    heff_drop_rec(v_root_2458, 4);
    heff_drop(v_prog_240);
    heff_drop(v_x_246);
    V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str5), v_why_2461), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str6));
    V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2462, NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_at_n(v_ru_24x_2460_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})}));
    V f_ = heff_dup(heff_rfield(v_z_241, 1));
    heff_room[0] = v_t_2470;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam7, 1, 2, (V[]){v_z_241, v_z_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_sums_2479 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    V v_t_2480;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2458, 0)), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str7))) {
      v_t_2480 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str8);
    } else {
      v_t_2480 = heff_dup(heff_rfield(v_root_2458, 0));
    }
    V v_t_2481 = (g_list_2emap_24s675147852x248982264(v_t_2480, heff_dup(heff_rfield(v_root_2458, 2))));
    V v_c_2485 = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam8, 3, 4, (V[]){v_prog_240, heff_dup(v_x_246), heff_dup(v_root_2458), v_sums_2479}), heff_rfield(v_root_2458, 0), v_t_2481, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2485;
    heff_room[0] = heff_dup(v_z_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam9, 1, 4, (V[]){v_x_246, v_root_2458, v_z_241, v_z_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str2);
    break;
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  HeffT2 v_t_2417 = ({ V a_0 = v_t_2416; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_t_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_x_246);
      heff_drop(v_prog_240);
      V v_p_2420 = v_field_2419;
      heff_drop(v_p_2420);
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str3), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
      V f_ = heff_dup(heff_rfield(v_z_241, 1));
      heff_room[0] = v_t_2428;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam4, 1, 2, (V[]){v_z_241, v_z_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_x_2437 = v_field_2419;
      HeffT2 v_t_2438 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2437));
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          heff_drop(v_x_246);
          heff_drop(v_prog_240);
          V v_x_2441 = v_field_2440;
          heff_drop(v_x_2441);
          V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str4), NTAG(TAG_MkUnit)});
          V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
          V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
          V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
          V f_ = heff_dup(heff_rfield(v_z_241, 1));
          heff_room[0] = v_t_2449;
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam5, 1, 2, (V[]){v_z_241, v_z_242});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          V v_root_2458 = v_field_2440;
          V v_c_2459 = (g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(heff_dup(v_x_246)));
          V f_ = v_c_2459;
          heff_room[0] = heff_dup(v_z_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam6, 1, 5, (V[]){v_z_241, v_z_242, v_root_2458, v_prog_240, v_x_246});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str1); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_247); r_; });
  V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam2_clo)}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam3, 1, 4, (V[]){v_z_241, v_z_242, v_x_246, v_prog_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_244, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_str0)));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1093108123x1546508578_lam1, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_home_243);
    heff_drop(v_sh_244);
    return v_next_245;
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x6_246, 0);
    V v_rest_248 = heff_field(v_x6_246, 1);
    V v_t_249 = (g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_home_243), heff_dup(v_sh_244), v_next_245, v_rest_248));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532(v_prog_240, v_st_241, v_t_242, v_home_243, v_sh_244, v_t_249, heff_dup(v_n_247));
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(a[0], a1, a[2], a[3], a[4], a[5], a6); heff_drop(a1); heff_drop(a6); return r;
}