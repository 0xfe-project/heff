// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_Copy 17796
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Holds 53574
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkGroup 19195
#define TAG_Move 53768
#define TAG_Open 48267
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_absolute 325777132
#define LBL_at 9882
#define LBL_copies 592412158
#define LBL_drive 297211300
#define LBL_emits 297985818
#define LBL_env 310119
#define LBL_file 9638467
#define LBL_groups 709681407
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_jss 315076
#define LBL_launch 837298910
#define LBL_loaded 849622832
#define LBL_mods 9852536
#define LBL_modules 1459291593
#define LBL_olds 9909235
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_program 2069953735
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_segments 1801007612
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s851371283x356629733(V, V, V, V, V);
V g_co_2eop_24s851371283x356629733_entry(V self, V *a);
extern Clo g_co_2eop_24s851371283x356629733_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_clo;
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2egoldenPart(V);
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1505276232x1076898175(V, V);
V g_list_2efilter_24s1505276232x1076898175_entry(V self, V *a);
extern Clo g_list_2efilter_24s1505276232x1076898175_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
HeffT2 g_list_2efind_24s814399109x689165205_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s86307863x1047527532(V, V);
V g_list_2efoldl_24s86307863x1047527532_entry(V self, V *a);
extern Clo g_list_2efoldl_24s86307863x1047527532_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2emap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2418;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2412;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        heff_take_n(v_x31_2414, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2416)) {
          v_t_2418 = v_x_2415;
        } else {
          heff_drop(v_x_2415);
          v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2418 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, v_t_246, v_t_2418));
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenPart_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenPart(V v_n_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_n_240, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_n_240, MK_INT(0LL), 2)) == ((int64_t)46ULL))) {
      return NTAG(TAG_False);
    } else {
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_n_240, 0)) - ((int64_t)1ULL));
      V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_243)));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenPart_lam0, 1, 1, (V[]){heff_dup(v_n_240)}); V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenPart(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenPart_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2egoldenByte(heff_strByteAt(v_n_240, v_i_245)));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  return v_v_2420;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2446;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2428)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2428, 0);
        heff_take_n(v_x_2428, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_x_2428);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_t_2443 = (g_std_2epath_2ejoin(v_st_2439, v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str5)));
    V v_t_2444 = (g_std_2epath_2ejoin(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str6), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str7)));
    v_x_2446 = ({ V a_0 = v_st_2439; V a_1 = v_t_2443; V a_2 = v_t_2444; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2439); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2445 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2428);
    heff_drop(v_st_2439);
    v_x_2446 = v_d_2445;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_241;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam6_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(v_t_2436, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam7, 1, 4, (V[]){v_x_2410, v_x_2419, v_x_2428, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam5, 1, 4, (V[]){v_hd_240, v_x_2410, v_x_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_lam3, 1, 3, (V[]){v_hd_240, v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str0)));
    V v_d_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_246, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_247, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_str1))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1, 2, 4, (V[]){v_path_248, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_t_2422 = v_x_2420;
    break;
  }
  case TAG_Just: {
    V v_text_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2421}), v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2410;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(v_ps_240, v_rest_245));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam4, 1, 3, (V[]){v_x_2418, v_m_244, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_path_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_249, v_m_244, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3(V self, V *args) {
  V v_ns_2416 = args[0];
  return v_ns_2416;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2427) == NTAG(TAG_True))) {
    heff_drop(v_x_2427);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2427);
    heff_drop(v_done_241);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_str1));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam7, 1, 2, (V[]){v_p_243, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2426);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_t_2425; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam5, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam1_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2446 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str10, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str11, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str17, 1, "\"");
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0_clo)})});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})));
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2424 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str2), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str3)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2424});
    }
  }
  case TAG_Just: {
    V v_kept_2425 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2425, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2425);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2425);
        V v_t_2428 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_path_242), v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4_clo)})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5, 1, 2, (V[]){v_path_242, v_z_246})));
      } else {
        heff_drop(v_z_245);
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str6); V a_1 = v_kept_2425; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str7), v_kept_2425, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_kept_2425); r_; });
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str8); V a_1 = v_text_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str9), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_243); r_; });
        HeffT2 v_t_2438 = (g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(MK_INT(1LL), v_t_2436, v_t_2437));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_n_2441 = v_field_2439;
          V v_x22_2442 = v_field_2440;
          V v_x_2451;
          switch (heff_tag_of(v_x22_2442)) {
          case TAG_MkPair: {
            V v_kept_2443 = heff_field(v_x22_2442, 0);
            V v_text_2444 = heff_field(v_x22_2442, 1);
            V v_ru_24x22_2442_24MkPair = heff_take_reuse_n(v_x22_2442, 3ULL, 2);
            V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str10), heff_intShow(v_n_2441));
            V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str11), heff_strAppend(v_path_242, v_t_2445));
            V v_t_2447 = ({ V a_0 = v_kept_2443; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2443); r_; });
            V v_t_2448 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str13), heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str14)));
            V v_t_2449 = ({ V a_0 = v_text_2444; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2444); r_; });
            V v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str16), heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str17)));
            v_x_2451 = heff_tag_at_n(v_ru_24x22_2442_24MkPair, TAG_Wrong, 2, (V[]){v_t_2446, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2448, v_t_2450})});
            break;
          }
          default: heff_nomatch(v_x22_2442);
          }
          return heff_tail(v_z_246, 1, (V[]){v_x_2451});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam0(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423;
  if ((heff_dup(v_x_2422) == NTAG(TAG_True))) {
    heff_drop(v_x_2422);
    v_t_2423 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2422);
    v_t_2423 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str0), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str1)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_path_242), v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam3, 1, 2, (V[]){v_path_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam4(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435;
  if ((heff_dup(v_x_2434) == NTAG(TAG_True))) {
    heff_drop(v_x_2434);
    v_t_2435 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2434);
    v_t_2435 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str4), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_str5)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(V v_rep_240, V v_opts_241, V v_done_242, V v_x3_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_done_242);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){v_acc_244});
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_x3_243, 0);
    V v_rest_248 = heff_field(v_x3_243, 1);
    V v_p_249 = heff_dup(heff_rfield(v_r_247, 1));
    V v_t_2410 = (g_list_2efilter_24s1505276232x1076898175(heff_dup(heff_rfield(v_r_247, 0)), heff_dup(v_done_242)));
    V v_t_2411 = (g_list_2esortBy_24s196358923x1153659155(v_t_2410));
    V v_more_2412 = (g_list_2emap_24s1498757180x165099811(v_t_2411));
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_249, 3)), v_more_2412));
    V v_c_2414 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_249, 0)), v_t_2413));
    V v_k_2417 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0, 1, 7, (V[]){v_acc_244, heff_dup(v_rep_240), heff_dup(v_opts_241), v_done_242, heff_dup(v_rest_248), heff_dup(v_z_245), v_z_246});
    return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1, 1, 5, (V[]){v_opts_241, v_k_2417, v_rep_240, v_p_249, v_z_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_acc_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_244, v_x_2415));
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_done_242; V a_3 = v_rest_248; V a_4 = v_t_2416; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rest_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_p_249 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2418)));
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_x_2418);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_249, 7);
    heff_drop(v_z_245);
    heff_drop(v_t_2419);
    V f_ = v_k_2417;
    args[0] = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get());
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2419);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_249, 0)), heff_dup(heff_rfield(v_p_249, 1)), heff_get_n(v_p_249, 2, 7), v_x_2418, v_z_245, v_k_2417));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str1, 0, "");
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(V v_rep_240, V v_prog_241, V v_rx_242, V v_ex_243, V v_opts_244, V v_ready_245, V v_acc_246) {
top: ;
  switch (heff_tag_of(v_ready_245)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_rx_242);
    heff_drop(v_ex_243);
    heff_drop_rec(v_opts_244, 4);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0, 2, 1, (V[]){v_acc_246});
  }
  case TAG_Cons: {
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2, 2, 8, (V[]){v_t_2412, v_rx_242, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246});
  }
  default: return heff_nomatch(v_ready_245);
  }
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_acc_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_acc_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4(V self, V *args) {
  V v_i_2416 = args[0];
  return v_i_2416;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_244 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_acc_246 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2439);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_244; V a_2 = v_x_2433; V a_3 = v_ready_245; V a_4 = v_acc_246; V a_5 = v_hd_2413; V a_6 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s581205110x197511476(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_ready_245, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_opts_244 = heff_env(self)[4];
  V v_x_2433 = heff_env(self)[5];
  V v_ready_245 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2437}));
  return (g_co_2eop_24s495635622x733177935(v_t_2438, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam8, 1, 7, (V[]){v_rep_240, v_opts_244, v_x_2433, v_ready_245, v_acc_246, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_opts_244 = heff_env(self)[6];
  V v_ready_245 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2434 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tr(heff_call(v_rx_242, 1, (V[]){v_t_2434}));
  return (g_co_2eop_24s495635622x733177935(v_t_2435, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam7, 1, 9, (V[]){v_x_2415, v_prog_241, v_hd_2413, v_rep_240, v_opts_244, v_x_2433, v_ready_245, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_244 = heff_env(self)[0];
  V v_ready_245 = heff_env(self)[1];
  V v_ex_243 = heff_env(self)[2];
  V v_rx_242 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_p_2419 = heff_dup(heff_rfield(v_opts_244, 1));
  V v_t_2429;
  if (heff_strEq_c_lent(v_p_2419, ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_str1), 2)) {
    heff_drop(v_p_2419);
    v_t_2429 = NTAG(TAG_Nil);
  } else {
    V v_t_2421 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_2419; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2419); r_; });
    V v_t_2422 = (g_list_2emap_24s1007499915x73800978(v_t_2421));
    HeffT2 v_t_2423 = (g_regex_2eallRead_24cpr(v_t_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_why_2427 = v_field_2425;
        heff_drop(v_why_2427);
        v_t_2429 = NTAG(TAG_Nil);
      } else {
        V v_sel_2428 = v_field_2425;
        v_t_2429 = v_sel_2428;
      }
    }
  }
  V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_245)));
  V v_t_2431 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2430; V r_ = (g_list_2efoldl_24s192900907x155689445(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
  V v_c_2432 = ({ V a_0 = v_ex_243; V a_1 = heff_dup(v_rx_242); V a_2 = v_t_2429; V a_3 = heff_dup(heff_rfield(v_opts_244, 2)); V a_4 = heff_tag_n(TAG_MkGroup, 1, (V[]){heff_dup(v_x_2418)}); V a_5 = v_t_2431; V a_6 = MK_INT(0LL); V a_7 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2429); r_; });
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam6, 1, 10, (V[]){v_x_2418, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_opts_244, v_ready_245, v_acc_246, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_rx_242 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_rx_242), 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam5, 1, 10, (V[]){v_opts_244, v_ready_245, v_ex_243, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_lam3, 1, 9, (V[]){v_rx_242, v_hd_2413, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s851371283x356629733(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str0, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str1, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str2, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str5, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str6, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str7, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str8, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str9, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str10, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str11, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str13, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str14, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str15, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str16, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str17, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str18, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(V v_rep_240, V v_prog_241, V v_opts_242, V v_at_243, V v_p_244, V v_k_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_p_244, 5)), 0, 5);
  HeffT2 v_t_249 = (g_list_2efind_24s814399109x689165205_24cpr(heff_dup(v_p_244), v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_src_2413 = v_field_2411;
      HeffT2 v_t_2414 = (g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(heff_dup(v_p_244), v_src_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_prog_241);
          heff_drop(v_at_243);
          V v_why_2418 = v_field_2416;
          V v_more_2419 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str0), v_why_2418, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
          V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2419));
          V v_c_2421 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2420));
          return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
        } else {
          V v_l_2425 = v_field_2416;
          V v_t_2426 = heff_strAppend(heff_dup(heff_rfield(v_p_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str1));
          V v_t_2428 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2426, MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2_clo)})}));
          return (g_co_2eop_24s495635622x733177935(v_t_2428, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3, 1, 9, (V[]){v_prog_241, v_z_246, v_l_2425, v_p_244, v_rep_240, v_opts_242, v_k_245, v_at_243, v_z_247})));
        }
      }
    } else {
      heff_drop(v_prog_241);
      heff_drop(v_at_243);
      heff_drop(v_field_2411);
      V v_more_24131 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str17), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str18), MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
      V v_t_24132 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_24131));
      V v_c_24133 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_24132));
      return heff_tail(v_c_24133, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2424});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2422)));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2422);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2423);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2423);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2422, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam1, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam2(V self, V *args) {
  V v_t_2427 = args[0];
  return v_t_2427;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_2448 = heff_env(self)[1];
  V v_z_2449 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2461});
  heff_room[1] = v_z_2448;
  heff_room[2] = v_z_2449;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_2448 = heff_env(self)[2];
  V v_z_2449 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2460 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2459)));
  if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
    heff_drop(v_x_2459);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2460);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2448;
    heff_room[2] = v_z_2449;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2460);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2459, heff_dup(v_z_2448), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam10, 1, 3, (V[]){v_k_245, v_z_2448, v_z_2449})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8(V self, V *args) {
  V v_x_2455 = args[0];
  V v_why_2447 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_2448 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_2449 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2455);
  V v_more_2456 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str7), v_why_2447, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_2457 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2456));
  V v_c_2458 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2457));
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_z_2448);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam9, 1, 6, (V[]){v_opts_242, v_k_245, v_z_2448, v_z_2449, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_2448 = heff_env(self)[2];
  V v_why_2447 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_z_2449 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2453}));
  return (g_co_2eop_24s495635622x733177935(v_t_2454, heff_dup(v_z_2448), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam8, 1, 7, (V[]){v_why_2447, v_p_244, v_opts_242, v_z_2448, v_k_245, v_z_2449, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6(V self, V *args) {
  V v_why_2447 = args[0];
  V v_z_2448 = args[1];
  V v_z_2449 = args[2];
  V v_x_2432 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450 = heff_tag_n(TAG_End, 2, (V[]){v_x_2432, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2450}));
  return (g_co_2eop_24s495635622x733177935(v_t_2451, heff_dup(v_z_2448), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam7, 1, 9, (V[]){v_x_2429, v_prog_241, v_z_2448, v_why_2447, v_p_244, v_opts_242, v_k_245, v_z_2449, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16(V self, V *args) {
  V v_x_2478 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_2468 = heff_env(self)[1];
  V v_z_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2478});
  heff_room[1] = v_z_2468;
  heff_room[2] = v_z_2469;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15(V self, V *args) {
  V v_x_2476 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_2468 = heff_env(self)[2];
  V v_z_2469 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2477 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2476)));
  if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
    heff_drop(v_x_2476);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2477);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2468;
    heff_room[2] = v_z_2469;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2477);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2476, heff_dup(v_z_2468), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam16, 1, 3, (V[]){v_k_245, v_z_2468, v_z_2469})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14(V self, V *args) {
  V v_x_2472 = args[0];
  V v_why_2467 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_2468 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_2469 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2472);
  V v_more_2473 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str10), v_why_2467, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_2474 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2473));
  V v_c_2475 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2474));
  V f_ = v_c_2475;
  heff_room[0] = heff_dup(v_z_2468);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam15, 1, 6, (V[]){v_opts_242, v_k_245, v_z_2468, v_z_2469, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13(V self, V *args) {
  V v_why_2467 = args[0];
  V v_z_2468 = args[1];
  V v_z_2469 = args[2];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2470 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2470}));
  return (g_co_2eop_24s495635622x733177935(v_t_2471, heff_dup(v_z_2468), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam14, 1, 7, (V[]){v_why_2467, v_p_244, v_opts_242, v_z_2468, v_k_245, v_z_2469, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18(V self, V *args) {
  V v_r_2481 = args[0];
  return v_r_2481;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20(V self, V *args) {
  V v_s_2489 = args[0];
  return v_s_2489;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22(V self, V *args) {
  V v_r_2498 = args[0];
  return v_r_2498;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24(V self, V *args) {
  V v_r_24107 = args[0];
  return v_r_24107;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26(V self, V *args) {
  V v_x_24117 = args[0];
  V v_x_2488 = heff_env(self)[0];
  V v_x_24105 = heff_env(self)[1];
  V v_x_2497 = heff_env(self)[2];
  V v_x_24114 = heff_env(self)[3];
  V v_l_2425 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_hd_2479 = heff_env(self)[8];
  V v_k_2480 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24117);
  V v_t_24120;
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Left: {
    heff_take_n(v_x_2488, 0ULL, 1);
    v_t_24120 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str12);
    break;
  }
  case TAG_Right: {
    V v_real_24119 = heff_field(v_x_2488, 0);
    heff_take_n(v_x_2488, 1ULL, 1);
    v_t_24120 = v_real_24119;
    break;
  }
  default: heff_nomatch(v_x_2488);
  }
  V v_t_24123;
  switch (heff_tag_of(v_x_24105)) {
  case TAG_Left: {
    heff_take_n(v_x_24105, 0ULL, 1);
    v_t_24123 = v_x_2497;
    break;
  }
  case TAG_Right: {
    V v_real_24122 = heff_field(v_x_24105, 0);
    heff_take_n(v_x_24105, 1ULL, 1);
    heff_drop(v_x_2497);
    v_t_24123 = v_real_24122;
    break;
  }
  default: heff_nomatch(v_x_24105);
  }
  V v_t_24126;
  switch (heff_tag_of(v_x_24114)) {
  case TAG_Left: {
    heff_take_n(v_x_24114, 0ULL, 1);
    v_t_24126 = heff_get_n(heff_get_n(v_l_2425, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_24125 = heff_field(v_x_24114, 0);
    heff_take_n(v_x_24114, 1ULL, 1);
    heff_drop_rec(v_l_2425, 5);
    v_t_24126 = v_real_24125;
    break;
  }
  default: heff_nomatch(v_x_24114);
  }
  V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str13), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str14)}), NTAG(TAG_Nil)});
  V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str15), v_t_24126}), v_t_24127});
  V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str16), v_t_24123}), v_t_24128});
  V v_t_24130 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_243, v_p_244, heff_rec_n(2, shape_program__env, (V[]){v_t_24120, v_t_24129})});
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24130});
  heff_room[1] = v_hd_2479;
  heff_room[2] = v_k_2480;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25(V self, V *args) {
  V v_x_24114 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_x_2488 = heff_env(self)[3];
  V v_x_24105 = heff_env(self)[4];
  V v_x_2497 = heff_env(self)[5];
  V v_l_2425 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_p_244 = heff_env(self)[8];
  V v_k_245 = heff_env(self)[9];
  V v_k_2480 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24115 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_24116 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_24115}));
  return (g_co_2eop_24s495635622x733177935(v_t_24116, heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam26, 1, 10, (V[]){v_x_2488, v_x_24105, v_x_2497, v_x_24114, v_l_2425, v_at_243, v_p_244, v_k_245, v_hd_2479, v_k_2480})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23(V self, V *args) {
  V v_x_24105 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_hd_2479 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  V v_x_2497 = heff_env(self)[5];
  V v_at_243 = heff_env(self)[6];
  V v_p_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  V v_k_2480 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24106 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 0, 6);
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24106, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam24_clo)})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24113}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam25, 1, 11, (V[]){v_x_2429, v_prog_241, v_hd_2479, v_x_2488, v_x_24105, v_x_2497, v_l_2425, v_at_243, v_p_244, v_k_245, v_k_2480})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21(V self, V *args) {
  V v_x_2497 = args[0];
  V v_hd_2479 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_k_2480 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){heff_dup(v_x_2497), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam22_clo)})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24104}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam23, 1, 10, (V[]){v_l_2425, v_hd_2479, v_x_2429, v_prog_241, v_x_2488, v_x_2497, v_at_243, v_p_244, v_k_245, v_k_2480})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_2479 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_k_2480 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam20_clo)})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
  return (g_co_2eop_24s495635622x733177935(v_t_2496, heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam21, 1, 9, (V[]){v_hd_2479, v_l_2425, v_x_2429, v_prog_241, v_x_2488, v_at_243, v_p_244, v_k_245, v_k_2480})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_path_2444 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){v_path_2444, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam18_clo)})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam19, 1, 8, (V[]){v_hd_2479, v_l_2425, v_x_2429, v_prog_241, v_at_243, v_p_244, v_k_245, v_k_2480})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12(V self, V *args) {
  V v_x_2464 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_dir_2434 = heff_env(self)[7];
  V v_out_2439 = heff_env(self)[8];
  V v_path_2444 = heff_env(self)[9];
  V v_at_243 = heff_env(self)[10];
  V v_hd_2462 = heff_env(self)[11];
  V v_k_2463 = heff_env(self)[12];
  heff_clo_take(self, 13);
  heff_drop(v_x_2464);
  V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str9), NTAG(TAG_Nil)});
  return ({ V a_0 = heff_dup(v_prog_241); V a_1 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam13, 3, 6, (V[]){heff_dup(v_x_2429), heff_dup(v_prog_241), heff_dup(v_p_244), v_opts_242, heff_dup(v_k_245), v_rep_240}); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str11); V a_3 = v_t_2465; V a_4 = v_t_2466; V a_5 = heff_dup(v_x_2429); V a_6 = v_dir_2434; V a_7 = v_out_2439; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam17, 2, 7, (V[]){v_path_2444, v_l_2425, v_x_2429, v_prog_241, v_at_243, v_p_244, v_k_245}); V a_9 = v_hd_2462; V a_10 = v_k_2463; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_2465); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_t_2446 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_dir_2434 = heff_env(self)[8];
  V v_out_2439 = heff_env(self)[9];
  V v_path_2444 = heff_env(self)[10];
  V v_at_243 = heff_env(self)[11];
  heff_clo_take(self, 12);
  return (g_co_2eop_24s495635622x733177935(v_t_2446, heff_dup(v_hd_2462), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam12, 1, 13, (V[]){v_l_2425, v_prog_241, v_x_2429, v_p_244, v_opts_242, v_k_245, v_rep_240, v_dir_2434, v_out_2439, v_path_2444, v_at_243, v_hd_2462, v_k_2463})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_x_2429 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  V v_z_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_dir_2434 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_d_2435 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2438;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Posix: {
    v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str4);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_out_2439 = ({ V a_0 = v_t_2436; V a_1 = v_d_2435; V a_2 = v_t_2438; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2436); r_; });
  V v_d_2440 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2443;
  switch (heff_tag_of(v_t_2442)) {
  case TAG_Posix: {
    v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str5);
    break;
  }
  case TAG_Windows: {
    v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str6);
    break;
  }
  default: heff_nomatch(v_t_2442);
  }
  V v_path_2444 = ({ V a_0 = v_t_2441; V a_1 = v_d_2440; V a_2 = v_t_2443; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; });
  V v_t_2445 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2432), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2445}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(heff_dup(v_rep_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam6, 3, 7, (V[]){v_x_2432, heff_dup(v_prog_241), heff_dup(v_x_2429), heff_dup(v_p_244), heff_dup(v_opts_242), heff_dup(v_k_245), heff_dup(v_rep_240)}), heff_dup(v_l_2425), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get())}), heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str8)), heff_dup(heff_rfield(v_p_244, 0)), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam11, 2, 12, (V[]){v_t_2446, v_l_2425, v_prog_241, v_x_2429, v_p_244, v_opts_242, v_k_245, v_rep_240, v_dir_2434, v_out_2439, v_path_2444, v_at_243}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_l_2425 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2429), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_str2), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2431, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam5, 1, 10, (V[]){v_l_2425, v_p_244, v_prog_241, v_rep_240, v_x_2429, v_opts_242, v_k_245, v_at_243, v_z_246, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28(V self, V *args) {
  V v_x_24136 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24136});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam27(V self, V *args) {
  V v_x_24134 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24135 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_24134)));
  if ((heff_dup(v_t_24135) == NTAG(TAG_True))) {
    heff_drop(v_x_24134);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_24135);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24135);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_24134, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_lam28, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str2, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2430;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2430 = v_done_245;
  } else {
    V v_ps_2410 = heff_dup(heff_rfield(v_bi_240, 0));
    V v_d_2411 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2410, 5), heff_take_field(v_ps_2410, 0), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str1)));
    V v_path_2412 = ({ V b_0 = heff_get_n(v_ps_2410, 5, 6); V a_1 = v_d_2411; V a_2 = heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get()); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_t_2430 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0, 2, 7, (V[]){v_path_2412, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(v_outPath_241, v_t_2430, heff_get_n(v_out_246, 0, 4), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2422);
  V v_t_2423 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_str2), heff_take_field(v_bi_240, 2)});
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop_tag(v_t_2424, 2); r_; });
  V v_t_2426 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_246, 1), heff_take_field(v_out_246, 2), NTAG(TAG_Nil), heff_get_n(v_out_246, 3, 4)});
  V v_t_2427 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2425, v_backs_244}), v_t_2426));
  V v_c_2428 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2423; V a_2 = v_t_2427; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(a_0, a_1, a_2)); heff_drop(v_t_2423); heff_drop(v_t_2427); r_; });
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam3, 1, 3, (V[]){v_done_245, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_path_2412 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2413, v_done_245, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str1, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s495635622x733177935(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1, 1, 4, (V[]){v_path_240, v_hd_242, v_text_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2439);
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str1), v_path_240), ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str2));
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2440, NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam6, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2431);
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_path_240), v_text_241, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam4_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam5, 1, 3, (V[]){v_k_243, v_path_240, v_hd_242})));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(v_st_2414, heff_dup(v_path_240)));
  V v_t_2422;
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2418));
    V v_xs_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2419; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    v_t_2422 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2416, v_field_2417, v_t_2421});
  }
  V v_path_2423 = ({ V a_0 = v_st_2414; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); r_; });
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2423, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam2_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_lam3, 1, 4, (V[]){v_path_240, v_text_241, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str2, 5, "win32");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6(V self, V *args) {
  V v_n_2433 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435;
  if (heff_strEq_c(v_x_2431, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str2))) {
    v_t_2435 = NTAG(TAG_Windows);
  } else {
    v_t_2435 = NTAG(TAG_Posix);
  }
  return ({ V a_0 = v_t_2435; V a_1 = v_p_245; V a_2 = v_n_2433; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ns_2422 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str1); V a_3 = v_ns_2422; V r_ = (g_list_2efilter_24s2101000672x961294372(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2436 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam6, 1, 2, (V[]){v_x_2431, v_p_245}), v_t_2432));
  V v_t_2437 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_2436, v_acc_241));
  V f_ = v_t_2437;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_245, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice(heff_dup(v_p_245), heff_box_word(v_t_2417), heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_str0))) {
      V v_t_2420 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2420;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2421 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_rest_246, v_acc_241));
      V f_ = v_t_2421;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2422 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam4_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s495635622x733177935(v_t_2430, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam5, 1, 6, (V[]){v_ns_2422, v_rest_246, v_p_245, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str2, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})));
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3_clo)})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_next_244;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str0), v_to_243));
  V v_t_2417 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str1)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam3(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5(V self, V *args) {
  V v_ok_2433 = args[0];
  return v_ok_2433;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str2), v_to_243));
  V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str4), v_t_2441));
  V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_str5)), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam7, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2432);
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam5_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_n_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_244, heff_dup(v_n_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0_clo)})}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1, 2, 7, (V[]){v_t_248, v_n_246, heff_dup(v_st_241), v_home_243, v_t_242, v_prog_240, v_next_245});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7(V self, V *args) {
  V v_ok_2433 = args[0];
  return v_ok_2433;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9(V self, V *args) {
  V v_ok_2442 = args[0];
  return v_ok_2442;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11(V self, V *args) {
  V v_ok_2451 = args[0];
  return v_ok_2451;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14(V self, V *args) {
  V v_x_2464 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2462 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2464);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2462;
  heff_room[1] = v_k_2463;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_t_2461 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2461, heff_dup(v_hd_2462), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam14, 1, 3, (V[]){v_next_245, v_hd_2462, v_k_2463})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_x_2415 = heff_env(self)[7];
  V v_next_245 = heff_env(self)[8];
  V v_hd_249 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2459 = ({ V a_0 = v_st_241; V a_1 = v_home_243; V a_2 = v_n_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2460 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2460}));
  return ({ V a_0 = v_t_242; V a_1 = v_x_2413; V a_2 = v_x_2415; V a_3 = v_t_2459; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam13, 2, 2, (V[]){v_t_2461, v_next_245}); V a_5 = v_x_2458; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s595061643x196701501(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2458); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10(V self, V *args) {
  V v_x_2449 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_x_2415 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2449);
  V v_to_2450 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), heff_dup(v_n_246)));
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){heff_dup(v_x_2413), v_to_2450, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam11_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam12, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2411, v_prog_240, v_t_242, v_x_2413, v_x_2415, v_next_245, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15(V self, V *args) {
  V v_ok_2465 = args[0];
  return v_ok_2465;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2491}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16(V self, V *args) {
  V v_x_2472 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2472);
  V v_t_2473 = ({ V a_0 = v_st_241; V a_1 = heff_get_n(v_t_242, 0, 6); V a_2 = v_n_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2474 = heff_strAppend(v_t_2473, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str4), v_x_2413));
  V v_why_2475 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str5), v_t_2474);
  V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str6), v_why_2475), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str7));
  V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2476, NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam17, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_t_242 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  if ((heff_dup(v_x_2440) == NTAG(TAG_True))) {
    heff_drop(v_x_2440);
    V v_path_2441 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), heff_dup(v_n_246)));
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_path_2441, heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam9_clo)})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam10, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2413, v_hd_249, v_x_2411, v_prog_240, v_t_242, v_x_2415, v_next_245, v_k_2410})));
  } else {
    heff_drop(v_x_2440);
    heff_drop(v_home_243);
    heff_drop(v_x_2415);
    heff_drop(v_x_2411);
    heff_drop(v_prog_240);
    heff_drop(v_next_245);
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam15_clo)})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam16, 1, 6, (V[]){v_st_241, v_t_242, v_n_246, v_x_2413, v_hd_249, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_home_243 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2431);
  V v_path_2432 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), heff_dup(v_n_246)));
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2432, heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam7_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam8, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2415, v_hd_249, v_x_2413, v_x_2411, v_prog_240, v_t_242, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_n_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_home_243 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_prog_240 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam5_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam6, 1, 11, (V[]){v_st_241, v_t_242, v_n_246, v_x_2413, v_hd_249, v_home_243, v_x_2415, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str0), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str1)));
  V v_x_2413 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), v_t_2412));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str2), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_str3)));
  V v_x_2415 = (g_std_2epath_2ejoin(v_st_241, heff_dup(v_home_243), v_t_2414));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam4, 1, 11, (V[]){v_x_2415, v_hd_249, v_st_241, v_t_242, v_n_246, v_x_2413, v_home_243, v_x_2411, v_prog_240, v_next_245, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_246 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_home_243 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_lam2, 1, 8, (V[]){v_n_246, v_st_241, v_home_243, v_hd_249, v_t_242, v_prog_240, v_next_245, v_k_2410})));
}