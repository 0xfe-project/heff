// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_c 317
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_out 319944
#define LBL_own 320000
#define LBL_root 10001833
#define LBL_seen 10021698
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(V, V);
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2eordmap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2416;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x31_2413 = v_field_2412;
      switch (heff_tag_of(v_x31_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x31_2413, 0);
        V v_j_2415 = heff_field(v_x31_2413, 1);
        heff_take_n(v_x31_2413, 3ULL, 2);
        if (heff_intLe_c(heff_strLength(v_text_249), v_j_2415)) {
          v_t_2416 = v_x_2414;
        } else {
          heff_drop(v_x_2414);
          v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        break;
      }
      default: heff_nomatch(v_x31_2413);
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, v_t_246, v_t_2416));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2424 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2422), v_x_2423));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_a_2424));
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2422), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str2)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_x_2428 = ({ V a_0 = v_st_2422; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2427); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2422;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str1))) {
    v_st_2422 = NTAG(TAG_Windows);
  } else {
    v_st_2422 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4, 1, 2, (V[]){v_st_2422, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2419}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2420;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_lib_2429 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_lib_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam5, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_245 = v_field_244;
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_path_245), heff_box_word(v_t_246), heff_strLength_lent(v_path_245, 0));
      V v_t_249;
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str0))) {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
        v_t_249 = heff_strSlice(v_path_245, MK_INT(0LL), heff_box_word(v_t_248));
      } else {
        v_t_249 = v_path_245;
      }
      V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_str1))));
      V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
      V v_a_2413 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0_clo)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_c_2426 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1_clo)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3, 2, 2, (V[]){v_c_2426, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam5_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2421})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2422));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam2, 2, 1, (V[]){v_x_2423});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_drop(v_m_241);
    V f_ = v_k_2428;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    V v_t_2432 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_y_2431})});
    V f_ = v_k_2428;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam4, 1, 2, (V[]){v_k_2428, v_m_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str8, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str9, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str10, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str13, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str14, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str15, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam8(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str3); V a_6 = v_t_2416; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(v_sources_241, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0, 1, 9, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2413, v_z_249, v_file_242, v_failed_245, v_bi_240, v_done_246})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2486 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str15), NTAG(TAG_MkUnit)});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
      return heff_tail(heff_dup(heff_rfield(v_z_248, 1)), 2, (V[]){v_t_2493, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam8, 1, 2, (V[]){v_z_248, v_z_249})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(a[0], a1, a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a1); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    V v_err_2438 = heff_field(v_x_2437, 0);
    V v_ru_24x_2437_24Left = heff_take_reuse_n(v_x_2437, 1ULL, 1);
    V v_t_2439 = heff_tag_at_n(v_ru_24x_2437_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2438})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2439));
  }
  case TAG_Right: {
    V v_x_2440 = heff_field(v_x_2437, 0);
    heff_take_n(v_x_2437, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam5, 2, 1, (V[]){v_x_2440});
  }
  default: return heff_nomatch(v_x_2437);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_ru_24x_2444_24Left = heff_take_reuse_n(v_x_2444, 0ULL, 1);
    V v_exports_2446 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str8); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2447 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2446)));
    V v_t_2448 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 10);
    V v_t_2449 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2448));
    V v_t_2450 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2447, v_t_2449));
    V v_t_2451 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2446, v_t_2450));
    return ({ V a_0 = v_ru_24x_2444_24Left; V a_1 = v_outPath_244; V b_2 = NTAG(TAG_True); V a_3 = v_t_2451; V a_4 = v_z_248; V a_5 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
  }
  case TAG_Right: {
    V v_ru_24x_2444_24Right = heff_take_reuse_n(v_x_2444, 0ULL, 1);
    V v_exports_2453 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str9); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2454 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2453)));
    V v_t_2455 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 10);
    V v_t_2456 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2455));
    V v_t_2457 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2454, v_t_2456));
    V v_t_2458 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2453, v_t_2457));
    return ({ V a_0 = v_ru_24x_2444_24Right; V a_1 = v_outPath_244; V b_2 = NTAG(TAG_False); V a_3 = v_t_2458; V a_4 = v_z_248; V a_5 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam7(V self, V *args) {
  V v_x_2480 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2469 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2480);
  V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str13), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str14));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2481, v_why_2469);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_x_2420 = heff_env(self)[6];
  V v_file_242 = heff_env(self)[7];
  V v_failed_245 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2420);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_bi_240);
    heff_drop(v_done_246);
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2424 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2423), heff_strLength_lent(v_outPath_244, 0));
    V v_t_2426;
    if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str6))) {
      int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2426 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2425), 6);
    } else {
      v_t_2426 = heff_dup(v_outPath_244);
    }
    V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str7))));
    V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
    V v_a_2430 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2428, v_x_2422, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam3_clo)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    V v_c_2443 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam4_clo)));
    V f_ = v_c_2443;
    heff_room[0] = heff_dup(v_z_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam6, 1, 5, (V[]){v_c_2413, v_x_2421, v_outPath_244, v_z_248, v_z_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2460 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
    V v_t_2461 = ({ V a_0 = v_t_2460; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2460); r_; });
    V v_leaves_2462 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2461));
    V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
    V v_t_2465 = (g_list_2emap_24s164225955x66209884(v_t_2463, v_t_2464, v_leaves_2462));
    HeffT2 v_t_2466 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2465));
    {
      V v_field_2468 = v_t_2466.f[1];
      int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
      if ((v_tag_2467 == ((int64_t)0ULL))) {
        heff_drop(v_x_2422);
        heff_drop_tag(v_name_243, 1);
        heff_drop(v_outPath_244);
        heff_drop_rec(v_c_2413, 14);
        heff_drop(v_x_2421);
        heff_drop(v_x_2420);
        heff_drop(v_bi_240);
        heff_drop(v_done_246);
        V v_why_2469 = v_field_2468;
        V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str10), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str11));
        V v_t_2471 = heff_strAppend(heff_strAppend(v_t_2470, heff_dup(v_why_2469)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str12));
        V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2471, NTAG(TAG_MkUnit)});
        V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
        V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
        V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})}));
        V f_ = heff_dup(heff_rfield(v_z_248, 1));
        heff_room[0] = v_t_2479;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam7, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2469, v_z_248, v_z_249});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_ms_2482 = v_field_2468;
        V v_glues_2483 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2482));
        V v_t_2484 = (g_list_2emap_24s1435185561x202019164(v_glues_2483));
        V v_t_2485 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2484));
        return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2421, v_x_2422}); V a_5 = v_failed_245; V a_6 = v_done_246; V a_7 = v_c_2413; V a_8 = v_t_2485; V a_9 = v_z_248; V a_10 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop_tag(v_name_243, 1); r_; });
      }
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam2, 1, 11, (V[]){v_name_243, v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249, v_x_2420, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam1, 1, 10, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2413, v_z_249, v_x_2420, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_lam8(V self, V *args) {
  V v_x_2494 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2494);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str4, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str5, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str6, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str8, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str9, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str10, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str11, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str12, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str13, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str14, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str15, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str16, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str17, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str18, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str21, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str22, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str23, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str24, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str25, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str26, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str27, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str28, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588(V v_lit_240, V v_lit_241, V v_failed_242, V v_who_243, V v_st_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_246)));
  V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2412 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam0_clo)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_c_2436 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam1, 3, 1, (V[]){v_path_249})));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam5, 2, 10, (V[]){v_c_2436, v_st_244, v_dir_246, v_p_245, v_lit_240, v_lit_241, v_out_247, v_next_248, v_who_243, v_failed_242});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2427));
  return (g_std_2epath_2ejoin(v_path_249, v_t_2428));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_2425 = args[1];
  V v_z_2426 = args[2];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2425);
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam3, 1, 1, (V[]){v_path_249}), v_x_2424));
  V v_x_2430 = (g_list_2emap_24s219049803x1458391381(v_x_2429));
  V f_ = v_z_2426;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam4(V self, V *args) {
  V v_n_2432 = args[0];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2432));
  return (g_std_2epath_2ejoin(v_path_249, v_t_2433));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_2420 = args[1];
  V v_z_2421 = args[2];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2422 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2422})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2423, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam2, 3, 1, (V[]){v_path_249}), v_z_2420, v_z_2421));
  }
  case TAG_Right: {
    V v_x_2431 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_z_2420);
    V v_x_2434 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam4, 1, 1, (V[]){v_path_249}), v_x_2431));
    V v_x_2435 = (g_list_2emap_24s219049803x1458391381(v_x_2434));
    V f_ = v_z_2421;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam7(V self, V *args) {
  V v_n_2446 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_dir_246));
  V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_n_2446));
  V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
  return ({ V a_0 = v_st_244; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_2449); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam8(V self, V *args) {
  V v_n_2454 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_dir_246));
  V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_n_2454));
  V v_t_2457 = (g_std_2epath_2ejoin(v_t_2455, v_t_2456));
  return ({ V a_0 = v_st_244; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_2457); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam9(V self, V *args) {
  V v_t_2462 = args[0];
  return v_t_2462;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam12(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  heff_drop(v_hd_2470);
  V v_t_2472 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str19), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str20)});
  V f_ = v_k_2471;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam13(V self, V *args) {
  V v_r_2481 = args[0];
  return v_r_2481;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam17(V self, V *args) {
  V v_x_24113 = args[0];
  V v_who_243 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_242 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24113);
  V v_t_24114 = heff_strAppend(heff_strAppend(v_who_243, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str28)), v_out_247);
  V f_ = v_failed_242;
  heff_room[0] = v_t_24114;
  heff_room[1] = v_hd_2437;
  heff_room[2] = v_k_2438;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam16(V self, V *args) {
  V v_x_24103 = args[0];
  V v_who_243 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_failed_242 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24103);
  V v_t_24104 = heff_strAppend(heff_strAppend(heff_dup(v_who_243), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str26)), heff_dup(v_out_247));
  V v_t_24105 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24104, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str27)), NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  heff_room[0] = v_t_24112;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam17, 1, 5, (V[]){v_who_243, v_out_247, v_failed_242, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam15(V self, V *args) {
  V v_x_2491 = args[0];
  V v_ended_2486 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  V v_err_2487 = heff_env(self)[4];
  V v_who_243 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2491);
  V v_t_2494;
  switch (heff_tag_of(v_ended_2486)) {
  case TAG_Exited: {
    V v_n_2492 = heff_field(v_ended_2486, 0);
    heff_take_n(v_ended_2486, 1ULL, 1);
    v_t_2494 = heff_bool(heff_intEq_c_lent(v_n_2492, MK_INT(0LL), 2));
    heff_drop(v_n_2492);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2486, 0ULL, 1);
    v_t_2494 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2494 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2494 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2486);
  }
  if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
    heff_drop(v_err_2487);
    heff_drop(v_who_243);
    heff_drop(v_out_247);
    heff_drop(v_failed_242);
    heff_drop(v_t_2494);
    V f_ = v_next_248;
    heff_room[0] = v_hd_2437;
    heff_room[1] = v_k_2438;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2494);
    V v_t_2495 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2487, NTAG(TAG_MkUnit)});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})}));
    V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
    heff_room[0] = v_t_24102;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam16, 1, 5, (V[]){v_who_243, v_out_247, v_hd_2437, v_failed_242, v_k_2438});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam14(V self, V *args) {
  V v_x_2485 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_hd_2437 = heff_env(self)[1];
  V v_next_248 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  V v_who_243 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_failed_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2486 = heff_take_field(v_x_2485, 0);
  V v_err_2487 = heff_get_n(v_x_2485, 2, 3);
  V v_t_2488 = heff_tag_n(TAG_End, 2, (V[]){v_x_2466, NTAG(TAG_MkUnit)});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  heff_room[0] = v_t_2490;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam15, 1, 8, (V[]){v_ended_2486, v_next_248, v_hd_2437, v_k_2438, v_err_2487, v_who_243, v_out_247, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam11(V self, V *args) {
  V v_x_2469 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2450 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_x_2466 = heff_env(self)[4];
  V v_hd_2437 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2438 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2484;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_Nothing: {
    heff_drop(v_x_2450);
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    v_c_2484 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam12_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2473 = heff_field(v_x_2469, 0);
    V v_ru_24x_2469_24Just = heff_take_reuse_n(v_x_2469, 1ULL, 1);
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str21), NTAG(TAG_Nil)});
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str22), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2474})});
    V v_t_2476 = (g_prelude_2e_2b_2b(v_os_2473, v_t_2475));
    V v_t_2477 = (g_prelude_2e_2b_2b(v_x_2450, v_t_2476));
    V v_ys_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str23), v_t_2477});
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, v_ys_2478})});
    V v_argv_2480 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str24), v_t_2479});
    V v_t_2482 = heff_tag_at_n(v_ru_24x_2469_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2466), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str25), v_argv_2480, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam13_clo)})});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
    v_c_2484 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2483}));
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam14, 1, 7, (V[]){v_x_2466, v_hd_2437, v_next_248, v_k_2438, v_who_243, v_out_247, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam10(V self, V *args) {
  V v_x_2466 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_x_2458 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2450 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2438 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2467;
  if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str3), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str4), 2))) {
    v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str5);
  } else {
    if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str6), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str7), 2))) {
      v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str8);
    } else {
      if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str9), 2)) {
        v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str10);
      } else {
        if (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str11), 2)) {
          v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str12);
        } else {
          if (((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str13), 2) || heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str14), 2)) || (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str15), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str16), 2)))) {
            v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str17);
          } else {
            v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str18);
          }
        }
      }
    }
  }
  V v_c_2468 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(heff_dup(v_x_2466), v_t_2467, v_x_2458, NTAG(TAG_Nil)));
  V f_ = v_c_2468;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam11, 1, 10, (V[]){v_out_247, v_x_2450, v_lit_240, v_lit_241, v_x_2466, v_hd_2437, v_next_248, v_k_2438, v_who_243, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2438 = heff_env(self)[8];
  V v_who_243 = heff_env(self)[9];
  V v_failed_242 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_x_2442;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    v_x_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2439, 0);
    V v_ru_24x_2439_24Right = heff_take_reuse_n(v_x_2439, 1ULL, 1);
    v_x_2442 = heff_tag_at_n(v_ru_24x_2439_24Right, TAG_Just, 1, (V[]){v_y_2441});
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  V v_t_2444;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    v_t_2444 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2443 = heff_dup(heff_field(v_x_2442, 0));
    v_t_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_t_2445 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str0); V a_1 = v_t_2444; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2450 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam7, 1, 2, (V[]){heff_dup(v_st_244), heff_dup(v_dir_246)}), v_t_2445));
  V v_t_2452;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    v_t_2452 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2451 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    v_t_2452 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_t_2453 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str1); V a_1 = v_t_2452; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2458 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam8, 1, 2, (V[]){v_st_244, v_dir_246}), v_t_2453));
  V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2450));
  V v_t_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2458));
  V v_total_2461 = heff_intAdd(heff_intAdd(v_t_2459, v_t_2460), MK_INT(1LL));
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_str2), v_total_2461, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam9_clo)})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){v_t_2464}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  heff_room[0] = v_t_2465;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam10, 1, 10, (V[]){v_lit_240, v_lit_241, v_x_2458, v_hd_2437, v_out_247, v_x_2450, v_next_248, v_k_2438, v_who_243, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_st_244 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1192179132x1383272588_lam6, 1, 11, (V[]){v_st_244, v_dir_246, v_p_245, v_hd_2437, v_lit_240, v_lit_241, v_out_247, v_next_248, v_k_2438, v_who_243, v_failed_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str9, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str11, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str12, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str0)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2411, NTAG(TAG_Nil)));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam0, 1, 7, (V[]){v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam7(V self, V *args) {
  V v_r_2459 = args[0];
  return v_r_2459;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam10(V self, V *args) {
  V v_n_2475 = args[0];
  V v_path_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2475));
  return (g_std_2epath_2ejoin(v_path_2457, v_t_2476));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam9(V self, V *args) {
  V v_x_2472 = args[0];
  V v_z_2473 = args[1];
  V v_z_2474 = args[2];
  V v_path_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2473);
  V v_x_2477 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam10, 1, 1, (V[]){v_path_2457}), v_x_2472));
  V v_x_2478 = (g_list_2emap_24s219049803x1458391381(v_x_2477));
  V f_ = v_z_2474;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2478});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam11(V self, V *args) {
  V v_n_2480 = args[0];
  V v_path_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2480));
  return (g_std_2epath_2ejoin(v_path_2457, v_t_2481));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam8(V self, V *args) {
  V v_x_2467 = args[0];
  V v_z_2468 = args[1];
  V v_z_2469 = args[2];
  V v_path_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2467)) {
  case TAG_Left: {
    V v_err_2470 = heff_field(v_x_2467, 0);
    V v_ru_24x_2467_24Left = heff_take_reuse_n(v_x_2467, 1ULL, 1);
    V v_t_2471 = heff_tag_at_n(v_ru_24x_2467_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2470})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2471, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam9, 3, 1, (V[]){v_path_2457}), v_z_2468, v_z_2469));
  }
  case TAG_Right: {
    V v_x_2479 = heff_field(v_x_2467, 0);
    heff_take_n(v_x_2467, 1ULL, 1);
    heff_drop(v_z_2468);
    V v_x_2482 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam11, 1, 1, (V[]){v_path_2457}), v_x_2479));
    V v_x_2483 = (g_list_2emap_24s219049803x1458391381(v_x_2482));
    V f_ = v_z_2469;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2483});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2467);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam13(V self, V *args) {
  V v_t_2492 = args[0];
  return v_t_2492;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam17(V self, V *args) {
  V v_x_24121 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24121);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam16(V self, V *args) {
  V v_x_24107 = args[0];
  V v_bad_24102 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_apps_24103 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_st_240 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_done_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24107);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_24102, 1)) {
    heff_drop(v_apps_24103);
    heff_drop(v_none_243);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_done_244);
    V v_n_24108 = v_bad_24102;
    V v_t_24109;
    if (heff_intEq_c_lent(v_n_24108, MK_INT(1LL), 2)) {
      heff_drop(v_n_24108);
      v_t_24109 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str17);
    } else {
      v_t_24109 = heff_strAppend(heff_intShow(v_n_24108), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str18));
    }
    V v_what_24110 = heff_strAppend(v_t_24109, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str19));
    V v_t_24111 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str20), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str21));
    V v_t_24112 = heff_strAppend(heff_strAppend(v_t_24111, v_what_24110), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str22));
    V v_t_24113 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24112, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str23)), NTAG(TAG_MkUnit)});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24120;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam17, 1, 2, (V[]){v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_bad_24102);
    heff_drop(v_cmd_241);
    switch (heff_tag_of(v_apps_24103)) {
    case TAG_Nil: {
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      heff_drop(v_done_244);
      V f_ = v_none_243;
      heff_room[0] = v_z_245;
      heff_room[1] = v_z_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_drop(v_none_243);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419(v_st_240, v_t_242, v_done_244, v_apps_24103, v_z_245, v_z_246));
    }
    default: return heff_nomatch(v_apps_24103);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam15(V self, V *args) {
  V v_x_24101 = args[0];
  V v_x_2496 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_bad_24102 = heff_take_field(v_x_24101, 1);
  V v_apps_24103 = heff_get_n(v_x_24101, 0, 2);
  V v_t_24104 = heff_tag_n(TAG_End, 2, (V[]){v_x_2496, NTAG(TAG_MkUnit)});
  V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_24106;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam16, 1, 9, (V[]){v_bad_24102, v_cmd_241, v_z_245, v_z_246, v_apps_24103, v_none_243, v_st_240, v_t_242, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam14(V self, V *args) {
  V v_x_2496 = args[0];
  V v_x_2488 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2497 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2499;
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Nothing: {
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2498 = heff_field(v_x_2488, 0);
    heff_take_n(v_x_2488, 1ULL, 1);
    v_t_2499 = v_x_2498;
    break;
  }
  default: heff_nomatch(v_x_2488);
  }
  V v_c_24100 = (g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(heff_dup(v_st_240), heff_dup(v_t_242), heff_dup(v_x_2496), v_t_2497, v_t_2499));
  V f_ = v_c_24100;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam15, 1, 8, (V[]){v_x_2496, v_z_245, v_cmd_241, v_z_246, v_none_243, v_st_240, v_t_242, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam12(V self, V *args) {
  V v_x_2485 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2488;
  switch (heff_tag_of(v_x_2485)) {
  case TAG_Left: {
    heff_take_n(v_x_2485, 0ULL, 1);
    v_x_2488 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2487 = heff_field(v_x_2485, 0);
    V v_ru_24x_2485_24Right = heff_take_reuse_n(v_x_2485, 1ULL, 1);
    v_x_2488 = heff_tag_at_n(v_ru_24x_2485_24Right, TAG_Just, 1, (V[]){v_y_2487});
    break;
  }
  default: heff_nomatch(v_x_2485);
  }
  V v_t_2490;
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Nothing: {
    v_t_2490 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2489 = heff_dup(heff_field(v_x_2488, 0));
    v_t_2490 = v_x_2489;
    break;
  }
  default: heff_nomatch(v_x_2488);
  }
  V v_total_2491 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2490; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2490); r_; });
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str16), v_total_2491, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam13_clo)})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2494}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2495;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam14, 1, 8, (V[]){v_x_2488, v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2452);
  V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str15)));
  V v_t_2455 = (g_std_2epath_2ejoin(v_t_2453, v_t_2454));
  V v_s_2456 = ({ V a_0 = v_st_240; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2455); r_; });
  V v_path_2457 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2456));
  V v_t_2458 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2457; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2460 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2458, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam7_clo)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_c_2484 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam8, 3, 1, (V[]){v_path_2457})));
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam12, 1, 7, (V[]){v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_errors_2423 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_seen_2424 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_none_243 = heff_env(self)[7];
  V v_done_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2425);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2423, 1)) {
    heff_drop(v_seen_2424);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2426 = v_errors_2423;
    V v_t_2427;
    if (heff_intEq_c_lent(v_n_2426, MK_INT(1LL), 2)) {
      heff_drop(v_n_2426);
      v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str2);
    } else {
      v_t_2427 = heff_strAppend(heff_intShow(v_n_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str3));
    }
    V v_what_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str4));
    V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str5), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str6));
    V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, v_what_2428), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str7));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str8)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2438;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam5, 1, 2, (V[]){v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_errors_2423);
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str9), heff_dup(v_cmd_241)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str10));
    V v_n_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2424; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2424); r_; });
    V v_t_2442;
    if (heff_intEq_c_lent(v_n_2441, MK_INT(1LL), 2)) {
      heff_drop(v_n_2441);
      v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str11);
    } else {
      v_t_2442 = heff_strAppend(heff_intShow(v_n_2441), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str12));
    }
    V v_str_2443 = heff_strAppend(heff_strAppend(v_t_2440, v_t_2442), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str13));
    V v_t_2444 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2443, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str14)), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2451;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam6, 1, 7, (V[]){v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_errors_2423 = heff_take_field(v_x_2422, 1);
  V v_seen_2424 = heff_get_n(v_x_2422, 0, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2419, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam4, 1, 9, (V[]){v_errors_2423, v_cmd_241, v_z_245, v_z_246, v_seen_2424, v_st_240, v_t_242, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2421 = ({ V a_0 = heff_dup(v_x_2419); V a_1 = v_t_2420; V a_2 = v_x_2413; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam3, 1, 8, (V[]){v_x_2419, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_str1), v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_lam2, 1, 8, (V[]){v_x_2413, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}