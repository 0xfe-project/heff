// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_c 317
#define LBL_copies 592412158
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_src 323678
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(V, V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1272156913x1766532544(V, V);
V g_list_2efoldl_24s1272156913x1766532544_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1272156913x1766532544_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1181715076x1618420649(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1181715076x1618420649_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1181715076x1618420649_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_std_2efilesystem_2ecopy_24s224212859x272253807(V, V, V);
V g_std_2efilesystem_2ecopy_24s224212859x272253807_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ecopy_24s224212859x272253807_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2efilesystem_2ereplace_24s1810255102x220553654(V, V, V);
V g_std_2efilesystem_2ereplace_24s1810255102x220553654_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereplace_24s1810255102x220553654_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}), heff_dup(g_std_2eordmap_2eempty_get()), v_ps_241));
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  HeffT3 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  V v_t_2416;
  {
    V v_field_2412 = v_t_2410.f[1];
    V v_field_2413 = v_t_2410.f[2];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      V v_j_2415 = v_field_2413;
      if (heff_intLe_c(heff_strLength(v_text_249), v_j_2415)) {
        v_t_2416 = v_x_2414;
      } else {
        heff_drop(v_x_2414);
        v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      heff_drop(v_field_2413);
      v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
  }
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, v_t_246, v_t_2416));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V v_e_240, V v_m_241, V v_x2_242, V v_n_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_m_241);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){v_n_243});
  }
  case TAG_Cons: {
    V v_l_246 = heff_field(v_x2_242, 0);
    V v_rest_247 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_strAppend(heff_dup(v_m_241), ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_str0)), v_l_246);
    V v_t_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_str1)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_lam0, 1, 6, (V[]){v_e_240, v_m_241, v_rest_247, v_n_243, v_p_244, v_p_245})));
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_n_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(v_e_240, v_m_241, v_rest_247, heff_intAdd(v_n_243, MK_INT(1LL)), v_p_244, v_p_245));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str3, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str5, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(V v_e_240, V v_name_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam0, 1, 4, (V[]){v_e_240, v_hd_242, v_name_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam1(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2456);
  V f_ = v_k_243;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam6, 1, 1, (V[]){v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 0ULL, 1);
    V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_x_244));
    V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2414), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str2)));
    V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
    V v_a_2435 = ({ V a_0 = v_st_2414; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_a_2435));
    V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_name_241));
    V v_t_2438 = (g_std_2epath_2ejoin(v_t_2436, v_t_2437));
    V v_t_2439 = ({ V a_0 = v_st_2414; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2438); r_; });
    V v_str_2440 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str3), v_t_2439);
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2440, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str4)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2430_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam5, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243})));
  }
  case TAG_Right: {
    V v_y_2457 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    heff_drop(v_st_2414);
    heff_drop(v_x_244);
    heff_drop(v_name_241);
    heff_drop(v_e_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = v_y_2457;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2414;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2414), heff_dup(v_x_244)));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2414), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_a_2418 = ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_a_2418));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2414), heff_dup(v_name_241)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2414; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2423); r_; });
  V v_t_2425 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam3_clo)}));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam4, 1, 6, (V[]){v_st_2414, v_x_244, v_name_241, v_e_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_lam2, 1, 5, (V[]){v_x_244, v_name_241, v_e_240, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(V v_e_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_str0), v_e_244), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_str1));
    V v_t_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_lam0, 1, 4, (V[]){v_e_240, v_rest_245, v_p_242, v_p_243}));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(v_e_240, v_rest_245, v_p_242, v_p_243));
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_entry, 13, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089(V v_e_240, V v_bi_241, V v_dir_242, V v_rt_243, V v_done_244, V v_c_245, V v_available_246, V v_r_247, V v_id_248, V v_texts_249, V v_backs_2410, V v_z_2411, V v_z_2412) {
top: ;
  V v_key_2413 = heff_take_field(v_r_247, 0);
  V v_effect_2414 = heff_get_n(v_r_247, 1, 2);
  V v_zig_2415 = heff_take_field(v_rt_243, 1);
  V v_c_2416 = heff_get_n(v_rt_243, 0, 2);
  V v_t_2417 = heff_get_n(heff_get_n(v_c_245, 5, 14), 0, 10);
  V v_t_2418 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_backs_2410, NTAG(TAG_Nil)));
  V v_bs_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2419));
  V v_t_2421 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2419; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2419); r_; });
  V v_t_2422 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_backs_2410, NTAG(TAG_Nil)));
  V v_bs_2423 = (g_list_2emap_24s1173914895x100384474(v_t_2422));
  V v_t_2424 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2423; V r_ = (g_list_2efoldl_24s1272156913x1766532544(a_0, a_1)); heff_drop(v_bs_2423); r_; });
  V v_t_2425 = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(v_c_2416, v_available_246, v_t_2417, v_key_2413, v_effect_2414, heff_dup(heff_rfield(v_bi_241, 1)), heff_rec_n(2, shape_units__copies, (V[]){v_t_2420, v_t_2421}), v_t_2424));
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989(v_e_240, v_bi_241, v_dir_242, v_zig_2415, v_id_248, v_texts_249, v_backs_2410, v_done_244, v_t_2425, v_z_2411, v_z_2412));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_entry(V self, V *a) {
  (void)self;
  V a9 = a[9]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a9, a[10], a[11], a[12]); heff_drop(a9); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058(V v_e_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str3); V a_6 = v_t_2416; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(heff_dup(v_e_240), v_sources_242, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam0, 1, 9, (V[]){v_e_240, v_bi_241, v_file_243, heff_dup(v_name_244), v_outPath_245, v_done_246, v_c_2413, v_z_248, v_z_249})});
    } else {
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_outPath_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str7), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam1, 1, 3, (V[]){v_e_240, v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058(a[0], a[1], a[2], a[3], a4, a[5], a[6], a7, a[8], a[9]); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_bi_241 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_244 = heff_env(self)[3];
  V v_outPath_245 = heff_env(self)[4];
  V v_done_246 = heff_env(self)[5];
  V v_c_2413 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2421 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str4); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str5); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_str6); V a_5 = v_x_2420; V r_ = (g_list_2ekeepIf_24s1181715076x1618420649(b_0, a_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = v_done_246; V a_6 = v_c_2413; V a_7 = v_t_2421; V a_8 = v_z_248; V a_9 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_name_244); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620(V v_e_240, V v_chk_241, V v_acc_242, V v_f_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam0, 1, 6, (V[]){v_e_240, v_f_243, v_hd_244, v_acc_242, v_chk_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2413);
  V f_ = v_k_245;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam3(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam8(V self, V *args) {
  V v_c_2423 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2424 = heff_take_field(v_c_2423, 1);
  V v_module_2425 = heff_get_n(v_c_2423, 0, 14);
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_x_2419, 2)), 1, 6);
  V v_t_2427 = (g_heff_2ebuild_2eload_2einside(heff_get_n(v_x_2419, 2, 5), v_t_2426, v_path_2424));
  if (((heff_dup(v_t_2427) == NTAG(TAG_True)) || ({ V v_t_2438 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_243))); int c_ = heff_strEq_c_lent(v_module_2425, v_t_2438, 0); heff_drop(v_t_2438); c_; }))) {
    heff_drop(v_x_248);
    heff_drop(v_f_243);
    heff_drop(v_t_2427);
    V v_x1_2428 = ({ V a_0 = v_module_2425; V b_1 = heff_get_n(v_acc_242, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(v_module_2425); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
    heff_drop(v_x1_2428);
    return v_ret_24bool;
  } else {
    heff_drop(v_x_248);
    heff_drop(v_f_243);
    heff_drop_rec(v_acc_242, 2);
    heff_drop(v_module_2425);
    heff_drop(v_t_2427);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_242, 0), heff_dup(v_x_2429)));
  V v_t_2435 = heff_intAdd(heff_get_n(v_acc_242, 1, 2), v_x_2420);
  V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2429; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_x_2429); r_; });
  V v_x_2437 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2434, heff_intAdd(v_t_2435, v_t_2436)});
  V f_ = v_k_245;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_2429 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam10, 1, 4, (V[]){v_acc_242, v_x_2429, v_x_2420, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_2418 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam8, 1, 4, (V[]){v_x_2419, v_x_248, v_f_243, heff_dup(v_acc_242)}), heff_get_n(v_x_2422, 0, 2)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_x_2429), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam9, 1, 7, (V[]){v_x_2418, v_e_240, v_hd_244, v_acc_242, v_x_2429, v_x_2420, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_acc_242 = heff_env(self)[5];
  V v_x_2418 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2421 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_x_2419)));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam7, 1, 9, (V[]){v_x_2419, v_x_248, v_f_243, v_acc_242, v_e_240, v_hd_244, v_x_2418, v_x_2420, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_str0), heff_dup(heff_rfield(v_x_2419, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam6, 1, 8, (V[]){v_e_240, v_x_2419, v_hd_244, v_x_248, v_f_243, v_acc_242, v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_f_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam5, 1, 7, (V[]){v_e_240, v_hd_244, v_x_248, v_f_243, v_acc_242, v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_chk_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_243)));
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_rfield(v_acc_242, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_249); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_drop(v_f_243);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_241, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam2, 1, 2, (V[]){v_k_245, v_acc_242})));
  } else {
    heff_drop(v_t_2410);
    V v_name_2414 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_243)));
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_241, v_name_2414, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam3_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2417, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam4, 1, 6, (V[]){v_e_240, v_f_243, v_hd_244, v_x_248, v_acc_242, v_k_245})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_chk_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), v_x_246, heff_dup(v_f_243)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_lam1, 1, 6, (V[]){v_f_243, v_acc_242, v_chk_241, v_e_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(V v_e_240, V v_st_241, V v_t_242, V v_rd_243, V v_acc_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_rd_243);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_244, 0)));
    V v_x_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_244, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x5_245, 0);
    V v_rest_2411 = heff_field(v_x5_245, 1);
    heff_take_n(v_x5_245, 3ULL, 2);
    V v_s_2412 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_str0)));
    V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
    V v_c_2414 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2413; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2413); r_; });
    V v_t_2415 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2419 = heff_tr(heff_call(v_c_2414, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam2, 2, 8, (V[]){v_c_2419, v_e_240, v_st_241, v_t_242, v_acc_244, v_x_2410, v_rd_243, v_rest_2411});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_rd_243 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  V v_rest_2411 = heff_env(self)[5];
  V v_hd_2420 = heff_env(self)[6];
  V v_k_2421 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2430);
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(v_e_240, v_st_241, v_t_242, v_rd_243, v_x_2427, v_rest_2411));
  V f_ = v_t_2431;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_rd_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2420 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_rest_2411 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_243), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_2420), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam5, 1, 8, (V[]){v_e_240, v_st_241, v_t_242, v_rd_243, v_x_2427, v_rest_2411, v_hd_2420, v_k_2421})));
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_rd_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_k_2421 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_t_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Just, 1, (V[]){v_y_2424});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_c_2426 = (g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), v_acc_244, v_x_2410, v_t_2425));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2420);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam4, 1, 7, (V[]){v_rd_243, v_e_240, v_hd_2420, v_st_241, v_t_242, v_rest_2411, v_k_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_rd_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_lam3, 1, 9, (V[]){v_e_240, v_st_241, v_t_242, v_acc_244, v_x_2410, v_hd_2420, v_rd_243, v_rest_2411, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(V v_e_240, V v_st_241, V v_t_242, V v_bp_243, V v_done_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_bp_243);
    return v_done_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_name_248 = heff_dup(heff_rfield(v_a_246, 0));
    V v_build_249 = heff_dup(heff_rfield(v_a_246, 1));
    V v_t_2410 = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_bp_243), v_done_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_clo), 7, (V[]){v_e_240, v_st_241, v_t_242, v_bp_243, v_name_248, v_build_249, v_t_2410});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str5, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam8, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam14, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522(V v_e_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x_245, V v_x6_246, V v_p_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nothing: {
    heff_drop(v_st_241);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_x_245);
    V v_t_249 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_243, NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam0, 1, 3, (V[]){v_next_244, v_p_247, v_p_248})));
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_x6_246, 0);
    V v_ru_24x6_246_24Just = heff_take_reuse_n(v_x6_246, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x6_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_243, heff_dup(v_n_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam1_clo)})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam2, 1, 8, (V[]){v_st_241, v_t_242, v_n_2412, v_e_240, v_p_247, v_x_245, v_next_244, v_p_248})));
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_p_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  V f_ = v_next_244;
  heff_room[0] = v_p_247;
  heff_room[1] = v_p_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2457 = args[1];
  V v_k_2458 = args[2];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    heff_take_n(v_x_2462, 0ULL, 1);
    v_t_2465 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2462, 0ULL, 1);
    v_t_2465 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V f_ = v_k_2461;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam9(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam10, 1, 1, (V[]){v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam13(V self, V *args) {
  V v_x_2484 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_p_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2484);
  V f_ = v_next_244;
  heff_room[0] = v_p_247;
  heff_room[1] = v_p_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam12(V self, V *args) {
  V v_x_2481 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam13, 1, 3, (V[]){v_next_244, v_p_247, v_p_248})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam14(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_2489 = args[1];
  V v_k_2490 = args[2];
  heff_drop(v_hd_2489);
  V f_ = v_k_2490;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2488});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam16(V self, V *args) {
  V v_x_24112 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_p_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24112);
  V v_t_24113 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24119}), v_p_247, v_p_248));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam15(V self, V *args) {
  V v_x_2492 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2492);
  V v_a_2493 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_241), heff_dup(v_t_242), v_x_245));
  V v_t_2494 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_a_2493));
  V v_t_2495 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_2412)));
  V v_t_2496 = (g_std_2epath_2ejoin(v_t_2494, v_t_2495));
  V v_t_2497 = ({ V a_0 = v_st_241; V a_1 = v_t_2496; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2496); r_; });
  V v_t_2498 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str4), v_t_2497), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str5));
  V v_t_2499 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_get_n(v_t_242, 1, 6)));
  V v_t_24100 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_2412));
  V v_t_24101 = (g_std_2epath_2ejoin(v_t_2499, v_t_24100));
  V v_t_24102 = ({ V a_0 = v_st_241; V a_1 = v_t_24101; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_24101); r_; });
  V v_why_24103 = heff_strAppend(v_t_2498, v_t_24102);
  V v_t_24104 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str6), v_why_24103), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str7));
  V v_t_24105 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24104, NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24111}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam16, 1, 3, (V[]){v_e_240, v_p_247, v_p_248})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam11(V self, V *args) {
  V v_x_2467 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  V v_x_2421 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2467) == NTAG(TAG_True))) {
    heff_drop(v_x_2467);
    heff_drop(v_x_2421);
    heff_drop(v_x_245);
    V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_take_field(v_t_242, 1)));
    V v_t_2469 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_2412));
    V v_t_2470 = (g_std_2epath_2ejoin(v_t_2468, v_t_2469));
    V v_path_2471 = ({ V a_0 = v_st_241; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2470); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_242, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str2));
    V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, v_path_2471), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str3));
    V v_t_2474 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2473, NTAG(TAG_MkUnit)});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2480}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam12, 1, 5, (V[]){v_x_2416, v_e_240, v_p_247, v_next_244, v_p_248})));
  } else {
    heff_drop(v_x_2467);
    heff_drop(v_x_2416);
    heff_drop(v_next_244);
    V v_path_2485 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2421));
    V v_c_2486 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2485; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2485); r_; });
    V v_t_2487 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2491 = heff_tr(heff_call(v_c_2486, 2, (V[]){v_t_2487, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam14_clo)}));
    V f_ = v_c_2491;
    heff_room[0] = heff_dup(v_p_247);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam15, 1, 7, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_e_240, v_p_247, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  V v_x_2416 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2466;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Left: {
    heff_take_n(v_x_2443, 0ULL, 1);
    v_c_2466 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam7_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2443, 0ULL, 1);
    V v_path_2448 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2421)));
    V v_t_2449 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 1))));
    V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_2412)));
    V v_t_2451 = (g_std_2epath_2ejoin(v_t_2449, v_t_2450));
    V v_s_2452 = ({ V a_0 = v_st_241; V a_1 = v_t_2451; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2451); r_; });
    V v_to_2453 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2452));
    V v_c_2454 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2448; V a_2 = v_to_2453; V r_ = (g_std_2efilesystem_2ereplace_24s1810255102x220553654(a_0, a_1, a_2)); heff_drop(v_path_2448); heff_drop(v_to_2453); r_; });
    V v_t_2455 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2459 = heff_tr(heff_call(v_c_2454, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam8_clo)}));
    v_c_2466 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam9, 2, 1, (V[]){v_c_2459});
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  V f_ = v_c_2466;
  heff_room[0] = heff_dup(v_p_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam11, 1, 10, (V[]){v_st_241, v_t_242, v_n_2412, v_e_240, v_p_247, v_x_2416, v_next_244, v_p_248, v_x_2421, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_2416 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2429);
  V v_a_2430 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_245)));
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_a_2430));
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_2412)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_s_2434 = ({ V a_0 = v_st_241; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2434));
  V v_to_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2421)));
  V v_c_2437 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2435; V a_2 = v_to_2436; V r_ = (g_std_2efilesystem_2ecopy_24s224212859x272253807(a_0, a_1, a_2)); heff_drop(v_path_2435); heff_drop(v_to_2436); r_; });
  V v_t_2438 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2442 = heff_tr(heff_call(v_c_2437, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam5_clo)}));
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_p_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam6, 1, 10, (V[]){v_x_2421, v_st_241, v_t_242, v_n_2412, v_e_240, v_p_247, v_x_2416, v_next_244, v_p_248, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 1))));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str0), heff_dup(v_n_2412)), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_str1));
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_t_2418));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
  V v_x_2421 = ({ V a_0 = v_st_241; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2421)));
  V v_c_2423 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2422; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2422); r_; });
  V v_t_2424 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2428 = heff_tr(heff_call(v_c_2423, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam3_clo)}));
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_p_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_lam4, 1, 10, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_x_2421, v_e_240, v_p_247, v_x_2416, v_next_244, v_p_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914(V v_e_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str0)));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str1)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_241; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_s_2414 = ({ V a_0 = v_st_241; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2414));
  V v_c_2416 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2415; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2415); r_; });
  V v_t_2417 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2421 = heff_tr(heff_call(v_c_2416, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam0_clo)}));
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam1, 1, 7, (V[]){v_progs_244, v_e_240, v_z_245, v_st_241, v_t_242, v_done_243, v_z_246})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam2(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_next_2429 = heff_env(self)[0];
  V v_hd_2430 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  V f_ = v_next_2429;
  heff_room[0] = v_hd_2430;
  heff_room[1] = v_k_2431;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x_2427 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_tag_n(TAG_End, 2, (V[]){v_x_2427, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam5, 1, 3, (V[]){v_next_2429, v_hd_2430, v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_done_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), v_done_243, heff_dup(v_progs_244), heff_dup(heff_rfield(v_t_242, 4))));
  V v_next_2429 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), v_t_2428, v_progs_244));
  V v_t_2435 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = heff_dup(v_x_2427); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam4, 2, 3, (V[]){v_x_2427, v_e_240, v_next_2429}); V a_5 = v_progs_244; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2435;
  heff_room[0] = v_z_245;
  heff_room[1] = v_z_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2422);
  V v_total_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_str2), v_total_2423, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam2_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2426, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_lam3, 1, 7, (V[]){v_e_240, v_st_241, v_t_242, v_done_243, v_progs_244, v_z_245, v_z_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402(V v_e_240, V v_outPath_241, V v_zig_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_246), heff_strLength_lent(v_outPath_241, 0));
  V v_t_249;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
    v_t_249 = heff_strSlice_lent(v_outPath_241, MK_INT(0LL), heff_box_word(v_t_248), 6);
  } else {
    v_t_249 = heff_dup(v_outPath_241);
  }
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str1))));
  V v_c_2411 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2410; V a_2 = v_zig_242; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2410); r_; });
  V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2416 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam0_clo)}));
  HEFF_LAST return g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(heff_dup(v_e_240), heff_dup(v_outPath_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam1, 2, 3, (V[]){v_c_2416, v_outPath_241, v_e_240}), v_o_243, v_z_244, v_z_245);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2414 = args[1];
  V v_k_2415 = args[2];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_outPath_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 0ULL, 1);
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
    V v_t_2422 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_2421), heff_strLength_lent(v_outPath_241, 0));
    V v_t_2424;
    if (heff_strEq_c(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str2))) {
      int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
      v_t_2424 = heff_strSlice(v_outPath_241, MK_INT(0LL), heff_box_word(v_t_2423));
    } else {
      v_t_2424 = v_outPath_241;
    }
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str3), heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str4)));
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_str5)), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam3, 1, 3, (V[]){v_e_240, v_hd_2417, v_k_2418})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop(v_outPath_241);
    heff_drop(v_e_240);
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_lam2, 1, 4, (V[]){v_outPath_241, v_e_240, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}