// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_e 319
#define LBL_holes 300818381
#define LBL_key 315609
#define LBL_match 305026527
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_tags 10047712
#define LBL_vars 10107635
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_tags__names__body[] = {LBL_tags, LBL_names, LBL_body};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eapartMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapartMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartMore_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebuiltApplied(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltApplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ehandedField(V, V);
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedField_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptMade_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emadeOne_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2epushArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etieDeps(V, V, V);
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieDeps_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2esimplify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_240, v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2epartialIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialIn(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_argv_247), v_f_246));
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EBool: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ESet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2elam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eapartMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartMore_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapartMore(V v_t_240, V v_vs_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_241));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_240, v_t_244}), NTAG(TAG_Nil)});
    return heff_rec_n(3, shape_tags__names__body, (V[]){v_t_245, v_vs_241, v_b_242});
  }
  case TAG_Just: {
    V v_ap_246 = heff_field(v_x4_243, 0);
    heff_drop(v_b_242);
    V v_tags_247 = heff_dup(heff_rfield(v_ap_246, 0));
    V v_names_248 = heff_dup(heff_rfield(v_ap_246, 1));
    V v_body_249 = heff_dup(heff_rfield(v_ap_246, 2));
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_241));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_240, v_t_2410}), v_tags_247});
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200(v_names_248, v_vs_241));
    return heff_rec_n(3, shape_tags__names__body, (V[]){v_t_2411, v_t_2412, v_body_249});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2eapartMore_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2eapartMore(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V v_x_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_EVar: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x41_243, 0);
      V v_argv_2410 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24EApp = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2450;
      switch (heff_tag_of(v_f_249)) {
      case TAG_EVar: {
        V v_y_2411 = heff_dup(heff_field(v_f_249, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_2411, 2)) {
          v_t_2450 = heff_intAdd(v_n_241, MK_INT(1LL));
        } else {
          v_t_2450 = v_n_241;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ELam: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EApp: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ELet: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ERecord: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EProj: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ETag: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EMatch: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EPrim: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ECall: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EInt: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EFloat: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EStr: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EBytes: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EFixed: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EFloat32: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EAbandon: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EBool: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_ESet: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EValues: {
        v_t_2450 = v_n_241;
        break;
      }
      case TAG_EFix: {
        v_t_2450 = v_n_241;
        break;
      }
      default: heff_nomatch(v_f_249);
      }
      V v_t_2451 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_243_24EApp, v_argv_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2450;
      V t_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2451});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2453 = heff_field(v_x41_243, 1);
      V v_b_2454 = heff_field(v_x41_243, 2);
      heff_take_n(v_x41_243, 6ULL, 3);
      V v_t_2455 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_a_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2454, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2455;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2456 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 2);
      V v_t_2458 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x4_242_24Cons, v_fs_2456, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2458;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2459 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_2459, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2464 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 2ULL, 3);
      V v_t_2466 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_242_24Cons, v_argv_2464, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2466;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2467 = heff_field(v_x41_243, 0);
      V v_arms_2468 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      V v_t_2469 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2468, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2467, v_t_2469});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2472 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 2ULL, 2);
      V v_t_2473 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_242_24Cons, v_argv_2472, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2473;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2475 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 2ULL, 2);
      V v_t_2476 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_242_24Cons, v_argv_2475, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2476;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2484 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_t_2485 = ({ V a_0 = v_c_2484; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2484); r_; });
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2485;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2487 = heff_field(v_x41_243, 1);
      V v_b_2488 = heff_field(v_x41_243, 2);
      heff_take_n(v_x41_243, 6ULL, 3);
      V v_t_2489 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_a_2487, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2488, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2489;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2490 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_t_2491 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_242_24Cons, v_es_2490, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2491;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialApp(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_g_249; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_argv_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2efewerThan(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialApp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_s_240, 2, 9); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_245;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_EVar: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        V v_xs_249 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 2);
        V v_x_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_249; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_n_242, v_x_2411, 0));
        heff_drop(v_n_242);
        heff_drop(v_x_2411);
        return v_ret_24bool;
      }
      case TAG_EApp: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_it1_246, 0ULL, 3);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_it1_246, 0ULL, 4);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_it1_246, 0ULL, 3);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_take_n(v_it1_246, 0ULL, 3);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_it1_246, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_n_242);
      heff_drop(v_field_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etakesMore(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V v_x1_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_246, v_p_242}});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x2_241, 0);
      V v_argv_248 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      HeffT2 v_t_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_e_2413 = heff_take_field(v_x_2412, 0);
        V v_vars_2414 = heff_take_field(v_x_2412, 1);
        V v_holes_2415 = heff_get_n(v_x_2412, 2, 4);
        V v_s_2416 = v_field_2411;
        V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_argv_248}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_s_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          V v_args_2421 = heff_take_field(v_x_2419, 0);
          V v_vars_2422 = heff_take_field(v_x_2419, 1);
          V v_holes_2423 = heff_get_n(v_x_2419, 2, 3);
          V v_t_2424 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x1_240_24Cons, v_vars_2414, v_vars_2422));
          V v_t_2425 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x2_241_24Cons, v_holes_2415, v_holes_2423));
          V v_x_2426 = heff_rec_n(3, shape_args__vars__holes, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_2413, v_args_2421}), v_t_2424, v_t_2425});
          return ((HeffT2){{v_x_2426, v_s_2420}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2418)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2earityIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earityIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2earityIn(V v_all_240, V v_g_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_all_240, v_g_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_EVar: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_ELam: {
        V v_xs_248 = heff_field(v_it1_245, 0);
        heff_take_n(v_it1_245, 1ULL, 2);
        return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      }
      case TAG_EApp: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ELet: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EProj: {
        heff_take_n(v_it1_245, 0ULL, 4);
        return MK_INT(0LL);
      }
      case TAG_ETag: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ECall: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EStr: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EAbandon: {
        return MK_INT(0LL);
      }
      case TAG_EBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_ESet: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_EValues: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFix: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      default: return heff_nomatch(v_it1_245);
      }
    } else {
      heff_drop(v_field_244);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2earityIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2estripLams_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_e_241, 0);
    V v_b_246 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_argv_247 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_245), v_argv_247));
    V v_m_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245));
    V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2414;
    if (heff_intLt_c(v_y_2411, v_x_2410)) {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_ys_245));
      v_e_2414 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_246});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_245);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_246;
    }
    V v_t_2415 = (g_std_2emap_2esize(v_m_249));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      heff_drop(v_m_249);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_2414);
    } else {
      V v_t_2416 = ({ V a_0 = v_m_249; V a_1 = v_e_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_249); r_; });
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2416);
    }
  }
  case TAG_EApp: {
    V v_e1_2417 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_2417)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EGlobal: {
      V v_g_2420 = heff_field(v_e1_2417, 0);
      V v_ru_24e1_2417_24EGlobal = heff_take_reuse_n(v_e1_2417, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EApp: {
        V v_argv_2422 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2423 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
        V v_t_2424 = (g_heff_2ecompile_2esimplify_2eappendL(v_argv_2422, v_t_2423));
        V v_t_2425 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2417_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2420}), v_t_2424});
        return heff_setField(v_d_242, MK_INT(2LL), v_t_2425);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2417, 0ULL, 4);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    default: return heff_nomatch(v_e1_2417);
    }
  }
  case TAG_ELet: {
    V v_x_2463 = heff_field(v_e_241, 0);
    V v_a_2464 = heff_field(v_e_241, 1);
    V v_b_2465 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2466 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2463, v_a_2464, heff_hole()});
    V v_u_2467 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2466));
    heff_drop(v_u_2467);
    V t_0 = v_zs_240;
    V t_1 = v_b_2465;
    V t_2 = v_cell_2466;
    v_zs_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2477 = heff_field(v_e_241, 0);
    V v_arms_2478 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2485 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0, 1, 1, (V[]){v_go_2479}), v_arms_2478));
    return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2477, v_t_2485}));
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EBool: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2499 = heff_field(v_e_241, 0);
    V v_a_24100 = heff_field(v_e_241, 1);
    V v_b_24101 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_24102 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2499, v_a_24100, heff_hole()});
    V v_u_24103 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_24102));
    heff_drop(v_u_24103);
    V t_0 = v_zs_240;
    V t_1 = v_b_24101;
    V t_2 = v_cell_24102;
    v_zs_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args) {
  V v_x2_2480 = args[0];
  V v_go_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkArm: {
    V v_t_2481 = heff_field(v_x2_2480, 0);
    V v_vs_2482 = heff_field(v_x2_2480, 1);
    V v_b_2483 = heff_field(v_x2_2480, 2);
    V v_ru_24x2_2480_24MkArm = heff_take_reuse_n(v_x2_2480, 7ULL, 3);
    V v_t_2484 = heff_tr(heff_call(v_go_2479, 1, (V[]){v_b_2483}));
    return heff_tag_at_n(v_ru_24x2_2480_24MkArm, TAG_MkArm, 3, (V[]){v_t_2481, v_vs_2482, v_t_2484});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_argv_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_argv_243));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(v_s_240, v_argv_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_242);
      heff_drop(v_argv_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_t_245 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_x21_249 = v_field_248;
            switch (heff_tag_of(v_x21_249)) {
            case TAG_MkPair: {
              V v_argv_2410 = heff_field(v_x21_249, 0);
              V v_f_2411 = heff_field(v_x21_249, 1);
              V v_ru_24x21_249_24MkPair = heff_take_reuse_n(v_x21_249, 3ULL, 2);
              V v_t_2412 = heff_tag_at_n(v_ru_24x21_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2410}), v_f_2411});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_249)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EGlobal: {
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x21_2418 = v_field_2417;
            switch (heff_tag_of(v_x21_2418)) {
            case TAG_MkPair: {
              V v_argv_2419 = heff_field(v_x21_2418, 0);
              V v_f_2420 = heff_field(v_x21_2418, 1);
              V v_ru_24x21_2418_24MkPair = heff_take_reuse_n(v_x21_2418, 3ULL, 2);
              V v_t_2421 = heff_tag_at_n(v_ru_24x21_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2419}), v_f_2420});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2418)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2414);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ELam: {
      V v_xs_2422 = heff_field(v_x21_242, 0);
      V v_b_2423 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_2422), heff_dup(v_b_2423)})));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        HeffT2 v_t_2425 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_x21_2428 = v_field_2427;
            switch (heff_tag_of(v_x21_2428)) {
            case TAG_MkPair: {
              V v_argv_2429 = heff_field(v_x21_2428, 0);
              V v_f_2430 = heff_field(v_x21_2428, 1);
              V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
              V v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2422, v_b_2423}), v_argv_2429});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_2428_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_f_2430})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2428)}});
            }
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_xs_2422);
            heff_drop(v_b_2423);
            heff_drop(v_field_2427);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_t_2424);
        V v_t_2432 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_rest_243)));
        V v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2432); r_; });
        if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
          heff_drop(v_t_2433);
          V v_t_2434 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_240}), v_rest_243});
          V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2422, v_b_2423})});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
        } else {
          heff_drop(v_k_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_xs_2422);
          heff_drop(v_b_2423);
          heff_drop(v_t_2433);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_EApp: {
      V v_t_2438 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_t_2438);
        HeffT2 v_t_2439 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2441 = v_t_2439.f[1];
          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
          if ((v_tag_2440 == ((int64_t)0ULL))) {
            V v_x21_2442 = v_field_2441;
            switch (heff_tag_of(v_x21_2442)) {
            case TAG_MkPair: {
              V v_argv_2443 = heff_field(v_x21_2442, 0);
              V v_f_2444 = heff_field(v_x21_2442, 1);
              V v_ru_24x21_2442_24MkPair = heff_take_reuse_n(v_x21_2442, 3ULL, 2);
              V v_t_2445 = heff_tag_at_n(v_ru_24x21_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2443}), v_f_2444});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2445}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2442)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2441);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2438);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ELet: {
      V v_t_2449 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        HeffT2 v_t_2450 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2452 = v_t_2450.f[1];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            V v_x21_2453 = v_field_2452;
            switch (heff_tag_of(v_x21_2453)) {
            case TAG_MkPair: {
              V v_argv_2454 = heff_field(v_x21_2453, 0);
              V v_f_2455 = heff_field(v_x21_2453, 1);
              V v_ru_24x21_2453_24MkPair = heff_take_reuse_n(v_x21_2453, 3ULL, 2);
              V v_t_2456 = heff_tag_at_n(v_ru_24x21_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2454}), v_f_2455});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2456}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2453)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 3);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2452);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2449);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ERecord: {
      V v_t_2459 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
        heff_drop(v_t_2459);
        HeffT2 v_t_2460 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2462 = v_t_2460.f[1];
          int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
          if ((v_tag_2461 == ((int64_t)0ULL))) {
            V v_x21_2463 = v_field_2462;
            switch (heff_tag_of(v_x21_2463)) {
            case TAG_MkPair: {
              V v_argv_2464 = heff_field(v_x21_2463, 0);
              V v_f_2465 = heff_field(v_x21_2463, 1);
              V v_ru_24x21_2463_24MkPair = heff_take_reuse_n(v_x21_2463, 3ULL, 2);
              V v_t_2466 = heff_tag_at_n(v_ru_24x21_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2464}), v_f_2465});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2466}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2463)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2462);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2459);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EProj: {
      V v_t_2471 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_t_2471);
        HeffT2 v_t_2472 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2474 = v_t_2472.f[1];
          int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
          if ((v_tag_2473 == ((int64_t)0ULL))) {
            V v_x21_2475 = v_field_2474;
            switch (heff_tag_of(v_x21_2475)) {
            case TAG_MkPair: {
              V v_argv_2476 = heff_field(v_x21_2475, 0);
              V v_f_2477 = heff_field(v_x21_2475, 1);
              V v_ru_24x21_2475_24MkPair = heff_take_reuse_n(v_x21_2475, 3ULL, 2);
              V v_t_2478 = heff_tag_at_n(v_ru_24x21_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2476}), v_f_2477});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2478}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2475)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 4);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2474);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 4);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2471);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ETag: {
      V v_t_2482 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
        heff_drop(v_t_2482);
        HeffT2 v_t_2483 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2485 = v_t_2483.f[1];
          int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
          if ((v_tag_2484 == ((int64_t)0ULL))) {
            V v_x21_2486 = v_field_2485;
            switch (heff_tag_of(v_x21_2486)) {
            case TAG_MkPair: {
              V v_argv_2487 = heff_field(v_x21_2486, 0);
              V v_f_2488 = heff_field(v_x21_2486, 1);
              V v_ru_24x21_2486_24MkPair = heff_take_reuse_n(v_x21_2486, 3ULL, 2);
              V v_t_2489 = heff_tag_at_n(v_ru_24x21_2486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2487}), v_f_2488});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2489}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2486)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 3);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2485);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2482);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EMatch: {
      V v_t_2492 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
        heff_drop(v_t_2492);
        HeffT2 v_t_2493 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2495 = v_t_2493.f[1];
          int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
          if ((v_tag_2494 == ((int64_t)0ULL))) {
            V v_x21_2496 = v_field_2495;
            switch (heff_tag_of(v_x21_2496)) {
            case TAG_MkPair: {
              V v_argv_2497 = heff_field(v_x21_2496, 0);
              V v_f_2498 = heff_field(v_x21_2496, 1);
              V v_ru_24x21_2496_24MkPair = heff_take_reuse_n(v_x21_2496, 3ULL, 2);
              V v_t_2499 = heff_tag_at_n(v_ru_24x21_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2497}), v_f_2498});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2499}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2496)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2495);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2492);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EPrim: {
      V v_t_24101 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
        heff_drop(v_t_24101);
        HeffT2 v_t_24102 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24104 = v_t_24102.f[1];
          int64_t v_tag_24103 = ((int64_t)v_t_24102.f[0]);
          if ((v_tag_24103 == ((int64_t)0ULL))) {
            V v_x21_24105 = v_field_24104;
            switch (heff_tag_of(v_x21_24105)) {
            case TAG_MkPair: {
              V v_argv_24106 = heff_field(v_x21_24105, 0);
              V v_f_24107 = heff_field(v_x21_24105, 1);
              V v_ru_24x21_24105_24MkPair = heff_take_reuse_n(v_x21_24105, 3ULL, 2);
              V v_t_24108 = heff_tag_at_n(v_ru_24x21_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24106}), v_f_24107});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24108}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24105)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24104);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24101);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EPrimCall: {
      V v_t_24111 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
        heff_drop(v_t_24111);
        HeffT2 v_t_24112 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24114 = v_t_24112.f[1];
          int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
          if ((v_tag_24113 == ((int64_t)0ULL))) {
            V v_x21_24115 = v_field_24114;
            switch (heff_tag_of(v_x21_24115)) {
            case TAG_MkPair: {
              V v_argv_24116 = heff_field(v_x21_24115, 0);
              V v_f_24117 = heff_field(v_x21_24115, 1);
              V v_ru_24x21_24115_24MkPair = heff_take_reuse_n(v_x21_24115, 3ULL, 2);
              V v_t_24118 = heff_tag_at_n(v_ru_24x21_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24116}), v_f_24117});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24118}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24115)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24114);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24111);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ECall: {
      V v_t_24121 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24121) == NTAG(TAG_True))) {
        heff_drop(v_t_24121);
        HeffT2 v_t_24122 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24124 = v_t_24122.f[1];
          int64_t v_tag_24123 = ((int64_t)v_t_24122.f[0]);
          if ((v_tag_24123 == ((int64_t)0ULL))) {
            V v_x21_24125 = v_field_24124;
            switch (heff_tag_of(v_x21_24125)) {
            case TAG_MkPair: {
              V v_argv_24126 = heff_field(v_x21_24125, 0);
              V v_f_24127 = heff_field(v_x21_24125, 1);
              V v_ru_24x21_24125_24MkPair = heff_take_reuse_n(v_x21_24125, 3ULL, 2);
              V v_t_24128 = heff_tag_at_n(v_ru_24x21_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24126}), v_f_24127});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24128}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24125)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24124);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24121);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EInt: {
      V v_t_24130 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
        heff_drop(v_t_24130);
        HeffT2 v_t_24131 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24133 = v_t_24131.f[1];
          int64_t v_tag_24132 = ((int64_t)v_t_24131.f[0]);
          if ((v_tag_24132 == ((int64_t)0ULL))) {
            V v_x21_24134 = v_field_24133;
            switch (heff_tag_of(v_x21_24134)) {
            case TAG_MkPair: {
              V v_argv_24135 = heff_field(v_x21_24134, 0);
              V v_f_24136 = heff_field(v_x21_24134, 1);
              V v_ru_24x21_24134_24MkPair = heff_take_reuse_n(v_x21_24134, 3ULL, 2);
              V v_t_24137 = heff_tag_at_n(v_ru_24x21_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24135}), v_f_24136});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24137}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24134)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24133);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24130);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EFloat: {
      V v_t_24139 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24139) == NTAG(TAG_True))) {
        heff_drop(v_t_24139);
        HeffT2 v_t_24140 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24142 = v_t_24140.f[1];
          int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
          if ((v_tag_24141 == ((int64_t)0ULL))) {
            V v_x21_24143 = v_field_24142;
            switch (heff_tag_of(v_x21_24143)) {
            case TAG_MkPair: {
              V v_argv_24144 = heff_field(v_x21_24143, 0);
              V v_f_24145 = heff_field(v_x21_24143, 1);
              V v_ru_24x21_24143_24MkPair = heff_take_reuse_n(v_x21_24143, 3ULL, 2);
              V v_t_24146 = heff_tag_at_n(v_ru_24x21_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24144}), v_f_24145});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24146}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24143)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24142);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24139);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EStr: {
      V v_t_24148 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24148) == NTAG(TAG_True))) {
        heff_drop(v_t_24148);
        HeffT2 v_t_24149 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24151 = v_t_24149.f[1];
          int64_t v_tag_24150 = ((int64_t)v_t_24149.f[0]);
          if ((v_tag_24150 == ((int64_t)0ULL))) {
            V v_x21_24152 = v_field_24151;
            switch (heff_tag_of(v_x21_24152)) {
            case TAG_MkPair: {
              V v_argv_24153 = heff_field(v_x21_24152, 0);
              V v_f_24154 = heff_field(v_x21_24152, 1);
              V v_ru_24x21_24152_24MkPair = heff_take_reuse_n(v_x21_24152, 3ULL, 2);
              V v_t_24155 = heff_tag_at_n(v_ru_24x21_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24153}), v_f_24154});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24155}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24152)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24151);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24148);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EBytes: {
      V v_t_24157 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24157) == NTAG(TAG_True))) {
        heff_drop(v_t_24157);
        HeffT2 v_t_24158 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24160 = v_t_24158.f[1];
          int64_t v_tag_24159 = ((int64_t)v_t_24158.f[0]);
          if ((v_tag_24159 == ((int64_t)0ULL))) {
            V v_x21_24161 = v_field_24160;
            switch (heff_tag_of(v_x21_24161)) {
            case TAG_MkPair: {
              V v_argv_24162 = heff_field(v_x21_24161, 0);
              V v_f_24163 = heff_field(v_x21_24161, 1);
              V v_ru_24x21_24161_24MkPair = heff_take_reuse_n(v_x21_24161, 3ULL, 2);
              V v_t_24164 = heff_tag_at_n(v_ru_24x21_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24162}), v_f_24163});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24164}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24161)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24160);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24157);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EFixed: {
      V v_t_24167 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
        heff_drop(v_t_24167);
        HeffT2 v_t_24168 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24170 = v_t_24168.f[1];
          int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
          if ((v_tag_24169 == ((int64_t)0ULL))) {
            V v_x21_24171 = v_field_24170;
            switch (heff_tag_of(v_x21_24171)) {
            case TAG_MkPair: {
              V v_argv_24172 = heff_field(v_x21_24171, 0);
              V v_f_24173 = heff_field(v_x21_24171, 1);
              V v_ru_24x21_24171_24MkPair = heff_take_reuse_n(v_x21_24171, 3ULL, 2);
              V v_t_24174 = heff_tag_at_n(v_ru_24x21_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24172}), v_f_24173});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24174}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24171)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24170);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24167);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EFloat32: {
      V v_t_24176 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24176) == NTAG(TAG_True))) {
        heff_drop(v_t_24176);
        HeffT2 v_t_24177 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24179 = v_t_24177.f[1];
          int64_t v_tag_24178 = ((int64_t)v_t_24177.f[0]);
          if ((v_tag_24178 == ((int64_t)0ULL))) {
            V v_x21_24180 = v_field_24179;
            switch (heff_tag_of(v_x21_24180)) {
            case TAG_MkPair: {
              V v_argv_24181 = heff_field(v_x21_24180, 0);
              V v_f_24182 = heff_field(v_x21_24180, 1);
              V v_ru_24x21_24180_24MkPair = heff_take_reuse_n(v_x21_24180, 3ULL, 2);
              V v_t_24183 = heff_tag_at_n(v_ru_24x21_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24181}), v_f_24182});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24183}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24180)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24179);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24176);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EAbandon: {
      V v_t_24184 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24184) == NTAG(TAG_True))) {
        heff_drop(v_t_24184);
        HeffT2 v_t_24185 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24187 = v_t_24185.f[1];
          int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
          if ((v_tag_24186 == ((int64_t)0ULL))) {
            V v_x21_24188 = v_field_24187;
            switch (heff_tag_of(v_x21_24188)) {
            case TAG_MkPair: {
              V v_argv_24189 = heff_field(v_x21_24188, 0);
              V v_f_24190 = heff_field(v_x21_24188, 1);
              V v_ru_24x21_24188_24MkPair = heff_take_reuse_n(v_x21_24188, 3ULL, 2);
              V v_t_24191 = heff_tag_at_n(v_ru_24x21_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24189}), v_f_24190});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24191}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24188)}});
            }
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24187);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24184);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EBool: {
      V v_t_24193 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24193) == NTAG(TAG_True))) {
        heff_drop(v_t_24193);
        HeffT2 v_t_24194 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24196 = v_t_24194.f[1];
          int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
          if ((v_tag_24195 == ((int64_t)0ULL))) {
            V v_x21_24197 = v_field_24196;
            switch (heff_tag_of(v_x21_24197)) {
            case TAG_MkPair: {
              V v_argv_24198 = heff_field(v_x21_24197, 0);
              V v_f_24199 = heff_field(v_x21_24197, 1);
              V v_ru_24x21_24197_24MkPair = heff_take_reuse_n(v_x21_24197, 3ULL, 2);
              V v_t_24200 = heff_tag_at_n(v_ru_24x21_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24198}), v_f_24199});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24200}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24197)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24196);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24193);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ESet: {
      V v_t_24204 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24204) == NTAG(TAG_True))) {
        heff_drop(v_t_24204);
        HeffT2 v_t_24205 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24207 = v_t_24205.f[1];
          int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
          if ((v_tag_24206 == ((int64_t)0ULL))) {
            V v_x21_24208 = v_field_24207;
            switch (heff_tag_of(v_x21_24208)) {
            case TAG_MkPair: {
              V v_argv_24209 = heff_field(v_x21_24208, 0);
              V v_f_24210 = heff_field(v_x21_24208, 1);
              V v_ru_24x21_24208_24MkPair = heff_take_reuse_n(v_x21_24208, 3ULL, 2);
              V v_t_24211 = heff_tag_at_n(v_ru_24x21_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24209}), v_f_24210});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24211}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24208)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 3);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24207);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24204);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EValues: {
      V v_t_24213 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24213) == NTAG(TAG_True))) {
        heff_drop(v_t_24213);
        HeffT2 v_t_24214 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24216 = v_t_24214.f[1];
          int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
          if ((v_tag_24215 == ((int64_t)0ULL))) {
            V v_x21_24217 = v_field_24216;
            switch (heff_tag_of(v_x21_24217)) {
            case TAG_MkPair: {
              V v_argv_24218 = heff_field(v_x21_24217, 0);
              V v_f_24219 = heff_field(v_x21_24217, 1);
              V v_ru_24x21_24217_24MkPair = heff_take_reuse_n(v_x21_24217, 3ULL, 2);
              V v_t_24220 = heff_tag_at_n(v_ru_24x21_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24218}), v_f_24219});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24220}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24217)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 1);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24216);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24213);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EFix: {
      V v_t_24223 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_24223) == NTAG(TAG_True))) {
        heff_drop(v_t_24223);
        HeffT2 v_t_24224 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_24226 = v_t_24224.f[1];
          int64_t v_tag_24225 = ((int64_t)v_t_24224.f[0]);
          if ((v_tag_24225 == ((int64_t)0ULL))) {
            V v_x21_24227 = v_field_24226;
            switch (heff_tag_of(v_x21_24227)) {
            case TAG_MkPair: {
              V v_argv_24228 = heff_field(v_x21_24227, 0);
              V v_f_24229 = heff_field(v_x21_24227, 1);
              V v_ru_24x21_24227_24MkPair = heff_take_reuse_n(v_x21_24227, 3ULL, 2);
              V v_t_24230 = heff_tag_at_n(v_ru_24x21_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_24228}), v_f_24229});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24230}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_24227)}});
            }
          } else {
            heff_drop_tag(v_x21_242, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_24226);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_24223);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam45(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ehandedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandedField(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam0, 1, 1, (V[]){v_a_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam1, 1, 1, (V[]){v_a_241});
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam2, 1, 1, (V[]){v_a_241});
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam3, 1, 1, (V[]){v_a_241});
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam4, 1, 1, (V[]){v_a_241});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam5, 1, 1, (V[]){v_a_241});
  }
  case TAG_EProj: {
    V v_a1_2419 = heff_dup(heff_field(v_a_241, 0));
    switch (heff_tag_of(v_a1_2419)) {
    case TAG_EVar: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam6, 1, 1, (V[]){v_a_241});
    }
    case TAG_EGlobal: {
      V v_g_2425 = heff_field(v_a1_2419, 0);
      heff_take_n(v_a1_2419, 1ULL, 1);
      switch (heff_tag_of(v_a_241)) {
      case TAG_EProj: {
        V v_l_2427 = heff_field(v_a_241, 1);
        V v_sh_2428 = heff_field(v_a_241, 2);
        V v_t_2429 = heff_field(v_a_241, 3);
        heff_take_n(v_a_241, 14ULL, 4);
        HeffT2 v_t_2430 = ({ V b_0 = heff_get_n(v_s_240, 2, 9); V a_1 = v_g_2425; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2432 = v_t_2430.f[1];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_x_2433 = v_field_2432;
            heff_drop(v_x_2433);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam7, 1, 4, (V[]){v_g_2425, v_l_2427, v_sh_2428, v_t_2429});
          } else {
            heff_drop(v_field_2432);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam8, 1, 4, (V[]){v_g_2425, v_l_2427, v_sh_2428, v_t_2429});
          }
        }
      }
      default: return heff_nomatch(v_a_241);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam9, 1, 1, (V[]){v_a_241});
    }
    case TAG_EApp: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam10, 1, 1, (V[]){v_a_241});
    }
    case TAG_ELet: {
      heff_take_n(v_a1_2419, 0ULL, 3);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam11, 1, 1, (V[]){v_a_241});
    }
    case TAG_ERecord: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam12, 1, 1, (V[]){v_a_241});
    }
    case TAG_EProj: {
      heff_take_n(v_a1_2419, 0ULL, 4);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam13, 1, 1, (V[]){v_a_241});
    }
    case TAG_ETag: {
      heff_take_n(v_a1_2419, 0ULL, 3);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam14, 1, 1, (V[]){v_a_241});
    }
    case TAG_EMatch: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam15, 1, 1, (V[]){v_a_241});
    }
    case TAG_EPrim: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam16, 1, 1, (V[]){v_a_241});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam17, 1, 1, (V[]){v_a_241});
    }
    case TAG_ECall: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam18, 1, 1, (V[]){v_a_241});
    }
    case TAG_EInt: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam19, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat: {
      heff_take_na(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam20, 1, 1, (V[]){v_a_241});
    }
    case TAG_EStr: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam21, 1, 1, (V[]){v_a_241});
    }
    case TAG_EBytes: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam22, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFixed: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam23, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat32: {
      heff_take_na(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam24, 1, 1, (V[]){v_a_241});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam25, 1, 1, (V[]){v_a_241});
    }
    case TAG_EBool: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam26, 1, 1, (V[]){v_a_241});
    }
    case TAG_ESet: {
      heff_take_n(v_a1_2419, 0ULL, 3);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam27, 1, 1, (V[]){v_a_241});
    }
    case TAG_EValues: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam28, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFix: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam29, 1, 1, (V[]){v_a_241});
    }
    default: return heff_nomatch(v_a1_2419);
    }
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam30, 1, 1, (V[]){v_a_241});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam31, 1, 1, (V[]){v_a_241});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam32, 1, 1, (V[]){v_a_241});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam33, 1, 1, (V[]){v_a_241});
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam34, 1, 1, (V[]){v_a_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam35, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam36, 1, 1, (V[]){v_a_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam37, 1, 1, (V[]){v_a_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam38, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam39, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam40, 1, 1, (V[]){v_a_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam41, 1, 1, (V[]){v_a_241});
  }
  case TAG_EBool: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam42, 1, 1, (V[]){v_a_241});
  }
  case TAG_ESet: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam43, 1, 1, (V[]){v_a_241});
  }
  case TAG_EValues: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam44, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam45, 1, 1, (V[]){v_a_241});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ehandedField(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_248});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2411});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2415});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam5(V self, V *args) {
  V v_s_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2418});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam6(V self, V *args) {
  V v_s_2424 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2424});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_l_2427 = heff_env(self)[1];
  V v_sh_2428 = heff_env(self)[2];
  V v_t_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2427, v_sh_2428, v_t_2429});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_s_2434});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam8(V self, V *args) {
  V v_s_2436 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_l_2427 = heff_env(self)[1];
  V v_sh_2428 = heff_env(self)[2];
  V v_t_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2437 = (g_heff_2ecompile_2esimplify_2eknownField_24cpr(v_g_2425, v_l_2427, v_s_2436));
  {
    V v_field_2438 = v_t_2437.f[0];
    V v_field_2439 = v_t_2437.f[1];
    V v_x_2440 = v_field_2438;
    V v_s_2441 = v_field_2439;
    V v_x_2444;
    switch (heff_tag_of(v_x_2440)) {
    case TAG_Nothing: {
      v_x_2444 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2427, v_sh_2428, v_t_2429});
      break;
    }
    case TAG_Just: {
      V v_v_2442 = heff_field(v_x_2440, 0);
      V v_ru_24x_2440_24Just = heff_take_reuse_n(v_x_2440, 1ULL, 1);
      V v_t_2443 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_v_2442)));
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop(v_g_2425);
        heff_drop(v_l_2427);
        heff_drop(v_sh_2428);
        heff_drop(v_t_2429);
        heff_drop_cell(v_ru_24x_2440_24Just, 1);
        heff_drop(v_t_2443);
        v_x_2444 = v_v_2442;
      } else {
        heff_drop(v_v_2442);
        heff_drop(v_t_2443);
        v_x_2444 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24x_2440_24Just, TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2427, v_sh_2428, v_t_2429});
      }
      break;
    }
    default: heff_nomatch(v_x_2440);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2441});
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam9(V self, V *args) {
  V v_s_2447 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam10(V self, V *args) {
  V v_s_2450 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam11(V self, V *args) {
  V v_s_2454 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam12(V self, V *args) {
  V v_s_2457 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2457});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam13(V self, V *args) {
  V v_s_2462 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam14(V self, V *args) {
  V v_s_2466 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2466});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam15(V self, V *args) {
  V v_s_2469 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2469});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam16(V self, V *args) {
  V v_s_2471 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2471});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam17(V self, V *args) {
  V v_s_2474 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2474});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam18(V self, V *args) {
  V v_s_2477 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2477});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam19(V self, V *args) {
  V v_s_2479 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2479});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam20(V self, V *args) {
  V v_s_2481 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2481});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam21(V self, V *args) {
  V v_s_2483 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2483});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam22(V self, V *args) {
  V v_s_2485 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2485});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam23(V self, V *args) {
  V v_s_2488 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2488});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam24(V self, V *args) {
  V v_s_2490 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2490});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam25(V self, V *args) {
  V v_s_2491 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2491});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam26(V self, V *args) {
  V v_s_2493 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2493});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam27(V self, V *args) {
  V v_s_2497 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2497});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam28(V self, V *args) {
  V v_s_2499 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2499});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam29(V self, V *args) {
  V v_s_24102 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24102});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam30(V self, V *args) {
  V v_s_24106 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24106});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam31(V self, V *args) {
  V v_s_24109 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24109});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam32(V self, V *args) {
  V v_s_24111 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24111});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam33(V self, V *args) {
  V v_s_24114 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam34(V self, V *args) {
  V v_s_24117 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24117});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam35(V self, V *args) {
  V v_s_24119 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24119});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam36(V self, V *args) {
  V v_s_24121 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24121});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam37(V self, V *args) {
  V v_s_24123 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam38(V self, V *args) {
  V v_s_24125 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24125});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam39(V self, V *args) {
  V v_s_24128 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24128});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam40(V self, V *args) {
  V v_s_24130 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24130});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam41(V self, V *args) {
  V v_s_24131 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24131});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam42(V self, V *args) {
  V v_s_24133 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24133});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam43(V self, V *args) {
  V v_s_24137 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24137});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam44(V self, V *args) {
  V v_s_24139 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24139});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam45(V self, V *args) {
  V v_s_24142 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24142});
}
Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltApplied_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2ebuiltApplied(V v_r_240, V v_f_241, V v_l_242, V v_e_243, V v_argv_244, V v_s_245) {
top: ;
  V v_simp_246 = heff_take_field(v_r_240, 0);
  V v_applyTo_247 = heff_get_n(v_r_240, 1, 4);
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(v_l_242, v_e_243, v_s_245));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_s_2412 = v_field_2410;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop(v_simp_246);
      heff_drop(v_applyTo_247);
      V v_x_2413 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_244));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_2412});
    }
    case TAG_Just: {
      V v_v_2414 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_f_241);
      V v_m_2415 = heff_tr(heff_call(v_simp_246, 1, (V[]){v_v_2414}));
      V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_t_2419 = (g_heff_2ecompile_2esimplify_2eprunedCopy(v_x_2417, v_argv_244));
        return heff_tail(v_applyTo_247, 3, (V[]){v_t_2419, v_argv_244, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltApplied_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ebuiltApplied(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2epushArm_24cpr(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_t_247, v_p_243));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2452;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_EVar: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2411, 0ULL, 4);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2432 = heff_field(v_x_2411, 1);
        heff_take_n(v_x_2411, 2ULL, 2);
        v_t_2452 = v_arms_2432;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      V v_m_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2452}));
      V v_x2_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_MkPair: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_s_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2455}), v_s_2456}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2454)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2emadeOne_24cpr(heff_dup(v_h_241), v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    heff_drop(v_x_247);
    V v_s_248 = v_field_246;
    HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ekeptMade_24cpr(v_h_241, v_s_248));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_x_2412 = v_field_2410;
      V v_s_2413 = v_field_2411;
      return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam0, 1, 3, (V[]){heff_dup(v_x_2412), heff_dup(v_h_241), v_b0_242}), heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam1, 2, 3, (V[]){v_x_2412, v_more_240, v_h_241}), v_s_2413));
    }
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_b0_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2esimplify_2emakeFresh(v_h_241, v_b0_242, v_p_2414));
  }
  case TAG_Just: {
    V v_b_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_h_241);
    heff_drop(v_b0_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_p_2414});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_b3_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b3_2416, v_x_2424}), v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args) {
  V v_b3_2416 = args[0];
  V v_z_2417 = args[1];
  V v_x_2412 = heff_env(self)[0];
  V v_more_240 = heff_env(self)[1];
  V v_h_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2426;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_m_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, MK_INT(5LL), heff_dup(v_h_241), v_b3_2416}));
    break;
  }
  case TAG_Just: {
    V v_t_2419 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b3_2416)));
    V v_t_2420 = (g_heff_2ecompile_2eir_2enubI(v_t_2419));
    V v_m_2421 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2420}));
    v_m_2426 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam2, 1, 2, (V[]){v_m_2421, v_b3_2416});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_x2_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_z_2417}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_s_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_x_2428)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_dup(heff_field(v_x_2428, 0));
      v_t_2432 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x_2428);
    }
    HeffT2 v_t_2433 = ({ V a_0 = v_x_2412; V a_1 = heff_dup(v_h_241); V a_2 = v_t_2432; V a_3 = v_s_2429; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2erefsMade_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2412); r_; });
    {
      V v_field_2434 = v_t_2433.f[0];
      V v_field_2435 = v_t_2433.f[1];
      V v_x_2436 = v_field_2434;
      heff_drop(v_x_2436);
      V v_s_2437 = v_field_2435;
      V v_t_2440;
      switch (heff_tag_of(v_x_2428)) {
      case TAG_MkPair: {
        V v_x_2438 = heff_dup(heff_field(v_x_2428, 0));
        v_t_2440 = v_x_2438;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      HeffT2 v_t_2441 = (g_heff_2ecompile_2esimplify_2eknownMade_24cpr(heff_dup(v_h_241), v_t_2440, v_s_2437));
      {
        V v_field_2442 = v_t_2441.f[0];
        V v_field_2443 = v_t_2441.f[1];
        V v_x_2444 = v_field_2442;
        heff_drop(v_x_2444);
        V v_s_2445 = v_field_2443;
        V v_t_2448;
        switch (heff_tag_of(v_x_2428)) {
        case TAG_MkPair: {
          V v_x_2446 = heff_dup(heff_field(v_x_2428, 0));
          v_t_2448 = v_x_2446;
          break;
        }
        default: heff_nomatch(v_x_2428);
        }
        V v_t_2451;
        switch (heff_tag_of(v_x_2428)) {
        case TAG_MkPair: {
          V v_y_2450 = heff_dup(heff_field(v_x_2428, 1));
          v_t_2451 = v_y_2450;
          break;
        }
        default: heff_nomatch(v_x_2428);
        }
        V v_m_2452 = (g_heff_2ecompile_2esimplify_2etieDeps(heff_dup(v_h_241), v_t_2448, v_t_2451));
        V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2445}));
        switch (heff_tag_of(v_x2_2453)) {
        case TAG_MkPair: {
          V v_x_2454 = heff_field(v_x2_2453, 0);
          V v_s_2455 = heff_field(v_x2_2453, 1);
          V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
          V v_t_2458;
          switch (heff_tag_of(v_x_2428)) {
          case TAG_MkPair: {
            V v_x_2456 = heff_field(v_x_2428, 0);
            heff_take_n(v_x_2428, 1ULL, 2);
            v_t_2458 = v_x_2456;
            break;
          }
          default: heff_nomatch(v_x_2428);
          }
          V v_t_2459 = heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_t_2458}), NTAG(TAG_Nil)});
          V v_x_2460 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2454, v_t_2459));
          return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){v_x_2460, v_s_2455});
        }
        default: return heff_nomatch(v_x2_2453);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_cell_247;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps(a[0], a[1], a[2]);
}